"""Revision check (2026-10-25): is the divergence of the abrupt-shedding quadratic case a solver artefact?
Repeats the quadratic-estimate case of abrupt_shedding_window.py with tighter settings
(Radau, rtol 1e-9, atol 1e-11, max_step 1 ms, window 2 s). Writes solver_check.json in this folder.
Usage (archive root): python -I posthoc_revision_20261025/solver_check.py"""
import sys, json, math, csv
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
HERE = Path(__file__).resolve().parent; SRC = HERE.parent / 'research_intelligence'; sys.path.insert(0, str(SRC / 'cdl1/code'))
import hdl2b_run as H
OUT = SRC / 'cdl1/out/HDL2b_20261021_a'
mods = H.import_models(str(SRC)); E = mods['e1_core']; model = H.make_model(mods, 'S3')
ms = {m['id']: m for m in json.loads((OUT / 'results.json').read_text(encoding='utf-8'))['members']}
m = ms['S3_P0.65_G0.20']; G = 0.20
d = H.dispatch_HDL2(E, model, E.Dispatcher(model), 0.65, G); sysm = H.RealSystem(mods, model, d['rho']); x0 = d['x0']
invM = np.zeros_like(sysm.M); nz = sysm.M != 0; invM[nz] = 1 / sysm.M[nz]
h = m['HAKT']['h']; c = (m['HAKT']['rho_plus'] - 2 * m['dGf'] + m['HAKT']['rho_minus']) / h ** 2
kfd = (m['HAKT']['rho_plus'] - m['HAKT']['rho_minus']) / (2 * h); dgf = m['dGf']
g = 2 * dgf / (1 - kfd + math.sqrt((1 - kfd) ** 2 - 2 * c * dgf))
ok, xe, *_ = H.path_step(sysm, x0, G, 0, g)
sol = solve_ivp(lambda t, x: invM * sysm.f(x, G - g), (0, 2.0), x0, method='Radau', rtol=1e-9, atol=1e-11, max_step=1e-3)
vb = np.hypot(sol.y[sysm.b[0]], sol.y[sysm.b[1]]) - np.hypot(xe[sysm.b[0]], xe[sysm.b[1]])
res = dict(case='quadratic', dG=g, method='Radau', rtol=1e-9, atol=1e-11, max_step_s=1e-3, success=bool(sol.success),
           message=str(sol.message), last_time_s=float(sol.t[-1]), max_abs_bus102_dev_pu=float(np.abs(vb).max()))
(HERE / 'solver_check.json').write_text(json.dumps(res, indent=2), encoding='utf-8'); print(res)
