"""Revision cross-check (2026-10-25) of the archived 79-member records: within-group structure of the
first-order prediction, sign-test discrimination against the constant (+) baseline, and resolution of the
quadratic-estimate comparison against the finite bisection bracket of the reference.
Reads the sealed members.csv / results.json only.
Usage (archive root): python -I posthoc_revision_20261025/stats_audit.py . posthoc_revision_20261025/stats_audit.json"""
import csv, json, math, sys
from pathlib import Path
import numpy as np
from scipy.stats import pearsonr, spearmanr
root = Path(sys.argv[1]); out = Path(sys.argv[2])
R = root / 'research_intelligence/cdl1/out/HDL2b_20261021_a'
rows = [r for r in csv.DictReader((R/'members.csv').open(encoding='utf8')) if r['in_E'] == 'True']
ms = {m['id']: m for m in json.loads((R/'results.json').read_text(encoding='utf8'))['members']}
f = np.array([float(r['dGf']) for r in rows]); t = np.array([float(r['dGt']) for r in rows])
k = np.array([float(r['k_tam']) for r in rows]); kl = np.array([float(r['k_L']) for r in rows])
P = np.array([float(r['P_akt']) for r in rows]); G = np.array([float(r['G_R']) for r in rows])
x = k/(1-k); y = (t-f)/f; xl = kl/(1-kl)
res = {}
res['n'] = len(rows)
res['pearson_all'] = pearsonr(x, y)[0]; res['spearman_all'] = spearmanr(x, y)[0]
res['pearson_all_load_side'] = pearsonr(xl, y)[0]
# within-group
grp = {}
for p in sorted(set(P)):
    m = P == p
    grp[f'{p:.3f}'] = dict(n=int(m.sum()), pearson=float(pearsonr(x[m], y[m])[0]), spearman=float(spearmanr(x[m], y[m])[0]),
                           x_range=[float(x[m].min()), float(x[m].max())], y_range=[float(y[m].min()), float(y[m].max())])
res['within_group'] = grp
# group means
gm = np.array([[x[P == p].mean(), y[P == p].mean()] for p in sorted(set(P))])
res['pearson_group_means'] = pearsonr(gm[:, 0], gm[:, 1])[0]
# pooled within-group (demeaned) correlation
xd = x.copy(); yd = y.copy()
for p in set(P):
    m = P == p; xd[m] -= x[m].mean(); yd[m] -= y[m].mean()
res['pearson_pooled_within_group_demeaned'] = pearsonr(xd, yd)[0]
# share of variance of y explained by P group alone (eta^2)
ss_tot = ((y-y.mean())**2).sum(); ss_between = sum((P == p).sum()*(y[P == p].mean()-y.mean())**2 for p in set(P))
res['eta_squared_y_by_P'] = ss_between/ss_tot
# does x add beyond P-group? linear model y ~ group dummies + x
X = np.column_stack([(P == p).astype(float) for p in sorted(set(P))] + [x])
beta, *_ = np.linalg.lstsq(X, y, rcond=None); res['coef_x_given_group_dummies'] = float(beta[-1])
# within-group permutation test of pooled demeaned correlation (two-sided), fixed seed
rng = np.random.default_rng(20261025); obs = res['pearson_pooled_within_group_demeaned']; cnt = 0; B = 20000
for _ in range(B):
    yp = yd.copy()
    for p in set(P):
        idx = np.where(P == p)[0]; yp[idx] = yd[rng.permutation(idx)]
    if abs(pearsonr(xd, yp)[0]) >= abs(obs): cnt += 1
res['within_group_perm_p_two_sided'] = (cnt+1)/(B+1); res['perm_B'] = B; res['perm_seed'] = 20261025
# Sign test 8a: rule vs constant '+' baseline
sign_true = np.sign(t-f); rule = np.sign(k); base = np.ones_like(rule)
res['sign_agreement_rule'] = int((rule == sign_true).sum()); res['sign_agreement_plus_baseline'] = int((base == sign_true).sum())
res['discordant_rule_vs_baseline'] = int((rule != base).sum())
res['mcnemar_note'] = 'no discordant pairs: exact McNemar p = 1; the sign test carries no discriminating information'
# 0/79 audit
q = []; curv = []
for r, a in zip(rows, f):
    m = ms[r['id']]; h = m['HAKT']['h']; c = (m['HAKT']['rho_plus']-2*a+m['HAKT']['rho_minus'])/h**2
    kd = (m['HAKT']['rho_plus']-m['HAKT']['rho_minus'])/(2*h); curv.append(c); q.append(2*a/(1-kd+math.sqrt((1-kd)**2-2*c*a)))
q = np.array(q); gap = t-q; tol = 1e-4*f
res['quadratic_gap_min'] = float(gap.min()); res['quadratic_gap_argmin_id'] = rows[int(gap.argmin())]['id']
res['bisection_tol_at_argmin'] = float(tol[gap.argmin()])
res['n_gap_below_bisection_tol'] = int((gap < tol).sum()); res['n_gap_below_half_tol'] = int((gap < tol/2).sum())
res['n_gap_below_tie_tol_2e-3'] = int((gap < 2e-3*f).sum())
# bracket geometry of the reference (hdl2b_run.py: grid step 0.01*dGf, bisection until width <= 1e-4*dGf, dGt = midpoint)
w = 0.01*f
while True:
    if np.all(w <= 1e-4*f): break
    w = np.where(w > 1e-4*f, w/2, w)
hw = w/2
res['final_bracket_width_over_dGf'] = float((w/f).max())
res['n_quadratic_below_stable_end_of_bracket'] = int((t - hw - q > 0).sum())
res['min_clearance_below_stable_end_pu'] = float((t - hw - q).min())
res['min_clearance_member'] = rows[int((t - hw - q).argmin())]['id']
res['gap_over_tol_quantiles'] = [float(v) for v in np.quantile(gap/tol, [0, .1, .5, .9, 1])]
res['first_order_overshoot_pct_range'] = [float(v) for v in [100*(f/(1-k)/t-1).min(), 100*(f/(1-k)/t-1).max()]]
# MAE reductions (exact vs rounded)
mae = lambda p: float(np.mean(np.abs(p-t)))
res['mae_frozen'] = mae(f); res['mae_quadratic'] = mae(q)
res['mae_reduction_quadratic_pct'] = 100*(1-mae(q)/mae(f))
json.dump(res, out.open('w'), indent=2, default=float)
print(json.dumps({k: v for k, v in res.items() if k != 'within_group'}, indent=2, default=float))
