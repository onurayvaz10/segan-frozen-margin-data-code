"""Revision check (2026-10-25): direct abrupt-shedding simulation with a longer integration window.

Same model, member (S3, P_set = 0.65, G_R = 0.20), four shedding amounts, solver (Radau, rtol 1e-7,
atol 1e-9, max_step 5 ms) and initial state (common pre-shedding equilibrium) as posthoc/abrupt_validation.py.
Only the window is changed (default 3.0 s instead of 0.5 s), because over 0.5 s the oscillation envelope
of the quadratic-estimate and recorded-reference cases was still growing.

Usage (from the archive root):  python -I posthoc_revision_20261025/abrupt_shedding_window.py [T_END_s]
Writes only into posthoc_revision_20261025/. Historical files are not modified.
"""
from pathlib import Path
import csv, json, sys, math
import numpy as np
from scipy.integrate import solve_ivp

HERE = Path(__file__).resolve().parent
SRC = HERE.parent / 'research_intelligence'
sys.path.insert(0, str(SRC / 'cdl1/code'))
import hdl2b_run as H

T_END = float(sys.argv[1]) if len(sys.argv) > 1 else 3.0
OUT = SRC.parent / 'research_intelligence' / 'cdl1' / 'out' / 'HDL2b_20261021_a'
mods = H.import_models(str(SRC)); E = mods['e1_core']; model = H.make_model(mods, 'S3')
rows = [r for r in csv.DictReader((OUT / 'members.csv').open(encoding='utf-8')) if r['in_E'] == 'True']
sealed = json.loads((OUT / 'results.json').read_text(encoding='utf-8'))
members = {m['id']: m for m in sealed['members']}
r = min([r for r in rows if abs(float(r['P_akt']) - .65) < 1e-9], key=lambda z: abs(float(z['G_R']) - .20))
P = float(r['P_akt']); G = float(r['G_R']); m = members[r['id']]
d = H.dispatch_HDL2(E, model, E.Dispatcher(model), P, G); assert d['ok']
sysm = H.RealSystem(mods, model, d['rho']); xpre = d['x0']
invM = np.zeros_like(sysm.M); nz = sysm.M != 0; invM[nz] = 1 / sysm.M[nz]
h = m['HAKT']['h']
curv = (m['HAKT']['rho_plus'] - 2 * m['dGf'] + m['HAKT']['rho_minus']) / h ** 2
kfd = (m['HAKT']['rho_plus'] - m['HAKT']['rho_minus']) / (2 * h)
dgf = m['dGf']; dgt = m['ref']['dGt']
dg2 = 2 * dgf / (1 - kfd + math.sqrt((1 - kfd) ** 2 - 2 * curv * dgf))
dg1 = dgf / (1 - m['kappa']['k_tam'])
EM = mods['e1_model']; dc = EM.IX[EM.V_DC]
cases = [('frozen', dgf), ('quadratic', dg2), ('recorded_reference', dgt), ('tangent', dg1)]
summary = dict(member=r['id'], P_set=P, G_R=G, T_end_s=T_END, method='Radau', rtol=1e-7, atol=1e-9,
               max_step_s=0.005, initial_state='pre-shedding equilibrium x0', cases=[])
outrows = []
for name, g in cases:
    Gpost = G - g
    ok, xe, *_ = H.path_step(sysm, xpre, G, 0, g); assert ok
    def rhs(t, x): return invM * sysm.f(x, Gpost)
    n = int(round(T_END * 1000)) + 1
    T = np.linspace(0, T_END, n)
    sol = solve_ivp(rhs, (0, T_END), xpre, t_eval=T, method='Radau', rtol=1e-7, atol=1e-9, max_step=.005)
    vdc = sol.y[dc] - xe[dc]
    vb = np.hypot(sol.y[sysm.b[0]], sol.y[sysm.b[1]]) - np.hypot(xe[sysm.b[0]], xe[sysm.b[1]])
    env = []
    for a in np.arange(0, T_END, 0.25):
        msk = (sol.t >= a) & (sol.t < a + 0.25)
        env.append(dict(t0=float(a), max_abs_bus102_dev_pu=float(np.abs(vb[msk]).max()) if msk.any() else None,
                        max_abs_vdc_dev_pu=float(np.abs(vdc[msk]).max()) if msk.any() else None))
    summary['cases'].append(dict(case=name, dG=float(g), success=bool(sol.success), solver_status=int(sol.status),
                                 solver_message=str(sol.message), last_sampled_time_s=float(sol.t[-1]),
                                 final_relative_distance=float(np.linalg.norm(sol.y[:, -1] - xe) / np.linalg.norm(xe)),
                                 envelope_250ms=env))
    for j, t in enumerate(sol.t):
        outrows.append([name, g, t, vdc[j], vb[j]])
with (HERE / 'abrupt_shedding_window_traces.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.writer(f); w.writerow(['case', 'dG', 'time_s', 'vdc_deviation_pu', 'bus102_voltage_deviation_pu']); w.writerows(outrows)
(HERE / 'abrupt_shedding_window.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps({c['case']: (c['success'], c['last_sampled_time_s']) for c in summary['cases']}))
