"""Revision cross-check (2026-10-25): SymPy/NumPy checks of Lemmas 1, 3, 4, 5, Examples 1-2 and Eqs. (18)-(19).
Usage: python -I posthoc_revision_20261025/math_check.py posthoc_revision_20261025/math_check.json"""
import sympy as sp, numpy as np, json, sys
out = {}
I2 = sp.eye(2); J = sp.Matrix([[0, -1], [1, 0]]); S = sp.diag(1, -1); N = sp.Matrix([[0, 1], [1, 0]])
# basis products
out['JS=N'] = bool(J*S == N); out['SJ=-N'] = bool(S*J == -N); out['JN=-S'] = bool(J*N == -S); out['NJ=S'] = bool(N*J == S)
out['J2=-I,S2=N2=I'] = bool(J*J == -I2 and S*S == I2 and N*N == I2)
# Lemma 4
P, V, th = sp.symbols('P V theta', positive=True)
vv = sp.Matrix([V*sp.cos(th), V*sp.sin(th)]); vd, vq = sp.symbols('v_d v_q', real=True)
i = P*sp.Matrix([vd, vq])/(vd**2+vq**2); Y = i.jacobian([vd, vq]).subs({vd: V*sp.cos(th), vq: V*sp.sin(th)})
R2 = sp.cos(2*th)*I2 + sp.sin(2*th)*J
out['Lemma4_eq10'] = bool(sp.simplify(Y - (-(P/V**2)*R2*S)) == sp.zeros(2))
g, Vp, thp = sp.symbols('g Vp thp', real=True)
Yg = -(P/(V+Vp*g)**2)*(sp.cos(2*thp*g)*I2 + sp.sin(2*thp*g)*J)*S
dY = Yg.diff(g).subs(g, 0)
out['Lemma4_eq11'] = bool(sp.simplify(dY - (2*P/V**3)*(Vp*S - (V*thp)*N)) == sp.zeros(2))
# Lemma 3 / 5 numerically with random complex matrices
rng = np.random.default_rng(1)
Jn = np.array([[0, -1], [1, 0]], float); Nn = np.array([[0, 1], [1, 0]], float); Sn = np.diag([1., -1.])
ok3 = True; ok5 = True
for _ in range(200):
    Ysrc = rng.normal(size=(2, 2)) + 1j*rng.normal(size=(2, 2)); Pn, Vn, GR = rng.uniform(.2, 1), rng.uniform(.8, 1.2), rng.uniform(0, 1)
    Ycpl = -(Pn/Vn**2)*Sn; Yt = Ysrc + GR*np.eye(2) + Ycpl
    lam, Rv = np.linalg.eig(Yt); Wl = np.linalg.inv(Rv)
    for kidx in range(2):
        v = Rv[:, kidx]; w = Wl[kidx, :]  # w @ Yt = lam w  (row vector, w* in paper's notation)
        proj = lambda X: (w @ X @ v)/(w @ v)
        ok3 &= abs(proj(Jn@Yt - Yt@Jn)) < 1e-9
        pix = proj(Nn)
        ok5 &= abs(pix - (Vn**2/(2*Pn))*proj(Jn@Ysrc - Ysrc@Jn)) < 1e-8
out['Lemma3_random'] = bool(ok3); out['Lemma5_eq16_random'] = bool(ok5)
# Lemma 1 numerically: Y(jw;p) = A(w)I + mu S + delta N with p entering mu
def crossing(p):
    from scipy.optimize import brentq
    A = lambda w: (0.7 - 1j*np.sqrt(3)) + (1+2j)*(w - 1.0)
    def lam(w):
        Yt = A(w)*np.eye(2) + (-1+0.3*p)*Sn + (0.5+0.2*p)*Nn + 2.0*Jn*1j*0.1*p
        # the two eigenvalues are A(w) +/- r and therefore equidistant from A(w); select the crossing branch by its
        # real part so that the choice does not depend on the eigenvalue order returned by LAPACK (fix 2026-10-25b)
        ev = np.linalg.eigvals(Yt); return ev[np.argmin(ev.real)]
    wst = brentq(lambda w: lam(w).imag, 0.2, 3.0); return lam(wst).real, wst, lam
h = 1e-6; r0, w0, lam0 = crossing(0.0); rp, _, _ = crossing(h); rm, _, _ = crossing(-h)
dl_dw = (lam0(w0+1e-7) - lam0(w0-1e-7))/2e-7; c = dl_dw.real/dl_dw.imag
eta = (crossing(h)[2](w0) - crossing(-h)[2](w0))/(2*h)
out['Lemma1_fd'] = float((rp-rm)/(2*h)); out['Lemma1_formula'] = float(eta.real - c*eta.imag)
# Example 1 table
def ex1(d0):
    mu = -1.0; r = np.hypot(mu, d0); D = 15 - d0**2; xi = np.array([5, -d0])/D
    kV = 2*xi[0]*(1/r); kth = -2*xi[1]*(-d0/r); return dict(r=r, D=D, xid=xi[0], xiq=xi[1], kV=kV, kth=kth, kL=kV+kth)
out['Example1'] = {str(d): {k: round(float(v), 4) for k, v in ex1(d).items()} for d in [0, 1, np.sqrt(5), 3]}
# Example 1 via eigenvectors directly
d0 = 3.0; Yt = 3.5*np.eye(2) - Sn + d0*Nn; lam, Rv = np.linalg.eig(Yt); kk = np.argmin(lam.real); v = Rv[:, kk]; w = np.linalg.inv(Rv)[kk]
out['Example1_<S>,<N>_d0=3'] = [float(((w@Sn@v)/(w@v)).real), float(((w@Nn@v)/(w@v)).real), 1/np.hypot(1, 3), -3/np.hypot(1, 3)]
# Example 2
b = 2.0; k = 1.0; s = np.sqrt(complex(k**2 - b**2)); Ast = 0.7 - 1j*np.sqrt(3)
Yc = lambda w: (Ast + (1+2j)*(w-1.0))*np.eye(2) + b*Jn - k*Sn
lam, Rv = np.linalg.eig(Yc(1.0)); kk = np.argmin(np.abs(lam.imag)); v = Rv[:, kk]; w = np.linalg.inv(Rv)[kk]
pr = lambda X: (w@X@v)/(w@v)
Yqs = np.array([[0, -2], [2, 2]], float); xi = np.linalg.solve(Yqs, [1, 0])
etaL = 2*(xi[0]*pr(Sn) - xi[1]*pr(Nn)); c2 = 0.5
out['Example2'] = dict(lambda_at_crossing=[float(lam[kk].real), float(lam[kk].imag)], two_pid_minus1=[float(pr(Sn).real), float(pr(Sn).imag)],
                       pi_x=[float(pr(Nn).real), float(pr(Nn).imag)], xi=[float(x) for x in xi], etaL=[float(etaL.real), float(etaL.imag)],
                       kappaL=float(etaL.real - c2*etaL.imag), expected=-0.5/np.sqrt(3))
# Example 2: Yqs = Ytot(j0)? A(0) = 1 stated; Ytot(0) = I + 2J - S = [[0,-2],[2,2]]
out['Example2_Yqs_check'] = (np.eye(2)*1 + 2*Jn - Sn).tolist()
# Quadratic root (18) and inequality (19)
Gf, kap, rho2, x = sp.symbols('Gf kappa rho2 x', real=True)
F2 = Gf + (kap-1)*x + sp.Rational(1, 2)*rho2*x**2
root = 2*Gf/((1-kap) + sp.sqrt((1-kap)**2 - 2*rho2*Gf))
num_ok = True
for _ in range(500):
    vals = {Gf: rng.uniform(0.01, .5), kap: rng.uniform(0.01, .9), rho2: -rng.uniform(0.01, 3)}
    rr = float(root.subs(vals)); num_ok &= abs(float(F2.subs(vals).subs(x, rr))) < 1e-10 and 0 < rr < float((Gf/(1-kap)).subs(vals))
out['Eq18_root_and_Eq19'] = bool(num_ok)
# 'lies above frozen iff kappa + rho2*Gf/2 > 0'
cnt = 0; bad = 0
for _ in range(2000):
    G_, k_, r_ = rng.uniform(0.01, .5), rng.uniform(0.01, .9), -rng.uniform(0.01, 5)
    rr = 2*G_/((1-k_) + np.sqrt((1-k_)**2 - 2*r_*G_)); cond = k_ + r_*G_/2 > 0
    bad += (rr > G_) != cond; cnt += 1
out['root_above_frozen_iff_condition_mismatches'] = int(bad)
json.dump(out, open(sys.argv[1], 'w'), indent=1, default=str); print(json.dumps(out, indent=1, default=str))
