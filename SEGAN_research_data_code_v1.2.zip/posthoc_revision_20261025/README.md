# Revision cross-checks, 25 October 2026 (archive v1.1)

This folder was added during the manuscript revision of 25 October 2026. It reads the sealed HDL2b records and the
retained model in `research_intelligence/` and the post-hoc outputs in `posthoc/`; it never writes outside this folder.
No historical or sealed file was modified.

Run from the archive root (Python 3.12, `pip install -r requirements_pinned.txt`):

| Command | Output | Purpose | Runtime (approx.) |
|---|---|---|---|
| `python -I posthoc_revision_20261025/stats_audit.py . posthoc_revision_20261025/stats_audit.json` | stats_audit.json | within-group structure of the first-order prediction; sign-test discrimination vs constant (+) baseline; resolution of the quadratic-estimate comparison against the reference bisection bracket (permutation seed 20261025) | 1 min |
| `python -I posthoc_revision_20261025/math_check.py posthoc_revision_20261025/math_check.json` | math_check.json | SymPy/NumPy checks of Lemmas 1, 3, 4, 5, Examples 1-2, Eqs. (18)-(19) (random seed 1) | < 1 min |
| `python -I posthoc_revision_20261025/abrupt_shedding_window.py 3.0` | abrupt_shedding_window.json, abrupt_shedding_window_traces.csv | the abrupt-shedding check of `posthoc/abrupt_validation.py` with a 3 s instead of a 0.5 s window | 1 min |
| `python -I posthoc_revision_20261025/solver_check.py` | solver_check.json | quadratic case of the abrupt check with tighter solver settings | < 1 min |
| `python -I posthoc_revision_20261025/make_figures.py` | figures/Figure_1..8.tif/.png | manuscript figures v1.1 from the archived data (Figure 5 = unchanged v1.0 Figure 3) | 1 min |

Figure numbering of the revised manuscript (v1.1) versus v1.0: 1→1, 2→2, 5→3, 6→4, 3→5, 4→6, 7→7, 8→8.

The whole sequence, including the v1.0 post-hoc scripts, can be run and checked in one step with `colab/run_all.py`
or the Colab notebook `colab/SEGAN_S1_Colab.ipynb` (see `colab/README_COLAB.md`).
