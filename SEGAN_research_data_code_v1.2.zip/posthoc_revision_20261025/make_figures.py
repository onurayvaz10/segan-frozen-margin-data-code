"""Revision (2026-10-25): regenerate Figures 1, 2, 4, 5, 6, 7 and 8 from archived data with reader-facing
notation, panel labels, units and non-overlapping labels. No numerical value is changed; every plotted number
is read from the archived CSV/JSON files named below (Figure 8 from the longer-window revision run).
Figure 5 of the revised manuscript (Figure 3 in v1.0) is unchanged (posthoc/reproduce_figure3.py); it is copied
as figures/Figure_5.tif. Figure numbers below follow the revised manuscript (v1.1).

Usage (archive root): python -I posthoc_revision_20261025/make_figures.py
Outputs: posthoc_revision_20261025/figures/Figure_<n>.tif (500 dpi, LZW) and .png (300 dpi).
"""
from pathlib import Path
import csv, json, math, statistics
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from PIL import Image

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SEALED = ROOT / 'research_intelligence/cdl1/out/HDL2b_20261021_a'
POST = ROOT / 'posthoc'
OUT = HERE / 'figures'; OUT.mkdir(exist_ok=True)
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8.5, 'axes.titlesize': 9, 'axes.labelsize': 8.5,
                     'legend.fontsize': 7.5, 'xtick.labelsize': 7.5, 'ytick.labelsize': 7.5, 'mathtext.fontset': 'dejavusans',
                     'axes.linewidth': 0.7, 'savefig.bbox': 'tight', 'savefig.pad_inches': 0.03})
W2 = 7.48  # double-column width, inches (190 mm)
GREYS = ['#1b9e77', '#d95f02', '#7570b3', '#e7298a', '#66a61e', '#e6ab02']


def save(fig, n):
    png = OUT / f'Figure_{n}.png'; tif = OUT / f'Figure_{n}.tif'
    fig.savefig(png, dpi=300)
    fig.savefig(OUT / f'_tmp_{n}.png', dpi=500)
    im = Image.open(OUT / f'_tmp_{n}.png').convert('RGB'); im.save(tif, compression='tiff_lzw', dpi=(500, 500))
    (OUT / f'_tmp_{n}.png').unlink(); plt.close(fig)


def panel(ax, s, x=-0.13, y=1.04):
    ax.text(x, y, s, transform=ax.transAxes, fontsize=9.5, fontweight='bold', va='bottom')


members = list(csv.DictReader((SEALED / 'members.csv').open(encoding='utf-8')))
E = [r for r in members if r['in_E'] == 'True']
sealed = {m['id']: m for m in json.loads((SEALED / 'results.json').read_text(encoding='utf-8'))['members']}

# ---------------------------------------------------------------- Figure 1 (schematic)
fig = plt.figure(figsize=(W2, 4.6))
axa = fig.add_axes([0, 0.47, 1, 0.5]); axb = fig.add_axes([0, 0.0, 1, 0.42])
for ax in (axa, axb):
    ax.set_xlim(0, 100); ax.set_ylim(0, 40); ax.axis('off')


def box(ax, x, y, w, h, txt, fc, ec, fs=7.6):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.4,rounding_size=1.2', fc=fc, ec=ec, lw=1.0))
    ax.text(x + w / 2, y + h / 2, txt, ha='center', va='center', fontsize=fs, linespacing=1.35)


box(axa, 1, 8, 25, 25, 'Grid-forming inverter\n(15 states)\nP–f / Q–V droop\nvirtual impedance $r_v, l_v$\ncascaded voltage/current PI\nactive damping, LCL filter', '#eaf1f8', '#2b5d8c')
axa.plot([31, 31], [5, 36], color='k', lw=3); axa.text(31, 37.5, 'Bus 101 ($v_1$)', ha='center', fontsize=7.8)
axa.annotate('', xy=(30.4, 20.5), xytext=(26.8, 20.5), arrowprops=dict(arrowstyle='->', lw=1))
box(axa, 36, 13, 22, 15, 'Dynamic π-line (6 states)\n$r = 0.01$, $x = 0.10$ pu\n$b/2 = 0.005$ pu at each end', '#fbf6e6', '#9a7a14')
axa.plot([31, 35.5], [20.5, 20.5], color='k', lw=1.2); axa.plot([58.6, 63], [20.5, 20.5], color='k', lw=1.2)
axa.plot([63, 63], [5, 36], color='#a33', lw=3); axa.text(63, 37.5, 'Bus 102 = port $b$ ($v_2$, frame $F_0$)', ha='center', fontsize=7.8, color='#a33')
box(axa, 69, 22, 30, 14, 'Active-rectifier CPL (12 states)\nPLL, LCL filter, DC link\nDC-voltage PI (settings S1–S3)\ninner current PI', '#fbecec', '#a33')
box(axa, 69, 3, 30, 13, 'Sheddable resistive load\n$G_R \\rightarrow G_R-\\Delta G$, $0<\\Delta G\\leq G_R$\nshifts equilibrium $x(\\Delta G)$', '#eaf6ee', '#2f7d4a')
for yy in (29, 9.5):
    axa.annotate('', xy=(68.6, yy), xytext=(63.4, yy), arrowprops=dict(arrowstyle='->', lw=1))
axa.text(0.5, 39.5, '(a)', fontsize=9.5, fontweight='bold')
steps = ['1. Operating point $x_0$\n(set-point $P_{set}$, $G_R$)\ngates K1–K7\nfrozen margin $\\Delta G_f^*$',
         '2. First-order sensitivity\none linear solve\n$Y_{qs}\\,\\xi = v_0$\n$\\hat\\kappa=\\mathrm{Re}[(1+jc)\\hat\\eta]$\nno further equilibrium',
         '3. Transfer pre-test\ntwo equilibria $x(\\pm h)$\n$\\kappa_{fd}$ vs $\\hat\\kappa$\n(re-used post hoc for $\\hat\\rho\'\'$)',
         '4. Blinded selection\nof $s_+$, $s_-$, recorded\nbefore any reference\nquantity',
         '5. Reference path\ncontinuation in $\\Delta G$,\n32-state eigenvalues\n$\\Rightarrow \\Delta G_t^*$; rules vs\nconstant-sign baselines']
cols = [('#f2f2f2', '#444'), ('#e6f5f2', '#1b7f6f'), ('#fbf1e2', '#b07513'), ('#f1ebf6', '#6d3e91'), ('#e9f0f8', '#2b5d8c')]
x = 1
for s, (fc, ec) in zip(steps, cols):
    box(axb, x, 4, 17.2, 27, s, fc, ec, fs=7.2)
    if x < 80:
        axb.annotate('', xy=(x + 19.6, 17.5), xytext=(x + 17.8, 17.5), arrowprops=dict(arrowstyle='->', lw=1.1))
    x += 20
axb.text(0.5, 37, '(b)', fontsize=9.5, fontweight='bold')
save(fig, 1)

# ---------------------------------------------------------------- Figure 2 (Example 1, analytical)
d0 = np.linspace(0, 3.25, 400); r = np.hypot(1, d0); D = 15 - d0 ** 2
kV = 10 / (r * D); kth = -2 * d0 ** 2 / (r * D); kL = kV + kth
fig, ax = plt.subplots(figsize=(W2 * 0.62, 2.5))
ax.plot(d0, kV, color='#2b5d8c', lw=1.6, label='$\\kappa_V$ (voltage magnitude)')
ax.plot(d0, kth, color='#d95f02', lw=1.6, ls='--', label='$\\kappa_\\theta$ (angle rotation)')
ax.plot(d0, kL, color='k', lw=2.0, label='$\\kappa_L=\\kappa_V+\\kappa_\\theta$')
ax.axhline(0, color='0.3', lw=0.7); ax.axvline(math.sqrt(5), color='0.4', lw=0.8, ls=':')
ax.text(math.sqrt(5) + 0.04, 0.55, '$\\delta_0=\\sqrt{5}$', fontsize=7.5)
ax.set_xlabel('Source anisotropy parameter $\\delta_0$ (pu)'); ax.set_ylabel('First-order coefficient (–)')
ax.grid(alpha=.25); ax.legend(loc='lower left', frameon=False)
save(fig, 2)

# ---------------------------------------------------------------- Figure 4 (prediction vs observation, estimator errors)
P = np.array([float(r['P_akt']) for r in E]); f = np.array([float(r['dGf']) for r in E]); t = np.array([float(r['dGt']) for r in E])
k = np.array([float(r['k_tam']) for r in E])
q = []
for r_, a in zip(E, f):
    m = sealed[r_['id']]; h = m['HAKT']['h']
    c = (m['HAKT']['rho_plus'] - 2 * a + m['HAKT']['rho_minus']) / h ** 2; kd = (m['HAKT']['rho_plus'] - m['HAKT']['rho_minus']) / (2 * h)
    q.append(2 * a / (1 - kd + math.sqrt((1 - kd) ** 2 - 2 * c * a)))
q = np.array(q)
x = k / (1 - k); y = (t - f) / f
loo = np.array([statistics.median(t[j] / f[j] for j in range(len(E)) if j != i) * f[i] for i in range(len(E))])
fig, axs = plt.subplots(1, 2, figsize=(W2, 2.9), gridspec_kw=dict(width_ratios=[1.15, 1]))
ax = axs[0]
for i, p in enumerate(sorted(set(P))):
    msk = P == p
    ax.scatter(x[msk], y[msk], s=11, color=GREYS[i], label=f'$P_{{set}}$ = {p:g}', zorder=3)
    cf = np.polyfit(x[msk], y[msk], 1); xx = np.linspace(x[msk].min(), x[msk].max(), 5)
    ax.plot(xx, np.polyval(cf, xx), color=GREYS[i], lw=0.9)
lim = [0.1, 0.56]; ax.plot(lim, lim, color='0.4', ls='--', lw=0.8, label='$y=x$')
ax.set_xlim(lim); ax.set_ylim(0.1, 0.46)
ax.set_xlabel('First-order predicted relative shift $\\hat\\kappa/(1-\\hat\\kappa)$ (–)')
ax.set_ylabel('Recorded relative shift (–)')
ax.text(0.03, 0.97, 'all members: Pearson $r$ = 0.937\nwithin each $P_{set}$ group:\nSpearman $\\rho_S$ = −1', transform=ax.transAxes, va='top', fontsize=7.2)
ax.legend(loc='lower right', bbox_to_anchor=(1.0, 0.0), fontsize=6.4, frameon=True, framealpha=0.9, ncol=2, columnspacing=0.8, handletextpad=0.3)
ax.set_xlim(0.1, 0.62)
ax.grid(alpha=.25); panel(ax, '(a)', x=-0.2)
ax = axs[1]
errs = [f - t, f / (1 - k) - t, loo - t, q - t]
labels = ['Frozen\n$\\Delta G_f^*$', 'First order\n$\\Delta G_{1st}^*$', 'Constant\nfactor (LOO)', 'Quadratic\n$\\Delta G_{2nd}^*$']
bp = ax.boxplot(errs, widths=0.55, patch_artist=True, medianprops=dict(color='k'), flierprops=dict(markersize=2.5))
for patch, col in zip(bp['boxes'], ['#c6dbef', '#fdd0a2', '#dadaeb', '#c7e9c0']): patch.set_facecolor(col)
ax.set_xticks(range(1, 5)); ax.set_xticklabels(labels, fontsize=7.2)
ax.axhline(0, color='#a33', lw=0.9, ls='--')
ax.set_ylabel('Signed error $\\widehat{\\Delta G}^*-\\Delta G_t^*$ (pu)')
ax.text(0.97, 0.04, 'above 0: beyond the recorded\nreference (overshoot)', transform=ax.transAxes, ha='right', va='bottom', fontsize=6.8, color='#a33')
ax.grid(alpha=.25, axis='y'); panel(ax, '(b)', x=-0.2)
fig.tight_layout(w_pad=2.0); save(fig, 6)  # manuscript Figure 6 (was Figure 4 in v1.0)

# ---------------------------------------------------------------- Figure 5 (grid heatmaps, all 90 members)
Pg = sorted(set(float(r['P_akt']) for r in members)); Gg = sorted(set(float(r['G_R']) for r in members))
fig, axs = plt.subplots(1, 2, figsize=(W2, 3.0))
for ax, which in zip(axs, ['dGt', 'rel']):
    M = np.full((len(Gg) + 3, len(Pg)), np.nan)  # include buffer rows 0.24-0.26 as empty
    Gfull = [round(0.17 + 0.01 * i, 2) for i in range(18)]
    for r_ in members:
        i = Gfull.index(round(float(r_['G_R']), 2)); j = Pg.index(float(r_['P_akt']))
        if r_['in_E'] == 'True':
            M[i, j] = float(r_['dGt']) if which == 'dGt' else 100 * (float(r_['dGt']) - float(r_['dGf'])) / float(r_['dGf'])
    im = ax.imshow(M[:len(Gfull)], origin='lower', aspect='auto', cmap='viridis' if which == 'dGt' else 'magma_r',
                   extent=[-0.5, len(Pg) - 0.5, Gfull[0] - 0.005, Gfull[-1] + 0.005])
    ax.axhspan(0.235, 0.265, color='0.88', zorder=2); ax.text(2.5, 0.25, 'blinding buffer (not part of the family)', ha='center', va='center', fontsize=6.8, zorder=3)
    for r_ in members:
        if r_['in_E'] != 'True':
            j = Pg.index(float(r_['P_akt'])); g = float(r_['G_R']); reason = r_['ne_reason']
            mk = 'x' if reason.startswith('K1') else ('^' if reason.startswith('K7') else 's')
            ax.plot(j, g, mk, color='k' if which == 'rel' else '#c00', ms=5, mew=1.2)
    ax.set_xticks(range(len(Pg))); ax.set_xticklabels([f'{p:g}' for p in Pg]); ax.set_xlabel('CPL set-point $P_{set}$ (pu)')
    ax.set_ylabel('Pre-shedding conductance $G_R$ (pu)')
    cb = fig.colorbar(im, ax=ax, fraction=0.05, pad=0.03)
    cb.set_label('$\\Delta G_t^*$ (pu)' if which == 'dGt' else '$(\\Delta G_t^*-\\Delta G_f^*)/\\Delta G_f^*$ (%)')
axs[0].plot([], [], 'x', color='#c00', label='K1 (operating limit)'); axs[0].plot([], [], '^', color='#c00', label='K7 (resolution)'); axs[0].plot([], [], 's', color='#c00', label='K2 (unstable at $x_0$)')
axs[0].legend(loc='upper left', fontsize=6.3, frameon=True, framealpha=0.9)
panel(axs[0], '(a)', x=-0.2); panel(axs[1], '(b)', x=-0.2)
fig.tight_layout(w_pad=1.5); save(fig, 3)  # manuscript Figure 3 (was Figure 5 in v1.0)

# ---------------------------------------------------------------- Figure 6 (decomposition, state participation)
grp = list(csv.DictReader((POST / 'table11_groups.csv').open(encoding='utf-8')))
pr = json.loads((POST / 'posthoc_reproduction.json').read_text(encoding='utf-8'))['benchmark_participation']
names = {'load1021:v_dc': 'CPL DC-link voltage $v_{dc}$', 'load1021:η': 'CPL DC-voltage PI integrator',
         'generator-101-1:ir_filter': 'GFM grid-side filter current (Re)', 'load1021:γd': 'CPL current-PI integrator ($d$)',
         'generator-101-1:ξd_ic': 'GFM voltage-PI integrator ($d$)', 'BUS 1-BUS 2-i_1:Il_R': 'Line current $i_l$ (Re)',
         'load1021:ir_cnv': 'CPL converter-side current (Re)', 'load1021:vr_filter': 'CPL filter voltage (Re)',
         'load1021:γq': 'CPL current-PI integrator ($q$)', 'generator-101-1:ξq_ic': 'GFM voltage-PI integrator ($q$)'}
fig, axs = plt.subplots(1, 2, figsize=(W2, 2.8), gridspec_kw=dict(width_ratios=[1.05, 1]))
ax = axs[0]; xs = np.arange(len(grp)); wdt = 0.2
series = [('k_V', '$\\hat\\kappa_V$', '#2b5d8c'), ('k_theta', '$\\hat\\kappa_\\theta$', '#1b9e77'),
          ('k_Delta', '$\\hat\\kappa_\\Delta$ (non-ideal CPL)', '#d95f02'), ('k_tam', '$\\hat\\kappa$ (total)', '0.15')]
for i, (key, lab, col) in enumerate(series):
    ax.bar(xs + (i - 1.5) * wdt, [float(g[key]) for g in grp], wdt, label=lab, color=col)
ax.axhline(0, color='k', lw=0.6); ax.set_xticks(xs); ax.set_xticklabels([f"{float(g['P_akt']):g}" for g in grp])
ax.set_xlabel('CPL set-point $P_{set}$ (pu)'); ax.set_ylabel('Group mean of coefficient (–)')
ax.legend(fontsize=6.6, frameon=False, loc='upper left'); ax.grid(alpha=.25, axis='y'); panel(ax, '(a)')
ax = axs[1]; top = pr[:8][::-1]
ax.barh(range(len(top)), [p['factor'] for p in top], color=['#a33' if p['state'].startswith('load') else ('#2b5d8c' if p['state'].startswith('gen') else '#b07513') for p in top])
ax.set_yticks(range(len(top))); ax.set_yticklabels([names.get(p['state'], p['state']) for p in top], fontsize=6.9)
for i, p in enumerate(top): ax.text(p['factor'] + 0.004, i, f"{p['factor']:.3f}", va='center', fontsize=6.6)
ax.set_xlim(0, 0.34); ax.set_xlabel('Normalized state participation $|r_k w_k|/\\sum_i |r_i w_i|$')
ax.grid(alpha=.25, axis='x'); panel(ax, '(b)', x=-0.62)
fig.tight_layout(w_pad=1.0); save(fig, 4)  # manuscript Figure 4 (was Figure 6 in v1.0)

# ---------------------------------------------------------------- Figure 7 (local perturbation at four equilibria)
tr = {}
for row in csv.DictReader((POST / 'time_domain_traces.csv').open(encoding='utf-8')):
    tr.setdefault(row['case'], []).append([float(row['time_s']), float(row['vdc_deviation_pu']), float(row['bus102_voltage_deviation_pu'])])
tr = {kk: np.array(v) for kk, v in tr.items()}
sty = {'frozen': ('Frozen $\\Delta G_f^*$', '#2b5d8c', '-'), 'quadratic': ('Quadratic $\\Delta G_{2nd}^*$', '#1b9e77', '--'),
       'recorded_reference': ('Recorded reference $\\Delta G_t^*$', 'k', ':'), 'tangent': ('Tangent $\\Delta G_{1st}^*$', '#c00', '-')}
fig, axs = plt.subplots(2, 2, figsize=(W2, 4.6))
order = ['frozen', 'quadratic', 'recorded_reference', 'tangent']
for col, (idx, ylab) in enumerate([(1, '$\\Delta v_{dc}$ ($10^{-4}$ pu)'), (2, '$\\Delta|v_{102}|$ ($10^{-4}$ pu)')]):
    for case in order:
        lab, c, ls = sty[case]; a = tr[case]; msk = a[:, 0] <= 0.06
        axs[0, col].plot(a[msk, 0] * 1e3, a[msk, idx] * 1e4, color=c, ls=ls, lw=1.0, label=lab)
        tt = np.arange(0, 1.0, 0.05); env = [np.abs(a[(a[:, 0] >= s0) & (a[:, 0] < s0 + 0.05), idx]).max() * 1e4 for s0 in tt]
        axs[1, col].semilogy(tt + 0.025, env, color=c, ls=ls, lw=1.2, marker='o', ms=2.2, label=lab)
    axs[0, col].set_xlabel('Time after the perturbation (ms)'); axs[0, col].set_ylabel(ylab)
    axs[1, col].set_xlabel('Time after the perturbation (s)'); axs[1, col].set_ylabel('Envelope of ' + ylab)
    for rr in (0, 1): axs[rr, col].grid(alpha=.25)
axs[1, 0].legend(fontsize=6.4, loc='lower left', frameon=True, framealpha=0.9)
for ax, s0 in zip(axs.flat, ['(a)', '(b)', '(c)', '(d)']): panel(ax, s0, x=-0.2, y=1.07)
fig.tight_layout(h_pad=1.2); save(fig, 7)

# ---------------------------------------------------------------- Figure 8 (abrupt shedding, 3 s window)
ab = {}
for row in csv.DictReader((HERE / 'abrupt_shedding_window_traces.csv').open(encoding='utf-8')):
    ab.setdefault(row['case'], []).append([float(row['time_s']), float(row['vdc_deviation_pu']), float(row['bus102_voltage_deviation_pu'])])
ab = {kk: np.array(v) for kk, v in ab.items()}
summ = {c['case']: c for c in json.loads((HERE / 'abrupt_shedding_window.json').read_text(encoding='utf-8'))['cases']}
fig, axs = plt.subplots(1, 3, figsize=(W2, 2.6))
for case in ['frozen', 'quadratic', 'recorded_reference', 'tangent']:
    lab, c, ls = sty[case]; a = ab[case]; msk = a[:, 0] <= 1.0
    axs[0].plot(a[msk, 0], a[msk, 2], color=c, ls=ls, lw=0.8, label=lab)
    axs[1].plot(a[msk, 0], a[msk, 1], color=c, ls=ls, lw=0.8)
    tt = np.arange(0, a[-1, 0], 0.05); env = [np.abs(a[(a[:, 0] >= s) & (a[:, 0] < s + 0.05), 2]).max() for s in tt]
    axs[2].semilogy(tt + 0.025, env, color=c, ls=ls, lw=1.1, marker='o', ms=1.8)
    if not summ[case]['success']:
        tl = summ[case]['last_sampled_time_s']
        axs[2].plot(tl, env[-1], 'x', color=c, ms=6, mew=1.4)
for ax in axs[:2]: ax.set_xlim(0, 1.0)
axs[0].set_ylim(-1.5, 1.5); axs[1].set_ylim(-0.25, 0.25)
axs[0].set_ylabel('$\\Delta|v_{102}|$ (pu)'); axs[1].set_ylabel('$\\Delta v_{dc}$ (pu)')
axs[2].set_ylabel('50-ms envelope of $|\\Delta|v_{102}||$ (pu)')
for ax in axs: ax.set_xlabel('Time after abrupt shedding (s)'); ax.grid(alpha=.25)
axs[2].set_xlim(0, 3.0)
axs[1].legend(*axs[0].get_legend_handles_labels(), fontsize=6.2, loc='lower left', frameon=True, framealpha=0.9)
axs[2].text(0.97, 0.62, '× integration stopped\n(trajectory diverged)', transform=axs[2].transAxes, ha='right', va='bottom', fontsize=6.4)
for ax, s in zip(axs, ['(a)', '(b)', '(c)']): panel(ax, s, x=-0.22, y=1.03)
fig.tight_layout(w_pad=0.8); save(fig, 8)
import shutil
shutil.copyfile(ROOT.parent / 'Figure_3_v1.0.tif' if (ROOT.parent / 'Figure_3_v1.0.tif').exists() else HERE / 'Figure_3_v1.0.tif', OUT / 'Figure_5.tif')
_im = Image.open(OUT / 'Figure_5.tif').convert('RGB'); _im.resize((_im.size[0] * 3 // 5, _im.size[1] * 3 // 5)).save(OUT / 'Figure_5.png', dpi=(300, 300))
print('figures written to', OUT)
