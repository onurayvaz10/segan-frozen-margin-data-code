# Running Supplementary Material S1 on Google Colab

## Option 1 — Colab notebook (no installation)

1. Open https://colab.research.google.com and choose *File ▸ Upload notebook*. Select `colab/SEGAN_S1_Colab.ipynb` from this archive.
2. Keep the default CPU runtime and choose *Runtime ▸ Run all*.
3. When the first cell asks for a file, upload `Supplementary_S1_data_code_v1.1.zip`. Alternatively, set `ARCHIVE_SOURCE = "drive"` or `"url"` in the settings cell.
4. After about 4–5 minutes the notebook shows `REPORT.md` and Figures 1–8, and downloads `segan_s1_results.zip`.

## Option 2 — any computer with Python 3.12

```bash
python -m venv segan_env && segan_env/bin/pip install -r requirements_pinned.txt   # Windows: segan_env\Scripts\pip
python colab/run_all.py --root . --python segan_env/bin/python --out segan_s1_results
```

`run_all.py` uses only the Python standard library. It runs the following steps in order:

| Step | Script | What it reproduces |
|---|---|---|
| S0 | `research_intelligence/cdl1/code/hdl2b_run.py --check-only` | hashes of the preregistration and the 13 pinned inputs of the sealed run |
| P1 | `posthoc/reproduce_tables.py` | Tables 7–8 |
| P2 | `posthoc/reproduce_posthoc.py` | post-hoc statistics, local nonlinear check (Figure 7 data) |
| P3 | `posthoc/reproduce_figure3.py` | model curve of Figure 5 (v1.0 Figure 3) |
| P4 | `posthoc/abrupt_validation.py` | v1.0 abrupt-shedding check (0.5 s) |
| R1 | `posthoc_revision_20261025/stats_audit.py` | within-group statistics, sign-rule discrimination, bisection resolution |
| R2 | `posthoc_revision_20261025/math_check.py` | checks of Lemmas 1–5 and Eqs. (18)–(19) |
| R3 | `posthoc_revision_20261025/abrupt_shedding_window.py 3.0` | abrupt-shedding check over 3 s (Figure 8) |
| R4 | `posthoc_revision_20261025/solver_check.py` | tighter-tolerance repeat of the quadratic case |
| R5 | `posthoc_revision_20261025/make_figures.py` | Figures 1–8 |

## How the check works

- **Manifests first.** The runner checks `SHA256SUMS`, `SHA256SUMS_v1.1` and the manifests of the sealed run folders before anything else. It stops if any listed file differs.
- **Working copy.** The scripts run unchanged on a copy of the archive, so the distributed outputs are never overwritten.
- **Comparison.** Every regenerated CSV/JSON file is compared with the distributed one using |a−b| ≤ 1e−7 + rtol·|a|, with rtol 1e−6, or 1e−4 for time traces. Solver bookkeeping fields (nfev, njev, nlu, step counts) and interpreter or version strings are ignored.
- **Figures.** Figures are checked for presence only. Their pixels depend on the rendering library, so compare them with the manuscript by eye.

**Tested on 25 October 2026 (Linux, Python 3.12.3).**
- With the pinned versions: ALL REPRODUCED. The largest relative difference was 2e−3, on near-zero values of a local ODE trace, with an absolute difference of 2e−9.
- With numpy 2.3.5, scipy 1.16.3, sympy 1.13.3 and matplotlib 3.10.7: ALL REPRODUCED.
- Total run time: about 2.5 minutes.

**Limitations.**
- The 79-member preregistered HDL2b evaluation is not re-executed; step S0 checks only its hashes.
- The GitHub mirror does not contain the preregistration files, so S0 is reported there as *not applicable*.

