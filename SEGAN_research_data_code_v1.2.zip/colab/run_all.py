#!/usr/bin/env python3
"""Run and check every reproduction script of Supplementary Material S1 in a fresh environment.

Works on Google Colab and on any Linux/macOS/Windows machine. Uses only the Python standard library, so it can be
started from the notebook kernel; the scientific scripts themselves are run with the interpreter given by --python
(normally a virtual environment with requirements_pinned.txt).

What it does, in order:
  1. verifies the SHA-256 manifests shipped with the archive (nothing is run if a sealed file has changed);
  2. copies the archive to a separate working folder, so the distributed outputs are never overwritten;
  3. runs the reproduction scripts unchanged, in the documented order, with `python -I -B`;
  4. compares every regenerated CSV/JSON output with the distributed copy (numerical tolerance, solver
     bookkeeping fields ignored) and checks that every figure file was produced;
  5. writes REPORT.md, report.json, the logs and the regenerated outputs to --out.

The historical scripts and the sealed records are not modified.

Usage:  python colab/run_all.py --root <extracted archive> [--python <interpreter>] [--out <folder>]
"""
import argparse, csv, hashlib, json, math, os, platform, re, shutil, subprocess, sys, time
from pathlib import Path

# Solver bookkeeping and environment strings that legitimately differ between machines.
IGNORED_KEYS = {'nfev', 'njev', 'nlu', 'ode_steps', 'python', 'numpy', 'scipy', 'message', 'solver_message'}
RTOL, RTOL_TRACES, ATOL = 1e-6, 1e-4, 1e-7

# (step id, script, arguments, outputs to compare, figures to check, purpose)
STEPS = [
    ('S0', 'research_intelligence/cdl1/code/hdl2b_run.py', ['--check-only'], [], [],
     'hash check of the preregistration and the 13 pinned inputs of the sealed HDL2b run (no computation)'),
    ('P1', 'posthoc/reproduce_tables.py', [],
     ['posthoc/tables_11_12_reproduction.json', 'posthoc/table11_groups.csv', 'posthoc/table12_metrics.csv'], [],
     'Tables 7-8 of the manuscript from the sealed member records'),
    ('P2', 'posthoc/reproduce_posthoc.py', [],
     ['posthoc/posthoc_reproduction.json', 'posthoc/posthoc_member_predictions.csv', 'posthoc/time_domain_traces.csv'],
     ['posthoc/fig7_reproduced.png'], 'post-hoc accuracy statistics and the local nonlinear check (Figure 7)'),
    ('P3', 'posthoc/reproduce_figure3.py', [], ['posthoc/figure3_model_curve.csv'], ['posthoc/fig3_reproduced.png'],
     'model curve of v1.0 Figure 3 (Figure 5 of the revised manuscript)'),
    ('P4', 'posthoc/abrupt_validation.py', [],
     ['posthoc/abrupt_validation.json', 'posthoc/abrupt_shedding_traces.csv'], ['posthoc/fig8_abrupt_shedding.png'],
     'v1.0 abrupt-shedding check, 0.5 s window'),
    ('R1', 'posthoc_revision_20261025/stats_audit.py', ['.', 'posthoc_revision_20261025/stats_audit.json'],
     ['posthoc_revision_20261025/stats_audit.json'], [],
     'within-group statistics, sign-rule discrimination, bisection-resolution audit'),
    ('R2', 'posthoc_revision_20261025/math_check.py', ['posthoc_revision_20261025/math_check.json'],
     ['posthoc_revision_20261025/math_check.json'], [], 'symbolic and numerical checks of Lemmas 1-5 and Eqs. (18)-(19)'),
    ('R3', 'posthoc_revision_20261025/abrupt_shedding_window.py', ['3.0'],
     ['posthoc_revision_20261025/abrupt_shedding_window.json',
      'posthoc_revision_20261025/abrupt_shedding_window_traces.csv'], [],
     'abrupt-shedding check with a 3 s window (Figure 8)'),
    ('R4', 'posthoc_revision_20261025/solver_check.py', [], ['posthoc_revision_20261025/solver_check.json'], [],
     'quadratic case of the abrupt check with tighter solver tolerances'),
    ('R5', 'posthoc_revision_20261025/make_figures.py', [], [],
     ['posthoc_revision_20261025/figures/Figure_%d.%s' % (n, e) for n in range(1, 9) for e in ('png', 'tif')],
     'Figures 1-8 of the revised manuscript'),
]
S0_REQUIRES = 'research_intelligence/cdl1/CDL2_HDL2b_On_Kayit_v1.0_SABIT.md'


def sha256(p):
    h = hashlib.sha256()
    with open(p, 'rb') as fh:
        for b in iter(lambda: fh.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


def manifests(root):
    found = [root / n for n in ('SHA256SUMS', 'SHA256SUMS_v1.1') if (root / n).is_file()]
    found += sorted(p for p in (root / 'research_intelligence').rglob('SHA256SUMS') if p.is_file())
    return found


def verify(root):
    results = []
    for m in manifests(root):
        base, n, bad = m.parent, 0, []
        for line in m.read_text(encoding='utf-8').splitlines():
            if not line.strip():
                continue
            digest, name = line.split(None, 1)
            name = name.strip().lstrip('*')
            name = name[2:] if name.startswith('./') else name
            p = base / name
            n += 1
            if not p.is_file():
                bad.append((name, 'missing'))
            elif sha256(p) != digest.lower():
                bad.append((name, 'hash mismatch'))
        results.append({'manifest': str(m.relative_to(root)), 'files': n, 'failures': bad})
    return results


def num(x):
    if isinstance(x, bool):
        return float(x)
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def flatten(o, pre=''):
    if isinstance(o, dict):
        for k, v in o.items():
            yield from flatten(v, pre + '/' + str(k))
    elif isinstance(o, list):
        for i, v in enumerate(o):
            yield from flatten(v, pre + '[%d]' % i)
    else:
        yield pre, o


def table(path):
    if path.suffix == '.json':
        return dict(flatten(json.loads(path.read_text(encoding='utf-8'))))
    with open(path, newline='', encoding='utf-8-sig') as fh:
        rows = list(csv.reader(fh))
    head = rows[0] if rows else []
    d = {'r%d/c%d/%s' % (i, j, head[j] if j < len(head) else ''): v
         for i, r in enumerate(rows[1:], 1) for j, v in enumerate(r)}
    d['header'] = '|'.join(head)
    return d


def compare(expected, got):
    rtol = RTOL_TRACES if 'traces' in expected.name else RTOL
    a, b = table(expected), table(got)
    if set(a) != set(b):
        return {'status': 'FAIL', 'detail': 'different structure (%d keys differ)' % len(set(a) ^ set(b))}
    worst_abs = worst_rel = 0.0
    worst = None
    bad = 0
    for k, x in a.items():
        if re.sub(r'(\[\d+\])+$', '', k.split('/')[-1]) in IGNORED_KEYS:
            continue
        y = b[k]
        fx, fy = num(x), num(y)
        if fx is None or fy is None:
            if x != y:
                bad += 1
                worst = worst or (k, x, y)
            continue
        if math.isnan(fx) and math.isnan(fy):
            continue
        d = abs(fx - fy)
        rel = d / max(abs(fx), abs(fy), 1e-300)
        worst_abs = max(worst_abs, d)
        if d > 0:
            worst_rel = max(worst_rel, rel)
        if d > ATOL + rtol * abs(fx):
            bad += 1
            worst = worst or (k, x, y)
    return {'status': 'PASS' if bad == 0 else 'FAIL', 'values_outside_tolerance': bad,
            'max_abs_diff': worst_abs, 'max_rel_diff': worst_rel, 'rtol': rtol, 'atol': ATOL,
            'first_difference': worst}


def env_info(py):
    code = ('import sys,platform,json;d={"python":sys.version.split()[0],"platform":platform.platform()}\n'
            'for m in ("numpy","scipy","sympy","matplotlib","PIL"):\n'
            '    try:\n        d[m]=__import__(m).__version__\n    except Exception as e:\n        d[m]="not installed"\n'
            'print(json.dumps(d))')
    r = subprocess.run([py, '-c', code], capture_output=True, text=True)
    try:
        return json.loads(r.stdout)
    except ValueError:
        return {'error': r.stderr[-500:]}


def main():
    ap = argparse.ArgumentParser(description=__doc__.split('\n')[0])
    ap.add_argument('--root', required=True, help='folder of the extracted archive (contains requirements_pinned.txt)')
    ap.add_argument('--python', default=sys.executable, help='interpreter used to run the scientific scripts')
    ap.add_argument('--out', default='segan_s1_results', help='output folder for the report, logs and regenerated files')
    ap.add_argument('--timeout', type=int, default=1800, help='per-step timeout in seconds')
    a = ap.parse_args()
    root, out = Path(a.root).resolve(), Path(a.out).resolve()
    # absolute path without resolving symlinks (a venv interpreter is a symlink to the base Python)
    a.python = os.path.abspath(a.python) if os.sep in a.python or (os.altsep and os.altsep in a.python) \
        else (shutil.which(a.python) or a.python)
    work = out / 'work_copy'
    if out.exists():
        shutil.rmtree(out)
    (out / 'logs').mkdir(parents=True)
    report = {'started': time.strftime('%Y-%m-%d %H:%M:%S %Z'), 'root': str(root),
              'runner_python': sys.version.split()[0], 'environment': env_info(a.python),
              'manifests': [], 'steps': []}
    env = report['environment']
    print('Environment:', env)

    print('\n[1/4] Verifying the SHA-256 manifests of the distributed archive ...')
    report['manifests'] = verify(root)
    sealed_ok = all(not m['failures'] for m in report['manifests']) and report['manifests']
    for m in report['manifests']:
        print('   %-60s %4d files  %s' % (m['manifest'], m['files'], 'OK' if not m['failures'] else
                                          'FAILED: %s' % m['failures'][:3]))
    if not sealed_ok:
        print('Archive integrity check failed or no manifest found; nothing was run.')
        report['verdict'] = 'NOT RUN: archive integrity check failed'
        write_report(out, report)
        return 2

    print('\n[2/4] Copying the archive to %s (the distributed files are never overwritten) ...' % work)
    shutil.copytree(root, work)

    # headless plotting; notebook kernels (Jupyter, Colab) export MPLBACKEND=module://matplotlib_inline..., which
    # `python -I` does not clear and which a script outside the kernel cannot load
    child_env = dict(os.environ, MPLBACKEND='Agg')
    print('\n[3/4] Running the reproduction scripts ...')
    for sid, script, args, outputs, figures, purpose in STEPS:
        step = {'id': sid, 'script': script, 'args': args, 'purpose': purpose}
        report['steps'].append(step)
        if not (work / script).is_file():
            step.update(status='NOT IN ARCHIVE')
            print('   %s %-52s not in this archive, skipped' % (sid, script))
            continue
        if sid == 'S0' and not (work / S0_REQUIRES).is_file():
            step.update(status='NOT APPLICABLE',
                        detail='the preregistration files are not part of this archive (GitHub mirror); '
                               'run this step on Supplementary Material S1')
            print('   %s %-52s preregistration files not in this archive, skipped' % (sid, script))
            continue
        # remove the distributed copies of this step's outputs from the working copy, so that only files actually
        # produced by the script can pass the comparison
        for o in outputs + figures:
            if (work / o).is_file():
                (work / o).unlink()
        t0 = time.time()
        try:
            r = subprocess.run([a.python, '-I', '-B', script] + args, cwd=work, capture_output=True, text=True,
                               timeout=a.timeout, env=child_env)
            rc, so, se = r.returncode, r.stdout, r.stderr
        except subprocess.TimeoutExpired as e:
            rc, so, se = 'timeout', e.stdout or '', e.stderr or ''
        step['seconds'] = round(time.time() - t0, 1)
        step['returncode'] = rc
        (out / 'logs' / ('%s_%s.log' % (sid, Path(script).stem))).write_text(
            '$ python -I -B %s %s\n\n--- stdout ---\n%s\n--- stderr ---\n%s\n' % (script, ' '.join(args), so, se),
            encoding='utf-8')
        comps = {}
        for o in outputs:
            src, dst = root / o, work / o
            if not dst.is_file():
                comps[o] = {'status': 'FAIL', 'detail': 'output not produced'}
            elif not src.is_file():
                comps[o] = {'status': 'NEW', 'detail': 'no distributed copy to compare with'}
            else:
                comps[o] = compare(src, dst)
        for f in figures:
            p = work / f
            comps[f] = {'status': 'PASS' if p.is_file() and p.stat().st_size > 0 else 'FAIL',
                        'detail': 'figure file produced (%d bytes); figures are checked visually, not byte by byte'
                                  % (p.stat().st_size if p.is_file() else 0)}
        step['outputs'] = comps
        ok = rc == 0 and all(c['status'] in ('PASS', 'NEW') for c in comps.values())
        if sid == 'S0':
            ok = ok and 'PIN: 13/13 OK' in so
        step['status'] = 'PASS' if ok else 'FAIL'
        print('   %s %-52s %-4s %6.1f s' % (sid, script, step['status'], step['seconds']))
        for o, c in comps.items():
            if c['status'] != 'PASS' or 'max_rel_diff' in c:
                print('        %-58s %s %s' % (o, c['status'],
                      'max rel diff %.2e' % c['max_rel_diff'] if 'max_rel_diff' in c else c.get('detail', '')))

    print('\n[4/4] Collecting regenerated outputs and writing the report ...')
    reg = out / 'regenerated'
    for st in report['steps']:
        for o in st.get('outputs', {}):
            if (work / o).is_file():
                (reg / o).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(work / o, reg / o)
    shutil.rmtree(work)
    statuses = [s['status'] for s in report['steps']]
    report['verdict'] = ('ALL REPRODUCED' if all(s in ('PASS', 'NOT APPLICABLE', 'NOT IN ARCHIVE') for s in statuses)
                         else 'DIFFERENCES FOUND - see REPORT.md')
    report['finished'] = time.strftime('%Y-%m-%d %H:%M:%S %Z')
    write_report(out, report)
    print('\nVerdict:', report['verdict'])
    print('Report: %s' % (out / 'REPORT.md'))
    return 0 if report['verdict'] == 'ALL REPRODUCED' else 1


def write_report(out, rep):
    (out / 'report.json').write_text(json.dumps(rep, indent=1, default=str), encoding='utf-8')
    L = ['# SEGAN S1 reproduction report', '',
         '- Started: %s; finished: %s' % (rep['started'], rep.get('finished', '-')),
         '- Archive: `%s`' % rep['root'],
         '- Environment: ' + ', '.join('%s %s' % kv for kv in rep['environment'].items()),
         '- **Verdict: %s**' % rep['verdict'], '',
         'Pinned versions (requirements_pinned.txt): Python 3.12, numpy 2.5.4, scipy 1.18.1, sympy 1.14.0, '
         'matplotlib 3.11.2. Other versions may give small numerical differences; the tolerances below absorb '
         'round-off and solver differences between machines, not changes of result.', '',
         '## Archive integrity', '', '| Manifest | Files | Result |', '|---|---|---|']
    for m in rep['manifests']:
        L.append('| %s | %d | %s |' % (m['manifest'], m['files'], 'OK' if not m['failures'] else
                                      'FAILED (%d): %s' % (len(m['failures']), m['failures'][:3])))
    L += ['', '## Steps', '', '| Step | Script | Purpose | Result | Time (s) |', '|---|---|---|---|---|']
    for s in rep['steps']:
        L.append('| %s | `%s %s` | %s | %s | %s |' % (s['id'], s['script'], ' '.join(s['args']), s['purpose'],
                                                     s['status'], s.get('seconds', '-')))
    L += ['', '## Output comparison with the distributed files', '',
          'Numbers are compared with |a-b| <= %.0e + rtol*|a| (rtol %.0e; %.0e for time traces). '
          'Ignored fields: %s.' % (ATOL, RTOL, RTOL_TRACES, ', '.join(sorted(IGNORED_KEYS))), '',
          '| File | Result | Max abs diff | Max rel diff | Note |', '|---|---|---|---|---|']
    for s in rep['steps']:
        for o, c in s.get('outputs', {}).items():
            L.append('| `%s` | %s | %s | %s | %s |' % (
                o, c['status'], '%.2e' % c['max_abs_diff'] if 'max_abs_diff' in c else '-',
                '%.2e' % c['max_rel_diff'] if 'max_rel_diff' in c else '-',
                c.get('detail', '') or (('first difference: %s' % (c['first_difference'],))
                                        if c.get('first_difference') and c['status'] != 'PASS' else '')))
    L += ['', 'Regenerated files are in `regenerated/`, the full output of every script in `logs/`.', '']
    (out / 'REPORT.md').write_text('\n'.join(L), encoding='utf-8')


if __name__ == '__main__':
    sys.exit(main())
