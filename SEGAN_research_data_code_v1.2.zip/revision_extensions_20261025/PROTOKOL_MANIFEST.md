# Protocol manifest (append-only)

Every protocol of the revision extensions is hashed and timestamped here before its outcomes are computed.
Entries are never edited; amendments are new entries.

| # | Time (local, +03:00) | File | SHA-256 | State at hashing |
|---|---|---|---|---|
| 1 | 2026-10-25T13:52:32 | `bagimsiz/PROTOCOL_INDEPENDENT_VALIDATION_v1.0.md` | c1ca75b1fba0e384ab4b8c8ae03cc5d40bfc11f6cdeb3dd74c5ed7730e4cd45b | only the smoke-test member computed (§6 of the protocol) |
| 2 | 2026-10-25T13:59:00 | `psv/PROSPECTIVE_VALIDATION_PROTOCOL.md` | 865d84e5ef6b928b0e8e962056596fb833fcf3f7fe2a0ed2ca72d13a37585f28 | no PSV point computed; only the off-family three-bus code test (§9) |
| 3 | 2026-10-25T13:59:49 | `bagimsiz/ind_engine.py` (frozen engine) | c45ec8f40d24911dfe51daee76056ae4aaefd0027b8b976aa1ef57e98315ae6b | frozen for PSV; the validation run (entry 1) uses this file |
| 4 | 2026-10-25T15:09:25 | `psv/PSV_AMENDMENT_A1.md` | 7bd97a737f430ec6c1214fa7006ee2b913c86423342832947c5fa5a8083ebe9a | after the validation result (78/79) and audit PSV-D1 (REVISE); no PSV point computed |
