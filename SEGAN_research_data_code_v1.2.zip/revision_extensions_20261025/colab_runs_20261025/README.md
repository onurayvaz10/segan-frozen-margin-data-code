# Google Colab koşuları, 25 Ekim 2026

Notebook GitHub'dan açılarak (`colab.research.google.com/github/onurayvaz10/segan-frozen-margin-data-code/blob/main/SEGAN_S1_Colab.ipynb`) Google Colab'da, standart CPU çalışma zamanında ve sabitlenmiş ortamla (Python 3.12.3, numpy 2.5.4, scipy 1.18.1, sympy 1.14.0, matplotlib 3.11.2) iki kez koşuldu.

| Koşu | Arşiv | Manifestler | Adımlar | Sonuç |
|---|---|---|---|---|
| `REPORT_S1.md` | `Supplementary_S1_data_code_v1.1.zip` | 4/4 OK (104 + 139 + 7 + 8 dosya) | 10/10 çalıştı; 9 PASS, R3 FAIL | DIFFERENCES FOUND (1 değer) |
| `REPORT_mirror.md` | GitHub `v1.1` etiketindeki `SEGAN_research_data_code_v1.1.zip` | 1/1 OK (100 dosya) | S0 uygulanamaz; 9/9 çalıştı; 8 PASS, R3 FAIL | DIFFERENCES FOUND (1 değer) |

**Tek fark.** `posthoc_revision_20261025/abrupt_shedding_window.json` içinde `cases[2].envelope_250ms[3].max_abs_bus102_dev_pu`: dağıtılan 1.1559694171, Colab 1.1559716103 (mutlak fark 2.2e−6 pu, göreli 1.9e−6; tolerans 1e−7 + 1e−6·|a|). Bu değer, kayıtlı referans durumunun 0.763 s'de ıraksadığı 0.75–1.00 s penceresindeki tepe bara-102 sapmasıdır. Çözücü dururken ölçüldüğü için kayan nokta farklarına en duyarlı değer budur. Aynı değer iki koşuda birebir aynı çıktı (Colab'da belirleyici).

**Değişmeyenler.** Dört durumun başarı bayrakları, ıraksama zamanları (kuadratik 0.825 s, referans 0.763 s, teğet 0.403 s), dondurulmuş payın 3 s'deki yakınsaması, aynı koşunun iz dosyası (`abrupt_shedding_window_traces.csv`, PASS) ve sıkı toleranslı tekrar (R4, PASS). Makaledeki hiçbir sayı ya da yargı bu farka bağlı değil.

**Şekiller.** Colab'da üretilen Şekil 1–7 dağıtılan PNG'lerle piksel düzeyinde aynı. Şekil 8'de fark yalnız (c) panelinde: dondurulmuş eğrinin 2.6 s sonrasındaki 1e−13–1e−14 yuvarlama tabanı farklı, otomatik y ekseni de bu yüzden paneli birkaç piksel kaydırıyor. (a) ve (b) aynı.

**Tolerans değiştirilmedi.** Eşik, sonuç görüldükten sonra gevşetilmedi. S1, hash listeleri ve yayımlanmış v1.1 sürümü olduğu gibi duruyor.

**Notlar.**
- S1 zip'i Colab'a yüklenmeden önce, tarayıcı yükleme sınırı (10 MB) nedeniyle aynı 140 dosya LZMA sıkıştırmayla yeniden paketlendi (10.53 → 9.80 MB). Dosya içerikleri birebir aynı; Colab'daki manifest kontrolü bunu ayrıca doğruladı. Teslim edilen S1 zip'i değişmedi.
- Raporlardaki "matplotlib not installed" ifadesi, yürütücünün sürüm okuyan yardımcı fonksiyonundan kaynaklanan bir raporlama kusuru. matplotlib 3.11.2 kuruldu ve şekiller (Şekil 1–8, Şekil 7 ve 8'in v1.0 sürümleri) sorunsuz üretildi.
