# SEGAN S1 reproduction report

- Started: 2026-10-25 09:26:55 UTC; finished: 2026-10-25 09:31:02 UTC
- Archive: `/content/S1`
- Environment: python 3.12.3, platform Linux-6.6.122+-x86_64-with-glibc2.39, numpy 2.5.4, scipy 1.18.1, sympy 1.14.0, matplotlib not installed, PIL 13.0.0
- **Verdict: DIFFERENCES FOUND - see REPORT.md**

Pinned versions (requirements_pinned.txt): Python 3.12, numpy 2.5.4, scipy 1.18.1, sympy 1.14.0, matplotlib 3.11.2. Other versions may give small numerical differences; the tolerances below absorb round-off and solver differences between machines, not changes of result.

## Archive integrity

| Manifest | Files | Result |
|---|---|---|
| SHA256SUMS | 100 | OK |
| research_intelligence/cdl1/out/HDL2b_20261021_a/SHA256SUMS | 8 | OK |

## Steps

| Step | Script | Purpose | Result | Time (s) |
|---|---|---|---|---|
| S0 | `research_intelligence/cdl1/code/hdl2b_run.py --check-only` | hash check of the preregistration and the 13 pinned inputs of the sealed HDL2b run (no computation) | NOT APPLICABLE | - |
| P1 | `posthoc/reproduce_tables.py ` | Tables 7-8 of the manuscript from the sealed member records | PASS | 0.1 |
| P2 | `posthoc/reproduce_posthoc.py ` | post-hoc accuracy statistics and the local nonlinear check (Figure 7) | PASS | 42.6 |
| P3 | `posthoc/reproduce_figure3.py ` | model curve of v1.0 Figure 3 (Figure 5 of the revised manuscript) | PASS | 14.3 |
| P4 | `posthoc/abrupt_validation.py ` | v1.0 abrupt-shedding check, 0.5 s window | PASS | 43.4 |
| R1 | `posthoc_revision_20261025/stats_audit.py . posthoc_revision_20261025/stats_audit.json` | within-group statistics, sign-rule discrimination, bisection-resolution audit | PASS | 16.1 |
| R2 | `posthoc_revision_20261025/math_check.py posthoc_revision_20261025/math_check.json` | symbolic and numerical checks of Lemmas 1-5 and Eqs. (18)-(19) | PASS | 7.1 |
| R3 | `posthoc_revision_20261025/abrupt_shedding_window.py 3.0` | abrupt-shedding check with a 3 s window (Figure 8) | FAIL | 50.4 |
| R4 | `posthoc_revision_20261025/solver_check.py ` | quadratic case of the abrupt check with tighter solver tolerances | PASS | 47.0 |
| R5 | `posthoc_revision_20261025/make_figures.py ` | Figures 1-8 of the revised manuscript | PASS | 16.9 |

## Output comparison with the distributed files

Numbers are compared with |a-b| <= 1e-07 + rtol*|a| (rtol 1e-06; 1e-04 for time traces). Ignored fields: message, nfev, njev, nlu, numpy, ode_steps, python, scipy, solver_message.

| File | Result | Max abs diff | Max rel diff | Note |
|---|---|---|---|---|
| `posthoc/tables_11_12_reproduction.json` | PASS | 0.00e+00 | 0.00e+00 |  |
| `posthoc/table11_groups.csv` | PASS | 0.00e+00 | 0.00e+00 |  |
| `posthoc/table12_metrics.csv` | PASS | 0.00e+00 | 0.00e+00 |  |
| `posthoc/posthoc_reproduction.json` | PASS | 1.36e-11 | 1.09e-05 |  |
| `posthoc/posthoc_member_predictions.csv` | PASS | 0.00e+00 | 0.00e+00 |  |
| `posthoc/time_domain_traces.csv` | PASS | 2.51e-09 | 4.86e-03 |  |
| `posthoc/fig7_reproduced.png` | PASS | - | - | figure file produced (721406 bytes); figures are checked visually, not byte by byte |
| `posthoc/figure3_model_curve.csv` | PASS | 9.71e-15 | 1.21e-12 |  |
| `posthoc/fig3_reproduced.png` | PASS | - | - | figure file produced (280749 bytes); figures are checked visually, not byte by byte |
| `posthoc/abrupt_validation.json` | PASS | 8.19e-07 | 1.18e-07 |  |
| `posthoc/abrupt_shedding_traces.csv` | PASS | 3.90e-07 | 6.40e-05 |  |
| `posthoc/fig8_abrupt_shedding.png` | PASS | - | - | figure file produced (771675 bytes); figures are checked visually, not byte by byte |
| `posthoc_revision_20261025/stats_audit.json` | PASS | 8.88e-16 | 1.69e-15 |  |
| `posthoc_revision_20261025/math_check.json` | PASS | 5.55e-16 | 1.11e+00 |  |
| `posthoc_revision_20261025/abrupt_shedding_window.json` | FAIL | 2.19e-06 | 7.66e-01 | first difference: ('/cases[2]/envelope_250ms[3]/max_abs_bus102_dev_pu', 1.1559694171079664, 1.1559716103102053) |
| `posthoc_revision_20261025/abrupt_shedding_window_traces.csv` | PASS | 2.19e-06 | 2.00e+00 |  |
| `posthoc_revision_20261025/solver_check.json` | PASS | 1.78e-10 | 2.19e-11 |  |
| `posthoc_revision_20261025/figures/Figure_1.png` | PASS | - | - | figure file produced (290357 bytes); figures are checked visually, not byte by byte |
| `posthoc_revision_20261025/figures/Figure_1.tif` | PASS | - | - | figure file produced (987394 bytes); figures are checked visually, not byte by byte |
| `posthoc_revision_20261025/figures/Figure_2.png` | PASS | - | - | figure file produced (105158 bytes); figures are checked visually, not byte by byte |
| `posthoc_revision_20261025/figures/Figure_2.tif` | PASS | - | - | figure file produced (198856 bytes); figures are checked visually, not byte by byte |
| `posthoc_revision_20261025/figures/Figure_3.png` | PASS | - | - | figure file produced (178512 bytes); figures are checked visually, not byte by byte |
| `posthoc_revision_20261025/figures/Figure_3.tif` | PASS | - | - | figure file produced (749188 bytes); figures are checked visually, not byte by byte |
| `posthoc_revision_20261025/figures/Figure_4.png` | PASS | - | - | figure file produced (155455 bytes); figures are checked visually, not byte by byte |
| `posthoc_revision_20261025/figures/Figure_4.tif` | PASS | - | - | figure file produced (380740 bytes); figures are checked visually, not byte by byte |
| `posthoc_revision_20261025/figures/Figure_5.png` | PASS | - | - | figure file produced (285942 bytes); figures are checked visually, not byte by byte |
| `posthoc_revision_20261025/figures/Figure_5.tif` | PASS | - | - | figure file produced (749164 bytes); figures are checked visually, not byte by byte |
| `posthoc_revision_20261025/figures/Figure_6.png` | PASS | - | - | figure file produced (201116 bytes); figures are checked visually, not byte by byte |
| `posthoc_revision_20261025/figures/Figure_6.tif` | PASS | - | - | figure file produced (415544 bytes); figures are checked visually, not byte by byte |
| `posthoc_revision_20261025/figures/Figure_7.png` | PASS | - | - | figure file produced (393886 bytes); figures are checked visually, not byte by byte |
| `posthoc_revision_20261025/figures/Figure_7.tif` | PASS | - | - | figure file produced (838834 bytes); figures are checked visually, not byte by byte |
| `posthoc_revision_20261025/figures/Figure_8.png` | PASS | - | - | figure file produced (238628 bytes); figures are checked visually, not byte by byte |
| `posthoc_revision_20261025/figures/Figure_8.tif` | PASS | - | - | figure file produced (494830 bytes); figures are checked visually, not byte by byte |

Regenerated files are in `regenerated/`, the full output of every script in `logs/`.
