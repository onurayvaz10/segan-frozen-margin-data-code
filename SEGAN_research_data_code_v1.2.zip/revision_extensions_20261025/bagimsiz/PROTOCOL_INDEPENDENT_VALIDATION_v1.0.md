# Protocol — separately coded validation, derivative validation and computational cost (v1.0)

Written 2026-10-25, before the full comparison was run. Only the single smoke-test member S3_P0.65_G0.20 had been
computed with the new code when this protocol was written (it agreed with the sealed record; see §6). This protocol
covers a **verification extension**: it recomputes quantities whose sealed values are already known. It is not a new
hypothesis test and it does not change any sealed result or verdict.

## 1. Question

Does a separately coded numerical implementation (`ind_engine.py`; numpy only, no import of the original modules,
complex-step Jacobian, augmented-Newton dispatch, explicit Schur complement, own crossing search and own
continuation) reproduce the sealed member-level results of the internally protocol-fixed run HDL2b_20261021_a?

## 2. Inputs (read-only)

- `cdl1/out/HDL2b_20261021_a/sonuc.json` (sealed; SHA-256 1680164109dd80fa8c7ffb7278c8ea42425173c24b6d54ca50b3e1fae140efd5):
  for each member only (P_set, G_R) are used as inputs; every other field is used only for comparison.
- `posthoc/posthoc_member_predictions.csv` (S1 v1.1): recorded quadratic estimate, for comparison only.
- The original model modules are imported only by the derivative-validation harness (§4 (i)), to compare Jacobians.

## 3. Quantities and acceptance criteria (per member, fixed before the run)

| Quantity | Comparison | PASS if |
|---|---|---|
| set-points ρ (5) | max abs difference | ≤ 1e-9 |
| bus angle θ_b | abs difference | ≤ 1e-9 rad |
| spectral abscissa α(x₀) | abs difference | ≤ 1e-6 s⁻¹ |
| frozen margin ΔG*_f and ω* | relative difference | ≤ 1e-8 |
| κ̂ (full-information) | relative difference | ≤ 1e-6 |
| κ_fd (same step h = 1e-3·ΔG*_f) | relative difference | ≤ 1e-6 |
| reference ΔG*_t, original definition (α ≥ −α_tab, α_tab = 1e-10·‖A‖₂) | abs difference | ≤ 1e-4·ΔG*_f (the sealed bisection width) + 1e-8 |
| quadratic estimate ΔG*_2nd | relative difference | ≤ 1e-6 |

Reported in addition, without a pass criterion: the reference at the exact eigenvalue crossing (α = 0), the
difference between the two reference definitions, and run times.

A member counts as reproduced when every applicable criterion passes. The overall result is reported as the
count of reproduced members out of the members for which the sealed record holds the quantity. No criterion is
changed after the run; failures are reported as they are.

## 4. Derivative validation (six members, one per P_set: the member with the largest G_R in 𝓔)

(i) Jacobian: complex step (h = 1e-30) vs central difference (h = 1e-7) vs the original symbolic Jacobian.
(ii) Path sensitivity ξ = dx/dΔG: linear solve vs central difference of re-solved equilibria (h = 1e-4·ΔG*_f) vs
     complex step through a complex Newton solve of the equilibrium with G_R − i·1e-20.
(iii) Eigenvalue sensitivity η: ⟨dY/dΔG⟩ vs central difference of λ(ω*) at x(±h).
(iv) κ: κ̂ vs κ_fd at two steps (1e-3 and 1e-4·ΔG*_f) and their Richardson extrapolation.
(v) crossing slope c: central differences in ω at two relative steps (1e-6, 1e-7).
Reported as relative errors; no pass criterion (descriptive validation).

## 5. Computational cost (same six members, same machine, same code)

Estimators: (A) reference continuation and bisection, (B) frozen margin only, (C) frozen + first order (κ̂ and
ΔG*_1st), (D) second order (ΔG*_2nd, two extra equilibria and two loci), (E) single-step relinearization at ΔG*_f.
Counted: equilibrium (Newton) solves, Jacobian evaluations, eigenvalue solves, frequency-scan points.
Timed: wall-clock and process CPU time, median of 5 repetitions, BLAS threads 1.

## 6. Smoke test before this protocol

S3_P0.65_G0.20: ρ identical to 12 digits, θ_b to 1e-17, α to 1e-12, ΔG*_f rel. 1e-13, ω* rel. 6e-15,
κ̂ 0.2460459174 vs 0.2460459166 (rel. 3e-9).
