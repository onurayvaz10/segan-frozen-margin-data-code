"""Run PROTOCOL_INDEPENDENT_VALIDATION_v1.0 §3 (all members): separately coded engine vs sealed record.

usage: python -I validate_all.py <sonuc.json> <posthoc_member_predictions.csv> <out_dir>
"""
import csv, json, math, os, sys, time
from pathlib import Path

os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('MKL_NUM_THREADS', '1')
import numpy as np  # noqa: E402

sys.path.insert(0, str(Path(__file__).parent))
import ind_engine as E  # noqa: E402

rec_path, pred_path, out = sys.argv[1], sys.argv[2], Path(sys.argv[3])
out.mkdir(parents=True, exist_ok=True)
members = json.load(open(rec_path, encoding='utf-8'))['members']
pred = {r['id']: r for r in csv.DictReader(open(pred_path, encoding='utf-8-sig'))}
lay = E.Layout(E.two_bus_system())


def rel(a, b):
    return abs(a - b) / max(abs(b), 1e-300)


def second_order(rho0, rp, rm, h, k_fd):
    a = 0.5 * (rp - 2 * rho0 + rm) / h ** 2
    b, c = k_fd - 1.0, rho0
    if abs(a) < 1e-300:
        return -c / b, a
    disc = b * b - 4 * a * c
    if disc < 0:
        return float('nan'), a
    roots = [(-b - math.sqrt(disc)) / (2 * a), (-b + math.sqrt(disc)) / (2 * a)]
    pos = [r for r in roots if r > 0]
    return (min(pos) if pos else float('nan')), a


rows = []
t_all = time.perf_counter()
for m in members:
    r = dict(id=m['id'], P_set=m['P_akt'], G_R=m['G_R'], in_E=m['in_E'])
    G = np.array([0.0, m['G_R']])
    d = E.dispatch(lay, [m['P_akt']], G)
    r['dispatch_ok'] = d['ok']
    x0, refs = d['x'], d['refs']
    r['refs_maxdiff'] = float(np.max(np.abs(refs - np.array(m['rho']))))
    th = float(np.arctan2(x0[lay.ix['V1:I']], x0[lay.ix['V1:R']]))
    r['theta_b_diff'] = abs(th - m['theta_b'])
    Jm = E.jac(lay, x0, refs, G)
    a = E.spectral_abscissa(lay, Jm)[0]
    r['alpha'], r['alpha_rec'] = a, m.get('alpha')
    r['alpha_diff'] = abs(a - m['alpha']) if m.get('alpha') is not None else None
    if m.get('dGf') is None or m.get('omega_star') is None:
        r['note'] = 'no frozen margin in the sealed record (gate failed before K4)'
        rows.append(r)
        continue
    fm = E.frozen_margin(lay, Jm, th, m['G_R'])
    r['dGf'], r['dGf_rec'] = fm['rho'], m['dGf']
    r['dGf_rel'] = rel(fm['rho'], m['dGf'])
    r['omega'], r['omega_rec'] = fm['omega'], m['omega_star']
    r['omega_rel'] = rel(fm['omega'], m['omega_star'])
    kr = m.get('kappa') or {}
    if kr.get('k_tam') is not None:
        k = E.kappa_hat(lay, x0, refs, G, th, fm)
        r['kappa'], r['kappa_rec'] = k['kappa'], kr['k_tam']
        r['kappa_rel'] = rel(k['kappa'], kr['k_tam'])
    hk = m.get('HAKT') or {}
    if hk.get('k_fd') is not None:
        h = 1e-3 * fm['rho']
        rr = {}
        for sg in (1, -1):
            Gk = G.copy()
            Gk[1] -= sg * h
            xs, ok, _, _ = E.newton_fixed_refs(lay, x0, refs, Gk)
            rr[sg] = E.rho_at(lay, xs, refs, G, th, fm)['rho']
        k_fd = (rr[1] - rr[-1]) / (2 * h)
        r['k_fd'], r['k_fd_rec'] = k_fd, hk['k_fd']
        r['k_fd_rel'] = rel(k_fd, hk['k_fd'])
        q2, a2 = second_order(fm['rho'], rr[1], rr[-1], h, k_fd)
        r['dG2nd'] = q2
        p = pred.get(m['id'])
        if p and p.get('dG_second_order'):
            r['dG2nd_rec'] = float(p['dG_second_order'])
            r['dG2nd_rel'] = rel(q2, float(p['dG_second_order']))
    ref = m.get('ref') or {}
    if ref.get('dGt') is not None:
        dmax = min(m['G_R'], 2.0 * fm['rho'])
        t0 = time.perf_counter()
        R1 = E.reference_margin(lay, x0, refs, G, dmax, 0.01 * fm['rho'], tol=1e-9, alpha_tab='rel')
        r['ref_time_s'] = time.perf_counter() - t0
        R0 = E.reference_margin(lay, x0, refs, G, dmax, 0.01 * fm['rho'], tol=1e-9, alpha_tab=0.0)
        r['dGt_tab'], r['dGt_rec'], r['dGt_exact'] = R1['dGt'], ref['dGt'], R0['dGt']
        r['dGt_status'] = R1['status']
        r['dGt_diff'] = abs(R1['dGt'] - ref['dGt'])
        r['dGt_tol'] = 1e-4 * fm['rho'] + 1e-8
        r['dGt_exact_minus_tab'] = R0['dGt'] - R1['dGt']
        r['ref_newton_solves'], r['ref_points'] = R1['newton_solves'], R1['points']
    # pass flags
    checks = []
    checks.append(r['refs_maxdiff'] <= 1e-9)
    checks.append(r['theta_b_diff'] <= 1e-9)
    if r.get('alpha_diff') is not None:
        checks.append(r['alpha_diff'] <= 1e-6)
    checks += [r['dGf_rel'] <= 1e-8, r['omega_rel'] <= 1e-8]
    if 'kappa_rel' in r:
        checks.append(r['kappa_rel'] <= 1e-6)
    if 'k_fd_rel' in r:
        checks.append(r['k_fd_rel'] <= 1e-6)
    if 'dGt_diff' in r:
        checks.append(r['dGt_diff'] <= r['dGt_tol'])
    if 'dG2nd_rel' in r:
        checks.append(r['dG2nd_rel'] <= 1e-6)
    r['n_checks'], r['n_pass'] = len(checks), int(sum(checks))
    r['reproduced'] = all(checks)
    rows.append(r)
    print(m['id'], 'PASS' if r['reproduced'] else 'FAIL', f"{r['n_pass']}/{r['n_checks']}",
          f"dGt diff {r.get('dGt_diff', float('nan')):.2e}", flush=True)

cols = []
for r in rows:
    for k in r:
        if k not in cols:
            cols.append(k)
with open(out / 'ind_vs_sealed.csv', 'w', encoding='utf-8', newline='') as f:
    w = csv.DictWriter(f, fieldnames=cols)
    w.writeheader()
    w.writerows(rows)
E_rows = [r for r in rows if r['in_E']]
summary = dict(
    members=len(rows), evaluable=len(E_rows),
    reproduced_evaluable=sum(1 for r in E_rows if r.get('reproduced')),
    dispatch_all=sum(1 for r in rows if r['dispatch_ok']),
    max=dict((k, max((r[k] for r in rows if r.get(k) is not None), default=None))
             for k in ('refs_maxdiff', 'theta_b_diff', 'alpha_diff', 'dGf_rel', 'omega_rel', 'kappa_rel',
                       'k_fd_rel', 'dGt_diff', 'dG2nd_rel')),
    dGt_exact_minus_tab=dict(min=min(r['dGt_exact_minus_tab'] for r in E_rows if 'dGt_exact_minus_tab' in r),
                             max=max(r['dGt_exact_minus_tab'] for r in E_rows if 'dGt_exact_minus_tab' in r)),
    runtime_s=time.perf_counter() - t_all,
    numpy=np.__version__, python=sys.version.split()[0])
(out / 'ind_vs_sealed_summary.json').write_text(json.dumps(summary, indent=1, default=str), encoding='utf-8')
print(json.dumps(summary, indent=1, default=str))
