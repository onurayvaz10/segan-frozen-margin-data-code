import json, sys, time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))
import ind_engine as E  # noqa: E402

rec_path, mid = sys.argv[1], sys.argv[2]
mem = {m['id']: m for m in json.load(open(rec_path, encoding='utf-8'))['members']}[mid]
P, GR = mem['P_akt'], mem['G_R']
lay = E.Layout(E.two_bus_system())
G = np.array([0.0, GR])
t = time.perf_counter()
d = E.dispatch(lay, [P], G)
print('dispatch ok', d['ok'], 'iters', d['iters'], 'res', d['hist'][-1], f'{time.perf_counter()-t:.2f}s')
print('refs mine', np.round(d['refs'], 12))
print('refs rec ', np.round(mem['rho'], 12))
x0 = d['x']
th_b = float(np.arctan2(x0[lay.ix['V1:I']], x0[lay.ix['V1:R']]))
print('theta_b', th_b, 'rec', mem['theta_b'])
Jm = E.jac(lay, x0, d['refs'], G)
a, _ = E.spectral_abscissa(lay, Jm)
print('alpha', a, 'rec', mem['alpha'])
t = time.perf_counter()
cr = E.crossings(lay, Jm, th_b)
print('crossings', len(cr), f'{time.perf_counter()-t:.2f}s', sorted([(round(c['omega'], 3), round(c['rho'], 6)) for c in cr])[:12])
fm = E.frozen_margin(lay, Jm, th_b, GR)
print('dGf', fm['rho'], 'omega*', fm['omega'], 'rec', mem['dGf'], mem['omega_star'])
k = E.kappa_hat(lay, x0, d['refs'], G, th_b, fm)
print('kappa', k['kappa'], 'c', k['c'], 'eta', k['eta'], 'rec', mem['kappa'].get('k_tam'), mem['kappa'].get('c'), mem['kappa'].get('eta'))
