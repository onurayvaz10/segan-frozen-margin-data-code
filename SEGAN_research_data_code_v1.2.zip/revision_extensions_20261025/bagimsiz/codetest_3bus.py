"""Code test of the generic network path on ONE off-family point (three buses). Prints only dispatch residual,
stability (sign of alpha) and the determinant identity check; it does not compute kappa or any margin."""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))
import ind_engine as E  # noqa: E402

par = E.base_parameters()
sysd = dict(par=par, buses=['1', '2', '3'], b_shunt=[0.005, 0.01, 0.005],
            lines=[dict(f=0, t=1, r=0.01, x=0.1), dict(f=1, t=2, r=0.01, x=0.1)], gfm_bus=0,
            cpls=[dict(bus=1, par=dict(par['cpl'])), dict(bus=2, par=dict(par['cpl']))], shed_bus=2)
lay = E.Layout(sysd)
G = np.array([0.0, 0.40, 0.40])          # off-family point (family G_R range ends at 0.30)
d = E.dispatch(lay, [0.05, 0.05], G)
print('n states', lay.n, 'dispatch ok', d['ok'], 'iters', d['iters'], 'res', d['hist'][-1])
Jm = E.jac(lay, d['x'], d['refs'], G)
a = E.spectral_abscissa(lay, Jm)[0]
print('alpha < 0:', a < 0)
keep, b = lay.keep, lay.port
r = [k for k in keep if k not in b]
for s in (1j * 2 * np.pi * 10, 1j * 2 * np.pi * 300):
    K = s * np.diag(lay.M) - Jm
    lhs = np.linalg.slogdet(K[np.ix_(keep, keep)])
    Y = E.port_admittance(lay, Jm, s)
    rr = np.linalg.slogdet(K[np.ix_(r, r)])
    print('det identity |dlog|', abs(lhs[1] - (rr[1] + np.log(abs(np.linalg.det(Y))))))
