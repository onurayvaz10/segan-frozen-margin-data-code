"""PROTOCOL_INDEPENDENT_VALIDATION_v1.0 §4 (derivative validation) and §5 (computational cost).

usage: python -I deriv_cost.py <sonuc.json> <research_intelligence root> <out_dir>
The original model modules are imported ONLY here, to compare the Jacobian (§4 (i)).
"""
import csv, json, math, os, statistics, sys, time
from pathlib import Path

os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('MKL_NUM_THREADS', '1')
import numpy as np  # noqa: E402

sys.path.insert(0, str(Path(__file__).parent))
import ind_engine as E  # noqa: E402

rec_path, ri_root, out = sys.argv[1], Path(sys.argv[2]), Path(sys.argv[3])
out.mkdir(parents=True, exist_ok=True)
members = json.load(open(rec_path, encoding='utf-8'))['members']
E_mem = [m for m in members if m['in_E']]
sel = []
for P in sorted({m['P_akt'] for m in E_mem}):
    sel.append(max((m for m in E_mem if m['P_akt'] == P), key=lambda m: m['G_R']))
lay = E.Layout(E.two_bus_system())

# ---------------- original model (comparison only) ----------------
sys.path.insert(0, str(ri_root / 'e1_k' / 'code'))
import e1k_model as KM  # noqa: E402
import e1k_core as KC  # noqa: E402

kpv, kiv = KC.pu_gains([s for s in KC.SETTINGS if s.code == 'S3'][0])
orig = KM.E1KModel('S3', dict(kpv=kpv, kiv=kiv))
ORIG_NAMES = list(KM.STATE_NAMES)


def to_mine_name(nm):
    if nm.startswith('V_1:'):
        return 'V0:' + nm[-1]
    if nm.startswith('V_2:'):
        return 'V1:' + nm[-1]
    if 'Il_R' in nm:
        return 'L0:R'
    if 'Il_I' in nm:
        return 'L0:I'
    dev, st = nm.split(':', 1)
    if dev == KM.G:
        return 'G:' + E.GFM_NAMES[list(KM.GFM_STATES).index(st)]
    return 'C0:' + E.CPL_NAMES[list(KM.LOAD_STATES).index(st)]


perm = [lay.ix[to_mine_name(nm)] for nm in ORIG_NAMES]          # orig index k -> mine index perm[k]


def relerr(a, b):
    return float(np.max(np.abs(a - b)) / max(float(np.max(np.abs(b))), 1e-300))


drows, crows = [], []
for m in sel:
    G = np.array([0.0, m['G_R']])
    d = E.dispatch(lay, [m['P_akt']], G)
    x0, refs = d['x'], d['refs']
    th = float(np.arctan2(x0[lay.ix['V1:I']], x0[lay.ix['V1:R']]))
    # (i) Jacobian
    Jcs = E.jac(lay, x0, refs, G)
    Jfd = np.zeros_like(Jcs)
    for k in range(lay.n):
        hk = 1e-7 * max(1.0, abs(x0[k]))
        xp, xm = x0.copy(), x0.copy()
        xp[k] += hk
        xm[k] -= hk
        Jfd[:, k] = (E.rhs(lay, xp, refs, G) - E.rhs(lay, xm, refs, G)) / (2 * hk)
    xo = x0[perm]
    Jor = np.asarray(orig.J(xo, refs, m['G_R']), dtype=float)
    Jor_m = np.zeros_like(Jor)
    Jor_m[np.ix_(perm, perm)] = Jor
    fo = np.asarray(orig.f(xo, refs, m['G_R']), dtype=float)
    # (ii) xi
    Jm = Jcs
    keep = lay.keep
    xi = np.zeros(lay.n)
    xi[keep] = np.linalg.solve(Jm[np.ix_(keep, keep)], E.dfdG(lay, x0, refs, G, 1)[keep])
    fm = E.frozen_margin(lay, Jm, th, m['G_R'])
    h = 1e-4 * fm['rho']
    xs = {}
    for sg in (1, -1):
        Gk = G.copy()
        Gk[1] -= sg * h
        xs[sg] = E.newton_fixed_refs(lay, x0, refs, Gk, tol=1e-14)[0]
    xi_fd = (xs[1] - xs[-1]) / (2 * h)
    eps = 1e-20
    xc = x0.astype(complex)
    Gc = G.astype(complex)
    Gc[1] -= 1j * eps
    for _ in range(4):
        Fc = E.rhs(lay, xc, refs, Gc)
        dxc = np.linalg.solve(Jm[np.ix_(keep, keep)], -Fc[keep])
        xc[keep] += dxc
    xi_cs = np.imag(xc) / eps
    # (iii) eta
    k = E.kappa_hat(lay, x0, refs, G, th, fm)
    lam = {}
    for sg in (1, -1):
        lam[sg] = E.eig_branch(lay, E.jac(lay, xs[sg], refs, G), th, fm['omega'], fm['lam'])[0]
    eta_fd = (lam[1] - lam[-1]) / (2 * h)
    # (iv) kappa
    kfd = {}
    for hh in (1e-3, 1e-4):
        hh_ = hh * fm['rho']
        rr = {}
        for sg in (1, -1):
            Gk = G.copy()
            Gk[1] -= sg * hh_
            xx = E.newton_fixed_refs(lay, x0, refs, Gk, tol=1e-14)[0]
            rr[sg] = E.rho_at(lay, xx, refs, G, th, fm)['rho']
        kfd[hh] = (rr[1] - rr[-1]) / (2 * hh_)
    k_rich = (100 * kfd[1e-4] - kfd[1e-3]) / 99
    # (v) c
    cs = {}
    for st in (1e-6, 1e-7):
        dw = st * fm['omega']
        lp = E.eig_branch(lay, Jm, th, fm['omega'] + dw, fm['lam'])[0]
        lm = E.eig_branch(lay, Jm, th, fm['omega'] - dw, fm['lam'])[0]
        dl = (lp - lm) / (2 * dw)
        cs[st] = dl.real / dl.imag
    drows.append(dict(
        id=m['id'], f_orig_residual_at_mine_x0=float(np.max(np.abs(fo[[i for i in range(len(fo)) if ORIG_NAMES[i] != KM.TH_OC]]))),
        J_cs_vs_original_symbolic=relerr(Jcs, Jor_m), J_fd_vs_cs=relerr(Jfd, Jcs),
        xi_fd_vs_linear=relerr(xi_fd[keep], xi[keep]), xi_cs_vs_linear=relerr(xi_cs[keep], xi[keep]),
        eta_linear=str(k['eta']), eta_fd_vs_linear=abs(eta_fd - k['eta']) / abs(k['eta']),
        kappa_hat=k['kappa'], kfd_1e3=kfd[1e-3], kfd_1e4=kfd[1e-4], kfd_richardson=k_rich,
        kappa_vs_richardson=abs(k['kappa'] - k_rich) / abs(k_rich),
        c_1e6=cs[1e-6], c_1e7=cs[1e-7], c_rel_spread=abs(cs[1e-6] - cs[1e-7]) / abs(cs[1e-6])))
    print('deriv', m['id'], {kk: (f'{v:.2e}' if isinstance(v, float) else v) for kk, v in drows[-1].items()}, flush=True)

    # ---------------- §5 cost ----------------
    cnt = dict(rhs=0, jac=0, eig=0, newton=0, scan_pts=0)
    _rhs, _jac, _nf, _cr, _eb = E.rhs, E.jac, E.newton_fixed_refs, E.crossings, E.eig_branch
    _eigvals = np.linalg.eigvals

    def c_jac(*a, **kw):
        cnt['jac'] += 1
        return _jac(*a, **kw)

    def c_newton(*a, **kw):
        cnt['newton'] += 1
        return _nf(*a, **kw)

    def c_cross(*a, **kw):
        cnt['scan_pts'] += 6000
        return _cr(*a, **kw)

    def c_eigvals(Mx):
        cnt['eig'] += 1
        return _eigvals(Mx)

    E.jac, E.newton_fixed_refs, E.crossings = c_jac, c_newton, c_cross
    np.linalg.eigvals = c_eigvals

    def est_frozen():
        Jx = E.jac(lay, x0, refs, G)
        return E.frozen_margin(lay, Jx, th, m['G_R'])

    def est_first():
        f0 = est_frozen()
        kk = E.kappa_hat(lay, x0, refs, G, th, f0)
        return f0['rho'] / (1 - kk['kappa'])

    def est_second():
        f0 = est_frozen()
        hh_ = 1e-3 * f0['rho']
        rr = {}
        for sg in (1, -1):
            Gk = G.copy()
            Gk[1] -= sg * hh_
            xx = E.newton_fixed_refs(lay, x0, refs, Gk)[0]
            rr[sg] = E.rho_at(lay, xx, refs, G, th, f0)['rho']
        kf = (rr[1] - rr[-1]) / (2 * hh_)
        a2 = 0.5 * (rr[1] - 2 * f0['rho'] + rr[-1]) / hh_ ** 2
        b2 = kf - 1
        disc = b2 * b2 - 4 * a2 * f0['rho']
        return (-b2 - math.sqrt(disc)) / (2 * a2)

    def est_single_step():
        f0 = est_frozen()
        Gk = G.copy()
        Gk[1] -= f0['rho']
        xx = E.newton_fixed_refs(lay, x0, refs, Gk)[0]
        Jx = E.jac(lay, xx, refs, G)
        cr = [c for c in E.crossings(lay, Jx, th) if c['rho'] > 0]
        return min(c['rho'] for c in cr) - f0['rho']

    def est_reference():
        f0 = est_frozen()
        return E.reference_margin(lay, x0, refs, G, min(m['G_R'], 2 * f0['rho']), 0.01 * f0['rho'],
                                  tol=1e-4 * f0['rho'], alpha_tab='rel')['dGt']

    for name, fn in (('B_frozen', est_frozen), ('C_first_order', est_first), ('D_second_order', est_second),
                     ('E_single_step_relinearization', est_single_step), ('A_reference_continuation', est_reference)):
        walls, cpus = [], []
        for rep in range(5):
            for kk in cnt:
                cnt[kk] = 0
            t0, c0 = time.perf_counter(), time.process_time()
            val = fn()
            walls.append(time.perf_counter() - t0)
            cpus.append(time.process_time() - c0)
        crows.append(dict(id=m['id'], estimator=name, value=val if not isinstance(val, dict) else val['rho'],
                          equilibrium_solves=cnt['newton'], jacobian_evaluations=cnt['jac'],
                          eigenvalue_solves=cnt['eig'], frequency_scan_points=cnt['scan_pts'],
                          wall_s_median=statistics.median(walls), cpu_s_median=statistics.median(cpus),
                          wall_s_min=min(walls), wall_s_max=max(walls), repetitions=5))
        print('cost', m['id'], name, f'{crows[-1]["wall_s_median"]:.3f}s', cnt, flush=True)
    E.jac, E.newton_fixed_refs, E.crossings = _jac, _nf, _cr
    np.linalg.eigvals = _eigvals

for name, rows in (('DERIVATIVE_VALIDATION_TABLE.csv', drows), ('COMPUTATIONAL_COST.csv', crows)):
    with open(out / name, 'w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
import platform  # noqa: E402
env = dict(python=sys.version, numpy=np.__version__, platform=platform.platform(), processor=platform.processor(),
           blas_threads=os.environ.get('OPENBLAS_NUM_THREADS'), cpu_count=os.cpu_count())
try:
    import numpy.__config__ as nc  # noqa: E402
    env['numpy_config'] = str(nc.CONFIG.get('Build Dependencies', {}).get('blas', ''))[:300]
except Exception:  # noqa: BLE001
    pass
(out / 'environment.json').write_text(json.dumps(env, indent=1), encoding='utf-8')
print('done')
