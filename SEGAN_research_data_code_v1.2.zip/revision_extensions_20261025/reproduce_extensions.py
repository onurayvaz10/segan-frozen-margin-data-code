"""One-command reproduction of the revision extensions of 25 October 2026 (stdlib + numpy).

usage (from the archive root):  python -I revision_extensions_20261025/reproduce_extensions.py [--with-cost]

Steps, in order, each in its own process (never in parallel): unit tests; PSV gate (--check-only) and synthetic
test (--synth); full validation of the separately coded engine against the sealed record (into a temporary folder);
post-hoc statistics (into a temporary folder); optional cost benchmark. Regenerated numbers are compared with the
distributed files; the sealed PSV run is NOT re-executed (single-run rule; its SHA256SUMS is verified instead).
Writes revision_extensions_20261025/REPRODUCTION_REPORT.md.
"""
import csv, hashlib, json, subprocess, sys, tempfile, time
from pathlib import Path

EXT = Path(__file__).resolve().parent
ROOT = EXT.parent
PY = sys.executable
rows = []


def step(name, args):
    t0 = time.perf_counter()
    r = subprocess.run([PY, '-I', '-X', 'utf8'] + [str(a) for a in args], capture_output=True, text=True,
                       encoding='utf-8', errors='replace')
    rows.append(dict(step=name, exit=r.returncode, seconds=round(time.perf_counter() - t0, 1),
                     tail=(r.stdout.strip().splitlines() or [''])[-1][:160]))
    print(f'[{name}] exit {r.returncode}  {rows[-1]["tail"]}', flush=True)
    return r.returncode


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def close(a, b, rtol=1e-6, atol=1e-9):
    return abs(a - b) <= atol + rtol * abs(b)


sealed = ROOT / 'research_intelligence/cdl1/out/HDL2b_20261021_a/sonuc.json'
pred = ROOT / 'posthoc/posthoc_member_predictions.csv'
tmp = Path(tempfile.mkdtemp(prefix='segan_ext_'))
step('unit tests', [EXT / 'tests/test_engine.py', ROOT])
step('PSV gate (--check-only)', [EXT / 'psv/psv_run.py', '--check-only'])
step('PSV synthetic test', [EXT / 'psv/psv_run.py', '--synth'])
step('engine validation (79 members)', [EXT / 'bagimsiz/validate_all.py', sealed, pred, tmp / 'val'])
step('post-hoc statistics', [EXT / 'istatistik/stats_ext.py', pred, tmp / 'stat'])
if '--with-cost' in sys.argv:
    step('cost benchmark (timings are machine-dependent)', [EXT / 'bagimsiz/deriv_cost.py', sealed, ROOT / 'research_intelligence', tmp / 'cost'])

cmp = []
try:
    a = json.loads((tmp / 'val/ind_vs_sealed_summary.json').read_text(encoding='utf-8'))
    b = json.loads((EXT / 'bagimsiz/out_validation/ind_vs_sealed_summary.json').read_text(encoding='utf-8'))
    cmp.append(('validation: members reproduced', a['reproduced_evaluable'] == b['reproduced_evaluable'],
                f"{a['reproduced_evaluable']}/{a['evaluable']} (distributed {b['reproduced_evaluable']}/{b['evaluable']})"))
    ra = {r['id']: r for r in csv.DictReader(open(tmp / 'val/ind_vs_sealed.csv', encoding='utf-8'))}
    rb = {r['id']: r for r in csv.DictReader(open(EXT / 'bagimsiz/out_validation/ind_vs_sealed.csv', encoding='utf-8'))}
    bad = [(k, c) for k in rb for c in ('dGf', 'kappa', 'k_fd', 'dGt_tab', 'dG2nd')
           if rb[k].get(c) not in ('', None) and not close(float(ra[k][c]), float(rb[k][c]))]
    cmp.append(('validation: per-member values (rtol 1e-6)', not bad, f'{len(bad)} differences'))
except Exception as exc:  # noqa: BLE001
    cmp.append(('validation comparison', False, repr(exc)))
try:
    a = json.loads((tmp / 'stat/STATISTICS_EXTENDED.json').read_text(encoding='utf-8'))
    b = json.loads((EXT / 'istatistik/out/STATISTICS_EXTENDED.json').read_text(encoding='utf-8'))
    keys = ('pooled_pearson', 'group_centred_pearson', 'eta_squared_groups', 'MAE_reduction_second_vs_frozen')
    cmp.append(('statistics: point estimates', all(close(a[k], b[k]) for k in keys), ', '.join(f'{k}={a[k]:.4f}' for k in keys)))
    cmp.append(('statistics: bootstrap intervals (seeded)', a['MAE_reduction_second_vs_frozen_CI_cluster'] == b['MAE_reduction_second_vs_frozen_CI_cluster'], str(a['MAE_reduction_second_vs_frozen_CI_cluster'])))
except Exception as exc:  # noqa: BLE001
    cmp.append(('statistics comparison', False, repr(exc)))
psv = EXT / 'psv/out/PSV_20261025_a'
ok_sums = all(sha(psv / ln.split()[1]) == ln.split()[0]
              for ln in (psv / 'SHA256SUMS').read_text(encoding='utf-8').splitlines() if ln.strip())
cmp.append(('sealed PSV run: SHA256SUMS', ok_sums, 'not re-executed (single-run rule)'))
verdict = 'VERIFIED' if all(r['exit'] == 0 for r in rows) and all(c[1] for c in cmp) else 'DIFFERENCES FOUND'
lines = ['# Reproduction report — revision extensions', '', f'Python {sys.version.split()[0]}; temporary outputs in `{tmp}`.', '',
         f'**Verdict: {verdict}**', '', '| Step | Exit | Seconds | Last line |', '|---|---|---|---|']
lines += [f"| {r['step']} | {r['exit']} | {r['seconds']} | {r['tail']} |" for r in rows]
lines += ['', '| Comparison | Result | Detail |', '|---|---|---|'] + [f'| {n} | {"PASS" if o else "FAIL"} | {d} |' for n, o, d in cmp]
(EXT / 'REPRODUCTION_REPORT.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
print('VERDICT', verdict)
sys.exit(0 if verdict == 'VERIFIED' else 1)
