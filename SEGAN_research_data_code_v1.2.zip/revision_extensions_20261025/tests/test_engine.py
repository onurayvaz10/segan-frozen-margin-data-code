"""Unit and regression tests of the separately coded engine (plain asserts; run: python -I tests/test_engine.py <archive root>).

Covers: equilibrium consistency, Jacobian accuracy, eigenvalue/crossing selection, first-order coefficient,
quadratic estimator formula and reproduction of one sealed reference margin.
"""
import json, math, sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'bagimsiz'))
import ind_engine as E  # noqa: E402

root = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE.parents[2]
rec = {m['id']: m for m in json.load(open(root / 'research_intelligence/cdl1/out/HDL2b_20261021_a/sonuc.json',
                                          encoding='utf-8'))['members']}['S3_P0.65_G0.20']
lay = E.Layout(E.two_bus_system())
G = np.array([0.0, rec['G_R']])
results = []


def check(name, cond, detail=''):
    results.append((name, bool(cond)))
    print(('PASS ' if cond else 'FAIL ') + name, detail)


d = E.dispatch(lay, [rec['P_akt']], G)
x0, refs = d['x'], d['refs']
check('equilibrium residual <= 1e-12', max(abs(E.rhs(lay, x0, refs, G)[lay.keep])) <= 1e-12)
check('set-points reproduce sealed record', np.max(np.abs(refs - np.array(rec['rho']))) <= 1e-9)
Jcs = E.jac(lay, x0, refs, G)
k = 7
hk = 1e-7
xp, xm = x0.copy(), x0.copy()
xp[k] += hk
xm[k] -= hk
col = (E.rhs(lay, xp, refs, G) - E.rhs(lay, xm, refs, G)) / (2 * hk)
check('complex-step vs central-difference Jacobian column', np.max(np.abs(col - Jcs[:, k])) <= 1e-6 * max(1, np.max(np.abs(col))))
th = float(np.arctan2(x0[lay.ix['V1:I']], x0[lay.ix['V1:R']]))
fm = E.frozen_margin(lay, Jcs, th, rec['G_R'])
check('frozen margin and crossing frequency', abs(fm['rho'] - rec['dGf']) <= 1e-8 * rec['dGf']
      and abs(fm['omega'] - rec['omega_star']) <= 1e-8 * rec['omega_star'])
lam, v, w, Y = E.eig_branch(lay, Jcs, th, fm['omega'], fm['lam'])
check('critical eigenvalue is real at the crossing', abs(lam.imag) <= 1e-10 * abs(lam))
kh = E.kappa_hat(lay, x0, refs, G, th, fm)
check('first-order coefficient vs sealed record', abs(kh['kappa'] - rec['kappa']['k_tam']) <= 1e-6 * abs(rec['kappa']['k_tam']))
h = 1e-3 * fm['rho']
rr = {}
for sg in (1, -1):
    Gk = G.copy()
    Gk[1] -= sg * h
    rr[sg] = E.rho_at(lay, E.newton_fixed_refs(lay, x0, refs, Gk)[0], refs, G, th, fm)['rho']
kfd = (rr[1] - rr[-1]) / (2 * h)
check('kappa_hat agrees with finite-difference slope', abs(kh['kappa'] - kfd) <= 1e-5 * abs(kfd))
curv = (rr[1] - 2 * fm['rho'] + rr[-1]) / h ** 2
q = 2 * fm['rho'] / ((1 - kfd) + math.sqrt((1 - kfd) ** 2 - 2 * curv * fm['rho']))
check('quadratic estimator (Eq. 18) lies between frozen and tangent', fm['rho'] < q < fm['rho'] / (1 - kfd))
R = E.reference_margin(lay, x0, refs, G, min(rec['G_R'], 2 * fm['rho']), 0.01 * fm['rho'], tol=1e-9, alpha_tab='rel')
check('reference margin reproduces sealed value', abs(R['dGt'] - rec['ref']['dGt']) <= 1e-4 * fm['rho'] + 1e-8,
      f"{R['dGt']:.8f} vs {rec['ref']['dGt']:.8f}")
ok = all(v for _, v in results)
print('TESTS', 'PASS' if ok else 'FAIL', f'{sum(v for _, v in results)}/{len(results)}')
sys.exit(0 if ok else 1)
