# PSV kod yeniden denetimi D2 — `psv/psv_run.py` v2
Tarih: 2026-10-25 · Kod yeniden denetimi D2.

## §0 Kapsam ve doğrulama
- VERIFIED SHA-256 (hepsi verilen pinlerle aynı): D1 raporu 5dd49d23…38de; protokol 865d84e5…5f28; ek metin A1 7bd97a73…be9a; betik v2 **186e4fe6…8f08**; v1 arşivi 0d3f90ee…4330; motor c45ec8f4…ae6b; yetki JSON'u 9aef8df4…3e85. Manifest satır 2–4 protokolü, motoru ve A1'i içeriyor.
- Kapsam yalnız şunlar: D1'deki R1–R10 düzeltmeleri ve bu düzeltmelerin getirdiği yeni kusurlar. v1→v2 farkı tam okundu.
- Koşulanlar:
  - `--check-only`: tüm hash'ler OK; manifest OK; doğrulama kapısı OK (evaluable 79, birincil başarısızlık yok, ikincil başarısızlık S3_P0.70_G0.20 dG2nd 1.59e-6); çıkış 0.
  - `--synth`: PASS 21/21, çıkış 0.
  - `--run` koşulmadı; `psv/out/` yok. PSV noktası hesaplanmadı, mühürlü sonuç görülmedi.
- Ek kontrol: proje dışında ayrı bir test betiğiyle (`t_d2.py`) yalnız sentetik girdiler üzerinde A1.4 eşitlik kuralı, boş kapsam, eşitlik eşiği ve seçim sınırı denetlendi. Proje klasörüne bu rapordan başka dosya yazılmadı.

## §1 D1 düzeltmeleri
| ID | Durum | Kanıt |
|---|---|---|
| R1 | IMPLEMENTED | A1.1. Kapı psv_run.py:459–474'te birincil ölçütleri kullanıyor (PRIMARY_CRIT 39–40 ve dGt_tol, `validate_all.py:101–111` ile aynı). `evaluable>0` koşulu 469'da. Başarısızlıkta `--check-only` 2 döndürüyor (612). |
| R2 | IMPLEMENTED | Özet ve CSV SHA'ları 32–35'te pinli, 448–454'te denetleniyor. Manifest girdileri 455–458'de kontrol ediliyor. |
| R3 | IMPLEMENTED | G3 şartı α < −max(1e-3, α_tab) (140–146) ve α_tab0 kaydediliyor. Hesap motorun 570–572 ve 584–586'daki tanımıyla aynı J'yi (G kesilmeden önceki) kullanıyor. Kalan 'unstable' durumları `S2-unstable-x0` etiketiyle dışlanıyor (216–219, 245–247) ve işaret almıyor (559). |
| R4 | IMPLEMENTED | A1.3'te 8 deneme / 7 yarılama beyan edilmiş. Motor değişmemiş (ind_engine.py:590–594). |
| R5 | IMPLEMENTED | 316–318: büyük p seçiliyor. Ek kontrol: acc(R2)=acc(R3)=0.5 için p(R2)=0.00195 ve p(R3)=0.0987. Seçilen R3, p=0.0987, satır 3 veriyor; doğru. |
| R6 | IMPLEMENTED | Her kapsam `evaluate`/`decide`'dan geçiyor (577–582). n=0 durumu 320'de ele alınıyor. Sentetik test 409–410. |
| R7 | IMPLEMENTED | Noktalar `except Exception` ile korunuyor (528–531, 551–554). try/except/finally yapısı 511–601'de. `crash.txt` 591'de, `exit_code.txt` 597'de, SHA256SUMS her yolda, ABORT dahil (514–519, 598–601). Aşama 2 artımlı yazılıyor (`stage2.jsonl`, 548–557). |
| R8 | IMPLEMENTED | run_id zorlanıyor (491–493). Yetki JSON'u denetleniyor (480–486) ve bu, import'tan (521) önce yapılıyor (499). Motor import sonrası yeniden doğrulanıyor (522–523). Pinler 560–563'te. |
| R9 | IMPLEMENTED | Seçimler docstring 12–15'te ve A1.7'de belgeli. `selection.json` κ̂, κ̂_noc, ΔG*_f ve ω* içeriyor (542–543). |
| R10 | PARTIAL | 21 durum var. İşaret atama saf bir fonksiyon (216–223) ve test ediliyor (429–432). Eksikler: p=0.01 ve Wilson 0.75 sınırlarında birebir test yok (332–336'daki işleçler protokolle aynı: `<10`, `≥0.01`, `≥0.75`). Eşitlik testi (380) simetrik olduğundan max-p mantığını ayırt etmiyor; bunu ek kontrolüm doğruladı. Yeniden koşu reddi (495–497) test edilmiyor. Yalnız başarısız durumlar adıyla basılıyor. Hiçbiri koşuyu engellemiyor. |

## §2 Körleme
Bozulmamış:
- Aşama 1'de sonuç hesabı yok; log yalnız öngörücüyü (κ̂) basıyor (533).
- `stage1.json` ve `selection.json` yazılıp hash'leniyor, ardından Aşama 2 başlıyor (534–546).
- Seçim tohumları ve tabakalar protokolle aynı. Ek kontrol: 121 üyede 60+60.

## §3 Yeni kusurlar (engelleyici değil)
- **N1:** Birincil alan boşsa veya NaN ise kapı onu sessizce atlıyor (465, 467). Pinli tabloda 79 üyenin 8 birincil alanında boş/NaN yok (kontrol edildi). Hash sabit olduğu için etkisi yok.
- **N2:** A1.1 ikincil başarısızlıkların "sonuçlarda" listelenmesini istiyor. Liste yalnız mühürlü `log.txt`'ye gidiyor (512–513), `result.json`'a girmiyor. Öneri: B5 raporu log'dan alıntılasın.
- **N3:** `accuracy_stats` içinde `rel = e/ref` (355) ΔG*_ref = 0 olursa (ilk adımda fold) inf/NaN üretir. Sonuç RuntimeWarning olur, çökme olmaz; yalnız betimsel yüzdelikleri etkiler. B5'te not edilmeli.
- **N4:** `check_only`/`check_auth` (498–499) çıktı klasörü oluşturulmadan önce istisna atarsa kayıt kalmaz. Hesap yapılmadığı için yanlılık doğmaz.
- **N5:** `stage1.json` yalnız 800 noktanın sonunda yazılıyor (535). Aşama 1'de bir çökme olursa nokta düzeyindeki satırlar `log.txt`'de ve `crash.txt` dosyasında kalır.
- **N6:** Aşama 2'de `dispatch` sonucunun `ok` değeri denetlenmiyor (229). Aynı deterministik çözüm G1'i geçmişti; zararsız.
- Yetki JSON'undaki "ACCEPT_FOR_RUN sonrası geçerli" koşulu makineyle denetlenmiyor; bu usule ait bir koşul.

## §4 Hüküm
D1'in engelleyici bulguları (R1, R3, R7) kapanmış; R2, R4, R5, R6, R8 ve R9 da uygulanmış. R10 kısmi kalıyor, ama eksik testler kod okumasıyla doğrulanan basit karşılaştırmalara ait. Kararı saptıracak, körlemeyi bozacak veya koşuyu kayıtsız çökertecek bir kusur bulunmadı.

**Genel hüküm: ACCEPT_FOR_RUN** (tek koşu `--run PSV_20261025_a`; N2 ve N3 B5 raporunda ele alınmalı).

