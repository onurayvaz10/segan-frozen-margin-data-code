"""Prospective sign validation and second test system (PROSPECTIVE_VALIDATION_PROTOCOL.md, PSV v1.0).

Modes
  --check-only          verify the hashes of the protocol and of the frozen engine; no model is built.
  --synth               synthetic test of selection, statistics and decision table on constructed inputs.
  --run RUN_ID          exactly one real run into psv/out/RUN_ID/ (refused if the folder exists).
Imports only numpy and the frozen engine bagimsiz/ind_engine.py. BLAS threads 1.
"""
import argparse, hashlib, json, math, os, sys, time
from pathlib import Path

os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['MKL_NUM_THREADS'] = '1'
import numpy as np  # noqa: E402

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PROTOCOL = HERE / 'PROSPECTIVE_VALIDATION_PROTOCOL.md'
PROTOCOL_SHA = '865d84e5ef6b928b0e8e962056596fb833fcf3f7fe2a0ed2ca72d13a37585f28'
ENGINE = ROOT / 'bagimsiz' / 'ind_engine.py'
ENGINE_SHA = 'c45ec8f40d24911dfe51daee76056ae4aaefd0027b8b976aa1ef57e98315ae6b'
VALIDATION_SUMMARY = ROOT / 'bagimsiz' / 'out_validation' / 'ind_vs_sealed_summary.json'

N_A, N_B = 400, 400
SEED_A, SEED_B, SEED_SEL_A, SEED_SEL_B, SEED_BOOT = 20261025, 20261026, 31, 32, 41
TAU_K, TIE_K, H_REL, SEL_MAX, SEL_STRATUM = 0.05, 2e-3, 1e-3, 120, 60
VB, PB = 380.0, 10000.0
IB = PB / VB
VB_DC = math.sqrt(8) / math.sqrt(3) * VB


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


# --------------------------------------------------------------------------------------------- sampling (§2)
def u(rng, lo, hi, log=False):
    if log:
        return float(math.exp(rng.uniform(math.log(lo), math.log(hi))))
    return float(rng.uniform(lo, hi))


def sample_A(n=N_A, seed=SEED_A):
    rng = np.random.default_rng(seed)
    out = []
    for k in range(n):
        out.append(dict(id=f'A{k:03d}', system='A', Kiv=u(rng, 15, 2700, True), s_pll=u(rng, 0.25, 4, True),
                        s_cc=u(rng, 0.5, 2, True), lv=u(rng, 0.05, 0.40), rv=u(rng, 0.0, 0.10),
                        s_v=u(rng, 0.5, 2, True), s_line=u(rng, 0.5, 3, True), kq=u(rng, 0.02, 0.10),
                        Rp=u(rng, 0.01, 0.05), P_set=u(rng, 0.45, 0.75), G_R=u(rng, 0.05, 0.35)))
    return out


def sample_B(n=N_B, seed=SEED_B):
    rng = np.random.default_rng(seed)
    out = []
    for k in range(n):
        out.append(dict(id=f'B{k:03d}', system='B', P1=u(rng, 0.10, 0.35), P2=u(rng, 0.20, 0.45),
                        G2=u(rng, 0.0, 0.15), G_R=u(rng, 0.05, 0.30), s_l1=u(rng, 0.5, 2.5, True),
                        s_l2=u(rng, 0.5, 2.5, True), Kiv1=u(rng, 15, 2700, True), Kiv2=u(rng, 15, 2700, True),
                        s_pll1=u(rng, 0.25, 4, True), s_pll2=u(rng, 0.25, 4, True), lv=u(rng, 0.05, 0.40)))
    return out


def cpl_variant(E, base, Kiv, s_pll=1.0, s_cc=1.0):
    q = dict(base)
    q['kiv'] = Kiv * (VB_DC / IB)
    q['kpv'] = (Kiv / 300.0) * (VB_DC / IB)
    q['kp_pll'], q['ki_pll'] = base['kp_pll'] * s_pll, base['ki_pll'] * s_pll
    q['kpc'], q['kic'] = base['kpc'] * s_cc, base['kic'] * s_cc
    return q


def build(E, spec):
    par = E.base_parameters()
    if spec['system'] == 'A':
        g = par['gfm']
        g['lv'], g['rv'], g['kq'], g['Rp'] = spec['lv'], spec['rv'], spec['kq'], spec['Rp']
        g['kpv'], g['kiv'] = g['kpv'] * spec['s_v'], g['kiv'] * spec['s_v']
        sysd = dict(par=par, buses=['1', '2'], b_shunt=[0.005, 0.005],
                    lines=[dict(f=0, t=1, r=0.01 * spec['s_line'], x=0.1 * spec['s_line'])], gfm_bus=0,
                    cpls=[dict(bus=1, par=cpl_variant(E, par['cpl'], spec['Kiv'], spec['s_pll'], spec['s_cc']))],
                    shed_bus=1)
        G = np.array([0.0, spec['G_R']])
        P = [spec['P_set']]
    else:
        par['gfm']['lv'] = spec['lv']
        sysd = dict(par=par, buses=['1', '2', '3'], b_shunt=[0.005, 0.010, 0.005],
                    lines=[dict(f=0, t=1, r=0.01 * spec['s_l1'], x=0.1 * spec['s_l1']),
                           dict(f=1, t=2, r=0.01 * spec['s_l2'], x=0.1 * spec['s_l2'])], gfm_bus=0,
                    cpls=[dict(bus=1, par=cpl_variant(E, par['cpl'], spec['Kiv1'], spec['s_pll1'])),
                          dict(bus=2, par=cpl_variant(E, par['cpl'], spec['Kiv2'], spec['s_pll2']))],
                    shed_bus=2)
        G = np.array([0.0, spec['G2'], spec['G_R']])
        P = [spec['P1'], spec['P2']]
    return E.Layout(sysd), G, P


# --------------------------------------------------------------------------------------------- stage 1 (§3)
def stage1_point(E, spec):
    rec = dict(spec)
    lay, G, P = build(E, spec)
    sb = lay.sysd['shed_bus']
    d = E.dispatch(lay, P, G, tol=1e-12)
    rec['res'] = d['hist'][-1]
    if not d['ok']:
        rec['excl'] = 'G1'
        return rec
    x0, refs = d['x'], d['refs']
    ix = lay.ix
    nb = len(lay.sysd['buses'])
    V = [abs(complex(x0[ix[f'V{k}:R']], x0[ix[f'V{k}:I']])) for k in range(nb)]
    kb = lay.sysd['gfm_bus']
    S_G = V[kb] * abs(complex(x0[ix['G:Irf']], x0[ix['G:Iif']]))
    load = sum(P) + sum(G[k] * V[k] ** 2 for k in range(nb))
    rec.update(Vmin=min(V), Vmax=max(V), S_G=S_G, load=load)
    if not (0.88 <= min(V) and max(V) <= 1.10 and S_G <= 1.0 and load <= 1.0):
        rec['excl'] = 'G2'
        return rec
    Jm = E.jac(lay, x0, refs, G)
    a = E.spectral_abscissa(lay, Jm)[0]
    rec['alpha0'] = a
    if not a < -1e-3:
        rec['excl'] = 'G3'
        return rec
    th = float(np.arctan2(x0[ix[f'V{sb}:I']], x0[ix[f'V{sb}:R']]))
    fm = E.frozen_margin(lay, Jm, th, G[sb])
    if fm is None or not (0 < fm['rho'] <= G[sb]):
        rec['excl'] = 'G4'
        rec['dGf'] = None if fm is None else fm['rho']
        return rec
    Y0 = E.to_F0(E.port_admittance(lay, Jm, 0.0), th)
    ev0 = np.linalg.eigvals(Y0)
    if any(abs(e.imag) < 1e-12 and 0 < e.real <= fm['rho'] for e in ev0):
        rec['excl'] = 'G4-omega0'
        return rec
    k = E.kappa_hat(lay, x0, refs, G, th, fm)
    lam, _, _, Yw = E.eig_branch(lay, Jm, th, fm['omega'], fm['lam'])
    evw = np.linalg.eigvals(Yw)
    gap = float(abs(evw[0] - evw[1]))
    rec.update(dGf=fm['rho'], omega=fm['omega'], c=k['c'], eta_re=k['eta'].real, eta_im=k['eta'].imag,
               kappa=k['kappa'], kappa_noc=k['eta'].real, gap=gap, dIm_domega=k['dlam_domega'].imag)
    if not (gap >= 1e-6 * max(1.0, abs(lam)) and abs(k['dlam_domega'].imag) >= 1e-9):
        rec['excl'] = 'G5'
        return rec
    h = H_REL * fm['rho']
    rr = {}
    for sg in (1, -1):
        Gk = G.copy()
        Gk[sb] -= sg * h
        xs, ok, _, _ = E.newton_fixed_refs(lay, x0, refs, Gk)
        if not ok:
            rec['excl'] = 'G6-newton'
            return rec
        rr[sg] = E.rho_at(lay, xs, refs, G, th, fm)['rho']
    k_fd = (rr[1] - rr[-1]) / (2 * h)
    curv = (rr[1] - 2 * fm['rho'] + rr[-1]) / h ** 2
    rec.update(k_fd=k_fd, curv=curv)
    sign_ok = abs(k_fd) < 0.005 or np.sign(k['kappa']) == np.sign(k_fd)
    mag_ok = abs(k['kappa'] - k_fd) <= 0.10 * max(abs(k_fd), TAU_K)
    if not (sign_ok and mag_ok):
        rec['excl'] = 'G6'
        return rec
    rec['dG1st'] = fm['rho'] / (1 - k['kappa']) if k['kappa'] < 1 else float('inf')
    a2, b2, c2 = 0.5 * curv, k_fd - 1.0, fm['rho']
    if abs(a2) < 1e-300:
        rec['dG2nd'] = -c2 / b2
    else:
        disc = b2 * b2 - 4 * a2 * c2
        roots = [(-b2 - math.sqrt(disc)) / (2 * a2), (-b2 + math.sqrt(disc)) / (2 * a2)] if disc >= 0 else []
        pos = [r for r in roots if r > 0]
        rec['dG2nd'] = min(pos) if pos else None
    rec['excl'] = None
    rec['abstain'] = abs(k['kappa']) < TAU_K
    return rec


def select(E1, seed):
    """§3 selection rule. E1: list of evaluable records (|kappa| >= tau)."""
    if len(E1) <= SEL_MAX:
        return sorted(r['id'] for r in E1)
    rng = np.random.default_rng(seed)
    neg = sorted(r['id'] for r in E1 if r['kappa'] < 0)
    pos = sorted(r['id'] for r in E1 if r['kappa'] > 0)
    pick = []
    for grp in (neg, pos):
        if len(grp) <= SEL_STRATUM:
            pick += grp
        else:
            pick += sorted(rng.choice(grp, size=SEL_STRATUM, replace=False).tolist())
    return sorted(pick)


# --------------------------------------------------------------------------------------------- stage 2 (§4)
def stage2_point(E, rec):
    lay, G, P = build(E, rec)
    sb = lay.sysd['shed_bus']
    d = E.dispatch(lay, P, G, tol=1e-12)
    x0, refs = d['x'], d['refs']
    dGf = rec['dGf']
    dmax = min(G[sb], 2.0 * dGf)
    t0 = time.perf_counter()
    R = E.reference_margin(lay, x0, refs, G, dmax, 0.01 * dGf, tol=1e-9, alpha_tab='rel')
    t_ref = time.perf_counter() - t0
    R0 = E.reference_margin(lay, x0, refs, G, dmax, 0.01 * dGf, tol=1e-9, alpha_tab=0.0)
    out = dict(id=rec['id'], dGref=R['dGt'], ref_status=R['status'], dGref_exact=R0['dGt'],
               ref_newton_solves=R['newton_solves'], ref_points=R['points'], t_ref=t_ref, dG_max=dmax)
    e = R['dGt'] - dGf
    tie = TIE_K * dGf
    if R['status'].startswith('censored'):
        s = 1
    else:
        s = 1 if e > tie else (-1 if e < -tie else 0)
    out.update(err=e, rel_err=e / dGf, ref_sign=s, fold=R['status'].startswith('newton'))
    # single-step relinearization F(dGf)
    Gk = G.copy()
    Gk[sb] -= dGf
    xs, ok, _, _ = E.newton_fixed_refs(lay, x0, refs, Gk)
    if ok:
        th = float(np.arctan2(x0[lay.ix[f'V{sb}:I']], x0[lay.ix[f'V{sb}:R']]))
        cr = [c for c in E.crossings(lay, E.jac(lay, xs, refs, G), th) if c['rho'] > 0]
        out['F_single'] = (min(c['rho'] for c in cr) - dGf) if cr else float('inf')
    else:
        out['F_single'] = None
    return out


# --------------------------------------------------------------------------------------------- analysis (§5, §6)
def wilson(k, n, z=1.959963984540054):
    if n == 0:
        return (float('nan'), float('nan'))
    p = k / n
    den = 1 + z * z / n
    c = (p + z * z / (2 * n)) / den
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return (c - h, c + h)


def mcnemar_exact(b, c):
    n = b + c
    if n == 0:
        return 1.0
    k = min(b, c)
    p = sum(math.comb(n, i) for i in range(k + 1)) / 2 ** n
    return min(1.0, 2 * p)


def mcc(tp, tn, fp, fn):
    den = math.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    return (tp * tn - fp * fn) / den if den > 0 else 0.0


def evaluate(rows):
    """rows: dicts with kappa, kappa_noc, ref_sign (ties already excluded or 0)."""
    R = [r for r in rows if r['ref_sign'] != 0]
    n = len(R)
    out = dict(n=n, n_ties=sum(1 for r in rows if r['ref_sign'] == 0))
    preds = dict(R1=lambda r: 1 if r['kappa'] > 0 else -1, R2=lambda r: 1, R3=lambda r: -1,
                 R4=lambda r: 1 if r['kappa_noc'] > 0 else -1)
    corr = {k: [f(r) == r['ref_sign'] for r in R] for k, f in preds.items()}
    for k, v in corr.items():
        out[f'acc_{k}'] = sum(v) / n if n else float('nan')
    out['acc_R5_expected'] = 0.5
    out['wilson_R1'] = wilson(sum(corr['R1']), n)
    neg = [r for r in R if r['kappa'] < 0]
    pos = [r for r in R if r['kappa'] > 0]
    out['n_minus'], out['n_plus'] = len(neg), len(pos)
    out['acc_R1_kappa_neg'] = (sum(1 for r in neg if r['ref_sign'] == -1) / len(neg)) if neg else float('nan')
    out['acc_R1_kappa_pos'] = (sum(1 for r in pos if r['ref_sign'] == 1) / len(pos)) if pos else float('nan')
    tp = sum(1 for r in R if r['kappa'] > 0 and r['ref_sign'] == 1)
    tn = sum(1 for r in R if r['kappa'] < 0 and r['ref_sign'] == -1)
    fp = sum(1 for r in R if r['kappa'] > 0 and r['ref_sign'] == -1)
    fn = sum(1 for r in R if r['kappa'] < 0 and r['ref_sign'] == 1)
    out.update(confusion=dict(pred_pos_ref_pos=tp, pred_neg_ref_neg=tn, pred_pos_ref_neg=fp, pred_neg_ref_pos=fn))
    sens = tp / (tp + fn) if tp + fn else float('nan')
    spec = tn / (tn + fp) if tn + fp else float('nan')
    out['balanced_acc_R1'] = 0.5 * (sens + spec) if not (math.isnan(sens) or math.isnan(spec)) else float('nan')
    out['mcc_R1'] = mcc(tp, tn, fp, fn)
    best = 'R2' if out['acc_R2'] >= out['acc_R3'] else 'R3'
    b = sum(1 for i in range(n) if corr['R1'][i] and not corr[best][i])
    c = sum(1 for i in range(n) if not corr['R1'][i] and corr[best][i])
    out.update(best_constant=best, mcnemar_b=b, mcnemar_c=c, mcnemar_p=mcnemar_exact(b, c))
    b4 = sum(1 for i in range(n) if corr['R1'][i] and not corr['R4'][i])
    c4 = sum(1 for i in range(n) if not corr['R1'][i] and corr['R4'][i])
    out.update(R1_vs_R4_b=b4, R1_vs_R4_c=c4, R1_vs_R4_p=mcnemar_exact(b4, c4))
    out['counterexamples_R1'] = sorted(r['id'] for r in R if (1 if r['kappa'] > 0 else -1) != r['ref_sign'])
    return out


def decide(ev, aborted=False):
    if aborted:
        return 1, 'ABORT'
    if ev['n_minus'] < 10 or ev['n_plus'] < 10:
        return 2, 'NOT EVALUABLE - sign diversity insufficient'
    if ev['mcnemar_p'] >= 0.01 or ev['acc_R1'] <= max(ev['acc_R2'], ev['acc_R3']):
        return 3, 'NOT SUPPORTED - no discrimination beyond a constant rule'
    if ev['wilson_R1'][0] >= 0.75 and ev['acc_R1_kappa_neg'] >= 0.75 and ev['acc_R1_kappa_pos'] >= 0.75:
        return 4, 'SUPPORTED - sign kappa discriminates direction in the tested families'
    return 5, 'PARTIAL - discriminates but fails a stratum or the accuracy bound'


def accuracy_stats(rows, seed=SEED_BOOT):
    rng = np.random.default_rng(seed)
    out = {}
    ref = np.array([r['dGref'] for r in rows])
    for key in ('dGf', 'dG1st', 'dG2nd'):
        est = np.array([r[key] if r.get(key) is not None else np.nan for r in rows], dtype=float)
        m = np.isfinite(est)
        e = est[m] - ref[m]
        ae = np.abs(e)
        if len(ae) == 0:
            continue
        boots = [float(np.mean(ae[rng.integers(0, len(ae), len(ae))])) for _ in range(10000)]
        out[key] = dict(n=int(m.sum()), MAE=float(np.mean(ae)), MAE_CI95=(float(np.percentile(boots, 2.5)),
                        float(np.percentile(boots, 97.5))), median_AE=float(np.median(ae)), max_AE=float(np.max(ae)),
                        RMSE=float(np.sqrt(np.mean(e ** 2))), overshoots=int(np.sum(e > 0)),
                        mean_rel_err_pct=float(100 * np.mean(ae / ref[m])))
    return out


# --------------------------------------------------------------------------------------------- synthetic test
def synth():
    ok = True

    def mk(k, s, kn=None):
        return dict(id=f'S{len(rows)}', kappa=k, kappa_noc=k if kn is None else kn, ref_sign=s)

    # case 1: perfect discrimination, 15/15 each sign -> row 4
    rows = []
    for _ in range(15):
        rows.append(mk(0.2, 1))
    for _ in range(15):
        rows.append(mk(-0.2, -1))
    ev = evaluate(rows)
    ok &= decide(ev)[0] == 4 and abs(ev['acc_R1'] - 1) < 1e-12 and ev['mcnemar_b'] == 15 and ev['mcnemar_c'] == 0
    # case 2: kappa negative only 5 -> row 2
    rows = [mk(0.2, 1) for _ in range(20)] + [mk(-0.2, -1) for _ in range(5)]
    ok &= decide(evaluate(rows))[0] == 2
    # case 3: all outcomes +1, kappa both signs -> constant rule better -> row 3
    rows = [mk(0.2, 1) for _ in range(15)] + [mk(-0.2, 1) for _ in range(15)]
    ok &= decide(evaluate(rows))[0] == 3
    # case 4: discriminates (McNemar b = 40, c = 15 vs constant +) but kappa<0 stratum 40/55 = 0.727 < 0.75 -> row 5
    rows = [mk(0.2, 1) for _ in range(40)] + [mk(-0.2, -1) for _ in range(40)] + [mk(-0.2, 1) for _ in range(15)]
    ev = evaluate(rows)
    ok &= decide(ev)[0] == 5 and ev['mcnemar_p'] < 0.01 and ev['wilson_R1'][0] >= 0.75
    # case 4b: weak discrimination (b = 9, c = 6) -> row 3
    rows = [mk(0.2, 1) for _ in range(40)] + [mk(-0.2, -1) for _ in range(9)] + [mk(-0.2, 1) for _ in range(6)]
    ok &= decide(evaluate(rows))[0] == 3
    # statistics: Wilson(8,10) known (0.4902, 0.9433); McNemar exact b=8,c=1 -> p = 0.0390625
    lo, hi = wilson(8, 10)
    ok &= abs(lo - 0.4902) < 1e-3 and abs(hi - 0.9433) < 1e-3
    ok &= abs(mcnemar_exact(8, 1) - 0.0390625) < 1e-12
    ok &= abs(mcc(10, 10, 0, 0) - 1) < 1e-12
    # selection rule: 200 evaluable (50 neg, 150 pos) -> 50 + 60
    E1 = [dict(id=f'X{i:03d}', kappa=(-0.1 if i < 50 else 0.1)) for i in range(200)]
    s = select(E1, 31)
    ok &= len(s) == 110 and sum(1 for i in s if int(i[1:]) < 50) == 50
    # ties excluded
    rows = [mk(0.2, 1) for _ in range(12)] + [mk(-0.2, -1) for _ in range(12)] + [mk(0.2, 0)]
    ev = evaluate(rows)
    ok &= ev['n'] == 24 and ev['n_ties'] == 1
    print('SYNTH', 'PASS' if ok else 'FAIL')
    return bool(ok)


# --------------------------------------------------------------------------------------------- main
def check_only():
    ps, es = sha(PROTOCOL), sha(ENGINE)
    print('protocol', ps, 'OK' if ps == PROTOCOL_SHA else 'MISMATCH')
    print('engine  ', es, 'OK' if es == ENGINE_SHA else 'MISMATCH')
    vs = json.loads(VALIDATION_SUMMARY.read_text(encoding='utf-8')) if VALIDATION_SUMMARY.exists() else None
    vok = bool(vs) and vs['reproduced_evaluable'] == vs['evaluable']
    print('validation', 'OK' if vok else 'NOT PASSED', vs and (vs['reproduced_evaluable'], vs['evaluable']))
    return ps == PROTOCOL_SHA and es == ENGINE_SHA, vok


def run(run_id):
    out = HERE / 'out' / run_id
    if out.exists():
        print('refused: output folder exists (no re-run)')
        return 3
    hashes_ok, val_ok = check_only()
    out.mkdir(parents=True)
    log = open(out / 'log.txt', 'w', encoding='utf-8')

    def L(*a):
        s = ' '.join(str(x) for x in a)
        print(s, flush=True)
        log.write(s + '\n')
        log.flush()

    sys.path.insert(0, str(ENGINE.parent))
    import ind_engine as E  # noqa: E402
    if not hashes_ok or not val_ok:
        res = dict(decision_row=1, verdict='ABORT', reason='hash or validation gate')
        (out / 'result.json').write_text(json.dumps(res, indent=1), encoding='utf-8')
        L('ABORT')
        return 2
    t0 = time.perf_counter()
    specs = sample_A() + sample_B()
    st1 = []
    for sp in specs:
        try:
            rec = stage1_point(E, sp)
        except (np.linalg.LinAlgError, ValueError, ZeroDivisionError, FloatingPointError) as exc:
            rec = dict(sp, excl='error', error=f'{type(exc).__name__}: {exc}')
        st1.append(rec)
        L(rec['id'], rec.get('excl'), rec.get('kappa'))
    p1 = out / 'stage1.json'
    p1.write_text(json.dumps(st1, indent=0, default=float), encoding='utf-8')
    L('stage1 sha256', sha(p1), f'{time.perf_counter() - t0:.0f}s')
    sel = {}
    for system, seed in (('A', SEED_SEL_A), ('B', SEED_SEL_B)):
        E1 = [r for r in st1 if r['system'] == system and r.get('excl') is None and not r['abstain']]
        sel[system] = select(E1, seed)
    p2 = out / 'selection.json'
    p2.write_text(json.dumps(sel, indent=1), encoding='utf-8')
    L('selection sha256', sha(p2), {k: len(v) for k, v in sel.items()})
    byid = {r['id']: r for r in st1}
    st2 = []
    for system in ('A', 'B'):
        for mid in sel[system]:
            try:
                o = stage2_point(E, byid[mid])
            except (np.linalg.LinAlgError, ValueError, ZeroDivisionError, FloatingPointError) as exc:
                o = dict(id=mid, error=f'{type(exc).__name__}: {exc}', ref_sign=None)
            st2.append(o)
            L('ref', mid, o.get('ref_status'), o.get('ref_sign'), o.get('rel_err'))
    (out / 'stage2.json').write_text(json.dumps(st2, indent=0, default=float), encoding='utf-8')
    merged = [dict(byid[o['id']], **o) for o in st2 if o.get('ref_sign') is not None]
    result = dict(protocol_sha256=PROTOCOL_SHA, engine_sha256=ENGINE_SHA, n_candidates=len(st1),
                  abstentions=sum(1 for r in st1 if r.get('excl') is None and r['abstain']),
                  evaluable={s: sum(1 for r in st1 if r['system'] == s and r.get('excl') is None and not r['abstain'])
                             for s in ('A', 'B')},
                  selected={k: len(v) for k, v in sel.items()}, stage2_errors=[o['id'] for o in st2 if 'error' in o])
    result['exclusions'] = {}
    for r in st1:
        k = str(r.get('excl'))
        result['exclusions'][k] = result['exclusions'].get(k, 0) + 1
    for scope, rows in (('pooled', merged), ('A', [r for r in merged if r['system'] == 'A']),
                        ('B', [r for r in merged if r['system'] == 'B'])):
        if not rows:
            result[scope] = dict(n=0)
            continue
        ev = evaluate(rows)
        row, verdict = decide(ev)
        ev.update(decision_row=row, verdict=verdict, accuracy=accuracy_stats(rows))
        result[scope] = ev
    result['runtime_s'] = time.perf_counter() - t0
    result['environment'] = dict(python=sys.version.split()[0], numpy=np.__version__)
    (out / 'result.json').write_text(json.dumps(result, indent=1, default=float), encoding='utf-8')
    L('VERDICT pooled:', result['pooled'].get('verdict'), '| A:', result['A'].get('verdict'), '| B:',
      result['B'].get('verdict'))
    log.close()
    with open(out / 'SHA256SUMS', 'w', encoding='utf-8', newline='\n') as f:
        for p in sorted(out.iterdir()):
            if p.name != 'SHA256SUMS':
                f.write(f'{sha(p)}  {p.name}\n')
    return 0


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument('--check-only', action='store_true')
    g.add_argument('--synth', action='store_true')
    g.add_argument('--run')
    a = ap.parse_args()
    if a.check_only:
        h, v = check_only()
        sys.exit(0 if h else 2)
    if a.synth:
        sys.exit(0 if synth() else 1)
    sys.exit(run(a.run))
