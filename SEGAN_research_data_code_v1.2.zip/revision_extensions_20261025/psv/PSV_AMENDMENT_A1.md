# PSV protocol — Amendment A1 (appended, 2026-10-25)

Applies to `PROSPECTIVE_VALIDATION_PROTOCOL.md` (SHA-256 865d84e5ef6b928b0e8e962056596fb833fcf3f7fe2a0ed2ca72d13a37585f28),
which is not edited. Written **after** (i) the engine validation run had finished (78 of 79 evaluable members passed
every criterion; the one failure is ΔG*_2nd of S3_P0.70_G0.20, relative difference 1.6e-6 against 1e-6) and (ii) the
code audit PSV-D1 (`PSV_kod_denetimi_D1.md`, SHA-256 5dd49d23…38de, verdict REVISE). Written **before** any PSV point
was computed. Hashed and entered in `PROTOKOL_MANIFEST.md` before the run.

**A1.1 Validation gate (§5 row 1).** The validation protocol defines no overall pass threshold. Row 1 is defined as
follows: the validation run completed; its summary (SHA-256 a87eef0757f52c7f56edbcd5a67cda4c5907ae263ce0deee549f65cf315ba14e)
and per-member table `ind_vs_sealed.csv` (SHA-256 fa9f6ae46821ef8087dd3bb5a443edc6342c8af46eaf194d18fdc23abad86cd9)
match these hashes; the number of evaluable members is positive; and **every evaluable member passes every criterion
on the quantities that PSV uses as primary inputs**: ρ, θ_b, α, ΔG*_f, ω*, κ̂, κ_fd and ΔG*_ref. Failures on secondary
quantities (ΔG*_2nd) do not abort; they are listed with member and size in the results, and the PSV ΔG*_2nd results
are read with that tolerance. This definition was chosen after the 78/79 result was seen; it does not use a
count threshold tailored to the result. Applied to the pinned table: 79 of 79 pass the primary criteria.

**A1.2 G3 consistent with the reference definition.** G3 becomes α(x₀) < −max(1e-3, α_tab(x₀)), α_tab = 1e-10·‖A‖₂
at x₀ (the definition used by the reference). α_tab(x₀) is recorded in Stage 1. If Stage 2 nevertheless returns
"unstable at x₀", the member is excluded with label `S2-unstable-x0` and receives no outcome sign.

**A1.3 Continuation step halving.** The frozen engine tries a continuation step up to 8 times (7 halvings), not
"up to 8 halvings". This is the definition used.

**A1.4 Tie between constant rules.** If acc(R2) = acc(R3), McNemar is computed against both and the larger p-value
is used (conservative).

**A1.5 Empty system.** A system with no evaluated member is passed through the decision table and gives row 2.

**A1.6 Execution robustness.** Every point is guarded against any exception (recorded, member excluded with label
`error`); the run writes Stage 2 incrementally, and always writes `exit_code.txt`, a crash record if any, and
`SHA256SUMS` (also on ABORT). The run identifier is fixed to `PSV_20261025_a`. An authorization file
`psv/PSV_yetki_PSV_20261025_a.json` (2026-10-25) is checked before the model code is imported.
`result.json` records the hashes of the protocol, this amendment, the runner, the engine (checked again after import),
the validation summary and table, and the manifest.

**A1.7 Implementation choices made explicit.** Sampling draws one scalar per parameter in table order for each point.
The stratified selection draws the κ̂ < 0 stratum first, then κ̂ > 0, each from its id-sorted list. ΔG*_1st = ∞ if
κ̂ ≥ 1. A Newton failure inside the bisection counts as "not stable" at that point (as the original reference).
`selection.json` contains, for every selected member, κ̂, κ̂_noc, ΔG*_f and ω*.
