# PROSPECTIVE VALIDATION PROTOCOL — sign discrimination and second test system (PSV v1.0)

Status: written and hashed on 2026-10-25 **before any outcome of this extension was computed**. Its SHA-256 and
time stamp are recorded in `revizyon_20261025/PROTOKOL_MANIFEST.md`. The protocol is never edited; changes can only
be appended as dated amendments at the end, and every amendment is hashed before the outcomes it affects.

Nature: an **internally protocol-fixed prospective extension** of the study. It is not an external registration
(no OSF or similar registry). It is separate from, and does not modify, the historical internally protocol-fixed
runs (HDL2 ℱ₁ 2026-10-16, HDL2b ℱ₂ 2026-10-21), their protocols, hashes or verdicts.

Scope: prospective validation extension of 2026-10-25 adding the second test system. This opens option (b) of the branch-narrowing record
`cdl1/HDL2_dal_daraltma_kaydi_v1.md` §3 ("iyimser yönün oluşup oluşmadığı … OPEN"), which had not been chosen then.

## 1. Scientific question

In ℱ₂ every evaluable member had a conservative frozen margin and κ̂ > 0, so sign κ̂ could not be distinguished
from the constant rule "the frozen margin is conservative" (row 8a). The question here is:

**Q.** In operating-point families of physically plausible islanded microgrids in which the first-order coefficient
κ̂ takes **both** signs, does sign κ̂ predict the direction of the frozen-margin error,
sign(ΔG*_ref − ΔG*_f), better than constant-sign rules and an incomplete rule?

Secondary questions: (S1) does a frozen-margin bias of material size occur in a second, structurally different
system? (S2) how accurate are the first-order (ΔG*_1st = ΔG*_f/(1 − κ̂)) and second-order (ΔG*_2nd) estimates there?

## 2. Systems and parameter spaces (fixed now)

All models use the separately coded engine `bagimsiz/ind_engine.py` (validated against the sealed ℱ₂ record under
`PROTOCOL_INDEPENDENT_VALIDATION_v1.0`) with the device equations of S2 Appendix B. Every member has one grid-forming
source (C3), a resistive load at the shedding bus, and active-rectifier CPLs; set-points follow the same dispatch
conditions as the study (slack bus 1∠0, nominal frequency, CPLs at their P_set with zero reactive power).

**System A (original topology, device and network variants).** Two buses as in the study. Varied, independently and
uniformly on the stated scale:

| Parameter | Range | Scale | Rationale |
|---|---|---|---|
| CPL DC-voltage loop, K_iv (K_pv = K_iv/300) | 15 – 2700 A/(V s) | log | span of the four source settings S1–S4 of the study (Bottrell 2014, Table 3.10) |
| CPL PLL gains (k_p, k_i) × s_pll | s_pll 0.25 – 4 | log | PLL bandwidth variation around the author data |
| CPL current loop (k_pc, k_ic) × s_cc | 0.5 – 2 | log | current-loop bandwidth variation |
| GFM virtual inductance l_v | 0.05 – 0.40 pu | lin | typical virtual-impedance range around 0.2 pu |
| GFM virtual resistance r_v | 0 – 0.10 pu | lin | 0 in the author data |
| GFM voltage loop (k_pv, k_iv) × s_v | 0.5 – 2 | log | voltage-loop bandwidth variation |
| Line impedance (r, x) × s_line | 0.5 – 3 | log | feeder length (X/R = 10 as the study) |
| Q–V droop k_q | 0.02 – 0.10 | lin | 0.05 in the author data |
| P–f droop R_p | 0.01 – 0.05 | lin | 0.02 in the author data |
| P_set | 0.45 – 0.75 pu | lin | around ℱ₂ (0.55 – 0.70) |
| G_R | 0.05 – 0.35 pu | lin | around ℱ₂ (0.17 – 0.34) |

**System B (second test system, three-bus radial feeder).** Bus 1: GFM source; line 1 to bus 2: CPL₁ (P₁) and a
non-shed resistive load G₂; line 2 to bus 3 (shedding bus): CPL₂ (P₂) and the sheddable resistive load G_R. Line
shunts b/2 = 0.005 at each line end (bus 2 carries both). Each CPL has its own device parameters. Varied:

| Parameter | Range | Scale |
|---|---|---|
| P₁, P₂ | 0.10 – 0.35, 0.20 – 0.45 pu | lin |
| G₂, G_R | 0 – 0.15, 0.05 – 0.30 pu | lin |
| line 1, line 2 impedance × s | 0.5 – 2.5 each (base r = 0.01, x = 0.1) | log |
| K_iv of CPL₁ and of CPL₂ (independent) | 15 – 2700 A/(V s) | log |
| s_pll of CPL₁ and of CPL₂ (independent) | 0.25 – 4 | log |
| l_v | 0.05 – 0.40 pu | lin |

All other parameters are those of the author data (S2 Table B.1).

**Sampling.** Reproducible pseudo-random uniform sampling (no quasi-random sequence) with numpy `default_rng(20261025)` for A and
`default_rng(20261026)` for B; N_A = 400 and N_B = 400 candidate points, drawn in one call each, in the order of the
tables above. No point is added, removed or re-drawn after the protocol is hashed.

## 3. Stage 1 — predictor stage (no outcome computed)

For every candidate point, in this order (first failure gives the exclusion reason; all reasons are reported):

- **G1 dispatch:** augmented Newton converges, max residual ≤ 1e-12.
- **G2 limits:** all bus voltage magnitudes in [0.88, 1.10] pu; GFM apparent power ≤ 1.0 pu; total load
  P_set (sum) + Σ G|V|² ≤ 1.0 pu.
- **G3 stable pre-shedding point:** spectral abscissa α(x₀) < −1e-3 s⁻¹.
- **G4 frozen crossing:** at least one crossing of the port-admittance eigenvalue loci (ω > 0, f from 0.01 Hz to
  3.16 kHz) with ρ > 0; critical crossing = smallest ρ; require 0 < ΔG*_f ≤ G_R. Points at which the real matrix
  Y_F0(j0) has a real eigenvalue in (0, ΔG*_f] are excluded (static ω = 0 candidate, label G4-ω0, as K5-ω0 of the
  study).
- **G5 simple and transversal:** eigenvalue gap |λ₁ − λ₂| ≥ 1e-6·max(1, |λ|) and |∂_ω Im λ| ≥ 1e-9 at ω*.
- **G6 predictor validity (transfer check, as H-AKT of the study):** κ_fd from equilibria at ±h, h = 1e-3·ΔG*_f;
  pass if (|κ_fd| < 0.005 or sign κ̂ = sign κ_fd) and |κ̂ − κ_fd| ≤ 0.10·max(|κ_fd|, 0.05).

Computed at x₀ for every point passing G1–G6: ΔG*_f, ω*, c, η, κ̂, κ̂_noc = Re η (incomplete rule that ignores the
crossing-frequency term), κ_fd, curvature ρ″ from the same two equilibria, ΔG*_1st and ΔG*_2nd.
**No equilibrium beyond ±h is solved and no state-space eigenvalue along the path is computed in Stage 1.**

**Evaluable set 𝓔 = points passing G1–G6 with |κ̂| ≥ τ_κ = 0.05** (|κ̂| < τ_κ: abstention, reported).

**Selection (fixed rule).** Per system, if 𝓔 has more than 120 members, a stratified subsample is drawn with
`default_rng(31)` (A) and `default_rng(32)` (B): up to 60 members with κ̂ < 0 and up to 60 with κ̂ > 0 (all members
of a stratum if it has fewer than 60). Otherwise all of 𝓔. The selection file (member ids, predictors) is written and
its SHA-256 printed **before** Stage 2 starts. The Stage 1 file is never rewritten.

## 4. Stage 2 — outcomes

For every selected member, the reference re-equilibrated small-signal margin ΔG*_ref: continuation in ΔG with set-points
fixed, step 0.01·ΔG*_f (halving up to 8 times on Newton failure), Newton tolerance 1e-12, upper end
ΔG_max = min(G_R, 2ΔG*_f); first ΔG where the spectral abscissa of A = M⁻¹J (32 states, θ_oc removed; 48 states in B)
reaches −α_tab, α_tab = 1e-10·‖A‖₂ (the definition of the study), bisection to 1e-9 pu. Also reported: the exact
crossing α = 0 and the single-step relinearization F(ΔG*_f).

Outcome: e = ΔG*_ref − ΔG*_f; ref_sign = +1 if e > τ_tie, −1 if e < −τ_tie, 0 (tie) otherwise, τ_tie = 2e-3·ΔG*_f.
Censored (stable up to ΔG_max): ΔG*_ref > ΔG_max ≥ ΔG*_f, ref_sign = +1. Newton failure before a stability loss
(fold): ΔG*_ref := last converged ΔG, labelled. Ties are excluded from accuracy and reported.

## 5. Primary analysis and decision table (pooled A ∪ B, also reported per system)

Rules compared on the same members: R1 sign κ̂ (full-information first-order rule); R2 constant +1 (frozen margin
conservative); R3 constant −1; R4 sign κ̂_noc (Re η only); R5 random ±1 (expected accuracy 0.5, reported only).

Metrics: accuracy with Wilson 95 % interval; accuracy within each predicted-sign stratum (κ̂ > 0, κ̂ < 0); balanced
accuracy; Matthews correlation; exact two-sided McNemar test of R1 against the better of R2/R3 on the same members.

Let n₋ = number of evaluated non-tie members with κ̂ < 0, n₊ likewise with κ̂ > 0.

| Row | Condition (checked in this order) | Verdict |
|---|---|---|
| 1 | engine validation protocol not passed, or a hash/manifest mismatch | ABORT (no verdict) |
| 2 | n₋ < 10 or n₊ < 10 | NOT EVALUABLE — sign diversity insufficient; the directional claim stays narrowed |
| 3 | McNemar p ≥ 0.01 or acc(R1) ≤ max(acc(R2), acc(R3)) | NOT SUPPORTED — no discrimination beyond a constant rule |
| 4 | Wilson lower bound of acc(R1) ≥ 0.75 and both stratum accuracies ≥ 0.75 | SUPPORTED — sign κ̂ discriminates direction in the tested families |
| 5 | otherwise | PARTIAL — discriminates but fails a stratum or the accuracy bound; reported with the failing stratum |

The same table is applied separately to A and to B (secondary). R4 is reported against R1 (does the crossing-frequency
term matter?). All members, counterexamples (members where R1 is wrong) and exclusions are listed.

## 6. Secondary analyses (descriptive)

- System B: distribution of the relative bias e/ΔG*_f; MAE, median and maximum absolute error and overshoot count of
  ΔG*_f, ΔG*_1st, ΔG*_2nd against ΔG*_ref, with bootstrap 95 % intervals (10 000 resamples, `default_rng(41)`).
- Same for A.
- Group structure: none is imposed by design (points are sampled, not gridded); correlations are therefore
  reported pooled, with this stated.

## 7. Interpretation limits (fixed now)

- E2 evidence level (offline computation on average-value models; no current limiting; no hardware).
- A "SUPPORTED" verdict means: in these two model families, under these parameter ranges, sign κ̂ predicted the
  direction of the frozen-margin error better than constant rules. It does not establish the rule for other source
  types, multiple sources, current-limited operation or large-signal shedding.
- A "NOT SUPPORTED" or "NOT EVALUABLE" verdict is reported in the manuscript with the same prominence.
- The quadratic estimate remains a post-hoc estimator in the history of the study; in this extension it is computed
  prospectively under this protocol, and is reported as such.

## 8. Code and execution gate

Runner `psv/psv_run.py` (imports only `ind_engine.py` and numpy). Before the real run: `--check-only` (hashes of this
protocol, the engine and the validation summary), a synthetic test of the decision table and the statistics on
constructed inputs, and a separate pre-run code audit.
Exactly one real run (`--run`), output folder `psv/out/PSV_20261025_a/` with its own SHA256SUMS; no re-run. If the
run crashes, the crash is recorded and a new run identifier is used only after an appended amendment states why.

## 9. Code test performed before this protocol (no family point)

One off-family three-bus point (G = 0.40 at buses 2 and 3, P = 0.05 each): dispatch residual 1.3e-13, α < 0,
determinant identity det(sM − J)_K = det(sM_r − J_rr)·det Y at 10 Hz and 300 Hz to 3e-14. κ̂ and margins were not
computed. No System A variant point was computed.
