# PSV kod denetimi D1 — `psv/psv_run.py`
Tarih: 2026-10-25 · Kod denetimi D1 · Dayanak: PSV protokolü §8.

## §0 Kapsam
- VERIFIED SHA-256: protokol 865d84e5…5f28, motor c45ec8f4…ae6b (ikisi de pinle ve manifest satır 2–3 ile aynı); denetlenen betik **f567cd51…d8b7f3**; doğrulama özeti a87eef07…a14e (pinli değil, bkz. R2); manifest 9af7dd15…32dc.
- Tamamen okunanlar: protokol, betik, motor, doğrulama protokolü, manifest; `validate_all.py` satır 20–143 (yalnız tanımlar için).
- Koşulanlar: `--check-only` (hash OK, "validation NOT PASSED (78, 79)", çıkış 0) ve `--synth` (PASS). `--run` koşulmadı. PSV aile noktası hesaplanmadı. Mühürlü değer görülmedi. Doğrulama özetinden yalnız 78/79 sayısı görüldü (koordinatör mesajı ve check-only çıktısı).

## §1 Özet
| Madde | Konu | Hüküm |
|---|---|---|
| A1 | §2 örnekleme: aralıklar, ölçek, tohum, sıra | PASS (R9 notu) |
| A2 | §3 G1–G6 sırası ve eşikleri | PASS |
| A3 | Değerlendirilebilir küme, çekimser kalma, seçim | PASS (küçük notlar) |
| A4 | §4 referans, eşitlik, sansür, fold | REVISE (R3, R4) |
| A5 | §5 kurallar, metrikler, McNemar, Wilson, tablo | REVISE (R5, R6) |
| A6 | §6 bootstrap | PASS, eksik raporlama var (öneri) |
| B | Körleme ve seçim mührü | PASS |
| C | Motorun doğruluğu | PASS (R3 dışında) |
| D | Sağlamlık ve mühür | REVISE (R1, R7, R8) |
| E | Sentetik test | REVISE (R10) |

**Genel hüküm: REVISE.**

## Doğru bulunanlar (kanıtlı)
- Örnekleme sırası ve aralıklar tablolarla birebir aynı (psv_run.py:47–61). K_pv = K_iv/300 ve pu dönüşümü motordaki S3 tabanıyla tutarlı (65–71; ind_engine.py:46–47). Sistem B'de şöntler [0.005, 0.010, 0.005] (88). Durum sayıları 32 (A) ve 48 (B), protokoldeki sayılarla tutuyor.
- G1–G6 protokoldeki sırayla uygulanıyor (104–163). Eşikler doğru: 1e-12; [0.88, 1.10]; 1.0; −1e-3; 0 < ρ ≤ G_R; G4-ω0; boşluk 1e-6, eğim 1e-9; G6 eşikleri 0.005, 0.10 ve 0.05. Frekans ızgarası 0.01 Hz–3.16 kHz (ind_engine.py:441).
- İşaretler doğru:
  - J ξ = ∂f/∂G (ind_engine.py:504), ΔG > 0 yük atma yönü.
  - Atılan yük Y → Y − ΔG·I olarak giriyor; çünkü K = sM − J'de port köşegeninde +G var (413).
  - κ = Re η − c·Im η, örtük fonksiyon türevine eşit (516–517).
  - κ_fd ve ρ″ ±h dengelerinden doğru işaretle hesaplanıyor (psv_run.py:148–157). ρ, J(x(ΔG), G) ile G sabit tutularak hesaplanıyor; sabit nokta tanımıyla tutarlı.
  - ΔG*_2nd formülü `validate_all.second_order` ile aynı.
- Çerçeve döndürmesi R(−θ)·Y·Rᵀ dik bir benzerlik dönüşümü; özdeğerleri ve η'yı değiştirmez, yani işaret yanlılığı yaratamaz. h pu cinsinden; port satırları M'ye bölünmüyor, birimler tutarlı.
- Karar tablosunun sırası ve koşulları 1→5 (290–299). Wilson ve kesin McNemar formülleri doğru; değerler elle kontrol edildi.
- Körleme: Aşama 1'de durum uzayı özdeğerleri yalnız x₀'da (G3) hesaplanıyor. Port özdeğerleri yalnız x₀'da ve ±h'de; ±h ötesinde denge çözülmüyor. Tek-adım yeniden doğrusallaştırma Aşama 2'de (215–224). `stage1.json` ve `selection.json` Aşama 2'den önce yazılıp hash'leri basılıyor (409–418).
- Yeniden koşu reddi doğru: klasör varsa çıkış 3 (379–381).

## Bulgular
**F1 (esaslı) — Doğrulama kapısı yazılı bir ölçüte dayanmıyor; şu hâliyle koşu ABORT verir.**
- Kanıt: psv_run.py:372 `reproduced_evaluable == evaluable` istiyor. Doğrulama protokolü §3 ise genel bir geçme eşiği tanımlamıyor; yalnız "count of reproduced members" raporlanacağını söylüyor. PSV §5 satır 1'deki "not passed" bu yüzden tanımsız.
- Bu ölçüt yazarın protokol dışı bir seçimi. Literal uygulanırsa 78/79 ile satır 1 (ABORT) çıkar.
- Ölçütü 78/79 görüldükten sonra gevşetmek post-hoc olur.
- Ayrıca: `evaluable > 0` denetlenmiyor (0 == 0 geçer); özet dosyasının hash'i pinli değil, oysa §8 bunu istiyor (bkz. F2); `--check-only` doğrulama başarısızken de 0 döndürüyor.

**F2 (yüksek) — Manifest ve özet hash'i denetlenmiyor.** §5 satır 1 "hash/manifest mismatch" ve §8 "hashes of … the validation summary" diyor. Betik ise ne manifesti ne özetin SHA'sını doğruluyor (367–374).

**F3 (yüksek) — G3 ile referans tanımı tutarsız; işaret yanlılığı riski taşıyor.**
- G3 α₀ < −1e-3 istiyor. Referans ise ilk α ≥ −α_tab noktasını arıyor; α_tab = 1e-10·‖A‖₂ (ind_engine.py:570–572).
- INFERENCE: Parametre büyüklüklerine göre ‖A‖₂ ~1e8–1e9 mertebesinde. CPL akım satırında kpc·kiv/M ≈ 4e8, K_iv = 2700 için. Buna göre α_tab ~1e-2–1e-1 s⁻¹, yani 1e-3'ten büyük olabilir.
- α₀ ∈ (−α_tab, −1e-3) olan bir nokta G1–G6'yı geçer. Sonra `reference_margin` 'unstable at x0' ve dGt = 0 döndürür (585–586). Betik buna sessizce ref_sign = −1 atar (psv_run.py:208–213).
- Bu, "frozen optimistic" yönüne yapay bir sonuç ekler. Protokolde bu durum için kural yok.

**F4 (orta) — Yarılama sayısı protokolle uyuşmuyor.** Protokol "halving up to 8 times" diyor. Motor 8 deneme yapıyor, bu da 7 yarılama demek (ind_engine.py:590–594). Sonuç: fold etiketi protokoldekinden erken düşebilir. Motor dondurulmuş olduğu için düzeltme kodda değil, ek metinde yapılmalı.

**F5 (orta) — En iyi sabit kuralda eşitlik.** R2 ve R3'ün doğruluğu eşit olduğunda betik R2'yi seçiyor (279). Bu durumda McNemar b/c ve p değeri seçime göre değişir ve protokol buna kural koymuyor.

**F6 (orta) — Boş kapsamda hüküm yok.** Bir sistemde hiç üye yoksa `dict(n=0)` yazılıyor ve hüküm üretilmiyor (442–444). Protokole göre n₋ = 0 < 10 olduğundan bu durum satır 2 (NOT EVALUABLE) olmalı.

**F7 (yüksek) — Tek koşu yakalanmamış bir istisnayla mühürsüz kalabilir.**
- Nokta başına yalnız 4 istisna türü yakalanıyor (405, 425). TypeError, KeyError, RuntimeError ve benzerleri koşuyu durdurur.
- Analiz ve yazma aşaması (440–458) hiç korunmuyor.
- ABORT yolunda (394–398) log kapatılmıyor ve SHA256SUMS yazılmıyor.
- `stage2.json` ancak en sonda yazılıyor; saatler süren bir koşu çökerse sonuçlar kaybolur.
- exit_code ve stderr kaydı yok.

**F8 (orta) — Girdi pinleri sonuca yazılmıyor.** `result.json`'da betiğin kendi SHA'sı, özetin SHA'sı ve manifestin SHA'sı yok. run_id protokoldeki `PSV_20261025_a` değerine zorlanmıyor. tek-kosu-kapisi §1/§4'ün istediği yetki JSON doğrulaması da yok; proje kapısı gereği.

**F9 (küçük) — Yazar seçimleri belgelenmemiş.** Belgelenmesi gereken seçimler:
- "One call each" protokoldeki gibi değil, nokta-öncelikli skaler çekimlerle uygulanmış.
- Seçim, kimlik sıralı listeden önce neg sonra pos olarak çekiliyor.
- Hata alan üyeler sessizce dışlanıyor.
- κ ≥ 1 ise dG1st = inf.
- Bisection sırasında Newton başarısız olursa hi = mid alınıyor; durum 'alpha' olarak kalıyor.
- `selection.json` protokolün istediği öngörücüleri içermiyor.

**F10 (orta) — Sentetik test eksik.** Satır 1 (ABORT), n = 10 / 0.75 / p = 0.01 sınırları, n₊ < 10, R2 = R3 eşitliği, R4 ≠ R1, MCC/BA değerleri, işaret atama (tie/sansür/fold/'unstable at x0'), `accuracy_stats`, boş kapsam, re-run reddi test edilmiyor. Test ayrıca hangi durumun kaldığını raporlamıyor.

## Doğrulama kapısı hakkında (koordinatör sorusu)
`reproduced_evaluable == evaluable` kuralı uygun değil. Sebepleri:
- Protokolde dayanağı yok.
- Hata büyüklüğünden ve hatanın PSV'deki rolünden bağımsız.
- Literal uygulandığında 78/79'u ABORT'a çeviriyor. Tek başarısızlık ikincil, betimsel bir nicelikte (ΔG*_2nd, §6): 1.6e-6'ya karşı 1e-6, karar tablosuna girmiyor.

Önerilen ifade, numaralı bir ek metin (amendment) olarak:
1. Ek metin, koşudan önce hash'lenip manifeste yazılır. 78/79'un görüldükten sonra yazıldığı açıkça beyan edilir.
2. Kapı şöyle tanımlanır:
   - doğrulama koşusu tamamlanmış ve özet SHA'sı pinli;
   - evaluable > 0;
   - birincil girdilerde (ρ, θ_b, α, ΔG*_f, ω*, κ̂, κ_fd, ΔG*_t) her değerlendirilebilir üye geçiyor;
   - ikincil niceliklerdeki başarısızlıklar üye kimliği ve büyüklüğüyle listeleniyor ve §6 raporunda gösteriliyor.
3. Bu ölçütü sınayabilmek için üye bazında kriter ayrıntısı gerekir. Mevcut özet sayıdan ibaret; `ind_vs_sealed.csv` okunmalı, onun da hash'i pinlenmeli.

Bunun yerine "≥78/79" gibi sayıya göre biçilmiş bir eşik konulmamalı.

## Düzeltme listesi (zorunlu)
| ID | Öncelik | Yer | Düzeltme |
|---|---|---|---|
| R1 | esaslı | psv_run.py:367–374, 394; ek metin | Doğrulama kapısını yukarıdaki biçimde hash'li bir ek metinle tanımlayın ve betiğe uygulayın. evaluable > 0 koşulunu ekleyin. Doğrulama başarısızsa `--check-only` ≠ 0 dönsün. |
| R2 | yüksek | 367–374 | Özet ve CSV SHA'larını pinleyin. Manifest satırlarını (protokol, motor) denetleyin. |
| R3 | yüksek | stage2_point 208–213; ek metin | 'unstable at x0' (ve α_tab ile ilgili erken kayıp) için kural yazın. Ya ayrı bir etiketle dışlayıp raporlayın ya da G3'ü α₀ < −max(1e-3, α_tab) yapın. Ek metin koşudan önce hash'lenmeli. Her durumda α_tab Aşama 1 kaydına yazılsın. |
| R4 | orta | ek metin | Motorun 8 deneme / 7 yarılama semantiğini ek metinde beyan edin. Motor değişmez. |
| R5 | orta | 279; ek metin | Eşitlik durumunda muhafazakâr kural koyun (iki sabitin büyük p'si). Kuralı beyan edin. |
| R6 | orta | 442–444 | Boş kapsam `evaluate`/`decide`'dan geçsin ve satır 2 versin. |
| R7 | yüksek | 400–458 | Nokta düzeyinde `except Exception` kullanın, etiketi 'error' olsun. Tüm koşuyu try/finally ile sarın; çökme kaydı, exit_code.txt ve her yolda SHA256SUMS yazılsın. Aşama 2 sonuçları artımlı yazılsın. ABORT yolu da mühürlensin. |
| R8 | orta | 431 | Betik, motor (import sonrası `E.__file__`), özet ve manifest SHA'larını sonuca yazın. run_id'yi doğrulayın. Yetki JSON'u kontrolü ekleyin ya da yokluğunu karar günlüğünde gerekçelendirin. |
| R9 | küçük | docstring | F9'daki seçimleri PSV-B1-a… olarak belgeleyin. `selection.json`'a κ̂ ve κ̂_noc ekleyin. |
| R10 | orta | synth() | F10'daki durumları elle kurulmuş beklentilerle ekleyin. İşaret atamayı saf bir fonksiyona çıkarıp test edin. Her test için PASS/FAIL basın. |

Öneriler (zorunlu değil):
- Wilson aralığını tüm kurallar için verin.
- e/ΔG*_f dağılımı için yüzdelikleri ve median/max bootstrap aralıklarını ekleyin.
- `accuracy_stats`'ta sansürlü ve fold üyeleri işaretleyin.
- `rho_at` ve secant için yakınsama bayrağı ekleyin.
- `reference_margin` R0 çağrısını ayrı bir try bloğuna alın.

## Çözülmemiş engeller
R1, R3 ve R7. R1 ve R3 için hash'li ek metin şart. Bu üçü kapanmadan gerçek koşu yapılmamalı.

## Genel hüküm: **REVISE**
Gerekçe: F1 esaslı. Mevcut kapı tanımsız bir ölçüte dayanıyor ve koşuyu ABORT'a götürür; düzeltmesi post-hoc olmamak için beyanlı bir ek metin gerektiriyor. F3, yanlılık üretebilecek tanımsız bir sonuç dalı. F7 tek koşunun mühürsüz kalma riski.

