# PSV sonuç raporu v1 (tek koşu PSV_20261025_a)

Tarih: 2026-10-25 · Koşu: `psv/out/PSV_20261025_a/` (SHA256SUMS içinde; exit 0; 402 s).
Dayanak: protokol 865d84e5…5f28, ek A1 7bd97a73…be9a, koşucu v2 186e4fe6…8f08, motor c45ec8f4…ae6b, denetimler
D1 (REVISE) ve D2 (ACCEPT_FOR_RUN). Kanıt düzeyi E2. Yeniden koşu yok.

## 1. Hüküm (karar tablosu, harfiyen)

**Havuzlanmış (A ∪ B): satır 2 — NOT EVALUABLE, işaret çeşitliliği yetersiz.** n₋ = 1 < 10.
A: satır 2 (n₋ = 0). B: satır 2 (n₋ = 1). Satır 1 (ABORT) eşleşmedi: bütün hash'ler, doğrulama kapısı (79/79 birincil)
ve yetki OK.

Protokol §7 gereği: yönsel iddia daraltılmış kalır; sign κ̂'nın sabit kurallardan ayırt edildiği gösterilemedi.

## 2. Sayılar

| | A (2 bara, cihaz/ağ varyantları) | B (3 bara radyal) | Toplam |
|---|---|---|---|
| Aday | 400 | 400 | 800 |
| G2 (sınır) / G3 (x₀ kararsız) / G4 (kesişim yok ya da ΔG*_f > G_R) | 24 / 93 / 250 | 37 / 60 / 234 | 61 / 153 / 484 |
| G5, G6, G4-ω0, hata | 0 | 0 | 0 |
| Çekimser (\|κ̂\| < 0.05) | 2 | 5 | 7 |
| Değerlendirilen (𝓔) | 31 | 64 | 95 |
| κ̂ < 0 | 0 | 1 (B202) | 1 |
| Sansürlü (ΔG_max'a kadar kararlı) | 5 | 13 | 18 |

**İşaret uyuşması (non-tie 95):** R1 sign κ̂ 95/95 (Wilson %95 [0.961, 1.000]); R2 sabit (+) 94/95; R3 sabit (−) 1/95;
R4 sign Re η 83/95. R1 – R2 McNemar b = 1, c = 0, p = 1.0. R1 – R4 b = 12, c = 0, p = 0.00049.
Karşı örnek (R1 yanlış): yok. Beraberlik: yok.

**Tek iyimser üye B202:** κ̂ = −0.0550, Re η = −0.0861, c = 0.138; ΔG*_f = 0.1712, ΔG*_ref = 0.1641
(dondurulmuş pay %4.15 iyimser); tek adım yeniden doğrusallaştırma F = −0.0073 (iyimser, uyuşuyor).

**Tek adım yeniden doğrusallaştırma:** 93/93 işaret uyuşması (2 üyede F hesaplanamadı: Newton).

## 3. İkincil analizler (§6, betimsel)

Sansürsüz 77 üyede göreli hata (ΔG*_ref − ΔG*_f)/ΔG*_f ∈ [−0.042, 0.903], medyan 0.236: dondurulmuş pay yanlılığı
ikinci sistemde de büyük ve neredeyse her zaman muhafazakâr.

| Tahmin edici (n = 95) | MAE (pu) [%95 GA] | Medyan MAE | Maks | Aşma |
|---|---|---|---|---|
| ΔG*_f | 0.0237 [0.0201, 0.0275] | 0.0192 | 0.0965 | 1 |
| ΔG*_1st | 0.0240 [0.0160, 0.0333] (n = 94; κ̂ ≥ 1 olan 1 üye ∞) | 0.0051 | 0.183 | 93 |
| ΔG*_2nd | 0.0057 [0.0034, 0.0085] | 0.0006 | 0.0914 | 28 |

Not (D2-N3 ve N2): sansürlü üyelerde ΔG*_ref = ΔG_max bir alt sınırdır; bu üyelerde tahmin edici hataları
yanlıdır (−%50 değerleri ΔG_max = 2ΔG*_f'den gelir). İkincil doğrulama başarısızlığı (S3_P0.70_G0.20, dG2nd
1.6e-6) yalnız log.txt'de; ΔG*_2nd sonuçları bu toleransla okunur.

## 4. Okuma (önceden yazılmış sınırlar içinde)

- Yönsel ayırt etme **sınanamadı**: iyimser yön 95 üyenin yalnız birinde oluştu. Gözlem: κ̂ o üyede doğru (post hoc
  değil, ön-kayıtlı kümede; ama n₋ = 1 kanıt sayılmaz).
- **Ön-kayıtlı ikincil karşılaştırma R1–R4** (protokol §5 son paragraf): kesişim frekansı terimini atan Re η kuralı
  12 üyede yanlış yön verdi, tam κ̂ hiçbirinde; p = 0.00049. Lemma 1'deki −c·Im η teriminin işaret için gerekli
  olduğu ileriye dönük olarak desteklendi (bu iki model ailesinde).
- Dondurulmuş pay yanlılığı ikinci, yapısal olarak farklı sistemde de var (S1 sorusu: evet; medyan %24).
- ℱ₂'deki "ΔG*_2nd 79/79 referansın altında" gözlemi **genellenmedi**: 28/95 aşma. İkinci mertebe tahmin daha doğru
  (MAE ~%76 düşük) ama muhafazakâr değildir.
- ΔG*_1st 93/94 aşıyor: teğet tahmin bir sınır olarak kullanılamaz (ℱ₂ ile aynı).

## 5. Makaleye etkisi

Bölüm 6.9 olarak raporlanır; özet ve sonuç "NOT EVALUABLE" hükmünü açıkça söyler. "Sign rule validated" denmez.
Yeni katkı ifadeleri: (i) ikinci sistemde yanlılığın varlığı; (ii) c teriminin gerekli olduğu (R1–R4); (iii) ikinci
mertebe tahminin doğru ama muhafazakâr olmadığı. Sınırlamalar: iki model ailesi, aynı cihaz modelleri, akım
sınırlaması yok, iyimser rejim bu aralıklarda nadir (1/95).
