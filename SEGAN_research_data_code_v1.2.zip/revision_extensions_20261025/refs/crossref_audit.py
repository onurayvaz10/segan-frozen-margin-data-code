"""Check every DOI of the reference list against Crossref metadata (stdlib only).

usage: python -I crossref_audit.py <references.csv> <out.csv> <cache.json>
"""
import csv, json, re, sys, time, unicodedata, urllib.parse, urllib.request
from pathlib import Path

src, out, cache_p = sys.argv[1:4]
cache = json.loads(Path(cache_p).read_text(encoding="utf-8")) if Path(cache_p).exists() else {}
UA = "SEGAN-reference-audit/1.0 (mailto:onurayvaz10@icloud.com)"


def get(url):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode("utf-8"))


def norm(s):
    s = unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", " ", s).strip()


def crossref(doi):
    if doi in cache:
        return cache[doi]
    try:
        m = get("https://api.crossref.org/works/" + urllib.parse.quote(doi))["message"]
    except Exception as e:  # noqa: BLE001
        m = {"error": str(e)}
    cache[doi] = m
    time.sleep(0.3)
    return m


def search(title):
    key = "search:" + title
    if key in cache:
        return cache[key]
    q = urllib.parse.urlencode({"query.bibliographic": title, "rows": 5})
    try:
        items = get("https://api.crossref.org/works?" + q)["message"]["items"]
    except Exception as e:  # noqa: BLE001
        items = [{"error": str(e)}]
    cache[key] = items
    time.sleep(0.3)
    return items


def year_of(m):
    for k in ("published-print", "published-online", "issued", "posted"):
        p = m.get(k, {}).get("date-parts", [[None]])[0]
        if p and p[0]:
            return str(p[0])
    return ""


rows = list(csv.DictReader(open(src, encoding="utf-8-sig")))
res = []
for r in rows:
    doi = r["doi"].strip()
    rec = dict(no=r["no"], type=r["type"], ms_authors=r["authors"], ms_title=r["title"], ms_venue=r["venue"],
               ms_volume=r["volume"], ms_number=r["number"], ms_pages=r["pages"], ms_year=r["year"], ms_doi=doi)
    flags = []
    m = crossref(doi) if doi and not doi.startswith("10.48550") else None
    if doi.startswith("10.48550"):
        flags.append("arXiv DOI (DataCite, not in Crossref)")
    if m is not None and "error" not in m:
        t = (m.get("title") or [""])[0]
        cont = (m.get("container-title") or [""])[0]
        fam = [a.get("family", "") for a in m.get("author", [])]
        rec.update(cr_title=t, cr_venue=cont, cr_year=year_of(m), cr_volume=m.get("volume", ""),
                   cr_issue=m.get("issue", ""), cr_pages=m.get("page", "") or m.get("article-number", ""),
                   cr_type=m.get("type", ""), cr_first_author=fam[0] if fam else "", cr_n_authors=len(fam))
        nt, ct = norm(r["title"]), norm(t)
        rec["title_match"] = "yes" if nt == ct or nt in ct or ct in nt else "CHECK"
        if rec["cr_year"] and r["year"] and rec["cr_year"] != r["year"]:
            flags.append(f"year {r['year']} vs Crossref {rec['cr_year']}")
        if rec["cr_volume"] and r["volume"] and rec["cr_volume"] != r["volume"]:
            flags.append(f"volume {r['volume']} vs {rec['cr_volume']}")
        pg = rec["cr_pages"].replace("-", "–")
        if pg and r["pages"] and pg.split("–")[0] != r["pages"].split("–")[0]:
            flags.append(f"pages {r['pages']} vs {rec['cr_pages']}")
        ms_first = norm(r["authors"].split(",")[0].split()[-1])
        if fam and ms_first and ms_first != norm(fam[0]):
            flags.append(f"first author {ms_first} vs {fam[0]}")
        if fam and len(fam) != len([a for a in r["authors"].split(",") if a.strip()]):
            flags.append(f"author count {len(r['authors'].split(','))} vs {len(fam)}")
    elif m is not None:
        rec["title_match"] = "DOI NOT RESOLVED"
        flags.append("Crossref: " + m["error"][:80])
    # preprints and DOI-less items: search for a published version by title
    if r["type"] in ("preprint", "patent") or not doi or doi.startswith("10.48550"):
        hits = search(r["title"])
        best = []
        for h in hits:
            if "error" in h:
                continue
            ht = (h.get("title") or [""])[0]
            if norm(ht) == norm(r["title"]) or (len(norm(r["title"])) > 30 and norm(r["title"])[:60] in norm(ht)):
                best.append(f"{h.get('DOI')} | {(h.get('container-title') or [''])[0]} | {year_of(h)} | "
                            f"vol {h.get('volume', '')} | {h.get('page', '') or h.get('article-number', '')}")
        rec["published_version_search"] = " || ".join(best) if best else "no exact-title match in Crossref"
    rec["flags"] = "; ".join(flags)
    res.append(rec)
    Path(cache_p).write_text(json.dumps(cache, ensure_ascii=False, indent=0), encoding="utf-8")

cols = sorted({k for r in res for k in r}, key=lambda k: list(res[0]).index(k) if k in res[0] else 99)
with open(out, "w", encoding="utf-8-sig", newline="") as f:
    w = csv.DictWriter(f, fieldnames=cols)
    w.writeheader()
    w.writerows(res)
for r in res:
    if r.get("flags") or r.get("title_match") not in (None, "yes") or r.get("published_version_search", "").startswith("10."):
        print(f"[{r['no']}] match={r.get('title_match')} flags={r.get('flags')} pub={r.get('published_version_search', '')[:200]}")
print("done", len(res))
