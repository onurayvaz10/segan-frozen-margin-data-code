# Kaynak denetimi bulguları (2026-10-25, Crossref API + doi.org handle)

Yöntem: `crossref_audit.py` her DOI'yi api.crossref.org/works/<doi> ile çekti; arXiv/patent/DOI'siz kayıtlar için
başlıkla Crossref'te yayımlanmış sürüm arandı. Ham çıktı `crossref_raw.csv`, önbellek `crossref_cache.json`.

| Ref | Bulgu | Eylem |
|---|---|---|
| [24] | Yayımlandı: Electric Power Systems Research 263 (Şubat 2027) 113583, DOI 10.1016/j.epsr.2026.113583. Crossref yazar sırası: Gorbunov, Chen, Ma, Verbič, Vorobev (makalede: Gorbunov, Chen, Vorobev, Ma, Verbič; yıl 2026) | künye yayıncı verisine göre güncellenir |
| [25] | Yayımlandı: Electric Power Systems Research 262 (Ocak 2027) 113570, DOI 10.1016/j.epsr.2026.113570; yazarlar Baron-Prada, Anta, Dörfler (makalede "Presented at PSCC 2026; arXiv") | künye güncellenir |
| [22] | Crossref başlığı "Multivariable-PI-Based dq Current Control…"; makalede "dq" düşmüş (çift boşluk) | başlık düzeltilir |
| [2] | DOI 10.25560/24658 Crossref'te yok; doi.org handle → spiral.imperial.ac.uk/handle/10044/1/24658 | VERIFIED (DOI çözümleniyor) |
| [13] | DOI 10.3321/j.issn:1000-1026.2009.10.001 Crossref'te yok; doi.org handle → Wanfang | VERIFIED (DOI çözümleniyor) |
| [8] | başlık farkı yalnız HTML varlığı (&amp;) | sorun yok |
| [36] | sayfa 1–8 (Crossref 01-08) | sorun yok |
| [43] | Crossref family alanında tam ad | sorun yok |
| [26], [31], [32], [47] | Crossref'te yayımlanmış sürüm yok (arXiv) | arXiv künyesi korunur |
| diğer 35 DOI | başlık, yıl, cilt, ilk sayfa ve ilk yazar Crossref ile eşleşti | VERIFIED |

İlgili yeni literatür adayı (değerlendirilecek): Baron-Prada, Anta, Dörfler, "On decentralized stability conditions
using scaled relative graphs", IEEE Control Systems Letters 9 (2025), DOI 10.1109/LCSYS.2025.3577230.
