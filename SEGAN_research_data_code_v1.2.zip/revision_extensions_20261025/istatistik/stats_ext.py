"""Post-hoc statistical strengthening on the sealed F2 records (revision of 25 October 2026; numpy only).

Population: the 79 evaluable members of F2, six P_set groups of 12-15 members that differ only in G_R. Members are
NOT independent systems; every interval below is reported both member-level and cluster-level (resampling groups).

usage: python -I stats_ext.py <posthoc_member_predictions.csv> <out_dir>
"""
import csv, json, math, sys
from pathlib import Path

import numpy as np

src, out = sys.argv[1], Path(sys.argv[2])
out.mkdir(parents=True, exist_ok=True)
R = list(csv.DictReader(open(src, encoding='utf-8-sig')))
P = np.array([float(r['P_akt']) for r in R])
dGf = np.array([float(r['dGf']) for r in R])
dGt = np.array([float(r['dGt_recorded']) for r in R])
kap = np.array([float(r['kappa']) for r in R])
kfd = np.array([float(r['kappa_fd']) for r in R])
d2 = np.array([float(r['dG_second_order']) for r in R])
groups = sorted(set(P))
gid = np.array([groups.index(p) for p in P])
rng = np.random.default_rng(20261025)
B = 20000


def pearson(a, b):
    a, b = a - a.mean(), b - b.mean()
    return float((a @ b) / math.sqrt((a @ a) * (b @ b)))


def boot_member(fn, n=B):
    idx = rng.integers(0, len(R), (n, len(R)))
    return np.array([fn(i) for i in idx])


def boot_cluster(fn, n=B):
    vals = []
    for _ in range(n):
        gs = rng.integers(0, len(groups), len(groups))
        idx = np.concatenate([np.nonzero(gid == g)[0] for g in gs])
        vals.append(fn(idx))
    return np.array(vals)


def ci(v):
    v = v[np.isfinite(v)]
    return [float(np.percentile(v, 2.5)), float(np.percentile(v, 97.5))]


res = dict(population='F2 evaluable members, n = 79, 6 P_set groups (post hoc)', n=len(R),
           group_sizes={f'{g:.3f}': int((gid == i).sum()) for i, g in enumerate(groups)})

# ---------------- association of predicted and recorded relative shift ----------------
x = kap / (1 - kap)                       # first-order predicted relative shift
y = (dGt - dGf) / dGf                     # recorded relative shift
res['pooled_pearson'] = pearson(x, y)
res['pooled_pearson_CI_member'] = ci(boot_member(lambda i: pearson(x[i], y[i])))
res['pooled_pearson_CI_cluster'] = ci(boot_cluster(lambda i: pearson(x[i], y[i]) if len(set(gid[i])) > 2 else np.nan))
xm = np.array([x[gid == g].mean() for g in range(len(groups))])
ym = np.array([y[gid == g].mean() for g in range(len(groups))])
res['between_group_pearson_of_means'] = pearson(xm, ym)
xc = x - xm[gid]
yc = y - ym[gid]
res['group_centred_pearson'] = pearson(xc, yc)
res['group_centred_pearson_CI_member'] = ci(boot_member(lambda i: pearson(xc[i], yc[i])))
# within-group (fixed-effects) slope and between-group slope
bw = float((xc @ yc) / (xc @ xc))
bb = float(np.polyfit(xm, ym, 1)[0])
res['within_group_slope'] = bw
res['between_group_slope'] = bb
res['within_group_slope_CI_cluster'] = ci(boot_cluster(
    lambda i: float(((x[i] - np.array([x[i][gid[i] == g].mean() for g in gid[i]])) @
                     (y[i] - np.array([y[i][gid[i] == g].mean() for g in gid[i]])))
                    / np.sum((x[i] - np.array([x[i][gid[i] == g].mean() for g in gid[i]])) ** 2)), n=2000))
ss_tot = float(np.sum((y - y.mean()) ** 2))
ss_between = float(np.sum([(gid == g).sum() * (ym[g] - y.mean()) ** 2 for g in range(len(groups))]))
res['eta_squared_groups'] = ss_between / ss_tot
res['within_group'] = {}
for g, pv in enumerate(groups):
    m = gid == g
    rk = lambda v: np.argsort(np.argsort(v)).astype(float)  # noqa: E731
    res['within_group'][f'{pv:.3f}'] = dict(n=int(m.sum()), pearson=pearson(x[m], y[m]),
                                            spearman=pearson(rk(x[m]), rk(y[m])))


# ---------------- estimator accuracy (second-order vs first-order vs frozen) ----------------
def acc(est):
    e = est - dGt
    ae = np.abs(e)
    return dict(MAE=float(ae.mean()), median_AE=float(np.median(ae)), max_AE=float(ae.max()),
                RMSE=float(np.sqrt(np.mean(e ** 2))), mean_rel_err_pct=float(100 * np.mean(ae / dGt)),
                overshoots=int(np.sum(e > 0)), n=len(e))


est = dict(frozen=dGf, first_order=dGf / (1 - kap), first_order_fd=dGf / (1 - kfd), second_order=d2)
res['accuracy'] = {k: acc(v) for k, v in est.items()}
for k, v in est.items():
    ae = np.abs(v - dGt)
    res['accuracy'][k]['MAE_CI_member'] = ci(boot_member(lambda i: ae[i].mean()))
    res['accuracy'][k]['MAE_CI_cluster'] = ci(boot_cluster(lambda i: ae[i].mean()))
ae2, ae0, ae1 = np.abs(d2 - dGt), np.abs(dGf - dGt), np.abs(dGf / (1 - kap) - dGt)
red = lambda i: 1 - ae2[i].mean() / ae0[i].mean()  # noqa: E731
res['MAE_reduction_second_vs_frozen'] = float(1 - ae2.mean() / ae0.mean())
res['MAE_reduction_second_vs_frozen_CI_member'] = ci(boot_member(red))
res['MAE_reduction_second_vs_frozen_CI_cluster'] = ci(boot_cluster(red))
res['MAE_reduction_second_vs_first'] = float(1 - ae2.mean() / ae1.mean())
res['MAE_reduction_second_vs_first_CI_cluster'] = ci(boot_cluster(lambda i: 1 - ae2[i].mean() / ae1[i].mean()))
res['second_order_worse_than_frozen_members'] = int(np.sum(ae2 > ae0))
res['second_order_worse_than_first_members'] = int(np.sum(ae2 > ae1))
res['groupwise_accuracy'] = {}
for g, pv in enumerate(groups):
    m = gid == g
    res['groupwise_accuracy'][f'{pv:.3f}'] = {k: dict(MAE=float(np.abs(v[m] - dGt[m]).mean()),
                                                      max_AE=float(np.abs(v[m] - dGt[m]).max()),
                                                      overshoots=int(np.sum(v[m] - dGt[m] > 0)))
                                              for k, v in est.items()}
res['largest_second_order_errors'] = sorted(
    [dict(id=R[i]['id'], abs_err=float(ae2[i]), rel_err=float(ae2[i] / dGt[i])) for i in range(len(R))],
    key=lambda d: -d['abs_err'])[:5]
res['bootstrap'] = dict(resamples=B, seed=20261025, cluster_unit='P_set group (6)')
(out / 'STATISTICS_EXTENDED.json').write_text(json.dumps(res, indent=1), encoding='utf-8')
with open(out / 'ESTIMATOR_ACCURACY.csv', 'w', encoding='utf-8', newline='') as f:
    w = csv.writer(f)
    w.writerow(['estimator', 'n', 'MAE', 'MAE_CI95_member', 'MAE_CI95_cluster', 'median_AE', 'max_AE', 'RMSE',
                'mean_rel_err_pct', 'overshoots'])
    for k, a in res['accuracy'].items():
        w.writerow([k, a['n'], a['MAE'], a['MAE_CI_member'], a['MAE_CI_cluster'], a['median_AE'], a['max_AE'],
                    a['RMSE'], a['mean_rel_err_pct'], a['overshoots']])
print(json.dumps({k: v for k, v in res.items() if k not in ('within_group', 'groupwise_accuracy')}, indent=1))
