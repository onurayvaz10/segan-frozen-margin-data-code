# revision_extensions_20261025 — revision extensions of 25 October 2026 (archive v1.2)

Added in the revision of 25 October 2026, after all historical, internally protocol-fixed results had been obtained.
Nothing outside this folder was changed; the v1.0 and v1.1 manifests still verify.

**One command:** `python -I revision_extensions_20261025/reproduce_extensions.py` (from the archive root; Python ≥ 3.12
with numpy; about 3 minutes). It runs the unit tests, the PSV gate and synthetic test, the full engine validation and
the post-hoc statistics, compares the regenerated numbers with the distributed files and writes
`REPRODUCTION_REPORT.md`. Add `--with-cost` to repeat the timing benchmark (timings are machine-dependent). The sealed
prospective run is not re-executed (single-run rule); its hash list is verified.

| Path | Content | Manuscript |
|---|---|---|
| `PROTOKOL_MANIFEST.md` | append-only list of protocol hashes and time stamps (entries 1–4) | §6.8–6.9, S2 App. D |
| `bagimsiz/ind_engine.py` | separately coded implementation (numpy only; frozen, SHA-256 c45ec8f4…ae6b) | §6.8 |
| `bagimsiz/PROTOCOL_INDEPENDENT_VALIDATION_v1.0.md`, `validate_all.py`, `deriv_cost.py`, `smoke.py`, `codetest_3bus.py` | validation protocol and scripts | §6.8, Table 10, S2 Tables D.1–D.2 |
| `bagimsiz/out_validation/` | `ind_vs_sealed.csv` (90 members), summary, `DERIVATIVE_VALIDATION_TABLE.csv`, `COMPUTATIONAL_COST.csv`, environment | §6.8, Table 10 |
| `bagimsiz/*.log` | logs of every execution, including an interrupted and a crashed harness run | S2 App. D.1 |
| `psv/PROSPECTIVE_VALIDATION_PROTOCOL.md`, `psv/PSV_AMENDMENT_A1.md` | prospective protocol (hashed before any point) and amendment | §6.9, S2 App. D.3 |
| `psv/psv_run.py`, `psv/archive/` | runner v2 and the audited v1 | §6.9 |
| `psv/PSV_kod_denetimi_D1.md`, `_D2.md` | code audits (REVISE, then ACCEPT_FOR_RUN) | §6.9 |
| `psv/PSV_yetki_PSV_20261025_a.json` | run authorization | §6.9 |
| `psv/out/PSV_20261025_a/` | sealed single run: stage 1, selection, stage 2, result, log, SHA256SUMS | §6.9, S2 Table D.3 |
| `psv/PSV_sonuc_raporu_v1.md` | result report applying the decision table literally | §6.9 |
| `istatistik/` | cluster-bootstrap statistics on the sealed F2 records | §6.8 |
| `refs/` | Crossref audit script and output of the reference list | references |
| `tests/test_engine.py` | unit and regression tests (9 checks) | — |
| `colab_runs_20261025/` | reports of the two Google Colab runs of `colab/` (S1 and GitHub mirror) | Data availability |

Environment of the extensions: Python 3.13.2, numpy 2.5.3, Windows 11, one BLAS thread (`requirements_extensions.txt`,
`bagimsiz/out_validation/environment.json`). The historical runs did not record package versions.
