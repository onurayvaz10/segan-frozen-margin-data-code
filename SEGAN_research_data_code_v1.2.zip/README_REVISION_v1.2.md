# Archive v1.2 (25 October 2026)

v1.2 adds the folder `revision_extensions_20261025/` (see its README): a separately coded implementation and its validation against the sealed record, derivative checks, a computational-cost benchmark, cluster-bootstrap statistics, a reference audit, unit tests, and a prospective, internally protocol-fixed sign test with a second (three-bus) test system, run once. No file of v1.0 or v1.1 was changed; `SHA256SUMS` and `SHA256SUMS_v1.1` still verify. `SHA256SUMS_v1.2_extensions` lists the new files.
One command: `python -I revision_extensions_20261025/reproduce_extensions.py`.
