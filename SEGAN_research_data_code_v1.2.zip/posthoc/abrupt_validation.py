from pathlib import Path
import csv,json,sys,math
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
HERE=Path(__file__).resolve().parent; SRC=HERE.parent/'research_intelligence'; sys.path.insert(0,str(SRC/'cdl1/code'))
import hdl2b_run as H
mods=H.import_models(str(SRC)); E=mods['e1_core']; model=H.make_model(mods,'S3')
rows=[r for r in csv.DictReader((SRC/'cdl1/out/HDL2b_20261021_a/members.csv').open()) if r['in_E']=='True']; sealed=json.loads((SRC/'cdl1/out/HDL2b_20261021_a/results.json').read_text()); members={m['id']:m for m in sealed['members']}
r=min([r for r in rows if abs(float(r['P_akt'])-.65)<1e-9],key=lambda z:abs(float(z['G_R'])-.20)); P=float(r['P_akt']); G=float(r['G_R']); m=members[r['id']]
d=H.dispatch_HDL2(E,model,E.Dispatcher(model),P,G); assert d['ok']; sysm=H.RealSystem(mods,model,d['rho']); xpre=d['x0']; invM=np.zeros_like(sysm.M); nz=sysm.M!=0; invM[nz]=1/sysm.M[nz]
h=m['HAKT']['h']; curv=(m['HAKT']['rho_plus']-2*m['dGf']+m['HAKT']['rho_minus'])/h**2; kfd=(m['HAKT']['rho_plus']-m['HAKT']['rho_minus'])/(2*h); dgf=m['dGf']; dgt=m['ref']['dGt']; dg2=2*dgf/(1-kfd+math.sqrt((1-kfd)**2-2*curv*dgf)); dg1=dgf/(1-m['kappa']['k_tam'])
EM=mods['e1_model']; dc=EM.IX[EM.V_DC]; cases=[('frozen',dgf),('quadratic',dg2),('recorded_reference',dgt),('tangent',dg1)]; summary=[]
fig,axs=plt.subplots(1,2,figsize=(11,3.8)); outrows=[]
for name,g in cases:
 Gpost=G-g; ok,xe,*_=H.path_step(sysm,xpre,G,0,g); assert ok
 def rhs(t,x): return invM*sysm.f(x,Gpost)
 T=np.linspace(0,.5,501); sol=solve_ivp(rhs,(0,.5),xpre,t_eval=T,method='Radau',rtol=1e-7,atol=1e-9,max_step=.005)
 vdc=sol.y[dc]-xe[dc]; vb=np.hypot(sol.y[sysm.b[0]],sol.y[sysm.b[1]])-np.hypot(xe[sysm.b[0]],xe[sysm.b[1]])
 dist=np.linalg.norm(sol.y[:,-1]-xe)/max(np.linalg.norm(xe),1e-12); maxdev=float(np.max(np.linalg.norm(sol.y-xe[:,None],axis=0)))
 summary.append(dict(id=r['id'],P=P,G=G,case=name,dG=float(g),success=bool(sol.success),solver_status=int(sol.status),solver_message=str(sol.message),last_sampled_time_s=float(sol.t[-1]),nfev=int(sol.nfev),njev=int(sol.njev),nlu=int(sol.nlu),method="Radau",rtol=1e-7,atol=1e-9,max_step_s=.005,relative_final_distance=float(dist),max_state_distance=maxdev))
 for j,t in enumerate(sol.t): outrows.append([name,g,t,vdc[j],vb[j]])
 axs[0].plot(sol.t,vdc,label=name.replace('_',' ').title()); axs[1].plot(sol.t,vb,label=name.replace('_',' ').title())
for ax in axs: ax.set_xlabel('Time after abrupt shedding (s)'); ax.grid(alpha=.2); ax.legend(fontsize=7)
axs[0].set_ylabel('CPL DC-link deviation from post-shedding equilibrium (pu)'); axs[1].set_ylabel('Bus-102 voltage-magnitude deviation (pu)'); fig.tight_layout(); fig.savefig(HERE/'fig8_abrupt_shedding.png',dpi=500); plt.close(fig)
with (HERE/'abrupt_shedding_traces.csv').open('w',newline='') as f: w=csv.writer(f); w.writerow(['case','dG','time_s','vdc_deviation_pu','bus102_voltage_deviation_pu']); w.writerows(outrows)
(HERE/'abrupt_validation.json').write_text(json.dumps(summary,indent=2)); print(json.dumps(summary,indent=2))
