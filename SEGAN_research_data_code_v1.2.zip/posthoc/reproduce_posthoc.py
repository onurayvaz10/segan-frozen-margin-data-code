"""Reproduce the paper's exploratory margin, modal and time-domain checks.

Reads the sealed HDL2b outputs; never writes into research_intelligence.
"""
from pathlib import Path
import csv,json,sys,math
import numpy as np,scipy
from scipy.integrate import solve_ivp
from scipy.stats import pearsonr,spearmanr
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE=Path(__file__).resolve().parent
SRC=Path(__file__).resolve().parents[1]/'research_intelligence'
sys.path.insert(0,str(SRC/'cdl1/code'))
import hdl2b_run as H
rows=[r for r in csv.DictReader((SRC/'cdl1/out/HDL2b_20261021_a/members.csv').open(encoding='utf-8')) if r['in_E']=='True']
sealed=json.loads((SRC/'cdl1/out/HDL2b_20261021_a/results.json').read_text(encoding='utf-8'))
members={m['id']:m for m in sealed['members']}
f=np.array([float(r['dGf']) for r in rows]);t=np.array([float(r['dGt']) for r in rows]);k=np.array([float(r['k_tam']) for r in rows]);kfd=np.array([float(r['k_fd']) for r in rows]);P=np.array([float(r['P_akt']) for r in rows]);G=np.array([float(r['G_R']) for r in rows])
curv=[]
for r in rows:
    m=members[r['id']];h=m['HAKT']['h']
    curv.append((m['HAKT']['rho_plus']-2*m['dGf']+m['HAKT']['rho_minus'])/h**2)
curv=np.array(curv)
q=2*f/(1-kfd+np.sqrt((1-kfd)**2-2*curv*f))
x=k/(1-k);y=(t-f)/f
with (HERE/'posthoc_member_predictions.csv').open('w',newline='',encoding='utf-8') as out:
    w=csv.writer(out);w.writerow(['id','P_akt','G_R','dGf','dGt_recorded','kappa','kappa_fd','curvature_central','dG_second_order','signed_error'])
    for i,r in enumerate(rows):w.writerow([r['id'],P[i],G[i],f[i],t[i],k[i],kfd[i],curv[i],q[i],q[i]-t[i]])
summary={'n':len(rows),'pearson':float(pearsonr(x,y).statistic),'spearman':float(spearmanr(x,y).statistic),'within_P_spearman':{str(v):float(spearmanr(x[P==v],y[P==v]).statistic) for v in sorted(set(P))},'mae_frozen':float(np.mean(abs(f-t))),'mae_quadratic':float(np.mean(abs(q-t))),'reduction_fraction':float(1-np.mean(abs(q-t))/np.mean(abs(f-t))),'recorded_overshoots':int(sum(q>t)),'min_recorded_reference_gap':float(min(t-q)),'curvature_range':list(map(float,[min(curv),max(curv)])),'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__}
pred_const=[];pred_cal=[]
for v in sorted(set(P)):
    train=P!=v;test=P==v
    constant=float(np.median((t/f)[train]))
    alpha=float(np.sum(y[train]*x[train])/np.sum(x[train]**2))
    pred_const.extend(abs(constant*f[test]-t[test]))
    pred_cal.extend(abs(f[test]*(1+alpha*x[test])-t[test]))
summary['held_out_power_group_mae']={'constant_factor':float(np.mean(pred_const)),'calibrated_first_order':float(np.mean(pred_cal))}
mods=H.import_models(str(SRC));E=mods['e1_core'];model=H.make_model(mods,'S3');d=H.dispatch_HDL2(E,model,E.Dispatcher(model),.65,.20)
assert d['ok'];sysm=H.RealSystem(mods,model,d['rho']);x0=d['x0'];m=members['S3_P0.65_G0.20'];hf=m['HAKT']['h'];dd=(m['HAKT']['rho_plus']-2*m['dGf']+m['HAKT']['rho_minus'])/hf**2
dgf=m['dGf'];dgt=m['ref']['dGt'];dg1=dgf/(1-m['kappa']['k_tam']);kfd_b=(m['HAKT']['rho_plus']-m['HAKT']['rho_minus'])/(2*hf);dg2=2*dgf/(1-kfd_b+math.sqrt((1-kfd_b)**2-2*dd*dgf))
invM=1/sysm.M.copy();invM[sysm.i_theta]=0
EModel=mods['e1_model'];dc=EModel.IX[EModel.V_DC]
cases={'frozen':dgf,'quadratic':dg2,'recorded_reference':dgt,'tangent':dg1}
fig,axs=plt.subplots(1,2,figsize=(11,3.8))
summary['benchmark']={}
with (HERE/'time_domain_traces.csv').open('w',newline='',encoding='utf-8') as out:
    w=csv.writer(out);w.writerow(['case','dG','time_s','vdc_deviation_pu','bus102_voltage_deviation_pu'])
    for name,g in cases.items():
        ok,xe,*_=H.path_step(sysm,x0,.20,0,g);assert ok
        A=sysm.J(xe,.20-g)[np.ix_(sysm.keep,sysm.keep)]/sysm.M[sysm.keep,None]
        eig=np.linalg.eigvals(A);ev=max((z for z in eig if z.imag>200),key=lambda z:z.real)
        if name=='recorded_reference':
            values,R=np.linalg.eig(A);W=np.linalg.inv(R);idx=min(range(len(values)),key=lambda i:abs(values[i]-ev));pf=np.abs(R[:,idx]*W[idx,:]);pf=pf/pf.sum()
            labels=[mods['e1_model'].STATE_NAMES[j] for j in sysm.keep]
            inds=np.argsort(pf)[::-1][:10]
            summary['benchmark_participation']=[{'state':labels[i],'factor':float(pf[i])} for i in inds]
        xinit=xe.copy();xinit[dc]+=1e-4
        def rhs(time,state):return invM*sysm.f(state,.20-g)
        def jac(time,state):return sysm.J(state,.20-g)*invM[:,None]
        T=np.linspace(0,1.0,2001)
        sol=solve_ivp(rhs,(0,1.0),xinit,t_eval=T,method='Radau',jac=jac,rtol=1e-8,atol=1e-10,max_step=.001)
        assert sol.success,(name,sol.message)
        dev=sol.y[dc]-xe[dc]
        vb=np.hypot(sol.y[sysm.b[0]],sol.y[sysm.b[1]])-np.hypot(xe[sysm.b[0]],xe[sysm.b[1]])
        for i in range(len(T)):w.writerow([name,g,T[i],dev[i],vb[i]])
        summary['benchmark'][name]={'dG':float(g),'eigenvalue':[float(ev.real),float(ev.imag)],'max_real_eigenvalue':float(max(eig.real)),'ode_success':sol.success,'ode_steps':len(sol.t),'final_abs_vdc_deviation':float(abs(dev[-1]))}
        print(name,summary['benchmark'][name],flush=True)
        for ax,arr in zip(axs,[dev,vb]):ax.plot(T,arr*1e4,label=name.replace('_',' ').title(),lw=1)
axs[0].set_ylabel('CPL DC-link voltage deviation (10⁻⁴ pu)')
axs[1].set_ylabel('Bus 102 voltage magnitude deviation (10⁻⁴ pu)')
for ax in axs:ax.set_xlabel('Time (s)');ax.grid(alpha=.2);ax.legend(fontsize=7)
fig.tight_layout();fig.savefig(HERE/'fig7_reproduced.png',dpi=300);plt.close(fig)
(HERE/'posthoc_reproduction.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding='utf-8')
print('Completed',summary['n'],summary['mae_quadratic'],flush=True)
