"""Reproduce Tables 11 and 12 from the retained 79 evaluable records.
LOO constant: training median(t/f). LOO calibration: origin-constrained least squares
of y=(t-f)/f on x=k/(1-k), excluding the evaluated row.
MRE uses the recorded reference as denominator. No historical file is modified.
"""
from pathlib import Path
import csv,json,statistics,math
HERE=Path(__file__).resolve().parent
R=HERE.parent/'research_intelligence/cdl1/out/HDL2b_20261021_a'
rows=[r for r in csv.DictReader((R/'members.csv').open(encoding='utf8')) if r['in_E']=='True']
sealed=json.loads((R/'results.json').read_text(encoding='utf8'));ms={m['id']:m for m in sealed['members']}
f=[float(r['dGf']) for r in rows];t=[float(r['dGt']) for r in rows];k=[float(r['k_tam']) for r in rows];kl=[float(r['k_L']) for r in rows]
x=[a/(1-a) for a in k];y=[(b-a)/a for a,b in zip(f,t)];q=[];curv=[]
for r,a in zip(rows,f):
 m=ms[r['id']];h=m['HAKT']['h'];c=(m['HAKT']['rho_plus']-2*a+m['HAKT']['rho_minus'])/h**2;kd=(m['HAKT']['rho_plus']-m['HAKT']['rho_minus'])/(2*h);curv.append(c);q.append(2*a/(1-kd+math.sqrt((1-kd)**2-2*c*a)))
cs=[];ca=[];coeff=[];alphas=[]
for i in range(len(rows)):
 inds=[j for j in range(len(rows)) if j!=i];c=statistics.median(t[j]/f[j] for j in inds);a=sum(x[j]*y[j] for j in inds)/sum(x[j]**2 for j in inds);coeff.append(c);alphas.append(a);cs.append(c*f[i]);ca.append(f[i]*(1+a*x[i]))
preds=[f,[a/(1-b) for a,b in zip(f,k)],[a/(1-b) for a,b in zip(f,kl)],cs,ca,q]
metrics=[]
for name,p in zip(['Frozen','First_order_full','First_order_load','LOO_constant','LOO_calibrated','Quadratic'],preds):
 e=[abs(a-b) for a,b in zip(p,t)];metrics.append(dict(estimator=name,n=len(rows),mae=statistics.mean(e),rmse=math.sqrt(statistics.mean(v*v for v in e)),max_error=max(e),mre_percent=100*statistics.mean(v/b for v,b in zip(e,t)),overshoots=sum(a>b for a,b in zip(p,t))))
groups=[]
for power in sorted(set(float(r['P_akt']) for r in rows)):
 a=[r for r in rows if float(r['P_akt'])==power];d={'P_akt':power,'n':len(a)}
 for col in ['omega_star','c','xi_d','xi_q','k_V','k_theta','k_L','k_Delta','k_K','k_tam']:d[col]=statistics.mean(float(r[col]) for r in a)
 d['frequency_hz']=d['omega_star']/(2*math.pi);d['pi_d']=statistics.mean(json.loads(r['pi_d'])[0] for r in a);d['pi_cross_abs']=statistics.mean(abs(complex(*json.loads(r['pi_x']))) for r in a);d['frequency_fraction_percent']=100*statistics.mean(-float(r['c'])*float(r['Im_eta'])/float(r['k_tam']) for r in a);groups.append(d)
summary=dict(groups=groups,metrics=metrics,loo_constant_mean=statistics.mean(coeff),loo_alpha_mean=statistics.mean(alphas),loo_reduction_percent=100*(1-metrics[4]['mae']/metrics[3]['mae']),curvature_range=[min(curv),max(curv)])
(HERE/'tables_11_12_reproduction.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
for name,rs in [('table11_groups.csv',groups),('table12_metrics.csv',metrics)]:
 with (HERE/name).open('w',newline='',encoding='utf8') as out:w=csv.DictWriter(out,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
print(json.dumps(summary,indent=2))
