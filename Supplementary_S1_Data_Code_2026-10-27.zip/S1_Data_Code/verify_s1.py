"""Read-only S1 inventory and recorded-data check; Python standard library only."""
from pathlib import Path
import csv, hashlib, json, sys

root=Path(__file__).resolve().parent
with (root/'FILE_INVENTORY.csv').open(encoding='utf-8',newline='') as f:
    inventory=list(csv.DictReader(f))
failures=[]
for item in inventory:
    p=root/item['file']
    if not p.is_file(): failures.append({'file':item['file'],'error':'missing'})
    elif hashlib.sha256(p.read_bytes()).hexdigest()!=item['sha256']:
        failures.append({'file':item['file'],'error':'hash mismatch'})
with (root/'research_intelligence/development_20261026/out/tsv/TSV_a/analysis/points.csv').open(encoding='utf-8',newline='') as f:
    rows=list(csv.DictReader(f))
primary=[r for r in rows if r['stage1_pin_ok']=='True' and r['abs_kappa'] and float(r['abs_kappa'])>=.05 and r['ref_sign'] in ('1','-1','1.0','-1.0')]
counts=dict(selected=len(rows),primary=len(primary),conservative=sum(float(r['ref_sign'])==1 for r in primary),
            optimistic=sum(float(r['ref_sign'])==-1 for r in primary),
            uncensored_primary=sum(r['censored']=='False' and r['ref_status']=='alpha' for r in primary),
            full_sign_errors=sum((1 if float(r['kappa'])>0 else -1)!=float(r['ref_sign']) for r in primary),
            no_crossing_frequency_errors=sum((1 if float(r['eta_re'])>0 else -1)!=float(r['ref_sign']) for r in primary))
expected=dict(selected=1249,primary=922,conservative=904,optimistic=18,uncensored_primary=774,full_sign_errors=0,no_crossing_frequency_errors=134)
print(json.dumps(dict(files_checked=len(inventory),integrity_failures=failures,counts=counts,counts_match=counts==expected),indent=2))
sys.exit(0 if not failures and counts==expected else 1)
