"""hdl2b_run.py icin AST statik denetimi (HDL2b SABIT s7 'Statik denetim' = H-DL2 SABIT s7 listesi aynen + aile
sabitleri + genisletilmis yasak dosya adi listesi). hdl2_static_check.py v2'den (7bb5354a...7c69; arsiv
archive/hdl2_static_check_v2_20261021.py) turetildi; yazar otopilot R9B2KF (HDL2b-B1), 2026-10-21.

Denetimler:
  S1  import izin listesi: ust duzeyde 10 standart modul + numpy; model modulleri (e1k_model, e1k_core, e1_core,
      e1_model) yalniz import_models() icinde; 'from' import yok; yasakli adlar (scipy, sympy, subprocess,
      importlib, e1k_run, e1_run, ...) yok.
  S2  yasakli cagrilar yok: eval, exec, compile, __import__, setattr, delattr, os.system, os.popen, os.exec*,
      os.spawn*, os.fork*.
  S3  open() yalniz _read_bytes ve _write_text icinde; pathlib/read_text yok.
  S4  PINS literal tablosu 1..13: 1-11 HDL2b SABIT s3.2 tablosu ile birebir (yol, bayt, sha); 12 = SABIT statu
      satirindaki kabul raporu (yol, bayt, sha statu satirinda gecer); 13 = s3.2 satir 13'un bayt ve sha'si,
      yol archive/hdl2_run_v2_<8 hane>.py; diskteki dosyalar bu degerlerle eslesir; SABIT_SHA256 dogru.
  S5  korlenmis/onceki sonuc dosya adlari kodda yok (S_/T_ nokta, durum, V5, ozdeger dosyalari; 'points/';
      onceki kosu klasorleri; HDL2b s7 R-3 genisletmesi: HT_sonuc, T4_sonuc, HDL2_2026, decision_log);
      'sonuc.json' ve 'uyeler.csv' yalniz write_outputs() icinde (cikti adi).
  S6  pinli modullere/model nesnesine yazma (yama) yok; sembolik/ozel nitelik yok; model, EC, EM, KC, KM
      uzerinde yalniz izinli nitelikler.
  S7  V_STAR hicbir bicimde (ad, nitelik, dizge) gecmez: rho'ya giremez (SABIT s4.2 adim 4).
  S8  dispatch_HDL2: rho = [p_e, q_e, v_refr, li['Vref_dc'], Iq_ref] (tek atama, harfiyen); cagri sirasi
      power_flow -> load_init -> _assemble -> refine('new') -> newton_theta_fixed; yakalanan istisna kumesi
      (DispatchError, LinAlgError, ValueError, ZeroDivisionError) (U-4).
  S9  korleme/yetki sirasi: evaluate() yalniz main() icinde ve verify_authorization() cagrisindan sonra;
      import_models/make_model/run_family yalniz evaluate() icinde (ic ice fonksiyonlar dahil); check_only()
      bunlari cagirmaz.
  S10 scipy tarzi cozucu adlari yok (odeint, solve_ivp, fsolve, brentq, minimize, root_scalar, least_squares,
      linprog, milp).
  S11 aile sabitleri HDL2b s4.2b ile birebir: SETTING_CODES = ('S3',); P_AKT_GRID degerleri SABIT'teki "Tam liste
      (artan)" ile, G_R_K/100 "Tam liste (azalan)" ile ayni sirada; 6 x 15 = N_FAMILY = 90; tampon (BUFFER_K =
      (25, 1)) icinde k yok (0.24/0.25/0.26 yok); P kimlik dizgesi degere esit; PRIOR_FAMILY_MEMBER =
      ('S3', '0.65', 20); N_P_MIN = 2; family_specs varsayilanlari P_AKT_GRID ve G_R_K; EXCLUDED/CANDIDATES
      family_specs icinde kullanilmaz.
Kullanim: python -I hdl2b_static_check.py [--root <research_intelligence>] [--script <hdl2b_run.py>]
Cikis: 0 = GECTI, 1 = KALDI.
"""
import argparse
import ast
import hashlib
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
TOP_IMPORTS = {'os', 'argparse', 'csv', 'hashlib', 'io', 'json', 'math', 're', 'sys', 'traceback', 'numpy'}
MODEL_IMPORTS = {'e1k_model', 'e1k_core', 'e1_core', 'e1_model'}
FORBIDDEN_NAMES = {'scipy', 'sympy', 'sp', 'subprocess', 'importlib', 'ctypes', 'multiprocessing', 'socket',
                   'urllib', 'http', 'shutil', 'pathlib', 'pickle', 'marshal', 'e1k_run', 'e1_run', 'ER'}
FORBIDDEN_CALLS = {'eval', 'exec', 'compile', '__import__', 'execfile', 'setattr', 'delattr'}
FORBIDDEN_ATTR_CALLS = {('os', 'system'), ('os', 'popen'), ('os', 'startfile')}
FORBIDDEN_ATTR_PREFIX = ('exec', 'spawn', 'fork')
OPEN_ALLOWED_IN = {'_read_bytes', '_write_text'}
BLINDED_FRAGMENTS = ('S_state', 'S_V5', 'S_point', 'T_point', 'T_state', 'T_V5', 'S_eigs', 'T_eigs', 'points/',
                     'SETTINGS_2026', 'HT_2026', 'T4_2026',
                     'HT_sonuc', 'T4_sonuc', 'HDL2_2026', 'decision_log')   # HDL2b s7 (R-3)
OUTPUT_ONLY = ('sonuc.json', 'uyeler.csv')   # yalniz write_outputs icinde cikti adi olarak
ALLOWED_ATTRS = {
    'model': {'f', 'J', 'Jx_tilde', 'h', 'M', 'load', 'net', 'theta_row_zero'},
    'EC': {'TH', 'KEEP', 'CANDIDATES', 'VIOL', 'BORDER', 'power_flow', 'load_init', 'Dispatcher', 'DispatchError',
           'newton_theta_fixed', 'eig_part', 'identify_ref', 'alpha_from', 'limits'},
    'EM': {'STATE_NAMES', 'I_THETA', 'LOAD_STATE_NAMES', 'L', 'WB', 'REF_NAMES', 'RB'},
    'KC': {'SETTINGS', 'pu_gains'},
    'KM': {'E1KModel'},
}
SYMBOLIC_ATTRS = {'jacobian', 'diff', 'lambdify', 'subs', 'J_new_sym', 'Jx_tilde_sym', 'Jz_tilde_sym', 'f_new_sym',
                  'J_fix_sym', 'f_fix_sym', '_Jn', '_Jxt', '_Jzt', '_fn', '_ft', '_ff', '_Jf', '_aux',
                  'J_complex_step', 'J_fixed', 'f_fixed', 'f_tilde', 'Jz_tilde', 'build_ftilde_k', 'build_ftilde',
                  'dispatch_E1', 'dispatch_RHA', 'continuation'}
PATCH_ROOTS = {'KM', 'KC', 'EC', 'EM', 'RB', 'model', 'mods', 'disp'}
SOLVER_NAMES = {'odeint', 'solve_ivp', 'fsolve', 'brentq', 'brenth', 'minimize', 'root_scalar', 'least_squares',
                'linprog', 'milp'}
RHO_EXPR = "np.array([gi['p_e'], gi['q_e'], gi['v_refr'], li['Vref_dc'], li['Iq_ref']], dtype=float)"
DISPATCH_ORDER = ('power_flow', 'load_init', '_assemble', 'refine', 'newton_theta_fixed')
CAUGHT = {'DispatchError', 'LinAlgError', 'ValueError', 'ZeroDivisionError'}
SABIT = ('cdl1/CDL2_HDL2b_On_Kayit_v1.0_SABIT.md', '839f19c29222236565de5ead0b5efa75140a1ef8ea133ac6541538fe26253381')
PIN12 = ('cdl1/CDL2_HDL2b_On_Kayit_v0.3_bagimsiz_denetim_Claude.md', 19344,
         '217a3dfd45f647a632754627ad904fab7b2d6e35ea777c5fa1246188aa72baa8')
PIN13_RE = r'^archive/hdl2_run_v2_\d{8}\.py$'
FAMILY_CONST = {'SETTING_CODES': ('S3',), 'BUFFER_K': (25, 1), 'PRIOR_FAMILY_MEMBER': ('S3', '0.65', 20),
                'N_FAMILY': 90, 'N_P_MIN': 2}


def sha(path):
    with open(path, 'rb') as fh:
        return hashlib.sha256(fh.read()).hexdigest()


def sabit_s3(md_text):
    """SABIT s3: '| n | `yol` | bayt | `sha` | kullanim |' satirlari."""
    out = []
    for line in md_text.splitlines():
        m = re.match(r'^\|\s*(\d+)\s*\|\s*`([^`]+)`\s*\|\s*(\d+)\s*\|\s*`([0-9a-f]{64})`\s*\|', line)
        if m:
            out.append((int(m.group(1)), m.group(2), int(m.group(3)), m.group(4)))
    return out


def sabit_s0(md_text):
    """SABIT s0: '| `yol` | `sha` | ...' satirlarinda tam (64 hane) hash'ler."""
    out = {}
    for line in md_text.splitlines():
        m = re.match(r'^\|\s*`([^`]+)`\s*\|\s*`([0-9a-f]{64})`\s*\|', line)
        if m:
            out[m.group(1)] = m.group(2)
    return out


def sabit_family(md_text):
    """HDL2b SABIT s4.2b: 'Tam liste (azalan): **{...}**' (G_R) ve 'Tam liste (artan): **{...}**' (P_akt)."""
    def grab(tag):
        m = re.search(r'Tam liste \(' + tag + r'\)[^*]*\*\*\{([^}]*)\}\*\*', md_text)
        return [float(v) for v in m.group(1).split(',')] if m else None
    return grab('artan'), grab('azalan')


def top_literals(tree):
    out = {}
    for n in tree.body:
        if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name):
            try:
                out[n.targets[0].id] = ast.literal_eval(n.value)
            except ValueError:
                out[n.targets[0].id] = None
    return out


def literal_pins(tree):
    for n in tree.body:
        if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name) \
                and n.targets[0].id == 'PINS':
            try:
                return [tuple(t) for t in ast.literal_eval(n.value)]
            except ValueError:
                return None
    return None


def parents_map(tree):
    """Dugum id -> icinde bulundugu fonksiyon adlari zinciri (ic -> dis)."""
    out = {}

    def visit(node, chain):
        for ch in ast.iter_child_nodes(node):
            out[id(ch)] = chain
            nxt = ((ch.name,) + chain) if isinstance(ch, (ast.FunctionDef, ast.AsyncFunctionDef)) else chain
            visit(ch, nxt)
    visit(tree, ())
    return out


def call_name(n):
    f = n.func
    return f.id if isinstance(f, ast.Name) else (f.attr if isinstance(f, ast.Attribute) else None)


def root_name(node):
    while isinstance(node, (ast.Attribute, ast.Subscript)):
        node = node.value
    return node.id if isinstance(node, ast.Name) else None


def func_def(tree, name):
    hits = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name]
    return hits[0] if len(hits) == 1 else None


def base_key(node):
    """'model.f' / 'self.model.f' -> 'model'; 'EC.x' -> 'EC'."""
    v = node.value
    if isinstance(v, ast.Name):
        return v.id
    if isinstance(v, ast.Attribute) and v.attr == 'model':
        return 'model'
    return None


def check(script_path, root):
    src_bytes = open(script_path, 'rb').read()
    tree = ast.parse(src_bytes.decode('utf-8'))
    chain = parents_map(tree)
    res = []
    doc = tree.body[0].value if (tree.body and isinstance(tree.body[0], ast.Expr)) else None

    # S1
    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Import):
            for a in n.names:
                top = a.name.split('.')[0]
                fn = chain.get(id(n), ())
                if top in MODEL_IMPORTS:
                    if fn[:1] != ('import_models',):
                        bad.append('%s import_models disinda (satir %d)' % (a.name, n.lineno))
                elif top not in TOP_IMPORTS:
                    bad.append(a.name)
        elif isinstance(n, ast.ImportFrom):
            bad.append('from %s' % n.module)
        elif isinstance(n, ast.Name) and n.id in FORBIDDEN_NAMES:
            bad.append(n.id)
        elif isinstance(n, ast.Attribute) and n.attr in FORBIDDEN_NAMES:
            bad.append('.' + n.attr)
    res.append(('S1 import/yasakli ad', not bad, bad))

    # S2
    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Call):
            f = n.func
            if isinstance(f, ast.Name) and f.id in FORBIDDEN_CALLS:
                bad.append(f.id)
            if isinstance(f, ast.Attribute) and isinstance(f.value, ast.Name):
                if (f.value.id, f.attr) in FORBIDDEN_ATTR_CALLS or (
                        f.value.id == 'os' and f.attr.startswith(FORBIDDEN_ATTR_PREFIX)):
                    bad.append('%s.%s' % (f.value.id, f.attr))
    res.append(('S2 yasakli cagri', not bad, bad))

    # S3
    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Call):
            name = call_name(n)
            if name in ('open', 'read_text', 'read_bytes', 'write_text', 'write_bytes', 'urlopen'):
                if not (name == 'open' and chain.get(id(n), ())[:1] and chain[id(n)][0] in OPEN_ALLOWED_IN):
                    bad.append('%s @ satir %d' % (name, n.lineno))
    res.append(('S3 dosya acma tek nokta', not bad, bad))

    # S4
    detail = []
    sp = os.path.join(root, *SABIT[0].split('/'))
    if sha(sp) != SABIT[1]:
        detail.append('SABIT sha uyusmuyor')
    md = open(sp, encoding='utf-8').read()
    s3 = {t[0]: t for t in sabit_s3(md)}   # HDL2b s3.2 satir 1-11 (12 'N4-S'de'; 13 yol sonrasi aciklamali)
    m13 = [re.match(r'^\|\s*13\s*\|\s*`([^`]+)`[^|]*\|\s*(\d+)\s*\|\s*`([0-9a-f]{64})`\s*\|', ln)
           for ln in md.splitlines()]
    m13 = [m for m in m13 if m]
    if len(m13) == 1 and 13 not in s3:
        s3[13] = (13, m13[0].group(1), int(m13[0].group(2)), m13[0].group(3))
    lp = literal_pins(tree) or []
    if [t[0] for t in lp] != list(range(1, 14)):
        detail.append('PINS numaralari 1..13 degil')
    if sorted(s3) != [n for n in range(1, 14) if n != 12]:
        detail.append('SABIT s3.2 tablosu beklenen 12 satir degil: %r' % sorted(s3))
    for t in lp:
        if t[0] <= 11 and s3.get(t[0]) != t:
            detail.append('PIN %d != SABIT s3.2' % t[0])
    row12 = [t for t in lp if t[0] == 12]
    if not row12 or tuple(row12[0][1:]) != PIN12:
        detail.append('PIN 12 != kabul raporu (N4-S)')
    statu = [ln for ln in md.splitlines() if ln.startswith('**Statü: SABİT v1.0')]
    if len(statu) != 1 or not all(v in statu[0] for v in (PIN12[0], str(PIN12[1]), PIN12[2])):
        detail.append('PIN 12 SABIT statu satirinda yok')
    row13 = [t for t in lp if t[0] == 13]
    if (not row13 or 13 not in s3 or tuple(row13[0][2:]) != tuple(s3[13][2:])
            or not re.match(PIN13_RE, row13[0][1])):
        detail.append('PIN 13 != SABIT s3.2 satir 13 (bayt/sha) ya da yol deseni')
    for no, rel, size, h in lp:
        p = os.path.join(root, *rel.split('/'))
        if not os.path.isfile(p) or os.path.getsize(p) != size or sha(p) != h:
            detail.append('pin %d diskte uyusmuyor' % no)
    sab = [n for n in tree.body if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name)
           and n.targets[0].id == 'SABIT_SHA256']
    if len(sab) != 1 or ast.literal_eval(sab[0].value) != SABIT[1]:
        detail.append('SABIT_SHA256 literal')
    res.append(('S4 PINS == HDL2b SABIT s3.2 (+12, 13) ve diskteki dosyalar', not detail, detail))

    # S5
    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Constant) and isinstance(n.value, str) and n is not doc:
            for b in BLINDED_FRAGMENTS:
                if b in n.value:
                    bad.append('%r @ satir %d' % (b, n.lineno))
            for o in OUTPUT_ONLY:
                if o in n.value and chain.get(id(n), ())[:1] != ('write_outputs',):
                    bad.append("%r write_outputs disinda @ satir %d" % (o, n.lineno))
    res.append(('S5 korlenmis/onceki sonuc dosyalari yok', not bad, bad))

    # S6
    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Attribute):
            if n.attr in SYMBOLIC_ATTRS:
                bad.append('.%s @ satir %d' % (n.attr, n.lineno))
            key = base_key(n)
            if key in ALLOWED_ATTRS and n.attr not in ALLOWED_ATTRS[key]:
                bad.append('%s.%s @ satir %d' % (key, n.attr, n.lineno))
        targets = []
        if isinstance(n, ast.Assign):
            targets = n.targets
        elif isinstance(n, (ast.AugAssign, ast.AnnAssign)):
            targets = [n.target]
        elif isinstance(n, ast.Delete):
            targets = n.targets
        for t in targets:
            for tt in (t.elts if isinstance(t, ast.Tuple) else [t]):
                if isinstance(tt, (ast.Attribute, ast.Subscript)):
                    rn = root_name(tt)
                    via_model = isinstance(tt, ast.Attribute) and isinstance(tt.value, ast.Attribute) \
                        and tt.value.attr in ('model', 'EC')
                    if rn in PATCH_ROOTS or via_model:
                        bad.append('yama: %s @ satir %d' % (ast.unparse(tt), n.lineno))
    res.append(('S6 yama/sembolik yok; izinli nitelikler', not bad, bad))

    # S7
    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Name) and n.id == 'V_STAR':
            bad.append('ad @ satir %d' % n.lineno)
        if isinstance(n, ast.Attribute) and n.attr == 'V_STAR':
            bad.append('nitelik @ satir %d' % n.lineno)
        if isinstance(n, ast.Constant) and isinstance(n.value, str) and 'V_STAR' in n.value and n is not doc:
            bad.append('dizge @ satir %d' % n.lineno)
    res.append(('S7 V_STAR yok (rho_4 = Vref_dc)', not bad, bad))

    # S8
    detail = []
    fd = func_def(tree, 'dispatch_HDL2')
    if fd is None:
        detail.append('dispatch_HDL2 yok')
    else:
        rho_as = [n for n in ast.walk(fd) if isinstance(n, ast.Assign) and len(n.targets) == 1
                  and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'rho']
        if len(rho_as) != 1 or ast.unparse(rho_as[0].value) != RHO_EXPR:
            detail.append('rho atamasi harfiyen degil')
        calls = [(call_name(n), n) for n in ast.walk(fd) if isinstance(n, ast.Call)]
        order = []
        for name, n in sorted(calls, key=lambda t: (t[1].lineno, t[1].col_offset)):
            if name in DISPATCH_ORDER and name not in order:
                order.append(name)
            if name == 'refine':
                args = [a.value for a in n.args if isinstance(a, ast.Constant)]
                if args != ['new']:
                    detail.append("refine 'new' ile cagrilmiyor")
        if tuple(order) != DISPATCH_ORDER:
            detail.append('cagri sirasi %r' % (order,))
        hand = [h for h in ast.walk(fd) if isinstance(h, ast.ExceptHandler)]
        names = set()
        for h in hand:
            if isinstance(h.type, ast.Tuple):
                for e in h.type.elts:
                    names.add(e.attr if isinstance(e, ast.Attribute) else getattr(e, 'id', None))
        if names != CAUGHT:
            detail.append('istisna kumesi %r' % sorted(map(str, names)))
    res.append(('S8 dispatch_HDL2 adimlari, rho ve istisna kumesi', not detail, detail))

    # S9
    detail = []
    calls_eval = [n for n in ast.walk(tree) if isinstance(n, ast.Call) and call_name(n) == 'evaluate']
    if len(calls_eval) != 1 or chain.get(id(calls_eval[0]), ())[:1] != ('main',):
        detail.append('evaluate() cagrisi tek ve main() icinde degil')
    else:
        auth = [n for n in ast.walk(func_def(tree, 'main')) if isinstance(n, ast.Call)
                and call_name(n) == 'verify_authorization']
        if len(auth) != 1 or not auth[0].lineno < calls_eval[0].lineno:
            detail.append('verify_authorization() evaluate()dan once degil')
    fc = func_def(tree, 'check_only')
    if fc is None:
        detail.append('check_only() yok')
    else:
        for n in ast.walk(fc):
            if isinstance(n, ast.Call) and call_name(n) in ('evaluate', 'import_models', 'make_model', 'run_family'):
                detail.append('check_only icinde %s' % call_name(n))
    for name in ('import_models', 'make_model', 'run_family'):
        sites = [chain.get(id(n), ()) for n in ast.walk(tree) if isinstance(n, ast.Call) and call_name(n) == name]
        if not sites or any('evaluate' not in s for s in sites):
            detail.append('%s evaluate() disinda cagriliyor ya da hic cagrilmiyor' % name)
    res.append(('S9 yetki -> evaluate sirasi', not detail, detail))

    # S10
    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Call) and call_name(n) in SOLVER_NAMES:
            bad.append('%s @ satir %d' % (call_name(n), n.lineno))
        if isinstance(n, ast.Attribute) and n.attr in SOLVER_NAMES:
            bad.append('.%s @ satir %d' % (n.attr, n.lineno))
    res.append(('S10 scipy tarzi cozucu yok', not bad, bad))

    # S11
    detail = []
    lits = top_literals(tree)
    for k, v in FAMILY_CONST.items():
        if lits.get(k) != v:
            detail.append('%s != HDL2b s4.2b (%r)' % (k, lits.get(k)))
    want_p, want_g = sabit_family(md)
    pg, gk = lits.get('P_AKT_GRID'), lits.get('G_R_K')
    if want_p is None or want_g is None or len(want_p) != 6 or len(want_g) != 15:
        detail.append('SABIT s4.2b tam listeleri okunamadi')
    elif not (isinstance(pg, tuple) and isinstance(gk, tuple)):
        detail.append('P_AKT_GRID/G_R_K literal tuple degil')
    else:
        if [p for p, _ in pg] != want_p:
            detail.append('P_AKT_GRID degerleri/sirasi != SABIT')
        if any(float(ps) != p for p, ps in pg) or len(set(ps for _, ps in pg)) != len(pg):
            detail.append('P kimlik dizgesi degere esit degil ya da tekrarli')
        if [k / 100.0 for k in gk] != want_g or any(not isinstance(k, int) for k in gk):
            detail.append('G_R_K/100 degerleri/sirasi != SABIT')
        if any(abs(k - 25) <= 1 for k in gk):
            detail.append('tampon icinde G_R (0.24/0.25/0.26)')
        if len(pg) * len(gk) != lits.get('N_FAMILY'):
            detail.append('6 x 15 != N_FAMILY')
    fs = func_def(tree, 'family_specs')
    if fs is None:
        detail.append('family_specs yok')
    else:
        dflt = [ast.unparse(d) for d in fs.args.defaults]
        if dflt != ['P_AKT_GRID', 'G_R_K']:
            detail.append('family_specs varsayilanlari %r' % dflt)
        names = {n.id for n in ast.walk(fs) if isinstance(n, ast.Name)} | \
            {n.attr for n in ast.walk(fs) if isinstance(n, ast.Attribute)}
        if names & {'EXCLUDED', 'CANDIDATES', 'candidates'}:
            detail.append('family_specs EXCLUDED/CANDIDATES kullaniyor')
        if 'BUFFER_K' not in names:
            detail.append('family_specs tampon denetimi yok')
    res.append(('S11 aile sabitleri == HDL2b s4.2b (90 uye, sira, tampon)', not detail, detail))

    return res, hashlib.sha256(src_bytes).hexdigest()


def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except (AttributeError, ValueError):
        pass
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default=os.path.dirname(os.path.dirname(HERE)))
    ap.add_argument('--script', default=os.path.join(HERE, 'hdl2b_run.py'))
    a = ap.parse_args(argv)
    res, h = check(a.script, a.root)
    print('hdl2b_run.py sha256: %s' % h)
    ok = True
    for name, passed, detail in res:
        print('%-55s %s%s' % (name, 'GECTI' if passed else 'KALDI', '' if passed else '  ' + '; '.join(map(str, detail))))
        ok &= passed
    print('STATIK DENETIM: %s' % ('GECTI' if ok else 'KALDI'))
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
