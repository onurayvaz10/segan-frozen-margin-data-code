"""Insert the switching-level (Y5) result into ms_v3_plan.txt and s2_appG_plan.txt, update package92.py and add D-255."""
import re
import shutil
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RI = ROOT.parent
p = ROOT / 'ms' / 'ms_v3_plan.txt'
t = p.read_text(encoding='utf-8')
EMT = ('**Switching-level check (pre-specified, S2 Appendix G.7).** The device and network equations were also '
       'integrated with two-level sinusoidal PWM, control outputs sampled every switching period and applied one '
       'period later, and the CPL DC link fed by the instantaneous switched power; with all network elements '
       'dynamic, this reproduces the switching behaviour of the balanced three-wire system, but it is not an '
       'independently built electromagnetic-transient model. At 10 kHz the one-period delay alone destabilized the '
       'pre-shedding equilibrium of the member (0.65, 0.20). At 20 kHz the equilibrium held, but the modulation index '
       'reached 1.09 even without shedding (0.94 in the averaged model), and every one of the six pre-specified ramped '
       'cases (the member (0.65, 0.20) and the two most optimistic A2 points, each with an amount between the frozen '
       'and reference margins and a control amount) ended in a voltage collapse within about 0.15 s after the ramp, '
       'including amounts that the averaged model places 10% inside the stable region. The direction test was '
       'therefore not evaluable in the switching model: with a 690-V source DC link the GFM operates close to its '
       'modulation limit, and saturation of the converter voltage, absent from the average-value model, dominates the '
       'response before the small-signal mode does.')
anchor = '![](../sekil/fig_stress_ramp.png)'
assert t.count(anchor) == 1
t = t.replace(anchor, EMT + '\n\n' + anchor)
for old in ('as in Section 6.4,', 'as in Section 6.4'):
    if old in t:
        t = t.replace(old, '(0.83 and 0.76 s in the historical record of Section 6.4),', 1)
        break
LIM = ('The switching-level check (Section 6.7) shows that the average-value results presume unsaturated converter '
       'voltages and continuous control: with sampled control and the given DC-link voltage, the tested model is '
       'unstable at 10 kHz and saturates at 20 kHz, so the margins reported here apply to converters with sufficient '
       'modulation headroom and control bandwidth.')
k = t.index('@@KEEP 713-715@@')
t = t[:k] + LIM + '\n' + t[k:]
p.write_text(t, encoding='utf-8')

s = ROOT / 'ms' / 's2_appG_plan.txt'
u = s.read_text(encoding='utf-8')
if '## G.7' not in u:
    u += ('\n\n## G.7 Switching-level check (protocols P92_EMT v1 and v2)\n\n'
          'Model: the equations of the engine with two-level regular-sampled triangular SPWM on both converters (leg '
          'voltage ±$V_{dc}$ in per unit, no common-mode injection), control outputs computed every switching period and '
          'applied one period later, switched voltages transformed back into the rotating frame, CPL DC link fed by the '
          'instantaneous switched power; fixed-step Heun integration. Protocol v1 (10 kHz, $\\Delta t = T_s/40$) was '
          'changed to v2 (20 kHz, $\\Delta t = T_s/20$) before any shedding case was run, because a 10⁻³-pu perturbation '
          'of the CPL current at $x_{0}$ grew from 1.7×10⁻³ to 15 pu within 20 ms at 10 kHz with the delay alone, '
          'whereas it decayed at 20 kHz and 50 kHz. Cases (ramp 0.25 s, horizon 2.75 s): the member (0.65, 0.20) with '
          '$\\Delta G = \\Delta G_{f}^{*} + 0.5(\\Delta G_{t}^{*} - \\Delta G_{f}^{*})$ (expected decaying) and '
          '$1.05\\,\\Delta G_{t}^{*}$ (expected growing); the A2 points A2-F00993 ($\\widehat{\\kappa}$ = −0.224) and '
          'A2-F01921 (−0.164) with $\\Delta G_{t}^{*} + 0.5(\\Delta G_{f}^{*} - \\Delta G_{t}^{*})$ (expected growing) and '
          '$0.90\\,\\Delta G_{t}^{*}$ (expected decaying). Result: all six cases were classified as diverged (deviation '
          'of the 2-ms average bus-voltage magnitude above 0.5 pu): the voltage collapsed to 0.86–1.02 pu below its '
          'post-shedding value about 0.1–0.15 s after the end of the ramp and stayed there. A diagnostic run without '
          'shedding (1 s) reached a modulation index of 1.09 and bus-voltage dips to 0.935 pu. H5 is not evaluable. A '
          'modulation scheme with more linear range (for example third-harmonic injection) or a higher DC-link voltage '
          'would change the model and was not tested. Outputs: S1 addition p92_20261026, folder out/y5.')
    s.write_text(u, encoding='utf-8')

q = ROOT / 'kod' / 'package92.py'
v = q.read_text(encoding='utf-8')
v = v.replace("'y4_ramp.py', 'y_chain.py',", "'y4_ramp.py', 'y5_emt.py', 'finalize_emt.py', 'y_chain.py',")
v = v.replace("shutil.copy(ROOT / 'ms' / 'ms_v2_plan.txt', K / 'kod')", "shutil.copy(ROOT / 'ms' / 'ms_v3_plan.txt', K / 'kod')")
v = v.replace("('Y5 EMT / bağımsız araç', 'YAPILMADI', 'MATLAB/Simulink sizde çalışıyor; PSID.jl (Julia) bu makinede yok'),",
              "('Y5 anahtarlamalı (EMT tipi) kontrol', 'YAPILDI — değerlendirilemez', '10 kHz: gecikme dengeyi bozuyor; 20 kHz: modülasyon sınırı, 6/6 durum rampadan sonra çöküyor (S2 G.7, §6.7). MATLAB Online oturumu kapalıydı; aynı denklemlerle yerelde Python.'),")
v = v.replace("('Uzunluğu 11–13 bin kelimeye indirme', 'YAPILMADI',", "('Uzunluğu 11–13 bin kelimeye indirme', 'KISMEN (~−1000 kelime)',")
q.write_text(v, encoding='utf-8')

LOG = RI / '00_decision_log.md'
L = LOG.read_text(encoding='utf-8')
if '| D-255 |' not in L:
    shutil.copy(LOG, RI / 'archive' / f'00_decision_log_before_D-255_{time.strftime("%Y%m%dT%H%M%S")}.md')
    row = ('| D-255 | 2026-10-26 | Y5 anahtarlamalı (PWM, örnekleme gecikmeli) kontrol ve kısaltma | Protokol P92_EMT v1 '
           '(10 kHz) öz-testte denge kararsız → v2 (20 kHz) hiçbir durum koşulmadan. Altı durumun altısı rampadan ~0.15 s '
           'sonra gerilim çöküşü (modülasyon indisi atmasız 1.09): H5 DEĞERLENDİRİLEMEZ. Makale v3: Sonnet alt-ajanıyla '
           '~1000 kelime kısaltma (sayı/iddia değişmedi), §6.7 ve §7.5’e anahtarlamalı kontrol sonucu, S2 G.7. | '
           'Kullanıcı talimatı; ön-kayıt | FINAL | — |')
    lines = L.split('\n')
    i = next(j for j, l in enumerate(lines) if l.startswith('| D-254 |'))
    lines.insert(i, row)
    LOG.write_text('\n'.join(lines), encoding='utf-8')
print('finalized')
