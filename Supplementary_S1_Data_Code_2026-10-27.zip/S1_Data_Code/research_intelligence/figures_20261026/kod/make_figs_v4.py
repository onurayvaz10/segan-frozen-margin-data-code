"""Figures of the shortened manuscript (ms_v4). Every plotted number of Figures 3, 8 and 11 is read from the archived
files named below; nothing is typed in. Figure 1(b, c) is a schematic with illustrative curves, labelled as such.

fig1_v4.png   Figure 1: (a) single-line diagram (drawing code of posthoc_revision_20261025/make_figures.py, unchanged);
              (b, c) schematic of the frozen margin, the re-equilibrated margin and the first-order tangent estimate.
fig3_v4.png   Figure 3: F2 grid as in posthoc_revision_20261025/make_figures.py, with neutral gate and band labels.
fig8_v4.png   Figure 8: as make_figs92.py, family names N2, N3 and N5, inset tick labels moved away from the main axis.
fig11_v4.png  Figure 11: as make_figs92.py, label placement of the two-solve secant and a neutral colour key.

Usage: python -I make_figs_v4.py MEMBERS_CSV TSV_POINTS_CSV Y2_ESTIMATORS_CSV
  MEMBERS_CSV        S1 v1.2: research_intelligence/cdl1/out/HDL2b_20261021_a/members.csv
  TSV_POINTS_CSV     S1 development_20261026: out/tsv/TSV_a/analysis/points.csv
  Y2_ESTIMATORS_CSV  S1 p92_20261026: out/summary/y2_estimators.csv
Output: sekil/<name>.png at 600 dpi.
"""
import csv
import math
import sys
from pathlib import Path

import matplotlib
import numpy as np

matplotlib.use('Agg')
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.patches import FancyBboxPatch  # noqa: E402

HERE = Path(__file__).resolve().parent
FIG = HERE.parent / 'sekil'
FIG.mkdir(exist_ok=True)
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8.5, 'axes.titlesize': 9, 'axes.labelsize': 8.5,
                     'legend.fontsize': 7.5, 'xtick.labelsize': 7.5, 'ytick.labelsize': 7.5,
                     'mathtext.fontset': 'dejavusans', 'axes.linewidth': 0.7, 'savefig.bbox': 'tight',
                     'savefig.pad_inches': 0.03})
W2 = 7.48
DPI = 600
COL = {'A2': '#1b9e77', 'B2': '#d95f02', 'C': '#7570b3'}
NAME = {'A2': 'N2', 'B2': 'N3', 'C': 'N5'}


def save(fig, name):
    fig.savefig(FIG / f'{name}.png', dpi=DPI)
    plt.close(fig)
    print('wrote', name)


def panel(ax, s, x=-0.12, y=1.03):
    ax.text(x, y, s, transform=ax.transAxes, fontsize=9.5, fontweight='bold', va='bottom')


def fnum(v):
    try:
        x = float(v)
        return x if math.isfinite(x) else float('nan')
    except (TypeError, ValueError):
        return float('nan')


def box(ax, x, y, w, h, txt, fc, ec, fs=7.6):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.4,rounding_size=1.2', fc=fc, ec=ec, lw=1.0))
    ax.text(x + w / 2, y + h / 2, txt, ha='center', va='center', fontsize=fs, linespacing=1.35)


def schematic(ax, kappa, rho2, xmax, ymax, title, legend):
    x = np.linspace(0, xmax, 400)
    ax.plot(x, x, color='0.35', lw=1.0, label=r'shed conductance $\Delta G$')
    ax.plot(x, np.ones_like(x), color='#2b5d8c', lw=1.2, ls='--', label=r'crossing value held at $x_0$')
    ax.plot(x, 1 + kappa * x + 0.5 * rho2 * x ** 2, color='#c0392b', lw=1.6,
            label=r'crossing value $\rho(x(\Delta G))$ after shedding')
    ax.plot(x, 1 + kappa * x, color='#1b9e77', lw=1.1, ls=':', label=r'tangent of slope $\kappa$')
    a, b = 0.5 * rho2, kappa - 1.0
    roots = [r.real for r in np.roots([a, b, 1.0]) if abs(r.imag) < 1e-12 and r.real > 0]
    gt = min(roots)
    pts = [(1.0, r'$\Delta G_f^*$', '#2b5d8c'), (gt, r'$\Delta G_t^*$', '#c0392b'),
           (1.0 / (1.0 - kappa), r'$\Delta G_{1st}^*$', '#1b9e77')]
    for g, _, c in pts:
        ax.plot([g, g], [0, g], color=c, lw=0.7, ls=(0, (1, 2)))
        ax.plot(g, g, 'o', color=c, ms=4, zorder=5)
    order = sorted(pts)
    ax.set_xticks([g for g, _, _ in order], [s for _, s, _ in order])
    ax.set_yticks([])
    ax.set_xlim(0, xmax)
    ax.set_ylim(0, ymax)
    ax.set_xlabel(r'shed conductance $\Delta G$')
    ax.set_ylabel('real part at the crossing')
    ax.text(0.30, 0.04, 'schematic', transform=ax.transAxes, ha='left', va='bottom', fontsize=6.8,
            style='italic', color='0.4')
    ax.set_title(title, fontsize=8, loc='left', pad=4)
    if legend:
        ax.legend(loc='upper left', fontsize=6.0, frameon=False, handlelength=2.2)


def fig1():
    fig = plt.figure(figsize=(W2, 5.0))
    axa = fig.add_axes([0, 0.52, 1, 0.46])
    axa.set_xlim(0, 100)
    axa.set_ylim(0, 40)
    axa.axis('off')
    box(axa, 1, 8, 25, 25, 'Grid-forming inverter\n(15 states)\nP–f / Q–V droop\nvirtual impedance $r_v, l_v$\n'
        'cascaded voltage/current PI\nactive damping, LCL filter', '#eaf1f8', '#2b5d8c')
    axa.plot([31, 31], [5, 36], color='k', lw=3)
    axa.text(31, 37.5, 'Bus 101 ($v_1$)', ha='center', fontsize=7.8)
    axa.annotate('', xy=(30.4, 20.5), xytext=(26.8, 20.5), arrowprops=dict(arrowstyle='->', lw=1))
    box(axa, 36, 13, 22, 15, 'Dynamic π-line (6 states)\n$r = 0.01$, $x = 0.10$ pu\n$b/2 = 0.005$ pu at each end',
        '#fbf6e6', '#9a7a14')
    axa.plot([31, 35.5], [20.5, 20.5], color='k', lw=1.2)
    axa.plot([58.6, 63], [20.5, 20.5], color='k', lw=1.2)
    axa.plot([63, 63], [5, 36], color='#a33', lw=3)
    axa.text(63, 37.5, 'Bus 102 = port $b$ ($v_2$, frame $F_0$)', ha='center', fontsize=7.8, color='#a33')
    box(axa, 69, 22, 30, 14, 'Active-rectifier CPL (12 states)\nPLL, LCL filter, DC link\n'
        'DC-voltage PI (settings S1–S3)\ninner current PI', '#fbecec', '#a33')
    box(axa, 69, 3, 30, 13, 'Sheddable resistive load\n$G_R \\rightarrow G_R-\\Delta G$, $0<\\Delta G\\leq G_R$\n'
        'shifts equilibrium $x(\\Delta G)$', '#eaf6ee', '#2f7d4a')
    for yy in (29, 9.5):
        axa.annotate('', xy=(68.6, yy), xytext=(63.4, yy), arrowprops=dict(arrowstyle='->', lw=1))
    axa.text(0.5, 39.5, '(a)', fontsize=9.5, fontweight='bold')
    axb = fig.add_axes([0.07, 0.07, 0.40, 0.36])
    axc = fig.add_axes([0.58, 0.07, 0.40, 0.36])
    schematic(axb, 0.30, -0.30, 1.6, 1.9, r'$\kappa>0$: frozen margin conservative', True)
    schematic(axc, -0.40, 0.50, 1.25, 1.35, r'$\kappa<0$: frozen margin optimistic', False)
    panel(axb, '(b)', x=-0.13, y=1.02)
    panel(axc, '(c)', x=-0.13, y=1.02)
    save(fig, 'fig1_v4')


def fig3(members_csv):
    members = list(csv.DictReader(open(members_csv, encoding='utf-8')))
    Pg = sorted(set(float(r['P_akt']) for r in members))
    fig, axs = plt.subplots(1, 2, figsize=(W2, 3.0))
    for ax, which in zip(axs, ['dGt', 'rel']):
        Gfull = [round(0.17 + 0.01 * i, 2) for i in range(18)]
        M = np.full((len(Gfull), len(Pg)), np.nan)
        for r_ in members:
            i = Gfull.index(round(float(r_['G_R']), 2))
            j = Pg.index(float(r_['P_akt']))
            if r_['in_E'] == 'True':
                M[i, j] = float(r_['dGt']) if which == 'dGt' else \
                    100 * (float(r_['dGt']) - float(r_['dGf'])) / float(r_['dGf'])
        im = ax.imshow(M, origin='lower', aspect='auto', cmap='viridis' if which == 'dGt' else 'magma_r',
                       extent=[-0.5, len(Pg) - 0.5, Gfull[0] - 0.005, Gfull[-1] + 0.005])
        ax.axhspan(0.235, 0.265, color='0.88', zorder=2)
        ax.text(2.5, 0.25, 'held-out band (not part of the family)', ha='center', va='center', fontsize=6.8, zorder=3)
        for r_ in members:
            if r_['in_E'] != 'True':
                j = Pg.index(float(r_['P_akt']))
                reason = r_['ne_reason']
                mk = 'x' if reason.startswith('K1') else ('^' if reason.startswith('K7') else 's')
                ax.plot(j, float(r_['G_R']), mk, color='k' if which == 'rel' else '#c00', ms=5, mew=1.2)
        ax.set_xticks(range(len(Pg)))
        ax.set_xticklabels([f'{p:g}' for p in Pg])
        ax.set_xlabel('CPL set-point $P_{set}$ (pu)')
        ax.set_ylabel('Pre-shedding conductance $G_R$ (pu)')
        cb = fig.colorbar(im, ax=ax, fraction=0.05, pad=0.03)
        cb.set_label('$\\Delta G_t^*$ (pu)' if which == 'dGt' else '$(\\Delta G_t^*-\\Delta G_f^*)/\\Delta G_f^*$ (%)')
    axs[0].plot([], [], 'x', color='#c00', label='operating limit')
    axs[0].plot([], [], '^', color='#c00', label='resolution check')
    axs[0].plot([], [], 's', color='#c00', label='unstable at $x_0$')
    axs[0].legend(loc='upper left', fontsize=6.3, frameon=True, framealpha=0.9)
    panel(axs[0], '(a)', x=-0.2, y=1.04)
    panel(axs[1], '(b)', x=-0.2, y=1.04)
    fig.tight_layout(w_pad=1.5)
    save(fig, 'fig3_v4')


def fig8(points_csv):
    pts = list(csv.DictReader(open(points_csv, encoding='utf-8')))
    fig, (a, b) = plt.subplots(1, 2, figsize=(W2, 3.1), gridspec_kw=dict(width_ratios=[1, 1.15], wspace=0.36))
    fams = ['A2', 'B2', 'C']
    for i, s in enumerate(fams):
        k = np.array([fnum(r['kappa']) for r in pts if r['system'] == s and r['source'] != 'search'])
        ks = np.array([fnum(r['kappa']) for r in pts if r['system'] == s and r['source'] == 'search'])
        y = i + np.random.default_rng(i).uniform(-0.18, 0.18, len(k))
        a.scatter(k, y, s=5, color=COL[s], alpha=0.55, lw=0)
        a.scatter(ks, i + 0.32 + 0 * ks, s=14, marker='v', facecolor='none', edgecolor=COL[s], lw=0.8)
    a.axvspan(-0.05, 0.05, color='#bbbbbb', alpha=0.35, lw=0)
    a.axvline(0, color='k', lw=0.6)
    a.set_yticks(range(3), ['N2\n(two-bus)', 'N3\n(three-bus)', 'N5\n(meshed)'])
    a.set_xlabel(r'first-order coefficient $\hat\kappa$')
    a.set_xlim(-0.6, 1.2)
    a.set_ylim(-0.6, 2.7)
    panel(a, '(a)', x=-0.2)
    ins = b.inset_axes([0.06, 0.56, 0.28, 0.34])
    for s in fams:
        rr = [r for r in pts if r['system'] == s and abs(fnum(r['kappa'])) >= 0.05 and r['ref_sign'] not in ('0', '0.0')]
        kk = np.array([fnum(r['kappa']) for r in rr])
        xr = np.where(kk < 1, kk / (1 - np.where(kk < 1, kk, 0)), np.inf)
        clip = xr > 1.45
        x = np.minimum(xr, 1.45)
        yv = 100 * np.array([fnum(r['rel_err']) for r in rr])
        src = np.array([r['source'] for r in rr])
        m = src != 'search'
        b.scatter(x[m & ~clip], yv[m & ~clip], s=7, color=COL[s], alpha=0.65, lw=0, label=f'{NAME[s]} (sampled)')
        b.scatter(x[m & clip], yv[m & clip], s=12, marker='>', color=COL[s], alpha=0.65, lw=0)
        b.scatter(x[~m], yv[~m], s=16, marker='v', facecolor='none', edgecolor=COL[s], lw=0.8,
                  label=f'{NAME[s]} (search)')
        neg = kk < 0
        ins.scatter(x[neg & m], yv[neg & m], s=10, color=COL[s], lw=0)
        ins.scatter(x[neg & ~m], yv[neg & ~m], s=16, marker='v', facecolor='none', edgecolor=COL[s], lw=0.8)
    for ax in (b, ins):
        ax.axhline(0, color='k', lw=0.6)
        ax.axvline(0, color='k', lw=0.6)
    b.set_xlim(-0.3, 1.5)
    b.set_ylim(-20, 106)
    ins.set_xlim(-0.22, 0.0)
    ins.set_ylim(-16, 0)
    ins.tick_params(labelsize=6)
    ins.yaxis.tick_right()
    ins.set_title(r'$\hat\kappa<0$ (18 points)', fontsize=6.5, pad=2)
    b.set_xlabel(r'predicted relative shift $\hat\kappa/(1-\hat\kappa)$ ($\triangleright$: clipped at 1.45)')
    b.set_ylabel(r'observed $(\Delta G_t^*-\Delta G_f^*)/\Delta G_f^*$ (%)')
    b.legend(loc='upper center', bbox_to_anchor=(0.5, -0.2), ncol=3, fontsize=6.3, frameon=False)
    panel(b, '(b)')
    save(fig, 'fig8_v4')


def fig11(points_csv, y2_csv):
    est = list(csv.DictReader(open(y2_csv, encoding='utf-8')))
    pts = list(csv.DictReader(open(points_csv, encoding='utf-8')))
    fig, (a, b) = plt.subplots(1, 2, figsize=(W2, 2.9), gridspec_kw=dict(wspace=0.34))
    lab = dict(frozen='frozen', first_order='first order', second_order='second order (Eq. 18)',
               secant_1='secant, 1 solve', secant_2='secant, 2 solves', newton_kappa_1=r'Newton-$\kappa$, 1 solve',
               kappa_started_secant_1=r'$\kappa$-started secant, 1 solve', newton_kappa_2=r'Newton-$\kappa$, 2 solves')
    off = dict(frozen=(4, 2, 'left'), first_order=(4, -9, 'left'), second_order=(4, 3, 'left'),
               secant_1=(4, -9, 'left'), secant_2=(-5, -11, 'right'), newton_kappa_1=(7, -3, 'left'),
               kappa_started_secant_1=(7, -3, 'left'), newton_kappa_2=(7, -3, 'left'))
    for r in est:
        n = int(r['extra_equilibria'])
        nk = r['estimator'].startswith('newton') or r['estimator'].startswith('kappa')
        xj = n + (0.12 if nk else -0.12)
        a.scatter(xj, fnum(r['MAE']), s=26, marker='D' if nk else 'o', color='#c0392b' if nk else '#2b5d8c', lw=0)
        dx, dy, ha = off[r['estimator']]
        a.annotate(lab[r['estimator']], (xj, fnum(r['MAE'])), fontsize=5.8, xytext=(dx, dy),
                   textcoords='offset points', ha=ha)
    a.set_yscale('log')
    a.set_xticks([0, 1, 2])
    a.set_xlim(-0.5, 3.1)
    a.set_xlabel('extra post-shedding equilibria per point')
    a.set_ylabel('MAE against the reference (pu)')
    a.text(0.98, 0.97, 'blue: frozen, Taylor and secant estimates\nred: estimators started or driven by $\\kappa$',
           transform=a.transAxes, fontsize=6, ha='right', va='top')
    panel(a, '(a)')
    rr = [r for r in pts if r.get('censored') in ('False', 'false', '0', '') and abs(fnum(r['kappa'])) >= 0.05
          and math.isfinite(fnum(r['eps2'])) and fnum(r['eps2']) > 0]
    e2 = np.array([fnum(r['eps2']) for r in rr])
    e1 = np.array([abs(fnum(r['relerr_first_order'])) for r in rr])
    e2n = np.array([abs(fnum(r['relerr_second_order'])) for r in rr])
    b.scatter(e2, 100 * e1, s=6, color='#2b5d8c', alpha=0.6, lw=0, label='first order')
    b.scatter(e2, 100 * e2n, s=6, color='#c0392b', alpha=0.6, lw=0, label='second order')
    xx = np.logspace(math.log10(max(e2.min(), 1e-4)), math.log10(e2.max()), 50)
    b.plot(xx, 100 * xx / 4, color='k', lw=0.8, ls='--', label=r'$\varepsilon_2/4$')
    b.set_xscale('log')
    b.set_yscale('log')
    b.set_xlabel(r'curvature indicator $\varepsilon_2=-2\hat\rho^{\prime\prime}\Delta G_f^*/(1-\hat\kappa)^2$')
    b.set_ylabel('|relative error| (%)')
    b.legend(frameon=False, loc='lower right')
    panel(b, '(b)')
    save(fig, 'fig11_v4')
    print('fig11 points with eps2 > 0:', len(rr))


if __name__ == '__main__':
    members_csv, points_csv, y2_csv = sys.argv[1:4]
    fig1()
    fig3(members_csv)
    fig8(points_csv)
    fig11(points_csv, y2_csv)
