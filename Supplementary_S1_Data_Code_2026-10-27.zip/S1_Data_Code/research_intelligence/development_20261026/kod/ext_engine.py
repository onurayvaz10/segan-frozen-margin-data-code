"""Extended engine for the 91+ development round (copy of bagimsiz/ind_engine.py, SHA-256 4f46d99a...9b43).

Extensions (all inactive by default; with every extension off the code path is the original one and the results are
bit-identical, checked by kod/t0_regression.py):
    * sysd['gfm_ilim'] = dict(Imax, p, kaw): smooth magnitude limiter on the GFM inner current reference,
      i_lim = i_ref * (1 + (|i_ref|/Imax)^p)^(-1/p), with back-calculation anti-windup on the voltage integrators,
      d xi/dt = e_v + (kaw/kiv) (i_lim - i_ref).
    * cpl par 'ilim' = dict(Imax, p, kaw): the same limiter on the CPL current reference (Idr, Iq_ref), anti-windup on
      the DC-voltage integrator eta.
    * cpl dict 'Q_set': reactive power drawn by the CPL in the dispatch (default 0, unity power factor).
    * any line list (meshed networks), any per-bus conductance vector G.

Original header follows.

Separately coded numerical implementation of the frozen-margin analysis (revision of 25 October 2026).

What this module is
    A second implementation of the test model and of every quantity that the manuscript reports, written in plain
    numpy without sympy and without importing any module of the original code base (rhab_model, e1_model, e1k_model,
    e1_core, hdl2b_run). It re-codes the device equations of Supplementary Methods S2, Appendix B, as numerical
    functions of a generic radial network (one grid-forming source, dynamic RL lines, bus shunt capacitances,
    any number of 12-state active-rectifier loads and resistive loads), so that the same code also builds the second
    test system of the revision.

What it is not
    It was written by the same authoring team, after the original code had been read.
    It is therefore a separately coded implementation, not an independent re-implementation by another group.

Numerical choices (all differ from the original code path)
    * Jacobian by complex step (exact to round-off), not by symbolic differentiation.
    * Set-points (P_ref, Q_ref, V_ref, V_ref_dc, Iq_ref) are solved together with the equilibrium in one augmented
      Newton system from the physical dispatch conditions (nominal frequency, |V_slack| = 1, CPL power P_set, CPL
      reactive power 0), not by the device-by-device initialisation of the original code.
    * Port admittance by an explicit Schur complement; crossings by a dense frequency scan plus secant refinement.
    * Reference margin by step-halving continuation in Delta G with eigenvalue-based bisection to 1e-9 pu.
"""
import math

import numpy as np

WB = 2 * math.pi * 60.0
NEWTON_FLOOR = 1e-9      # extension: a Newton iteration that stagnates below this residual is accepted (see newton_fixed_refs)


# ----------------------------------------------------------------------------------------------------------------
# Parameters (S2 Table B.1; author data in per unit). Kept as plain dicts so that the extensions can vary them.
# ----------------------------------------------------------------------------------------------------------------
def base_parameters():
    Ob = 2 * math.pi * 60
    Vb, Pb = 380.0, 10000.0
    Ib = Pb / Vb
    Zb = Vb / Ib
    Lb = Zb / Ob
    Cb = 1 / (Zb * Ob)
    Vb_dc = math.sqrt(8) / math.sqrt(3) * Vb
    Ib_dc = Pb / Vb_dc
    Zb_dc = Vb_dc / Ib_dc
    Cb_dc = 1 / (Zb_dc * Ob)
    # CPL DC-voltage loop: setting S3 of the study, K_pv = 2 A/V, K_iv = 600 A/(V s), K_pu = K_SI * V_b,dc / I_b
    cpl = dict(r_load=70.0 / Zb_dc, c_dc=2040e-6 / Cb_dc, rf=0.1 / Zb, lf=2.3e-3 / Lb, cf=8.8e-6 / Cb,
               rg=0.03 / Zb, lg=0.93e-3 / Lb, kp_pll=0.4, ki_pll=4.69, kpv=2.0 * (Vb_dc / Ib),
               kiv=600.0 * (Vb_dc / Ib), kpc=15.0 * (Ib / Vb), kic=30000.0 * (Ib / Vb), base_power=100.0)
    gfm = dict(Rp=0.02, wz=2 * math.pi * 20, kq=0.05, wf=2 * math.pi * 20, kpv=0.59, kiv=736.0, kffv=0.0,
               rv=0.0, lv=0.2, kpc=1.27, kic=14.3, kffi=0.0, wad=50.0, kad=0.2, lf=0.08, rf=0.003, cf=0.074,
               lg=0.2, rg=0.01, Vdc=690.0, w_ref=1.0, base_power=100.0)
    return dict(cpl=cpl, gfm=gfm, Sbase=100.0)


def two_bus_system(par=None):
    """Original test system: GFM at bus 0 ('101'), pi-line, CPL and G_R at bus 1 ('102')."""
    par = par or base_parameters()
    return dict(par=par, buses=['101', '102'], b_shunt=[0.005, 0.005],
                lines=[dict(f=0, t=1, r=0.01, x=0.1)], gfm_bus=0, cpls=[dict(bus=1, par=dict(par['cpl']))],
                shed_bus=1)


# ----------------------------------------------------------------------------------------------------------------
# State layout
# ----------------------------------------------------------------------------------------------------------------
GFM_NAMES = ['th', 'pm', 'qm', 'xid', 'xiq', 'gd', 'gq', 'phd', 'phq', 'Irc', 'Iic', 'Vrf', 'Vif', 'Irf', 'Iif']
CPL_NAMES = ['thp', 'eps', 'eta', 'vdc', 'gd', 'gq', 'Irc', 'Iic', 'Vrf', 'Vif', 'Irf', 'Iif']


class Layout:
    def __init__(self, sysd):
        self.sysd = sysd
        names = []
        nb = len(sysd['buses'])
        for k in range(nb):
            names += [f'V{k}:R', f'V{k}:I']
        for li in range(len(sysd['lines'])):
            names += [f'L{li}:R', f'L{li}:I']
        names += ['G:' + s for s in GFM_NAMES]
        for c in range(len(sysd['cpls'])):
            names += [f'C{c}:' + s for s in CPL_NAMES]
        self.names = names
        self.ix = {n: i for i, n in enumerate(names)}
        self.n = len(names)
        self.i_theta = self.ix['G:th']
        self.keep = [i for i in range(self.n) if i != self.i_theta]
        b = sysd['shed_bus']
        self.port = [self.ix[f'V{b}:R'], self.ix[f'V{b}:I']]
        self.M = self._mass()

    def _mass(self):
        s, p = self.sysd, self.sysd['par']
        M = np.ones(self.n)
        for k, bsh in enumerate(s['b_shunt']):
            M[self.ix[f'V{k}:R']] = M[self.ix[f'V{k}:I']] = bsh / WB
        g = p['gfm']
        for nm, val in (('Irc', g['lf']), ('Iic', g['lf']), ('Vrf', g['cf']), ('Vif', g['cf']),
                        ('Irf', g['lg']), ('Iif', g['lg'])):
            M[self.ix['G:' + nm]] = val / WB
        for c, cd in enumerate(s['cpls']):
            q = cd['par']
            for nm, val in (('Irc', q['lf']), ('Iic', q['lf']), ('Vrf', q['cf']), ('Vif', q['cf']),
                            ('Irf', q['lg']), ('Iif', q['lg'])):
                M[self.ix[f'C{c}:' + nm]] = val / WB
        return M


def park(th, r, i):
    c, s = np.cos(th), np.sin(th)
    return c * r + s * i, -s * r + c * i


def ipark(th, d, q):
    c, s = np.cos(th), np.sin(th)
    return c * d - s * q, s * d + c * q


# ----------------------------------------------------------------------------------------------------------------
# Right-hand side f(x) with frame frequency z = h(x) (GFM droop frequency), theta_oc row identically zero.
# refs = (P_ref, Q_ref, V_ref, [V_ref_dc_c, Iq_ref_c for each CPL]); G = conductance per bus (array).
# ----------------------------------------------------------------------------------------------------------------
def rhs(lay, x, refs, G):
    s, p = lay.sysd, lay.sysd['par']
    g = p['gfm']
    ix = lay.ix
    f = np.zeros(lay.n, dtype=np.result_type(x, refs, float))
    Pref, Qref, Vref = refs[0], refs[1], refs[2]
    X = lambda nm: x[ix[nm]]  # noqa: E731

    th, pm, qm = X('G:th'), X('G:pm'), X('G:qm')
    xid, xiq, gd, gq, phd, phq = X('G:xid'), X('G:xiq'), X('G:gd'), X('G:gq'), X('G:phd'), X('G:phq')
    Irc, Iic, Vrf, Vif, Irf, Iif = X('G:Irc'), X('G:Iic'), X('G:Vrf'), X('G:Vif'), X('G:Irf'), X('G:Iif')
    z = g['w_ref'] + g['Rp'] * (Pref - pm)            # GFM droop frequency = frame frequency
    p_e = Irf * Vrf + Iif * Vif
    q_e = -Iif * Vrf + Irf * Vif
    f[ix['G:pm']] = g['wz'] * (p_e - pm)
    f[ix['G:qm']] = g['wf'] * (q_e - qm)
    Voc = Vref + g['kq'] * (Qref - qm)
    Idf, Iqf = park(th, Irf, Iif)
    Idc, Iqc = park(th, Irc, Iic)
    Vdf, Vqf = park(th, Vrf, Vif)
    Vdr = Voc - g['rv'] * Idf + z * g['lv'] * Iqf
    Vqr = -g['rv'] * Iqf - z * g['lv'] * Idf
    f[ix['G:xid']] = Vdr - Vdf
    f[ix['G:xiq']] = Vqr - Vqf
    Idcr = g['kpv'] * (Vdr - Vdf) + g['kiv'] * xid - g['cf'] * z * Vqf + g['kffi'] * Idf
    Iqcr = g['kpv'] * (Vqr - Vqf) + g['kiv'] * xiq + g['cf'] * z * Vdf + g['kffi'] * Iqf
    lim = s.get('gfm_ilim')
    if lim is not None:
        sc = _soft_scale(Idcr, Iqcr, lim['Imax'], lim['p'])
        Idl, Iql = Idcr * sc, Iqcr * sc
        f[ix['G:xid']] = f[ix['G:xid']] + (lim['kaw'] / g['kiv']) * (Idl - Idcr)
        f[ix['G:xiq']] = f[ix['G:xiq']] + (lim['kaw'] / g['kiv']) * (Iql - Iqcr)
        Idcr, Iqcr = Idl, Iql
    f[ix['G:gd']] = Idcr - Idc
    f[ix['G:gq']] = Iqcr - Iqc
    Vdc_ = g['kpc'] * (Idcr - Idc) + g['kic'] * gd - z * g['lf'] * Iqc + g['kffv'] * Vdf - g['kad'] * (Vdf - phd)
    Vqc_ = g['kpc'] * (Iqcr - Iqc) + g['kic'] * gq + z * g['lf'] * Idc + g['kffv'] * Vqf - g['kad'] * (Vqf - phq)
    f[ix['G:phd']] = g['wad'] * (Vdf - phd)
    f[ix['G:phq']] = g['wad'] * (Vqf - phq)
    Vrc, Vic = ipark(th, Vdc_, Vqc_)                   # modulation x Vdc cancels (average converter)
    kb = s['gfm_bus']
    Vr_b, Vi_b = X(f'V{kb}:R'), X(f'V{kb}:I')
    f[ix['G:Irc']] = Vrc - Vrf - g['rf'] * Irc + z * g['lf'] * Iic
    f[ix['G:Iic']] = Vic - Vif - g['rf'] * Iic - z * g['lf'] * Irc
    f[ix['G:Vrf']] = Irc - Irf + z * g['cf'] * Vif
    f[ix['G:Vif']] = Iic - Iif - z * g['cf'] * Vrf
    f[ix['G:Irf']] = Vrf - Vr_b - g['rg'] * Irf + z * g['lg'] * Iif
    f[ix['G:Iif']] = Vif - Vi_b - g['rg'] * Iif - z * g['lg'] * Irf

    nb = len(s['buses'])
    inj_r = [0 * z for _ in range(nb)]
    inj_i = [0 * z for _ in range(nb)]
    kG = g['base_power'] / p['Sbase']
    inj_r[kb] = inj_r[kb] + kG * Irf
    inj_i[kb] = inj_i[kb] + kG * Iif

    for c, cd in enumerate(s['cpls']):
        q = cd['par']
        pre = f'C{c}:'
        Vref_dc, Iq_ref = refs[3 + 2 * c], refs[4 + 2 * c]
        thp, eps, eta, vdc = X(pre + 'thp'), X(pre + 'eps'), X(pre + 'eta'), X(pre + 'vdc')
        lgd, lgq = X(pre + 'gd'), X(pre + 'gq')
        lIrc, lIic, lVrf, lVif, lIrf, lIif = (X(pre + k) for k in ('Irc', 'Iic', 'Vrf', 'Vif', 'Irf', 'Iif'))
        lIdc, lIqc = park(thp, lIrc, lIic)
        Vdp, Vqp = park(thp, lVrf, lVif)
        dw = q['kp_pll'] * Vqp + q['ki_pll'] * eps
        f[ix[pre + 'thp']] = WB * (1 + dw - z)
        f[ix[pre + 'eps']] = Vqp
        Idr = q['kpv'] * (Vref_dc - vdc) + q['kiv'] * eta
        f[ix[pre + 'eta']] = Vref_dc - vdc
        clim = q.get('ilim')
        if clim is not None:
            sc = _soft_scale(Idr, Iq_ref, clim['Imax'], clim['p'])
            f[ix[pre + 'eta']] = f[ix[pre + 'eta']] + (clim['kaw'] / q['kiv']) * (Idr * sc - Idr)
            Idr, Iq_ref = Idr * sc, Iq_ref * sc
        f[ix[pre + 'gd']] = -Idr + lIdc
        f[ix[pre + 'gq']] = -Iq_ref + lIqc
        Vd_c = q['kpc'] * (-Idr + lIdc) + q['kic'] * lgd + (1 + dw) * q['lf'] * lIqc
        Vq_c = q['kpc'] * (-Iq_ref + lIqc) + q['kic'] * lgq - (1 + dw) * q['lf'] * lIdc
        lVrc, lVic = ipark(thp, Vd_c, Vq_c)
        Pcnv = lVrc * lIrc + lVic * lIic
        f[ix[pre + 'vdc']] = (WB / q['c_dc']) * (Pcnv / vdc - vdc / q['r_load'])
        bb = cd['bus']
        Vr_b, Vi_b = X(f'V{bb}:R'), X(f'V{bb}:I')
        f[ix[pre + 'Irc']] = lVrf - lVrc - q['rf'] * lIrc + z * q['lf'] * lIic
        f[ix[pre + 'Iic']] = lVif - lVic - q['rf'] * lIic - z * q['lf'] * lIrc
        f[ix[pre + 'Vrf']] = lIrf - lIrc + z * q['cf'] * lVif
        f[ix[pre + 'Vif']] = lIif - lIic - z * q['cf'] * lVrf
        f[ix[pre + 'Irf']] = Vr_b - lVrf - q['rg'] * lIrf + z * q['lg'] * lIif
        f[ix[pre + 'Iif']] = Vi_b - lVif - q['rg'] * lIif - z * q['lg'] * lIrf
        kL = q['base_power'] / p['Sbase']
        inj_r[bb] = inj_r[bb] - kL * lIrf
        inj_i[bb] = inj_i[bb] - kL * lIif

    for li, ln in enumerate(s['lines']):
        IlR, IlI = X(f'L{li}:R'), X(f'L{li}:I')
        a, b = ln['f'], ln['t']
        Va_r, Va_i, Vb_r, Vb_i = X(f'V{a}:R'), X(f'V{a}:I'), X(f'V{b}:R'), X(f'V{b}:I')
        f[ix[f'L{li}:R']] = (WB / ln['x']) * ((Va_r - Vb_r) - ln['r'] * IlR + z * ln['x'] * IlI)
        f[ix[f'L{li}:I']] = (WB / ln['x']) * ((Va_i - Vb_i) - ln['r'] * IlI - z * ln['x'] * IlR)
        inj_r[a] = inj_r[a] - IlR
        inj_i[a] = inj_i[a] - IlI
        inj_r[b] = inj_r[b] + IlR
        inj_i[b] = inj_i[b] + IlI

    for k in range(nb):
        Vr, Vi = X(f'V{k}:R'), X(f'V{k}:I')
        bsh = s['b_shunt'][k]
        f[ix[f'V{k}:R']] = inj_r[k] - G[k] * Vr + z * bsh * Vi
        f[ix[f'V{k}:I']] = inj_i[k] - G[k] * Vi - z * bsh * Vr
    return f


def _soft_scale(a, b, Imax, p):
    """Scale factor of the smooth magnitude limiter: |(a, b)| s ~= min(|(a, b)|, Imax), analytic for complex step."""
    m = (a * a + b * b) ** 0.5
    return (1.0 + (m / Imax) ** p) ** (-1.0 / p)


def jac(lay, x, refs, G, h=1e-30):
    """Complex-step Jacobian df/dx (exact to round-off)."""
    n = lay.n
    Jm = np.zeros((n, n))
    xc = np.array(x, dtype=complex)
    for k in range(n):
        xc[k] += 1j * h
        Jm[:, k] = np.imag(rhs(lay, xc, refs, G)) / h
        xc[k] -= 1j * h
    return Jm


def dfdG(lay, x, refs, G, bus):
    """Partial derivative of f with respect to the conductance at `bus` (linear, exact)."""
    d = np.zeros(lay.n)
    d[lay.ix[f'V{bus}:R']] = -x[lay.ix[f'V{bus}:R']]
    d[lay.ix[f'V{bus}:I']] = -x[lay.ix[f'V{bus}:I']]
    return d


# ----------------------------------------------------------------------------------------------------------------
# Dispatch: equilibrium and set-points from physical conditions (augmented Newton)
# ----------------------------------------------------------------------------------------------------------------
def n_refs(lay):
    return 3 + 2 * len(lay.sysd['cpls'])


def _constraints(lay, x, refs, P_set):
    """Dispatch conditions: P_ref = p_m (nominal frequency), Q_ref = q_m, slack bus |V| = 1 and angle 0,
    each CPL draws P_set[c] active and zero reactive power at its bus (as the original power-flow dispatch)."""
    s = lay.sysd
    ix = lay.ix
    kb = s['gfm_bus']
    out = [refs[0] - x[ix['G:pm']], refs[1] - x[ix['G:qm']],
           x[ix[f'V{kb}:R']] ** 2 + x[ix[f'V{kb}:I']] ** 2 - 1.0, x[ix[f'V{kb}:I']]]
    for c, cd in enumerate(s['cpls']):
        q = cd['par']
        kL = q['base_power'] / s['par']['Sbase']
        bb = cd['bus']
        Vr, Vi = x[ix[f'V{bb}:R']], x[ix[f'V{bb}:I']]
        Ir, Ii = kL * x[ix[f'C{c}:Irf']], kL * x[ix[f'C{c}:Iif']]
        out += [Vr * Ir + Vi * Ii - P_set[c], Vi * Ir - Vr * Ii - cd.get('Q_set', 0.0)]
    return np.array(out, dtype=np.result_type(x, refs, float))


def initial_guess(lay, P_set, G):
    """Phasor estimate of the equilibrium (flat voltages, steady currents); integrators and angles approximate."""
    s, p = lay.sysd, lay.sysd['par']
    ix = lay.ix
    nb = len(s['buses'])
    # radial power flow by fixed-point iteration (slack at GFM bus)
    Ybus = np.zeros((nb, nb), dtype=complex)
    for ln in s['lines']:
        y = 1 / complex(ln['r'], ln['x'])
        a, b = ln['f'], ln['t']
        Ybus[a, a] += y
        Ybus[b, b] += y
        Ybus[a, b] -= y
        Ybus[b, a] -= y
    for k in range(nb):
        Ybus[k, k] += 1j * s['b_shunt'][k] + G[k]
    Pc = np.zeros(nb, dtype=complex)
    for c, cd in enumerate(s['cpls']):
        Pc[cd['bus']] += P_set[c] + 1j * cd.get('Q_set', 0.0)
    kb = s['gfm_bus']
    V = np.ones(nb, dtype=complex)
    others = [k for k in range(nb) if k != kb]
    for _ in range(200):
        Iinj = -np.conj(Pc / V)
        Vn = V.copy()
        A = Ybus[np.ix_(others, others)]
        rhs_ = Iinj[others] - Ybus[np.ix_(others, [kb])][:, 0] * V[kb]
        Vn[others] = np.linalg.solve(A, rhs_)
        if np.max(np.abs(Vn - V)) < 1e-14:
            V = Vn
            break
        V = Vn
    x = np.zeros(lay.n)
    for k in range(nb):
        x[ix[f'V{k}:R']], x[ix[f'V{k}:I']] = V[k].real, V[k].imag
    for li, ln in enumerate(s['lines']):
        Il = (V[ln['f']] - V[ln['t']]) / complex(ln['r'], ln['x'])
        x[ix[f'L{li}:R']], x[ix[f'L{li}:I']] = Il.real, Il.imag
    Ig = (Ybus[kb] @ V) / (p['gfm']['base_power'] / p['Sbase'])
    g = p['gfm']
    Vf = V[kb] + Ig * complex(g['rg'], g['lg'])
    Ic = Ig + 1j * g['cf'] * Vf
    Vc = Vf + Ic * complex(g['rf'], g['lf'])
    th = math.atan2(Vc.imag, Vc.real)
    for nm, val in (('Irf', Ig.real), ('Iif', Ig.imag), ('Vrf', Vf.real), ('Vif', Vf.imag), ('Irc', Ic.real),
                    ('Iic', Ic.imag), ('th', th)):
        x[ix['G:' + nm]] = val
    S = Vf * np.conj(Ig)
    x[ix['G:pm']], x[ix['G:qm']] = S.real, S.imag
    vd, vq = park(th, Vf.real, Vf.imag)
    x[ix['G:phd']], x[ix['G:phq']] = vd, vq
    refs = [S.real, S.imag, abs(Vf)]
    for c, cd in enumerate(s['cpls']):
        q = cd['par']
        kL = q['base_power'] / p['Sbase']
        Vb = V[cd['bus']]
        Il = np.conj((P_set[c] + 1j * cd.get('Q_set', 0.0)) / Vb) / kL
        Vf = Vb - Il * complex(q['rg'], q['lg'])
        Ic = Il - 1j * q['cf'] * Vf
        Vc = Vf - Ic * complex(q['rf'], q['lf'])
        Pc0 = (Vc * np.conj(Ic)).real
        vdc = math.sqrt(max(Pc0, 1e-9) * q['r_load'])
        thp = math.atan2(Vf.imag, Vf.real)
        Id, Iq = park(thp, Ic.real, Ic.imag)
        pre = f'C{c}:'
        for nm, val in (('Irf', Il.real), ('Iif', Il.imag), ('Vrf', Vf.real), ('Vif', Vf.imag), ('Irc', Ic.real),
                        ('Iic', Ic.imag), ('thp', thp), ('vdc', vdc), ('eta', Id / q['kiv'])):
            x[ix[pre + nm]] = val
        refs += [vdc, Iq]
    return x, np.array(refs, dtype=float)


def dispatch(lay, P_set, G, tol=1e-13, maxit=60):
    """Solve f_keep(x, refs) = 0 and the dispatch conditions for (x, refs). Returns dict."""
    x, refs = initial_guess(lay, P_set, G)
    nr = n_refs(lay)
    keep = lay.keep
    hist = []
    for it in range(maxit):
        F = np.concatenate([rhs(lay, x, refs, G)[keep], _constraints(lay, x, refs, P_set)])
        r = float(np.max(np.abs(F)))
        hist.append(r)
        if r <= tol:
            break
        # augmented Jacobian by complex step over (x, refs)
        z0 = np.concatenate([x, refs])
        nz = len(z0)
        Ja = np.zeros((len(F), nz))
        for k in range(nz):
            zc = z0.astype(complex)
            zc[k] += 1e-30j
            xc, rc = zc[:lay.n], zc[lay.n:]
            Ja[:, k] = np.imag(np.concatenate([rhs(lay, xc, rc, G)[keep], _constraints(lay, xc, rc, P_set)])) / 1e-30
        dz = np.linalg.lstsq(Ja, -F, rcond=None)[0]
        lam = 1.0
        for _ in range(30):
            zt = z0 + lam * dz
            Ft = np.concatenate([rhs(lay, zt[:lay.n], zt[lay.n:], G)[keep],
                                 _constraints(lay, zt[:lay.n], zt[lay.n:], P_set)])
            if np.max(np.abs(Ft)) < r or lam < 1e-6:
                break
            lam /= 2
        x, refs = zt[:lay.n].copy(), zt[lay.n:].copy()
    ok = hist[-1] <= tol
    return dict(ok=ok, x=x, refs=refs, hist=hist, iters=len(hist))


def newton_fixed_refs(lay, x0, refs, G, tol=1e-12, maxit=40):
    """Equilibrium with set-points fixed (post-shedding), theta_oc fixed. Returns (x, ok, n_iter, n_jac)."""
    x = x0.copy()
    keep = lay.keep
    nj = 0
    r_prev = float('inf')
    for it in range(maxit):
        F = rhs(lay, x, refs, G)
        r = float(np.max(np.abs(F[keep])))
        if r <= tol:
            return x, True, it, nj
        # EXTENSION: accept stagnation at the round-off floor (below FLOOR) - the 70-state system C cannot reach 1e-12
        if it >= 2 and r <= NEWTON_FLOOR and r > 0.5 * r_prev:
            return x, True, it, nj
        r_prev = r
        Jm = jac(lay, x, refs, G)
        nj += 1
        dx = np.linalg.solve(Jm[np.ix_(keep, keep)], -F[keep])
        lam = 1.0
        for _ in range(20):
            xt = x.copy()
            xt[keep] += lam * dx
            if np.max(np.abs(rhs(lay, xt, refs, G)[keep])) < r:
                break
            lam /= 2
        x = xt
    rf = float(np.max(np.abs(rhs(lay, x, refs, G)[keep])))
    return x, rf <= tol or rf <= NEWTON_FLOOR, maxit, nj


# ----------------------------------------------------------------------------------------------------------------
# Small-signal quantities
# ----------------------------------------------------------------------------------------------------------------
def spectral_abscissa(lay, Jm):
    keep = lay.keep
    A = Jm[np.ix_(keep, keep)] / lay.M[keep][:, None]
    ev = np.linalg.eigvals(A)
    return float(np.max(ev.real)), ev


def port_admittance(lay, Jm, s):
    """Y(s) at the shedding bus: Schur complement of (sM - J)_keep onto the two port voltage states."""
    keep = lay.keep
    b = lay.port
    r = [k for k in keep if k not in b]
    K = s * np.diag(lay.M) - Jm
    Kbb = K[np.ix_(b, b)]
    Kbr = K[np.ix_(b, r)]
    Krb = K[np.ix_(r, b)]
    Krr = K[np.ix_(r, r)]
    return Kbb - Kbr @ np.linalg.solve(Krr, Krb)


def rot(phi):
    c, s = math.cos(phi), math.sin(phi)
    return np.array([[c, -s], [s, c]])


def to_F0(Y, theta_b):
    R = rot(-theta_b)
    return R @ Y @ R.T


def eig2(Y):
    ev, R = np.linalg.eig(Y)
    W = np.linalg.inv(R)                     # rows: left eigenvectors normalised so that W R = I
    return ev, R, W


def crossings(lay, Jm, theta_b, f_hz=None):
    """All crossings of Im(lambda) = 0 of the two eigenvalue branches of Y_F0(j w), w > 0, by a dense scan
    with continuity-based branch tracking and secant refinement. Returns list of dict(omega, rho, branch)."""
    if f_hz is None:
        f_hz = np.logspace(-2, 3.5, 6000)
    w = 2 * np.pi * f_hz
    lam = np.array([np.linalg.eigvals(to_F0(port_admittance(lay, Jm, 1j * wk), theta_b)) for wk in w])
    # branch tracking by minimum-distance assignment between consecutive points
    tr = lam.copy()
    for k in range(1, len(w)):
        a, b = tr[k - 1], lam[k]
        if abs(a[0] - b[0]) + abs(a[1] - b[1]) > abs(a[0] - b[1]) + abs(a[1] - b[0]):
            tr[k] = b[::-1]
    out = []

    def lam_at(wq, prev):
        ev = np.linalg.eigvals(to_F0(port_admittance(lay, Jm, 1j * wq), theta_b))
        return ev[np.argmin(np.abs(ev - prev))]

    for br in range(2):
        im = tr[:, br].imag
        for k in np.nonzero(np.sign(im[:-1]) * np.sign(im[1:]) < 0)[0]:
            wa, wb = w[k], w[k + 1]
            la, lb = tr[k, br], tr[k + 1, br]
            # secant / bisection on Im lambda along the branch
            for _ in range(100):
                wm = wa - la.imag * (wb - wa) / (lb.imag - la.imag)
                if not (min(wa, wb) < wm < max(wa, wb)):
                    wm = 0.5 * (wa + wb)
                lm = lam_at(wm, la + (lb - la) * (wm - wa) / (wb - wa))
                if abs(lm.imag) < 1e-13 * max(1.0, abs(lm)) or abs(wb - wa) < 1e-13 * wm:
                    break
                if np.sign(lm.imag) == np.sign(la.imag):
                    wa, la = wm, lm
                else:
                    wb, lb = wm, lm
            out.append(dict(omega=float(wm), rho=float(lm.real), branch=br, lam=lm))
    return out


def frozen_margin(lay, Jm, theta_b, G_R):
    """Frozen margin: smallest positive crossing real part not exceeding G_R (the shed amount must exist)."""
    cr = [c for c in crossings(lay, Jm, theta_b) if c['rho'] > 0]
    if not cr:
        return None
    c = min(cr, key=lambda d: d['rho'])
    return c


def eig_branch(lay, Jm, theta_b, omega, target):
    Y = to_F0(port_admittance(lay, Jm, 1j * omega), theta_b)
    ev, R, W = eig2(Y)
    i = int(np.argmin(np.abs(ev - target)))
    return ev[i], R[:, i], W[i], Y


def kappa_hat(lay, x0, refs, G, theta_b, crit, eps=1e-5):
    """First-order coefficient kappa = Re[(1 + j c) <dY/dDeltaG>] along the quasi-static path.

    xi = dx/dDeltaG from one linear solve; dY/dDeltaG by a central difference of Y along xi (refs and G_R fixed in Y);
    c from a central difference of the critical branch in omega. Returns dict with kappa, eta, c, xi."""
    keep = lay.keep
    sb = lay.sysd['shed_bus']
    Jm = jac(lay, x0, refs, G)
    # d f / d DeltaG = - d f / d G_shed
    rhs_ = dfdG(lay, x0, refs, G, sb)
    xi = np.zeros(lay.n)
    xi[keep] = np.linalg.solve(Jm[np.ix_(keep, keep)], rhs_[keep])    # J xi + (-df/dG) = 0  ->  J xi = df/dG
    w0 = crit['omega']
    lam0, v, wl, Y0 = eig_branch(lay, Jm, theta_b, w0, crit['lam'])
    sc = eps                                   # step in Delta G units along xi = dx/dDeltaG
    Jp = jac(lay, x0 + sc * xi, refs, G)
    Jn = jac(lay, x0 - sc * xi, refs, G)
    dY = (to_F0(port_admittance(lay, Jp, 1j * w0), theta_b) - to_F0(port_admittance(lay, Jn, 1j * w0), theta_b)) / (2 * sc)
    eta = complex(wl @ dY @ v / (wl @ v))
    dw = 1e-6 * w0
    lp = eig_branch(lay, Jm, theta_b, w0 + dw, lam0)[0]
    lm = eig_branch(lay, Jm, theta_b, w0 - dw, lam0)[0]
    dl = (lp - lm) / (2 * dw)
    c = dl.real / dl.imag
    kappa = (eta * complex(1.0, c)).real
    return dict(kappa=kappa, eta=eta, c=c, xi=xi, lam0=lam0, dlam_domega=dl, step=sc)


def rho_at(lay, x, refs, G, theta_b, crit_prev):
    """Crossing real part of the branch that continues the given crossing (local secant around previous omega)."""
    Jm = jac(lay, x, refs, G)
    w = crit_prev['omega']
    lam = eig_branch(lay, Jm, theta_b, w, crit_prev['lam'])[0]
    for _ in range(60):
        dw = 1e-7 * w
        lp = eig_branch(lay, Jm, theta_b, w + dw, lam)[0]
        dIm = (lp.imag - lam.imag) / dw
        wn = w - lam.imag / dIm
        lam = eig_branch(lay, Jm, theta_b, wn, lam)[0]
        if abs(wn - w) < 1e-12 * w:
            w = wn
            break
        w = wn
    return dict(omega=w, rho=lam.real, lam=lam)


def path_point(lay, x0, refs, G, dG, steps=1):
    """x(DeltaG) with refs fixed, by `steps` continuation steps of Newton from x0."""
    sb = lay.sysd['shed_bus']
    x = x0.copy()
    nj = ns = 0
    for k in range(1, steps + 1):
        Gk = G.copy()
        Gk[sb] = G[sb] - dG * k / steps
        x, ok, it, j = newton_fixed_refs(lay, x, refs, Gk)
        nj += j
        ns += 1
        if not ok:
            return None, nj, ns
    return x, nj, ns


def reference_margin(lay, x0, refs, G, dG_max, d_step, tol=1e-9, alpha_tab=0.0):
    """First Delta G in (0, dG_max] at which the spectral abscissa of A(x(DeltaG)) reaches -tab, where
    tab = alpha_tab (a number) or, if alpha_tab == 'rel', 1e-10 * ||A||_2 at that point (the definition of the
    sealed run). Step d_step with halving on Newton failure, then bisection to `tol`. Returns dict with counters."""
    sb = lay.sysd['shed_bus']
    cnt = dict(newton_solves=0, jacobians=0, eig_solves=0, points=0)
    keep = lay.keep

    def alpha(x, dg):
        Gk = G.copy()
        Gk[sb] = G[sb] - dg
        Jm = jac(lay, x, refs, Gk)
        cnt['jacobians'] += 1
        cnt['eig_solves'] += 1
        a = spectral_abscissa(lay, Jm)[0]
        if alpha_tab == 'rel':
            A = Jm[np.ix_(keep, keep)] / lay.M[keep][:, None]
            return a + 1e-10 * float(np.linalg.norm(A, 2))     # >= 0  <=>  a >= -tab
        return a + alpha_tab

    def solve(xs, dg):
        Gk = G.copy()
        Gk[sb] = G[sb] - dg
        xn, ok, it, nj = newton_fixed_refs(lay, xs, refs, Gk)
        cnt['newton_solves'] += 1
        cnt['jacobians'] += nj
        return xn if ok else None

    dg, x = 0.0, x0.copy()
    a = alpha(x, 0.0)
    if a >= 0:
        return dict(dGt=0.0, status='unstable at x0', **cnt)
    while dg < dG_max - 1e-15:
        h = min(d_step, dG_max - dg)
        xn = None
        for _ in range(8):
            xn = solve(x, dg + h)
            if xn is not None:
                break
            h /= 2
        if xn is None:
            return dict(dGt=dg, status='newton failure (fold?)', **cnt)
        cnt['points'] += 1
        an = alpha(xn, dg + h)
        if an >= 0:
            lo, hi, xlo = dg, dg + h, x
            while hi - lo > tol:
                mid = 0.5 * (lo + hi)
                xm = solve(xlo, mid)
                if xm is None:
                    hi = mid
                    continue
                if alpha(xm, mid) >= 0:
                    hi = mid
                else:
                    lo, xlo = mid, xm
            return dict(dGt=0.5 * (lo + hi), status='alpha', bracket=(lo, hi), **cnt)
        dg, x = dg + h, xn
    return dict(dGt=dG_max, status='censored (stable up to dG_max)', **cnt)
