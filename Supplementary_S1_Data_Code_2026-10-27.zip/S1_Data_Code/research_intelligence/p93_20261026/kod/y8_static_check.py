"""y8_run.py için AST statik denetimi, v2.1 (SABİT v1.0 §9 "Statik denetim" S1-S10; S11-S13 ek).
Yazar: B1 alt-ajanı run_tag Y8GK4M-W1, 2026-10-26 (revizyon turu 1; v1 arşivi kod/archive/y8_static_check_v1_20261026.py).
Betiği çalıştırmaz; yalnız ayrıştırır ve dosya hash'lerini okur.

  S1  import izin listesi: üst düzeyde os, argparse, copy, csv, hashlib, io, json, math, re, sys, time, traceback,
      numpy; y_common yalnız import_common(), ext_engine/ext_common/ext_engine_d/ext_common_d yalnız import_models(),
      make_engine_d yalnız import_generator() içinde; 'from' import yok; yasaklı adlar yok.
  S2  yasaklı çağrılar: eval, exec, compile (re.compile hariç), __import__, setattr, delattr, globals, locals, vars,
      breakpoint, input; subprocess; os.system/popen/startfile/remove/unlink/rmdir/removedirs/rename/replace/chmod/kill,
      os.exec*/spawn*/fork*.
  S3  open() yalnız _read_bytes / _write_text içinde; read_text/read_bytes/write_text/write_bytes, .open yok.
  S4  PINS = ön-kayıt §4.1 tablosu (sıra, yol, bayt, sha; PIN_ROOT = "G" öneki); DOC_PINS = §4.2; DERIVED ve PINS
      diskte; DERIVED başlıkta listeli; SABIT_REL beklenen ad; SABIT_SHA256 None (başlıkta yer tutucu) ya da diskte eşleşir.
  S5  körlenmiş/önceki sonuç dosya adları yok; points.csv/selection.json yalnız PINS içinde; çıktı adları yalnız OUT_*.
  S6  model modülleri yalnız verify_authorization'dan (ve prerun_gate'ten) sonra ya da --selftest'te pin doğrulamasından
      sonra import edilir; check_only model/hesap çağırmaz; X1 döngüsü -> 'if fails: raise' -> gecikmeli döngü.
  S7  modül niteliğine atama yok (yama yok); nitelik ataması yalnız sınıf yöntemlerinde self.<ad>; modül ve model
      nesnesi kökenli öğe ataması yok (modül düzeyindeki os.environ[_v] hariç); modüllerde yalnız izinli nitelikler.
  S8  scipy/sympy ve dış çözücü adları yok (np.linalg yalnız norm).
  S9  lay0.sysd'ye yazma yok: 'sysd' içeren tek öğe ataması delayed_layout'ta harfiyen
      "sysd_d['ctrl_delay'] = dict(Td=TD, rotate=ROTATE)" ve gövde deepcopy ile başlar.
  S10 os.environ okuması serbest; G92_* ataması yok; env_gate main() başında ve import_common içinde çağrılır;
      import_common U.TSV yolunu pin 4/5 ile karşılaştırır (R2-3).
  S11 ön-kayıt sabitleri (değer ve tür) ve metinleri ön-kayıtta; decide() dönüşleri satır 1..5 sırasında.
  S12 ön-kayıt çağrı biçimleri (C.BUILDERS(dict(srec)), C.stage1, E.dispatch, ED.dispatch, CD.stage1_at,
      ED.reference_margin(alpha_tab=tab0), C.ref_sign_of, U.y2_set, default_rng, rng.choice); çağrı yerleri sınırlı.
  S13 make_engine_d.py: import'lar argparse, ast, hashlib, os, sys; yasaklı çağrı yok; open yalnız _read_bytes /
      _write_bytes; SOURCES = §4.1 pin 1-2.
Kullanım: python -I -B y8_static_check.py [--root <G>] [--script <y8_run.py>]
Çıkış: 0 = GEÇTİ, 1 = KALDI.
"""
import argparse
import ast
import hashlib
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
TASLAK = ('protokol\\P93_GECIKME_On_Kayit_TASLAK_v0.2.md',
          '18a139a85f084368f7559595b1d0f1ec48a1661dac04b0527aaf89ecffea43d2')
SABIT_NAME = 'protokol\\P93_GECIKME_On_Kayit_v1.0_SABIT.md'
TOP_IMPORTS = {'os', 'argparse', 'copy', 'csv', 'hashlib', 'io', 'json', 'math', 're', 'sys', 'time', 'traceback',
               'numpy'}
MODEL_IMPORTS = {'y_common': 'import_common', 'ext_engine': 'import_models', 'ext_common': 'import_models',
                 'ext_engine_d': 'import_models', 'ext_common_d': 'import_models', 'make_engine_d': 'import_generator'}
FORBIDDEN_NAMES = {'scipy', 'sympy', 'subprocess', 'importlib', 'ctypes', 'multiprocessing', 'socket', 'urllib', 'http',
                   'shutil', 'pathlib', 'Path', 'pickle', 'marshal', 'tempfile', 'builtins', 'y8_delay'}
FORBIDDEN_CALLS = {'eval', 'exec', 'compile', '__import__', 'execfile', 'setattr', 'delattr', 'globals', 'locals',
                   'vars', 'breakpoint', 'input'}
ALLOWED_ATTR_CALLS = {('re', 'compile')}
FORBIDDEN_OS = {'system', 'popen', 'startfile', 'remove', 'unlink', 'rmdir', 'removedirs', 'rename', 'replace', 'chmod',
                'kill', 'truncate'}
FORBIDDEN_OS_PREFIX = ('exec', 'spawn', 'fork')
OPEN_ALLOWED_IN = {'_read_bytes', '_write_text'}
MODULE_ENV_TARGET = 'os.environ[_v]'
BLINDED_FRAGMENTS = ('stage2.jsonl', 'estimators.csv', 'directional.csv', 'envelope', 'failures.csv', 'results.json',
                     'quoted_numbers', 'limiter.jsonl', 'emt_v3', 'emt.jsonl', 'selftest_y3', 'selftest_y5', 'y5v3',
                     'newton.jsonl', 'cikti', 'out_ozet', 'p2_explore', 'p2_focus', 'p3_boundary', 'environment.json',
                     'log.txt')
PIN_ONLY = ('points.csv', 'selection.json')
OUTPUT_NAMES = ('y8.jsonl', 'sonuc.json', 'hukum.txt', 'girdi_pinleri.json', 'selftest_y8.json')
ALLOWED_ATTRS = {
    'E': {'dispatch', 'jac', '__file__'},
    'C': {'BUILDERS', 'stage1', 'ref_sign_of', 'lower_priority', 'E', 'TAU_K', 'TIE_K', '__file__'},
    'ED': {'Layout', 'dispatch', 'jac', 'reference_margin', 'path_point', 'spectral_abscissa', 'DELAY_NAMES',
           '__file__'},
    'CD': {'stage1_at', 'E', 'TAU_K', 'TIE_K', '__file__'},
    'U': {'num', 'y2_set', 'TAU', 'SEED', 'wilson', 'clean', 'load_points', 'selection', 'TSV', '__file__'},
    'MK': {'generate', '__file__'},
    'np': {'random', '__version__', 'linalg', 'ix_', 'argmax', 'array'},
}
SUB_ATTRS = {('np', 'random'): {'default_rng'}, ('np', 'linalg'): {'norm'}}
ENGINE_INTERNAL = {'rhs', '_delay', 'ipark', 'park', '_constraints', 'initial_guess', 'newton_fixed_refs', 'crossings',
                   'frozen_margin', 'kappa_hat', 'stage2', 'port_admittance', 'dfdG', '__dict__', '__code__',
                   '__globals__', 'modules', '__builtins__'}
PATCH_ROOTS = {'E', 'C', 'ED', 'CD', 'U', 'MK', 'np', 'sys', 'os', 'M', 'lay0', 'layd', 'json', 'math', 're', 'csv',
               'io', 'hashlib', 'copy'}
SOLVER_NAMES = {'odeint', 'solve_ivp', 'fsolve', 'brentq', 'brenth', 'minimize', 'root_scalar', 'least_squares',
                'linprog', 'milp', 'lstsq', 'solve', 'eig', 'eigvals', 'inv'}
CONSTS = {'TS': 50e-6, 'TD': 7.5e-5, 'ROTATE': True, 'TAU': 0.05, 'TIE_K': 2e-3, 'SEED': 20261026, 'SEED_OFFSET': 100,
          'FAMILIES': ('A2', 'B2', 'C'), 'N_PER_FAMILY': 14, 'N_OPT_REQUIRED': 18, 'POOL_MIN': 15, 'N_NEG_MIN': 8,
          'N_POS_MIN': 20, 'AGREE_MIN': 0.75, 'X1_KAPPA_REL': 1e-9, 'X1_DGF_ABS': 1e-10, 'DISPATCH_TOL': 1e-12,
          'RES_MAX': 1e-8, 'TAB_K': 1e-10, 'REF_STEP': 0.01, 'REF_TOL': 1e-9, 'THETA_M': 2.0, 'EQ_TOL': 1e-5,
          'VERDICTS': {1: 'ABORT', 2: 'NOT_EVALUABLE', 3: 'RET', 4: 'KISMİ', 5: 'TUTARLI'},
          'RUN_ID': 'P93_20261026_a', 'YETKI_REL': 'protokol\\P93_yetki_P93_20261026_a.json',
          'AUDIT_REL': 'protokol\\P93_kod_denetimi_D3.md', 'ACTION': 'ALLOW_P93_RUN', 'DAYANAK': 'D-260',
          'SCRIPT_KEYS': ('y8_run.py', 'y8_static_check.py', 'y8_synth_test.py', 'make_engine_d.py'),
          'DERIVED_KEYS': ('ext_engine_d.py', 'ext_common_d.py'), 'FORBIDDEN_RUN_TAGS': ('Y8GK4M',),
          'SELFTEST_FAMILY': 'A2', 'SABIT_REL': SABIT_NAME, 'FORBIDDEN_ENV': ('G92_S1', 'G92_OUT'), 'EXIT_USER_WAIT': 5}
PREREG_TEXTS = ('τ = 0.05', 'T_d = 7.5·10⁻⁵ s', 'T_s = 50 µs', 'default_rng(20261126 + i)', 'size=14',
                '|S_opt| = 18', '|havuz_F| ≥ 15', '10⁻⁹·max(1, |κ_csv|)', '|r0.dGf − dGf_csv| > 10⁻¹⁰', 'θ_M = 2',
                'ikisi de ≤ 10⁻⁵', 'alpha_tab = tab0', 'P93_yetki_P93_20261026_a.json', 'D-260', 'run_tag ≠ Y8GK4M',
                'n₋ < 8 ya da n₊ < 20', '< 0.75', 'tol=1e-12', 'copy.deepcopy(lay0.sysd)',
                'dict(Td=7.5e-5, rotate=True)', 'strict=True', 'P93_20261026_a', 'KISMİ', 'TUTARLI', 'NOT_EVALUABLE',
                'RET', 'ABORT', '0.01·dGf_d', 'tol=1e-9', 'U.wilson(n − k, n)[0]', "mode_status ∈ {'uyumlu', 'uygulanmaz'}",
                'G92_S1', 'G92_OUT', 'S3\'ün üç noktasında')
DERIVED_NAMES = ('make_engine_d.py', 'ext_engine_d.py', 'ext_common_d.py')
CALL_FORMS = {
    'point_x1': ["C.BUILDERS[pt['system']](dict(srec))", 'C.stage1(lay0, G, P, rec={}, strict=True)',
                 'x1_context(E, lay0, P, G)'],
    'x1_context': ['E.dispatch(lay0, P, G, tol=DISPATCH_TOL)', 'E.jac(lay0, x0, refs, G)'],
    'point_delayed': ["C.BUILDERS[pt['system']](dict(srec))", 'delayed_core(M, lay0, G, P, ctx, o)'],
    'delayed_core': ['delayed_layout(ED, lay0)', 'ED.dispatch(layd, P, G, tol=DISPATCH_TOL)',
                      'CD.stage1_at(layd, G, P, x0, refs, rec={}, strict=True)',
                      'ED.reference_margin(layd, x0, refs, G, dmax, REF_STEP * dGf_d, tol=REF_TOL, alpha_tab=tab0)'],
    'reference_fields': ['C.ref_sign_of(st, err, dGf_d)'],
    'sample_points': ['U.y2_set(rows)', 'np.random.default_rng(U.SEED + SEED_OFFSET + i)',
                      'rng.choice(len(pool), size=N_PER_FAMILY, replace=False)'],
    'mode_identity': ['ED.path_point(layd, x0, refs, G, dg_hi, steps=steps)', 'ED.jac(layd, x_hi, refs, G_hi)'],
}
CALL_SITES = (('stage1', {'point_x1'}), ('stage1_at', {'delayed_core'}), ('reference_margin', {'delayed_core'}),
              ('delayed_core', {'point_delayed'}), ('x1_context', {'point_x1'}),
              ('y2_set', {'sample_points'}), ('path_point', {'mode_identity'}))
DELAYED_LAYOUT_BODY = ['sysd_d = copy.deepcopy(lay0.sysd)', "sysd_d['ctrl_delay'] = dict(Td=TD, rotate=ROTATE)",
                       'return ED.Layout(sysd_d)']


def _read(path):
    with open(path, 'rb') as fh:
        return fh.read()


def sha(path):
    return hashlib.sha256(_read(path)).hexdigest()


def pin_path(root, rel):
    return os.path.join(root, *re.split(r'[\\/]', rel))


def prereg_tables(md):
    """§4.1 ('G\\' satırları) ve §4.2 satırları; "`G` = `...`" öneki."""
    m = re.search(r'`G` = `([^`]+)`', md)
    s41 = md.split('### 4.1', 1)[-1].split('### 4.2', 1)[0]
    s42 = md.split('### 4.2', 1)[-1].split('## 5.', 1)[0]
    rx = re.compile(r'^\|\s*`([^`]+)`[^|]*\|\s*(\d+)\s*\|\s*`?([0-9a-f]{64})`?\s*\|')
    t41 = []
    for line in s41.splitlines():
        r = rx.match(line)
        if r and r.group(1).startswith('G\\'):
            t41.append((r.group(1)[2:], int(r.group(2)), r.group(3)))
    t42 = []
    for line in s42.splitlines():
        r = rx.match(line)
        if r:
            p = r.group(1)
            p = ('research_intelligence\\gelistirme92_20261026\\' + p[2:]) if p.startswith('G\\') else \
                (p[2:] if p.startswith('…\\') else p)
            t42.append((p, int(r.group(2)), r.group(3)))
    return (m.group(1) if m else None), t41, t42


def top_assign(tree, name):
    hits = [n for n in tree.body if isinstance(n, ast.Assign) and len(n.targets) == 1
            and isinstance(n.targets[0], ast.Name) and n.targets[0].id == name]
    return hits[0] if len(hits) == 1 else None


def top_literal(tree, name):
    n = top_assign(tree, name)
    if n is None:
        return KeyError
    try:
        return ast.literal_eval(n.value)
    except ValueError:
        return ValueError


def parents_map(tree):
    out = {}

    def visit(node, chain):
        for ch in ast.iter_child_nodes(node):
            out[id(ch)] = chain
            nxt = ((ch.name,) + chain) if isinstance(ch, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) \
                else chain
            visit(ch, nxt)
    visit(tree, ())
    return out


def call_name(n):
    f = n.func
    return f.id if isinstance(f, ast.Name) else (f.attr if isinstance(f, ast.Attribute) else None)


def root_name(node):
    while isinstance(node, (ast.Attribute, ast.Subscript, ast.Call)):
        node = node.value if not isinstance(node, ast.Call) else node.func
    return node.id if isinstance(node, ast.Name) else None


def func_def(tree, name):
    hits = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name]
    return hits[0] if len(hits) == 1 else None


def calls_in(node, name):
    return sorted([n for n in ast.walk(node) if isinstance(n, ast.Call) and call_name(n) == name],
                  key=lambda n: (n.lineno, n.col_offset))


def assign_targets(n):
    if isinstance(n, ast.Assign):
        return n.targets
    if isinstance(n, (ast.AugAssign, ast.AnnAssign)):
        return [n.target]
    if isinstance(n, ast.Delete):
        return n.targets
    return []


def flat(t):
    return [x for e in t.elts for x in flat(e)] if isinstance(t, (ast.Tuple, ast.List)) else [t]


def sites(tree, chain, name):
    return [chain.get(id(n), ())[:1] for n in calls_in(tree, name)]


def check(script_path, root):
    src = _read(script_path)
    tree = ast.parse(src.decode('utf-8'))
    chain = parents_map(tree)
    doc_node = tree.body[0].value if tree.body and isinstance(tree.body[0], ast.Expr) else None
    docstring = ast.get_docstring(tree) or ''
    res = []

    # S1
    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Import):
            for a in n.names:
                top = a.name.split('.')[0]
                fn = chain.get(id(n), ())
                if top in MODEL_IMPORTS:
                    if fn[:1] != (MODEL_IMPORTS[top],):
                        bad.append('%s %s() dışında (satır %d)' % (a.name, MODEL_IMPORTS[top], n.lineno))
                elif top not in TOP_IMPORTS or fn:
                    bad.append('%s (satır %d)' % (a.name, n.lineno))
        elif isinstance(n, ast.ImportFrom):
            bad.append('from %s (satır %d)' % (n.module, n.lineno))
        elif isinstance(n, ast.Name) and n.id in FORBIDDEN_NAMES:
            bad.append('%s (satır %d)' % (n.id, n.lineno))
        elif isinstance(n, ast.Attribute) and n.attr in FORBIDDEN_NAMES:
            bad.append('.%s (satır %d)' % (n.attr, n.lineno))
    res.append(('S1 import izin listesi / yasaklı ad', not bad, bad))

    # S2
    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Call):
            f = n.func
            if isinstance(f, ast.Name) and f.id in FORBIDDEN_CALLS:
                bad.append('%s (satır %d)' % (f.id, n.lineno))
            if isinstance(f, ast.Attribute) and f.attr in FORBIDDEN_CALLS and \
                    (root_name(f), f.attr) not in ALLOWED_ATTR_CALLS:
                bad.append('.%s (satır %d)' % (f.attr, n.lineno))
            if isinstance(f, ast.Attribute) and root_name(f) == 'os' and (
                    f.attr in FORBIDDEN_OS or f.attr.startswith(FORBIDDEN_OS_PREFIX)):
                bad.append('os.%s (satır %d)' % (f.attr, n.lineno))
    res.append(('S2 yasaklı çağrı', not bad, bad))

    # S3
    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Call):
            name = call_name(n)
            if name in ('read_text', 'read_bytes', 'write_text', 'write_bytes', 'urlopen', 'fdopen'):
                bad.append('%s (satır %d)' % (name, n.lineno))
            if name == 'open':
                if isinstance(n.func, ast.Attribute):
                    bad.append('.open (satır %d)' % n.lineno)
                elif not (chain.get(id(n), ())[:1] and chain[id(n)][0] in OPEN_ALLOWED_IN):
                    bad.append('open (satır %d)' % n.lineno)
    for fn in OPEN_ALLOWED_IN:
        if func_def(tree, fn) is None:
            bad.append('%s yok' % fn)
    res.append(('S3 dosya erişimi tek nokta (_read_bytes/_write_text)', not bad, bad))

    # S4
    detail = []
    pins, derived, docp = top_literal(tree, 'PINS'), top_literal(tree, 'DERIVED'), top_literal(tree, 'DOC_PINS')
    pin_root = top_literal(tree, 'PIN_ROOT')
    sabit_rel, sabit_sha = top_literal(tree, 'SABIT_REL'), top_literal(tree, 'SABIT_SHA256')
    if sabit_rel != SABIT_NAME:
        detail.append('SABIT_REL beklenen ad değil')
    if sabit_sha is None:
        pre_rel, pre_sha, basis = TASLAK[0], TASLAK[1], 'TASLAK v0.2 (SABİT bekleniyor)'
        if 'SABİT hash: (fixation sonrası doldurulacak)' not in docstring:
            detail.append('SABİT yer tutucu başlıkta yok')
    else:
        pre_rel, pre_sha, basis = sabit_rel, sabit_sha, 'SABİT'
        if not isinstance(sabit_sha, str) or sabit_sha not in docstring:
            detail.append('SABİT hash başlıkta yok')
    pre_path = pin_path(root, pre_rel)
    md = ''
    if not os.path.isfile(pre_path) or sha(pre_path) != pre_sha:
        detail.append('ön-kayıt dosyası yok ya da hash uyuşmuyor: %s' % pre_rel)
    else:
        md = _read(pre_path).decode('utf-8')
    prefix, t41, t42 = prereg_tables(md)
    if not isinstance(pins, list) or not t41 or [p[0] for p in pins] != list(range(1, len(t41) + 1)):
        detail.append('PINS numaraları §4.1 ile aynı değil')
    else:
        for p, t in zip(pins, t41):
            if tuple(p[1:]) != t:
                detail.append('PIN %d != §4.1 %r' % (p[0], t))
    if pin_root != prefix:
        detail.append('PIN_ROOT != ön-kayıt G öneki')
    if not isinstance(docp, list) or [tuple(d) for d in docp] != t42:
        detail.append('DOC_PINS != §4.2 tablosu')
    if not isinstance(derived, list) or [d[0] for d in derived] != [6, 7, 8] or \
            [re.split(r'[\\/]', d[1])[-1] for d in derived] != list(DERIVED_NAMES):
        detail.append('DERIVED satırları 6-8 değil')
    else:
        for no, rel, size, h in derived:
            name = re.split(r'[\\/]', rel)[-1]
            line = [ln for ln in docstring.splitlines() if ('kod/' + name) in ln and h in ln]
            if len(line) != 1 or str(size) not in line[0]:
                detail.append('DERIVED %s başlıkta (bayt + sha) listelenmemiş' % name)
    for no, rel, size, h in (pins if isinstance(pins, list) else []) + (derived if isinstance(derived, list) else []):
        p = pin_path(root, rel)
        if not os.path.isfile(p) or os.path.getsize(p) != size or sha(p) != h:
            detail.append('pin %d diskte uyuşmuyor: %s' % (no, rel))
    if basis == 'SABİT':
        sp = pin_path(root, sabit_rel)
        if not os.path.isfile(sp) or sha(sp) != sabit_sha:
            detail.append('SABİT diskte uyuşmuyor')
    res.append(('S4 PINS == ön-kayıt §4 [%s]; DERIVED; disk' % basis, not detail, detail))

    # S5
    bad = []
    pins_node = top_assign(tree, 'PINS')
    pin_consts = {id(n) for n in ast.walk(pins_node)} if pins_node is not None else set()
    out_nodes = set()
    for n in tree.body:
        if isinstance(n, ast.Assign) and all(isinstance(t, (ast.Name, ast.Tuple)) for t in n.targets):
            names = [x.id for t in n.targets for x in flat(t) if isinstance(x, ast.Name)]
            if names and all(nm.startswith('OUT_') for nm in names):
                out_nodes |= {id(m) for m in ast.walk(n)}
    for n in ast.walk(tree):
        if isinstance(n, ast.Constant) and isinstance(n.value, str) and n is not doc_node:
            for b in BLINDED_FRAGMENTS:
                if b in n.value:
                    bad.append('%r (satır %d)' % (b, n.lineno))
            for b in PIN_ONLY:
                if b in n.value and id(n) not in pin_consts:
                    bad.append('%r PINS dışında (satır %d)' % (b, n.lineno))
            for b in OUTPUT_NAMES:
                if b in n.value and id(n) not in out_nodes:
                    bad.append('%r OUT_* dışında (satır %d)' % (b, n.lineno))
    res.append(('S5 körlenmiş/önceki sonuç adı yok; pin ve çıktı adları tek yerde', not bad, bad))

    # S6
    detail = []
    fmain, fev, fst, fco = (func_def(tree, x) for x in ('main', 'evaluate', 'selftest_mode', 'check_only'))
    if None in (fmain, fev, fst, fco):
        detail.append('main/evaluate/selftest_mode/check_only eksik')
    else:
        ev, va, pg = calls_in(tree, 'evaluate'), calls_in(fmain, 'verify_authorization'), calls_in(fmain, 'prerun_gate')
        ex = calls_in(fmain, 'exists')
        if len(ev) != 1 or chain.get(id(ev[0]), ())[:1] != ('main',):
            detail.append('evaluate() tek ve main() içinde değil')
        elif len(va) != 1 or len(pg) != 1 or not va[0].lineno <= pg[0].lineno < ev[0].lineno:
            detail.append('verify_authorization -> prerun_gate -> evaluate sırası değil')
        elif not any(pg[0].lineno < e.lineno < ev[0].lineno for e in ex):
            detail.append('çıktı klasörü denetimi prerun_gate ile evaluate arasında değil')
        for name, allowed in (('import_models', {'evaluate', 'selftest_mode'}),
                              ('import_common', {'check_only', 'import_models', 'prerun_gate'}),
                              ('import_generator', {'check_only'}),
                              ('point_x1', {'evaluate', 'selftest_mode'}),
                              ('point_delayed', {'evaluate', 'selftest_mode'}),
                              ('prerun_gate', {'main'}), ('selftest_mode', {'main'}), ('check_only', {'main'})):
            ss = sites(tree, chain, name)
            if not ss or any((not s) or s[0] not in allowed for s in ss):
                detail.append('%s yalnız %s içinde çağrılmalı (%r)' % (name, sorted(allowed), ss))
        for n in ast.walk(fco):
            if isinstance(n, ast.Call) and call_name(n) in ('evaluate', 'import_models', 'point_x1', 'point_delayed',
                                                            'selftest_mode', 'delayed_layout', 'lower_priority'):
                detail.append('check_only içinde %s' % call_name(n))
        for f, label in ((fev, 'evaluate'), (fst, 'selftest_mode')):
            vp, im = calls_in(f, 'verify_pins'), calls_in(f, 'import_models')
            if not vp or not im or not vp[0].lineno < im[0].lineno:
                detail.append('%s: verify_pins import_models\'ten önce değil' % label)
        px, pdl = calls_in(fev, 'point_x1'), calls_in(fev, 'point_delayed')
        raises = [n for n in ast.walk(fev) if isinstance(n, ast.If) and ast.unparse(n.test) == 'fails'
                  and any(isinstance(s, ast.Raise) for s in n.body)]
        if len(px) != 1 or len(pdl) != 1 or not raises or not (px[0].lineno < raises[0].lineno < pdl[0].lineno):
            detail.append("evaluate: X1 döngüsü -> 'if fails: raise' -> gecikmeli döngü sırası değil")
    res.append(('S6 model importu yetki/pin doğrulamasından sonra', not detail, detail))

    # S7
    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Attribute):
            if n.attr in ENGINE_INTERNAL:
                bad.append('.%s (satır %d)' % (n.attr, n.lineno))
            if isinstance(n.value, ast.Name) and n.value.id in ALLOWED_ATTRS and n.attr not in ALLOWED_ATTRS[n.value.id]:
                bad.append('%s.%s (satır %d)' % (n.value.id, n.attr, n.lineno))
            if isinstance(n.value, ast.Attribute) and isinstance(n.value.value, ast.Name):
                key = (n.value.value.id, n.value.attr)
                if key in SUB_ATTRS and n.attr not in SUB_ATTRS[key]:
                    bad.append('%s.%s.%s (satır %d)' % (key[0], key[1], n.attr, n.lineno))
        for t in assign_targets(n):
            for tt in flat(t):
                if isinstance(tt, ast.Attribute):
                    fn = chain.get(id(n), ())
                    if not (isinstance(tt.value, ast.Name) and tt.value.id == 'self' and len(fn) >= 2):
                        bad.append('nitelik ataması: %s (satır %d)' % (ast.unparse(tt), n.lineno))
                elif isinstance(tt, ast.Subscript):
                    env_ok = ast.unparse(tt) == MODULE_ENV_TARGET and not chain.get(id(n), ())
                    if root_name(tt) in PATCH_ROOTS and not env_ok:
                        bad.append('modül/model öğe ataması: %s (satır %d)' % (ast.unparse(tt), n.lineno))
    res.append(('S7 yama yok; izinli nitelikler', not bad, bad))

    # S8
    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Call) and call_name(n) in SOLVER_NAMES:
            bad.append('%s (satır %d)' % (call_name(n), n.lineno))
        if isinstance(n, ast.Attribute) and n.attr in SOLVER_NAMES:
            bad.append('.%s (satır %d)' % (n.attr, n.lineno))
        if isinstance(n, ast.Name) and n.id in SOLVER_NAMES | {'scipy', 'sympy'}:
            bad.append('%s (satır %d)' % (n.id, n.lineno))
    res.append(('S8 scipy/sympy/çözücü adı yok', not bad, bad))

    # S9
    bad = []
    for n in ast.walk(tree):
        for t in assign_targets(n):
            for tt in flat(t):
                if isinstance(tt, (ast.Subscript, ast.Attribute)) and 'sysd' in ast.unparse(tt):
                    if not (chain.get(id(n), ())[:1] == ('delayed_layout',) and ast.unparse(n) == DELAYED_LAYOUT_BODY[1]):
                        bad.append('sysd ataması: %s (satır %d)' % (ast.unparse(n), n.lineno))
    fd = func_def(tree, 'delayed_layout')
    if fd is None:
        bad.append('delayed_layout yok')
    else:
        body = [ast.unparse(s) for s in fd.body if not (isinstance(s, ast.Expr) and isinstance(s.value, ast.Constant))]
        if body != DELAYED_LAYOUT_BODY:
            bad.append('delayed_layout gövdesi harfiyen değil: %r' % body)
    res.append(('S9 lay0.sysd yazılmaz (deepcopy + ctrl_delay)', not bad, bad))

    # S10
    detail = []
    fdocs = {id(f.body[0].value) for f in ast.walk(tree) if isinstance(f, ast.FunctionDef) and f.body
             and isinstance(f.body[0], ast.Expr) and isinstance(f.body[0].value, ast.Constant)}
    for n in ast.walk(tree):
        for t_ in assign_targets(n):
            for tt in flat(t_):
                if 'os.environ' in ast.unparse(tt) and ast.unparse(tt) != MODULE_ENV_TARGET:
                    detail.append('environ ataması: %s (satır %d)' % (ast.unparse(n), n.lineno))
        if isinstance(n, ast.Call) and call_name(n) in ('putenv', 'setdefault', 'update', 'pop') \
                and 'os.environ' in ast.unparse(n.func):
            detail.append('environ değiştirme: %s (satır %d)' % (ast.unparse(n), n.lineno))
        if isinstance(n, ast.Constant) and isinstance(n.value, str) and 'G92_' in n.value and n is not doc_node \
                and id(n) not in fdocs:
            if chain.get(id(n), ()) or not any(id(n) in {id(m) for m in ast.walk(a)} for a in
                                               [top_assign(tree, 'FORBIDDEN_ENV')] if a is not None):
                detail.append('G92_ dizgesi FORBIDDEN_ENV dışında (satır %d)' % n.lineno)
    if top_literal(tree, 'FORBIDDEN_ENV') != ('G92_S1', 'G92_OUT'):
        detail.append('FORBIDDEN_ENV')
    fm, fic = func_def(tree, 'main'), func_def(tree, 'import_common')
    if fm is None or fic is None or not calls_in(fm, 'env_gate') or not calls_in(fic, 'env_gate'):
        detail.append('env_gate main() ve import_common() içinde çağrılmıyor')
    elif fm is not None:
        eg, ap_ = calls_in(fm, 'env_gate'), calls_in(fm, 'parse_known_args')
        if not ap_ or not eg[0].lineno < ap_[0].lineno:
            detail.append('env_gate main() başında değil')
    if fic is not None and not ({'U.TSV'} <= {ast.unparse(n) for n in ast.walk(fic) if isinstance(n, ast.Attribute)}):
        detail.append('import_common U.TSV yolunu denetlemiyor')
    res.append(('S10 ortam kapısı (G92_*), U yolu', not detail, detail))

    # S11
    detail = []
    for k, v in CONSTS.items():
        got = top_literal(tree, k)
        if got != v or type(got) is not type(v):
            detail.append('%s = %r (beklenen %r)' % (k, got, v))
    for t in PREREG_TEXTS:
        if t not in md:
            detail.append('ön-kayıtta yok: %r' % t)
    fd = func_def(tree, 'decide')
    if fd is None:
        detail.append('decide yok')
    else:
        order = [ast.unparse(n.value) for n in sorted((n for n in ast.walk(fd) if isinstance(n, ast.Return)),
                                                      key=lambda n: n.lineno)]
        if order != ['(%d, VERDICTS[%d])' % (i, i) for i in range(1, 6)]:
            detail.append('decide dönüş sırası %r' % order)
    res.append(('S11 ön-kayıt sabitleri ve karar sırası', not detail, detail))

    # S12
    detail = []
    for fname, forms in CALL_FORMS.items():
        fd = func_def(tree, fname)
        if fd is None:
            detail.append('%s yok' % fname)
            continue
        got = {ast.unparse(n) for n in ast.walk(fd) if isinstance(n, ast.Call)}
        for f in forms:
            if f not in got:
                detail.append('%s: %s yok' % (fname, f))
    for name, allowed in CALL_SITES:
        ss = sites(tree, chain, name)
        if not ss or any((not s) or s[0] not in allowed for s in ss):
            detail.append('%s çağrı yerleri %r' % (name, ss))
    res.append(('S12 ön-kayıt çağrı biçimleri', not detail, detail))

    # S13
    detail = []
    mk = pin_path(root, 'kod\\make_engine_d.py')
    try:
        mt = ast.parse(_read(mk).decode('utf-8'))
        mchain = parents_map(mt)
        for n in ast.walk(mt):
            if isinstance(n, ast.Import):
                for a in n.names:
                    if a.name not in ('argparse', 'ast', 'hashlib', 'os', 'sys'):
                        detail.append('import %s' % a.name)
            elif isinstance(n, ast.ImportFrom):
                detail.append('from %s' % n.module)
            elif isinstance(n, ast.Call):
                nm = call_name(n)
                if nm in FORBIDDEN_CALLS or (nm in FORBIDDEN_OS and root_name(n.func) == 'os'):
                    detail.append('%s (satır %d)' % (nm, n.lineno))
                if nm == 'open' and mchain.get(id(n), ())[:1] not in (('_read_bytes',), ('_write_bytes',)):
                    detail.append('open (satır %d)' % n.lineno)
        want = {'ext_engine.py': tuple(t41[0][1:]) if len(t41) > 0 else None,
                'ext_common.py': tuple(t41[1][1:]) if len(t41) > 1 else None}
        if top_literal(mt, 'SOURCES') != want:
            detail.append('SOURCES != §4.1 pin 1-2')
    except (OSError, SyntaxError) as e:
        detail.append('make_engine_d.py okunamadı: %s' % e)
    res.append(('S13 make_engine_d.py', not detail, detail))
    return res, hashlib.sha256(src).hexdigest(), basis


def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except (AttributeError, ValueError):
        pass
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default=os.path.dirname(HERE))
    ap.add_argument('--script', default=os.path.join(HERE, 'y8_run.py'))
    a = ap.parse_args(argv)
    res, h, basis = check(a.script, a.root)
    print('y8_run.py sha256: %s' % h)
    print('y8_static_check.py sha256: %s' % sha(os.path.abspath(__file__)))
    if basis != 'SABİT':
        print('UYARI: SABİT hash betikte doldurulmadı; S4/S11 %s ile denetlendi' % basis)
    ok = True
    for name, passed, detail in res:
        print('%-58s %s%s' % (name, 'GEÇTİ' if passed else 'KALDI',
                              '' if passed else '  ' + '; '.join(map(str, detail))))
        ok &= passed
    print('STATİK DENETİM: %s' % ('GEÇTİ' if ok else 'KALDI'))
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
