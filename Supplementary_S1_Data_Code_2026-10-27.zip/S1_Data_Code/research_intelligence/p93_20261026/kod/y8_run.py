"""P93 (kontrol gecikmesi altında işaret kuralı; H-P93) tek koşu betiği, v2.

SABİT hash: 9931723814d718dee6ab77f4dc6ec11c051daa4cdb6d093b4de812e456e7d173
SABİT: protokol/P93_GECIKME_On_Kayit_v1.0_SABIT.md (43478 bayt; D2 ACCEPT_FOR_FIXATION, R2-1...R2-8 işlendi)
Önceki dayanak: protokol/P93_GECIKME_On_Kayit_TASLAK_v0.2.md (38343 bayt, 18a139a8...43d2). PINS = SABİT §4.1 tablosu.
Türetilen dosyaların SABİT ek notu ile pinlenmesi SABİT §4.1 / R2-7'ye göre ayrı adımdır; bu betik onları DERIVED
literali ve yetki dosyasıyla doğrular.
Yazar: B1 alt-ajanı run_tag Y8GK4M-W1, 2026-10-26 (P93-B1, revizyon turu 1). v1 arşivi: kod/archive/y8_run_v1_20261026.py
(46553 bayt, d0fbf7272e9172a6e3454452aa6676255d3f3f57e7edd3927aea886017639dc4). Gerçek kip B2, B3 (ayrı koşu;
protokol/P93_kod_denetimi_D3.md) ve protokol/P93_yetki_P93_20261026_a.json olmadan çalışmaz; B4 run_tag'i Y8GK4M
(Y8GK4M-W1/W2 dahil) olamaz (ön-kayıt §10).

Türetilen dosyalar (ön-kayıt §4.1 "Türetilen dosyalar", §5.2 a-b; DERIVED literal tablosu ve yetki ile pinlenir)
  kod/make_engine_d.py   10158 bayt  9fc63b1e054f8410056de27fa54d7940ea167c15d8e81429c7f8bdbca0085f49
  kod/ext_engine_d.py    30767 bayt  780c4d95a6748a137fd6ba0045603dda025c001b4d073bd3553fe62a76851cea
  kod/ext_common_d.py    21470 bayt  98747eef15690f25b882850a04e77f53c22bbb21375fa7750b1a0c08242da727
(v1 ile aynı; v0.2 §5.1-§5.2 türetilen dosyalarda değişiklik gerektirmedi.)

Ön-kayıt v0.2 bölümü -> fonksiyon
  §4.1 pinler ........... PINS, DERIVED, verify_pins, pin_list_sha256, rehash_pins; §4.2 DOC_PINS (yalnız bilgi)
  §5.1-5.2 M-D .......... ext_engine_d (make_engine_d); delayed_layout (deepcopy + ctrl_delay); gecikme kapalı = E/C
  §5.3 hesap kalıbı ..... point_delayed: ED.dispatch(tol=1e-12) -> CD.stage1_at(x0, refs) -> ED.reference_margin
                          (alpha_tab = tab0) -> C:414-427 alanları (reference_fields) -> mode_identity, eq_identity
  §5.4 yön, birincil .... primary_set, strata_counts, ne_reason
  §5.5 örneklem ......... parse_points, parse_selection, sample_points, sample_ids_sha256, sample_gate
  §5.6 X1 / X2 / X3 ..... point_x1 + x1_check / verify_authorization, prerun_gate, klasör reddi, rehash_pins / ne_reason
  §5.7 denge kimliği .... eq_identity (EQ_TOL = 1e-5)
  §5.8 mod kimliği ...... mode_identity (THETA_M = 2)
  §5.9 alpha_tab ........ point_x1 (tab0 = 1e-10 ||A_0||_2, gecikmesiz denge), point_delayed (tab_d, rapor)
  §6 yalnız rapor ....... report_only (a)-(m)
  §8 karar tablosu ...... decide (ilk eşleşen satır)
  §9 kipler ............. main, check_only, selftest_mode (S3 + S9), evaluate, write_outputs
  §10 yetki ............. verify_authorization, prerun_gate

Yazar uygulama seçimleri (B3 kabul ya da red eder; v1'den süren ve v2'de yeni olanlar)
  Y8-B1-a  Pinli girdiler bir kez okunur, bayt + sha256 doğrulanır ve aynı baytlardan ayrıştırılır (U.load_points /
           U.selection ile aynı ayrıştırma: UTF-8, evrensel satır sonu, csv.DictReader + U.num; json.loads); ikinci okuma
           yoktur. Eşdeğerlik öz-testte (--selftest) gerçek dosyada sınanır.
  Y8-B1-b  X1 evresi 60 noktanın tamamında gecikmeli evreden önce (§5.6). X1 bir noktada kalırsa ABORT ve hiçbir
           gecikmeli hesap yapılmaz. X1 evresinde ayrı d0 = E.dispatch(lay0, P, G, tol=1e-12) (R2-8): kabul §5.3-1,
           değilse ya da tab0 hesaplanamaz/sonlu değilse X1 kalır (ABORT).
  Y8-B1-c  Gecikmeli evrede her istisna -> NE-nokta ('istisna' + tür; traceback sonu kaydedilir). Kod hatası türleri
           (KeyError, TypeError, AttributeError, NameError, IndexError, UnboundLocalError) sonuc.json'da ayrıca listelenir.
  Y8-B1-d  'G1' (gecikmeli dispatch kabul edilmedi) status 'stage1_excluded', excl 'G1' olarak kaydedilir.
  Y8-B1-e  Birincil küme §5.4: mode_status in {'uyumlu', 'uygulanmaz'} (R2-1). mode_status: excl != None ya da
           ref_sign None -> None (§5.8); ref_status 'alpha' dışındaki (sansürlü, fold) -> 'uygulanmaz'.
  Y8-B1-f  Denge kimliğinde refs ölçüsü durumlarla aynıdır: max_j |refs_d,j - refs_0,j| / max(1, |refs_0,j|).
  Y8-B1-g  X2 klasör kuralı: out/<run_id>/ HERHANGİ bir durumda varsa (exit_code.txt olmasa da) koşu başlamaz; yarım
           koşu sürdürülmez (tek-kosu-kapisi §4). X2 başta kalırsa klasör yazılmaz (KAPI, çıkış 3); koşu sonunda
           bütün pinler yeniden hash'lenir, değişim -> ABORT (mühürlü).
  Y8-B1-h  Yetki dosyası alanları (§10): action, run_id (= RUN_ID), sabit_sha256, script_sha256 {y8_run.py,
           y8_static_check.py, y8_synth_test.py, make_engine_d.py}, derived_sha256 {ext_engine_d.py, ext_common_d.py},
           pin_list_sha256 (PINS + DERIVED), sample_ids_sha256, python, numpy, b2_sha256sums {research_intelligence'a
           göre yol: SHA256SUMS dosyasının sha256'sı; boş olamaz, her dosya diskte eşleşmeli}, code_audit_report {path =
           protokol\\P93_kod_denetimi_D3.md, sha256}, dayanak (D-260 içermeli), yazan (boş değil, 'Y8GK4M' içeremez).
  Y8-B1-i  sample_ids_sha256, python ve numpy sürümleri yetki doğrulamasından sonra, model importundan ve çıktı klasörü
           açılmadan önce prerun_gate'te yeniden doğrulanır (uyuşmazlık KAPI, X2); ön kabuller (§5.5) de burada.
  Y8-B1-j  --check-only make_engine_d.generate() ile bellekte yeniden üretimi diskteki türetilen dosyalarla karşılaştırır
           (make_engine_d pin 6 doğrulandıktan sonra import edilir; model değildir, numpy kullanmaz).
  Y8-B1-k  §4.2 dayanak belgeleri DOC_PINS olarak --check-only'de yalnız bilgi amaçlı denetlenir (UYARI); koşu kapısı
           değildir (makale/S2 metinleri B4'ten önce değişebilir). pin_list_sha256 yalnız §4.1 + türetilenleri kapsar.
  Y8-B1-l  --selftest (B2-Ö, SABİT §9): S3 (örneklem dışı 3 nokta, C.stage1, X1 kuralı) + S9 (aynı 3 noktada, A2, B2,
           C sırasıyla, tam gecikmeli hesap). Geçme: S3 üçü; S9 (i) istisna yok, (ii) eq_ok hepsinde, (iii) en az bir
           noktada excl None ve mode_status in {uyumlu, uyusmaz, uygulanmaz}. (i)/(ii)/S3 kalırsa çıkış 1 (KALDI);
           yalnız (iii) kalırsa çıkış 5 (KULLANICI_BEKLIYOR). Ek: ayrıştırma eşdeğerliği; yapı denetimleri. Çıktı
           klasörü --out-dir ile zorunlu, varsa red.
  Y8-B1-m  Çıkış kodları: 0 hüküm (satır 2-5) / öz-test geçti; 2 ABORT; 3 kapı reddi; 1 beklenmeyen hata ya da öz-test
           kaldı (stderr.txt; gerçek kipte tek koşuyu tüketir); 4 --check-only pinler ve ön kabuller tamam, SABİT
           bekleniyor; --check-only'de pin/ön kabul KAPI'sı çıkış 2; 5 öz-test S9 (iii) KULLANICI_BEKLIYOR.
  Y8-B1-n  TD = 7.5e-5 literal (§5.1 "T_d = 7.5·10⁻⁵ s"; 1.5 * 50e-6 ikilik gösterimde 1 ulp farklıdır).
  Y8-B1-o  Mod kimliğinde path_point adım sayısı ceil(dG_hi / (0.01 dGf_d)) (en az 1); ω*_d = 0 ya da sonlu değilse
           'hesap'.
  Y8-B1-q  R2-3: G92_S1 / G92_OUT tanımlıysa main() başında KAPI (çıkış 3) ve import_common'da Abort; y_common'ın
           okuma yolları (U.TSV/TSV_a/analysis/points.csv, U.TSV/selection.json) pin 4/5 tam yoluyla aynı olmalı.
  Y8-B1-p  BLAS iş parçacığı 1 (numpy importundan önce os.environ[...] = '1'); model importundan sonra
           C.lower_priority(); stdout UTF-8; KeyboardInterrupt da mühürlenir (çıkış 1).

v2.1 (SABİT v1.0, D2 R2-1..R2-8): SABİT hash; birincil küme mode_status kümesi; mode_status None kuralı; S9 üç nokta
ve çıkış 5; ortam kapısı ve U yolu; rapor (n); X1 ayrı dispatch kabulü -> ABORT; delayed_core (S10 için ortak yol).
v2 değişiklikleri (ön-kayıt TASLAK v0.2): X1 pinli özgün C.BUILDERS + C.stage1 ve TSV pin toleransı (kappa
1e-9 max(1,|kappa|), dGf 1e-10 mutlak); gecikmeli düzen deepcopy(lay0.sysd) + ctrl_delay; ED.dispatch + CD.stage1_at;
referans ED.reference_margin(alpha_tab = tab0) ve C:414-427 kurallı alanlar; mod kimliği (θ_M = 2) ve denge kimliği
(1e-5); birincil kümeye mode_status ve eq_ok; örneklem ön kabulleri KAPI (18, havuz >= 15, 60 benzersiz, seçimde tam bir
kez, zorunlu alanlar); sample_ids_sha256 ve sürümler; yetki dosyası adı ve alanları; öz-test S3 + S9; yalnız rapor
(a)-(m). Örneklem kuralı ve tohum v1 ile aynı.

Kipler
  --check-only               SABİT + pinler, türetilen dosyaların yeniden üretimi, pin_list_sha256, örneklem ve ön kabuller,
                             sample_ids_sha256, S3 / öz-test kimlikleri, python/numpy. Model import edilmez, hesap ve
                             dosya yazımı yoktur.
  --selftest --out-dir P     B2-Ö öz-testi (S3 + S9); çıktı P/ (varsa red).
  --run-id P93_20261026_a --yetki P   tek gerçek koşu; çıktı out/P93_20261026_a/ (varsa red; yeniden koşu yok).
Kipler birlikte verilemez; argümansız koşu çalışmaz (KAPI, çıkış 3).
"""
import os
for _v in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[_v] = '1'

import argparse  # noqa: E402
import copy  # noqa: E402
import csv  # noqa: E402
import hashlib  # noqa: E402
import io  # noqa: E402
import json  # noqa: E402
import math  # noqa: E402
import re  # noqa: E402
import sys  # noqa: E402
import time  # noqa: E402
import traceback  # noqa: E402

import numpy as np  # noqa: E402

# ------------------------------------------------------------------ ön-kayıt sabitleri (gecikmeli değer görülmeden)
TS = 50e-6                  # §5.1 T_s (20 kHz)
TD = 7.5e-5                 # §5.1 T_d = 1.5 T_s (Y8-B1-n)
ROTATE = True               # §5.1 adım 2
TAU = 0.05                  # §5.4 tau (= y_common.TAU)
TIE_K = 2e-3                # §5.4 eşitlik (= ext_common.TIE_K)
SEED = 20261026             # §5.5 (= y_common.SEED)
SEED_OFFSET = 100           # §5.5 default_rng(20261126 + i)
FAMILIES = ('A2', 'B2', 'C')
N_PER_FAMILY = 14           # §5.5
N_OPT_REQUIRED = 18         # §5.5 ön kabul (KAPI)
POOL_MIN = 15               # §5.5 ön kabul (14 seçim + örneklem dışı nokta)
N_NEG_MIN = 8               # §8 satır 2
N_POS_MIN = 20              # §8 satır 2
AGREE_MIN = 0.75            # §8 satır 3
X1_KAPPA_REL = 1e-9         # §5.6 X1: |dk| <= 1e-9 max(1, |kappa|)
X1_DGF_ABS = 1e-10          # §5.6 X1: |d dGf| <= 1e-10
DISPATCH_TOL = 1e-12        # §5.3 adım 1
RES_MAX = 1e-8              # §5.3 adım 1 kabul
TAB_K = 1e-10               # §5.9 tab0 = 1e-10 ||A_0||_2
REF_STEP = 0.01             # §5.3 adım 3 (0.01 dGf_d)
REF_TOL = 1e-9              # §5.3 adım 3
THETA_M = 2.0               # §5.8
EQ_TOL = 1e-5               # §5.7
SELFTEST_FAMILY = 'A2'      # §9 S9
VERDICTS = {1: 'ABORT', 2: 'NOT_EVALUABLE', 3: 'RET', 4: 'KISMİ', 5: 'TUTARLI'}
REQ_POINT_FIELDS = ('id', 'system', 'kappa', 'abs_kappa', 'dGf', 'ref_sign', 'ref_status', 'censored', 'stage1_pin_ok')
REQ_SEL_FIELDS = ('id', 'system')

# ------------------------------------------------------------------ pinler (ön-kayıt §4.1; G öneki + göreli yol)
PIN_ROOT = 'C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme92_20261026\\'
PINS = [
    (1, 'kod\\ext_engine.py', 28393, '22feea1836b7e3b475e86efc0c3660eb742f83cd224444a2317ff001bd58489e'),
    (2, 'kod\\ext_common.py', 21468, 'b11b55cd58665944e7371aece67dd2dea147bdae7156cc75190b8668544e811a'),
    (3, 'kod\\y_common.py', 3644, '7b16ffbf27dce28fb1932a38705eadbadde2ad1f22c9349c485f6feb523a2970'),
    (4, 'girdi\\development_20261026\\out\\tsv\\TSV_a\\analysis\\points.csv', 2111107,
     '6a099961188a4cdf51865fbc0e370c2c9ce5a8e961e55a8a7e23e01dcbb844e7'),
    (5, 'girdi\\development_20261026\\out\\tsv\\selection.json', 2635991,
     '2d5a00d86497b174277d238293e08129f901627da99844552dcfcc397d981b53'),
]
DERIVED = [
    (6, 'kod\\make_engine_d.py', 10158, '9fc63b1e054f8410056de27fa54d7940ea167c15d8e81429c7f8bdbca0085f49'),
    (7, 'kod\\ext_engine_d.py', 30767, '780c4d95a6748a137fd6ba0045603dda025c001b4d073bd3553fe62a76851cea'),
    (8, 'kod\\ext_common_d.py', 21470, '98747eef15690f25b882850a04e77f53c22bbb21375fa7750b1a0c08242da727'),
]
# §4.2 dayanak belgeler (proje köküne göre; yalnız bilgi, Y8-B1-k)
DOC_PINS = [
    ('research_intelligence\\gelistirme91_20261025\\protokol\\TSV_PROTOKOL_v1.txt', 11966,
     '8df1074091a17b2fb0560d254abaefa6fd9854f94181cf43f67f0a24cad0075c'),
    ('research_intelligence\\gelistirme91_20261025\\protokol\\TSV_yetki_TSV_a.json', 868,
     '3133b436bd9369783784055d716e529c868682d621195360baf885e136aa8b5e'),
    ('research_intelligence\\gelistirme91_20261025\\kod\\p4_stage2.py', 8294,
     'f7564417afd423eb8f901ebdca5a76fda788a6093938fb3b3cfd9d374a6a04d3'),
    ('research_intelligence\\gelistirme91_20261025\\kod\\p4_analysis.py', 24226,
     '3b2ac2d65dab6a3fb383d852832fbf62fc2a4639fc0d11051d84e023662b181b'),
    ('research_intelligence\\gelistirme92_20261026\\ms\\ms_v4.txt', 137899,
     '541815fff7d7d2e5c1db8adad06e8b1488e8111c9a2bb98f6a222dc40a2479ab'),
    ('research_intelligence\\gelistirme92_20261026\\ms\\s2_v3.txt', 205431,
     'd0bc90765961b8d95f4737ef199615fcaf48c9ab649bc6d9d8e0a0ce95e69fe1'),
    ('research_intelligence\\makale\\elestiri_SEGAN_P92_v2_v0.1.md', 14890,
     'd18daace21d8dedff6e16ef5b0b8ae3ec1723751cb796982636f50cac2c3afe4'),
    ('research_intelligence\\gelistirme92_20261026\\protokol\\P93_On_Kayit_denetimi_D1.md', 40315,
     '109d6080edaff7d2b7a89cfa9e38d47037a5f77274df31e05538b7da6b09a9d7'),
    ('research_intelligence\\gelistirme92_20261026\\protokol\\P93_B1_uygulama_notu_v0.1.md', 4678,
     '6e93a4ec1a40c98fc266a4826d7ff4a5355e351a205625956b7d6f291854248b'),
]
SABIT_REL = 'protokol\\P93_GECIKME_On_Kayit_v1.0_SABIT.md'
SABIT_SHA256 = '9931723814d718dee6ab77f4dc6ec11c051daa4cdb6d093b4de812e456e7d173'
PIN_YCOMMON, PIN_POINTS, PIN_SELECTION = 3, 4, 5
PIN_ENGINE, PIN_COMMON, PIN_MAKE, PIN_ENGINE_D, PIN_COMMON_D = 1, 2, 6, 7, 8

RUN_ID = 'P93_20261026_a'
YETKI_REL = 'protokol\\P93_yetki_P93_20261026_a.json'
AUDIT_REL = 'protokol\\P93_kod_denetimi_D3.md'
ACTION = 'ALLOW_P93_RUN'
DAYANAK = 'D-260'
SCRIPT_KEYS = ('y8_run.py', 'y8_static_check.py', 'y8_synth_test.py', 'make_engine_d.py')
DERIVED_KEYS = ('ext_engine_d.py', 'ext_common_d.py')
FORBIDDEN_RUN_TAGS = ('Y8GK4M',)
FORBIDDEN_ENV = ('G92_S1', 'G92_OUT')      # SABİT §9 (R2-3)
EXIT_USER_WAIT = 5                         # öz-test S9 (iii): KULLANICI_BEKLIYOR
SHA_RE = re.compile(r'^[0-9a-f]{64}$')
OUT_JSONL, OUT_RESULT, OUT_VERDICT, OUT_PINS = 'y8.jsonl', 'sonuc.json', 'hukum.txt', 'girdi_pinleri.json'
OUT_SELFTEST = 'selftest_y8.json'
CODE_ERROR_TYPES = ('KeyError', 'TypeError', 'AttributeError', 'NameError', 'IndexError', 'UnboundLocalError')
REF_NAMES_GFM = ('P_ref', 'Q_ref', 'V_ref')
SEALED_KEYS = ('kappa', 'dGf', 'dGref', 'ref_sign', 'omega', 'eps2', 'censored', 'rel_err', 'fold', 'ref_status')
D1_KEYS = ('excl', 'phys_gate', 'alpha0', 'dGf', 'omega', 'kappa', 'k_fd', 'curv', 'eps2', 'kappa_L', 'kappa_rest', 'c',
           'gap_rel', 'cond_J')


class Abort(Exception):
    """Ön-kayıt §8 satır 1 (kind: 'X1' ya da 'X2')."""

    def __init__(self, msg, kind='X2'):
        super().__init__(msg)
        self.kind = kind


# ------------------------------------------------------------------ dosya erişimi (tek nokta)
def _read_bytes(path):
    with open(path, 'rb') as fh:
        return fh.read()


def _write_text(path, text, mode='w'):
    with open(path, mode, encoding='utf-8', newline='\n') as fh:
        fh.write(text)


def sha256_hex(data):
    return hashlib.sha256(data).hexdigest()


def pin_path(root, rel):
    return os.path.join(root, *re.split(r'[\\/]', rel))


def project_root(root):
    """G'nin iki üstü (EN YENİ MAKALEM): DOC_PINS göreli yolları için."""
    return os.path.dirname(os.path.dirname(root))


def pin_list_sha256(rows):
    """'no<TAB>yol<TAB>bayt<TAB>sha' satırları (PINS + DERIVED, literal sırasıyla), UTF-8, LF."""
    return sha256_hex(''.join('%d\t%s\t%d\t%s\n' % tuple(r) for r in rows).encode('utf-8'))


def verify_pins(root, rows):
    """Bayt + sha256; tek uyuşmazlık Abort (X2). Döner: (satırlar, {no: bayt})."""
    out, data = [], {}
    for no, rel, size, sha in rows:
        path = pin_path(root, rel)
        if not os.path.isfile(path):
            raise Abort('pin %d yok: %s' % (no, rel))
        b = _read_bytes(path)
        got = sha256_hex(b)
        out.append(dict(no=no, path=rel, bytes_expected=size, bytes=len(b), sha256_expected=sha, sha256=got))
        if len(b) != size or got != sha:
            raise Abort('pin %d uyuşmuyor: %s (bayt %d/%d)' % (no, rel, len(b), size))
        data[no] = b
    return out, data


def rehash_pins(root, rows):
    bad = []
    for no, rel, size, sha in rows:
        path = pin_path(root, rel)
        if not os.path.isfile(path):
            bad.append(no)
            continue
        b = _read_bytes(path)
        if len(b) != size or sha256_hex(b) != sha:
            bad.append(no)
    return bad


def _same_file(a, b):
    return os.path.normcase(os.path.realpath(a)) == os.path.normcase(os.path.realpath(b))


def _rel_of(rows, no):
    hits = [r for n, r, _, _ in rows if n == no]
    if len(hits) != 1:
        raise Abort('pin %d tabloda yok' % no)
    return hits[0]


def _finite(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def _inside(base, path):
    b = os.path.normcase(os.path.realpath(base))
    try:
        return os.path.commonpath([b, os.path.normcase(os.path.realpath(path))]) == b
    except ValueError:
        return False


def versions():
    return sys.version.split()[0], np.__version__


# ------------------------------------------------------------------ modül yükleme (yalnız pin doğrulamasından SONRA)
def _kod_on_path(root):
    kod = pin_path(root, 'kod')
    if kod not in sys.path:
        sys.path.insert(0, kod)


def env_gate():
    """SABİT §9 (R2-3): G92_S1 ya da G92_OUT tanımlıysa Abort (KAPI/ABORT)."""
    bad = [k for k in FORBIDDEN_ENV if k in os.environ]
    if bad:
        raise Abort('ortam değişkeni tanımlı: %s (SABİT §9)' % bad)


def import_common(root, pins):
    """y_common (pin 3). check-only ve prerun_gate'te de kullanılır; model değildir."""
    env_gate()
    _kod_on_path(root)
    import y_common as U
    if not _same_file(U.__file__, pin_path(root, _rel_of(pins, PIN_YCOMMON))):
        raise Abort('y_common pinli dosyadan yüklenmedi: %s' % U.__file__)
    tsv = str(U.TSV)
    for no in (PIN_POINTS, PIN_SELECTION):
        parts = re.split(r'[\\/]', _rel_of(pins, no))
        tail = parts[parts.index('tsv') + 1:]           # U: TSV/TSV_a/analysis/<pin 4>, TSV/<pin 5>
        if os.path.normcase(os.path.abspath(os.path.join(tsv, *tail))) != \
                os.path.normcase(os.path.abspath(pin_path(root, _rel_of(pins, no)))):
            raise Abort('y_common okuma yolu pin %d tam yoluyla aynı değil (R2-3)' % no)
    if U.TAU != TAU or U.SEED != SEED:
        raise Abort('y_common sabitleri ön-kayıttan farklı (TAU %r, SEED %r)' % (U.TAU, U.SEED))
    return U


def import_generator(root, derived):
    """make_engine_d (pin 6; Y8-B1-j). Model değildir."""
    _kod_on_path(root)
    import make_engine_d as MK
    if not _same_file(MK.__file__, pin_path(root, _rel_of(derived, PIN_MAKE))):
        raise Abort('make_engine_d pinli dosyadan yüklenmedi: %s' % MK.__file__)
    return MK


def import_models(root, pins, derived):
    """E, C (gecikme kapalı yol, §5.2 d) ve ED, CD (gecikmeli). Yalnız evaluate() ve selftest_mode() içinden."""
    U = import_common(root, pins)
    import ext_engine as E
    import ext_common as C
    import ext_engine_d as ED
    import ext_common_d as CD
    for mod, rows, no in ((E, pins, PIN_ENGINE), (C, pins, PIN_COMMON), (ED, derived, PIN_ENGINE_D),
                          (CD, derived, PIN_COMMON_D)):
        if not _same_file(mod.__file__, pin_path(root, _rel_of(rows, no))):
            raise Abort('model modülü pinli dosyadan yüklenmedi: %s' % mod.__file__)
    if C.E is not E or CD.E is not ED:
        raise Abort('ext_common / ext_common_d beklenen motoru kullanmıyor')
    if C.TAU_K != TAU or C.TIE_K != TIE_K or CD.TAU_K != TAU or CD.TIE_K != TIE_K:
        raise Abort('ext_common sabitleri ön-kayıttan farklı')
    return U, E, C, ED, CD


# ------------------------------------------------------------------ mühürlü girdiler ve örneklem (§5.5)
def parse_points(U, data):
    """U.load_points ile aynı ayrıştırma, doğrulanmış baytlardan (Y8-B1-a)."""
    text = io.StringIO(data.decode('utf-8'), newline=None)
    return [{k: U.num(v) for k, v in r.items()} for r in csv.DictReader(text)]


def parse_selection(data):
    """Pin 5 'points' listesi (U.selection ile aynı kaynak; çift kimlik denetimi için liste)."""
    doc = json.loads(data.decode('utf-8'))
    if not isinstance(doc, dict) or not isinstance(doc.get('points'), list):
        raise Abort("pin 5: 'points' alanı yok")
    return doc['points']


def sample_points(U, rows):
    """§5.5: base = U.y2_set(rows); S_opt; S_cons (aile i: default_rng(SEED + 100 + i), 14, yerine koymadan, sıralı)."""
    base = U.y2_set(rows)
    s_opt = sorted([r for r in base if r['kappa'] < 0], key=lambda r: r['id'])
    s_cons, pools = [], {}
    for i, fam in enumerate(FAMILIES):
        pool = sorted([r for r in base if r['system'] == fam and r['kappa'] >= U.TAU], key=lambda r: r['id'])
        pools[fam] = pool
        if len(pool) < N_PER_FAMILY:
            continue
        rng = np.random.default_rng(U.SEED + SEED_OFFSET + i)
        idx = sorted(int(j) for j in rng.choice(len(pool), size=N_PER_FAMILY, replace=False))
        s_cons += [pool[j] for j in idx]
    return s_opt, s_cons, pools


def sample_ids_sha256(ids):
    return sha256_hex(''.join(i + '\n' for i in ids).encode('utf-8'))


def first_unselected(pools, sample_ids):
    out = {}
    for fam in FAMILIES:
        rest = [r for r in pools.get(fam, []) if r['id'] not in sample_ids]
        out[fam] = rest[0] if rest else None
    return out


def sample_gate(rows, sel_list, s_opt, s_cons, pools):
    """§5.5 ön kabuller ve eksik alanlar. Döner: KAPI nedenleri listesi (boş = geçti)."""
    why = []
    if rows:
        miss = [f for f in REQ_POINT_FIELDS if f not in rows[0]]
        if miss:
            why.append('pin 4 zorunlu alan yok: %s' % miss)
    else:
        why.append('pin 4 boş')
    if any(not isinstance(p, dict) or any(f not in p for f in REQ_SEL_FIELDS) for p in sel_list):
        why.append('pin 5 kaydında id/system yok')
    if why:
        return why
    if len(s_opt) != N_OPT_REQUIRED:
        why.append('|S_opt| = %d (gerekli %d)' % (len(s_opt), N_OPT_REQUIRED))
    for fam in FAMILIES:
        if len(pools.get(fam, [])) < POOL_MIN:
            why.append('havuz %s = %d < %d' % (fam, len(pools.get(fam, [])), POOL_MIN))
    ids = [r['id'] for r in s_opt + s_cons]
    if len(ids) != N_OPT_REQUIRED + N_PER_FAMILY * len(FAMILIES) or len(set(ids)) != len(ids):
        why.append('örneklem 60 benzersiz kimlik değil (%d / %d)' % (len(ids), len(set(ids))))
    cnt = {}
    for p in sel_list:
        cnt[p['id']] = cnt.get(p['id'], 0) + 1
    bad = [i for i in ids if cnt.get(i, 0) != 1]
    if bad:
        why.append('pin 5 içinde tam bir kez olmayan kimlik: %s' % bad[:5])
    return why


def build_sample(U, data):
    """Ayrıştırma + örneklem + ön kabuller. Döner: dict."""
    rows = parse_points(U, data[PIN_POINTS])
    sel_list = parse_selection(data[PIN_SELECTION])
    s_opt, s_cons, pools = sample_points(U, rows)
    gate = sample_gate(rows, sel_list, s_opt, s_cons, pools)
    sel = {p['id']: p for p in sel_list if isinstance(p, dict) and 'id' in p}
    ids = [r['id'] for r in s_opt + s_cons]
    return dict(rows=rows, sel=sel, s_opt=s_opt, s_cons=s_cons, pools=pools, gate=gate, ids=ids,
                sha=sample_ids_sha256(ids), extra=first_unselected(pools, set(ids)))


def sealed_values(pt):
    out = {k: pt.get(k) for k in SEALED_KEYS}
    if _finite(out['ref_sign']):
        out['ref_sign'] = int(out['ref_sign'])
    return out


# ------------------------------------------------------------------ X1 (gecikme kapalı yol, §5.2 d, §5.6)
def x1_check(r0, sealed):
    """TSV pin kuralı (p4_stage2.py:127-128). Döner: (geçti, neden, |dk|, |d dGf|)."""
    if r0.get('excl') is not None:
        return False, 'excl=%s' % r0.get('excl'), None, None
    a, b = r0.get('kappa'), sealed.get('kappa')
    c, d = r0.get('dGf'), sealed.get('dGf')
    if not (_finite(a) and _finite(b) and _finite(c) and _finite(d)):
        return False, 'kappa/dGf yok ya da sonlu değil', None, None
    dk, dd = abs(a - b), abs(c - d)
    ok = dk <= X1_KAPPA_REL * max(1.0, abs(b)) and dd <= X1_DGF_ABS
    return ok, (None if ok else 'TSV pin toleransı aşıldı'), dk, dd


def tab_of(Jm, lay):
    keep = lay.keep
    A = Jm[np.ix_(keep, keep)] / lay.M[keep][:, None]
    return TAB_K * float(np.linalg.norm(A, 2))


def point_x1(M, pt, srec):
    """X1: C.BUILDERS + C.stage1 (pinli özgün); geçerse gecikmesiz denge (E.dispatch) ve tab0 (§5.9).
    Döner: (kayıt, bağlam {x0, refs, tab0} ya da None)."""
    U, E, C, ED, CD = M
    t0 = time.perf_counter()
    o = dict(phase='X1', id=pt['id'], system=pt['system'])
    ctx = None
    try:
        lay0, G, P = C.BUILDERS[pt['system']](dict(srec))
        r0 = C.stage1(lay0, G, P, rec={}, strict=True)
        ok, why, dk, dd = x1_check(r0, sealed_values(pt))
        o.update(ok=bool(ok), reason=why, excl=r0.get('excl'), kappa=r0.get('kappa'), dGf=r0.get('dGf'),
                 abs_dkappa=dk, abs_ddGf=dd, n_states0=lay0.n)
    except Exception as e:  # noqa: BLE001  (X1 yeniden üretilemedi -> kaldı)
        o.update(ok=False, reason='istisna', error_type=type(e).__name__, error=str(e),
                 tb=traceback.format_exc()[-800:])
        lay0 = None
    if lay0 is not None and o['ok']:
        try:
            ctx = x1_context(E, lay0, P, G)
            o.update(res0=ctx['res0'], refs0=[float(v) for v in ctx['refs']], tab0=ctx['tab0'])
        except Exception as e:  # noqa: BLE001  (R2-8: gecikmesiz denge/tab0 yok -> X1 kaldı)
            o.update(ok=False, reason='gecikmesiz denge/tab0: %s: %s' % (type(e).__name__, e))
            ctx = None
    o['t_s'] = time.perf_counter() - t0
    return o, ctx


def x1_context(E, lay0, P, G):
    """R2-8: ayrı E.dispatch(lay0, P, G, tol=1e-12); kabul §5.3-1 (ok ya da kalıntı <= 1e-8), değilse ValueError;
    tab0 = 1e-10 ||A_0||_2 (§5.9)."""
    d0 = E.dispatch(lay0, P, G, tol=DISPATCH_TOL)
    res0 = float(d0['hist'][-1])
    if not (d0['ok'] or res0 <= RES_MAX):
        raise ValueError('gecikmesiz dispatch kabul edilmedi (kalıntı %.3e)' % res0)
    x0, refs = d0['x'], d0['refs']
    tab0 = tab_of(E.jac(lay0, x0, refs, G), lay0)
    if not _finite(tab0):
        raise ValueError('tab0 sonlu değil')
    return dict(x0=np.array(x0, float), refs=np.array(refs, float), tab0=tab0, names=list(lay0.names), res0=res0)


# ------------------------------------------------------------------ gecikmeli hesap (§5.2 c, §5.3, §5.7, §5.8)
def delayed_layout(ED, lay0):
    """§5.2 (c): sysd_d = deepcopy(lay0.sysd); ctrl_delay; ED.Layout(sysd_d). lay0.sysd değişmez."""
    sysd_d = copy.deepcopy(lay0.sysd)
    sysd_d['ctrl_delay'] = dict(Td=TD, rotate=ROTATE)
    return ED.Layout(sysd_d)


def eq_identity(names0, x0_0, refs_0, x_d, refs_d):
    """§5.7: Φ = özgün adlar - {G:gd, G:gq, C<c>:gd, C<c>:gq}. Döner: (eq_maxdev, eq_refs_maxdev, eq_ok)."""
    dev = 0.0
    for i, nm in enumerate(names0):
        if nm.split(':', 1)[1] in ('gd', 'gq'):
            continue
        dev = max(dev, abs(float(x_d[i]) - float(x0_0[i])) / max(1.0, abs(float(x0_0[i]))))
    rdev = max(abs(float(a) - float(b)) / max(1.0, abs(float(b))) for a, b in zip(refs_d, refs_0))
    return dev, rdev, bool(dev <= EQ_TOL and rdev <= EQ_TOL)


def reference_fields(C, R, dGf_d, dmax):
    """C:414-427 ile aynı kurallar (tahminci alanları yok)."""
    st = R['status']
    err = R['dGt'] - dGf_d
    return dict(dGref=R['dGt'], ref_status=st, err=err, rel_err=err / dGf_d, ref_sign=C.ref_sign_of(st, err, dGf_d),
                fold=st.startswith('newton'), censored=st.startswith('censored'), bracket=R.get('bracket'),
                dG_max=dmax, ref_newton_solves=R.get('newton_solves'), ref_points=R.get('points'))


def mode_identity(ED, layd, x0, refs, G, dGf_d, omega_d, ref):
    """§5.8. Döner: dict(mode_status, omega_ref, mode_ratio, mode_steps)."""
    if ref['ref_sign'] is None:
        return dict(mode_status=None, omega_ref=None, mode_ratio=None)   # §5.8 (R2-1)
    if ref['ref_status'] != 'alpha':
        return dict(mode_status='uygulanmaz', omega_ref=None, mode_ratio=None)
    try:
        dg_hi = float(ref['bracket'][1])
        steps = max(1, int(math.ceil(dg_hi / (REF_STEP * dGf_d))))
        x_hi = ED.path_point(layd, x0, refs, G, dg_hi, steps=steps)[0]
        if x_hi is None or not _finite(omega_d) or omega_d == 0:
            return dict(mode_status='hesap', omega_ref=None, mode_ratio=None, mode_steps=steps)
        sb = layd.sysd['shed_bus']
        G_hi = G.copy()
        G_hi[sb] = G[sb] - dg_hi
        ev = ED.spectral_abscissa(layd, ED.jac(layd, x_hi, refs, G_hi))[1]
        i = int(np.argmax(ev.real))
        w_ref = float(abs(ev[i].imag))
        ratio = w_ref / float(omega_d)
        ok = (1.0 / THETA_M) <= ratio <= THETA_M
        return dict(mode_status='uyumlu' if ok else 'uyusmaz', omega_ref=w_ref, mode_ratio=ratio, mode_steps=steps,
                    lam_ref=[float(ev[i].real), float(ev[i].imag)])
    except Exception as e:  # noqa: BLE001
        return dict(mode_status='hesap', omega_ref=None, mode_ratio=None, mode_error='%s: %s' % (type(e).__name__, e))


def point_delayed(M, pt, srec, ctx):
    """§5.3 adım 1-4 (gecikmeli). ctx: X1 evresinin gecikmesiz dengesi ve tab0."""
    U, E, C, ED, CD = M
    t0 = time.perf_counter()
    o = dict(phase='D', id=pt['id'], system=pt['system'], cluster=srec.get('cluster'), source=srec.get('source'),
             sealed=sealed_values(pt), tab0=None if ctx is None else ctx['tab0'], mode_status=None)
    try:
        if ctx is None or not _finite(ctx.get('tab0')):
            o.update(status='ne', ne='tab0')
            return o
        lay0, G, P = C.BUILDERS[pt['system']](dict(srec))
        delayed_core(M, lay0, G, P, ctx, o)
    except Exception as e:  # noqa: BLE001  (Y8-B1-c: X3 'istisna')
        o.update(status='error', error_type=type(e).__name__, error=str(e), tb=traceback.format_exc()[-800:])
    finally:
        o['t_s'] = time.perf_counter() - t0
    return o


def delayed_core(M, lay0, G, P, ctx, o):
    """§5.3 adım 1-4, o yerinde doldurulur (point_delayed ve sentetik S10 aynı yolu kullanır). R2-1: tanımsız
    durumlarda mode_status None kalır."""
    U, E, C, ED, CD = M
    o.setdefault('mode_status', None)
    layd = delayed_layout(ED, lay0)
    n0 = lay0.n
    dnames = [n for n in layd.names if n.split(':', 1)[1] in ED.DELAY_NAMES]
    o.update(n_cpl=len(layd.sysd['cpls']), n_states0=n0, n_states=layd.n,
             names_prefix_ok=list(layd.names[:n0]) == list(lay0.names), n_delay_states=len(dnames),
             delay_mass_ok=all(layd.M[layd.ix[n]] == TD for n in dnames), lay0_unchanged='ctrl_delay' not in lay0.sysd)
    d = ED.dispatch(layd, P, G, tol=DISPATCH_TOL)
    res = float(d['hist'][-1])
    o['res'] = res
    if not (d['ok'] or res <= RES_MAX):
        o.update(status='stage1_excluded', excl='G1')
        return o
    x0, refs = d['x'], d['refs']
    dev, rdev, eq_ok = eq_identity(ctx['names'], ctx['x0'], ctx['refs'], x0, refs)
    o.update(eq_maxdev=dev, eq_refs_maxdev=rdev, eq_ok=eq_ok, refsd=[float(v) for v in refs])
    t1 = time.perf_counter()
    rec = CD.stage1_at(layd, G, P, x0, refs, rec={}, strict=True)
    rec['res'] = res
    o['t_stage1'] = time.perf_counter() - t1
    o.update({k: rec.get(k) for k in D1_KEYS})
    o['d1'] = rec
    try:
        o['tab_d'] = tab_of(ED.jac(layd, x0, refs, G), layd)
    except Exception as e:  # noqa: BLE001  (yalnız rapor)
        o['tab_d'] = None
        o['tab_d_error'] = '%s: %s' % (type(e).__name__, e)
    if rec.get('excl') is not None:
        o['status'] = 'stage1_excluded'
        return o
    sb = layd.sysd['shed_bus']
    dGf_d = rec['dGf']
    dmax = min(G[sb], 2.0 * dGf_d)
    tab0 = ctx['tab0']
    t2 = time.perf_counter()
    R = ED.reference_margin(layd, x0, refs, G, dmax, REF_STEP * dGf_d, tol=REF_TOL, alpha_tab=tab0)
    ref = reference_fields(C, R, dGf_d, dmax)
    o.update(ref)
    o['t_ref'] = time.perf_counter() - t2
    o.update(mode_identity(ED, layd, x0, refs, G, dGf_d, rec.get('omega'), ref))
    o['status'] = 'ok'
    return o


# ------------------------------------------------------------------ karar (§5.4, §8)
def ne_reason(r):
    """§5.6 X3 nedeni; birincil kümeye giren nokta için None (|kappa| < tau ve ref_sign 0 ayrıca)."""
    st = r.get('status')
    if st == 'error':
        return 'istisna:%s' % r.get('error_type')
    if st == 'ne':
        return r.get('ne')
    if st == 'stage1_excluded':
        return str(r.get('excl'))
    if st != 'ok':
        return 'durum:%s' % st
    if r.get('ref_sign') is None:
        return 'ref_sign None'
    if r.get('mode_status') == 'uyusmaz':
        return 'mod-kimligi'
    if r.get('mode_status') == 'hesap':
        return 'mod-hesap'
    if r.get('eq_ok') is not True:
        return 'denge-kimligi'
    return None


def primary_set(drows):
    """§5.4 (+ Y8-B1-e): excl None ∧ |kappa_d| >= tau ∧ ref_sign ±1 ∧ mod 'uyumlu'/'uygulanmaz' ∧ eq_ok."""
    out = []
    for r in drows:
        if ne_reason(r) is not None or r.get('excl') is not None:
            continue
        k, s = r.get('kappa'), r.get('ref_sign')
        if not _finite(k) or isinstance(s, bool) or s not in (1, -1):
            continue
        if r.get('mode_status') not in ('uyumlu', 'uygulanmaz'):
            continue
        if abs(k) >= TAU:
            out.append(r)
    return out


def strata_counts(prim):
    neg = [r for r in prim if r['kappa'] < 0]
    pos = [r for r in prim if r['kappa'] > 0]
    return (len(neg), len(pos), sum(1 for r in neg if r['ref_sign'] != -1),
            sum(1 for r in pos if r['ref_sign'] != 1))


def decide(x1_ok, x2_ok, n_neg, n_pos, k_neg, k_pos, wilson):
    """Ön-kayıt §8, ilk eşleşen satır. wilson(k, n) -> (alt, üst). Döner: (satır, hüküm)."""
    if not (x1_ok and x2_ok):
        return 1, VERDICTS[1]
    if n_neg < N_NEG_MIN or n_pos < N_POS_MIN:
        return 2, VERDICTS[2]
    n, k = n_neg + n_pos, k_neg + k_pos
    if ((n_neg - k_neg) / n_neg < AGREE_MIN or (n_pos - k_pos) / n_pos < AGREE_MIN
            or wilson(n - k, n)[0] < AGREE_MIN):
        return 3, VERDICTS[3]
    if k >= 1:
        return 4, VERDICTS[4]
    return 5, VERDICTS[5]


def _sgn(v):
    return 1 if v > 0 else (-1 if v < 0 else 0)


def _stats(vals):
    v = sorted(x for x in vals if _finite(x))
    if not v:
        return dict(n=0, median=None, min=None, max=None)
    m = len(v) // 2
    med = v[m] if len(v) % 2 else 0.5 * (v[m - 1] + v[m])
    return dict(n=len(v), median=med, min=v[0], max=v[-1])


def mcnemar_exact(b, c):
    """İki yanlı kesin McNemar p (uyumsuz çiftler b, c)."""
    n = b + c
    if n == 0:
        return 1.0
    s = sum(math.comb(n, i) for i in range(0, min(b, c) + 1))
    return min(1.0, 2.0 * s / 2 ** n)


def report_only(drows, prim, x1rows):
    """§6 yalnız rapor (a)-(m). Hükme girmez."""
    ok = [r for r in drows if r.get('status') == 'ok']
    refs0 = {r['id']: r.get('refs0') for r in x1rows}
    out = {}
    sig = [r for r in ok if r.get('ref_sign') in (1, -1)]
    out['a_gecikmesiz_kappa_gecikmeli_yon'] = dict(
        birincil=dict(n=len(prim), uyum=sum(1 for r in prim if _sgn(r['sealed']['kappa']) == r['ref_sign'])),
        ref_sign_pm1=dict(n=len(sig), uyum=sum(1 for r in sig if _sgn(r['sealed']['kappa']) == r['ref_sign'])))
    have = [r for r in ok if r.get('ref_sign') is not None]
    diff = [r for r in have if r['ref_sign'] != r['sealed']['ref_sign']]
    out['b_yon_degisimi'] = dict(n=len(have), n_farkli=len(diff), ids=[r['id'] for r in diff])
    rel = {}
    for key in ('kappa', 'dGf', 'dGref', 'omega'):
        rel[key] = _stats([(r[key] - r['sealed'][key]) / abs(r['sealed'][key]) for r in ok
                           if _finite(r.get(key)) and _finite(r['sealed'].get(key)) and r['sealed'][key] != 0])
    out['c_goreli_degisim'] = rel
    reasons = {}
    for r in drows:
        why = ne_reason(r)
        if why is not None:
            reasons.setdefault(why, []).append(r['id'])
    out['d_dislanan'] = dict(nedenler={k: len(v) for k, v in reasons.items()}, liste=reasons,
                             ayrinti=[(r['id'], r.get('excl'), r.get('phys_gate'), r.get('alpha0'), r.get('ref_status'))
                                      for r in drows if ne_reason(r) is not None])
    out['e_uyumsuzluk_eps2'] = [dict(id=r['id'], kappa=r['kappa'], ref_sign=r['ref_sign'], eps2=r.get('eps2'),
                                     abs_eps2=abs(r['eps2']) if _finite(r.get('eps2')) else None)
                                for r in prim if r['ref_sign'] != _sgn(r['kappa'])]
    out['f_eq_maxdev'] = dict(durum=_stats([r.get('eq_maxdev') for r in drows]),
                              refs=_stats([r.get('eq_refs_maxdev') for r in drows]))
    comp = {}
    for r in drows:
        a, b = refs0.get(r['id']), r.get('refsd')
        if isinstance(a, list) and isinstance(b, list) and len(a) == len(b):
            names = list(REF_NAMES_GFM) + ['%s_C%d' % (nm, c) for c in range((len(a) - 3) // 2)
                                           for nm in ('V_ref_dc', 'Iq_ref')]
            for nm, u, v in zip(names, a, b):
                if _finite(u) and _finite(v):
                    comp[nm] = max(comp.get(nm, 0.0), abs(v - u))
    out['f_set_noktasi_max_abs_degisim'] = comp
    band = [r for r in ok if _finite(r.get('kappa')) and abs(r['kappa']) < TAU]
    out['g_cekimser_bant'] = [dict(id=r['id'], kappa=r['kappa'], ref_sign=r.get('ref_sign')) for r in band]
    out['h_esitlik'] = [r['id'] for r in ok if r.get('ref_sign') == 0]
    fam = {}
    for f in FAMILIES:
        rr = [r for r in prim if r['system'] == f]
        fam[f] = dict(n=len(rr), k=sum(1 for r in rr if r['ref_sign'] != _sgn(r['kappa'])))
    out['i_aile'] = fam
    out['j_tekil_kume'] = len({r.get('cluster') for r in prim})
    out['k_mod'] = dict(mode_ratio=_stats([r.get('mode_ratio') for r in drows]),
                        omega_d_bolu_omega=_stats([r['omega'] / r['sealed']['omega'] for r in ok
                                                   if _finite(r.get('omega')) and _finite(r['sealed'].get('omega'))
                                                   and r['sealed']['omega'] != 0]),
                        durum={s: sum(1 for r in drows if r.get('mode_status') == s)
                               for s in ('uyumlu', 'uyusmaz', 'hesap', 'uygulanmaz')})
    out['l_tab'] = dict(tab0=_stats([r.get('tab0') for r in drows]), tab_d=_stats([r.get('tab_d') for r in drows]),
                        alpha0_d=_stats([r.get('alpha0') for r in drows]))
    mis = [r for r in drows if r.get('mode_status') == 'uyusmaz' and _finite(r.get('kappa'))
           and r.get('ref_sign') in (1, -1)]
    out['n_mod_uyusmaz_uyum'] = dict(n=len(mis), uyum=sum(1 for r in mis if _sgn(r['kappa']) == r['ref_sign']),
                                     ne_mod_kimligi=sum(1 for r in drows if ne_reason(r) == 'mod-kimligi'),
                                     ne_mod_hesap=sum(1 for r in drows if ne_reason(r) == 'mod-hesap'))
    if prim:
        acc_r1 = [r['ref_sign'] == _sgn(r['kappa']) for r in prim]
        best = 1 if sum(r['ref_sign'] == 1 for r in prim) >= sum(r['ref_sign'] == -1 for r in prim) else -1
        acc_c = [r['ref_sign'] == best for r in prim]
        b = sum(1 for x, y in zip(acc_r1, acc_c) if x and not y)
        c = sum(1 for x, y in zip(acc_r1, acc_c) if y and not x)
        out['m_sabit_kural'] = dict(en_iyi_sabit=best, dogruluk_R1=sum(acc_r1) / len(prim),
                                    dogruluk_sabit=sum(acc_c) / len(prim), b=b, c=c, mcnemar_p=mcnemar_exact(b, c))
    else:
        out['m_sabit_kural'] = None
    return out


def verdict_line(res):
    if res.get('verdict') is None:
        return 'BEKLENMEYEN HATA (hüküm yok; stderr.txt)'
    if res.get('decision_row') == 1:
        return 'P93 H-P93 hükmü: ABORT (karar tablosu satır 1; %s; yeniden koşu yok) - %s' % (
            res.get('abort_kind'), res.get('abort_reason'))
    p = res.get('primary') or {}
    return ('P93 H-P93 hükmü: %s (karar tablosu satır %s; n(kappa_d<0)=%s, n(kappa_d>0)=%s, uyumsuz(-)=%s, '
            'uyumsuz(+)=%s, Wilson alt=%s)' % (res.get('verdict'), res.get('decision_row'), p.get('n_neg'),
                                               p.get('n_pos'), p.get('k_neg'), p.get('k_pos'), p.get('wilson_lo')))


# ------------------------------------------------------------------ yetki (§10) ve kipler
def verify_authorization(root, yetki_path, run_id, pins, derived, sabit, script_path):
    """Y8-B1-h. Uyuşmazlıkta ValueError. Model import edilmez."""
    if run_id != RUN_ID:
        raise ValueError('run_id %s değil' % RUN_ID)
    if os.path.normcase(os.path.abspath(yetki_path)) != os.path.normcase(os.path.abspath(pin_path(root, YETKI_REL))):
        raise ValueError('yetki dosyası yolu %s değil' % YETKI_REL)
    if not os.path.isfile(yetki_path):
        raise ValueError('yetki dosyası yok')
    try:
        y = json.loads(_read_bytes(yetki_path).decode('utf-8'))
    except (UnicodeDecodeError, ValueError):
        raise ValueError('yetki dosyası JSON değil')
    if not isinstance(y, dict):
        raise ValueError('yetki dosyası sözlük değil')
    if y.get('action') != ACTION:
        raise ValueError('action != %s' % ACTION)
    if y.get('run_id') != run_id:
        raise ValueError('run_id uyuşmuyor')
    sabit_rel, sabit_sha = sabit
    if not sabit_rel or not sabit_sha:
        raise ValueError('SABİT hash betikte doldurulmadı (fixation sonrası doldurulacak)')
    sp = pin_path(root, sabit_rel)
    if not os.path.isfile(sp) or sha256_hex(_read_bytes(sp)) != sabit_sha:
        raise ValueError('SABİT dosyası yok ya da hash uyuşmuyor')
    if y.get('sabit_sha256') != sabit_sha:
        raise ValueError('yetki.sabit_sha256 uyuşmuyor')
    scripts = y.get('script_sha256')
    if not isinstance(scripts, dict):
        raise ValueError('yetki.script_sha256 eksik')
    kod = os.path.dirname(os.path.abspath(script_path))
    for name in SCRIPT_KEYS:
        p = script_path if name == 'y8_run.py' else os.path.join(kod, name)
        if not os.path.isfile(p) or scripts.get(name) != sha256_hex(_read_bytes(p)):
            raise ValueError('yetki.script_sha256[%s] uyuşmuyor' % name)
    lit = {re.split(r'[\\/]', rel)[-1]: sha for no, rel, size, sha in derived}
    if scripts.get('make_engine_d.py') != lit.get('make_engine_d.py'):
        raise ValueError('yetki.script_sha256[make_engine_d.py] DERIVED literaliyle uyuşmuyor')
    dsha = y.get('derived_sha256')
    if not isinstance(dsha, dict) or any(dsha.get(k) != lit.get(k) for k in DERIVED_KEYS):
        raise ValueError('yetki.derived_sha256 uyuşmuyor')
    if y.get('pin_list_sha256') != pin_list_sha256(list(pins) + list(derived)):
        raise ValueError('yetki.pin_list_sha256 uyuşmuyor')
    if not isinstance(y.get('sample_ids_sha256'), str) or not SHA_RE.match(y['sample_ids_sha256']):
        raise ValueError('yetki.sample_ids_sha256 eksik')
    py, npv = versions()
    if y.get('python') != py or y.get('numpy') != npv:
        raise ValueError('python/numpy sürümü yetkidekiyle aynı değil (%s, %s)' % (py, npv))
    b2 = y.get('b2_sha256sums')
    ri = os.path.dirname(root)
    if not isinstance(b2, dict) or not b2:
        raise ValueError('yetki.b2_sha256sums boş')
    for rel, h in b2.items():
        p = pin_path(ri, rel)
        if not isinstance(h, str) or not _inside(ri, p) or not os.path.isfile(p) or sha256_hex(_read_bytes(p)) != h:
            raise ValueError('B2 SHA256SUMS uyuşmuyor: %s' % rel)
    rep = y.get('code_audit_report')
    if not isinstance(rep, dict) or not isinstance(rep.get('path'), str) or not isinstance(rep.get('sha256'), str):
        raise ValueError('yetki.code_audit_report eksik')
    if re.split(r'[\\/]', rep['path']) != re.split(r'[\\/]', AUDIT_REL):
        raise ValueError('kod denetimi raporu yolu %s değil' % AUDIT_REL)
    rp = pin_path(root, rep['path'])
    if not os.path.isfile(rp) or sha256_hex(_read_bytes(rp)) != rep['sha256']:
        raise ValueError('kod denetimi raporu yok ya da hash uyuşmuyor')
    day = y.get('dayanak')
    if not isinstance(day, list) or DAYANAK not in day or not all(isinstance(d, str) for d in day):
        raise ValueError('yetki.dayanak %s içermiyor' % DAYANAK)
    yazan = y.get('yazan')
    if not isinstance(yazan, str) or not yazan.strip():
        raise ValueError('yetki.yazan boş')
    for tag in FORBIDDEN_RUN_TAGS:
        if tag in yazan:
            raise ValueError('yazan %s içeriyor (ön-kayıt §10)' % tag)
    try:
        verify_pins(root, list(pins) + list(derived))
    except Abort as e:
        raise ValueError('X2 pin: %s' % e)
    return y


def prerun_gate(root, pins, derived, y):
    """Y8-B1-i: örneklem ön kabulleri ve sample_ids_sha256 (model yok). ValueError -> KAPI."""
    try:
        _, data = verify_pins(root, list(pins) + list(derived))
        U = import_common(root, pins)
        smp = build_sample(U, data)
    except Abort as e:
        raise ValueError('X2: %s' % e)
    if smp['gate']:
        raise ValueError('örneklem ön kabulleri: %s' % '; '.join(smp['gate']))
    if smp['sha'] != y.get('sample_ids_sha256'):
        raise ValueError('sample_ids_sha256 uyuşmuyor (%s)' % smp['sha'])
    return smp['sha']


def check_only(root, pins, derived, sabit, log, script_path):
    """§9: SABİT, pinler, türetilenler, örneklem. Model import edilmez; hesap ve dosya yazımı yok."""
    sabit_rel, sabit_sha = sabit
    if not sabit_rel or not sabit_sha:
        log('SABİT hash: (fixation sonrası doldurulacak) -- DOĞRULANMADI (%s)' % sabit_rel)
        sabit_state = 'bekliyor'
    else:
        sp = pin_path(root, sabit_rel)
        good = os.path.isfile(sp) and sha256_hex(_read_bytes(sp)) == sabit_sha
        log('SABİT hash: %s (%s)' % ('OK' if good else 'UYUŞMUYOR', sabit_rel))
        if not good:
            log('KAPI: SABİT')
            return 2
        sabit_state = 'ok'
    rows_all = list(pins) + list(derived)
    try:
        rows, data = verify_pins(root, rows_all)
    except Abort as e:
        log('KAPI: PIN - %s' % e)
        return 2
    for r in rows:
        log('pin %d OK  %d bayt  %s  %s' % (r['no'], r['bytes'], r['sha256'], r['path']))
    log('PIN: %d/%d OK' % (len(rows), len(rows_all)))
    log('pin_list_sha256: %s' % pin_list_sha256(rows_all))
    log('y8_run.py sha256: %s' % sha256_hex(_read_bytes(script_path)))
    try:
        MK = import_generator(root, derived)
        gen = MK.generate(pin_path(root, 'kod'))
    except (Abort, ValueError, AssertionError, SyntaxError) as e:
        log('KAPI: make_engine_d - %s' % e)
        return 2
    same = all(gen.get(re.split(r'[\\/]', rel)[-1]) == data[no] for no, rel, _, _ in derived if no != PIN_MAKE)
    log('make_engine_d yeniden üretimi diskle aynı: %s' % same)
    if not same:
        log('KAPI: türetilen dosyalar yeniden üretimle aynı değil')
        return 2
    pr = project_root(root)
    for rel, size, sha in DOC_PINS:
        p = pin_path(pr, rel)
        ok = os.path.isfile(p) and os.path.getsize(p) == size and sha256_hex(_read_bytes(p)) == sha
        log('§4.2 %s: %s' % (rel, 'OK' if ok else 'UYARI: uyuşmuyor (yalnız bilgi)'))
    try:
        U = import_common(root, pins)
        smp = build_sample(U, data)
    except (Abort, ValueError, KeyError, TypeError) as e:
        log('KAPI: örneklem - %s: %s' % (type(e).__name__, e))
        return 2
    fam = {f: sum(1 for r in smp['s_cons'] if r['system'] == f) for f in FAMILIES}
    log('örneklem: %d kimlik (%d benzersiz); S_opt %d; S_cons %r; havuzlar %r' % (
        len(smp['ids']), len(set(smp['ids'])), len(smp['s_opt']), fam,
        {f: len(p) for f, p in smp['pools'].items()}))
    log('örneklem kimlikleri: %s' % ','.join(smp['ids']))
    log('sample_ids_sha256: %s' % smp['sha'])
    log('S3 noktaları (örneklem dışı): %s' % {f: (p['id'] if p else None) for f, p in smp['extra'].items()})
    log('öz-test S9 noktaları: S3 ile aynı (SABİT §9)')
    py, npv = versions()
    log('python: %s  numpy: %s' % (py, npv))
    log('yetki dosyası %s: %s' % (YETKI_REL, 'var' if os.path.isfile(pin_path(root, YETKI_REL)) else 'yok'))
    od = pin_path(root, 'out\\' + RUN_ID)
    log('çıktı klasörü out\\%s: %s' % (RUN_ID, 'VAR' if os.path.exists(od) else 'yok'))
    if smp['gate'] or any(p is None for p in smp['extra'].values()):
        log('KAPI: örneklem ön kabulleri - %s' % '; '.join(smp['gate'] or ['örneklem dışı nokta yok']))
        return 2
    if os.path.exists(od):
        log('KAPI: çıktı klasörü var (X2)')
        return 2
    if sabit_state != 'ok':
        log('CHECK-ONLY: pinler ve ön kabuller tamam; SABİT bekleniyor (çıkış 4)')
        return 4
    log('CHECK-ONLY: TAMAM')
    return 0


def _append_jsonl(out_dir, o):
    _write_text(os.path.join(out_dir, OUT_JSONL), json.dumps(o, ensure_ascii=False) + '\n', mode='a')


def evaluate(root, pins, derived, out_dir, log, res):
    """Tek gerçek koşu (yetki ve prerun_gate'ten sonra main() çağırır). res yerinde doldurulur."""
    t0 = time.perf_counter()
    rows_all = list(pins) + list(derived)
    pin_rows, data = verify_pins(root, rows_all)
    res['pins'] = pin_rows
    M = import_models(root, pins, derived)
    U, E, C, ED, CD = M
    C.lower_priority()
    py, npv = versions()
    res['environment'] = dict(python=py, numpy=npv, blas_threads=1)
    smp = build_sample(U, data)
    if smp['gate']:
        raise Abort('örneklem ön kabulleri: %s' % '; '.join(smp['gate']))
    sample = [(r, 'opt') for r in smp['s_opt']] + [(r, 'cons') for r in smp['s_cons']]
    sel = smp['sel']
    res['sample'] = dict(n=len(sample), ids=smp['ids'], sample_ids_sha256=smp['sha'])
    log('örneklem: %d nokta; sample_ids_sha256 %s' % (len(sample), smp['sha']))
    # ---- evre 1: X1 (60 nokta, gecikme kapalı = pinli özgün yol)
    x1rows, ctxs = [], {}
    for k, (pt, st) in enumerate(sample):
        o, ctx = point_x1(M, pt, sel[pt['id']])
        o = U.clean(o)
        o['sample_stratum'] = st
        _append_jsonl(out_dir, o)
        x1rows.append(o)
        ctxs[pt['id']] = ctx
        log('X1 %d/%d %s %s t=%.0fs' % (k + 1, len(sample), o['id'],
                                         'GEÇTİ' if o['ok'] else 'KALDI (%s)' % o.get('reason'), o['t_s']))
    fails = [o for o in x1rows if not o['ok']]
    res['X1'] = dict(ok=not fails, n=len(x1rows), n_fail=len(fails),
                     fail=[(o['id'], o.get('reason'), o.get('error')) for o in fails],
                     max_abs_dkappa=max((o['abs_dkappa'] for o in x1rows if _finite(o.get('abs_dkappa'))), default=None),
                     max_abs_ddGf=max((o['abs_ddGf'] for o in x1rows if _finite(o.get('abs_ddGf'))), default=None))
    res['timings'] = dict(x1_s=time.perf_counter() - t0)
    if fails:
        raise Abort('X1: %d noktada gecikmesiz Stage 1 TSV değerlerini vermedi' % len(fails), kind='X1')
    # ---- evre 2: gecikmeli hesap (yalnız B4)
    t1 = time.perf_counter()
    drows = []
    for k, (pt, st) in enumerate(sample):
        o = U.clean(point_delayed(M, pt, sel[pt['id']], ctxs[pt['id']]))
        o['sample_stratum'] = st
        _append_jsonl(out_dir, o)
        drows.append(o)
        log('D %d/%d %s %s%s t=%.0fs' % (k + 1, len(sample), o['id'], o['status'],
                                         '' if ne_reason(o) is None else ' (%s)' % ne_reason(o), o['t_s']))
    res['timings']['delayed_s'] = time.perf_counter() - t1
    changed = rehash_pins(root, rows_all)
    res['X2'] = dict(start_ok=True, end_ok=not changed, changed=changed)
    if changed:
        raise Abort('X2: koşu sırasında değişen pinler %r' % changed)
    prim = primary_set(drows)
    n_neg, n_pos, k_neg, k_pos = strata_counts(prim)
    row, verdict = decide(True, True, n_neg, n_pos, k_neg, k_pos, U.wilson)
    n, k = n_neg + n_pos, k_neg + k_pos
    lo, hi = U.wilson(n - k, n)
    st_counts = {}
    for r in drows:
        st_counts[r['status']] = st_counts.get(r['status'], 0) + 1
    res['points'] = dict(n=len(drows), status=st_counts,
                         ne=[(r['id'], ne_reason(r)) for r in drows if ne_reason(r) is not None],
                         kod_hatasi_supheli=[r['id'] for r in drows if r.get('error_type') in CODE_ERROR_TYPES])
    res['primary'] = dict(ids=[r['id'] for r in prim], n=n, n_neg=n_neg, n_pos=n_pos, k_neg=k_neg, k_pos=k_pos,
                          ratio_neg=(n_neg - k_neg) / n_neg if n_neg else None,
                          ratio_pos=(n_pos - k_pos) / n_pos if n_pos else None, wilson_lo=lo, wilson_hi=hi,
                          uyumsuz=[(r['id'], r['system']) for r in prim if r['ref_sign'] != _sgn(r['kappa'])])
    res.update(decision_row=row, verdict=verdict, report_only=report_only(drows, prim, x1rows))
    res['timings']['total_s'] = time.perf_counter() - t0
    return res


def selftest_mode(root, pins, derived, out_dir, log, script_path):
    """Y8-B1-l: B2-Ö öz-testi = S3 (3 örneklem dışı nokta, X1 kuralı) + S9 (A2 öz-test noktasında tam gecikmeli)."""
    rows_all = list(pins) + list(derived)
    try:
        verify_pins(root, rows_all)
    except Abort as e:
        log('KAPI: pin - %s' % e)
        return 3
    if os.path.exists(out_dir):
        log('KAPI: öz-test klasörü zaten var: %s' % out_dir)
        return 3
    os.makedirs(out_dir)
    py, npv = versions()
    res = dict(script_sha256=sha256_hex(_read_bytes(script_path)), pin_list_sha256=pin_list_sha256(rows_all),
               python=py, numpy=npv)
    code, err = 1, ''
    try:
        _, data = verify_pins(root, rows_all)
        M = import_models(root, pins, derived)
        U, E, C, ED, CD = M
        C.lower_priority()
        smp = build_sample(U, data)
        ids = set(smp['ids'])
        res['sample_ids_sha256'] = smp['sha']
        res['ornek_on_kabul'] = smp['gate']
        res['ayristirma_esdeger'] = (
            [sorted((k, repr(v)) for k, v in r.items()) for r in smp['rows']]
            == [sorted((k, repr(v)) for k, v in r.items()) for r in U.load_points()]
            and sorted(U.selection()) == sorted(smp['sel']))
        extra = smp['extra']
        if any(p is None or p['id'] in ids for p in extra.values()):
            raise Abort('S3/öz-test noktası bulunamadı ya da örneklemde (körleme)')
        s3, ctxs = {}, {}
        for fam in FAMILIES:
            pt = extra[fam]
            o, ctx = point_x1(M, pt, smp['sel'][pt['id']])
            s3[fam] = U.clean(o)
            ctxs[fam] = ctx
            log('S3 %s %s %s |dk|=%s |ddGf|=%s t=%.1fs' % (fam, pt['id'], 'GEÇTİ' if o['ok'] else 'KALDI',
                                                         o.get('abs_dkappa'), o.get('abs_ddGf'), o['t_s']))
        s9 = {}
        for fam in FAMILIES:                        # SABİT §9 S9: S3'ün üç noktası, A2, B2, C sırasıyla
            pt = extra[fam]
            d = U.clean(point_delayed(M, pt, smp['sel'][pt['id']], ctxs[fam]))
            s9[fam] = d
            log('S9 %s %s %s ne=%s mode=%s eq_maxdev=%s t=%.1fs' % (fam, d['id'], d.get('status'), ne_reason(d),
                                                                    d.get('mode_status'), d.get('eq_maxdev'), d['t_s']))
        checks = {
            'ornek_disi': all(p['id'] not in ids for p in extra.values()),
            'ayristirma_esdeger': res['ayristirma_esdeger'] is True,
            'S3_uc_nokta': all(o['ok'] for o in s3.values()),
            'S9_i_istisnasiz': all(d.get('status') not in ('error', 'ne') for d in s9.values()),
            'S9_ii_eq_ok': all(d.get('eq_ok') is True for d in s9.values()),
            'S9_yapi': all(d.get('names_prefix_ok') is True and d.get('lay0_unchanged') is True
                           and d.get('delay_mass_ok') is True
                           and d.get('n_states') == d.get('n_states0', 0) + 4 * (1 + (d.get('n_cpl') or 0))
                           for d in s9.values()),
        }
        yol = any(d.get('excl') is None and d.get('status') == 'ok'
                  and d.get('mode_status') in ('uyumlu', 'uyusmaz', 'uygulanmaz') for d in s9.values())
        checks['S9_iii_referans_ve_mod_yolu'] = yol
        hard = all(v for k, v in checks.items() if k != 'S9_iii_referans_ve_mod_yolu')
        res.update(S3=s3, S9=s9, checks=checks, passed=hard and yol)
        code = 0 if res['passed'] else (EXIT_USER_WAIT if hard else 1)
        log('öz-test denetimleri: %s' % ', '.join('%s=%s' % kv for kv in checks.items()))
        log('ÖZ-TEST: %s' % ('GEÇTİ' if code == 0 else ('KULLANICI_BEKLIYOR (S9 iii)' if code == EXIT_USER_WAIT
                                                         else 'KALDI')))
    except Exception:  # noqa: BLE001
        err = traceback.format_exc()
        sys.stderr.write(err)
        res['error'] = err[-800:]
        log('ÖZ-TEST: HATA (stderr.txt)')
    write_outputs(out_dir, {OUT_SELFTEST: json.dumps(res, indent=1, ensure_ascii=False)}, log.lines, code, err)
    return code


def write_outputs(out_dir, files, log_lines, exit_code, stderr_text):
    """Mühürleme: verilen dosyalar + stdout.txt, stderr.txt, exit_code.txt, en son SHA256SUMS."""
    for name, text in files.items():
        _write_text(os.path.join(out_dir, name), text)
    _write_text(os.path.join(out_dir, 'stdout.txt'), '\n'.join(log_lines) + '\n')
    _write_text(os.path.join(out_dir, 'stderr.txt'), stderr_text)
    _write_text(os.path.join(out_dir, 'exit_code.txt'), '%d\n' % exit_code)
    names = sorted(n for n in os.listdir(out_dir) if n != 'SHA256SUMS')
    _write_text(os.path.join(out_dir, 'SHA256SUMS'),
                ''.join('%s  %s\n' % (sha256_hex(_read_bytes(os.path.join(out_dir, n))), n) for n in names))


class _Log:
    def __init__(self):
        self.lines = []

    def __call__(self, s):
        self.lines.append(s)
        print(s, flush=True)


def main(argv=None, root=None, pins=None, derived=None, sabit=None, script_path=None):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except (AttributeError, ValueError):
        pass
    root = root or PIN_ROOT.rstrip('\\')
    pins = PINS if pins is None else pins
    derived = DERIVED if derived is None else derived
    sabit = (SABIT_REL, SABIT_SHA256) if sabit is None else sabit
    script_path = script_path or os.path.abspath(__file__)
    log = _Log()
    try:
        env_gate()
    except Abort as e:
        log('KAPI: %s' % e)
        return 3
    ap = argparse.ArgumentParser(description='P93 tek koşu betiği', add_help=False)
    ap.add_argument('--check-only', action='store_true')
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--out-dir')
    ap.add_argument('--run-id')
    ap.add_argument('--yetki')
    try:
        a, extra = ap.parse_known_args(argv)
    except SystemExit:
        log('KAPI: komut satırı çözümlenemedi')
        return 3
    if extra:
        log('KAPI: tanınmayan argüman %r' % (extra,))
        return 3
    run_args = a.run_id is not None or a.yetki is not None
    if a.check_only:
        if a.selftest or a.out_dir is not None or run_args:
            log('KAPI: --check-only başka kiple birlikte verilemez')
            return 3
        return check_only(root, pins, derived, sabit, log, script_path)
    if a.selftest:
        if run_args or not a.out_dir:
            log('KAPI: --selftest yalnız --out-dir ile verilir (--run-id/--yetki olmadan)')
            return 3
        return selftest_mode(root, pins, derived, os.path.abspath(a.out_dir), log, script_path)
    if a.out_dir is not None:
        log('KAPI: --out-dir yalnız --selftest ile')
        return 3
    if not (a.run_id and a.yetki):
        log('KAPI: gerçek kip --run-id ve --yetki ister; çalışmadı')
        return 3
    try:
        y = verify_authorization(root, a.yetki, a.run_id, pins, derived, sabit, script_path)
        ssha = prerun_gate(root, pins, derived, y)
    except ValueError as e:
        log('KAPI: yetki reddedildi - %s' % e)
        return 3
    out_dir = pin_path(root, 'out\\' + a.run_id)
    if os.path.exists(out_dir):
        log('KAPI: %s zaten var; yeniden koşu yok (X2: koşu başlamadı)' % out_dir)
        return 3
    os.makedirs(out_dir)
    ysha = sha256_hex(_read_bytes(a.yetki))
    log('run_id: %s' % a.run_id)
    log('yetki: OK (%s, sha256 %s); sample_ids_sha256 %s' % (YETKI_REL, ysha, ssha))
    res = dict(run_id=a.run_id, script_sha256=sha256_hex(_read_bytes(script_path)),
               pin_list_sha256=pin_list_sha256(list(pins) + list(derived)),
               sabit=dict(path=sabit[0], sha256=sabit[1]),
               yetki=dict(path=YETKI_REL, sha256=ysha, dayanak=y.get('dayanak'), yazan=y.get('yazan')))
    err = ''
    try:
        evaluate(root, pins, derived, out_dir, log, res)
        code = 0
    except Abort as e:
        row, verdict = decide(e.kind != 'X1', e.kind != 'X2', 0, 0, 0, 0, None)
        res.update(decision_row=row, verdict=verdict, abort_kind=e.kind, abort_reason=str(e))
        code = 2
    except (Exception, KeyboardInterrupt):  # noqa: BLE001  (Y8-B1-m: tek koşuyu tüketir, kayıt bırakılır)
        err = traceback.format_exc()
        sys.stderr.write(err)
        res.update(verdict=None, decision_row=None, error='beklenmeyen hata; stderr.txt')
        code = 1
    line = verdict_line(res)
    log(line)
    files = {OUT_PINS: json.dumps(dict(pins=res.get('pins'), sabit=res.get('sabit'), yetki=res.get('yetki')),
                                  indent=1, ensure_ascii=False),
             OUT_RESULT: json.dumps(res, indent=1, ensure_ascii=False),
             OUT_VERDICT: line + '\n'}
    write_outputs(out_dir, files, log.lines, code, err)
    return code


if __name__ == '__main__':
    sys.exit(main())
