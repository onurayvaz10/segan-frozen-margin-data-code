"""P93 sentetik testleri, v2.1 (SABİT v1.0 §9: S1, S2, S4, S5, S6, S7, S8, S10; S3 ve S9 öz-testtedir: y8_run --selftest).
Yazar: B1 alt-ajanı run_tag Y8GK4M-W1, 2026-10-26 (revizyon turu 1; v1 arşivi kod/archive/y8_synth_test_v1_20261026.py).

Körleme. Örneklemdeki 60 noktanın hiçbirinde gecikmeli değer hesaplanmaz: gecikmeli rhs/jac/Layout ve S10 yolu yalnız
E.two_bus_system() (el yapımı sistem, A2/B2/C ailelerinde değil) üzerinde değerlendirilir. Gerçek kipte koşu yoktur:
yetki testleri --work-dir altındaki geçici kökte sahte SABİT, sahte denetim raporu ve sahte B2 özetiyle yapılır; hepsi
hesaba geçmeden reddedilir ya da yalnız verify_authorization / prerun_gate düzeyinde kabul edilir. Geçici kökteki
pinli girdiler gerçek dosyaların kopyasıdır (yalnız hash ve örneklem kimliği kapısı için; gecikmesiz, körleme dışı).
El yapımı girdiler: synth_y8/karar_durumlari.json ve bu dosyadaki S5 tabloları (beklenen değerler elle kuruldu).

Bölümler
  T0  make_engine_d: yeniden üretim diskle bayt bayt aynı; çapa hataları ve kaynak pin uyuşmazlığı; tek satır farkı.
  S1  Padé bloğu: ED._delay'den çıkarılan (A, B, C, D) = ([[0,2],[-6,-6]]/T_d, [0,6]/T_d, [0,-2], 1) (elle); H(jω),
      ω ∈ {0, 60, 600, 6000, 2e4} rad/s'de [2/2] Padé ile göreli hata < 1e-10; |H(0) - 1| < 1e-12.
  S2  E.two_bus_system(), sabit tohumlu rastgele x: (i) ctrl_delay yokken ED.rhs == E.rhs bit düzeyinde, Layout aynı;
      (ii) ctrl_delay, rotate=False, tüm q = 0: fiziksel satırlar E.rhs ile bit düzeyinde aynı, f_p = 0.
  S4  karar tablosu (her satır, 7/8, 19/20, 0.75, Wilson n=28 k=2/3, n=60 k=8/9), birincil küme ve NE nedenleri,
      X1 TSV toleransı, yalnız rapor (a)-(n), uçtan uca dört hüküm.
  S5  el yapımı points/selection: str sıralama, sorted(rng.choice), i -> aile, 60 benzersiz, 18 + 3x14; KAPI dalları.
  S6  ED.jac (karmaşık adım) ile merkezi fark, two_bus, gecikme açık, rotate=True, z != 1, dw != 0.
  S7  dönme işareti (_delay: u=(1,0), φ>0 -> (cos φ, -sin φ)) ve rhs'ten çıkarılan açı (GFM WB z T_d, CPL WB(1+dw) T_d).
  S8  gecikme bloğu J/M = [[0,2],[-6,-6]]/T_d, giriş 6/T_d, özdeğerler (-3 ± j√3)/T_d.
  S10 two_bus + ctrl_delay: delayed_core (dispatch, stage1_at, reference_margin(alpha_tab=tab0), mod kimliği) istisnasız;
      bracket genişliği <= 1e-9; mode_status tanımlı.
  K   kapılar (yetki alanları, yol, sürümler, B2 özetleri, ortam değişkeni, U yolu, örneklem kimliği, klasör, kipler).
  W   write_outputs / SHA256SUMS, hüküm satırı.
  M   statik denetim duyarlılığı: değiştirilmemiş betik GEÇTİ; her mutasyon beklenen S maddesinde KALDI.
Kullanım: python -I -B y8_synth_test.py --work-dir <henüz olmayan klasör>
Çıkış: 0 = GEÇTİ, 1 = KALDI.
"""
import argparse
import cmath
import contextlib
import hashlib
import io
import json
import math
import os
import sys
import time
import traceback

for _v in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[_v] = '1'
import numpy as np  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SYNTH = os.path.join(HERE, 'synth_y8', 'karar_durumlari.json')
if HERE not in sys.path:
    sys.path.insert(0, HERE)
import y8_run as Y  # noqa: E402
import y8_static_check as SC  # noqa: E402
import make_engine_d as MK  # noqa: E402

RESULTS = []
RUN_ID = Y.RUN_ID


def record(name, ok, detail=''):
    RESULTS.append((name, bool(ok), detail))
    print('%-10s %s%s' % (name, 'GEÇTİ' if ok else 'KALDI', '' if ok and not detail else '  ' + str(detail)), flush=True)


def _rb(p):
    with open(p, 'rb') as fh:
        return fh.read()


def _wb(p, b):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, 'wb') as fh:
        fh.write(b)


def _sha(b):
    return hashlib.sha256(b).hexdigest()


def quiet(fn, *a, **k):
    buf, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(err):
        r = fn(*a, **k)
    return r, buf.getvalue() + err.getvalue()


@contextlib.contextmanager
def isolated(tr):
    """Geçici kökün y_common / make_engine_d modüllerini yükletmek için önbellektekiler geçici olarak çıkarılır, sonra geri konur."""
    names = ('y_common', 'make_engine_d')
    saved = {n: sys.modules.pop(n, None) for n in names}
    try:
        yield
    finally:
        for n in names:
            sys.modules.pop(n, None)
            if saved[n] is not None:
                sys.modules[n] = saved[n]
        kd = Y.pin_path(tr, 'kod')
        while kd in sys.path:
            sys.path.remove(kd)


def load_all():
    rows, data = Y.verify_pins(ROOT, list(Y.PINS) + list(Y.DERIVED))
    import y_common as U
    import ext_engine as E
    import ext_common as C
    import ext_engine_d as ED
    import ext_common_d as CD
    for mod, rel in ((U, Y.PINS[2][1]), (E, Y.PINS[0][1]), (C, Y.PINS[1][1]), (ED, Y.DERIVED[1][1]),
                     (CD, Y.DERIVED[2][1])):
        assert Y._same_file(mod.__file__, Y.pin_path(ROOT, rel)), mod.__file__
    assert C.E is E and CD.E is ED
    return data, U, E, C, ED, CD


# ============================================================================================ T0
def section_T0(work, E, ED):
    outs = MK.generate(HERE)
    for name, b in sorted(outs.items()):
        record('T0-%s' % name[:-3], _rb(os.path.join(HERE, name)) == b, 'diskle bayt bayt aynı')
    record('T0-DERIVED', all(os.path.getsize(Y.pin_path(ROOT, r[1])) == r[2] and _sha(_rb(Y.pin_path(ROOT, r[1]))) == r[3]
                             for r in Y.DERIVED), 'literal = disk')
    a = _rb(os.path.join(HERE, 'ext_common.py')).decode('utf-8').split('\n')
    b = _rb(os.path.join(HERE, 'ext_common_d.py')).decode('utf-8').split('\n')
    diff = [k for k in range(len(a)) if a[k] != b[k]] if len(a) == len(b) else None
    record('T0-tek-satir', diff is not None and len(diff) == 1, 'fark %r' % (diff,))
    for tag, args in (('cifte-capa', ('x\nA\nA\n', (('i', 'A\n', 'after', 'B\n'),))),
                      ('eksik-capa', ('x\n', (('y', 'A\n', 'before', 'B\n'),)))):
        try:
            MK.apply_insertions(*args)
            record('T0-%s' % tag, False, 'yakalanmadı')
        except AssertionError:
            record('T0-%s' % tag, True)
    d = os.path.join(work, 't0')
    _wb(os.path.join(d, 'ext_engine.py'), _rb(os.path.join(HERE, 'ext_engine.py')) + b'#')
    try:
        MK.load_source('ext_engine.py', d)
        record('T0-kaynak-pin', False, 'değişmiş kaynak kabul edildi')
    except ValueError:
        record('T0-kaynak-pin', True)
    record('T0-DELAY_NAMES', ED.DELAY_NAMES == ['Dpd', 'Dqd', 'Dpq', 'Dqq']
           and E.Layout(E.two_bus_system()).names == ED.Layout(E.two_bus_system()).names)


# ============================================================================================ S1
def delay_block(ED, xv, ud, uq, rotate=False, phi=0.0):
    ix = {'X:Dpd': 0, 'X:Dqd': 1, 'X:Dpq': 2, 'X:Dqq': 3}
    f = np.zeros(4)
    yd, yq = ED._delay(f, ix, 'X:', ud, uq, np.asarray(xv, float), dict(Td=Y.TD, rotate=rotate), phi)
    return f, np.array([yd, yq])


def section_S1(ED):
    Td = Y.TD
    A, Cm, B, D = np.zeros((4, 4)), np.zeros((2, 4)), np.zeros((4, 2)), np.zeros((2, 2))
    for j in range(4):
        e = np.zeros(4)
        e[j] = 1.0
        A[:, j], Cm[:, j] = delay_block(ED, e, 0.0, 0.0)
    for j in range(2):
        u = [0.0, 0.0]
        u[j] = 1.0
        B[:, j], D[:, j] = delay_block(ED, np.zeros(4), u[0], u[1])
    # elle: kanal başına (A, B, C, D) = ([[0,2],[-6,-6]]/T_d, [0,6]/T_d, [0,-2], 1); _delay kütle T_d ile f = T_d x'
    A_hand = np.array([[0.0, 2.0], [-6.0, -6.0]])
    B_hand, C_hand = np.array([0.0, 6.0]), np.array([0.0, -2.0])
    ok_m = all(np.array_equal(A[2 * c:2 * c + 2, 2 * c:2 * c + 2], A_hand) and np.array_equal(B[2 * c:2 * c + 2, c], B_hand)
               and np.array_equal(Cm[c, 2 * c:2 * c + 2], C_hand) and D[c, c] == 1.0 for c in range(2))
    cross = np.count_nonzero(A[0:2, 2:4]) + np.count_nonzero(A[2:4, 0:2]) + np.count_nonzero(B[0:2, 1]) + \
        np.count_nonzero(B[2:4, 0]) + np.count_nonzero(D - np.eye(2))
    record('S1-matrisler-elle', ok_m and cross == 0, 'A, B, C, D = elle kurulan; kanallar arası sıfır')
    worst = 0.0
    for w in (0.0, 60.0, 600.0, 6000.0, 2e4):
        s = 1j * w
        H = C_hand @ np.linalg.solve(s * np.eye(2) - A_hand / Td, B_hand / Td) + 1.0
        Hi = Cm @ np.linalg.solve(s * Td * np.eye(4) - A, B) + D
        st = s * Td
        Hp = (1 - st / 2 + st * st / 12) / (1 + st / 2 + st * st / 12)
        worst = max(worst, abs(H - Hp) / abs(Hp), abs(Hi[0, 0] - Hp) / abs(Hp), abs(Hi[1, 1] - Hp) / abs(Hp))
    record('S1-pade-5-frekans', worst < 1e-10, 'en kötü göreli hata %.2e (ω = 0, 60, 600, 6000, 2e4 rad/s)' % worst)
    H0 = C_hand @ np.linalg.solve(-A_hand / Td, B_hand / Td) + 1.0
    record('S1-DC', abs(H0 - 1.0) < 1e-12, '|H(0)-1| = %.1e' % abs(H0 - 1.0))


# ============================================================================================ S2, S6, S7, S8
def two_bus_state(E, rng, delay_states=0):
    lay = E.Layout(E.two_bus_system())
    x = rng.uniform(-0.5, 0.5, size=lay.n)
    x[lay.ix['C0:vdc']] = 1.4
    refs = np.array([0.6, 0.05, 1.0, 1.3, 0.02])
    return lay, x, refs, np.array([0.0, 0.2])


def delayed_two_bus(ED, E, rotate):
    sysd = E.two_bus_system()
    sysd['ctrl_delay'] = dict(Td=Y.TD, rotate=rotate)
    return ED.Layout(sysd)


def section_S2(E, ED):
    rng = np.random.default_rng(20261026)
    lay, x, refs, G = two_bus_state(E, rng)
    layD = ED.Layout(E.two_bus_system())
    same = lay.names == layD.names and np.array_equal(lay.M, layD.M) and \
        np.array_equal(E.rhs(lay, x, refs, G), ED.rhs(layD, x, refs, G))
    record('S2-i-gecikme-yok', same, 'Layout ve rhs bit düzeyinde aynı')
    layd = delayed_two_bus(ED, E, rotate=False)
    n0 = lay.n
    xd = np.zeros(layd.n)
    xd[:n0] = x
    for nm in layd.names[n0:]:
        if ':Dp' in nm:
            xd[layd.ix[nm]] = rng.uniform(-1, 1)          # p rastgele, q = 0
    fd = ED.rhs(layd, xd, refs, G)
    fp = [fd[layd.ix[nm]] for nm in layd.names[n0:] if ':Dp' in nm]
    record('S2-ii-q0', np.array_equal(fd[:n0], E.rhs(lay, x, refs, G)) and all(v == 0.0 for v in fp),
           'fiziksel satırlar aynı, f_p = 0 (%d gecikme durumu)' % (layd.n - n0))


def jac_state(E, ED):
    """S6/S7/S8 için el yapımı durum: two_bus gecikmesiz dengesi + bozulma; P_ref kaydırılır (z != 1), eps != 0 (dw != 0)."""
    lay0 = E.Layout(E.two_bus_system())
    G, P = np.array([0.0, 0.2]), [0.65]
    d = E.dispatch(lay0, P, G, tol=1e-12)
    layd = delayed_two_bus(ED, E, rotate=True)
    rng = np.random.default_rng(7)
    xd = np.zeros(layd.n)
    xd[:lay0.n] = d['x'] + 1e-3 * rng.normal(size=lay0.n)
    xd[layd.ix['C0:eps']] += 0.02
    for nm in layd.names[lay0.n:]:
        xd[layd.ix[nm]] = 0.1 * rng.normal()
    refs = np.array(d['refs'], float)
    refs[0] += 0.05
    return lay0, layd, xd, refs, G


def zdw(layd, x, refs):
    g = layd.sysd['par']['gfm']
    q = layd.sysd['cpls'][0]['par']
    ix = layd.ix
    z = g['w_ref'] + g['Rp'] * (refs[0] - x[ix['G:pm']])
    thp = x[ix['C0:thp']]
    Vqp = -math.sin(thp) * x[ix['C0:Vrf']] + math.cos(thp) * x[ix['C0:Vif']]
    return z, q['kp_pll'] * Vqp + q['ki_pll'] * x[ix['C0:eps']]


def section_S6(E, ED):
    lay0, layd, x, refs, G = jac_state(E, ED)
    z, dw = zdw(layd, x, refs)
    J = ED.jac(layd, x, refs, G)
    worst = 0.0
    for k in range(layd.n):
        h = 1e-7 * max(1.0, abs(x[k]))
        xp, xm = x.copy(), x.copy()
        xp[k] += h
        xm[k] -= h
        Jk = (ED.rhs(layd, xp, refs, G) - ED.rhs(layd, xm, refs, G)) / (2 * h)
        worst = max(worst, float(np.max(np.abs(Jk - J[:, k]))) / max(1.0, float(np.max(np.abs(J[:, k])))))
    record('S6-jacobian', worst <= 1e-6 and abs(z - 1) > 1e-6 and abs(dw) > 1e-6,
           'en kötü sütun göreli fark %.2e; z-1 = %.2e, dw = %.2e' % (worst, z - 1, dw))


def set_p_to_u(ED, layd, x, refs, G, n0):
    """Dönme kapalı düzende q = 0 ve p == u (f[Dq] tam sıfır) bulunur."""
    x = x.copy()
    x[n0:] = 0.0
    f0 = ED.rhs(layd, x, refs, G)
    for nm in layd.names[n0:]:
        if not nm.endswith(('Dqd', 'Dqq')):
            continue
        iq, ip = layd.ix[nm], layd.ix[nm.replace(':Dq', ':Dp')]
        p = f0[iq] / 6.0
        for _ in range(200):
            x[ip] = p
            r = ED.rhs(layd, x, refs, G)[iq]
            if r == 0.0:
                break
            p = np.nextafter(p, np.inf if r > 0 else -np.inf)
        else:
            raise AssertionError('p = u bulunamadı')
    return x


def section_S7(E, ED):
    phi = 0.3
    f, y = delay_block(ED, np.zeros(4), 1.0, 0.0, rotate=True, phi=phi)
    record('S7-isaret', abs(y[0] - math.cos(phi)) < 1e-15 and abs(y[1] + math.sin(phi)) < 1e-15,
           'u=(1,0), φ=0.3 -> (%.6f, %.6f)' % tuple(y))
    lay0, layr, x, refs, G = jac_state(E, ED)
    layn = delayed_two_bus(ED, E, rotate=False)
    n0 = lay0.n
    x = set_p_to_u(ED, layn, x, refs, G, n0)
    fn, fr = ED.rhs(layn, x, refs, G), ED.rhs(layr, x, refs, G)
    ix = layn.ix
    z, dw = zdw(layn, x, refs)

    def angle_from(th, dr, di, ud, uq):
        c, s = math.cos(th), math.sin(th)
        vd, vq = ud + (c * dr + s * di), uq + (-s * dr + c * di)       # park(th, Δ) = v - u
        return cmath.phase(complex(ud, uq)) - cmath.phase(complex(vd, vq))

    phiG = angle_from(x[ix['G:th']], fr[ix['G:Irc']] - fn[ix['G:Irc']], fr[ix['G:Iic']] - fn[ix['G:Iic']],
                      x[ix['G:Dpd']], x[ix['G:Dpq']])
    phiC = angle_from(x[ix['C0:thp']], -(fr[ix['C0:Irc']] - fn[ix['C0:Irc']]), -(fr[ix['C0:Iic']] - fn[ix['C0:Iic']]),
                      x[ix['C0:Dpd']], x[ix['C0:Dpq']])
    eG = abs(phiG - E.WB * z * Y.TD) / (E.WB * z * Y.TD)
    eC = abs(phiC - E.WB * (1 + dw) * Y.TD) / (E.WB * (1 + dw) * Y.TD)
    record('S7-aci-kaynagi', eG < 1e-9 and eC < 1e-9, 'GFM göreli %.1e, CPL göreli %.1e (z=%.5f, dw=%.2e)'
           % (eG, eC, z, dw))


def section_S8(E, ED):
    lay0, layd, x, refs, G = jac_state(E, ED)
    J = ED.jac(layd, x, refs, G)
    i = [layd.ix['G:Dpd'], layd.ix['G:Dqd']]
    sub = J[np.ix_(i, i)] / layd.M[i][:, None]
    want = np.array([[0.0, 2.0], [-6.0, -6.0]]) / Y.TD
    ev = np.sort_complex(np.linalg.eigvals(sub))
    ev_want = np.sort_complex(np.array([(-3 - 1j * math.sqrt(3)) / Y.TD, (-3 + 1j * math.sqrt(3)) / Y.TD]))
    f, _ = delay_block(ED, np.zeros(4), 1.0, 0.0)
    record('S8-blok', np.max(np.abs(sub - want)) <= 1e-12 * np.max(np.abs(want))
           and np.max(np.abs(ev - ev_want)) <= 1e-9 * abs(ev_want[0]) and f[1] / Y.TD == 6.0 / Y.TD,
           'J/M alt matrisi, özdeğerler %s' % ev)


def section_S10(M):
    U, E, C, ED, CD = M
    lay0 = E.Layout(E.two_bus_system())
    G, P = np.array([0.0, 0.20]), [0.65]
    try:
        ctx = Y.x1_context(E, lay0, P, G)
        o = {}
        Y.delayed_core(M, lay0, G, P, ctx, o)
        br = o.get('bracket')
        width_ok = o.get('ref_status') != 'alpha' or (br is not None and br[1] - br[0] <= 1e-9)
        record('S10-two_bus-yol', o.get('status') == 'ok' and width_ok and o.get('mode_status') is not None
               and 'lay0' and 'ctrl_delay' not in lay0.sysd,
               'durum %s, ref_status %s, braket %s, mode_status %s, eq_ok %s' % (
                   o.get('status'), o.get('ref_status'), None if br is None else '%.1e' % (br[1] - br[0]),
                   o.get('mode_status'), o.get('eq_ok')))
    except Exception:  # noqa: BLE001
        record('S10-two_bus-yol', False, traceback.format_exc()[-600:])


# ============================================================================================ S4
def section_S4(U, syn):
    for c in syn['decide']:
        got = Y.decide(c['x1'], c['x2'], c['n_neg'], c['n_pos'], c['k_neg'], c['k_pos'], U.wilson)
        record('S4-%s' % c['ad'][:40], got == (c['satir'], c['hukum']), 'beklenen %s/%s, bulunan %s/%s'
               % (c['satir'], c['hukum'], got[0], got[1]))
    bk = syn['birincil_kume']
    prim = Y.primary_set(bk['satirlar'])
    cnt = Y.strata_counts(prim)
    row = Y.decide(True, True, *cnt, U.wilson)[0]
    record('S4-birincil-kume', [r['id'] for r in prim] == bk['beklenen_ids'] and list(cnt) == bk['beklenen_sayilar']
           and row == bk['beklenen_satir'], 'ids %s, sayılar %s, satır %s' % ([r['id'] for r in prim], cnt, row))
    ne = {r['id']: Y.ne_reason(r) for r in bk['satirlar'] if Y.ne_reason(r) is not None}
    record('S4-NE-nedenleri', ne == bk['beklenen_ne'], ne)
    record('S4-birincil-NaN', Y.primary_set([dict(id='n', status='ok', kappa=float('nan'), ref_sign=1,
                                                  mode_status='uyumlu', eq_ok=True)]) == [])
    for c in syn['x1']:
        ok = Y.x1_check(c['rec0'], c['muhur'])[0]
        record('S4-X1-%s' % c['ad'][:34], ok == c['gecer'], 'bulunan %s' % ok)
    record('S4-X1-NaN', Y.x1_check(dict(excl=None, kappa=0.2, dGf=float('nan')), dict(kappa=0.2, dGf=0.1))[0] is False)
    rp = syn['rapor']
    prim = Y.primary_set(rp['d'])
    ro = Y.report_only(rp['d'], prim, rp['x1'])
    be = rp['beklenen']

    def near(x, y_):
        return x is not None and abs(x - y_) <= 1e-12

    a, b = ro['a_gecikmesiz_kappa_gecikmeli_yon'], ro['b_yon_degisimi']
    ck, co = ro['c_goreli_degisim']['kappa'], ro['c_goreli_degisim']['omega']
    checks = [
        [a['birincil']['n'], a['birincil']['uyum']] == be['a_birincil_n_uyum'],
        [b['n'], b['n_farkli'], b['ids']] == be['b_n_farkli_ids'],
        ck['n'] == 2 and all(near(ck[k], v) for k, v in zip(('median', 'min', 'max'), be['c_kappa_n_median_min_max'][1:])),
        co['n'] == 2 and all(near(co[k], v) for k, v in zip(('median', 'min', 'max'), be['c_omega_n_median_min_max'][1:])),
        ro['d_dislanan']['nedenler'] == be['d_nedenler'],
        [[e['id'] for e in ro['e_uyumsuzluk_eps2']], [e['abs_eps2'] for e in ro['e_uyumsuzluk_eps2']]]
        == be['e_ids_abs_eps2'],
        near(ro['f_set_noktasi_max_abs_degisim'].get('V_ref_dc_C0'), be['f_V_ref_dc_C0']),
        ro['i_aile'] == be['i_aile'], ro['j_tekil_kume'] == be['j_tekil_kume'],
        ro['k_mod']['durum'] == be['k_mod_durum'],
        ro['m_sabit_kural'] == be['m_sabit_kural'],
        ro['n_mod_uyusmaz_uyum'] == dict(n=0, uyum=0, ne_mod_kimligi=0, ne_mod_hesap=0),
    ]
    record('S4-yalniz-rapor-a-n', all(checks), 'alt denetimler %s' % checks)
    mis = [dict(id='u1', status='ok', kappa=0.3, ref_sign=1, mode_status='uyusmaz', eq_ok=True),
           dict(id='u2', status='ok', kappa=-0.3, ref_sign=1, mode_status='uyusmaz', eq_ok=True),
           dict(id='h1', status='ok', kappa=0.3, ref_sign=1, mode_status='hesap', eq_ok=True)]
    for r in mis:
        r['sealed'] = dict(kappa=0.3, ref_sign=1, dGf=0.1, dGref=0.1, omega=10.0)
    rn = Y.report_only(mis, Y.primary_set(mis), [])['n_mod_uyusmaz_uyum']
    record('S4-rapor-n', rn == dict(n=2, uyum=1, ne_mod_kimligi=2, ne_mod_hesap=1), rn)
    record('S4-mcnemar', Y.mcnemar_exact(0, 0) == 1.0 and Y.mcnemar_exact(0, 3) == 0.25
           and Y.mcnemar_exact(1, 4) == 0.375, 'p(0,3) = 2/8, p(1,4) = 2*6/32')

    def mk(nn, np_, kn, kp):
        rows = [dict(id='n%d' % i, status='ok', kappa=-0.2, ref_sign=(1 if i < kn else -1), mode_status='uyumlu',
                     eq_ok=True) for i in range(nn)]
        rows += [dict(id='p%d' % i, status='ok', kappa=0.3, ref_sign=(-1 if i < kp else 1), mode_status='uygulanmaz',
                      eq_ok=True) for i in range(np_)]
        rows += [dict(id='t', status='ok', kappa=0.3, ref_sign=0, mode_status='uyumlu', eq_ok=True),
                 dict(id='x', status='error', kappa=None, ref_sign=None, error_type='ValueError')]
        return rows
    for tag, args, want in (('TUTARLI', (18, 42, 0, 0), 'TUTARLI'), ('KISMI', (18, 42, 0, 1), 'KISMİ'),
                            ('RET', (18, 42, 5, 0), 'RET'), ('NE', (7, 42, 0, 0), 'NOT_EVALUABLE')):
        prim = Y.primary_set(mk(*args))
        got = Y.decide(True, True, *Y.strata_counts(prim), U.wilson)[1]
        record('S4-ucuca-%s' % tag, got == want and len(prim) == args[0] + args[1], 'bulunan %s' % got)


# ============================================================================================ S5
def s5_tables():
    """El yapımı tablolar (U.num çıktısı biçiminde). Havuzlar 15'er (str sırası P1, P10..P15, P2..P9 sınanır)."""
    def row(i, fam, k, rs, **kw):
        r = dict(id=i, system=fam, kappa=k, abs_kappa=abs(k), dGf=0.1, ref_sign=rs, ref_status='alpha', censored=False,
                 stage1_pin_ok=True)
        r.update(kw)
        return r
    rows = []
    for fam in ('C', 'A2', 'B2'):
        rows += [row('%s-P%d' % (fam, j), fam, 0.06 + 0.01 * j, 1.0) for j in range(15, 0, -1)]
    rows += [row('%s-N%d' % ('A2B2C'[j % 3] if False else ('A2', 'B2', 'C')[j % 3], j), ('A2', 'B2', 'C')[j % 3],
                 -0.1 - 0.001 * j, -1.0) for j in range(1, 19)]
    rows += [row('A2-X1', 'A2', 0.3, 1.0, censored=True), row('A2-X2', 'A2', 0.3, 0.0),
             row('A2-X3', 'A2', 0.04, 1.0), row('A2-X4', 'A2', 0.3, 1.0, stage1_pin_ok=False),
             row('A2-X5', 'A2', -0.3, -1.0, ref_status='censored (stable up to dG_max)')]
    sel = [dict(id=r['id'], system=r['system']) for r in rows]
    return rows, sel


def section_S5(U):
    rows, sel = s5_tables()
    s_opt, s_cons, pools = Y.sample_points(U, rows)
    opt_want = sorted('%s-N%d' % (('A2', 'B2', 'C')[j % 3], j) for j in range(1, 19))
    record('S5-S_opt', [r['id'] for r in s_opt] == opt_want, '18 iyimser, str sırası, dışlananlar (X1-X5) yok')
    ok = True
    info = []
    for i, fam in enumerate(('A2', 'B2', 'C')):
        pool = sorted('%s-P%d' % (fam, j) for j in range(1, 16))
        ok &= [r['id'] for r in pools[fam]] == pool
        idx = sorted(int(k) for k in np.random.default_rng(20261126 + i).choice(15, size=14, replace=False))
        got = [r['id'] for r in s_cons if r['system'] == fam]
        ok &= got == [pool[j] for j in idx]
        info.append('%s dışarıda %s' % (fam, sorted(set(pool) - set(got))))
    record('S5-S_cons', ok and pool[:3] == ['C-P1', 'C-P10', 'C-P11'], '; '.join(info))
    ids = [r['id'] for r in s_opt + s_cons]
    record('S5-60-gate', len(set(ids)) == 60 and Y.sample_gate(rows, sel, s_opt, s_cons, pools) == [])
    record('S5-kimlik-sha', Y.sample_ids_sha256(ids) == _sha(''.join(i + '\n' for i in ids).encode('utf-8')))

    def gate(rows_, sel_):
        so, sc, pl = Y.sample_points(U, rows_)
        return Y.sample_gate(rows_, sel_, so, sc, pl)
    r17 = [r for r in rows if r['id'] != 'A2-N3']
    g = gate(r17, sel)
    record('S5-KAPI-opt17', any('|S_opt| = 17' in w for w in g), g)
    r14 = [r for r in rows if r['id'] != 'B2-P7']
    g = gate(r14, sel)
    record('S5-KAPI-havuz14', any('havuz B2 = 14' in w for w in g), g)
    g = gate(rows, [p for p in sel if p['id'] != 'C-P1'] + [dict(id='A2-N1', system='A2')])
    record('S5-KAPI-kimlik-yok-cift', any('tam bir kez' in w for w in g), g)
    g = gate([{k: v for k, v in r.items() if k != 'dGf'} for r in rows], sel)
    record('S5-KAPI-eksik-alan', any('zorunlu alan' in w for w in g), g)
    g = gate(rows, sel + [dict(id='Z')])
    record('S5-KAPI-secim-alan', any('id/system' in w for w in g), g)


# ============================================================================================ K
def build_temp_root(work, U, data):
    tr = os.path.join(work, 'kok')
    for no, rel, size, sha in list(Y.PINS) + list(Y.DERIVED):
        _wb(Y.pin_path(tr, rel), _rb(Y.pin_path(ROOT, rel)))
    for name in ('y8_run.py', 'y8_static_check.py', 'y8_synth_test.py'):
        _wb(os.path.join(tr, 'kod', name), _rb(os.path.join(HERE, name)))
    _wb(Y.pin_path(tr, Y.SABIT_REL), 'SENTETİK SABİT (yalnız kapı testi)\n'.encode('utf-8'))
    _wb(Y.pin_path(tr, Y.AUDIT_REL), 'SENTETİK DENETİM RAPORU (yalnız kapı testi)\n'.encode('utf-8'))
    b2 = os.path.join(work, 'b2', 'P93STATIC_sentetik', 'SHA256SUMS')
    _wb(b2, b'0' * 64 + b'  stdout.txt\n')
    script = os.path.join(tr, 'kod', 'y8_run.py')
    sabit = (Y.SABIT_REL, _sha(_rb(Y.pin_path(tr, Y.SABIT_REL))))
    py, npv = Y.versions()
    good = dict(action=Y.ACTION, run_id=RUN_ID, sabit_sha256=sabit[1],
                script_sha256={n: _sha(_rb(os.path.join(tr, 'kod', n))) for n in Y.SCRIPT_KEYS},
                derived_sha256={n: [r[3] for r in Y.DERIVED if r[1].endswith(n)][0] for n in Y.DERIVED_KEYS},
                pin_list_sha256=Y.pin_list_sha256(list(Y.PINS) + list(Y.DERIVED)),
                sample_ids_sha256=Y.build_sample(U, data)['sha'], python=py, numpy=npv,
                b2_sha256sums={'b2\\P93STATIC_sentetik\\SHA256SUMS': _sha(_rb(b2))},
                code_audit_report=dict(path=Y.AUDIT_REL, sha256=_sha(_rb(Y.pin_path(tr, Y.AUDIT_REL)))),
                dayanak=['D-260'], yazan='sentetik test (B1 ön-koşusu; gerçek yetki değil)')
    return tr, script, sabit, good


def write_yetki(tr, doc, rel=None):
    p = Y.pin_path(tr, rel or Y.YETKI_REL)
    _wb(p, (doc if isinstance(doc, str) else json.dumps(doc, ensure_ascii=False)).encode('utf-8'))
    return p


def section_K(work, U, data):
    tr, script, sabit, good = build_temp_root(work, U, data)
    yp = write_yetki(tr, good)

    def va(path=yp, run_id=RUN_ID, sab=None):
        try:
            Y.verify_authorization(tr, path, run_id, Y.PINS, Y.DERIVED, sab or sabit, script)
            return None
        except ValueError as e:
            return str(e)

    record('K-olumlu-yetki', va() is None, 'geçerli sahte yetki kabul (yalnız doğrulama)')

    def bad(tag, mutate, needle, rel=None, run_id=RUN_ID, sab=None):
        doc = json.loads(json.dumps(good))
        out = mutate(doc)
        p = write_yetki(tr, out if out is not None else doc, rel)
        msg = va(p, run_id, sab)
        write_yetki(tr, good)
        record('K-%s' % tag, msg is not None and needle in msg, msg)

    bad('action', lambda d: d.update(action='ALLOW_P92_RUN'), 'action')
    bad('run_id-baska', lambda d: d.update(run_id='P93_20261026_b'), 'run_id', run_id='P93_20261026_b')
    bad('run_id-uyusmaz', lambda d: d.update(run_id='P93_20261026_b'), 'run_id uyuşmuyor')
    bad('yanlis-yol', lambda d: None, 'yetki dosyası yolu', rel='protokol\\P93_yetki.json')
    bad('json-degil', lambda d: '{bozuk', 'JSON değil')
    bad('sozluk-degil', lambda d: '[1]', 'sözlük değil')
    bad('sabit-yer-tutucu', lambda d: None, 'SABİT hash betikte doldurulmadı', sab=(Y.SABIT_REL, None))
    bad('sabit-disk', lambda d: None, 'SABİT dosyası', sab=(Y.SABIT_REL, '0' * 64))
    bad('sabit-yetki', lambda d: d.update(sabit_sha256='0' * 64), 'yetki.sabit_sha256')
    for k in Y.SCRIPT_KEYS:
        bad('betik-%s' % k[:-3], lambda d, k=k: d['script_sha256'].update({k: '0' * 64}), 'script_sha256[%s]' % k)
    bad('turetilmis', lambda d: d['derived_sha256'].update({'ext_engine_d.py': '0' * 64}), 'derived_sha256')
    bad('pin-listesi', lambda d: d.update(pin_list_sha256='0' * 64), 'pin_list_sha256')
    bad('ornek-sha-yok', lambda d: d.pop('sample_ids_sha256') and None, 'sample_ids_sha256')
    bad('python-surum', lambda d: d.update(python='3.12.0'), 'sürüm')
    bad('numpy-surum', lambda d: d.update(numpy='1.26.4'), 'sürüm')
    bad('b2-bos', lambda d: d.update(b2_sha256sums={}), 'b2_sha256sums')
    bad('b2-hash', lambda d: d.update(b2_sha256sums={'b2\\P93STATIC_sentetik\\SHA256SUMS': '0' * 64}), 'B2')
    bad('b2-disari', lambda d: d.update(b2_sha256sums={'..\\x\\SHA256SUMS': '0' * 64}), 'B2')
    bad('denetim-yol', lambda d: d['code_audit_report'].update(path='protokol\\baska.md'), 'kod denetimi raporu yolu')
    bad('denetim-hash', lambda d: d['code_audit_report'].update(sha256='0' * 64), 'kod denetimi raporu')
    bad('denetim-eksik', lambda d: d.pop('code_audit_report') and None, 'code_audit_report eksik')
    bad('dayanak-D260-yok', lambda d: d.update(dayanak=['D-259']), 'D-260')
    bad('yazan-bos', lambda d: d.update(yazan=' '), 'yazan boş')
    bad('yazan-Y8GK4M', lambda d: d.update(yazan='otopilot Y8GK4M-W2, B4'), 'Y8GK4M')
    os.remove(yp)
    record('K-yetki-dosyasi-yok', 'yetki dosyası yok' in (va() or ''))
    write_yetki(tr, good)
    yc = Y.pin_path(tr, 'kod\\y_common.py')
    orig = _rb(yc)
    _wb(yc, orig + b'\n')
    record('K-pin-diskte-degismis', 'X2 pin' in (va() or ''))
    r_co, out_co = quiet(Y.main, ['--check-only'], root=tr, sabit=sabit, script_path=script)
    record('K-check-only-pin-2', r_co == 2 and 'KAPI: PIN' in out_co, 'çıkış %s' % r_co)
    _wb(yc, orig)

    def m(argv, **kw):
        kw.setdefault('root', tr)
        kw.setdefault('sabit', sabit)
        kw.setdefault('script_path', script)
        return quiet(Y.main, argv, **kw)

    for tag, argv in (('argumansiz', []), ('cift-check-run', ['--check-only', '--run-id', RUN_ID]),
                      ('cift-check-selftest', ['--check-only', '--selftest']),
                      ('cift-selftest-run', ['--selftest', '--out-dir', os.path.join(work, 'x'), '--run-id', RUN_ID]),
                      ('selftest-outdir-yok', ['--selftest']), ('outdir-yalniz', ['--out-dir', os.path.join(work, 'x')]),
                      ('run-id-yalniz', ['--run-id', RUN_ID]), ('yetki-yalniz', ['--yetki', yp]),
                      ('taninmayan', ['--check-only', '--fazla']), ('deger-eksik', ['--run-id'])):
        r, out = m(argv)
        record('K-main-%s' % tag, r == 3 and 'KAPI' in out, 'çıkış %s' % r)
    os.environ['G92_S1'] = 'sentetik'
    try:
        r, out = m(['--check-only'])
        try:
            Y.env_gate()
            eg = False
        except Y.Abort:
            eg = True
    finally:
        del os.environ['G92_S1']
    record('K-ortam-G92_S1', r == 3 and 'ortam değişkeni' in out and eg, 'çıkış %s' % r)
    bad_pins = [p if p[0] != Y.PIN_POINTS else (p[0], 'girdi\\baska\\out\\tsv\\TSV_a\\analysis\\points.csv', p[2], p[3])
                for p in Y.PINS]
    try:
        Y.import_common(ROOT, bad_pins)
        record('K-U-yolu', False, 'farklı yol kabul edildi')
    except Y.Abort as e:
        record('K-U-yolu', 'R2-3' in str(e), str(e))
    with isolated(tr):
        try:
            sha_ok = Y.prerun_gate(tr, Y.PINS, Y.DERIVED, good) == good['sample_ids_sha256']
        except ValueError as e:
            sha_ok = 'HATA %s' % e
        try:
            Y.prerun_gate(tr, Y.PINS, Y.DERIVED, dict(good, sample_ids_sha256='0' * 64))
            sha_bad = False
        except ValueError as e:
            sha_bad = 'sample_ids_sha256' in str(e)
    record('K-prerun-ornek-kimligi', sha_ok is True and sha_bad is True, 'doğru %s, yanlış reddedildi %s' % (sha_ok, sha_bad))
    od = Y.pin_path(tr, 'out\\' + RUN_ID)
    os.makedirs(od)
    with isolated(tr):
        r, out = m(['--run-id', RUN_ID, '--yetki', yp])
    record('K-main-klasor-var', r == 3 and 'zaten var' in out and os.listdir(od) == [], 'çıkış %s' % r)
    with isolated(tr):
        r, out = m(['--run-id', RUN_ID, '--yetki', yp], sabit=(Y.SABIT_REL, None))
    record('K-main-sabit-yok', r == 3 and 'SABİT hash betikte doldurulmadı' in out, 'çıkış %s' % r)
    os.rmdir(od)
    sd = os.path.join(work, 'oz_test_var')
    os.makedirs(sd)
    r, out = m(['--selftest', '--out-dir', sd])
    record('K-main-oztest-klasor-var', r == 3 and 'zaten var' in out, 'çıkış %s' % r)
    with isolated(tr):
        r0, out0 = m(['--check-only'])
        r4, out4 = m(['--check-only'], sabit=(Y.SABIT_REL, None))
    record('K-check-only-0', r0 == 0 and 'CHECK-ONLY: TAMAM' in out0, 'çıkış %s' % r0)
    record('K-check-only-4', r4 == 4 and 'SABİT bekleniyor' in out4, 'çıkış %s' % r4)
    os.makedirs(od)
    with isolated(tr):
        r2, out2 = m(['--check-only'])
    record('K-check-only-klasor-2', r2 == 2 and 'X2' in out2, 'çıkış %s' % r2)


# ============================================================================================ W
def section_W(work):
    d = os.path.join(work, 'w')
    os.makedirs(d)
    Y._write_text(os.path.join(d, 'ham.jsonl'), '{"a": 1}\n')
    Y.write_outputs(d, {'sonuc_s.json': '{}', 'hukum_s.txt': 'H\n'}, ['l1', 'l2'], 2, 'hata\n')
    names = sorted(os.listdir(d))
    sums = _rb(os.path.join(d, 'SHA256SUMS')).decode('utf-8').splitlines()
    want = ['%s  %s' % (_sha(_rb(os.path.join(d, n))), n) for n in names if n != 'SHA256SUMS']
    record('W-muhur', sums == want and len(want) == 6 and _rb(os.path.join(d, 'exit_code.txt')) == b'2\n')
    l1 = Y.verdict_line(dict(verdict='ABORT', decision_row=1, abort_kind='X1', abort_reason='r'))
    l2 = Y.verdict_line(dict(verdict='TUTARLI', decision_row=5, primary=dict(n_neg=18, n_pos=42, k_neg=0, k_pos=0,
                                                                            wilson_lo=0.94)))
    record('W-hukum-satiri', 'satır 1' in l1 and 'TUTARLI' in l2 and 'BEKLENMEYEN' in Y.verdict_line(dict(verdict=None)))


# ============================================================================================ M
def mutations():
    p3, d7 = Y.PINS[2], Y.DERIVED[1]
    return [
        ('M01', 'S1', 'import traceback  # noqa: E402\n', 'import traceback  # noqa: E402\nimport subprocess  # noqa: E402\n'),
        ('M02', 'S1', 'import numpy as np  # noqa: E402\n', 'import numpy as np  # noqa: E402\nfrom os import path  # noqa: E402\n'),
        ('M03', 'S1', '    import make_engine_d as MK\n', '    import make_engine_d as MK\n    import ext_engine as E0\n'),
        ('M04', 'S2', "    res['pins'] = pin_rows\n", "    res['pins'] = pin_rows\n    eval('1')\n"),
        ('M05', 'S3', '    rows_all = list(pins) + list(derived)\n    try:\n        rows, data = verify_pins(root, rows_all)\n',
         '    rows_all = list(pins) + list(derived)\n    _ = open(root)\n    try:\n        rows, data = verify_pins(root, rows_all)\n'),
        ('M06', 'S4', p3[3], p3[3][:-1] + ('0' if p3[3][-1] != '0' else '1')),
        ('M07', 'S4', "%d, '%s'" % (d7[2], d7[3]), "%d, '%s'" % (d7[2], ('0' if d7[3][0] != '0' else '1') + d7[3][1:])),
        ('M08', 'S5', "    res['pins'] = pin_rows\n", "    res['pins'] = pin_rows\n    _ = 'stage2.jsonl'\n"),
        ('M09', 'S5', "    res['pins'] = pin_rows\n", "    res['pins'] = pin_rows\n    _ = 'sonuc.json'\n"),
        ('M10', 'S7', '    if C.E is not E or CD.E is not ED:\n', '    ED.rhs = None\n    if C.E is not E or CD.E is not ED:\n'),
        ('M11', 'S9', '    sysd_d = copy.deepcopy(lay0.sysd)\n', '    sysd_d = lay0.sysd\n'),
        ('M12', 'S9', '        delayed_core(M, lay0, G, P, ctx, o)\n',
         "        lay0.sysd['ctrl_delay'] = dict(Td=TD, rotate=ROTATE)\n        delayed_core(M, lay0, G, P, ctx, o)\n"),
        ('M13', 'S6', "    log('PIN: %d/%d OK' % (len(rows), len(rows_all)))\n",
         "    log('PIN: %d/%d OK' % (len(rows), len(rows_all)))\n    import_models(root, pins, derived)\n"),
        ('M14', 'S6', "    pin_rows, data = verify_pins(root, rows_all)\n    res['pins'] = pin_rows\n"
                      "    M = import_models(root, pins, derived)\n",
         "    M = import_models(root, pins, derived)\n    pin_rows, data = verify_pins(root, rows_all)\n"
         "    res['pins'] = pin_rows\n"),
        ('M15', 'S6', '        ssha = prerun_gate(root, pins, derived, y)\n', '        ssha = None\n'),
        ('M16', 'S8', "    ok = [r for r in drows if r.get('status') == 'ok']\n",
         "    ok = [r for r in drows if r.get('status') == 'ok']\n    _ = np.linalg.solve\n"),
        ('M17', 'S11', 'N_NEG_MIN = 8 ', 'N_NEG_MIN = 7 '),
        ('M18', 'S11', '    if k >= 1:\n        return 4, VERDICTS[4]\n    return 5, VERDICTS[5]\n',
         '    if k == 0:\n        return 5, VERDICTS[5]\n    return 4, VERDICTS[4]\n'),
        ('M19', 'S11', 'THETA_M = 2.0 ', 'THETA_M = 3.0 '),
        ('M20', 'S11', 'X1_DGF_ABS = 1e-10 ', 'X1_DGF_ABS = 1e-9 '),
        ('M21', 'S12', '        r0 = C.stage1(lay0, G, P, rec={}, strict=True)\n',
         '        r0 = CD.stage1(lay0, G, P, rec={}, strict=True)\n'),
        ('M22', 'S12', 'tol=REF_TOL, alpha_tab=tab0)', "tol=REF_TOL, alpha_tab='rel')"),
        ('M23', 'S12', 'CD.stage1_at(layd, G, P, x0, refs, rec={}, strict=True)',
         'CD.stage1_at(layd, G, P, x0, refs, rec={}, strict=False)'),
        ('M24', 'S10', "    try:\n        env_gate()\n    except Abort as e:\n        log('KAPI: %s' % e)\n        return 3\n", ''),
        ('M25', 'S10', '    log = _Log()\n', "    log = _Log()\n    os.environ['G92_OUT'] = ''\n"),
    ]


def section_M(work):
    src = _rb(os.path.join(HERE, 'y8_run.py')).decode('utf-8')
    res, _, basis = SC.check(os.path.join(HERE, 'y8_run.py'), ROOT)
    record('M00-taban', all(p for _, p, _ in res), '%d/%d madde GEÇTİ (%s)' % (sum(p for _, p, _ in res), len(res), basis))
    d = os.path.join(work, 'mutasyon')
    os.makedirs(d)
    for mid, item, old, new in mutations():
        n = src.count(old)
        if n != 1:
            record(mid, False, 'mutasyon çapası %d kez' % n)
            continue
        p = os.path.join(d, 'y8_run_%s.py' % mid)
        _wb(p, src.replace(old, new).encode('utf-8'))
        r, _, _ = SC.check(p, ROOT)
        failed = [name.split()[0] for name, passed, _ in r if not passed]
        record('%s-%s' % (mid, item), item in failed, 'KALDI: %s' % failed)


def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except (AttributeError, ValueError):
        pass
    ap = argparse.ArgumentParser()
    ap.add_argument('--work-dir', required=True)
    a = ap.parse_args(argv)
    work = os.path.abspath(a.work_dir)
    if os.path.exists(work):
        print('KAPI: --work-dir zaten var: %s' % work)
        return 1
    os.makedirs(work)
    t0 = time.perf_counter()
    print('y8_synth_test.py sha256: %s' % _sha(_rb(os.path.abspath(__file__))))
    print('y8_run.py sha256: %s' % _sha(_rb(os.path.join(HERE, 'y8_run.py'))))
    print('synth_y8/karar_durumlari.json sha256: %s' % _sha(_rb(SYNTH)))
    try:
        data, U, E, C, ED, CD = load_all()
        C.lower_priority()
        syn = json.loads(_rb(SYNTH).decode('utf-8'))
        M = (U, E, C, ED, CD)
        section_T0(work, E, ED)
        section_S1(ED)
        section_S2(E, ED)
        section_S4(U, syn)
        section_S5(U)
        section_S6(E, ED)
        section_S7(E, ED)
        section_S8(E, ED)
        section_S10(M)
        section_K(work, U, data)
        section_W(work)
        section_M(work)
    except Exception:  # noqa: BLE001
        record('BEKLENMEYEN', False, traceback.format_exc()[-1500:])
    n_ok = sum(1 for _, ok, _ in RESULTS if ok)
    print('SENTETİK TEST: %s (%d/%d; %.1f s)' % ('GEÇTİ' if n_ok == len(RESULTS) else 'KALDI', n_ok, len(RESULTS),
                                               time.perf_counter() - t0))
    return 0 if n_ok == len(RESULTS) else 1


if __name__ == '__main__':
    sys.exit(main())
