"""Reproduce Figure 3 from the retained 32-state model and sealed benchmark.

Run from an extracted S1 archive as: python -I posthoc/reproduce_figure3.py
"""
from pathlib import Path
import csv, json, sys, math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE=Path(__file__).resolve().parent
SRC=HERE.parent/'research_intelligence'
sys.path.insert(0,str(SRC/'cdl1/code'))
import hdl2b_run as H

sealed=json.loads((SRC/'cdl1/out/HDL2b_20261021_a/sonuc.json').read_text(encoding='utf8'))
m=next(v for v in sealed['members'] if v['id']=='S3_P0.65_G0.20')
mods=H.import_models(str(SRC))
E=mods['e1_core']
model=H.make_model(mods,'S3')
d=H.dispatch_HDL2(E,model,E.Dispatcher(model),.65,.20)
assert d['ok']
sysm=H.RealSystem(mods,model,d['rho'])
x0=d['x0'];G=.20
b=sysm.b;r=[i for i in sysm.keep if i not in b]

def pport(x):
    return H.port_parts(sysm.J(x,G),sysm.M,b,r)

def critical(pp):
    return H.min_cand(H.locus(pp)['cands'])

def branch(pp,candidate):
    w=np.linspace(510,690,301)
    vals=H.track_branches(np.linalg.eigvals(H.y_port_batch(pp,1j*w)))
    nearest=int(np.argmin(abs(w-candidate['omega'])))
    j=int(np.argmin(abs(vals[nearest]-candidate['lam'])))
    return w,vals[:,j]

pp0=pport(x0)
c0=critical(pp0)
dgf=float(m['dGf']);dgt=float(m['ref']['dGt'])
ok,xt,*_=H.path_step(sysm,x0,G,0,dgt)
assert ok
ppt=pport(xt)
ct=critical(ppt)
assert ct is not None and abs(ct['rho']-dgt)<0.002
w0,l0=branch(pp0,c0);wt,lt=branch(ppt,ct)

previous=0.0;x=x0;rows=[];tracked=c0
for g in np.linspace(0,.086,35):
    if g>0:
        ok,x,*_=H.path_step(sysm,x,G,previous,g)
        assert ok,(g,previous)
    lc=H.locus(pport(x))
    tr=H.track(lc['cands'],tracked['omega'],tracked['v'])
    assert tr is not None,g
    rows.append((float(g),float(tr['rho']),float(tr['rho']-g)))
    previous=g;tracked=tr

with (HERE/'figure3_model_curve.csv').open('w',newline='',encoding='utf8') as output:
    writer=csv.writer(output)
    writer.writerow(['dG_pu','tracked_rho_pu','F_pu'])
    writer.writerows(rows)

k=float(m['kappa']['k_tam'])
h=float(m['HAKT']['h'])
kfd=(m['HAKT']['rho_plus']-m['HAKT']['rho_minus'])/(2*h)
curv=(m['HAKT']['rho_plus']-2*dgf+m['HAKT']['rho_minus'])/h**2
dg1=dgf/(1-k)
dg2=2*dgf/(1-kfd+math.sqrt((1-kfd)**2-2*curv*dgf))
g=np.array([v[0] for v in rows]);f=np.array([v[2] for v in rows])

fig,axs=plt.subplots(1,2,figsize=(11,4.1))
ax=axs[0]
ax.plot(l0.real,l0.imag,label='Original equilibrium',lw=2.2)
ax.plot(lt.real,lt.imag,label='At recorded boundary',lw=2.2)
ax.scatter([c0['rho'],ct['rho']],[0,0],s=40,zorder=5)
ax.axhline(0,color='black',lw=.75)
ax.set_xlabel(r'Re $\lambda(j\omega)$ (pu)')
ax.set_ylabel(r'Im $\lambda(j\omega)$ (pu)')
ax.set_title('(a) Model-evaluated admittance loci')
ax.legend(fontsize=8)
ax.grid(alpha=.2)

ax=axs[1]
ax.plot(g,f,color='black',lw=2.4,label='Model-evaluated tracked F')
ax.plot(g,dgf-g,color='gray',ls=':',lw=1.7,label='Frozen')
ax.plot(g,dgf+(k-1)*g,color='darkorange',ls='--',lw=1.6,label='First-order tangent')
ax.plot(g,dgf+(kfd-1)*g+.5*curv*g*g,color='forestgreen',ls='-.',lw=1.6,label='Quadratic estimate')
ax.axhline(0,color='black',lw=.75)
ax.scatter([dgf,dg2,dgt,dg1],[0,0,0,0],s=28,zorder=5,
           c=['gray','forestgreen','black','darkorange'])
ax.set_xlabel(r'Shed conductance $\Delta G$ (pu)')
ax.set_ylabel(r'Crossing function $F$ (pu)')
ax.set_title('(b) Model curve and local approximations')
ax.legend(fontsize=7)
ax.grid(alpha=.2)
fig.tight_layout()
fig.savefig(HERE/'fig3_reproduced.png',dpi=300)
plt.close(fig)
print('figure3',len(rows),'points','F_at_recorded',ct['rho']-dgt,'quadratic',dg2)
