"""C-DL1 / T4 yurutme betigi: kaynak/ag port admitansi Y_src ile kanonik gamma'nin bagimsiz sinamasi.

Dayanak: cdl1/CDL1_T4_On_Kayit_v1.0_SABIT.md (sha256 SABIT_SHA256 asagida); D-093.
Tarih: 2026-10-16 (adim T4-B1). Bu betik T4-B3 kod denetiminden (yazar != denetci)
ve cdl1/T4_yetki_<run_id>.json dosyasindan once gercek kipte calismaz.

Kipler
  --check-only            SABIT hash'i + 22 pin (bayt, sha256) + korlenmemis dosyalarda alan denetimi
                          (T_point, T_state, H-T sonuc.json yapisi). Korlenmis S dosyalari (S_state.csv,
                          S_V5_admittance.csv, S_point.json) yalniz bayt olarak hash'lenir; AYRISTIRILMAZ.
                          Model import edilmez, deger yazdirilmaz, cikti klasoru yazilmaz.
  --run-id ID --yetki P   Tek gercek kosu. Yetki dosyasi (SABIT s7) dogrulanmadan hicbir girdi ayristirilmaz.
                          cdl1/out/<ID>/ zaten varsa kosu reddedilir (yeniden kosu yok).

Cikis kodlari: 0 = hukum uretildi; 2 = ABORT (SABIT s6 satir 1); 3 = kapi reddi (yetki/kip/klasor);
1 = beklenmeyen hata (stderr.txt'ye yazilir).

Onceden sabit uygulama secimleri (SABIT'in acik biraktigi; T4-B3 denetler):
  T4-B1-a  e1k_run.py ve e1_run.py import EDILMEZ (e1_run import aninda surec onceligi/affinitesini degistirir;
           pin 22 'import edilmez'). Model nesnesi e1k_run.build_model'in S3 dalinin (343-348) aynisi:
           KM.E1KModel('S3', dict(kpv=kpv, kiv=kiv)), (kpv, kiv) = KC.pu_gains(S3).
  T4-B1-b  scipy yalniz e1_core'un kendi import'u ile dolayli yuklenir; sympy yalniz model modulu icinde.
           Betik ikisini de dogrudan import etmez ve cagirmaz.
  T4-B1-c  Model modulleri yalniz pin dogrulamasindan sonra import edilir; her modulun __file__ yolu pinli yolla
           ayni olmali. Betik sabitleri (ETA_ALPHA, TH_ZERO, TH_RES, COND_MAX, V5 satir sayisi, KEEP) model
           modulundeki degerlerle karsilastirilir. Uyusmazlik -> ABORT.
  T4-B1-d  G_R,X (X_point.json) ile sonuc.json values.G_R_X tam esit; kL_model = load.base_power/net.Sbase ile
           values.kL bagil 1e-12 icinde olmali. Aksi -> ABORT (s6 satir 1, alan/tutarlilik).
  T4-B1-e  T4-c ciftleri (lo_T, lo_S) ve (hi_T, hi_S); ayni satir ciftleri tekillestirilir (H-T B1-e).
           Pasiflik bantlari (X, satir) ile tekillestirilir; s_X(f) icin o satirin ilk okunan q'su kullanilir.
  T4-B1-f  Satir 2 tetiklense de hesaplanabilen nicelikler raporlanir. Sonlu olmayan Y/mu/nu ya da
           LinAlgError -> o karsilastirma 'HESAPLANAMADI' ve NOT_EVALUABLE gerekcesi.
  T4-B1-g  SINIRDA (s5 son madde): her karsilastirilan q+mu ve q+nu icin |deger| <= 1e-9*max(1, |q|).
  N-1      e_X(f) = 10*cond2(j2*pi*f*I - A_sigma)*u*max(1, ||Y_src||2), u = 2**-53. |mu + eps_p*s|, |q + mu|
           ya da |q + nu| < e_X(f) -> SAYISAL-SINIRDA bayragi (yalniz rapor; hukmu degistirmez).
  N-2      Satir 3 hukum satiri: 'T4-RET-pasiflik [X=<T|S>, f=<Hz>, <tam aktif|belirsiz-isaretli>; ...]'.
  N-3      Basarisiz butun kapilar (K0a-K0d; K0b'de n0 > 0 ve sinif uyusmazligi ayri ayri) gerekceye yazilir.
  T4-B1-h  R3 Weyl denetimi q_yeniden = G_R + kL*lambda_min(H_L) (V5 Y'sinden) ile; tolerans
           1e-12*max(1, |G_R|, kL*||H_L||2, ||H_src||2). Yalniz rapor.
  T4-B1-i  R4: bant [mu, nu] c (0.48525, 0.56360] <=> mu > 0.48525 ve nu <= 0.56360; ayrik <=> nu <= 0.48525
           ya da mu > 0.56360; aksi 'kesisiyor'.
  T4-B1-j  R5: J = model.J (tam, z = h(x)); s = j*2*pi*f; Y_sig_tam = J_bs (s M_s - J_ss)^-1 J_sb;
           Y_x = J_bl (s M_l - J_ll)^-1 J_ls (s M_s - J_ss)^-1 J_sb. Raporlanan: -Y_sig_tam ve -Y_x Hermitci
           ozdegerleri, ||Herm(Y_x)||2 / max(|q|, kL*c*), ||-Y_sig_tam - Y_src||2, ayrica ayni formulun
           dondurulmus J~ ile degeri (isaret ozdesligi denetimi: -Y_sig_dond = Y_src) ve max|J_sl|.
  T4-B1-k  BLAS is parcacigi sayisi 1 (OPENBLAS/OMP/MKL), numpy'dan once.
  T4-B1-l  stdout UTF-8'e ayarlanir (durum adlarinda Yunan harfleri var).
  T4-B1-m  check-only'de T_state icin 33 benzersiz ad ve sonlu deger denetlenir; STATE_NAMES ile ad eslemesi
           yalniz gercek kipte (check-only model import etmez).
"""
import os
for _v in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[_v] = '1'

import argparse  # noqa: E402
import csv  # noqa: E402
import hashlib  # noqa: E402
import io  # noqa: E402
import json  # noqa: E402
import math  # noqa: E402
import re  # noqa: E402
import sys  # noqa: E402
import traceback  # noqa: E402

import numpy as np  # noqa: E402

# ------------------------------------------------------------------ SABIT sabitleri (deger gorulmeden)
ETA_ALPHA = 1e-2            # SABIT s5 K0a/K0b/K0c (e1_core.py:21)
TH_ZERO = 1e-8              # SABIT s5 K0b (e1_core.py:20)
TH_RES = 1e-8               # SABIT s4.1 denge dogrulamasi (e1_core.py:19)
COND_MAX = 1e12             # SABIT s5 K0d (e1_core.py:25)
EPS_P = 1e-9                # SABIT s4.4
SONDA_RTOL = 1e-9           # SABIT s4.6
SINIRDA_K = 1e-9            # SABIT s5 son madde
WEYL_TOL = 1e-12            # SABIT s7 (viii)
U_ROUND = 2.0 ** -53        # N-1
N1_FACTOR = 10.0            # N-1
R4_LO, R4_HI = 0.48525, 0.56360   # SABIT s5 R4 (sonuc goruldukten sonra tanimlandi)
SIGMA_SIZE = 18             # SABIT s4.2
N_STATES = 33
V5_ROWS = 200               # e1_core.py:36
KL_RTOL = 1e-12             # T4-B1-d

SABIT_REL = 'cdl1/CDL1_T4_On_Kayit_v1.0_SABIT.md'
SABIT_SHA256 = 'e6457498a262063a546ec00162ebef575aabfea8ab375144233c0625725f3d6d'

_PTS = 'e1_k/out/SETTINGS_20261012_a/settings/S3/points/'
# SABIT s3: pin 1-15 = H-T SABIT s3 tablosu (ht_run.PINS ile ayni), pin 16-22 = T4 SABIT s3.
PINS = [
    (1, 'e1_k/out/SETTINGS_20261012_a/settings/S3_kayit.json', 9678,
     '552424241767dfa42573b4dfe1c9629d2dcfedadd810132ac93a3d87dfcdb0c8'),
    (2, _PTS + 'T_point.json', 8793, 'f65b5e8d29e83ec04b30f1d4b7cb3096a79faff34ce16a02f6189b99badc7558'),
    (3, _PTS + 'S_point.json', 8442, 'd893c0922757b5a905fa189ded3a9a7a53c60369e0c16a3cacd00778eb3d5c86'),
    (4, _PTS + 'T_state.csv', 3468, '2d28f35a835207613bf62c22c4f3bc5f074c5e18ec39b03ec7f16393c92d4db4'),
    (5, _PTS + 'S_state.csv', 3573, 'af5e52ed01a29158c1991bb659a0d9e70742d151df0f9b67a61acb58c02553e7'),
    (6, _PTS + 'T_V5_admittance.csv', 48265, 'b13b952f2c12f85718135f3dd481fe2b4189ed1e18cf47180e757815204f0c48'),
    (7, _PTS + 'S_V5_admittance.csv', 48501, 'd6fe815903f268202cee29ca796f4ba0abeac0e96d5154112705316266cc7ca2'),
    (8, _PTS + 'T_eigs.csv', 6882, '05b7d05f2e7eee678396ad7ce457088c1b38470731fcb3af26d27eb738b79ec7'),
    (9, _PTS + 'S_eigs.csv', 6912, 'eee3939ef99bb3630c9dcc4d862b6ee97f3500d8421147938e9cd8879b2c5253'),
    (10, 'e1_k/code/e1k_model.py', 9383, 'd4e6392ca50337134e8602f9f129109a3aa156fa86591b29f9875bf30c5e7d78'),
    (11, 'e1_m-e1-0/code/e1_core.py', 37783, 'f1b9191cb05a2b4e08ffaba1ac4a44e3e9b50a21040055e96fe7b3f72fb34819'),
    (12, 'r_ha_b/code/rhab_model.py', 16913, 'db9dd3fdf510a21606a25060e423421dec977ce29dfd4fcadffb38eb9e1c9825'),
    (13, 'cdl1/CDL1_E1_analitik_not_v0.2.md', 14214,
     '17d3344162b25c825a3ccede84e080040c3c1852ea1f74ba71b1f14392ff926b'),
    (14, 'e1_k/sabit/PF1_E1K_On_Kayit_v1.0_SABIT.md', 23857,
     'cb924a2f415021e2d354eaead2a0e854d2072f700b2123d01d9aff1e6dfdeb96'),
    (15, 'e1_k/cb/E1KCB_rapor.md', 4558, 'df125ef0f3eb0321eab5d402546573cb2f1b9d097a81d7a0cb8671ace9a3cad2'),
    (16, 'cdl1/CDL1_HT_On_Kayit_v1.0_SABIT.md', 29436,
     '3adc9f2b024897d386b3f074ba14f6fee5f44f07d43a7502fc4f3dd6b3543b91'),
    (17, 'cdl1/out/HT_20261015_a/sonuc.json', 4450,
     '018819e6227b2d1a5bd528b86f7c81614753fae3efb2522756c54b345e9c4047'),
    (18, 'e1_m-e1-0/code/e1_model.py', 12073, '0ba6571559b557090e693aa007a57d69cbaf409122ea7602fbe7e1edefe9a15b'),
    (19, 'e1_k/code/e1k_core.py', 16085, '6053896404aed7d52f8f75ee6a514cb243b330ef3a4392a3c2ca9475c5e21b3f'),
    (20, 'e1_k/code/e1k_run.py', 50372, '3aa707f190d433864eb7c30be96580f15c4a65b3e4e055b48992af5535387c4a'),
    (21, 'PF1_K1_analitik_mekanizma_notu_v0.2.md', 13470,
     'f272c408c5b1120cd7b744da31988487c8a1d0a477591cff3001b505fc17374c'),
    (22, 'e1_m-e1-0/code/e1_run.py', 42245, '3d087257646472e741d199998c691fba0fa56afa454d05714acc73924925b593'),
]
ROLE = {2: 'T_point', 3: 'S_point', 4: 'T_state', 5: 'S_state', 17: 'sonuc'}
# import edilen model modulleri -> pin numarasi (T4-B1-c); 20 (e1k_run) import edilmez, yalniz yeniden hash'lenir
MODULE_PINS = {'e1k_model': 10, 'e1_core': 11, 'rhab_model': 12, 'e1_model': 18, 'e1k_core': 19}
REHASH_PINS = (10, 11, 12, 18, 19, 20)
RHO_FIELDS = ('P_ref', 'Q_ref', 'V_ref', 'V_ref_dc', 'Iq_ref')
LOADREF_ROWS = ('V_2:R', 'V_2:I', 'load1021:ir_filter', 'load1021:ii_filter')
RUN_ID_RE = re.compile(r'^T4_\d{8}_[a-z]$')
POINTS = ('T', 'S')
KINDS = ('f0', 'lo', 'hi')
LBL_FULL, LBL_MIXED = 'tam aktif', 'belirsiz-işaretli'
GEC, KAL, BEL, HSZ = 'GEC', 'KAL', 'BELIRSIZ', 'HESAPLANAMADI'

PARSED_PATHS = []           # sentetik test: hangi dosyalarin ayristirildigi


class Abort(Exception):
    """SABIT s6 satir 1."""


# ------------------------------------------------------------------ dosya erisimi (tek nokta)
def _read_bytes(path):
    with open(path, 'rb') as fh:
        return fh.read()


def _write_text(path, text):
    with open(path, 'w', encoding='utf-8', newline='\n') as fh:
        fh.write(text)


def sha256_hex(data):
    return hashlib.sha256(data).hexdigest()


def pin_list_sha256(pins):
    """Yetki dosyasindaki 'pin listesi hash'i': 'no<TAB>yol<TAB>bayt<TAB>sha' satirlari, UTF-8, LF."""
    text = ''.join('%d\t%s\t%d\t%s\n' % p for p in pins)
    return sha256_hex(text.encode('utf-8'))


def pin_path(root, rel):
    return os.path.join(root, *rel.split('/'))


def verify_pins(root, pins):
    """Tum pinleri bayt + sha256 ile dogrular; tek uyusmazlik ABORT. Icerik ayristirilmaz."""
    blobs, rows = {}, []
    for no, rel, size, sha in pins:
        path = pin_path(root, rel)
        if not os.path.isfile(path):
            raise Abort('pin %d yok: %s' % (no, rel))
        data = _read_bytes(path)
        got = sha256_hex(data)
        rows.append(dict(no=no, path=rel, bytes_expected=size, bytes=len(data), sha256_expected=sha, sha256=got))
        if len(data) != size or got != sha:
            raise Abort('pin %d uyusmuyor: %s (bayt %d/%d)' % (no, rel, len(data), size))
        blobs[no] = data
    return blobs, rows


def rehash_pins(root, pins, numbers):
    """SABIT s3: model modulleri kosu sonunda yeniden hash'lenir; degisim -> ABORT."""
    for no, rel, size, sha in pins:
        if no in numbers:
            data = _read_bytes(pin_path(root, rel))
            if len(data) != size or sha256_hex(data) != sha:
                raise Abort('pin %d kosu sirasinda degisti: %s' % (no, rel))


# ------------------------------------------------------------------ ayristiricilar (ABORT kurallari)
def _num(x, what):
    if isinstance(x, bool) or not isinstance(x, (int, float)):
        raise Abort('%s sayi degil' % what)
    x = float(x)
    if not math.isfinite(x):
        raise Abort('%s sonlu degil' % what)
    return x


def _int(x, what):
    if isinstance(x, bool) or not isinstance(x, int):
        raise Abort('%s tamsayi degil' % what)
    return x


def _get(d, keys, what):
    cur = d
    for k in keys:
        if not isinstance(cur, dict) or k not in cur:
            raise Abort('%s eksik' % what)
        cur = cur[k]
    return cur


def parse_json(data, label):
    PARSED_PATHS.append(label)
    try:
        return json.loads(data.decode('utf-8'))
    except (UnicodeDecodeError, ValueError) as e:
        raise Abort('%s JSON okunamadi: %s' % (label, e))


def parse_state_full(data, label):
    """X_state.csv: 'state', 'x_equilibrium'; 33 benzersiz ad, sonlu deger. Doner: {ad: deger}."""
    PARSED_PATHS.append(label)
    try:
        text = data.decode('utf-8-sig')
    except UnicodeDecodeError as e:
        raise Abort('%s UTF-8 degil: %s' % (label, e))
    rd = csv.DictReader(io.StringIO(text))
    if rd.fieldnames is None or 'state' not in rd.fieldnames or 'x_equilibrium' not in rd.fieldnames:
        raise Abort('%s sutun eksik (state, x_equilibrium)' % label)
    out = {}
    for i, r in enumerate(rd):
        name = r['state']
        if name in out:
            raise Abort('%s: %r cift' % (label, name))
        try:
            v = float(r['x_equilibrium'])
        except (TypeError, ValueError):
            raise Abort('%s satir %d sayi degil' % (label, i))
        if not math.isfinite(v):
            raise Abort('%s satir %d sonlu degil' % (label, i))
        out[name] = v
    if len(out) != N_STATES:
        raise Abort('%s: %d durum (beklenen %d)' % (label, len(out), N_STATES))
    for name in LOADREF_ROWS:
        if name not in out:
            raise Abort('%s: %s eksik' % (label, name))
    return out


def parse_point(obj, label):
    """H-T SABIT s4.1 alanlari: G_R, rho (5 alan)."""
    g_r = _num(_get(obj, ('G_R',), label + '.G_R'), label + '.G_R')
    rho = _get(obj, ('rho',), label + '.rho')
    if not isinstance(rho, dict):
        raise Abort('%s.rho sozluk degil' % label)
    rho = {k: _num(_get(rho, (k,), label + '.rho.' + k), label + '.rho.' + k) for k in RHO_FIELDS}
    return dict(G_R=g_r, rho=rho)


def _reading(obj, keys, what):
    d = _get(obj, keys, what)
    if not isinstance(d, dict):
        raise Abort('%s sozluk degil' % what)
    row = _int(_get(d, ('row',), what + '.row'), what + '.row')
    if not 0 <= row < V5_ROWS:
        raise Abort('%s.row aralik disi' % what)
    return dict(row=row, f_Hz=_num(_get(d, ('f_Hz',), what + '.f_Hz'), what + '.f_Hz'),
                lam=_num(_get(d, ('lam_min_H',), what + '.lam_min_H'), what + '.lam_min_H'))


def parse_sonuc(obj):
    """H-T sonuc.json (pin 17), SABIT s4.5-4.6 alanlari. Doner: kL, G_R{X}, q_f0{X}, read{X}{f0,lo,hi}."""
    v = _get(obj, ('values',), 'sonuc.values')
    if not isinstance(v, dict):
        raise Abort('sonuc.values sozluk degil')
    kL = _num(_get(v, ('kL',), 'values.kL'), 'values.kL')
    if not kL > 0:
        raise Abort('values.kL <= 0')
    out = dict(kL=kL, G_R={}, q_f0={}, read={})
    for X in POINTS:
        out['G_R'][X] = _num(_get(v, ('G_R_' + X,), 'values.G_R_' + X), 'values.G_R_' + X)
        out['q_f0'][X] = _num(_get(v, ('q_%s_f0' % X,), 'values.q_%s_f0' % X), 'values.q_%s_f0' % X)
        rd = dict(f0=_reading(v, ('f0_' + X,), 'values.f0_' + X))
        for k in ('lo', 'hi'):
            rd[k] = _reading(v, ('fc_' + X, 'rows', k), 'values.fc_%s.rows.%s' % (X, k))
        out['read'][X] = rd
    return out


def load_ref(st, rho):
    """H-T SABIT s4.6: c = P_L/|V|^2, c* = sqrt(c^2 + (I_q/(2|V|))^2). Yalniz R5 olcegi icin."""
    Vr, Vi = st['V_2:R'], st['V_2:I']
    Ir, Ii = st['load1021:ir_filter'], st['load1021:ii_filter']
    V2 = Vr * Vr + Vi * Vi
    PL = Vr * Ir + Vi * Ii
    if not V2 > 0:
        return dict(c=None, c_star=None)
    c = PL / V2
    return dict(c=c, c_star=math.sqrt(c * c + (rho['Iq_ref'] / (2.0 * math.sqrt(V2))) ** 2))


# ------------------------------------------------------------------ model (yalniz import; T4-B1-a/c)
def import_models(root):
    """Pin dogrulamasindan SONRA cagrilir. Model modulleri degistirilmez, yamalanmaz."""
    for sub in ('e1_m-e1-0/code', 'e1_k/code'):
        p = pin_path(root, sub)
        if p not in sys.path:
            sys.path.insert(0, p)
    import e1k_model as KM
    import e1k_core as KC
    import e1_core as EC
    import e1_model as EM
    mods = dict(e1k_model=KM, e1k_core=KC, e1_core=EC, e1_model=EM, rhab_model=EM.RB)
    rel = {no: r for no, r, _, _ in PINS}
    for name, no in MODULE_PINS.items():
        got = os.path.normcase(os.path.realpath(mods[name].__file__))
        exp = os.path.normcase(os.path.realpath(pin_path(root, rel[no])))
        if got != exp:
            raise Abort('modul %s pinli yoldan yuklenmedi: %s' % (name, mods[name].__file__))
    TH = EC.TH
    if not (TH['eta_alpha'] == ETA_ALPHA and TH['zero'] == TH_ZERO and TH['res'] == TH_RES
            and TH['cond_branch'] == COND_MAX):
        raise Abort('e1_core.TH esikleri betik sabitleriyle uyusmuyor')
    if len(EC.V5_F_HZ) != V5_ROWS or len(EM.STATE_NAMES) != N_STATES:
        raise Abort('V5 izgarasi ya da durum sayisi beklenen degil')
    if list(EC.KEEP) != [k for k in range(N_STATES) if k != EM.I_THETA]:
        raise Abort('e1_core.KEEP beklenen degil')
    if tuple(EM.REF_NAMES) != RHO_FIELDS:
        raise Abort('REF_NAMES sirasi RHO_FIELDS ile ayni degil')
    return mods


def make_model(mods):
    """e1k_run.build_model(S3) ile ayni nesne (T4-B1-a)."""
    KC, KM = mods['e1k_core'], mods['e1k_model']
    s3 = [s for s in KC.SETTINGS if s.code == 'S3']
    if len(s3) != 1:
        raise Abort('e1k_core.SETTINGS icinde S3 tek degil')
    kpv, kiv = KC.pu_gains(s3[0])
    return KM.E1KModel('S3', dict(kpv=kpv, kiv=kiv))


def state_vector(st, names):
    """SABIT s4.1: 33 ad STATE_NAMES ile birebir; eksik ya da fazla -> ABORT."""
    if set(st) != set(names) or len(names) != N_STATES:
        raise Abort('durum adlari STATE_NAMES ile birebir degil (eksik: %d, fazla: %d)'
                    % (len(set(names) - set(st)), len(set(st) - set(names))))
    return np.array([st[n] for n in names], dtype=float)


def build_operators(mods, model, x, rhov, GR):
    """SABIT s4.1-4.2: dondurulmus cerceve (z = z*) operatorleri ve R5 icin tam J."""
    EM, EC = mods['e1_model'], mods['e1_core']
    names = EM.STATE_NAMES
    IX = {n: k for k, n in enumerate(names)}
    zs = model.h(x, rhov)
    Jt = model.Jx_tilde(x, zs, rhov, GR)
    Mv = np.asarray(model.M, dtype=float)
    A = Jt / Mv[:, None]
    keep = list(EC.KEEP)
    l_idx = [IX[n] for n in EM.LOAD_STATE_NAMES]
    b_idx = [IX['V_2:R'], IX['V_2:I']]
    sig = [k for k in range(len(names)) if k not in l_idx and k not in b_idx and k != EM.I_THETA]
    if len(sig) != SIGMA_SIZE:
        raise Abort('|sigma| = %d (beklenen %d)' % (len(sig), SIGMA_SIZE))
    C = np.zeros((2, len(sig)))
    C[0, sig.index(IX[EM.LINE + ':Il_R'])] = -1.0
    C[1, sig.index(IX[EM.LINE + ':Il_I'])] = -1.0
    Jf = model.J(x, rhov, GR)
    return dict(z_star=float(zs), A_keep=A[np.ix_(keep, keep)], A_sig=A[np.ix_(sig, sig)],
                B_sig=A[np.ix_(sig, b_idx)], C_sig=C, A_L=A[np.ix_(l_idx, l_idx)],
                sig_names=[names[k] for k in sig],
                r5=dict(J=np.asarray(Jf, dtype=float), Jt=Jt, M=Mv, b=b_idx, s=sig, l=l_idx))


# ------------------------------------------------------------------ saf dogrusal cebir (sentetik testle sinanir)
def cond2(Mx):
    """2-norm kosul sayisi; SVD yakinsamaz ya da sonlu degilse inf (K0d'de kapi reddi)."""
    with np.errstate(all='ignore'):
        try:
            c = float(np.linalg.cond(Mx))
        except np.linalg.LinAlgError:
            return float('inf')
    return c if math.isfinite(c) else float('inf')


def y_src(A, B, C, f):
    """Y = C (j 2 pi f I - A)^-1 B ve cond2(j 2 pi f I - A). Tekil/sonlu degil -> (None, cond)."""
    Mx = 1j * 2.0 * math.pi * f * np.eye(A.shape[0]) - A
    cond = cond2(Mx)
    with np.errstate(all='ignore'):
        try:
            Y = C @ np.linalg.solve(Mx, B)
        except np.linalg.LinAlgError:
            return None, cond
    if not np.all(np.isfinite(Y)):
        return None, cond
    return Y, cond


def herm(Y):
    return (Y + Y.conj().T) / 2.0


def band(Y):
    """SABIT s4.3: [mu, nu] = [lambda_min, lambda_max] (Herm Y)."""
    ev = np.linalg.eigvalsh(herm(Y))
    return float(ev[0]), float(ev[-1])


def compare(X, q, mu, nu):
    """SABIT s4.3 karsilastirma tablosu (tek satir, tek nokta)."""
    if not all(math.isfinite(v) for v in (q, mu, nu)):
        return HSZ
    if X == 'T':
        if q + mu > 0:
            return GEC
        if q + nu <= 0:
            return KAL
        return BEL
    if q + nu <= 0:
        return GEC
    if q + mu > 0:
        return KAL
    return BEL


def pair_verdict(vT, vS):
    """SABIT s4.3: cift icinde en az biri KAL -> KAL; ikisi GEC -> GEC; aksi BELIRSIZ."""
    if HSZ in (vT, vS):
        return HSZ
    if KAL in (vT, vS):
        return KAL
    if vT == GEC and vS == GEC:
        return GEC
    return BEL


def combine(verdicts):
    """SABIT s4.3 E5 / s5 T4-c: hepsi GEC -> GEC; hepsi KAL -> KAL; aksi BELIRSIZ."""
    if HSZ in verdicts:
        return HSZ
    if all(v == GEC for v in verdicts):
        return GEC
    if all(v == KAL for v in verdicts):
        return KAL
    return BEL


def passivity(mu, nu, q):
    """SABIT s4.4: s = max(1, |q|, |nu|); aktif <=> mu < -eps_p*s; SINIRDA-pasiflik <=> |mu| <= eps_p*s."""
    s = max(1.0, abs(q), abs(nu))
    thr = EPS_P * s
    active = mu < -thr
    tag = (LBL_FULL if nu < -thr else LBL_MIXED) if active else None
    return dict(s=s, threshold=thr, active=bool(active), sinirda_pasiflik=bool(abs(mu) <= thr), tag=tag,
                margin=mu + thr)


def eigvals_safe(A):
    if not np.all(np.isfinite(A)):
        return None
    return np.linalg.eigvals(A)


def k0b(A_keep, X):
    """SABIT s5 K0b: hicbir ozdeger cikarilmadan max Re; n0 = |lambda| <= 1e-8 sayisi."""
    lam = eigvals_safe(A_keep)
    if lam is None:
        return dict(alpha_tilde=None, n0=None, zero_eigs=[], min_abs_eig=None, class_ok=False, finite=False)
    alpha = float(np.max(lam.real))
    n0 = int(np.sum(np.abs(lam) <= TH_ZERO))
    zero = [[float(z.real), float(z.imag)] for z in lam[np.abs(lam) <= TH_ZERO]]
    class_ok = (alpha <= -ETA_ALPHA) if X == 'T' else (alpha >= ETA_ALPHA)
    return dict(alpha_tilde=alpha, n0=n0, zero_eigs=zero, min_abs_eig=float(np.min(np.abs(lam))),
                class_ok=bool(class_ok), finite=True)


def max_re(A):
    lam = eigvals_safe(A)
    return None if lam is None else float(np.max(lam.real))


def cplx(Y):
    return None if Y is None else [[[float(Y[a, b].real), float(Y[a, b].imag)] for b in range(Y.shape[1])]
                                    for a in range(Y.shape[0])]


def r5_terms(r5, f, q, kL, c_star, Ysrc):
    """R5 (T4-B1-j). Yalniz rapor; hata olursa hata metni doner."""
    try:
        J, Jt, M, b, s, l = r5['J'], r5['Jt'], r5['M'], r5['b'], r5['s'], r5['l']
        lam = 1j * 2.0 * math.pi * f

        def ysig(Jm):
            Qs = lam * np.diag(M[s]) - Jm[np.ix_(s, s)]
            Rs_Jsb = np.linalg.solve(Qs, Jm[np.ix_(s, b)])
            return Jm[np.ix_(b, s)] @ Rs_Jsb, Rs_Jsb
        Ysf, RsJsb = ysig(J)
        Ql = lam * np.diag(M[l]) - J[np.ix_(l, l)]
        Yx = J[np.ix_(b, l)] @ np.linalg.solve(Ql, J[np.ix_(l, s)] @ RsJsb)
        Ysd, _ = ysig(Jt)
        hx = herm(Yx)
        denom = max(abs(q), kL * c_star) if c_star is not None else abs(q)
        return dict(
            minus_Y_sigma_full=cplx(-Ysf), minus_Y_sigma_full_band=list(band(-Ysf)),
            minus_Y_cross=cplx(-Yx), minus_Y_cross_band=list(band(-Yx)),
            norm_herm_Y_cross=float(np.linalg.norm(hx, 2)),
            ratio_herm_Y_cross=(float(np.linalg.norm(hx, 2)) / denom) if denom > 0 else None,
            norm_full_minus_src=(None if Ysrc is None else float(np.linalg.norm(-Ysf - Ysrc, 2))),
            sign_identity_frozen=(None if Ysrc is None else float(np.linalg.norm(-Ysd - Ysrc, 2))),
            max_abs_J_sigma_load=float(np.max(np.abs(J[np.ix_(s, l)]))))
    except Exception as e:      # yalniz rapor; hukme girmez
        return dict(error='%s: %s' % (type(e).__name__, e))


def reading_list(sn):
    """SABIT s4.5-4.6: okuma satirlari ve q degerleri (yeniden hesaplanmaz)."""
    out = []
    for X in POINTS:
        for kind in KINDS:
            r = sn['read'][X][kind]
            q = sn['q_f0'][X] if kind == 'f0' else sn['G_R'][X] + sn['kL'] * r['lam']
            out.append(dict(X=X, kind=kind, row=r['row'], f_Hz=r['f_Hz'], lam_ht=r['lam'], q=q))
    return out


def core(f_grid, sn, ops, v5, c_star=None, full_grid=True):
    """SABIT s4.3-s6. sn: parse_sonuc ciktisi; ops[X]: build_operators ciktisi; v5[X]: e1_core.V5 satirlari.
    Abort firlatabilir (frekans eslesmesi, sonda). Doner: sonuc sozlugu."""
    R = dict(not_evaluable_reasons=[], sinirda=[], sayisal_sinirda=[], gates={}, readings=[], bands={},
             comparisons={}, pairs={}, tests={}, report={})
    ne = R['not_evaluable_reasons']
    kL = sn['kL']
    reads = reading_list(sn)

    # --- s4.5 frekans eslesmesi ve s4.6 sonda (ABORT; NOT_EVALUABLE'dan once)
    sonda = []
    for r in reads:
        X, k = r['X'], r['row']
        if not 0 <= k < len(f_grid) or float(f_grid[k]) != r['f_Hz']:
            raise Abort('frekans eslesmesi: %s %s satir %d' % (X, r['kind'], k))
        if len(v5[X]) != len(f_grid) or float(v5[X][k]['f_Hz']) != r['f_Hz']:
            raise Abort('V5 satiri frekansla eslesmiyor: %s satir %d' % (X, k))
        lam_new = float(v5[X][k]['lam_min_H'])
        d = abs(lam_new - r['lam_ht'])
        tol = SONDA_RTOL * max(1.0, abs(r['lam_ht']))
        sonda.append(dict(X=X, kind=r['kind'], row=k, lam_ht=r['lam_ht'], lam_new=lam_new, abs_diff=d, tol=tol))
        if not (math.isfinite(lam_new) and d <= tol):
            raise Abort('sonda: %s %s satir %d |dlam| = %r > %r' % (X, r['kind'], k, d, tol))
    R['report']['sonda'] = sonda

    # --- s5 K0a-K0c (N-3: hepsi yazilir)
    for X in POINTS:
        o = ops[X]
        g = dict(max_re_A_sigma=max_re(o['A_sig']), K0b=k0b(o['A_keep'], X), max_re_A_L=max_re(o['A_L']))
        g['K0a'] = g['max_re_A_sigma'] is not None and g['max_re_A_sigma'] <= -ETA_ALPHA
        g['K0c'] = g['max_re_A_L'] is not None and g['max_re_A_L'] <= -ETA_ALPHA
        R['gates'][X] = g
        if not g['K0a']:
            ne.append('K0a,%s: max Re lambda(A_sigma) = %r > -eta_alpha' % (X, g['max_re_A_sigma']))
        kb = g['K0b']
        if not kb['finite']:
            ne.append('K0b,%s: sonlu olmayan deger' % X)
        else:
            if kb['n0'] > 0:
                ne.append('K0b,%s: dondurulmus KEEP operatorunde sifir mod (n0 = %d); E1 alpha tanimi uygulanamaz'
                          % (X, kb['n0']))
            if not kb['class_ok']:
                ne.append('K0b,%s: sinif uyusmazligi (alpha~ = %r); dondurulmus cerceve ayrisimi siniflayici '
                          'operatoru temsil etmiyor' % (X, kb['alpha_tilde']))
        if not g['K0c']:
            ne.append('K0c,%s: max Re lambda(A_L) = %r > -eta_alpha' % (X, g['max_re_A_L']))

    # --- okuma satirlari: Y_src, bant, K0d, N-1
    cache = {}
    for r in reads:
        X, k = r['X'], r['row']
        if (X, k) not in cache:
            o = ops[X]
            f = r['f_Hz']
            Y, cond_s = y_src(o['A_sig'], o['B_sig'], o['C_sig'], f)
            cond_L = cond2(1j * 2.0 * math.pi * f * np.eye(o['A_L'].shape[0]) - o['A_L'])
            ent = dict(Y=Y, cond_sigma=cond_s, cond_L=cond_L, mu=float('nan'), nu=float('nan'), normY=None, e=None)
            if Y is not None:
                ent['mu'], ent['nu'] = band(Y)
                ent['normY'] = float(np.linalg.norm(Y, 2))
                ent['e'] = N1_FACTOR * cond_s * U_ROUND * max(1.0, ent['normY'])
            ent['K0d'] = bool(cond_s <= COND_MAX and cond_L <= COND_MAX)
            if not ent['K0d']:
                ne.append('K0d,%s satir %d: cond(jwI - A_sigma) = %r, cond(jwI - A_L) = %r' % (X, k, cond_s, cond_L))
            if Y is None or not (math.isfinite(ent['mu']) and math.isfinite(ent['nu'])):
                ne.append('sonlu olmayan deger: Y_src,%s satir %d' % (X, k))
            cache[(X, k)] = ent
        ent = cache[(X, k)]
        q, mu, nu = r['q'], ent['mu'], ent['nu']
        r.update(mu=mu, nu=nu, cond_sigma=ent['cond_sigma'], cond_L=ent['cond_L'], normY=ent['normY'],
                 e_N1=ent['e'], K0d=ent['K0d'], Y_src=cplx(ent['Y']))
        r['verdict'] = compare(X, q, mu, nu)
        if r['verdict'] != HSZ:
            for nm, val in (('q+mu', q + mu), ('q+nu', q + nu)):
                if abs(val) <= SINIRDA_K * max(1.0, abs(q)):
                    R['sinirda'].append(dict(X=X, kind=r['kind'], row=k, compare=nm, value=val,
                                             threshold=SINIRDA_K * max(1.0, abs(q))))
        R['readings'].append(r)

    # --- s4.4 pasiflik (tekil bantlar)
    pas = []
    for r in R['readings']:
        if any(p['X'] == r['X'] and p['row'] == r['row'] for p in pas):
            continue
        if not (math.isfinite(r['mu']) and math.isfinite(r['nu'])):
            continue
        p = passivity(r['mu'], r['nu'], r['q'])
        p.update(X=r['X'], row=r['row'], f_Hz=r['f_Hz'], kind=r['kind'], mu=r['mu'], nu=r['nu'], q=r['q'])
        pas.append(p)
    R['bands'] = pas

    # --- N-1 SAYISAL-SINIRDA (yalniz rapor)
    for r in R['readings']:
        if r['e_N1'] is None:
            continue
        p = [b for b in pas if b['X'] == r['X'] and b['row'] == r['row']][0]
        for nm, val in (('mu+eps_p*s', r['mu'] + EPS_P * p['s']), ('q+mu', r['q'] + r['mu']), ('q+nu', r['q'] + r['nu'])):
            if abs(val) < r['e_N1']:
                R['sayisal_sinirda'].append(dict(X=r['X'], kind=r['kind'], row=r['row'], compare=nm, value=val,
                                                 e=r['e_N1']))

    # --- s4.3 esleme ve T4-s / T4-c
    by = {(r['X'], r['kind']): r for r in R['readings']}
    R['comparisons'] = {'%s_%s' % key: dict(row=r['row'], f_Hz=r['f_Hz'], q=r['q'], mu=r['mu'], nu=r['nu'],
                                            verdict=r['verdict']) for key, r in by.items()}
    s_pair = pair_verdict(by[('T', 'f0')]['verdict'], by[('S', 'f0')]['verdict'])
    c_pairs, seen = [], []
    for kind in ('lo', 'hi'):
        rT, rS = by[('T', kind)], by[('S', kind)]
        if (rT['row'], rS['row']) in seen:
            continue
        seen.append((rT['row'], rS['row']))
        c_pairs.append(dict(kind=kind, row_T=rT['row'], row_S=rS['row'], T=rT['verdict'], S=rS['verdict'],
                            pair=pair_verdict(rT['verdict'], rS['verdict'])))
    R['pairs'] = dict(T4_s=dict(row_T=by[('T', 'f0')]['row'], row_S=by[('S', 'f0')]['row'], pair=s_pair),
                      T4_c=c_pairs)
    R['tests']['T4-s'] = s_pair
    R['tests']['T4-c'] = combine([c['pair'] for c in c_pairs])
    if HSZ in (R['tests']['T4-s'], R['tests']['T4-c']) and not ne:
        ne.append('hesaplanamayan karsilastirma')

    # --- yalniz rapor
    R['report'].update(reports(f_grid, sn, ops, v5, R, c_star, full_grid))

    # --- s6 karar tablosu (sira sabit; ilk eslesen satir)
    active = [p for p in pas if p['active']]
    t = R['tests']
    if ne:
        row, verdict, ht = 2, 'NOT_EVALUABLE', 'acik'
    elif active:
        row, verdict, ht = 3, 'T4-RET-pasiflik', 'REDDEDILDI (kanonik bicimiyle; gamma >= 0 kaynakla belirlenemiyor)'
    elif t['T4-s'] == KAL:
        row, verdict, ht = 4, 'T4-RET-statik', "REDDEDILDI (kanonik marj L1'e aktarilamaz; H-D yeniden dusunulur)"
    elif t['T4-c'] == KAL:
        row, verdict, ht = 5, 'T4-RET-dinamik', 'REDDEDILDI (kanonik bicimiyle)'
    elif BEL in (t['T4-s'], t['T4-c']):
        row, verdict, ht = 6, 'BELIRSIZ', 'acik'
    elif t['T4-s'] == GEC and t['T4-c'] == GEC:
        row, verdict, ht = 7, 'T4-TUTARLI', 'kapanir (model ici, dondurulmus cerceve, E2)'
    else:
        raise RuntimeError('karar tablosu eslesmedi: %r' % t)
    R['decision_row'], R['verdict'], R['HT_status'] = row, verdict, ht
    R['verdict_detail'] = ('; '.join('X=%s, f=%r, %s' % (p['X'], p['f_Hz'], p['tag']) for p in active)
                           if row == 3 else None)
    return R


def reports(f_grid, sn, ops, v5, R, c_star, full_grid):
    """R1-R6 (hukme girmez)."""
    out = {}
    kL = sn['kL']
    by = {(r['X'], r['kind']): r for r in R['readings']}
    # R1
    r1 = {}
    for X in POINTS:
        o = ops[X]
        mus, nus = [], []
        rows = range(len(f_grid)) if full_grid else sorted({r['row'] for r in R['readings'] if r['X'] == X})
        for k in rows:
            Y, _ = y_src(o['A_sig'], o['B_sig'], o['C_sig'], float(f_grid[k]))
            if Y is not None:
                m, n = band(Y)
                mus.append((m, float(f_grid[k])))
                nus.append((n, float(f_grid[k])))
        f0 = by[(X, 'f0')]
        rel = {}
        for kind in ('lo', 'hi'):
            rc = by[(X, kind)]
            rel[kind] = dict(mu=(rc['mu'] - f0['mu']) / max(abs(f0['mu']), 1e-12),
                             nu=(rc['nu'] - f0['nu']) / max(abs(f0['nu']), 1e-12))
        r1[X] = dict(n_rows=len(mus), mu_min=min(mus) if mus else None, mu_max=max(mus) if mus else None,
                     nu_min=min(nus) if nus else None, nu_max=max(nus) if nus else None, rel_change_fc_vs_f0=rel)
    r1['abs_diff_f0'] = dict(mu=abs(by[('T', 'f0')]['mu'] - by[('S', 'f0')]['mu']),
                             nu=abs(by[('T', 'f0')]['nu'] - by[('S', 'f0')]['nu']))
    out['R1'] = r1
    # R2, R3, R5, N-1 (okuma satiri basina)
    per = []
    for r in R['readings']:
        X, k = r['X'], r['row']
        ent = dict(X=X, kind=r['kind'], row=k, f_Hz=r['f_Hz'], cond_sigma=r['cond_sigma'], normY=r['normY'],
                   e_N1=r['e_N1'])
        if r['Y_src'] is not None:
            Y = np.array([[complex(*c) for c in row] for row in r['Y_src']])
            H = herm(Y)
            tr2 = float(np.trace(H).real) / 2.0
            ent['R2'] = dict(tr_half=tr2, q_plus_tr_half=r['q'] + tr2,
                             isotropy_ratio=(r['nu'] - r['mu']) / max(abs(tr2), 1e-12))
            YL = np.array(v5[X][k]['Y'], dtype=complex)
            HL = herm(YL)
            G = sn['G_R'][X]
            Htot = G * np.eye(2) + kL * HL + H
            lt = float(np.linalg.eigvalsh(Htot)[0])
            q_re = G + kL * float(np.linalg.eigvalsh(HL)[0])
            sc = max(1.0, abs(G), kL * float(np.linalg.norm(HL, 2)), float(np.linalg.norm(H, 2)))
            tol = WEYL_TOL * sc
            ent['R3'] = dict(lam_min_H_tot=lt, q_recomputed=q_re, weyl_lower=q_re + r['mu'], weyl_upper=q_re + r['nu'],
                             weyl_ok=bool(q_re + r['mu'] - tol <= lt <= q_re + r['nu'] + tol),
                             highlight=r['verdict'] == BEL)
            if ops[X].get('r5') is not None:
                ent['R5'] = r5_terms(ops[X]['r5'], r['f_Hz'], r['q'], kL, c_star[X] if c_star else None, Y)
        per.append(ent)
    out['per_reading'] = per
    # R4
    out['R4'] = dict(label='Deger, H-T sonucu goruldukten sonra tanimlandi (D-092 D1-iii); ikincil',
                     interval=[R4_LO, R4_HI], bands=[dict(
                         X=p['X'], row=p['row'], kind=p['kind'], mu=p['mu'], nu=p['nu'],
                         relation=('icinde' if (p['mu'] > R4_LO and p['nu'] <= R4_HI) else
                                   ('ayrik' if (p['nu'] <= R4_LO or p['mu'] > R4_HI) else 'kesisiyor')))
                         for p in R['bands']])
    # R6
    out['R6'] = dict(gates=R['gates'], passivity=[dict(X=p['X'], row=p['row'], sinirda_pasiflik=p['sinirda_pasiflik'],
                                                       active=p['active'], tag=p['tag'], s=p['s'],
                                                       margin=p['margin']) for p in R['bands']])
    return out


# ------------------------------------------------------------------ cekirdek degerlendirme (gercek kip)
def evaluate(root, pins):
    """Pin dogrulama + s4 tanimlari + s5 + s6. Abort firlatabilir (s6 satir 1). Doner: (pin_rows, sonuc)."""
    blobs, pin_rows = verify_pins(root, pins)
    by_role = {ROLE[no]: blobs[no] for no in blobs if no in ROLE}
    sn = parse_sonuc(parse_json(by_role['sonuc'], 'sonuc'))
    P = {X: parse_point(parse_json(by_role[X + '_point'], X + '_point'), X + '_point') for X in POINTS}
    ST = {X: parse_state_full(by_role[X + '_state'], X + '_state') for X in POINTS}
    for X in POINTS:
        if P[X]['G_R'] != sn['G_R'][X]:
            raise Abort('G_R,%s: %s_point ile sonuc.json uyusmuyor' % (X, X))
    mods = import_models(root)
    EC, EM = mods['e1_core'], mods['e1_model']
    model = make_model(mods)
    kL_model = float(model.load['base_power']) / float(model.net['Sbase'])
    if not abs(kL_model - sn['kL']) <= KL_RTOL * max(1.0, abs(sn['kL'])):
        raise Abort('kL: model ile sonuc.json uyusmuyor')
    ops, v5, cst, vals = {}, {}, {}, dict(kL_model=kL_model)
    for X in POINTS:
        x = state_vector(ST[X], EM.STATE_NAMES)
        rhov = [P[X]['rho'][k] for k in EM.REF_NAMES]
        GR = P[X]['G_R']
        res = float(np.max(np.abs(model.f(x, rhov, GR))))
        vals['residual_' + X] = res
        if not res <= TH_RES:
            raise Abort('denge dogrulamasi: max|f(x_%s)| = %r > %r' % (X, res, TH_RES))
        ops[X] = build_operators(mods, model, x, rhov, GR)
        v5[X] = EC.V5(model, x, rhov, GR)['rows']
        cst[X] = load_ref(ST[X], P[X]['rho'])['c_star']
        vals['z_star_' + X] = ops[X]['z_star']
    vals['sigma_states'] = ops['T']['sig_names']
    vals['c_star'] = cst
    R = core(EC.V5_F_HZ, sn, ops, v5, c_star=cst, full_grid=True)
    rehash_pins(root, pins, REHASH_PINS)
    R['values'] = vals
    return pin_rows, R


# ------------------------------------------------------------------ kapi (SABIT s7)
def verify_authorization(root, yetki_path, run_id, pins, script_path):
    """Yetki dosyasini dogrular; uyusmazlikta ValueError. Hicbir S girdisi okunmaz."""
    if not RUN_ID_RE.match(run_id):
        raise ValueError('run_id bicimi gecersiz')
    expect = os.path.normcase(os.path.abspath(os.path.join(root, 'cdl1', 'T4_yetki_%s.json' % run_id)))
    if os.path.normcase(os.path.abspath(yetki_path)) != expect:
        raise ValueError('yetki dosyasi yolu cdl1/T4_yetki_<run_id>.json degil')
    if not os.path.isfile(yetki_path):
        raise ValueError('yetki dosyasi yok')
    try:
        y = json.loads(_read_bytes(yetki_path).decode('utf-8'))
    except (UnicodeDecodeError, ValueError):
        raise ValueError('yetki dosyasi JSON degil')
    if not isinstance(y, dict):
        raise ValueError('yetki dosyasi sozluk degil')
    if y.get('action') != 'ALLOW_T4_RUN':
        raise ValueError('action != ALLOW_T4_RUN')
    if y.get('run_id') != run_id:
        raise ValueError('run_id uyusmuyor')
    sabit = pin_path(root, SABIT_REL)
    if not os.path.isfile(sabit) or sha256_hex(_read_bytes(sabit)) != SABIT_SHA256:
        raise ValueError('SABIT dosyasi hash uyusmuyor')
    if y.get('sabit_sha256') != SABIT_SHA256:
        raise ValueError('yetki.sabit_sha256 uyusmuyor')
    scripts = y.get('script_sha256')
    if not isinstance(scripts, dict) or scripts.get('t4_run.py') != sha256_hex(_read_bytes(script_path)):
        raise ValueError('yetki.script_sha256[t4_run.py] uyusmuyor')
    if y.get('pin_list_sha256') != pin_list_sha256(pins):
        raise ValueError('yetki.pin_list_sha256 uyusmuyor')
    rep = y.get('code_audit_report')
    if not isinstance(rep, dict) or not isinstance(rep.get('path'), str) or not isinstance(rep.get('sha256'), str):
        raise ValueError('yetki.code_audit_report eksik')
    rp = pin_path(root, rep['path'])
    if not os.path.isfile(rp) or sha256_hex(_read_bytes(rp)) != rep['sha256']:
        raise ValueError('kod denetimi raporu hash uyusmuyor')
    return y


# ------------------------------------------------------------------ kipler
def check_only(root, pins, log):
    """Pin + korlenmemis dosyalarda alan denetimi. Korlenmis S dosyalari ayristirilmaz; model import edilmez."""
    sabit = pin_path(root, SABIT_REL)
    ok_sabit = os.path.isfile(sabit) and sha256_hex(_read_bytes(sabit)) == SABIT_SHA256
    log('SABIT hash: %s' % ('OK' if ok_sabit else 'UYUSMUYOR'))
    if not ok_sabit:
        return 2
    try:
        blobs, rows = verify_pins(root, pins)
    except Abort as e:
        log('PIN: ABORT - %s' % e)
        return 2
    log('PIN: %d/%d OK' % (len(rows), len(pins)))
    log('pin_list_sha256: %s' % pin_list_sha256(pins))
    by_role = {ROLE[no]: blobs[no] for no in blobs if no in ROLE}
    try:
        parse_sonuc(parse_json(by_role['sonuc'], 'sonuc'))
        parse_point(parse_json(by_role['T_point'], 'T_point'), 'T_point')
        parse_state_full(by_role['T_state'], 'T_state')
    except Abort as e:
        log('ALAN (korlenmemis): ABORT - %s' % e)
        return 2
    log('ALAN (korlenmemis: sonuc.json yapisi, T_point, T_state): OK')
    log('korlenmis S dosyalari (S_point, S_state, S_V5): yalniz hash; ayristirilmadi; model import edilmedi')
    return 0


def _jsonable(v):
    if isinstance(v, dict):
        return {str(k): _jsonable(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [_jsonable(x) for x in v]
    if isinstance(v, (np.floating, np.integer)):
        return v.item()
    if isinstance(v, np.bool_):
        return bool(v)
    if isinstance(v, np.ndarray):
        return _jsonable(v.tolist())
    if isinstance(v, complex):
        return [v.real, v.imag]
    return v


def write_outputs(out_dir, pin_rows, result, verdict_line, log_lines, exit_code, stderr_text):
    _write_text(os.path.join(out_dir, 'girdi_pinleri.json'), json.dumps(pin_rows, indent=1, ensure_ascii=False))
    _write_text(os.path.join(out_dir, 'sonuc.json'), json.dumps(_jsonable(result), indent=1, ensure_ascii=False))
    _write_text(os.path.join(out_dir, 'hukum.txt'), verdict_line + '\n')
    _write_text(os.path.join(out_dir, 'stdout.txt'), '\n'.join(log_lines) + '\n')
    _write_text(os.path.join(out_dir, 'stderr.txt'), stderr_text)
    _write_text(os.path.join(out_dir, 'exit_code.txt'), '%d\n' % exit_code)
    names = sorted(n for n in os.listdir(out_dir) if n != 'SHA256SUMS')
    _write_text(os.path.join(out_dir, 'SHA256SUMS'),
                ''.join('%s  %s\n' % (sha256_hex(_read_bytes(os.path.join(out_dir, n))), n) for n in names))


def verdict_line(result):
    """N-2 bicimi."""
    v = result['verdict']
    if result.get('decision_row') == 3:
        v = '%s [%s]' % (v, result['verdict_detail'])
    return 'T4 hukmu: %s (karar tablosu satir %d; H-T statusu: %s)' % (v, result['decision_row'], result['HT_status'])


def default_root():
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def main(argv=None, root=None, pins=None, script_path=None):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except (AttributeError, ValueError):
        pass
    root = root or default_root()
    pins = pins or PINS
    script_path = script_path or os.path.abspath(__file__)
    ap = argparse.ArgumentParser(description='C-DL1 T4 tek kosu betigi')
    ap.add_argument('--check-only', action='store_true')
    ap.add_argument('--run-id')
    ap.add_argument('--yetki')
    a = ap.parse_args(argv)
    lines = []

    def log(s):
        lines.append(s)
        print(s)

    if a.check_only:
        if a.run_id or a.yetki:
            log('KAPI: --check-only ile --run-id/--yetki birlikte verilemez')
            return 3
        return check_only(root, pins, log)
    if not (a.run_id and a.yetki):
        log('KAPI: gercek kip --run-id ve --yetki ister; calismadi')
        return 3
    try:
        verify_authorization(root, a.yetki, a.run_id, pins, script_path)
    except ValueError as e:
        log('KAPI: yetki reddedildi - %s' % e)
        return 3
    out_dir = os.path.join(root, 'cdl1', 'out', a.run_id)
    if os.path.exists(out_dir):
        log('KAPI: %s zaten var; yeniden kosu yok' % out_dir)
        return 3
    os.makedirs(out_dir)
    log('run_id: %s' % a.run_id)
    log('yetki: OK')
    pin_rows, result, err = [], {}, ''
    try:
        pin_rows, result = evaluate(root, pins)
        code = 0
        line = verdict_line(result)
    except Abort as e:
        code, line = 2, 'T4 hukmu: ABORT (karar tablosu satir 1; H-T statusu: degismez) - %s' % e
        result = dict(verdict='ABORT', decision_row=1, abort_reason=str(e))
    except Exception:
        code, line = 1, 'BEKLENMEYEN HATA (hukum yok)'
        err = traceback.format_exc()
        result = dict(verdict=None, error='beklenmeyen hata; stderr.txt')
        sys.stderr.write(err)
    log(json.dumps(_jsonable(result), indent=1, ensure_ascii=False))
    log(line)
    write_outputs(out_dir, pin_rows, result, line, lines, code, err)
    return code


if __name__ == '__main__':
    sys.exit(main())
