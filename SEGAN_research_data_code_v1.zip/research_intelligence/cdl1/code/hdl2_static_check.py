"""hdl2_run.py icin AST statik denetimi (H-DL2 SABIT s7 'Statik denetim'; T4 kalibi).

Denetimler:
  S1  import izin listesi: ust duzeyde 10 standart modul + numpy; model modulleri (e1k_model, e1k_core, e1_core,
      e1_model) yalniz import_models() icinde; 'from' import yok; yasakli adlar (scipy, sympy, subprocess,
      importlib, e1k_run, e1_run, ...) yok.
  S2  yasakli cagrilar yok: eval, exec, compile, __import__, setattr, delattr, os.system, os.popen, os.exec*,
      os.spawn*, os.fork*.
  S3  open() yalniz _read_bytes ve _write_text icinde; pathlib/read_text yok.
  S4  PINS literal tablosu: 1-6 SABIT s3 tablosu ile birebir (yol, bayt, sha); 7-9 SABIT s0 tam hash'leriyle;
      10 = N3-D(v0.2) raporu (D-135 sha); diskteki dosyalar bu degerlerle eslesir; SABIT_SHA256 dogru.
  S5  korlenmis/onceki sonuc dosya adlari kodda yok (S_/T_ nokta, durum, V5, ozdeger dosyalari; 'points/';
      onceki kosu klasorleri); 'sonuc.json' yalniz write_outputs() icinde (cikti adi).
  S6  pinli modullere/model nesnesine yazma (yama) yok; sembolik/ozel nitelik yok; model, EC, EM, KC, KM
      uzerinde yalniz izinli nitelikler.
  S7  V_STAR hicbir bicimde (ad, nitelik, dizge) gecmez: rho'ya giremez (SABIT s4.2 adim 4).
  S8  dispatch_HDL2: rho = [p_e, q_e, v_refr, li['Vref_dc'], Iq_ref] (tek atama, harfiyen); cagri sirasi
      power_flow -> load_init -> _assemble -> refine('new') -> newton_theta_fixed; yakalanan istisna kumesi
      (DispatchError, LinAlgError, ValueError, ZeroDivisionError) (U-4).
  S9  korleme/yetki sirasi: evaluate() yalniz main() icinde ve verify_authorization() cagrisindan sonra;
      import_models/make_model/run_family yalniz evaluate() icinde (ic ice fonksiyonlar dahil); check_only()
      bunlari cagirmaz.
  S10 scipy tarzi cozucu adlari yok (odeint, solve_ivp, fsolve, brentq, minimize, root_scalar, least_squares,
      linprog, milp).
Kullanim: python -I hdl2_static_check.py [--root <research_intelligence>] [--script <hdl2_run.py>]
Cikis: 0 = GECTI, 1 = KALDI.
"""
import argparse
import ast
import hashlib
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
TOP_IMPORTS = {'os', 'argparse', 'csv', 'hashlib', 'io', 'json', 'math', 're', 'sys', 'traceback', 'numpy'}
MODEL_IMPORTS = {'e1k_model', 'e1k_core', 'e1_core', 'e1_model'}
FORBIDDEN_NAMES = {'scipy', 'sympy', 'sp', 'subprocess', 'importlib', 'ctypes', 'multiprocessing', 'socket',
                   'urllib', 'http', 'shutil', 'pathlib', 'pickle', 'marshal', 'e1k_run', 'e1_run', 'ER'}
FORBIDDEN_CALLS = {'eval', 'exec', 'compile', '__import__', 'execfile', 'setattr', 'delattr'}
FORBIDDEN_ATTR_CALLS = {('os', 'system'), ('os', 'popen'), ('os', 'startfile')}
FORBIDDEN_ATTR_PREFIX = ('exec', 'spawn', 'fork')
OPEN_ALLOWED_IN = {'_read_bytes', '_write_text'}
BLINDED_FRAGMENTS = ('S_state', 'S_V5', 'S_point', 'T_point', 'T_state', 'T_V5', 'S_eigs', 'T_eigs', 'points/',
                     'SETTINGS_2026', 'HT_2026', 'T4_2026')
ALLOWED_ATTRS = {
    'model': {'f', 'J', 'Jx_tilde', 'h', 'M', 'load', 'net', 'theta_row_zero'},
    'EC': {'TH', 'KEEP', 'CANDIDATES', 'VIOL', 'BORDER', 'power_flow', 'load_init', 'Dispatcher', 'DispatchError',
           'newton_theta_fixed', 'eig_part', 'identify_ref', 'alpha_from', 'limits'},
    'EM': {'STATE_NAMES', 'I_THETA', 'LOAD_STATE_NAMES', 'L', 'WB', 'REF_NAMES', 'RB'},
    'KC': {'SETTINGS', 'pu_gains'},
    'KM': {'E1KModel'},
}
SYMBOLIC_ATTRS = {'jacobian', 'diff', 'lambdify', 'subs', 'J_new_sym', 'Jx_tilde_sym', 'Jz_tilde_sym', 'f_new_sym',
                  'J_fix_sym', 'f_fix_sym', '_Jn', '_Jxt', '_Jzt', '_fn', '_ft', '_ff', '_Jf', '_aux',
                  'J_complex_step', 'J_fixed', 'f_fixed', 'f_tilde', 'Jz_tilde', 'build_ftilde_k', 'build_ftilde',
                  'dispatch_E1', 'dispatch_RHA', 'continuation'}
PATCH_ROOTS = {'KM', 'KC', 'EC', 'EM', 'RB', 'model', 'mods', 'disp'}
SOLVER_NAMES = {'odeint', 'solve_ivp', 'fsolve', 'brentq', 'brenth', 'minimize', 'root_scalar', 'least_squares',
                'linprog', 'milp'}
RHO_EXPR = "np.array([gi['p_e'], gi['q_e'], gi['v_refr'], li['Vref_dc'], li['Iq_ref']], dtype=float)"
DISPATCH_ORDER = ('power_flow', 'load_init', '_assemble', 'refine', 'newton_theta_fixed')
CAUGHT = {'DispatchError', 'LinAlgError', 'ValueError', 'ZeroDivisionError'}
SABIT = ('cdl1/CDL2_HDL2_On_Kayit_v1.0_SABIT.md', 'c1215e60a2100165729bafb99b0ef2b81f089e04981b686177cc8a2f48ef0e36')
DOC_PINS = {7: 'cdl1/CDL2_HDL2_On_Kayit_TASLAK_v0.1.md', 8: 'cdl1/CDL2_HDL2_On_Kayit_v0.1_bagimsiz_denetim.md',
            9: 'cdl1/CDL2_E1_notu_v0.1.md'}
PIN10 = ('cdl1/CDL2_HDL2_On_Kayit_v0.2_bagimsiz_denetim.md',
         '25549bd5e13f1b417ff6882deb58905eea7166eb737819fecd2e2f63cf16fa42')


def sha(path):
    with open(path, 'rb') as fh:
        return hashlib.sha256(fh.read()).hexdigest()


def sabit_s3(md_text):
    """SABIT s3: '| n | `yol` | bayt | `sha` | kullanim |' satirlari."""
    out = []
    for line in md_text.splitlines():
        m = re.match(r'^\|\s*(\d+)\s*\|\s*`([^`]+)`\s*\|\s*(\d+)\s*\|\s*`([0-9a-f]{64})`\s*\|', line)
        if m:
            out.append((int(m.group(1)), m.group(2), int(m.group(3)), m.group(4)))
    return out


def sabit_s0(md_text):
    """SABIT s0: '| `yol` | `sha` | ...' satirlarinda tam (64 hane) hash'ler."""
    out = {}
    for line in md_text.splitlines():
        m = re.match(r'^\|\s*`([^`]+)`\s*\|\s*`([0-9a-f]{64})`\s*\|', line)
        if m:
            out[m.group(1)] = m.group(2)
    return out


def literal_pins(tree):
    for n in tree.body:
        if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name) \
                and n.targets[0].id == 'PINS':
            try:
                return [tuple(t) for t in ast.literal_eval(n.value)]
            except ValueError:
                return None
    return None


def parents_map(tree):
    """Dugum id -> icinde bulundugu fonksiyon adlari zinciri (ic -> dis)."""
    out = {}

    def visit(node, chain):
        for ch in ast.iter_child_nodes(node):
            out[id(ch)] = chain
            nxt = ((ch.name,) + chain) if isinstance(ch, (ast.FunctionDef, ast.AsyncFunctionDef)) else chain
            visit(ch, nxt)
    visit(tree, ())
    return out


def call_name(n):
    f = n.func
    return f.id if isinstance(f, ast.Name) else (f.attr if isinstance(f, ast.Attribute) else None)


def root_name(node):
    while isinstance(node, (ast.Attribute, ast.Subscript)):
        node = node.value
    return node.id if isinstance(node, ast.Name) else None


def func_def(tree, name):
    hits = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name]
    return hits[0] if len(hits) == 1 else None


def base_key(node):
    """'model.f' / 'self.model.f' -> 'model'; 'EC.x' -> 'EC'."""
    v = node.value
    if isinstance(v, ast.Name):
        return v.id
    if isinstance(v, ast.Attribute) and v.attr == 'model':
        return 'model'
    return None


def check(script_path, root):
    src_bytes = open(script_path, 'rb').read()
    tree = ast.parse(src_bytes.decode('utf-8'))
    chain = parents_map(tree)
    res = []
    doc = tree.body[0].value if (tree.body and isinstance(tree.body[0], ast.Expr)) else None

    # S1
    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Import):
            for a in n.names:
                top = a.name.split('.')[0]
                fn = chain.get(id(n), ())
                if top in MODEL_IMPORTS:
                    if fn[:1] != ('import_models',):
                        bad.append('%s import_models disinda (satir %d)' % (a.name, n.lineno))
                elif top not in TOP_IMPORTS:
                    bad.append(a.name)
        elif isinstance(n, ast.ImportFrom):
            bad.append('from %s' % n.module)
        elif isinstance(n, ast.Name) and n.id in FORBIDDEN_NAMES:
            bad.append(n.id)
        elif isinstance(n, ast.Attribute) and n.attr in FORBIDDEN_NAMES:
            bad.append('.' + n.attr)
    res.append(('S1 import/yasakli ad', not bad, bad))

    # S2
    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Call):
            f = n.func
            if isinstance(f, ast.Name) and f.id in FORBIDDEN_CALLS:
                bad.append(f.id)
            if isinstance(f, ast.Attribute) and isinstance(f.value, ast.Name):
                if (f.value.id, f.attr) in FORBIDDEN_ATTR_CALLS or (
                        f.value.id == 'os' and f.attr.startswith(FORBIDDEN_ATTR_PREFIX)):
                    bad.append('%s.%s' % (f.value.id, f.attr))
    res.append(('S2 yasakli cagri', not bad, bad))

    # S3
    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Call):
            name = call_name(n)
            if name in ('open', 'read_text', 'read_bytes', 'write_text', 'write_bytes', 'urlopen'):
                if not (name == 'open' and chain.get(id(n), ())[:1] and chain[id(n)][0] in OPEN_ALLOWED_IN):
                    bad.append('%s @ satir %d' % (name, n.lineno))
    res.append(('S3 dosya acma tek nokta', not bad, bad))

    # S4
    detail = []
    sp = os.path.join(root, *SABIT[0].split('/'))
    if sha(sp) != SABIT[1]:
        detail.append('SABIT sha uyusmuyor')
    md = open(sp, encoding='utf-8').read()
    s3 = sabit_s3(md)
    s0 = sabit_s0(md)
    lp = literal_pins(tree) or []
    if [t[0] for t in lp] != list(range(1, 11)):
        detail.append('PINS numaralari 1..10 degil')
    if [t for t in lp if t[0] <= 6] != s3 or len(s3) != 6:
        detail.append('PINS 1-6 != SABIT s3 tablosu')
    for no, rel in DOC_PINS.items():
        row = [t for t in lp if t[0] == no]
        if not row or row[0][1] != rel or s0.get(rel) != row[0][3]:
            detail.append('PIN %d != SABIT s0' % no)
    row10 = [t for t in lp if t[0] == 10]
    if not row10 or (row10[0][1], row10[0][3]) != PIN10:
        detail.append('PIN 10 != D-135 kaydi')
    for no, rel, size, h in lp:
        p = os.path.join(root, *rel.split('/'))
        if not os.path.isfile(p) or os.path.getsize(p) != size or sha(p) != h:
            detail.append('pin %d diskte uyusmuyor' % no)
    sab = [n for n in tree.body if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name)
           and n.targets[0].id == 'SABIT_SHA256']
    if len(sab) != 1 or ast.literal_eval(sab[0].value) != SABIT[1]:
        detail.append('SABIT_SHA256 literal')
    res.append(('S4 PINS == SABIT s3/s0 (+pin 10) ve diskteki dosyalar', not detail, detail))

    # S5
    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Constant) and isinstance(n.value, str) and n is not doc:
            for b in BLINDED_FRAGMENTS:
                if b in n.value:
                    bad.append('%r @ satir %d' % (b, n.lineno))
            if 'sonuc.json' in n.value and chain.get(id(n), ())[:1] != ('write_outputs',):
                bad.append("'sonuc.json' write_outputs disinda @ satir %d" % n.lineno)
    res.append(('S5 korlenmis/onceki sonuc dosyalari yok', not bad, bad))

    # S6
    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Attribute):
            if n.attr in SYMBOLIC_ATTRS:
                bad.append('.%s @ satir %d' % (n.attr, n.lineno))
            key = base_key(n)
            if key in ALLOWED_ATTRS and n.attr not in ALLOWED_ATTRS[key]:
                bad.append('%s.%s @ satir %d' % (key, n.attr, n.lineno))
        targets = []
        if isinstance(n, ast.Assign):
            targets = n.targets
        elif isinstance(n, (ast.AugAssign, ast.AnnAssign)):
            targets = [n.target]
        elif isinstance(n, ast.Delete):
            targets = n.targets
        for t in targets:
            for tt in (t.elts if isinstance(t, ast.Tuple) else [t]):
                if isinstance(tt, (ast.Attribute, ast.Subscript)):
                    rn = root_name(tt)
                    via_model = isinstance(tt, ast.Attribute) and isinstance(tt.value, ast.Attribute) \
                        and tt.value.attr in ('model', 'EC')
                    if rn in PATCH_ROOTS or via_model:
                        bad.append('yama: %s @ satir %d' % (ast.unparse(tt), n.lineno))
    res.append(('S6 yama/sembolik yok; izinli nitelikler', not bad, bad))

    # S7
    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Name) and n.id == 'V_STAR':
            bad.append('ad @ satir %d' % n.lineno)
        if isinstance(n, ast.Attribute) and n.attr == 'V_STAR':
            bad.append('nitelik @ satir %d' % n.lineno)
        if isinstance(n, ast.Constant) and isinstance(n.value, str) and 'V_STAR' in n.value and n is not doc:
            bad.append('dizge @ satir %d' % n.lineno)
    res.append(('S7 V_STAR yok (rho_4 = Vref_dc)', not bad, bad))

    # S8
    detail = []
    fd = func_def(tree, 'dispatch_HDL2')
    if fd is None:
        detail.append('dispatch_HDL2 yok')
    else:
        rho_as = [n for n in ast.walk(fd) if isinstance(n, ast.Assign) and len(n.targets) == 1
                  and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'rho']
        if len(rho_as) != 1 or ast.unparse(rho_as[0].value) != RHO_EXPR:
            detail.append('rho atamasi harfiyen degil')
        calls = [(call_name(n), n) for n in ast.walk(fd) if isinstance(n, ast.Call)]
        order = []
        for name, n in sorted(calls, key=lambda t: (t[1].lineno, t[1].col_offset)):
            if name in DISPATCH_ORDER and name not in order:
                order.append(name)
            if name == 'refine':
                args = [a.value for a in n.args if isinstance(a, ast.Constant)]
                if args != ['new']:
                    detail.append("refine 'new' ile cagrilmiyor")
        if tuple(order) != DISPATCH_ORDER:
            detail.append('cagri sirasi %r' % (order,))
        hand = [h for h in ast.walk(fd) if isinstance(h, ast.ExceptHandler)]
        names = set()
        for h in hand:
            if isinstance(h.type, ast.Tuple):
                for e in h.type.elts:
                    names.add(e.attr if isinstance(e, ast.Attribute) else getattr(e, 'id', None))
        if names != CAUGHT:
            detail.append('istisna kumesi %r' % sorted(map(str, names)))
    res.append(('S8 dispatch_HDL2 adimlari, rho ve istisna kumesi', not detail, detail))

    # S9
    detail = []
    calls_eval = [n for n in ast.walk(tree) if isinstance(n, ast.Call) and call_name(n) == 'evaluate']
    if len(calls_eval) != 1 or chain.get(id(calls_eval[0]), ())[:1] != ('main',):
        detail.append('evaluate() cagrisi tek ve main() icinde degil')
    else:
        auth = [n for n in ast.walk(func_def(tree, 'main')) if isinstance(n, ast.Call)
                and call_name(n) == 'verify_authorization']
        if len(auth) != 1 or not auth[0].lineno < calls_eval[0].lineno:
            detail.append('verify_authorization() evaluate()dan once degil')
    fc = func_def(tree, 'check_only')
    if fc is None:
        detail.append('check_only() yok')
    else:
        for n in ast.walk(fc):
            if isinstance(n, ast.Call) and call_name(n) in ('evaluate', 'import_models', 'make_model', 'run_family'):
                detail.append('check_only icinde %s' % call_name(n))
    for name in ('import_models', 'make_model', 'run_family'):
        sites = [chain.get(id(n), ()) for n in ast.walk(tree) if isinstance(n, ast.Call) and call_name(n) == name]
        if not sites or any('evaluate' not in s for s in sites):
            detail.append('%s evaluate() disinda cagriliyor ya da hic cagrilmiyor' % name)
    res.append(('S9 yetki -> evaluate sirasi', not detail, detail))

    # S10
    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Call) and call_name(n) in SOLVER_NAMES:
            bad.append('%s @ satir %d' % (call_name(n), n.lineno))
        if isinstance(n, ast.Attribute) and n.attr in SOLVER_NAMES:
            bad.append('.%s @ satir %d' % (n.attr, n.lineno))
    res.append(('S10 scipy tarzi cozucu yok', not bad, bad))

    return res, hashlib.sha256(src_bytes).hexdigest()


def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except (AttributeError, ValueError):
        pass
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default=os.path.dirname(os.path.dirname(HERE)))
    ap.add_argument('--script', default=os.path.join(HERE, 'hdl2_run.py'))
    a = ap.parse_args(argv)
    res, h = check(a.script, a.root)
    print('hdl2_run.py sha256: %s' % h)
    ok = True
    for name, passed, detail in res:
        print('%-55s %s%s' % (name, 'GECTI' if passed else 'KALDI', '' if passed else '  ' + '; '.join(map(str, detail))))
        ok &= passed
    print('STATIK DENETIM: %s' % ('GECTI' if ok else 'KALDI'))
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
