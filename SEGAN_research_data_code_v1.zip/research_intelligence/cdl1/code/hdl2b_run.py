"""C-DL2 / H-DL2b yurutme betigi: direncli yuk atmasinda dondurulmus lokus payi DG*_f'nin hata isaretinin
birinci mertebe kestirimi (kappa-hat) ve yeniden dengelenmis referans DG*_t ile sinamasi -- yeni nokta ailesi F_b.

Dayanak: cdl1/CDL2_HDL2b_On_Kayit_v1.0_SABIT.md (sha256 SABIT_SHA256 asagida; D-169). HDL2b SABIT, H-DL2 SABIT
v1.0'in (pin 7) farkini on-kaydeder. Bu betikteki "SABIT sx" atiflari v2 metninden kalmistir ve H-DL2 SABIT v1.0'a
aittir; HDL2b SABIT'in kapali degisiklik listesi (Delta-1...Delta-9) disinda aynen gecerlidir. "HDL2b sx" atiflari
HDL2b SABIT'e aittir.
Turetme: cdl1/code/hdl2_run.py v2 (W6R2HM; sha256 9b9085b2...0e98; B3 v2 ACCEPT D-143). v2'nin degismemis kopyasi
pin 13 (archive/hdl2_run_v2_20261021.py); HDL2b-B3 v2 -> HDL2b farkini buna karsi satir satir denetler.
Tarih: 2026-10-21 (adim HDL2b-B1). Bu betik HDL2b-B3 kod denetiminden (yazar != denetci;
B2 kosucusu != denetci) ve cdl1/HDL2b_yetki_<run_id>.json dosyasindan once gercek kipte calismaz.

v2 -> HDL2b degisiklikleri (HDL2b s7 kapali fark listesi (1)-(9); baska hesap degisikligi yok)
  (1) Aile sabitleri (HDL2b s4.2b, Delta-1): SETTING_CODES = ('S3',); P_AKT_GRID 6 deger (artan; kimlik
      dizgesiyle); G_R_K 15 tamsayi (G_R = k/100, azalan); N_FAMILY = 90; sira (P_akt artan, G_R azalan).
      family_specs artik e1_core.CANDIDATES kullanmaz (CANDIDATES yalniz import_models'daki model sabiti
      denetiminde kalir).
  (2) Korleme tamponu (HDL2b s2, Delta-2): |k - 25| <= 1 olan G_R family_specs'te Abort ile reddedilir (izgarada
      yok; v2 EXCLUDED tablosunun yerine).
  (3) HDL2b s4.3b n_P sarti ve s6 satir 2 (Delta-3, Delta-4): n_P = E'deki farkli P_akt sayisi; satir 2 = n_E < 5
      ya da n_P < 2; Sonuc metni "ucuncu aile yok -> dal-kapanisi degerlendirmesi + kullanici karari". Asama 2-3
      yalniz n_E >= 5, n_P >= 2 ve butun H-AKT GEC ise kosar (HDL2-B1-o'nun uzantisi; satir 2 eslesirse
      referans hesaplanmaz).
  (4) S1/S3 ABORT tetikleyicisi HDL2b s5.6b'ye baglandi (yalniz yorum satirlari; HDL2-B1-m (v2) davranisi aynen).
  (5) run_id deseni 'HDL2b_<8 hane>_<kucuk harf>', yetki eylemi ALLOW_HDL2B_RUN, yetki dosyasi
      cdl1/HDL2b_yetki_<run_id>.json, yetki.script_sha256 anahtari 'hdl2b_run.py'.
  (6) SABIT_REL/SABIT_SHA256 (HDL2b s3.1) ve PINS (HDL2b s3.2) 13 satir, numara-numara; v2 pin 7, 8, 10 duser.
  (7) uyeler.csv'ye onceki_aile_uyesi sutunu; sonuc.json'a n_P ve tests.e_taban (HDL2b s5 (e) yalniz-rapor alt
      satiri: sabit-(+)/(-) taban uyusma sayilari; N_-^tam, N_-^L, N_+^tam, N_+^L boyutlari ve uyusma
      sayilari). Yalniz sayim; yeni model hesabi yok.
  (8) Bu baslik ve degisiklik listesi.
  (9) Komut satiri 'python -I -B cdl1/code/hdl2b_run.py --run-id ... --yetki <mutlak yol>'; konsol yakalamasi
      operatorce ayri cdl1/out/<run_id>_konsol/ klasorune (betik o klasoru yazmaz; cikti klasoru betige aittir).

HDL2b uygulama secimleri (HDL2b SABIT'in acik biraktigi; HDL2b-B3 denetler)
  HDL2b-B1-q  Uye kimligi '<setting>_P<P dizgesi>_G<G_R %.2f>'. P dizgesi literal tablodan gelir; '0.625' ve
              '0.675' yuvarlanmaz (%.2f iki farkli uyeyi ayni kimlige dusururdu). Onceki-aile uyesinin kimligi
              v2'deki gibi 'S3_P0.65_G0.20' kalir; onceki_aile_uyesi = (setting, P dizgesi, k) == ('S3', '0.65', 20).
  HDL2b-B1-r  G_R tamsayi k'dan k / 100.0 ile uretilir (ornek: 20 / 100.0 == 0.20 ayni ikili deger).
  HDL2b-B1-s  e_taban: sabit_E, sabit_tam, sabit_L = E ve |kappa| >= tau_kappa alt kumelerinde (n, ref_sign = +1
              sayisi = sabit-(+) uyusmasi, ref_sign = -1 sayisi = sabit-(-) uyusmasi); ref_sign (a) sayimindakiyle
              ayni (beraberlik 0 = her iki tabanla uyusmaz; sansur kurali ayni). N kumelerinde agree = ref_sign ==
              sgn(kappa) sayisi; ids = uye kimlikleri. Ayirt edilemezlik cumlesi betikte yazilmaz: HDL2b s1.4
              kurali B5'te mekanik uygulanir; betik yalniz sayar.
  HDL2b-B1-t  HDL2-B1-d (v2 pin aciklamasi) yerine HDL2b s3.2 gecerlidir: pin 12 = kabul veren denetim raporu
              (SABIT statu satiri, N4-S), pin 13 = v2 arsiv kopyasi (yalniz hash; import edilmez, okunmaz).
  HDL2b-B1-u  HDL2-B1-a'daki "ayar basina bir model" aynen; F_b tek ayarli oldugundan tek model ve tek Dispatcher
              90 uyede kullanilir.

Kipler
  --check-only            SABIT hash'i + 13 pin (bayt, sha256). Model import edilmez, hesap yapilmaz,
                          cikti klasoru yazilmaz.
  --run-id ID --yetki P   Tek gercek kosu (HDL2b s7). Yetki dosyasi dogrulanmadan model import edilmez.
                          cdl1/out/<ID>/ zaten varsa kosu reddedilir (yeniden kosu yok).
Betik hicbir korlenmis ya da onceki sonuc dosyasini (S/T nokta, durum, V5 dosyalari; H-T/T4 sonuc kayitlari;
onceki H-DL2 kosusunun cikti klasoru) okumaz; butun isletme noktalari s4.2 sevk kuraliyla yeniden uretilir.

Cikis kodlari: 0 = hukum uretildi; 2 = ABORT (s6 satir 1); 3 = kapi reddi (yetki/kip/klasor);
1 = beklenmeyen hata (stderr.txt'ye yazilir; T4 kod denetimi N-2 emsali: tek kosuyu tuketir).

v2'den aynen devralinan uygulama secimleri (H-DL2 SABIT'in acik biraktigi; HDL2-B3 v1/v2 denetledi)
  HDL2-B1-a  e1k_run.py ve e1_run.py import EDILMEZ (T4-B1-a emsali). Model nesnesi e1k_run.build_model
             (pin 5:343-348) ile ayni yol: KM.E1KModel(code, dict(kpv=kpv, kiv=kiv)), (kpv, kiv) = KC.pu_gains.
             Ayar basina bir model ve bir EC.Dispatcher nesnesi kurulur ve o ayarin 15 (S3: 12) uyesinde kullanilir.
  HDL2-B1-b  scipy yalniz e1_core'un kendi import'u ile dolayli; sympy yalniz model modulu icinde. Betik
             ikisini dogrudan import etmez. Brent kok bulucu (s4.5) betik icinde yazilidir (brent_root).
  HDL2-B1-c  Model modulleri yalniz pin dogrulamasindan sonra import edilir; __file__ yollari pinli yollarla ayni
             olmali. Betik sabitleri model sabitleriyle karsilastirilir (TH['res'], TH['cond_branch'],
             TH['halvings'], CANDIDATES, KEEP, REF_NAMES, sinir durum dizgeleri). Uyusmazlik -> ABORT.
  HDL2-B1-d  Pinler: 1-6 SABIT s3 tablosu (bayt + sha256); 7-9 SABIT s0'da tam sha256'si yazili uc belge
             (v0.1 taslak, N3-D raporu, E1 notu); 10 = U-notlarinin kaynagi N3-D(v0.2) raporu (sha256 D-135
             kaydindan). s0'daki kisaltilmis hash'li belgeler (N2-D, v0.3, N1-D(v0.3)) pinlenmez: SABIT tam hash
             vermiyor. Bayt sayilari 7-10 icin bu koşuda olculdu ve DURUM kayitlariyla eslesti.
  HDL2-B1-e  Port bolumlemesi: b = {V_2:R, V_2:I}; r = KEEP minus b; yuk alt kumesi l = LOAD_STATE_NAMES (12);
             sigma = r minus l (18: kaynak + hat + bara 101). Alt admitanslar dondurulmus J~ = Jx_tilde(x, h(x))
             ile kurulur. J~ icinde l-sigma capraz bloklari yapisal olarak sifirdir; olculen max|J~_l,sigma|,
             max|J~_sigma,l| rapor edilir, sifir degilse kalan Y_x'e gider (tanim geregi).
  HDL2-B1-f  Sol ozvektor: W = R^-1 (R sag ozvektor matrisi). <X> := W[i] X R[:, i] (W[i] R[:, i] = 1), bu
             w*Xv/(w*v) ile ayni (E1 notu s1.1). pi_d = W[i,0]R[0,i], pi_q = W[i,1]R[1,i],
             pi_x = <N> = W[i,0]R[1,i] + W[i,1]R[0,i]. Ayni fonksiyonlar (eig_lr, pis, kappa_parts) kappa, S2 ve
             S5'te kullanilir (SABIT s5.3 "ayni kod yolu").
  HDL2-B1-g  Gosterim E1 notu s1.1: J_E = [[0,-1],[1,0]], Sigma = diag(1,-1), N = [[0,1],[1,0]],
             R(phi) = cos(phi) I + sin(phi) J_E; F0 donusumu Y^F0 = R(-theta_b) Y R(-theta_b)^T, theta_b x0'da sabit.
  HDL2-B1-h  Lokus dal izleme: izgarada ardisik noktada iki ozdegerin en yakin eslesmesi (ozdes ya da yer
             degistirme, toplam mesafe en kucuk). Kesisim: bir dalda Im lambda isaret degistiren izgara araligi
             (ya da tam 0 noktasi); Brent g(w) = Im lambda_dal(w), dal araligin uclarindaki ozdegerlerin w'de
             dogrusal ara degerine en yakin ozdegerdir. Inceltmeden sonra rho_j = Re lambda > 0 olan kesisimler
             aday sayilir ("Re lambda > 0 olan araliklar" = inceltilmis kesisimde Re > 0). Bu tanim P7 ve
             H-AKT izlemesinde de ayni: yalniz rho_j > 0 kesisimleri "kesisim" sayilir.
  HDL2-B1-i  alpha: EC.eig_part + EC.identify_ref + EC.alpha_from (tam 33x33 A = J/M, SABIT s4.3 K2). Referans
             kimligi basarisizsa alpha "tanimsiz": K2'de KAL, K7'de "K7-cozunurluk" (sifir sinifi gibi),
             referans taramasinda "kararli degil" (kayip) sayilir ve etiketlenir.
  HDL2-B1-j  K7: herhangi bir noktada "sifir" ya da "tanimsiz" sinifi -> "K7-cozunurluk" (oncelikli); aksi
             halde (i) ya da (ii) saglanmazsa "K7-uyumsuz". DG*_f,ss yalniz (i) saglandiginda hesaplanir.
             U-6: K7'nin iki noktasinda |alpha|/alpha_tab orani raporlanir.
  HDL2-B1-k  Referans: kivrim Newton kaynakliysa DG*_t := son yakinsayan izgara DG (bir onceki nokta);
             yakinsayan noktada cond(J_KEEP) > 1e12 ise DG*_t := o nokta (yakinsadi). alpha kaynakli kayipta
             ikiye bolme sonucu DG*_t := (lo + hi)/2; bolme icinde Newton basarisiz olursa orta nokta
             "kararli degil" sayilir (etiket 'bolme-Newton'). Port tabanli ilk kayip DG*_t,port: ayni izgarada
             F_port = min_j rho_j(x(DG)) - DG <= 0 olan ilk nokta, onceki noktayla dogrusal ara degerle.
             P3 := (DG*_t,port bulundu ve |DG*_t,port - DG*_t| > tau_tie) ya da (bulundu ve sansurlu) ya da
             (bulunmadi, DG*_t belirli ve son izgara noktasi - DG*_t > tau_tie). P2': A_rr = J_rr/M_r'nin
             Re > 0 ozdeger sayisi x0'dakinden farkli. Izleme (Y2) bir onceki izgara noktasinin kesisimine gore
             s5.1 N-d kuraliyla yapilir.
  HDL2-B1-l  Rakip 5: x(DG*_f) referansla ayni adim kuraliyla (0.01*DG*_f adim, 2^h alt adim) ayri bir
             devamlilikla bulunur; adim ve Newton iterasyon sayilari raporlanir. Kesisim yoksa F5 = +inf.
  HDL2-B1-m (v2)  S1 "ilk uye": s4.2 sirasinda K1-K3'u gecen ilk uye (SABIT s5.6 harfiyen). S3 "ilk uye":
             s4.2 sirasinda K1-K3'u gecen VE S3'un degerlendirildigi (K4-K6 da gecen, kappa hesaplanan) ilk uye.
             SABIT s5.6, K1-K3'u gecen ilk uyede S3'un degerlendirilemedigi (K4-K6 KAL ya da kappa hatasi)
             durumu tanimlamaz; bu bosluk icin secim budur ve SABIT'in tanimli oldugu her durumda harfiyen
             okumayla ayni sonucu verir (B3 denetimi B-1 onerisi). K1-K3'u gecmeyen bir uyedeki S3 basarisizligi
             hicbir zaman ABORT vermez ('S3-NE'). S2 ve S4 x0'i olan her uyede. (v1 secimi: S3'un
             degerlendirildigi ilk uye, K2 aranmadan -- HDL2-B3 B-1 ile reddedildi.)
  HDL2-B1-n  Gecitler hesaplanabildigi olcude hepsi hesaplanir (s4.3); NE nedeni ilk basarisiz gecittir. kappa
             K1, K3, K4, K5, K6 gecen her uyede hesaplanir (E disi uyelerde yalniz rapor). H-AKT yalniz E'de.
             Gecit hesaplarinda LinAlgError/ValueError/ZeroDivisionError -> o gecit HESAPLANAMADI (uye NE).
  HDL2-B1-o  Asama 2 secimi (s5.4) yalniz n_E >= n_min ve butun H-AKT GEC ise yapilir; secim.json yazilir ve
             sha256'si stdout'a basilir; asama 3 (referans + rakip 5) ancak ondan sonra baslar.
  HDL2-B1-p  BLAS is parcacigi 1; stdout UTF-8. Kontrol akisinda rastgelelik yok (SABIT s4.2 (c)).
  U-1  Y_L^dond sistem-pu Schur katkisidir (bara 102 satirindaki -kL*i_filter dahil, J~_bl icinde). kappa_Delta
       formulu harfiyen kL*dY_L^dond ile uygulanir; kL kosu basinda hesaplanip raporlanir. kL != 1 ise S3 ilk
       uyede ABORT verir (dogru tespit; sentetik testte gosterilir).
  U-2  Bara 102 sont kapasitesinin tamami Y_src^dond'a girer: s*M_b ve -J~_bb'nin G_R*I disindaki kismi
       (z*b2 terimi; z = h(x), turevi dz'yi icerir). -J~_bb'nin geri kalani G_R*I'dir.
  U-3  S1 toleransi SABIT s5.6 harfiyen (e_S1 = max(1e-8, 10u(cond L + cond Q))); sentetik testte cond(Y_tot)
       ~ 1e10 durumu sahte ABORT vermeden gecmelidir. Gecmezse tolerans degistirilmez -> KULLANICI_BEKLIYOR.
  U-4  dispatch_HDL2, dispatch_E1'in yakaladigi istisna kumesini (DispatchError, LinAlgError, ValueError,
       ZeroDivisionError) yakalar ve uyeyi K1 NE-x0 yapar. Beklenmeyen istisna tek kosuyu tuketir.
  U-5  Her uyede L1-L5 degerleri, durumlari ve marjlari (sinira uzaklik, pozitif = icinde) uyeler.csv'ye yazilir.
  U-6  K7'nin iki noktasinda |alpha|/alpha_tab raporlanir (kapi degil).
  U-7  S2'de Y_iso = Z_line^-1 + Y_to; b_from girmez; net sozlugundeki r, x, b_to kullanilir.
"""
import os
for _v in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[_v] = '1'

import argparse  # noqa: E402
import csv  # noqa: E402
import hashlib  # noqa: E402
import io  # noqa: E402
import json  # noqa: E402
import math  # noqa: E402
import re  # noqa: E402
import sys  # noqa: E402
import traceback  # noqa: E402

import numpy as np  # noqa: E402

# ------------------------------------------------------------------ SABIT sabitleri (deger gorulmeden)
TAU_K = 0.05                 # s5 tau_kappa
DELTA_DEC = 0.05             # s5 delta_dec
SMALL_DG = 0.2               # s5 kucuk-DG bolgesi DG*_f <= 0.2 G_R
N_MIN = 5                    # s5 n_min
SETTING_CODES = ('S3',)                               # HDL2b s4.2b (Delta-1)
P_AKT_GRID = ((0.55, '0.55'), (0.60, '0.60'), (0.625, '0.625'), (0.65, '0.65'), (0.675, '0.675'),
              (0.70, '0.70'))                         # HDL2b s4.2b; (deger, kimlik dizgesi), artan
G_R_K = (34, 33, 32, 31, 30, 29, 28, 27, 23, 22, 21, 20, 19, 18, 17)   # HDL2b s4.2b; G_R = k/100, azalan
BUFFER_K = (25, 1)                                    # HDL2b s2 (Delta-2): |k - 25| <= 1 aileye giremez
PRIOR_FAMILY_MEMBER = ('S3', '0.65', 20)              # HDL2b s4.2b onceki-aile uyesi
CANDIDATES_EXPECTED = (0.25, 0.20, 0.15, 0.10, 0.05)  # e1_core.CANDIDATES (yalniz model sabiti denetimi)
N_FAMILY = 90
N_P_MIN = 2                                           # HDL2b s4.3b (Delta-3)
TH_RES = 1e-8                # s4.3 K1 (e1_core TH['res'])
COND_MAX = 1e12              # s4.3 K3, s4.5, s4.6 (e1_core TH['cond_branch'])
HALVINGS = 5                 # s4.6 (e1_core TH['halvings'])
ALPHA_TAB_K = 1e-10          # s4.6
TAU7 = 1e-3                  # s4.6 K7
K7_N = 200                   # s4.6 K7 (ii): i = 0..200
SS_REL = 1e-6                # s4.6 DG*_f,ss
TIE_K = 2e-3                 # s4.6 tau_tie
REF_STEP = 0.01              # s4.6 izgara
REF_BISECT = 1e-4            # s4.6
LOCUS_F_HZ = np.logspace(-2, 3.5, 4000)               # s4.5
BRENT_RTOL = 1e-12           # s4.5
BRENT_MAXIT = 200
COND_JRR_W0 = 1e12           # s4.5 omega = 0 adayi
SIMPLE_K = 1e-6              # s4.3 K6, s5.3
TRANS_MIN = 1e-9             # s4.3 K6
HAKT_H = 1e-3                # s5.1
HAKT_REL = 0.10              # s5.1
TRACK_WIN = 0.05             # s5.1 N-d
TRACK_DW = 1e-2              # s5.1 N-d
EPS_REL = 1e-6               # s4.7
U_ROUND = 2.22e-16           # s5.6
PROBE_F_HZ = (0.1, 1.0, 10.0, 100.0, 1000.0)          # s5.3, s5.6
S1_MIN = 1e-8
S2_TOL = 1e-9
S3_MIN = 1e-9
S4_K = 4.0
S5_TOL = 1e-9
LIM_VIOL, LIM_BORDER = 'ihlal', 'sinirda'             # e1_core OK/VIOL/BORDER
LIM_KEYS = ('L1', 'L2', 'L3', 'L4', 'L5')

J_E = np.array([[0.0, -1.0], [1.0, 0.0]])
SIGMA = np.diag([1.0, -1.0])
N_X = np.array([[0.0, 1.0], [1.0, 0.0]])
I2 = np.eye(2)

SABIT_REL = 'cdl1/CDL2_HDL2b_On_Kayit_v1.0_SABIT.md'
SABIT_SHA256 = '839f19c29222236565de5ead0b5efa75140a1ef8ea133ac6541538fe26253381'

# HDL2b s3.2 (1-13; v2 pin 7, 8, 10 duser); HDL2b-B1-t
PINS = [
    (1, 'e1_m-e1-0/code/e1_model.py', 12073, '0ba6571559b557090e693aa007a57d69cbaf409122ea7602fbe7e1edefe9a15b'),
    (2, 'e1_m-e1-0/code/e1_core.py', 37783, 'f1b9191cb05a2b4e08ffaba1ac4a44e3e9b50a21040055e96fe7b3f72fb34819'),
    (3, 'e1_k/code/e1k_model.py', 9383, 'd4e6392ca50337134e8602f9f129109a3aa156fa86591b29f9875bf30c5e7d78'),
    (4, 'e1_k/code/e1k_core.py', 16085, '6053896404aed7d52f8f75ee6a514cb243b330ef3a4392a3c2ca9475c5e21b3f'),
    (5, 'e1_k/code/e1k_run.py', 50372, '3aa707f190d433864eb7c30be96580f15c4a65b3e4e055b48992af5535387c4a'),
    (6, 'r_ha_b/code/rhab_model.py', 16913, 'db9dd3fdf510a21606a25060e423421dec977ce29dfd4fcadffb38eb9e1c9825'),
    (7, 'cdl1/CDL2_HDL2_On_Kayit_v1.0_SABIT.md', 38263,
     'c1215e60a2100165729bafb99b0ef2b81f089e04981b686177cc8a2f48ef0e36'),
    (8, 'cdl1/HDL2_sonuc_raporu_v1.md', 10874, 'c62dd5eac15de5b134fe0145437583ce0c8e2e953028ece6aba331dcb5288f84'),
    (9, 'cdl1/CDL2_E1_notu_v0.1.md', 24819, '7c5fd5881288ab58e15b2b7ea059088b7bb841728a5376475dcd0273d606a7f3'),
    (10, 'cdl1/HDL2_kod_denetimi_v2.md', 8912,
     '313290a8fb69510a5a3cb0e14a529480908b479f6df258ff6149c8878da2f27f'),
    (11, 'cdl1/CDL2_HDL2b_On_Kayit_v0.1_bagimsiz_denetim.md', 18359,
     'e2d5adef11ff20f292154bb757d5b828d576e7844cf1efdd6d18d001392b095c'),
    (12, 'cdl1/CDL2_HDL2b_On_Kayit_v0.3_bagimsiz_denetim.md', 19344,
     '217a3dfd45f647a632754627ad904fab7b2d6e35ea777c5fa1246188aa72baa8'),
    (13, 'archive/hdl2_run_v2_20261021.py', 73625, 'cbc34430d54b4d3f71e4c1a951646180b0025bfd9e7611d001b8d3c30d174057'),
]
MODULE_PINS = {'e1_model': 1, 'e1_core': 2, 'e1k_model': 3, 'e1k_core': 4, 'rhab_model': 6}
REHASH_PINS = (1, 2, 3, 4, 5, 6)
RHO_FIELDS = ('P_ref', 'Q_ref', 'V_ref', 'V_ref_dc', 'Iq_ref')
RUN_ID_RE = re.compile(r'^HDL2b_\d{8}_[a-z]$')

GEC, KAL, BEL, NE, HSZ = 'GEC', 'KAL', 'BELIRSIZ', 'NE', 'HESAPLANAMADI'
GATE_ORDER = ('K1', 'K2', 'K3', 'K3p', 'K4', 'K5', 'K6', 'K7')
CAUGHT = (np.linalg.LinAlgError, ValueError, ZeroDivisionError)


class Abort(Exception):
    """SABIT s6 satir 1."""


# ------------------------------------------------------------------ dosya erisimi (tek nokta)
def _read_bytes(path):
    with open(path, 'rb') as fh:
        return fh.read()


def _write_text(path, text):
    with open(path, 'w', encoding='utf-8', newline='\n') as fh:
        fh.write(text)


def sha256_hex(data):
    return hashlib.sha256(data).hexdigest()


def pin_list_sha256(pins):
    """Yetki dosyasindaki 'pin listesi hash'i': 'no<TAB>yol<TAB>bayt<TAB>sha' satirlari, UTF-8, LF (T4 kalibi)."""
    text = ''.join('%d\t%s\t%d\t%s\n' % p for p in pins)
    return sha256_hex(text.encode('utf-8'))


def pin_path(root, rel):
    return os.path.join(root, *rel.split('/'))


def verify_pins(root, pins):
    """Tum pinleri bayt + sha256 ile dogrular; tek uyusmazlik ABORT. Icerik ayristirilmaz."""
    rows = []
    for no, rel, size, sha in pins:
        path = pin_path(root, rel)
        if not os.path.isfile(path):
            raise Abort('pin %d yok: %s' % (no, rel))
        data = _read_bytes(path)
        got = sha256_hex(data)
        rows.append(dict(no=no, path=rel, bytes_expected=size, bytes=len(data), sha256_expected=sha, sha256=got))
        if len(data) != size or got != sha:
            raise Abort('pin %d uyusmuyor: %s (bayt %d/%d)' % (no, rel, len(data), size))
    return rows


def rehash_pins(root, pins, numbers):
    """SABIT s3: model modulleri kosu sonunda yeniden hash'lenir; degisim -> ABORT."""
    for no, rel, size, sha in pins:
        if no in numbers:
            data = _read_bytes(pin_path(root, rel))
            if len(data) != size or sha256_hex(data) != sha:
                raise Abort('pin %d kosu sirasinda degisti: %s' % (no, rel))


# ------------------------------------------------------------------ model (yalniz import; HDL2-B1-a/c)
def import_models(root):
    """Pin dogrulamasindan SONRA cagrilir. Model modulleri degistirilmez, yamalanmaz."""
    for sub in ('e1_m-e1-0/code', 'e1_k/code'):
        p = pin_path(root, sub)
        if p not in sys.path:
            sys.path.insert(0, p)
    import e1k_model as KM
    import e1k_core as KC
    import e1_core as EC
    import e1_model as EM
    mods = dict(e1k_model=KM, e1k_core=KC, e1_core=EC, e1_model=EM, rhab_model=EM.RB)
    rel = {no: r for no, r, _, _ in PINS}
    for name, no in MODULE_PINS.items():
        got = os.path.normcase(os.path.realpath(mods[name].__file__))
        exp = os.path.normcase(os.path.realpath(pin_path(root, rel[no])))
        if got != exp:
            raise Abort('modul %s pinli yoldan yuklenmedi: %s' % (name, mods[name].__file__))
    TH = EC.TH
    if not (TH['res'] == TH_RES and TH['cond_branch'] == COND_MAX and TH['halvings'] == HALVINGS):
        raise Abort('e1_core.TH esikleri betik sabitleriyle uyusmuyor')
    if tuple(EC.CANDIDATES) != CANDIDATES_EXPECTED:
        raise Abort('e1_core.CANDIDATES beklenen degil')
    if list(EC.KEEP) != [k for k in range(len(EM.STATE_NAMES)) if k != EM.I_THETA]:
        raise Abort('e1_core.KEEP beklenen degil')
    if tuple(EM.REF_NAMES) != RHO_FIELDS:
        raise Abort('REF_NAMES sirasi RHO_FIELDS ile ayni degil')
    if EC.VIOL != LIM_VIOL or EC.BORDER != LIM_BORDER:
        raise Abort('e1_core sinir durum dizgeleri beklenen degil')
    codes = [s.code for s in KC.SETTINGS]
    if any(codes.count(c) != 1 for c in SETTING_CODES):
        raise Abort('e1k_core.SETTINGS icinde S1/S2/S3 tek degil')
    return mods


def make_model(mods, code):
    """e1k_run.build_model ile ayni nesne (HDL2-B1-a; pin 5:343-348)."""
    KC, KM = mods['e1k_core'], mods['e1k_model']
    spec = [s for s in KC.SETTINGS if s.code == code][0]
    kpv, kiv = KC.pu_gains(spec)
    return KM.E1KModel(code, dict(kpv=kpv, kiv=kiv))


def dispatch_HDL2(EC, model, disp, P_akt, G_R):
    """SABIT s4.2 adim 1-6 (B-1 secenek ii). Pinli modullere yazmaz; ozel yontemler degistirilmeden cagrilir.
    U-4: dispatch_E1 istisna kumesi yakalanir -> K1 NE-x0."""
    rec = dict(ok=False, reason=None, P_akt=P_akt, G_R=G_R)
    try:
        pf = EC.power_flow(P_akt, G_R, model.net)                                      # adim 1
        rec['pf_mismatch'] = float(pf['mismatch'])
        if not pf['converged']:
            rec['reason'] = 'K1: power_flow yakinsamadi'
            return rec
        li = EC.load_init(P_akt * model.net['Sbase'] / model.load['base_power'], pf['V2'], model.load)  # adim 2
        x_init, gi = disp._assemble(pf, li)                                             # adim 3
        rho = np.array([gi['p_e'], gi['q_e'], gi['v_refr'], li['Vref_dc'], li['Iq_ref']], dtype=float)  # adim 4
        x_ref, hist, _ = disp.refine(x_init, rho, G_R, 'new')                          # adim 5
        rec['rho'] = rho
        rec['refine_res'] = [float(hh['res']) for hh in hist]
        nt = EC.newton_theta_fixed(model, x_ref, rho, G_R)                              # adim 6
        rec.update(newton_res=float(nt['res']), newton_iter=int(nt['n_iter']), newton_criterion=nt['criterion'])
        if not nt['converged']:
            rec['reason'] = 'K1: newton_theta_fixed yakinsamadi'
            return rec
        rec['x0'] = np.array(nt['x'], dtype=float)
        rec['ok'] = True
        return rec
    except (EC.DispatchError, np.linalg.LinAlgError, ValueError, ZeroDivisionError) as exc:
        rec['reason'] = 'K1: %s: %s' % (type(exc).__name__, exc)
        return rec


class RealSystem:
    """PF-1 dondurulmus modelinin uye (model, rho) arayuzu. Sentetik testteki SynthSystem ile ayni arayuz."""

    def __init__(self, mods, model, rho):
        EM, EC = mods['e1_model'], mods['e1_core']
        self.EC, self.model, self.rho = EC, model, np.asarray(rho, dtype=float)
        names = list(EM.STATE_NAMES)
        ix = {nm: k for k, nm in enumerate(names)}
        self.n = len(names)
        self.i_theta = EM.I_THETA
        self.keep = list(EC.KEEP)
        self.b = [ix['V_2:R'], ix['V_2:I']]
        self.l = [ix[nm] for nm in EM.LOAD_STATE_NAMES]
        self.sig = [k for k in self.keep if k not in self.b and k not in self.l]
        self.i_load_cur = (ix[EM.L + ':ir_filter'], ix[EM.L + ':ii_filter'])
        self.M = np.asarray(model.M, dtype=float)
        self.kL = float(model.load['base_power']) / float(model.net['Sbase'])
        self.trz = bool(model.theta_row_zero['new'])
        self.net = dict(r=float(model.net['r']), x=float(model.net['x']), b_to=float(model.net['b_to']),
                        wb=float(EM.WB))
        self.TH = EC.TH

    def f(self, x, G):
        return np.asarray(self.model.f(x, self.rho, G), dtype=float)

    def J(self, x, G):
        return np.asarray(self.model.J(x, self.rho, G), dtype=float)

    def Jt(self, x, G):
        model = self.model
        return np.asarray(model.Jx_tilde(x, model.h(x, self.rho), self.rho, G), dtype=float)

    def newton(self, x, G):
        r = self.EC.newton_theta_fixed(self.model, x, self.rho, G)
        return dict(x=np.array(r['x'], dtype=float), converged=bool(r['converged']), n_iter=int(r['n_iter']),
                    res=float(r['res']))

    def alpha(self, x, G):
        """HDL2-B1-i: alpha_from(identify_ref) tam A = J/M uzerinde. Doner: (alpha ya da None, A)."""
        EC = self.EC
        A = self.J(x, G) / self.M[:, None]
        lam, _, _, PFn = EC.eig_part(A)
        ref = EC.identify_ref(lam, PFn, self.trz)
        al = EC.alpha_from(lam, ref)
        return (float(al['alpha']) if al['defined'] else None), A

    def limits(self, x, G):
        return self.EC.limits(self.model, x, self.rho, G)


# ------------------------------------------------------------------ saf dogrusal cebir
def cond2(Mx):
    with np.errstate(all='ignore'):
        try:
            c = float(np.linalg.cond(Mx))
        except np.linalg.LinAlgError:
            return float('inf')
    return c if math.isfinite(c) else float('inf')


def rot(theta):
    """R(-theta) (HDL2-B1-g)."""
    c, s = math.cos(theta), math.sin(theta)
    return c * I2 - s * J_E


def to_f0(Ro, Y):
    return Ro @ Y @ Ro.T


def eig_lr(Y):
    """Sag ozvektorler R ve W = R^-1 (HDL2-B1-f)."""
    lam, R = np.linalg.eig(np.asarray(Y, dtype=complex))
    W = np.linalg.inv(R)
    return lam, R, W


def bra(W, R, i, X):
    return complex(W[i] @ X @ R[:, i])


def pis(W, R, i):
    pd = complex(W[i, 0] * R[0, i])
    pq = complex(W[i, 1] * R[1, i])
    px = complex(W[i, 0] * R[1, i] + W[i, 1] * R[0, i])
    return pd, pq, px


def kap(c, z):
    """kappa = Re[(1 + ic) z] (E1 notu L-kappa)."""
    return float(((1.0 + 1j * c) * z).real)


def kappa_parts(c, P, V, xi_d, xi_q, pi_d, pi_x):
    """SABIT s4.8: kappa_V, kappa_theta, kappa_L."""
    a = 2.0 * P / V ** 3
    kV = kap(c, a * xi_d * (2.0 * pi_d - 1.0))
    kT = kap(c, -a * xi_q * pi_x)
    return kV, kT, kV + kT


def nearest(lam, target):
    return int(np.argmin(np.abs(np.asarray(lam) - target)))


def gap_ok(lam):
    l1, l2 = complex(lam[0]), complex(lam[1])
    return abs(l1 - l2) > SIMPLE_K * max(1.0, abs(l1), abs(l2))


def sgn(v):
    return 1 if v > 0 else (-1 if v < 0 else 0)


# ------------------------------------------------------------------ port admitansi (s4.4)
def port_parts(J, M, b, r):
    J = np.asarray(J, dtype=float)
    return dict(Jbb=J[np.ix_(b, b)], Jbr=J[np.ix_(b, r)], Jrb=J[np.ix_(r, b)], Jrr=J[np.ix_(r, r)],
                Mb=np.asarray(M, dtype=float)[b], Mr=np.asarray(M, dtype=float)[r])


def _q(pp, s):
    return s * np.diag(pp['Mr']) - pp['Jrr']


def y_port(pp, s):
    """Y_tot(s) = s M_b - J_bb - J_br (s M_r - J_rr)^-1 J_rb."""
    KJ = np.linalg.solve(_q(pp, s), pp['Jrb'].astype(complex))
    return s * np.diag(pp['Mb']) - pp['Jbb'] - pp['Jbr'] @ KJ


def y_port_batch(pp, s_arr):
    nr = len(pp['Mr'])
    Q = s_arr[:, None, None] * np.diag(pp['Mr'])[None] - pp['Jrr'][None]
    KJ = np.linalg.solve(Q, np.broadcast_to(pp['Jrb'].astype(complex), (len(s_arr), nr, 2)).copy())
    return s_arr[:, None, None] * np.diag(pp['Mb'])[None] - pp['Jbb'][None] - pp['Jbr'][None] @ KJ


def schur_terms(pp, s):
    """K J_rb ve J_br K (K = (s M_r - J_rr)^-1)."""
    Q = _q(pp, s)
    KJ = np.linalg.solve(Q, pp['Jrb'].astype(complex))
    JK = np.linalg.solve(Q.T, pp['Jbr'].T.astype(complex)).T
    return Q, KJ, JK


def dy_domega(pp, s):
    """d_omega Y_tot = j[M_b + J_br K M_r K J_rb] (s4.7)."""
    _, KJ, JK = schur_terms(pp, s)
    return 1j * (np.diag(pp['Mb']) + JK @ np.diag(pp['Mr']) @ KJ)


def y_zero(pp):
    """s4.5 N-a: Y_tot(0) = -J_bb + J_br J_rr^-1 J_rb; cond(J_rr) > 1e12 -> None (P2'-omega0)."""
    if cond2(pp['Jrr']) > COND_JRR_W0:
        return None
    return -pp['Jbb'] + pp['Jbr'] @ np.linalg.solve(pp['Jrr'], pp['Jrb'])


# ------------------------------------------------------------------ lokus (s4.5)
def track_branches(lam):
    out = np.array(lam, dtype=complex, copy=True)
    for k in range(1, out.shape[0]):
        p0, p1 = out[k - 1, 0], out[k - 1, 1]
        a, b = out[k, 0], out[k, 1]
        if abs(a - p0) + abs(b - p1) > abs(b - p0) + abs(a - p1):
            out[k, 0], out[k, 1] = b, a
    return out


def brent_root(g, a, b, fa, fb, rtol=BRENT_RTOL, maxit=BRENT_MAXIT):
    """Brent-Dekker (ikiye bolme + sekant + ters ikinci derece). |b - a| <= rtol*min(|a|, |b|) durur."""
    if fa == 0.0:
        return a
    if fb == 0.0:
        return b
    if fa * fb > 0:
        raise ValueError('brent: isaret degisimi yok')
    if abs(fa) < abs(fb):
        a, b, fa, fb = b, a, fb, fa
    c, fc, mflag, d = a, fa, True, a
    for _ in range(maxit):
        if fb == 0.0 or abs(b - a) <= rtol * min(abs(a), abs(b)):
            return b
        if fa != fc and fb != fc:
            s = (a * fb * fc / ((fa - fb) * (fa - fc)) + b * fa * fc / ((fb - fa) * (fb - fc))
                 + c * fa * fb / ((fc - fa) * (fc - fb)))
        else:
            s = b - fb * (b - a) / (fb - fa)
        tol = rtol * min(abs(a), abs(b))
        lo, hi = sorted(((3.0 * a + b) / 4.0, b))
        if (not (lo < s < hi) or (mflag and abs(s - b) >= abs(b - c) / 2.0)
                or (not mflag and abs(s - b) >= abs(c - d) / 2.0)
                or (mflag and abs(b - c) < tol) or (not mflag and abs(c - d) < tol)):
            s = (a + b) / 2.0
            mflag = True
        else:
            mflag = False
        fs = g(s)
        d, c, fc = c, b, fb
        if fa * fs < 0:
            b, fb = s, fs
        else:
            a, fa = s, fs
        if abs(fa) < abs(fb):
            a, b, fa, fb = b, a, fb, fa
    return b


def _branch_at(pp, w, wa, wb, la, lb):
    t = (w - wa) / (wb - wa)
    target = la + t * (lb - la)
    lam, R = np.linalg.eig(y_port(pp, 1j * w))
    i = nearest(lam, target)
    return complex(lam[i]), R[:, i]


def locus(pp, f_hz=LOCUS_F_HZ):
    """s4.5: omega > 0 adaylari (Brent) + omega = 0 adaylari. Doner: dict(cands, p2w0, n_signchange)."""
    w = 2.0 * math.pi * np.asarray(f_hz, dtype=float)
    Y = y_port_batch(pp, 1j * w)
    lam = np.linalg.eigvals(Y)
    if not np.all(np.isfinite(lam)):
        raise ValueError('lokus: sonlu olmayan ozdeger')
    lam = track_branches(lam)
    cands, nsc = [], 0
    for j in (0, 1):
        im = lam[:, j].imag
        for k in range(len(w)):
            if im[k] == 0.0:
                lc, v, wc = complex(lam[k, j]), None, float(w[k])
            elif k + 1 < len(w) and im[k] * im[k + 1] < 0:
                wa, wb, la, lb = float(w[k]), float(w[k + 1]), complex(lam[k, j]), complex(lam[k + 1, j])

                def g(ww, wa=wa, wb=wb, la=la, lb=lb):
                    return _branch_at(pp, ww, wa, wb, la, lb)[0].imag
                wc = brent_root(g, wa, wb, float(im[k]), float(im[k + 1]))
                lc, v = _branch_at(pp, wc, wa, wb, la, lb)
            else:
                continue
            nsc += 1
            if v is None:
                ev, Rv = np.linalg.eig(y_port(pp, 1j * wc))
                v = Rv[:, nearest(ev, lc)]
            if lc.real > 0:
                cands.append(dict(kind='w>0', branch=j, omega=wc, lam=lc, rho=float(lc.real), v=np.asarray(v)))
    Y0 = y_zero(pp)
    p2w0 = Y0 is None
    if Y0 is not None:
        ev, Rv = np.linalg.eig(Y0)
        if not (np.iscomplexobj(ev) and np.any(np.asarray(ev).imag != 0)):
            for i in range(2):
                e = float(np.real(ev[i]))
                if e > 0:
                    cands.append(dict(kind='w0', branch=None, omega=0.0, lam=complex(e), rho=e,
                                      v=np.asarray(Rv[:, i], dtype=complex)))
    return dict(cands=cands, p2w0=p2w0, n_signchange=nsc)


def min_cand(cands):
    if not cands:
        return None
    best = cands[0]
    for c in cands[1:]:
        if c['rho'] < best['rho']:
            best = c
    return best


def overlap(v0, v):
    return float(abs(np.vdot(v0, v)) / (np.linalg.norm(v0) * np.linalg.norm(v)))


def track(cands, w_ref, v_ref):
    """s5.1 N-d izleme kurali. Doner: aday ya da None (izleme-KAL)."""
    win = [c for c in cands if c['kind'] == 'w>0' and abs(c['omega'] - w_ref) <= TRACK_WIN * w_ref]
    if not win:
        return None
    best = None
    for c in win:
        o = overlap(v_ref, c['v'])
        if best is None or o > best[0] or (o == best[0] and c['omega'] < best[1]['omega']):
            best = (o, c)
    br = best[1]['branch']
    same = [c for c in cands if c['kind'] == 'w>0' and c['branch'] == br]
    pick = None
    for c in same:
        dd = abs(c['omega'] - w_ref)
        if pick is None or dd < pick[0] or (dd == pick[0] and c['omega'] < pick[1]['omega']):
            pick = (dd, c)
    c = pick[1]
    if abs(c['omega'] - w_ref) / w_ref > TRACK_DW:
        return None
    return dict(c, overlap=best[0])


def crit_check(pp, crit, Ro):
    """K6 (P8) ve kritik dalin F0 ozvektorleri."""
    s = 1j * crit['omega']
    YF = to_f0(Ro, y_port(pp, s))
    lam, R, W = eig_lr(YF)
    i = nearest(lam, crit['lam'])
    dl = bra(W, R, i, to_f0(Ro, dy_domega(pp, s)))
    return dict(i=i, lam=lam, R=R, W=W, simple=gap_ok(lam), d_omega_lam=dl, transversal=abs(dl.imag) > TRANS_MIN,
                gap=float(abs(lam[0] - lam[1])))


# ------------------------------------------------------------------ alpha siniflamasi (s4.6)
def alpha_class(a, tab):
    if a is None:
        return 'tanimsiz'
    if a < -tab:
        return 'kararli'
    if a > tab:
        return 'kararsiz'
    return 'sifir'


def alpha_tab_of(A, keep):
    return ALPHA_TAB_K * float(np.linalg.norm(A[np.ix_(keep, keep)], 2))


def k7_check(sysm, x0, G, dGf, tab):
    """s4.6 K7 (dondurulmus; x0 sabit, yalniz G_R -> G_R - DG). HDL2-B1-j."""
    def cls(dg):
        a, _ = sysm.alpha(x0, G - dg)
        return alpha_class(a, tab), a
    lo_dg, hi_dg = dGf * (1.0 - TAU7), dGf * (1.0 + TAU7)
    c_lo, a_lo = cls(lo_dg)
    c_hi, a_hi = cls(hi_dg)
    grid = []
    for i in range(K7_N + 1):
        c, a = cls((i / float(K7_N)) * lo_dg)
        grid.append(c)
    classes = [c_lo, c_hi] + grid
    cond_i = c_lo == 'kararli' and c_hi == 'kararsiz'
    cond_ii = all(c == 'kararli' for c in grid)
    first_bad = next((i for i, c in enumerate(grid) if c != 'kararli'), None)
    out = dict(alpha_lo=a_lo, alpha_hi=a_hi, class_lo=c_lo, class_hi=c_hi, cond_i=cond_i, cond_ii=cond_ii,
               grid_first_not_stable=first_bad, ratio_lo=(abs(a_lo) / tab if a_lo is not None else None),
               ratio_hi=(abs(a_hi) / tab if a_hi is not None else None), alpha_tab=tab)
    if any(c in ('sifir', 'tanimsiz') for c in classes):
        out.update(passed=False, reason='K7-cozunurluk')
    elif not (cond_i and cond_ii):
        out.update(passed=False, reason='K7-uyumsuz')
    else:
        out.update(passed=True, reason=None)
    if cond_i:
        lo, hi = lo_dg, hi_dg
        while hi - lo > SS_REL * dGf:
            mid = (lo + hi) / 2.0
            if cls(mid)[0] == 'kararli':
                lo = mid
            else:
                hi = mid
        out['dGf_ss'] = (lo + hi) / 2.0
    else:
        out['dGf_ss'] = None
    return out


# ------------------------------------------------------------------ kappa (s4.7-4.8)
def sub_admittances(sysm, x, G, s, Jfull):
    """N-e / U-1 / U-2: Y_src^dond, Y_L^dond (J~ = Jx_tilde(x, h(x))), Y_x = Y_tot - Y_src - Y_L - G I."""
    Jt = sysm.Jt(x, G)
    b, l, sg, M = sysm.b, sysm.l, sysm.sig, sysm.M
    Mb = np.diag(M[b])
    Qs = s * np.diag(M[sg]) - Jt[np.ix_(sg, sg)]
    Ysrc = (s * Mb + (-Jt[np.ix_(b, b)] - G * I2)
            - Jt[np.ix_(b, sg)] @ np.linalg.solve(Qs, Jt[np.ix_(sg, b)].astype(complex)))
    Ql = s * np.diag(M[l]) - Jt[np.ix_(l, l)]
    YL = -Jt[np.ix_(b, l)] @ np.linalg.solve(Ql, Jt[np.ix_(l, b)].astype(complex))
    r = [k for k in sysm.keep if k not in b]
    Ytot = y_port(port_parts(Jfull, M, b, r), s)
    Yx = Ytot - Ysrc - YL - G * I2
    cross = (float(np.max(np.abs(Jt[np.ix_(l, sg)]))), float(np.max(np.abs(Jt[np.ix_(sg, l)]))))
    return Ysrc, YL, Yx, cross


def kappa_member(sysm, x0, G, crit, theta_b):
    """SABIT s4.7-4.8 + S3 (s5.6)."""
    keep, b = sysm.keep, sysm.b
    r = [k for k in keep if k not in b]
    M = sysm.M
    J0 = sysm.J(x0, G)
    Jk = J0[np.ix_(keep, keep)]
    dfd = np.zeros(sysm.n)
    dfd[b] = x0[b]                                        # df/dDG = +(V_2:R, V_2:I) bara 102 satirlari
    d = np.zeros(sysm.n)
    d[keep] = -np.linalg.solve(Jk, dfd[keep])
    eps = EPS_REL / max(1e-300, float(np.max(np.abs(d)))) * max(1.0, float(np.max(np.abs(x0))))
    xp, xm = x0 + eps * d, x0 - eps * d
    Jp, Jm = sysm.J(xp, G), sysm.J(xm, G)
    dJ = (Jp - Jm) / (2.0 * eps)
    s = 1j * crit['omega']
    pp = port_parts(J0, M, b, r)
    dp = port_parts(dJ, M, b, r)
    Q, KJ, JK = schur_terms(pp, s)
    dY = -dp['Jbb'] - dp['Jbr'] @ KJ - JK @ dp['Jrr'] @ KJ - JK @ dp['Jrb']
    Ro = rot(theta_b)
    cc = crit_check(pp, crit, Ro)
    W, R, i = cc['W'], cc['R'], cc['i']
    dlw = cc['d_omega_lam']
    c = float(dlw.real / dlw.imag)
    eta = bra(W, R, i, to_f0(Ro, dY))
    xi = Ro @ d[b]
    ir, ii = sysm.i_load_cur
    P = sysm.kL * (x0[b[0]] * x0[ir] + x0[b[1]] * x0[ii])
    V = math.hypot(x0[b[0]], x0[b[1]])
    pd, pq, px = pis(W, R, i)
    k_tam = kap(c, eta)
    kV, kT, kL_ = kappa_parts(c, P, V, xi[0], xi[1], pd, px)
    Sp = sub_admittances(sysm, xp, G, s, Jp)
    Sm = sub_admittances(sysm, xm, G, s, Jm)
    S0 = sub_admittances(sysm, x0, G, s, J0)
    dYsrc, dYL, dYx = [(Sp[k] - Sm[k]) / (2.0 * eps) for k in range(3)]
    Mxi = xi[0] * SIGMA - xi[1] * N_X
    a = 2.0 * P / V ** 3
    k_D = kap(c, bra(W, R, i, to_f0(Ro, sysm.kL * dYL)) - a * bra(W, R, i, Mxi))
    k_K = kap(c, bra(W, R, i, to_f0(Ro, dYsrc)))
    k_x1 = k_tam - kL_ - k_D - k_K
    k_x2 = kap(c, bra(W, R, i, to_f0(Ro, dYx)))
    condQ = cond2(Q)
    e_s3 = max(S3_MIN, 10.0 * U_ROUND * condQ / EPS_REL) * max(1.0, abs(k_tam))
    s3_ok = bool(math.isfinite(k_x1) and math.isfinite(k_x2) and abs(k_x1 - k_x2) <= e_s3)
    return dict(c=c, eta=eta, xi_d=float(xi[0]), xi_q=float(xi[1]), P=float(P), V=float(V), pi_d=pd, pi_q=pq,
                pi_x=px, k_tam=k_tam, k_V=kV, k_theta=kT, k_L=kL_, k_Delta=k_D, k_K=k_K, k_x1=k_x1, k_x2=k_x2,
                eps=eps, d_inf=float(np.max(np.abs(d))), S3=dict(passed=s3_ok, diff=abs(k_x1 - k_x2), tol=e_s3,
                                                                 cond_Q=condQ),
                d_dominant=sgn(kap(c, 2.0 * pd - 1.0)), H4=bool(abs(k_tam - kL_) > 0.5 * abs(kL_)),
                rest=abs(k_tam - kL_), kL=sysm.kL, Jt_cross_max=S0[3])


# ------------------------------------------------------------------ sondalar (s5.6)
def s1_probe(J, M, keep, b):
    r = [k for k in keep if k not in b]
    pp = port_parts(J, M, b, r)
    rows, ok = [], True
    for fz in PROBE_F_HZ:
        s = 1j * 2.0 * math.pi * fz
        L = (s * np.diag(M) - J)[np.ix_(keep, keep)]
        Q = _q(pp, s)
        Y = y_port(pp, s)
        sL, lL = np.linalg.slogdet(L)
        sQ, lQ = np.linalg.slogdet(Q)
        sY, lY = np.linalg.slogdet(Y)
        e = max(S1_MIN, 10.0 * U_ROUND * (cond2(L) + cond2(Q)))
        dl = abs(lL - (lQ + lY))
        ds = abs(sL * np.conj(sQ * sY) - 1.0)
        passed = bool(np.isfinite(dl) and np.isfinite(ds) and dl <= e and ds <= e)
        ok &= passed
        rows.append(dict(f_Hz=fz, d_log=float(dl), d_sgn=float(ds), tol=e, cond_Y=cond2(Y), passed=passed))
    return dict(passed=bool(ok), rows=rows)


def y_probe(net, theta_b, G, P, V, w):
    """s5.3 Y_probe(jw) = R(-theta_b) Y_iso R(-theta_b)^T + G I - (P/V^2) Sigma (U-7)."""
    s = 1j * w
    Z = (net['r'] + net['x'] * s / net['wb']) * I2 + net['x'] * J_E
    Yiso = np.linalg.inv(Z) + (net['b_to'] * s / net['wb']) * I2 + net['b_to'] * J_E
    Ro = rot(theta_b)
    return to_f0(Ro, Yiso) + G * I2 - (P / V ** 2) * SIGMA


def s2_probe(net, theta_b, G, P, V, omega_star=None):
    pts = [('%g Hz' % fz, 2.0 * math.pi * fz) for fz in PROBE_F_HZ]
    if omega_star is not None:
        pts.append(('omega*', float(omega_star)))
    rows, ok, n_eval = [], True, 0
    for lab, w in pts:
        lam, R, W = eig_lr(y_probe(net, theta_b, G, P, V, w))
        if not gap_ok(lam):
            rows.append(dict(point=lab, skipped=True))
            continue
        for i in range(2):
            pd, pq, px = pis(W, R, i)
            tol = S2_TOL * max(1.0, abs(pd), abs(pq))
            passed = bool(abs(px) <= tol)
            ok &= passed
            n_eval += 1
            rows.append(dict(point=lab, branch=i, pi_x_abs=abs(px), tol=tol, passed=passed, skipped=False))
    return dict(passed=bool(ok), n_evaluated=n_eval, NE=(n_eval == 0), rows=rows)


def s4_probe(sysm, x0, G):
    dG = 0.5 * G
    D = sysm.J(x0, G - dG) - sysm.J(x0, G)
    tol = S4_K * U_ROUND * max(1.0, G)
    b = sysm.b
    diag_ok = all(abs(D[k, k] - dG) <= tol for k in b)
    mask = np.ones(D.shape, dtype=bool)
    for k in b:
        mask[k, k] = False
    other_zero = bool(np.all(D[mask] == 0.0))
    return dict(passed=bool(diag_ok and other_zero), diag=[float(D[k, k]) for k in b], dG=dG, tol=tol,
                other_zero=other_zero)


def s5_probe():
    """E1 notu s3: Ornek B ve Ornek C bilinen yanitlari (kappa ve S2 ile ayni kod yolu)."""
    rows, ok = [], True
    sq3 = math.sqrt(3.0)
    # Ornek B: Y = A I + 2 J_E - Sigma, A* = 0.7 - i sqrt(3), c = 1/2, xi = (0.5, -0.5), P = V = 1
    Y = (0.7 - 1j * sq3) * I2 + 2.0 * J_E - SIGMA
    lam, R, W = eig_lr(Y)
    i = nearest(lam, 0.7)
    pd, _, px = pis(W, R, i)
    kV, kT, kL_ = kappa_parts(0.5, 1.0, 1.0, 0.5, -0.5, pd, px)
    exp = -1.0 / (2.0 * sq3)
    passed = abs(kL_ - exp) <= S5_TOL and abs(kL_ - (-exp)) > 1e-3 and abs(px) <= S5_TOL
    ok &= passed
    rows.append(dict(example='B', k_L=kL_, expected=exp, k_theta=kT, pi_x_abs=abs(px), passed=bool(passed)))
    # Ornek C: Y = 3.5 I - Sigma + d0 N, kritik dal lambda = 3.5 - r, xi = (5, -d0)/D, D = 15 - d0^2
    for d0 in (0.0, 1.0, math.sqrt(5.0), 3.0):
        r = math.sqrt(1.0 + d0 * d0)
        D = 15.0 - d0 * d0
        Y = 3.5 * I2 - SIGMA + d0 * N_X
        lam, R, W = eig_lr(Y)
        i = nearest(lam, 3.5 - r)
        pd, _, px = pis(W, R, i)
        kV, kT, kL_ = kappa_parts(0.5, 1.0, 1.0, 5.0 / D, -d0 / D, pd, px)
        e = (10.0 / (r * D), -2.0 * d0 * d0 / (r * D), -2.0 * (d0 * d0 - 5.0) / (r * D))
        passed = all(abs(a - b) <= S5_TOL for a, b in zip((kV, kT, kL_), e))
        row = dict(example='C', d0=d0, k_V=kV, k_theta=kT, k_L=kL_, expected=list(e))
        if d0 == 3.0:
            row['pi_x'] = px.real
            passed = passed and abs(px - (-3.0 / math.sqrt(10.0))) <= S5_TOL
        row['passed'] = bool(passed)
        ok &= passed
        rows.append(row)
    return dict(passed=bool(ok), rows=rows)


# ------------------------------------------------------------------ devamlilik (s4.6)
def path_step(sysm, x, G, dg_from, dg_to):
    """dg_from -> dg_to; basarisizlikta 2^h alt adim (h <= 5). Doner: (ok, x, newton_iter, h, n_substeps)."""
    iters, nsub_total = 0, 0
    for hv in range(HALVINGS + 1):
        nsub = 2 ** hv
        xs, ok = np.array(x, dtype=float, copy=True), True
        for j in range(1, nsub + 1):
            g = dg_from + (dg_to - dg_from) * j / nsub
            res = sysm.newton(xs, G - g)
            iters += res['n_iter']
            nsub_total += 1
            if not res['converged']:
                ok = False
                break
            xs = res['x']
        if ok:
            return True, xs, iters, hv, nsub_total
    return False, np.array(x, dtype=float, copy=True), iters, None, nsub_total


def rhp_count(J, M, r):
    A = J[np.ix_(r, r)] / np.asarray(M, dtype=float)[r][:, None]
    return int(np.sum(np.linalg.eigvals(A).real > 0))


def ref_grid(G, dGf):
    dgmax = min(G, 2.0 * dGf)
    out, k = [], 0
    while True:
        g = k * REF_STEP * dGf
        if g >= dgmax:
            out.append(dgmax)
            break
        out.append(g)
        k += 1
    return out, dgmax


def reference(sysm, x0, G, dGf, crit0):
    """s4.6 referans DG*_t + etiketler (HDL2-B1-k)."""
    keep, b, M = sysm.keep, sysm.b, sysm.M
    r = [k for k in keep if k not in b]
    tie = TIE_K * dGf
    grid, dgmax = ref_grid(G, dGf)
    rhp0 = rhp_count(sysm.J(x0, G), M, r)
    lab = dict(Y1=None, Y2=None, P7=None, P7_izlemesiz=None, P2p=None, P3=False, bolme_newton=False,
               alpha_tanimsiz=False)
    x, prev_g, n_newton, n_points = np.array(x0, dtype=float, copy=True), 0.0, 0, 0
    tw, tv = crit0['omega'], crit0['v']
    F_prev, port_loss = dGf, None
    loss, dGt, last_g = None, None, 0.0
    for g in grid[1:]:
        ok, xn, it, hv, ns = path_step(sysm, x, G, prev_g, g)
        n_newton += it
        if not ok:
            lab['Y1'] = g
            loss, dGt = 'kivrim-newton', prev_g
            break
        n_points += 1
        last_g = g
        Jn = sysm.J(xn, G - g)
        if cond2(Jn[np.ix_(keep, keep)]) > COND_MAX:
            lab['Y1'] = g
            loss, dGt = 'kivrim-cond', g
            break
        # port etiketleri (G_R ozgun degerinde; s4.6)
        pp = port_parts(sysm.J(xn, G), M, b, r)
        lc = locus(pp)
        tr = track(lc['cands'], tw, tv)
        if tr is None:
            if lab['Y2'] is None:
                lab['Y2'] = g
        else:
            cc = crit_check(pp, tr, I2)
            if not (cc['simple'] and cc['transversal']) and lab['Y2'] is None:
                lab['Y2'] = g
            tw, tv = tr['omega'], tr['v']
        if tr is None:
            # v2 N-1: izleme kaybinda izlenen-disi ayrimi tanimsiz; P7 degerlendirilmez, ayri etiket
            if lab['P7_izlemesiz'] is None and any(c['rho'] <= g for c in lc['cands']):
                lab['P7_izlemesiz'] = g
        else:
            others = [c for c in lc['cands'] if not (c['kind'] == tr['kind'] and c['branch'] == tr['branch']
                                                     and c['omega'] == tr['omega'])]
            if lab['P7'] is None and any(c['rho'] <= g for c in others):
                lab['P7'] = g
        if lab['P2p'] is None and rhp_count(Jn, M, r) != rhp0:
            lab['P2p'] = g
        mc = min_cand(lc['cands'])
        F = (mc['rho'] - g) if mc is not None else float('inf')
        if port_loss is None and F <= 0:
            port_loss = prev_g + F_prev * (g - prev_g) / (F_prev - F) if F_prev > 0 else g
        F_prev = F
        a, A = sysm.alpha(xn, G - g)
        cls = alpha_class(a, alpha_tab_of(A, keep))
        if cls == 'tanimsiz':
            lab['alpha_tanimsiz'] = True
        if cls != 'kararli':
            lo, hi, xlo = prev_g, g, x
            while hi - lo > REF_BISECT * dGf:
                mid = (lo + hi) / 2.0
                okm, xm, itm, _, _ = path_step(sysm, xlo, G, lo, mid)
                n_newton += itm
                if not okm:
                    lab['bolme_newton'] = True
                    hi = mid
                    continue
                am, Am = sysm.alpha(xm, G - mid)
                cm = alpha_class(am, alpha_tab_of(Am, keep))
                if cm == 'kararli':
                    lo, xlo = mid, xm
                else:
                    hi = mid
            loss, dGt = 'alpha', (lo + hi) / 2.0
            break
        x, prev_g = xn, g
    censored = loss is None
    if port_loss is not None:
        lab['P3'] = bool(censored or abs(port_loss - dGt) > tie)
    elif not censored:
        lab['P3'] = bool(last_g - dGt > tie)
    return dict(dGt=dGt, censored=censored, loss=loss, dG_max=dgmax, dgmax_is_GR=bool(G <= 2.0 * dGf), tie=tie,
                dGt_port=port_loss, labels=lab, n_newton=n_newton, n_points=n_points, last_g=last_g)


def rival5(sysm, x0, G, dGf):
    """s4.9 + HDL2-B1-l."""
    keep, b, M = sysm.keep, sysm.b, sysm.M
    r = [k for k in keep if k not in b]
    x, prev, n_newton, n_steps = np.array(x0, dtype=float, copy=True), 0.0, 0, 0
    nk = int(round(1.0 / REF_STEP))
    for k in range(1, nk + 1):
        g = dGf if k == nk else k * REF_STEP * dGf
        ok, x, it, hv, ns = path_step(sysm, x, G, prev, g)
        n_newton += it
        n_steps += ns
        if not ok:
            return dict(ok=False, F5=None, pred=None, n_newton=n_newton, n_steps=n_steps)
        prev = g
    mc = min_cand(locus(port_parts(sysm.J(x, G), M, b, r))['cands'])
    F5 = (mc['rho'] - dGf) if mc is not None else float('inf')
    tie = TIE_K * dGf
    pred = -1 if F5 < -tie else (1 if F5 > tie else 0)
    return dict(ok=True, F5=F5, pred=pred, n_newton=n_newton, n_steps=n_steps, n_loci=1)


# ------------------------------------------------------------------ H-AKT (s5.1)
def hakt(sysm, x0, G, dGf, crit0, k_tam):
    keep, b, M = sysm.keep, sysm.b, sysm.M
    r = [k for k in keep if k not in b]
    h = HAKT_H * dGf
    rhos = {}
    for sg in (1, -1):
        nt = sysm.newton(x0, G - sg * h)
        if not nt['converged']:
            return dict(status=KAL, reason='H-AKT-Newton', k_fd=None)
        lc = locus(port_parts(sysm.J(nt['x'], G), M, b, r))
        tr = track(lc['cands'], crit0['omega'], crit0['v'])
        if tr is None:
            return dict(status=KAL, reason='izleme-KAL', k_fd=None)
        rhos[sg] = tr['rho']
    k_fd = (rhos[1] - rhos[-1]) / (2.0 * h)
    sign_ok = abs(k_fd) < TAU_K / 10.0 or sgn(k_tam) == sgn(k_fd)
    mag_ok = abs(k_tam - k_fd) <= HAKT_REL * max(abs(k_fd), TAU_K)
    st = GEC if (sign_ok and mag_ok) else KAL
    return dict(status=st, reason=None if st == GEC else 'H-AKT-esik', k_fd=k_fd, sign_ok=bool(sign_ok),
                mag_ok=bool(mag_ok), h=h, rho_plus=rhos[1], rho_minus=rhos[-1])


# ------------------------------------------------------------------ uye: asama 1
def family_specs(p_grid=P_AKT_GRID, g_k=G_R_K):
    """HDL2b s4.2b: S3 x P_akt (literal sira, artan) x G_R = k/100 (literal sira, azalan). HDL2b s2 tamponu
    (|k - 25| <= 1) icindeki bir G_R aileyi gecersiz kilar -> Abort (HDL2b-B1-q, -r)."""
    out = []
    for code in SETTING_CODES:
        for p, ps in p_grid:
            for k in g_k:
                if abs(k - BUFFER_K[0]) <= BUFFER_K[1]:
                    raise Abort('aile korleme tamponunda G_R = %d/100 iceriyor (HDL2b s2, Delta-2)' % k)
                g = k / 100.0
                out.append(dict(setting=code, P_akt=p, G_R=g, id='%s_P%s_G%.2f' % (code, ps, g),
                                onceki_aile_uyesi=bool((code, ps, k) == PRIOR_FAMILY_MEMBER)))
    return out


def margins(lim, TH):
    L = lim['limits']
    l3 = min(min(L['L3']['V_101'] - TH['L3'][0], TH['L3'][1] - L['L3']['V_101']),
             min(L['L3']['V_102'] - TH['L3'][0], TH['L3'][1] - L['L3']['V_102']))
    return dict(L1=TH['L1'] - L['L1']['value'], L2=TH['L2'] - L['L2']['value'], L3=l3,
                L4=min(L['L4']['value'] - TH['L4'][0], TH['L4'][1] - L['L4']['value']), L5=-L['L5']['value'])


def stage1_member(spec, sysm, disp, flags):
    """Asama 1: K1-K7, sondalar S1-S4, kappa, (E'de) H-AKT. Abort firlatabilir."""
    G = spec['G_R']
    rec = dict(spec, dispatch={k: v for k, v in disp.items() if k not in ('x0', 'rho')},
               gates={k: dict(status=HSZ) for k in GATE_ORDER}, labels=[])
    gates = rec['gates']
    rec['rho'] = [float(v) for v in disp['rho']] if disp.get('rho') is not None else None
    if not disp['ok'] or sysm is None:
        gates['K1'] = dict(status=KAL, reason=disp.get('reason'))
        return _finish(rec)
    x0 = disp['x0']
    rec['_x0'] = x0
    keep, b, M = sysm.keep, sysm.b, sysm.M
    r = [k for k in keep if k not in b]
    theta_b = math.atan2(x0[b[1]], x0[b[0]])
    rec['theta_b'] = theta_b
    # K1
    res = float(np.max(np.abs(sysm.f(x0, G))))
    lim = sysm.limits(x0, G)
    L = lim['limits']
    rec['limits'] = {k: dict(value=L[k].get('value'), status=L[k]['status']) for k in L}
    rec['limits']['L3'].update(V_101=L['L3']['V_101'], V_102=L['L3']['V_102'])
    rec['margins'] = margins(lim, sysm.TH)
    rec['residual'] = res
    viol = [k for k in LIM_KEYS if L[k]['status'] == LIM_VIOL]
    border = [k for k in LIM_KEYS if L[k]['status'] == LIM_BORDER]
    if border:
        rec['labels'].append('sinirda:' + ','.join(border))
    if L['L6']['status'] != 'saglaniyor':
        rec['labels'].append('L6:' + L['L6']['status'])
    k1 = res <= TH_RES and not viol
    gates['K1'] = dict(status=GEC if k1 else KAL, reason=None if k1 else (
        'K1: res %r' % res if res > TH_RES else 'K1: sinir ihlali ' + ','.join(viol)))
    # S4 (x0 olan her uyede)
    rec['S4'] = s4_probe(sysm, x0, G)
    if not rec['S4']['passed']:
        raise Abort('S4 basarisiz: %s' % spec['id'])
    # K2, K3
    J0 = sysm.J(x0, G)
    try:
        a0, A0 = sysm.alpha(x0, G)
        tab = alpha_tab_of(A0, keep)
        rec.update(alpha=a0, alpha_tab=tab)
        c0 = alpha_class(a0, tab)
        gates['K2'] = dict(status=GEC if c0 == 'kararli' else KAL, reason=None if c0 == 'kararli' else 'K2: ' + c0)
    except CAUGHT as exc:
        tab = None
        gates['K2'] = dict(status=HSZ, reason='K2: %s' % exc)
    condJ = cond2(J0[np.ix_(keep, keep)])
    rec['cond_J'] = condJ
    gates['K3'] = dict(status=GEC if condJ <= COND_MAX else KAL, reason=None if condJ <= COND_MAX else 'K3: cond')
    # K3' (S1)
    try:
        s1 = s1_probe(J0, M, keep, b)
    except CAUGHT as exc:
        s1 = dict(passed=False, error=str(exc))
    rec['S1'] = s1
    # HDL2b s5.6b (Delta-5): S1 ilk uye = K1, K2, K3'un ucunu de gecen ilk uye (HDL2-B1-m (v2); davranis aynen)
    first_k13 = all(gates[k]['status'] == GEC for k in ('K1', 'K2', 'K3')) and not flags['s1_first_done']
    if all(gates[k]['status'] == GEC for k in ('K1', 'K2', 'K3')):
        flags['s1_first_done'] = True
    if not s1['passed'] and first_k13:
        raise Abort('S1 ilk uyede basarisiz: %s' % spec['id'])
    gates['K3p'] = dict(status=GEC if s1['passed'] else KAL, reason=None if s1['passed'] else 'K3p: S1')
    # K4, K5, K6 (lokus)
    pp = port_parts(J0, M, b, r)
    crit, cc = None, None
    try:
        lc = locus(pp)
        rec['locus'] = dict(n_cands=len(lc['cands']), p2w0=lc['p2w0'], n_signchange=lc['n_signchange'],
                            cands=[dict(kind=c['kind'], branch=c['branch'], omega=c['omega'], rho=c['rho'])
                                   for c in lc['cands']])
        if lc['p2w0']:
            rec['labels'].append("P2'-omega0")
        crit = min_cand(lc['cands'])
        if crit is None or not (0 < crit['rho'] <= G):
            gates['K4'] = dict(status=KAL, reason='K4: atma bu G_R\'de kararliligi bozamaz (dondurulmus)')
            if crit is not None:
                rec['dGf'] = crit['rho']
            crit = None
        else:
            rec.update(dGf=crit['rho'], omega_star=crit['omega'], crit_kind=crit['kind'])
            gates['K4'] = dict(status=GEC)
            if crit['kind'] == 'w0':
                gates['K5'] = dict(status=KAL, reason='K5-omega0')
            else:
                gates['K5'] = dict(status=GEC)
                cc = crit_check(pp, crit, rot(theta_b))
                rec['K6'] = dict(gap=cc['gap'], d_omega_Im=cc['d_omega_lam'].imag, simple=cc['simple'],
                                 transversal=cc['transversal'])
                k6 = cc['simple'] and cc['transversal']
                gates['K6'] = dict(status=GEC if k6 else KAL, reason=None if k6 else 'K6: P8')
    except CAUGHT as exc:
        gates['K4'] = dict(status=HSZ, reason='K4: %s' % exc)
        crit = None
    # S2 (x0 olan her uyede; omega* K4-K5 gectiyse)
    ir, ii = sysm.i_load_cur
    P = sysm.kL * (x0[b[0]] * x0[ir] + x0[b[1]] * x0[ii])
    V = math.hypot(x0[b[0]], x0[b[1]])
    w_s = crit['omega'] if (crit is not None and crit['kind'] == 'w>0') else None
    rec['S2'] = s2_probe(sysm.net, theta_b, G, P, V, w_s)
    if not rec['S2']['passed']:
        raise Abort('S2 basarisiz: %s' % spec['id'])
    if rec['S2']['NE']:
        rec['labels'].append('S2-NE')
    # K7
    if crit is not None and gates['K2']['status'] != HSZ and tab is not None:
        try:
            rec['K7'] = k7_check(sysm, x0, G, crit['rho'], tab)
            gates['K7'] = dict(status=GEC if rec['K7']['passed'] else KAL, reason=rec['K7']['reason'])
        except CAUGHT as exc:
            gates['K7'] = dict(status=HSZ, reason='K7: %s' % exc)
    # kappa (K1, K3, K4, K5, K6 gecen uyede; HDL2-B1-n)
    if (cc is not None and gates['K6']['status'] == GEC and gates['K3']['status'] == GEC
            and gates['K1']['status'] == GEC):
        try:
            kp = kappa_member(sysm, x0, G, crit, theta_b)
        except CAUGHT as exc:
            kp = None
            rec['kappa_error'] = str(exc)
        if kp is not None:
            rec['kappa'] = kp
            # HDL2b s5.6b (Delta-5): S3 ilk uye = K1-K3'u gecen ve S3'un degerlendirildigi ilk uye (davranis aynen)
            k13 = all(gates[k]['status'] == GEC for k in ('K1', 'K2', 'K3'))  # HDL2-B1-m (v2)
            if not kp['S3']['passed']:
                if k13 and not flags['s3_first_done']:
                    raise Abort('S3 ilk K1-K3 uyesinde basarisiz: %s' % spec['id'])
                rec['labels'].append('S3-NE')
            if k13:
                flags['s3_first_done'] = True
            if kp['H4']:
                rec['labels'].append('H4')
    rec['_crit'] = crit
    rec = _finish(rec)
    if rec['in_E'] and rec.get('kappa') is None:
        rec['in_E'] = False
        rec['ne_reason'] = 'kappa hesaplanamadi'
    if rec['in_E']:
        try:
            rec['HAKT'] = hakt(sysm, x0, G, rec['dGf'], crit, rec['kappa']['k_tam'])
        except CAUGHT as exc:
            rec['HAKT'] = dict(status=KAL, reason='H-AKT-hata: %s' % exc, k_fd=None)
    return rec


def _finish(rec):
    gates = rec['gates']
    bad = [k for k in GATE_ORDER if gates[k]['status'] != GEC]
    rec['in_E'] = not bad
    rec['ne_reason'] = None if not bad else (gates[bad[0]].get('reason') or '%s: %s' % (bad[0], gates[bad[0]]['status']))
    return rec


# ------------------------------------------------------------------ asama 2-4
def selection(E):
    """s5.4 (N-c): s+ = argmax kappa_L (>= tau), s- = argmin kappa_L (<= -tau); esitlikte s4.2 sirasinda ilk."""
    best_p = best_m = None
    for e in E:
        k = e['kappa']['k_L']
        if k >= TAU_K and (best_p is None or k > best_p[1]):
            best_p = (e['id'], k)
        if k <= -TAU_K and (best_m is None or k < best_m[1]):
            best_m = (e['id'], k)
    return dict(s_plus=best_p[0] if best_p else None, kappa_L_plus=best_p[1] if best_p else None,
                s_minus=best_m[0] if best_m else None, kappa_L_minus=best_m[1] if best_m else None,
                n_E=len(E), E_ids=[e['id'] for e in E], tau_kappa=TAU_K)


def ref_sign(e):
    """s4.6 (N-2, N-b): +1, -1 ya da 0 (BERABERE)."""
    rf = e['ref']
    dGf = e['dGf']
    if rf['censored']:
        if rf['dgmax_is_GR'] and e['G_R'] - dGf <= rf['tie']:
            return 0
        return 1
    diff = rf['dGt'] - dGf
    return 0 if abs(diff) <= rf['tie'] else sgn(diff)


def evaluate_tests(E, sel):
    """s5.2-5.5 alt sinamalar. E: referansi hesaplanmis uyeler."""
    T = {}
    for e in E:
        e['ref_sign'] = ref_sign(e)
        rf = e['ref']
        e['sansur_sinirda'] = bool(rf['censored'] and e['ref_sign'] == 0)
        e['d_belirsiz'] = bool(rf['censored'] and rf['dgmax_is_GR'] and e['G_R'] < (1.0 + DELTA_DEC) * e['dGf']) \
            or e['sansur_sinirda']
    by_id = {e['id']: e for e in E}

    def rule(key):
        S = [e for e in E if abs(e['kappa'][key]) >= TAU_K]
        mism = [e['id'] for e in S if e['ref_sign'] != sgn(e['kappa'][key])]
        opt = [e for e in S if e['kappa'][key] < 0]
        con = [e for e in S if e['kappa'][key] > 0]
        return dict(n=len(S), mismatches=mism,
                    n_mismatch_optimistic=sum(1 for e in opt if e['id'] in mism), n_optimistic=len(opt),
                    n_mismatch_conservative=sum(1 for e in con if e['id'] in mism), n_conservative=len(con))
    T['a_tam'] = rule('k_tam')
    T['a_L'] = rule('k_L')
    # (b')
    D = [e for e in E if abs(e['kappa']['k_V']) >= TAU_K and abs(e['kappa']['k_L']) >= TAU_K
         and sgn(e['kappa']['k_V']) != sgn(e['kappa']['k_L'])]
    if not D:
        bp = NE
    elif all(e['ref_sign'] == sgn(e['kappa']['k_L']) for e in D):
        bp = GEC
    elif all(e['ref_sign'] == sgn(e['kappa']['k_V']) for e in D):
        bp = 'YANLISLANDI'
    else:
        bp = BEL
    T['b_prime'] = dict(status=bp, D=[e['id'] for e in D])
    # (b)
    st = []
    for key in ('s_plus', 's_minus'):
        sid = sel[key]
        if sid is not None:
            e = by_id[sid]
            st.append(e['ref_sign'] == sgn(e['kappa']['k_L']))
    if sel['s_plus'] is not None and sel['s_minus'] is not None:
        bst = GEC if all(st) else KAL
    elif sel['s_plus'] is None and sel['s_minus'] is None:
        bst = 'YOK'
    elif sel['s_minus'] is None:
        bst = 'TEK-YON[-]' if all(st) else KAL
    else:
        bst = 'TEK-YON[+]' if all(st) else KAL
    T['b'] = dict(status=bst)
    # (c)
    small = [e for e in E if e['dGf'] <= SMALL_DG * e['G_R']]
    n_cens_small = sum(1 for e in small if e['ref']['censored'])
    C = [e for e in small if e['kappa']['k_tam'] < 1 and not e['ref']['censored'] and e['ref_sign'] != 0]
    impr, impr_L = [], []
    for e in C:
        t, f = e['ref']['dGt'], e['dGf']
        impr.append(abs(f / (1.0 - e['kappa']['k_tam']) - t) < abs(f - t))
        kl = e['kappa']['k_L']
        impr_L.append((abs(f / (1.0 - kl) - t) < abs(f - t)) if kl < 1 else None)
    if len(C) < 3 or n_cens_small > len(small) / 2.0:
        cst = NE
    elif all(impr):
        cst = GEC
    elif sum(impr) < len(C) / 2.0:
        cst = KAL
    else:
        cst = 'KISMI'
    T['c'] = dict(status=cst, n_C=len(C), n_small=len(small), n_censored_small=n_cens_small, n_improved=sum(impr),
                  L_report=impr_L)
    # (d)
    sat = []
    for e in E:
        if e['ref']['censored']:
            sat.append(False)
        else:
            sat.append(abs(e['ref']['dGt'] - e['dGf']) / e['dGf'] < DELTA_DEC)
    T['d'] = dict(onemsiz=bool(E) and all(sat), n_satisfied=sum(sat), d_belirsiz=[e['id'] for e in E if e['d_belirsiz']])
    # (e)
    def rate(pred_key, subset_key=None):
        S = E if subset_key is None else [e for e in E if abs(e['kappa'][subset_key]) >= TAU_K]
        if pred_key == 'rival5':
            pairs = [(e['rival5']['pred'], e['ref_sign']) for e in S if e['rival5']['ok']]
        else:
            pairs = [(sgn(e['kappa'][pred_key]), e['ref_sign']) for e in S]
        return dict(n=len(pairs), agree=sum(1 for p, q in pairs if p == q))
    T['e'] = dict(rival5_E=rate('rival5'), rival5_tam=rate('rival5', 'k_tam'), rival5_L=rate('rival5', 'k_L'),
                  S3_tam_E=rate('k_tam'), S3_tam=rate('k_tam', 'k_tam'), S3_L_E=rate('k_L'), S3_L=rate('k_L', 'k_L'),
                  second_equilibria=dict(S3=0, rival5=[dict(id=e['id'], n_steps=e['rival5']['n_steps'],
                                                            n_newton=e['rival5']['n_newton']) for e in E]),
                  note=('Rakip 5 bagimsiz bir ongorucu degil, referansin tek noktadaki degerlendirmesidir; isaret '
                        'uyusmasi pratikte kesin beklenir. S-3\'un rakip 5\'e karsi tek argumani maliyettir '
                        '(ikinci dogrusal olmayan denge sayisi 0\'a karsi 1 devamlilik). Dogrulukta ustunluk iddia '
                        'edilmez (T-4 acik kalir).'))

    # HDL2b s5 (e) yalniz-rapor alt satiri (Delta-8; HDL2b-B1-s): yalniz sayim, hukum satiri yok
    def base(subset_key=None):
        S = E if subset_key is None else [e for e in E if abs(e['kappa'][subset_key]) >= TAU_K]
        return dict(n=len(S), agree_plus=sum(1 for e in S if e['ref_sign'] == 1),
                    agree_minus=sum(1 for e in S if e['ref_sign'] == -1))

    def nset(key, side):
        S = [e for e in E if (e['kappa'][key] <= -TAU_K if side < 0 else e['kappa'][key] >= TAU_K)]
        return dict(n=len(S), agree=sum(1 for e in S if e['ref_sign'] == sgn(e['kappa'][key])),
                    ids=[e['id'] for e in S])
    T['e_taban'] = dict(sabit_E=base(), sabit_tam=base('k_tam'), sabit_L=base('k_L'),
                        N_minus_tam=nset('k_tam', -1), N_minus_L=nset('k_L', -1),
                        N_plus_tam=nset('k_tam', 1), N_plus_L=nset('k_L', 1))
    return T


def decide(n_E, n_P, hakt_kal, T):
    """HDL2b s6 satir 2-9 (satir 1 Abort ile). Satir 2: n_E < n_min ya da n_P < 2 (Delta-3, Delta-4)."""
    if n_E < N_MIN or n_P < N_P_MIN:
        return 2, 'NOT_EVALUABLE-aile', ('acik; ucuncu aile yok -> dal-kapanisi degerlendirmesi + kullanici karari '
                                         '(HDL2b s1.3)')
    if hakt_kal:
        return 3, 'H-AKT-RET', "H-DL2 degerlendirilemez; L-kappa PF-1'e aktarilamadi -> KULLANICI_BEKLIYOR"
    if T['d']['onemsiz']:
        return 4, 'H-DL2-ONEMSIZ', 'dondurulmus olcut yeterli; C-DL2 dali kapanir'
    if T['a_tam']['n'] == 0:
        return 5, 'H-DL2-ESIK-ALTI', 'kural bu ailede ongoru vermiyor; BELIRSIZ'
    if T['a_tam']['mismatches']:
        return 6, 'H-DL2-RET-kural', 'birinci mertebe kural PF-1\'de isaret vermiyor; S-3 yontem olarak duser'
    if T['a_L']['n'] == 0 or T['a_L']['mismatches']:
        return 7, 'H-DL2-RET-mekanizma', 'S-3_tam yasar; ideal-CPL anizotropi mekanizmasi isareti belirlemiyor'
    if T['b']['status'] == 'TEK-YON[-]':
        return '8a', 'H-DL2-TEK-YON[-]', 'kural tutarli; iyimser yon ailede olusmadi'
    if T['b']['status'] == 'TEK-YON[+]':
        return '8b', 'H-DL2-TEK-YON[+]', 'kural tutarli; muhafazakar yon ailede olusmadi'
    return 9, 'H-DL2-TUTARLI', '(a), (b) gecti; alt etiketler raporlanir (E2; yorum siniri s6)'


def run_family(specs, build_member, write_secim, log, events):
    """Asama 1-4. build_member(spec) -> (sysm ya da None, dispatch kaydi). Abort firlatabilir."""
    s5 = s5_probe()
    log('S5: %s' % ('GECTI' if s5['passed'] else 'KALDI'))
    if not s5['passed']:
        raise Abort('S5 basarisiz')
    flags = dict(s1_first_done=False, s3_first_done=False)
    recs, systems = [], {}
    events.append('asama1')
    for spec in specs:
        sysm, disp = build_member(spec)
        rec = stage1_member(spec, sysm, disp, flags)
        systems[spec['id']] = sysm
        recs.append(rec)
        log('%s: %s%s' % (spec['id'], 'E' if rec['in_E'] else 'NE-x0',
                          '' if rec['in_E'] else ' (%s)' % rec['ne_reason']))
    E = [r for r in recs if r['in_E']]
    hakt_kal = [e['id'] for e in E if e['HAKT']['status'] != GEC]
    n_P = len(set(e['P_akt'] for e in E))  # HDL2b s4.3b (Delta-3)
    R = dict(S5=s5, n_E=len(E), n_P=n_P, hakt_kal=hakt_kal, selection=None, secim_sha256=None, tests=None)
    if len(E) >= N_MIN and n_P >= N_P_MIN and not hakt_kal:
        sel = selection(E)
        R['selection'] = sel
        R['secim_sha256'] = write_secim(sel)
        events.append('secim')
        log('secim.json sha256: %s' % R['secim_sha256'])
        events.append('asama3')
        for e in E:
            sysm = systems[e['id']]
            e['ref'] = reference(sysm, e['_x0'], e['G_R'], e['dGf'], e['_crit'])
            e['rival5'] = rival5(sysm, e['_x0'], e['G_R'], e['dGf'])
            events.append('ref:' + e['id'])
        R['tests'] = evaluate_tests(E, sel)
    row, verdict, outcome = decide(len(E), n_P, hakt_kal, R['tests'])
    events.append('karar')
    R.update(decision_row=row, verdict=verdict, outcome=outcome, members=recs,
             label_counts=label_counts(recs))
    return R


def label_counts(recs):
    out = {}
    for r in recs:
        labs = list(r.get('labels', []))
        if r.get('ref'):
            labs += [k for k, v in r['ref']['labels'].items() if v not in (None, False)]
            if r['ref']['censored']:
                labs.append('sansurlu')
        if r.get('d_belirsiz'):
            labs.append('d-belirsiz')
        if r.get('K7') and r['K7']['reason'] == 'K7-cozunurluk':
            labs.append('K7-cozunurluk')
        for lb in labs:
            key = lb.split(':')[0]
            out[key] = out.get(key, 0) + 1
    return out


# ------------------------------------------------------------------ gercek kip (s7)
def evaluate(root, pins, write_secim, log, events):
    """Pin dogrulama + model + asama 1-4. Abort firlatabilir (s6 satir 1). Doner: (pin_rows, sonuc)."""
    pin_rows = verify_pins(root, pins)
    mods = import_models(root)
    EC = mods['e1_core']
    cache = {}

    def build_member(spec):
        code = spec['setting']
        if code not in cache:
            model = make_model(mods, code)
            cache.clear()
            cache[code] = (model, EC.Dispatcher(model))
        model, disp = cache[code]
        rec = dispatch_HDL2(EC, model, disp, spec['P_akt'], spec['G_R'])
        if not rec['ok']:
            return None, rec
        return RealSystem(mods, model, rec['rho']), rec
    specs = family_specs()
    if len(specs) != N_FAMILY:
        raise Abort('aile buyuklugu %d (beklenen %d)' % (len(specs), N_FAMILY))
    R = run_family(specs, build_member, write_secim, log, events)
    rehash_pins(root, pins, REHASH_PINS)
    return pin_rows, R


def verify_authorization(root, yetki_path, run_id, pins, script_path):
    """Yetki dosyasini dogrular; uyusmazlikta ValueError. Hicbir model import edilmez."""
    if not RUN_ID_RE.match(run_id):
        raise ValueError('run_id bicimi gecersiz')
    expect = os.path.normcase(os.path.abspath(os.path.join(root, 'cdl1', 'HDL2b_yetki_%s.json' % run_id)))
    if os.path.normcase(os.path.abspath(yetki_path)) != expect:
        raise ValueError('yetki dosyasi yolu cdl1/HDL2b_yetki_<run_id>.json degil')
    if not os.path.isfile(yetki_path):
        raise ValueError('yetki dosyasi yok')
    try:
        y = json.loads(_read_bytes(yetki_path).decode('utf-8'))
    except (UnicodeDecodeError, ValueError):
        raise ValueError('yetki dosyasi JSON degil')
    if not isinstance(y, dict):
        raise ValueError('yetki dosyasi sozluk degil')
    if y.get('action') != 'ALLOW_HDL2B_RUN':
        raise ValueError('action != ALLOW_HDL2B_RUN')
    if y.get('run_id') != run_id:
        raise ValueError('run_id uyusmuyor')
    sabit = pin_path(root, SABIT_REL)
    if not os.path.isfile(sabit) or sha256_hex(_read_bytes(sabit)) != SABIT_SHA256:
        raise ValueError('SABIT dosyasi hash uyusmuyor')
    if y.get('sabit_sha256') != SABIT_SHA256:
        raise ValueError('yetki.sabit_sha256 uyusmuyor')
    scripts = y.get('script_sha256')
    if not isinstance(scripts, dict) or scripts.get('hdl2b_run.py') != sha256_hex(_read_bytes(script_path)):
        raise ValueError('yetki.script_sha256[hdl2b_run.py] uyusmuyor')
    if y.get('pin_list_sha256') != pin_list_sha256(pins):
        raise ValueError('yetki.pin_list_sha256 uyusmuyor')
    rep = y.get('code_audit_report')
    if not isinstance(rep, dict) or not isinstance(rep.get('path'), str) or not isinstance(rep.get('sha256'), str):
        raise ValueError('yetki.code_audit_report eksik')
    rp = pin_path(root, rep['path'])
    if not os.path.isfile(rp) or sha256_hex(_read_bytes(rp)) != rep['sha256']:
        raise ValueError('kod denetimi raporu hash uyusmuyor')
    return y


def check_only(root, pins, log):
    """SABIT hash + pinler. Model import edilmez; hesap yapilmaz."""
    sabit = pin_path(root, SABIT_REL)
    ok_sabit = os.path.isfile(sabit) and sha256_hex(_read_bytes(sabit)) == SABIT_SHA256
    log('SABIT hash: %s' % ('OK' if ok_sabit else 'UYUSMUYOR'))
    if not ok_sabit:
        return 2
    try:
        rows = verify_pins(root, pins)
    except Abort as e:
        log('PIN: ABORT - %s' % e)
        return 2
    log('PIN: %d/%d OK' % (len(rows), len(pins)))
    log('pin_list_sha256: %s' % pin_list_sha256(pins))
    return 0


# ------------------------------------------------------------------ cikti
def _jsonable(v):
    if isinstance(v, dict):
        return {str(k): _jsonable(x) for k, x in v.items() if not str(k).startswith('_')}
    if isinstance(v, (list, tuple)):
        return [_jsonable(x) for x in v]
    if isinstance(v, (np.floating, np.integer)):
        v = v.item()  # v2 N-2: once Python skalerine, sonra asagidaki sonluluk denetimi
    if isinstance(v, np.bool_):
        return bool(v)
    if isinstance(v, np.ndarray):
        return _jsonable(v.tolist())
    if isinstance(v, complex):
        return [v.real, v.imag]
    if isinstance(v, float) and not math.isfinite(v):
        return repr(v)
    return v


CSV_COLS = ('id', 'setting', 'P_akt', 'G_R', 'onceki_aile_uyesi', 'in_E',
             'ne_reason', 'rho', 'residual', 'L1', 'L1_status', 'L1_margin',
            'L2', 'L2_status', 'L2_margin', 'L3_V101', 'L3_V102', 'L3_status', 'L3_margin', 'L4', 'L4_status',
            'L4_margin', 'L5', 'L5_status', 'L5_margin', 'L6', 'L6_status', 'alpha', 'alpha_tab', 'cond_J', 'dGf',
            'omega_star', 'crit_kind', 'K7_ratio_lo', 'K7_ratio_hi', 'dGf_ss', 'c', 'Re_eta', 'Im_eta', 'pi_d',
            'pi_x', 'xi_d', 'xi_q', 'P', 'V', 'kL', 'k_tam', 'k_V', 'k_theta', 'k_L', 'k_Delta', 'k_K', 'k_x1', 'k_x2',
            'S3_passed', 'd_dominant', 'H4', 'rest', 'HAKT', 'k_fd', 'dGt', 'censored', 'loss', 'dGt_port',
            'ref_sign', 'F5', 'rival5_pred', 'labels')


def csv_row(r):
    row = {k: r.get(k) for k in ('id', 'setting', 'P_akt', 'G_R', 'onceki_aile_uyesi', 'in_E', 'ne_reason',
                                  'residual', 'alpha',
                                  'alpha_tab', 'cond_J', 'dGf', 'omega_star', 'crit_kind', 'ref_sign')}
    row['rho'] = json.dumps(r.get('rho'))
    lim, mg = r.get('limits') or {}, r.get('margins') or {}
    for k in ('L1', 'L2', 'L4', 'L5', 'L6'):
        if k in lim:
            row[k], row[k + '_status'] = lim[k].get('value'), lim[k]['status']
    if 'L3' in lim:
        row.update(L3_V101=lim['L3'].get('V_101'), L3_V102=lim['L3'].get('V_102'), L3_status=lim['L3']['status'])
    for k in LIM_KEYS:
        row[k + '_margin'] = mg.get(k)
    k7 = r.get('K7') or {}
    row.update(K7_ratio_lo=k7.get('ratio_lo'), K7_ratio_hi=k7.get('ratio_hi'), dGf_ss=k7.get('dGf_ss'))
    kp = r.get('kappa')
    if kp:
        row.update(c=kp['c'], Re_eta=kp['eta'].real, Im_eta=kp['eta'].imag, pi_d=json.dumps(_jsonable(kp['pi_d'])),
                   pi_x=json.dumps(_jsonable(kp['pi_x'])), S3_passed=kp['S3']['passed'])
        for k in ('xi_d', 'xi_q', 'P', 'V', 'kL', 'k_tam', 'k_V', 'k_theta', 'k_L', 'k_Delta', 'k_K', 'k_x1', 'k_x2',
                  'd_dominant', 'H4', 'rest'):
            row[k] = kp[k]
    if r.get('HAKT'):
        row.update(HAKT=r['HAKT']['status'], k_fd=r['HAKT'].get('k_fd'))
    if r.get('ref'):
        row.update(dGt=r['ref']['dGt'], censored=r['ref']['censored'], loss=r['ref']['loss'],
                   dGt_port=r['ref']['dGt_port'])
    if r.get('rival5'):
        row.update(F5=r['rival5']['F5'], rival5_pred=r['rival5']['pred'])
    row['labels'] = ';'.join(r.get('labels', []))
    return row


def members_csv(recs):
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=CSV_COLS, lineterminator='\n')
    w.writeheader()
    for r in recs:
        w.writerow({k: ('' if v is None else v) for k, v in csv_row(r).items()})
    return buf.getvalue()


def write_outputs(out_dir, pin_rows, result, verdict_line, log_lines, exit_code, stderr_text):
    _write_text(os.path.join(out_dir, 'girdi_pinleri.json'), json.dumps(pin_rows, indent=1, ensure_ascii=False))
    _write_text(os.path.join(out_dir, 'sonuc.json'), json.dumps(_jsonable(result), indent=1, ensure_ascii=False))
    _write_text(os.path.join(out_dir, 'uyeler.csv'), members_csv(result.get('members') or []))
    _write_text(os.path.join(out_dir, 'hukum.txt'), verdict_line + '\n')
    _write_text(os.path.join(out_dir, 'stdout.txt'), '\n'.join(log_lines) + '\n')
    _write_text(os.path.join(out_dir, 'stderr.txt'), stderr_text)
    _write_text(os.path.join(out_dir, 'exit_code.txt'), '%d\n' % exit_code)
    names = sorted(n for n in os.listdir(out_dir) if n != 'SHA256SUMS')
    _write_text(os.path.join(out_dir, 'SHA256SUMS'),
                ''.join('%s  %s\n' % (sha256_hex(_read_bytes(os.path.join(out_dir, n))), n) for n in names))


def verdict_line(result):
    return 'H-DL2 hukmu: %s (karar tablosu satir %s; %s)' % (result['verdict'], result['decision_row'],
                                                             result['outcome'])


def default_root():
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def main(argv=None, root=None, pins=None, script_path=None):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except (AttributeError, ValueError):
        pass
    root = root or default_root()
    pins = pins or PINS
    script_path = script_path or os.path.abspath(__file__)
    ap = argparse.ArgumentParser(description='C-DL2 H-DL2 tek kosu betigi')
    ap.add_argument('--check-only', action='store_true')
    ap.add_argument('--run-id')
    ap.add_argument('--yetki')
    a = ap.parse_args(argv)
    lines = []

    def log(s):
        lines.append(s)
        print(s, flush=True)

    if a.check_only:
        if a.run_id or a.yetki:
            log('KAPI: --check-only ile --run-id/--yetki birlikte verilemez')
            return 3
        return check_only(root, pins, log)
    if not (a.run_id and a.yetki):
        log('KAPI: gercek kip --run-id ve --yetki ister; calismadi')
        return 3
    try:
        verify_authorization(root, a.yetki, a.run_id, pins, script_path)
    except ValueError as e:
        log('KAPI: yetki reddedildi - %s' % e)
        return 3
    out_dir = os.path.join(root, 'cdl1', 'out', a.run_id)
    if os.path.exists(out_dir):
        log('KAPI: %s zaten var; yeniden kosu yok' % out_dir)
        return 3
    os.makedirs(out_dir)
    log('run_id: %s' % a.run_id)
    log('yetki: OK')
    events = []

    def write_secim(sel):
        text = json.dumps(_jsonable(sel), indent=1, ensure_ascii=False)
        _write_text(os.path.join(out_dir, 'secim.json'), text)
        return sha256_hex(_read_bytes(os.path.join(out_dir, 'secim.json')))
    pin_rows, result, err = [], {}, ''
    try:
        pin_rows, result = evaluate(root, pins, write_secim, log, events)
        code = 0
        line = verdict_line(result)
    except Abort as e:
        code, line = 2, 'H-DL2 hukmu: ABORT (karar tablosu satir 1; degismez; yeniden kosu yok) - %s' % e
        result = dict(verdict='ABORT', decision_row=1, abort_reason=str(e))
    except Exception:
        code, line = 1, 'BEKLENMEYEN HATA (hukum yok)'
        err = traceback.format_exc()
        result = dict(verdict=None, error='beklenmeyen hata; stderr.txt')
        sys.stderr.write(err)
    result['events'] = events
    log(line)
    write_outputs(out_dir, pin_rows, result, line, lines, code, err)
    return code


if __name__ == '__main__':
    sys.exit(main())
