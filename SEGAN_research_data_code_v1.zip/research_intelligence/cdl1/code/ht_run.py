"""C-DL1 / H-T yurutme betigi (salt-okuma, yalniz standart kutuphane).

Dayanak: cdl1/CDL1_HT_On_Kayit_v1.0_SABIT.md (sha256 SABIT_SHA256 asagida).
Tarih: 2026-10-15 (adim B1). Bu betik B3 kod denetiminden
(yazar != denetci) ve HT_yetki_<run_id>.json dosyasindan once gercek modda calismaz.

Kipler
  --check-only            SABIT hash'i + 15 pin (boyut, sha256) + korlenmemis dosyalarda alan
                          denetimi. Korlenmis S dosyalari (S_state.csv, S_V5_admittance.csv,
                          S_point.json) yalniz bayt olarak hash'lenir; AYRISTIRILMAZ, deger
                          yazdirilmaz. Cikti klasoru yazilmaz.
  --run-id ID --yetki P   Tek gercek kosu. Yetki dosyasi (SABIT s8) dogrulanmadan hicbir girdi
                          ayristirilmaz. cdl1/out/<ID>/ zaten varsa kosu reddedilir (yeniden kosu yok).

Cikis kodlari: 0 = hukum uretildi; 2 = ABORT (SABIT s6 satir 1); 3 = kapi reddi
(yetki/kip/klasor); 1 = beklenmeyen hata (stderr.txt'ye yazilir).

Onceden sabit uygulama secimleri (SABIT'in acik birakti; B3 denetler):
  K-3.1  SINIRDA olcegi: karsilastirilan nicelik X noktasina aitse 1e-9*max(1, c*_X);
         T1/T3b'deki q_T - q_S farki icin 1e-9*max(1, c*_T, c*_S). c*_X tanimsizsa (T2
         NOT_EVALUABLE) c*_X yerine 1 kullanilir. Bayrak yalniz rapordur.
  B1-a   s4.1 'alan eksik/sonlu degil/tip yanlis -> ABORT' kurali; s4.1 son madde ve s4.2a
         istisnasi: S.fyu.lam / S.fyu.f_Hz ya da X.descriptive.a_DC_CPL_pair yoksa (ya da
         JSON null ise) NOT_EVALUABLE; varsa ama tipi/sonlulugu bozuksa ABORT.
  B1-b   G_R: sayi tipinde degilse ABORT (s4.1). T icin tam 0.25 degilse ABORT (s4.2).
         S icin sonlu degil ya da < 0 ise NOT_EVALUABLE (s4.9, s6 satir 2).
  B1-c   c = P_L/|V|^2; |V|^2 = 0, P_L <= 0 ya da c* <= 0 ise T2 NOT_EVALUABLE (s4.6).
  B1-d   f_c disarida kurali kayitli izgaranin [f_min, f_max] araligina gore uygulanir
         (s4.2'de f_min=0.1, f_max=1000 beklenir); f_c <= 0 disarida sayilir.
  B1-e   T3b esleme: (alt_T, alt_S) ve (ust_T, ust_S); ayni satir ciftleri tekillestirilir.
  B1-f   Karar tablosu satir 2 tetiklense de hesaplanabilen sinamalar raporlanir (K-3.3).
  B1-g   e_min/e_max ayrica c ile raporlanir (K-3.2: 'c* yerine c ile'); c <= 0 ise yazilmaz.
  B1-h   s7'deki 'csv, json, hashlib, math, ast' listesine ek olarak yalniz G/C ve kapi icin
         standart kutuphaneden argparse, io, os, re, sys, traceback kullanilir (hesaba girmez).
         ht_static_check.py izin listesini bu 11 modulle sinirlar.
"""
import argparse
import ast
import csv
import hashlib
import io
import json
import math
import os
import re
import sys
import traceback

ETA_ALPHA = 1e-2            # E1-K SABIT:164
G_R_T_EXPECTED = 0.25       # E1-K SABIT:154
T2_TOL = 0.10               # SABIT s5.1
T2_REPORT_TOLS = (0.05, 0.20)
F0 = 0.1                    # SABIT s4.8
F0_RTOL = 1e-12
V5_ROWS = 200               # e1_core.py:36
SINIRDA_K = 1e-9            # SABIT s5.1 (R2-2), K-3.1

SABIT_REL = 'cdl1/CDL1_HT_On_Kayit_v1.0_SABIT.md'
SABIT_SHA256 = '3adc9f2b024897d386b3f074ba14f6fee5f44f07d43a7502fc4f3dd6b3543b91'

_PTS = 'e1_k/out/SETTINGS_20261012_a/settings/S3/points/'
# SABIT s3 pin tablosu (K-2.1 tam yollar). Sira, bayt, sha256 aynen.
PINS = [
    (1, 'e1_k/out/SETTINGS_20261012_a/settings/S3_kayit.json', 9678,
     '552424241767dfa42573b4dfe1c9629d2dcfedadd810132ac93a3d87dfcdb0c8'),
    (2, _PTS + 'T_point.json', 8793, 'f65b5e8d29e83ec04b30f1d4b7cb3096a79faff34ce16a02f6189b99badc7558'),
    (3, _PTS + 'S_point.json', 8442, 'd893c0922757b5a905fa189ded3a9a7a53c60369e0c16a3cacd00778eb3d5c86'),
    (4, _PTS + 'T_state.csv', 3468, '2d28f35a835207613bf62c22c4f3bc5f074c5e18ec39b03ec7f16393c92d4db4'),
    (5, _PTS + 'S_state.csv', 3573, 'af5e52ed01a29158c1991bb659a0d9e70742d151df0f9b67a61acb58c02553e7'),
    (6, _PTS + 'T_V5_admittance.csv', 48265, 'b13b952f2c12f85718135f3dd481fe2b4189ed1e18cf47180e757815204f0c48'),
    (7, _PTS + 'S_V5_admittance.csv', 48501, 'd6fe815903f268202cee29ca796f4ba0abeac0e96d5154112705316266cc7ca2'),
    (8, _PTS + 'T_eigs.csv', 6882, '05b7d05f2e7eee678396ad7ce457088c1b38470731fcb3af26d27eb738b79ec7'),
    (9, _PTS + 'S_eigs.csv', 6912, 'eee3939ef99bb3630c9dcc4d862b6ee97f3500d8421147938e9cd8879b2c5253'),
    (10, 'e1_k/code/e1k_model.py', 9383, 'd4e6392ca50337134e8602f9f129109a3aa156fa86591b29f9875bf30c5e7d78'),
    (11, 'e1_m-e1-0/code/e1_core.py', 37783, 'f1b9191cb05a2b4e08ffaba1ac4a44e3e9b50a21040055e96fe7b3f72fb34819'),
    (12, 'r_ha_b/code/rhab_model.py', 16913, 'db9dd3fdf510a21606a25060e423421dec977ce29dfd4fcadffb38eb9e1c9825'),
    (13, 'cdl1/CDL1_E1_analitik_not_v0.2.md', 14214,
     '17d3344162b25c825a3ccede84e080040c3c1852ea1f74ba71b1f14392ff926b'),
    (14, 'e1_k/sabit/PF1_E1K_On_Kayit_v1.0_SABIT.md', 23857,
     'cb924a2f415021e2d354eaead2a0e854d2072f700b2123d01d9aff1e6dfdeb96'),
    (15, 'e1_k/cb/E1KCB_rapor.md', 4558, 'df125ef0f3eb0321eab5d402546573cb2f1b9d097a81d7a0cb8671ace9a3cad2'),
]
# Hesaba giren pinler (numara -> rol). 8, 9, 10, 11, 13, 14, 15 yalniz pin.
ROLE = {1: 'kayit', 2: 'T_point', 3: 'S_point', 4: 'T_state', 5: 'S_state', 6: 'T_V5', 7: 'S_V5', 12: 'rhab'}
BLINDED_ROLES = ('S_point', 'S_state', 'S_V5')
STATE_ROWS = ('V_2:R', 'V_2:I', 'load1021:ir_filter', 'load1021:ii_filter')
RHO_FIELDS = ('P_ref', 'Q_ref', 'V_ref', 'V_ref_dc', 'Iq_ref')
RUN_ID_RE = re.compile(r'^HT_\d{8}_[a-z]$')

PARSED_PATHS = []           # sentetik test: hangi dosyalarin ayristirildigi


class Abort(Exception):
    """SABIT s6 satir 1."""


# ------------------------------------------------------------------ dosya erisimi (tek nokta)
def _read_bytes(path):
    with open(path, 'rb') as fh:
        return fh.read()


def _write_text(path, text):
    with open(path, 'w', encoding='utf-8', newline='\n') as fh:
        fh.write(text)


def sha256_hex(data):
    return hashlib.sha256(data).hexdigest()


def pin_list_sha256(pins):
    """Yetki dosyasindaki 'pin listesi hash'i': 'no<TAB>yol<TAB>bayt<TAB>sha' satirlari, LF ile."""
    text = ''.join('%d\t%s\t%d\t%s\n' % p for p in pins)
    return sha256_hex(text.encode('utf-8'))


def verify_pins(root, pins):
    """Tum pinleri bayt + sha256 ile dogrular; tek uyusmazlik ABORT. Icerik ayristirilmaz."""
    blobs, rows = {}, []
    for no, rel, size, sha in pins:
        path = os.path.join(root, *rel.split('/'))
        if not os.path.isfile(path):
            raise Abort('pin %d yok: %s' % (no, rel))
        data = _read_bytes(path)
        got = sha256_hex(data)
        rows.append(dict(no=no, path=rel, bytes_expected=size, bytes=len(data), sha256_expected=sha, sha256=got))
        if len(data) != size or got != sha:
            raise Abort('pin %d uyusmuyor: %s (bayt %d/%d)' % (no, rel, len(data), size))
        blobs[no] = data
    return blobs, rows


# ------------------------------------------------------------------ ayristiricilar (ABORT kurallari)
def _num(x, what):
    if isinstance(x, bool) or not isinstance(x, (int, float)):
        raise Abort('%s sayi degil' % what)
    x = float(x)
    if not math.isfinite(x):
        raise Abort('%s sonlu degil' % what)
    return x


def _get(d, keys, what):
    cur = d
    for k in keys:
        if not isinstance(cur, dict) or k not in cur:
            raise Abort('%s eksik' % what)
        cur = cur[k]
    return cur


def _opt(d, keys):
    """Alan yoksa ya da null ise None (s4.1 son madde / s4.2a istisnasi)."""
    cur = d
    for k in keys:
        if not isinstance(cur, dict) or k not in cur or cur[k] is None:
            return None
        cur = cur[k]
    return cur


def _lam_pair(x, what):
    if not isinstance(x, list) or len(x) != 2:
        raise Abort('%s 2 elemanli liste degil' % what)
    return [_num(x[0], what + '[0]'), _num(x[1], what + '[1]')]


def parse_json(data, label):
    PARSED_PATHS.append(label)
    try:
        return json.loads(data.decode('utf-8'))
    except (UnicodeDecodeError, ValueError) as e:
        raise Abort('%s JSON okunamadi: %s' % (label, e))


def _csv_rows(data, label, cols):
    PARSED_PATHS.append(label)
    try:
        text = data.decode('utf-8-sig')
    except UnicodeDecodeError as e:
        raise Abort('%s UTF-8 degil: %s' % (label, e))
    rd = csv.DictReader(io.StringIO(text))
    if rd.fieldnames is None or any(c not in rd.fieldnames for c in cols):
        raise Abort('%s sutun eksik (%s)' % (label, ','.join(cols)))
    return list(rd)


def parse_state(data, label):
    rows = _csv_rows(data, label, ('state', 'x_equilibrium'))
    out = {}
    for name in STATE_ROWS:
        hit = [r for r in rows if r['state'] == name]
        if len(hit) != 1:
            raise Abort('%s: %s satiri %d kez' % (label, name, len(hit)))
        try:
            v = float(hit[0]['x_equilibrium'])
        except (TypeError, ValueError):
            raise Abort('%s: %s sayi degil' % (label, name))
        if not math.isfinite(v):
            raise Abort('%s: %s sonlu degil' % (label, name))
        out[name] = v
    return out


def parse_v5(data, label):
    rows = _csv_rows(data, label, ('f_Hz', 'lam_min_H', 'lam_max_H'))
    if len(rows) != V5_ROWS:
        raise Abort('%s: %d satir (beklenen %d)' % (label, len(rows), V5_ROWS))
    f, lmin, lmax = [], [], []
    for i, r in enumerate(rows):
        try:
            a, b, c = float(r['f_Hz']), float(r['lam_min_H']), float(r['lam_max_H'])
        except (TypeError, ValueError):
            raise Abort('%s satir %d sayi degil' % (label, i))
        if not (math.isfinite(a) and math.isfinite(b) and math.isfinite(c)):
            raise Abort('%s satir %d sonlu degil' % (label, i))
        f.append(a)
        lmin.append(b)
        lmax.append(c)
    for i in range(1, len(f)):
        if not f[i] > f[i - 1]:
            raise Abort('%s: f_Hz kesin artan degil (satir %d)' % (label, i))
    return dict(f=f, lmin=lmin, lmax=lmax)


def parse_point(obj, label):
    g_r = _num(_get(obj, ('G_R',), label + '.G_R'), label + '.G_R')
    rho = _get(obj, ('rho',), label + '.rho')
    if not isinstance(rho, dict):
        raise Abort('%s.rho sozluk degil' % label)
    rho = {k: _num(_get(rho, (k,), label + '.rho.' + k), label + '.rho.' + k) for k in RHO_FIELDS}
    alpha = _num(_get(obj, ('alpha',), label + '.alpha'), label + '.alpha')     # ust duzey (K-2.2)
    return dict(G_R=g_r, rho=rho, alpha=alpha)


def parse_kayit(obj):
    out = {}
    for X in ('T', 'S'):
        out[X + '_alpha'] = _num(_get(obj, (X, 'alpha'), X + '.alpha'), 'kayit.' + X + '.alpha')
        a = _opt(obj, (X, 'descriptive', 'a_DC_CPL_pair'))
        if a is None:
            out[X + '_aDC'] = None
        else:
            out[X + '_aDC'] = dict(lam=_lam_pair(_get(a, ('lam',), X + '.aDC.lam'), X + '.aDC.lam'),
                                   f_Hz=_num(_get(a, ('f_Hz',), X + '.aDC.f_Hz'), X + '.aDC.f_Hz'))
    lam, fz = _opt(obj, ('S', 'fyu', 'lam')), _opt(obj, ('S', 'fyu', 'f_Hz'))
    out['S_fyu'] = None if (lam is None or fz is None) else dict(
        lam=_lam_pair(lam, 'S.fyu.lam'), f_Hz=_num(fz, 'S.fyu.f_Hz'))
    return out


def read_kL(data):
    """s4.5: rhab_model.py ast.parse ile; import edilmez. Doner: (kL ya da None, aciklama)."""
    PARSED_PATHS.append('rhab')
    try:
        tree = ast.parse(data.decode('utf-8'))
    except (SyntaxError, UnicodeDecodeError) as e:
        return None, 'ayristirilamadi: %s' % e
    funcs = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'parameters']
    if len(funcs) != 1:
        return None, 'parameters() sayisi %d' % len(funcs)

    def kw(var, key):
        hits = []
        for n in ast.walk(funcs[0]):
            if (isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name)
                    and n.targets[0].id == var and isinstance(n.value, ast.Call)
                    and isinstance(n.value.func, ast.Name) and n.value.func.id == 'dict'):
                hits += [k.value for k in n.value.keywords if k.arg == key]
        if len(hits) != 1:
            return None, '%s.%s eslesme sayisi %d' % (var, key, len(hits))
        v = hits[0]
        if not (isinstance(v, ast.Constant) and isinstance(v.value, (int, float))
                and not isinstance(v.value, bool)):
            return None, '%s.%s sayisal literal degil' % (var, key)
        return float(v.value), 'ok'

    bp, m1 = kw('load', 'base_power')
    sb, m2 = kw('net', 'Sbase')
    if bp is None or sb is None:
        return None, m1 if bp is None else m2
    if sb == 0:
        return None, 'Sbase = 0'
    kL = bp / sb
    if not (math.isfinite(kL) and kL > 0):
        return None, 'kL <= 0 ya da sonlu degil'
    return kL, 'base_power=%r Sbase=%r' % (bp, sb)


# ------------------------------------------------------------------ yardimci hesaplar
def f0_index(f, label):
    hit = [i for i, x in enumerate(f) if abs(x / F0 - 1.0) <= F0_RTOL]
    if len(hit) != 1:
        raise Abort('%s: f0 satiri %d adet' % (label, len(hit)))
    return hit[0]


def select_rows(f, fc):
    """s4.8: en yakin satir (log-uzaklik; esitlikte dusuk f) ve cevreleyen satirlar.
    Doner: None (izgara disi) ya da dict(nearest, lo, hi)."""
    if not (fc > 0) or fc < f[0] or fc > f[-1]:
        return None
    lf = math.log(fc)
    best = 0
    for i in range(1, len(f)):
        if abs(math.log(f[i]) - lf) < abs(math.log(f[best]) - lf):   # kesin kucuk: esitlikte dusuk kalir
            best = i
    lo = max(i for i in range(len(f)) if f[i] <= fc)
    hi = min(i for i in range(len(f)) if f[i] >= fc)
    return dict(nearest=best, lo=lo, hi=hi)


def load_ref(st, rho):
    """s4.4, s4.6."""
    Vr, Vi = st['V_2:R'], st['V_2:I']
    Ir, Ii = st['load1021:ir_filter'], st['load1021:ii_filter']
    V2 = Vr * Vr + Vi * Vi
    PL = Vr * Ir + Vi * Ii
    Iq = rho['Iq_ref']
    out = dict(V_r=Vr, V_i=Vi, I_r=Ir, I_i=Ii, V_abs2=V2, P_L=PL, I_q=Iq, c=None, c_star=None)
    if V2 > 0:
        Vabs = math.sqrt(V2)
        out['c'] = PL / V2
        out['c_star'] = math.sqrt(out['c'] ** 2 + (Iq / (2.0 * Vabs)) ** 2)
    out['ok'] = bool(V2 > 0 and PL > 0 and out['c_star'] is not None and out['c_star'] > 0)
    return out


def sinirda(value, scale):
    return abs(value) <= SINIRDA_K * max(1.0, scale)


# ------------------------------------------------------------------ cekirdek degerlendirme
def evaluate(root, pins):
    """Pin dogrulama + s4 tanimlari + s5 sinamalari + s6 karar tablosu.
    Abort firlatabilir (s6 satir 1). Doner: (pin_rows, sonuc sozlugu)."""
    blobs, pin_rows = verify_pins(root, pins)
    by_role = {ROLE[no]: blobs[no] for no in blobs if no in ROLE}

    # --- s4.1-4.2: ayristirma + capraz denetim (hepsi ABORT; NOT_EVALUABLE'dan once)
    kay = parse_kayit(parse_json(by_role['kayit'], 'kayit'))
    P = {X: parse_point(parse_json(by_role[X + '_point'], X + '_point'), X + '_point') for X in ('T', 'S')}
    ST = {X: parse_state(by_role[X + '_state'], X + '_state') for X in ('T', 'S')}
    V5 = {X: parse_v5(by_role[X + '_V5'], X + '_V5') for X in ('T', 'S')}
    for X in ('T', 'S'):
        if kay[X + '_alpha'] != P[X]['alpha']:
            raise Abort('alpha capraz denetimi: kayit.%s.alpha != %s_point.alpha' % (X, X))
    if P['T']['G_R'] != G_R_T_EXPECTED:
        raise Abort('T_point.G_R != 0.25')
    i0 = {X: f0_index(V5[X]['f'], X + '_V5') for X in ('T', 'S')}

    R = dict(not_evaluable_reasons=[], sinirda=[], tests={}, report={}, values={})
    ne = R['not_evaluable_reasons']
    vals = R['values']

    # --- s4.5 kL
    kL, kL_note = read_kL(by_role['rhab'])
    vals['kL'] = kL
    vals['kL_note'] = kL_note
    if kL is None:
        ne.append('kL okunamiyor (%s)' % kL_note)

    # --- s4.3 siniflar
    aT, aS = P['T']['alpha'], P['S']['alpha']
    vals.update(alpha_T=aT, alpha_S=aS, eta_alpha=ETA_ALPHA)
    if not (aT <= -ETA_ALPHA and aS >= ETA_ALPHA):
        ne.append('sinif on kabulu tutmuyor (T kararli: %s, S kararsiz: %s)' % (aT <= -ETA_ALPHA, aS >= ETA_ALPHA))

    # --- s4.9 G_R
    gT, gS = P['T']['G_R'], P['S']['G_R']
    vals.update(G_R_T=gT, G_R_S=gS)
    gS_ok = math.isfinite(gS) and gS >= 0
    if not gS_ok:
        ne.append('G_R,S gecersiz')

    # --- s4.6 yuk referansi
    LR = {X: load_ref(ST[X], P[X]['rho']) for X in ('T', 'S')}
    vals['load_ref'] = LR
    cs = {X: (LR[X]['c_star'] if LR[X]['ok'] else None) for X in ('T', 'S')}
    sc = {X: (cs[X] if cs[X] is not None else 1.0) for X in ('T', 'S')}      # K-3.1
    sc_TS = max(sc['T'], sc['S'])

    def flag(name, value, scale):
        if sinirda(value, scale):
            R['sinirda'].append(dict(compare=name, value=value, threshold=SINIRDA_K * max(1.0, scale)))

    # --- f0 satirlari
    for X in ('T', 'S'):
        i = i0[X]
        vals['f0_' + X] = dict(row=i, f_Hz=V5[X]['f'][i], lam_min_H=V5[X]['lmin'][i], lam_max_H=V5[X]['lmax'][i],
                               next2=[dict(row=j, f_Hz=V5[X]['f'][j], lam_min_H=V5[X]['lmin'][j],
                                           lam_max_H=V5[X]['lmax'][j])
                                      for j in range(i + 1, min(i + 3, len(V5[X]['f'])))])

    def q(X, i):
        return gX[X] + kL * V5[X]['lmin'][i]
    gX = dict(T=gT, S=gS)
    can_q = kL is not None and gS_ok

    # --- T1
    if can_q:
        qT0, qS0 = q('T', i0['T']), q('S', i0['S'])
        vals.update(q_T_f0=qT0, q_S_f0=qS0, Gamma0_open_lower=-qT0, Gamma0_closed_upper=-qS0)
        R['tests']['T1'] = 'GEC' if (qS0 <= 0 and qT0 > qS0) else 'KAL'
        flag('T1: q_S(f0) <= 0', qS0, sc['S'])
        flag('T1: q_T(f0) - q_S(f0) > 0', qT0 - qS0, sc_TS)
    else:
        R['tests']['T1'] = 'HESAPLANAMADI'

    # --- T2
    if LR['T']['ok'] and LR['S']['ok']:
        e = {}
        for X in ('T', 'S'):
            lmn, lmx, c_s, c = V5[X]['lmin'][i0[X]], V5[X]['lmax'][i0[X]], LR[X]['c_star'], LR[X]['c']
            e[X] = dict(e_min=abs(lmn + c_s) / c_s, e_max=abs(lmx - c_s) / c_s)
            if c > 0:
                e[X].update(e_min_c=abs(lmn + c) / c, e_max_c=abs(lmx - c) / c)
        vals['T2_errors'] = e
        R['tests']['T2'] = 'GEC' if all(e[X]['e_min'] <= T2_TOL and e[X]['e_max'] <= T2_TOL for X in e) else 'KAL'
        R['report']['T2_at_tols'] = {str(t): all(e[X]['e_min'] <= t and e[X]['e_max'] <= t for X in e)
                                     for t in T2_REPORT_TOLS}
    else:
        R['tests']['T2'] = 'NOT_EVALUABLE'
        ne.append('T2 NOT_EVALUABLE (P_L <= 0, |V| = 0 ya da c* <= 0)')

    # --- s4.2a mod kimligi
    fyu, aS_, aT_ = kay['S_fyu'], kay['S_aDC'], kay['T_aDC']
    mode = dict(S_fyu=fyu, S_aDC=aS_, T_aDC=aT_)
    same = (fyu is not None and aS_ is not None and aT_ is not None
            and fyu['lam'][0] == aS_['lam'][0] and abs(fyu['lam'][1]) == abs(aS_['lam'][1]))
    mode['same_mode'] = same
    vals['mode_identity'] = mode
    if not same:
        if fyu is None:
            why = 'S.fyu.lam/f_Hz eksik (alpha tanimsiz)'
        elif aS_ is None or aT_ is None:
            why = 'a_DC_CPL_pair eksik (%s)' % ','.join(X for X, a in (('T', aT_), ('S', aS_)) if a is None)
        else:
            why = 'sinifi belirleyen mod CPL/DC cifti degil'
        ne.append('mod kimligi saglanmiyor: ' + why)
        R['tests']['T3a'] = R['tests']['T3b'] = 'NOT_EVALUABLE'
    else:
        sel = {}
        for X in ('T', 'S'):
            fc = abs((aS_ if X == 'S' else aT_)['f_Hz'])
            sel[X] = select_rows(V5[X]['f'], fc)
            vals['fc_' + X] = dict(f_c=fc, selection=sel[X], rows=None if sel[X] is None else {
                k: dict(row=i, f_Hz=V5[X]['f'][i], lam_min_H=V5[X]['lmin'][i]) for k, i in sel[X].items()})
        if sel['T'] is None or sel['S'] is None:
            ne.append('f_c izgara disinda (%s)' % ','.join(X for X in ('T', 'S') if sel[X] is None))
            R['tests']['T3a'] = R['tests']['T3b'] = 'NOT_EVALUABLE'
        else:
            # T3a
            rows_S = sorted({sel['S']['lo'], sel['S']['hi']})
            neg = []
            for i in rows_S:
                lm = V5['S']['lmin'][i]
                neg.append(lm < 0)
                flag('T3a: lam_min_H,S(row %d) < 0' % i, lm, sc['S'])
            R['tests']['T3a'] = 'GEC' if all(neg) else ('KAL' if not any(neg) else 'BELIRSIZ')
            # T3b
            if can_q:
                pairs = []
                for k in ('lo', 'hi'):
                    pr = (sel['T'][k], sel['S'][k])
                    if pr not in pairs:
                        pairs.append(pr)
                ok, det = [], []
                for iT, iS in pairs:
                    qT, qS = q('T', iT), q('S', iS)
                    good = qS <= 0 and qT > qS
                    ok.append(good)
                    det.append(dict(row_T=iT, row_S=iS, q_T=qT, q_S=qS, Gamma_c_open_lower=-qT,
                                    Gamma_c_closed_upper=-qS, holds=good))
                    flag('T3b: q_S(row %d) <= 0' % iS, qS, sc['S'])
                    flag('T3b: q_T(row %d) - q_S(row %d) > 0' % (iT, iS), qT - qS, sc_TS)
                vals['T3b_pairs'] = det
                R['tests']['T3b'] = 'GEC' if all(ok) else ('KAL' if not any(ok) else 'BELIRSIZ')
            else:
                R['tests']['T3b'] = 'HESAPLANAMADI'
    R['tests']['T4'] = 'NOT_EVALUABLE (onceden ilan edildi)'

    # --- yalniz rapor
    R['report']['rho_T_equals_rho_S'] = {k: P['T']['rho'][k] == P['S']['rho'][k] for k in RHO_FIELDS}
    R['report']['rho_all_equal'] = all(R['report']['rho_T_equals_rho_S'].values())
    R['report']['Onerme1_G_R_S_lt_G_R_T'] = (gS < gT) if gS_ok else None

    # --- s6 karar tablosu (sira sabit)
    t = R['tests']
    if ne:
        row, verdict = 2, 'NOT_EVALUABLE'
    elif t['T1'] == 'KAL':
        row, verdict = 3, 'RET-statik'
    elif t['T3a'] == 'KAL':
        row, verdict = 4, 'RET-mekanizma'
    elif t['T3b'] == 'KAL':
        row, verdict = 5, 'RET-dinamik'
    elif t['T3a'] == 'BELIRSIZ' or t['T3b'] == 'BELIRSIZ':
        row, verdict = 6, 'BELIRSIZ'
    elif t['T2'] == 'KAL':
        row, verdict = 7, 'KISMI-olcek'
    elif all(t[k] == 'GEC' for k in ('T1', 'T2', 'T3a', 'T3b')):
        row, verdict = 8, 'TUTARLI-T'
    else:
        raise RuntimeError('karar tablosu eslesmedi: %r' % t)
    R['decision_row'] = row
    R['verdict'] = verdict
    R['failed_or_uncertain'] = sorted(k for k in ('T1', 'T2', 'T3a', 'T3b')
                                      if t[k] not in ('GEC',))
    return pin_rows, R


# ------------------------------------------------------------------ kapi (SABIT s8)
def verify_authorization(root, yetki_path, run_id, pins, script_path):
    """Yetki dosyasini dogrular; uyusmazlikta ValueError. Hicbir S girdisi okunmaz."""
    if not RUN_ID_RE.match(run_id):
        raise ValueError('run_id bicimi gecersiz')
    expect = os.path.normcase(os.path.abspath(os.path.join(root, 'cdl1', 'HT_yetki_%s.json' % run_id)))
    if os.path.normcase(os.path.abspath(yetki_path)) != expect:
        raise ValueError('yetki dosyasi yolu cdl1/HT_yetki_<run_id>.json degil')
    if not os.path.isfile(yetki_path):
        raise ValueError('yetki dosyasi yok')
    try:
        y = json.loads(_read_bytes(yetki_path).decode('utf-8'))
    except (UnicodeDecodeError, ValueError):
        raise ValueError('yetki dosyasi JSON degil')
    if not isinstance(y, dict):
        raise ValueError('yetki dosyasi sozluk degil')
    if y.get('action') != 'ALLOW_HT_RUN':
        raise ValueError('action != ALLOW_HT_RUN')
    if y.get('run_id') != run_id:
        raise ValueError('run_id uyusmuyor')
    sabit = os.path.join(root, *SABIT_REL.split('/'))
    if not os.path.isfile(sabit) or sha256_hex(_read_bytes(sabit)) != SABIT_SHA256:
        raise ValueError('SABIT dosyasi hash uyusmuyor')
    if y.get('sabit_sha256') != SABIT_SHA256:
        raise ValueError('yetki.sabit_sha256 uyusmuyor')
    scripts = y.get('script_sha256')
    if not isinstance(scripts, dict) or scripts.get('ht_run.py') != sha256_hex(_read_bytes(script_path)):
        raise ValueError('yetki.script_sha256[ht_run.py] uyusmuyor')
    if y.get('pin_list_sha256') != pin_list_sha256(pins):
        raise ValueError('yetki.pin_list_sha256 uyusmuyor')
    rep = y.get('code_audit_report')
    if not isinstance(rep, dict) or not isinstance(rep.get('path'), str) or not isinstance(rep.get('sha256'), str):
        raise ValueError('yetki.code_audit_report eksik')
    rp = os.path.join(root, *rep['path'].split('/'))
    if not os.path.isfile(rp) or sha256_hex(_read_bytes(rp)) != rep['sha256']:
        raise ValueError('kod denetimi raporu hash uyusmuyor')
    return y


# ------------------------------------------------------------------ kipler
def check_only(root, pins, log):
    """Pin + korlenmemis dosyalarda alan denetimi. Korlenmis S dosyalari ayristirilmaz."""
    sabit = os.path.join(root, *SABIT_REL.split('/'))
    ok_sabit = os.path.isfile(sabit) and sha256_hex(_read_bytes(sabit)) == SABIT_SHA256
    log('SABIT hash: %s' % ('OK' if ok_sabit else 'UYUSMUYOR'))
    if not ok_sabit:
        return 2
    try:
        blobs, rows = verify_pins(root, pins)
    except Abort as e:
        log('PIN: ABORT - %s' % e)
        return 2
    log('PIN: %d/%d OK' % (len(rows), len(pins)))
    log('pin_list_sha256: %s' % pin_list_sha256(pins))
    by_role = {ROLE[no]: blobs[no] for no in blobs if no in ROLE}
    try:
        kay_obj = parse_json(by_role['kayit'], 'kayit')
        kay = parse_kayit(kay_obj)
        pT = parse_point(parse_json(by_role['T_point'], 'T_point'), 'T_point')
        parse_state(by_role['T_state'], 'T_state')
        f0_index(parse_v5(by_role['T_V5'], 'T_V5')['f'], 'T_V5')
        if kay['T_alpha'] != pT['alpha']:
            raise Abort('alpha capraz denetimi (T)')
        if pT['G_R'] != G_R_T_EXPECTED:
            raise Abort('T_point.G_R != 0.25')
    except Abort as e:
        log('ALAN (korlenmemis): ABORT - %s' % e)
        return 2
    log('ALAN (korlenmemis: kayit, T_point, T_state, T_V5): OK')
    log('alan varligi: S.fyu=%s, T.a_DC_CPL_pair=%s, S.a_DC_CPL_pair=%s'
        % (kay['S_fyu'] is not None, kay['T_aDC'] is not None, kay['S_aDC'] is not None))
    kL, note = read_kL(by_role['rhab'])
    log('kL: %r (%s)' % (kL, note))
    log('korlenmis S dosyalari (S_point, S_state, S_V5): yalniz hash; ayristirilmadi')
    return 0


def write_outputs(out_dir, pin_rows, result, verdict_line, log_lines, exit_code, stderr_text):
    _write_text(os.path.join(out_dir, 'girdi_pinleri.json'), json.dumps(pin_rows, indent=1, ensure_ascii=False))
    _write_text(os.path.join(out_dir, 'sonuc.json'), json.dumps(result, indent=1, ensure_ascii=False))
    _write_text(os.path.join(out_dir, 'hukum.txt'), verdict_line + '\n')
    _write_text(os.path.join(out_dir, 'stdout.txt'), '\n'.join(log_lines) + '\n')
    _write_text(os.path.join(out_dir, 'stderr.txt'), stderr_text)
    _write_text(os.path.join(out_dir, 'exit_code.txt'), '%d\n' % exit_code)
    names = sorted(n for n in os.listdir(out_dir) if n != 'SHA256SUMS')
    _write_text(os.path.join(out_dir, 'SHA256SUMS'),
                ''.join('%s  %s\n' % (sha256_hex(_read_bytes(os.path.join(out_dir, n))), n) for n in names))


def default_root():
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def main(argv=None, root=None, pins=None, script_path=None):
    root = root or default_root()
    pins = pins or PINS
    script_path = script_path or os.path.abspath(__file__)
    ap = argparse.ArgumentParser(description='C-DL1 H-T tek kosu betigi')
    ap.add_argument('--check-only', action='store_true')
    ap.add_argument('--run-id')
    ap.add_argument('--yetki')
    a = ap.parse_args(argv)
    lines = []

    def log(s):
        lines.append(s)
        print(s)

    if a.check_only:
        if a.run_id or a.yetki:
            log('KAPI: --check-only ile --run-id/--yetki birlikte verilemez')
            return 3
        return check_only(root, pins, log)
    if not (a.run_id and a.yetki):
        log('KAPI: gercek kip --run-id ve --yetki ister; calismadi')
        return 3
    try:
        verify_authorization(root, a.yetki, a.run_id, pins, script_path)
    except ValueError as e:
        log('KAPI: yetki reddedildi - %s' % e)
        return 3
    out_dir = os.path.join(root, 'cdl1', 'out', a.run_id)
    if os.path.exists(out_dir):
        log('KAPI: %s zaten var; yeniden kosu yok' % out_dir)
        return 3
    os.makedirs(out_dir)
    log('run_id: %s' % a.run_id)
    log('yetki: OK')
    pin_rows, result, err = [], {}, ''
    try:
        pin_rows, result = evaluate(root, pins)
        code = 0
        line = 'H-T hukmu: %s (karar tablosu satir %d)' % (result['verdict'], result['decision_row'])
    except Abort as e:
        code, line = 2, 'H-T hukmu: ABORT (karar tablosu satir 1) - %s' % e
        result = dict(verdict='ABORT', decision_row=1, abort_reason=str(e))
    except Exception:
        code, line = 1, 'BEKLENMEYEN HATA (hukum yok)'
        err = traceback.format_exc()
        result = dict(verdict=None, error='beklenmeyen hata; stderr.txt')
        sys.stderr.write(err)
    log(json.dumps(result, indent=1, ensure_ascii=False))
    log(line)
    write_outputs(out_dir, pin_rows, result, line, lines, code, err)
    return code


if __name__ == '__main__':
    sys.exit(main())
