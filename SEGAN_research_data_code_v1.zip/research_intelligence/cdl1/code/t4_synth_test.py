"""t4_run.py sentetik testi (T4 SABIT s7 (i)-(viii) + kapi/korleme/statik negatif denetimler). Gercek S/T dosyasi
acilmaz; Y_src gercek veride hesaplanmaz.

Bolumler
  A  saf cekirdek (t4_run.core) el yapimi operatorlerle: (ii) bant hukumleri, (iii) pasiflik, (iv) K0a-K0d,
     (v) karar tablosu satirlari ve karisik ciftler, (vi) sonda/frekans ABORT, (vii) SINIRDA, N-1, (viii) Weyl.
  B  (i) donen cercevede seri R-L hat, ideal kaynak: Y = (aI - XJ)/(a^2 + X^2), mu, nu = Re(p) -+ |Im t|.
  C  sentetik research_intelligence agaci (--out altinda): gercek model dosyalari bayt olarak kopyalanir,
     T/S noktalari ve sonuc.json el yapimidir (denge DEGIL). check-only korlemesi, pin ABORT, yetki kapisi,
     G_R tutarlilik ABORT, gercek kip yolunun denge dogrulamasinda ABORT ile bitmesi, yeniden kosu reddi.
  D  model yolu (sentetik x, denge degil): import_models + make_model + build_operators + e1_core.V5 calisir;
     |sigma| = 18, C_sigma isareti, R5 isaret ozdesligi (-Y_sigma^dond = Y_src) ve J_sigma,load = 0 yapisi.
  E  t4_static_check negatif denetimleri: mutasyonlu kopyalar ilgili denetimde KALIR.
Kullanim: python -I t4_synth_test.py --out <bos klasor> [--skip-model]
Cikis: 0 = tum durumlar GECTI, 1 = en az biri KALDI.
"""
import argparse
import copy
import hashlib
import json
import math
import os
import shutil
import sys
import traceback

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import t4_run as T  # noqa: E402
import t4_static_check as SC  # noqa: E402
import ht_run  # noqa: E402  (yalniz read_kL: rhab_model.py AST'den kL; import edilmez)

SYN = os.path.join(HERE, 'synth_t4')
REAL_ROOT = os.path.dirname(os.path.dirname(HERE))
GRID = np.logspace(-1, 3, 200)          # e1_core.py:36 ile ayni tanim
RESULTS = []


def load_json(name):
    with open(os.path.join(SYN, name), encoding='utf-8') as fh:
        return json.load(fh)


BASE = load_json('case_base.json')
NAMES = load_json('state_names.json')


def record(name, ok, detail=''):
    RESULTS.append((name, bool(ok), detail))


# ------------------------------------------------------------------ A: cekirdek durum kurucusu
def mk(over=None):
    """Taban + degisiklik -> (f_grid, sn, ops, v5). q hedefleri birebir; lam = (q - G_R)/kL."""
    c = copy.deepcopy(BASE)
    for k, v in (over or {}).items():
        c[k] = v
    kL = c['kL_core']
    sn = dict(kL=kL, G_R=dict(c['G_R']), q_f0={}, read={})
    ops, v5 = {}, {}
    K = c['K_sigma']
    for X in T.POINTS:
        rows, qs = c['rows'][X], c['q'][X]
        lam = {kind: (qs[kind] - c['G_R'][X]) / kL for kind in T.KINDS}
        sn['read'][X] = {kind: dict(row=rows[kind], f_Hz=float(GRID[rows[kind]]), lam=lam[kind]) for kind in T.KINDS}
        sn['q_f0'][X] = c['G_R'][X] + kL * lam['f0']
        base = [c['v5_lam_base']] * len(GRID)
        for kind in T.KINDS:
            base[rows[kind]] = lam[kind]
        if 'v5_override' in c and X in c['v5_override']:
            for k, val in c['v5_override'][X].items():
                base[int(k)] = val
        v5[X] = [dict(f_Hz=float(GRID[i]), lam_min_H=base[i], lam_max_H=base[i] + c['v5_lam_gap'],
                      Y=[[complex(base[i]), 0j], [0j, complex(base[i] + c['v5_lam_gap'])]]) for i in range(len(GRID))]
        g = c['g'][X]
        A_sig = np.array(c['A_sig'][X], dtype=float) if 'A_sig' in c and X in c['A_sig'] else -K * np.eye(2)
        B_sig = (np.array(c['B_sig'][X], dtype=float) if 'B_sig' in c and X in c['B_sig']
                 else K * np.diag(g))
        A_L = (np.array(c['A_L'][X], dtype=float) if 'A_L' in c and X in c['A_L']
               else c['A_L_diag'] * np.eye(3))
        ops[X] = dict(A_keep=np.diag(c['A_keep'][X]).astype(float), A_sig=A_sig, B_sig=B_sig,
                      C_sig=np.eye(2) if A_sig.shape[0] == 2 else np.eye(2, A_sig.shape[0]), A_L=A_L, r5=None)
    if 'sn_patch' in c:
        c['sn_patch'](sn)
    return GRID, sn, ops, v5


def run_core(over=None):
    f, sn, ops, v5 = mk(over)
    return T.core(f, sn, ops, v5, c_star=None, full_grid=False)


def weyl_all(R):
    return all(p['R3']['weyl_ok'] for p in R['report']['per_reading'] if 'R3' in p)


def q_over(T_=None, S_=None):
    q = copy.deepcopy(BASE['q'])
    for X, d in (('T', T_), ('S', S_)):
        for k, v in (d or {}).items():
            q[X][k] = v
    return q


def section_A():
    # (v) satir 7
    R = run_core()
    record('A-v satir 7 T4-TUTARLI', R['decision_row'] == 7 and R['verdict'] == 'T4-TUTARLI', R['tests'])
    record('A-viii Weyl (taban)', weyl_all(R))
    record('A-ii T-GEC ve S-GEC (taban)', R['comparisons']['T_f0']['verdict'] == 'GEC'
           and R['comparisons']['S_f0']['verdict'] == 'GEC')
    # (ii) dort kesin hukum + BELIRSIZ-esleme
    R = run_core(dict(q=q_over(T_=dict(f0=-0.6))))            # T: q+nu = -0.05 <= 0 -> KAL
    record('A-ii T-KAL', R['comparisons']['T_f0']['verdict'] == 'KAL', R['comparisons']['T_f0'])
    R = run_core(dict(q=q_over(S_=dict(f0=-0.4))))            # S: q+mu = 0.1 > 0 -> KAL
    record('A-ii S-KAL', R['comparisons']['S_f0']['verdict'] == 'KAL', R['comparisons']['S_f0'])
    R = run_core(dict(q=q_over(T_=dict(f0=-0.52), S_=dict(f0=-0.52))))
    record('A-ii BELIRSIZ-esleme (T ve S)', R['comparisons']['T_f0']['verdict'] == 'BELIRSIZ'
           and R['comparisons']['S_f0']['verdict'] == 'BELIRSIZ')
    # (v) satir 4: T4-s KAL
    R = run_core(dict(q=q_over(T_=dict(f0=-0.6))))
    record('A-v satir 4 T4-RET-statik', R['decision_row'] == 4 and R['verdict'] == 'T4-RET-statik', R['tests'])
    # (v) cift icinde T-KAL + S-BELIRSIZ -> KAL
    R = run_core(dict(q=q_over(T_=dict(f0=-0.6), S_=dict(f0=-0.52))))
    record('A-v cift ici T-KAL + S-BELIRSIZ -> KAL', R['pairs']['T4_s']['pair'] == 'KAL' and R['decision_row'] == 4,
           R['pairs']['T4_s'])
    # (v) satir 5: iki f_c cifti KAL
    R = run_core(dict(q=q_over(S_=dict(lo=-0.4, hi=-0.4))))
    record('A-v satir 5 T4-RET-dinamik', R['decision_row'] == 5 and R['verdict'] == 'T4-RET-dinamik', R['tests'])
    # (v) ciftler arasi KAL + BELIRSIZ -> BELIRSIZ; KAL + GEC -> BELIRSIZ
    R = run_core(dict(q=q_over(S_=dict(lo=-0.4, hi=-0.52))))
    record('A-v ciftler arasi KAL + BELIRSIZ -> BELIRSIZ', R['tests']['T4-c'] == 'BELIRSIZ' and R['decision_row'] == 6,
           R['pairs']['T4_c'])
    R = run_core(dict(q=q_over(S_=dict(lo=-0.4))))
    record('A-v ciftler arasi KAL + GEC -> BELIRSIZ', R['tests']['T4-c'] == 'BELIRSIZ' and R['decision_row'] == 6,
           R['pairs']['T4_c'])
    # (v) satir 6: T4-s BELIRSIZ
    R = run_core(dict(q=q_over(T_=dict(f0=-0.52))))
    record('A-v satir 6 BELIRSIZ', R['decision_row'] == 6 and R['verdict'] == 'BELIRSIZ', R['tests'])
    # tek cift: lo = hi (f_c izgara noktasi) -> tek esleme
    R = run_core(dict(rows={'T': {'f0': 0, 'lo': 150, 'hi': 150}, 'S': {'f0': 0, 'lo': 150, 'hi': 150}},
                      q=q_over(T_=dict(hi=-0.4), S_=dict(hi=-0.6))))
    record('A-v lo = hi -> tek cift', len(R['pairs']['T4_c']) == 1 and R['decision_row'] == 7, R['pairs']['T4_c'])

    # (iii) pasiflik
    R = run_core(dict(g={'T': [0.5, 0.55], 'S': [-2e-9, 0.55]}))
    lines = T.verdict_line(R)
    record('A-iii mu = -2 eps_p s -> satir 3 (belirsiz-isaretli)', R['decision_row'] == 3
           and all(p['tag'] == T.LBL_MIXED for p in R['bands'] if p['active'])
           and 'T4-RET-pasiflik [X=S, f=' in lines and T.LBL_MIXED in lines, lines)
    R = run_core(dict(g={'T': [-0.3, -0.2], 'S': [0.5, 0.55]}))
    record('A-iii tam aktif etiketi', R['decision_row'] == 3
           and all(p['tag'] == T.LBL_FULL for p in R['bands'] if p['active'])
           and len([p for p in R['bands'] if p['active']]) == 3, T.verdict_line(R))
    for val in (0.5e-9, -0.5e-9, 0.0):
        R = run_core(dict(g={'T': [0.5, 0.55], 'S': [val, 0.55]}))
        sp = [p for p in R['bands'] if p['X'] == 'S']
        record('A-iii |mu| <= eps_p s (mu=%r) -> SINIRDA-pasiflik, satir 3 yok' % val,
               R['decision_row'] != 3 and all(p['sinirda_pasiflik'] and not p['active'] for p in sp),
               (R['decision_row'], sp))
    # s olcegi: |q| > 1 iken esik buyur
    p = T.passivity(-2e-9, 0.5, -3.0)
    record('A-iii s = max(1,|q|,|nu|) olcegi', p['s'] == 3.0 and not p['active'] and p['sinirda_pasiflik'], p)
    # satir 3 satir 4'ten once gelir
    R = run_core(dict(g={'T': [0.5, 0.55], 'S': [-0.3, 0.55]}, q=q_over(T_=dict(f0=-0.6))))
    record('A-v satir 3 satir 4ten once', R['decision_row'] == 3, R['tests'])

    # (iv) kapilar
    R = run_core(dict(A_sig={'T': [[-1e9, 0.0], [0.0, -0.005]]}))
    record('A-iv K0a -> NOT_EVALUABLE', R['decision_row'] == 2 and any(r.startswith('K0a,T') for r in
                                                                      R['not_evaluable_reasons']),
           R['not_evaluable_reasons'])
    R = run_core(dict(A_keep={'T': [0.3, -1.0, -2.0], 'S': [0.5, -1.0, -2.0]}))
    record('A-iv K0b sinif uyusmazligi (T)', R['decision_row'] == 2 and any('K0b,T: sinif' in r for r in
                                                                           R['not_evaluable_reasons']),
           R['not_evaluable_reasons'])
    R = run_core(dict(A_keep={'T': [0.0, -1.0, -2.0], 'S': [0.5, -1.0, -2.0]}))
    ne = R['not_evaluable_reasons']
    record('A-iv K0b n0 > 0 (T, tek sifir ozdeger) + N-3 iki gerekce', R['decision_row'] == 2
           and any('K0b,T: dondurulmus KEEP' in r for r in ne) and any('K0b,T: sinif' in r for r in ne)
           and R['gates']['T']['K0b']['n0'] == 1, ne)
    R = run_core(dict(A_keep={'T': [-1.0, -2.0, -3.0], 'S': [0.5, 0.0, -2.0]}))
    ne = R['not_evaluable_reasons']
    record('A-iv K0b n0 > 0 (S, sinif uygun) -> yalniz n0 gerekcesi', R['decision_row'] == 2
           and any('K0b,S: dondurulmus KEEP' in r for r in ne) and not any('K0b,S: sinif' in r for r in ne), ne)
    R = run_core(dict(A_L={'S': [[0.1, 0, 0], [0, -1, 0], [0, 0, -1]]}))
    record('A-iv K0c -> NOT_EVALUABLE', R['decision_row'] == 2 and any(r.startswith('K0c,S') for r in
                                                                      R['not_evaluable_reasons']),
           R['not_evaluable_reasons'])
    R = run_core(dict(A_sig={'T': [[-1.0, 1e14], [0.0, -1.0]]}, B_sig={'T': [[1.0, 0.0], [0.0, 1.0]]}))
    record('A-iv K0d (tekile yakin) -> NOT_EVALUABLE; K0a gecer', R['decision_row'] == 2
           and any(r.startswith('K0d,T') for r in R['not_evaluable_reasons'])
           and R['gates']['T']['K0a'], R['not_evaluable_reasons'])
    R = run_core(dict(A_sig={'T': [[-1e9, 0.0], [0.0, -0.005]]}, A_L={'T': [[0.1, 0, 0], [0, -1, 0], [0, 0, -1]]},
                      A_keep={'T': [0.0, -1.0, -2.0], 'S': [0.5, -1.0, -2.0]}))
    ne = R['not_evaluable_reasons']
    record('A-iv N-3 coklu kapi: hepsi yazilir', R['decision_row'] == 2 and all(
        any(r.startswith(p) for r in ne) for p in ('K0a,T', 'K0b,T: dondurulmus', 'K0b,T: sinif', 'K0c,T')), ne)
    R = run_core(dict(A_sig={'T': [[float('nan'), 0.0], [0.0, -1e9]]}))
    record('A-iv sonlu olmayan deger -> NOT_EVALUABLE', R['decision_row'] == 2, R['not_evaluable_reasons'])

    # (vi) sonda ve frekans -> ABORT
    for name, over in (
            ('sonda |dlam| > 1e-9 -> ABORT', dict(v5_override={'T': {'150': (-0.4 - 0.25) + 1e-6}})),
            ('frekans eslesmesi -> ABORT', dict(sn_patch=lambda sn: sn['read']['S']['lo'].update(
                f_Hz=sn['read']['S']['lo']['f_Hz'] * (1 + 1e-15))))):
        try:
            run_core(over)
            record('A-vi ' + name, False, 'ABORT olmadi')
        except T.Abort as e:
            record('A-vi ' + name, True, str(e))
    # sonda tolerans icinde -> ABORT yok
    R = run_core(dict(v5_override={'T': {'150': (-0.4 - 0.25) + 1e-10}}))
    record('A-vi sonda tolerans icinde (1e-10) -> ABORT yok', R['decision_row'] == 7)

    # (vii) SINIRDA bayragi ve N-1 SAYISAL-SINIRDA
    R = run_core(dict(q=q_over(T_=dict(f0=-0.5 + 1e-10))))
    fl = [s for s in R['sinirda'] if s['X'] == 'T' and s['kind'] == 'f0' and s['compare'] == 'q+mu']
    record('A-vii SINIRDA bayragi (q+mu = 1e-10)', len(fl) == 1, R['sinirda'])
    R = run_core(dict(q=q_over(T_=dict(f0=-0.5))))
    ns = [s for s in R['sayisal_sinirda'] if s['X'] == 'T' and s['kind'] == 'f0' and s['compare'] == 'q+mu']
    record('A-vii N-1 SAYISAL-SINIRDA (q+mu ~ 0) ve hukum degismez', len(ns) == 1
           and R['comparisons']['T_f0']['verdict'] == 'BELIRSIZ' and R['decision_row'] == 6, R['sayisal_sinirda'])
    R = run_core()
    record('A-vii taban: SINIRDA ve SAYISAL-SINIRDA bos', not R['sinirda'] and not R['sayisal_sinirda'])
    rd = R['readings'][0]
    record('A-vii N-1 e_X(f) = 10 cond u max(1,||Y||)', abs(rd['e_N1'] - 10 * rd['cond_sigma'] * 2.0 ** -53
                                                           * max(1.0, rd['normY'])) <= 1e-30, rd['e_N1'])

    # (viii) Weyl: rastgele anizotrop 4x4 kaynak, rastgele Hermitci olmayan Y_L
    rng = np.random.default_rng(20261016)
    okw, bad = True, []
    for trial in range(20):
        A = -3.0 * np.eye(4) + 0.5 * rng.standard_normal((4, 4))
        B = rng.standard_normal((4, 2))
        C = rng.standard_normal((2, 4))
        YL = rng.standard_normal((2, 2)) + 1j * rng.standard_normal((2, 2))
        lamL = float(np.linalg.eigvalsh((YL + YL.conj().T) / 2)[0])
        f, sn, ops, v5 = mk()
        for X in T.POINTS:
            ops[X].update(A_sig=A, B_sig=B, C_sig=C)
            for kind in T.KINDS:
                sn['read'][X][kind]['lam'] = lamL
            sn['q_f0'][X] = sn['G_R'][X] + sn['kL'] * lamL
            for i in range(len(v5[X])):
                v5[X][i].update(lam_min_H=lamL, Y=YL.tolist())
        Rr = T.core(f, sn, ops, v5, full_grid=False)
        w = [p['R3'] for p in Rr['report']['per_reading'] if 'R3' in p]
        if not (w and all(x['weyl_ok'] for x in w)):
            okw = False
            bad.append(trial)
    record('A-viii Weyl: q+mu <= lam_min(H_tot) <= q+nu (20 rastgele durum)', okw, bad)


# ------------------------------------------------------------------ B: (i) seri R-L
def section_B():
    WB = 2 * math.pi * 60.0
    Rl, Xl, z = 0.02, 0.15, 1.003
    A = (WB / Xl) * np.array([[-Rl, z * Xl], [-z * Xl, -Rl]])
    B = -(WB / Xl) * np.eye(2)
    C = -np.eye(2)
    J = np.array([[0.0, -1.0], [1.0, 0.0]])
    L = Xl / WB
    X = z * Xl
    for f in (0.0, 0.1, 50.0, 997.0):
        a = Rl + 1j * 2 * math.pi * f * L
        Yexp = (a * np.eye(2) - X * J) / (a * a + X * X)
        p, t = a / (a * a + X * X), X / (a * a + X * X)
        mu_e, nu_e = p.real - abs(t.imag), p.real + abs(t.imag)
        Y, cond = T.y_src(A, B, C, f)
        mu, nu = T.band(Y)
        okY = np.max(np.abs(Y - Yexp)) <= 1e-12 * max(1.0, np.max(np.abs(Yexp)))
        okb = abs(mu - mu_e) <= 1e-12 * max(1.0, abs(mu_e)) and abs(nu - nu_e) <= 1e-12 * max(1.0, abs(nu_e))
        extra = True
        if f == 0.0:
            iso = Rl / (Rl * Rl + X * X)
            extra = abs(mu - iso) <= 1e-12 and abs(nu - iso) <= 1e-12
        record('B-i R-L Y girdileri ve (mu, nu), f = %r' % f, okY and okb and extra,
               dict(Y=Y.tolist(), Yexp=Yexp.tolist(), mu=mu, nu=nu, mu_e=mu_e, nu_e=nu_e))


# ------------------------------------------------------------------ C: sentetik agac
def write_tree(root, kL_true, gr_point=None, sonuc_patch=None, state_dup=False):
    tb = BASE['tree']
    files = {}

    def put_bytes(rel, data):
        p = os.path.join(root, *rel.split('/'))
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, 'wb') as fh:
            fh.write(data)
        files[rel] = p

    def put(rel, text):
        put_bytes(rel, text.encode('utf-8'))

    real_copy = (10, 11, 12, 18, 19, 20, 22)
    for no, rel, _, _ in T.PINS:
        if no in real_copy:
            with open(os.path.join(REAL_ROOT, *rel.split('/')), 'rb') as fh:
                put_bytes(rel, fh.read())
    with open(os.path.join(REAL_ROOT, *T.SABIT_REL.split('/')), 'rb') as fh:
        put_bytes(T.SABIT_REL, fh.read())
    G = gr_point or tb['G_R_point']
    for X in T.POINTS:
        put(T._PTS + X + '_point.json', json.dumps(dict(G_R=G[X], rho=tb['rho'], alpha=-1.0 if X == 'T' else 1.0)))
        rows = [(n, 0.5 + 0.01 * k) for k, n in enumerate(NAMES)]
        if state_dup:
            rows.append(rows[0])
        put(T._PTS + X + '_state.csv', 'state,x_equilibrium\n' + ''.join('%s,%r\n' % r for r in rows))
    v = dict(kL=kL_true)
    for X in T.POINTS:
        gr = tb['G_R_point'][X]
        lam = tb['lam']
        v['G_R_' + X] = gr
        v['q_%s_f0' % X] = gr + kL_true * lam['f0']
        v['f0_' + X] = dict(row=0, f_Hz=float(GRID[0]), lam_min_H=lam['f0'])
        v['fc_' + X] = dict(f_c=float(GRID[150]), rows=dict(
            nearest=dict(row=150, f_Hz=float(GRID[150]), lam_min_H=lam['lo']),
            lo=dict(row=150, f_Hz=float(GRID[150]), lam_min_H=lam['lo']),
            hi=dict(row=151, f_Hz=float(GRID[151]), lam_min_H=lam['hi'])))
    son = dict(values=v, verdict='SENTETIK')
    if sonuc_patch:
        sonuc_patch(son)
    put('cdl1/out/HT_20261015_a/sonuc.json', json.dumps(son, indent=1))
    for no, rel, _, _ in T.PINS:
        if rel not in files:
            put(rel, 'sentetik yer tutucu %d\n' % no)
    pins = []
    for no, rel, _, _ in T.PINS:
        with open(files[rel], 'rb') as fh:
            data = fh.read()
        pins.append((no, rel, len(data), hashlib.sha256(data).hexdigest()))
    return pins


def write_yetki(root, run_id, pins, action='ALLOW_T4_RUN'):
    rep_rel = 'cdl1/T4_kod_denetimi_SENTETIK.md'
    rep = os.path.join(root, *rep_rel.split('/'))
    with open(rep, 'w', encoding='utf-8', newline='\n') as fh:
        fh.write('sentetik kod denetimi raporu (gercek degil)\n')
    with open(rep, 'rb') as fh:
        rsha = hashlib.sha256(fh.read()).hexdigest()
    with open(os.path.join(HERE, 't4_run.py'), 'rb') as fh:
        ssha = hashlib.sha256(fh.read()).hexdigest()
    y = dict(action=action, run_id=run_id, sabit_sha256=T.SABIT_SHA256, script_sha256={'t4_run.py': ssha},
             pin_list_sha256=T.pin_list_sha256(pins), code_audit_report=dict(path=rep_rel, sha256=rsha))
    p = os.path.join(root, 'cdl1', 'T4_yetki_%s.json' % run_id)
    with open(p, 'w', encoding='utf-8', newline='\n') as fh:
        fh.write(json.dumps(y, indent=1))
    return p


def read_text(p):
    with open(p, encoding='utf-8') as fh:
        return fh.read()


def section_C(out, run_model):
    with open(os.path.join(REAL_ROOT, 'r_ha_b', 'code', 'rhab_model.py'), 'rb') as fh:
        kL_true, note = ht_run.read_kL(fh.read())
    record('C kL (rhab_model AST, import yok)', kL_true is not None, note)
    root = os.path.join(out, 'tree_main')
    pins = write_tree(root, kL_true)

    # check-only korlemesi
    T.PARSED_PATHS.clear()
    rc = T.main(['--check-only'], root=root, pins=pins)
    record('C check-only cikis 0 ve S rolleri ayristirilmadi', rc == 0 and not any(
        p.startswith('S_') for p in T.PARSED_PATHS), T.PARSED_PATHS)
    # pin uyusmazligi -> ABORT
    bad = list(pins)
    no, rel, size, sha = bad[2]
    bad[2] = (no, rel, size, '0' * 64)
    try:
        T.verify_pins(root, bad)
        record('C-vi pin uyusmazligi -> ABORT', False, 'ABORT olmadi')
    except T.Abort as e:
        record('C-vi pin uyusmazligi -> ABORT', True, str(e))
    record('C-vi check-only pin uyusmazligi -> 2', T.main(['--check-only'], root=root, pins=bad) == 2)
    # kapi
    record('C kapi: yetkisiz gercek kip -> 3', T.main(['--run-id', 'T4_20990101_a'], root=root, pins=pins) == 3)
    yp = write_yetki(root, 'T4_20990101_b', pins, action='ALLOW_HT_RUN')
    record('C kapi: yanlis action -> 3', T.main(['--run-id', 'T4_20990101_b', '--yetki', yp], root=root,
                                                pins=pins) == 3)
    yp = write_yetki(root, 'T4_20990101_c', pins)
    record('C kapi: run_id/yol uyusmazligi -> 3', T.main(['--run-id', 'T4_20990101_d', '--yetki', yp], root=root,
                                                         pins=pins) == 3)
    record('C kapi: --check-only + --run-id -> 3', T.main(['--check-only', '--run-id', 'T4_20990101_c'],
                                                          root=root, pins=pins) == 3)
    record('C kapi: yetki pin listesi farkli -> 3', T.main(['--run-id', 'T4_20990101_c', '--yetki', yp], root=root,
                                                           pins=bad) == 3)
    # G_R tutarlilik -> ABORT (model import'undan once)
    root_g = os.path.join(out, 'tree_gr')
    pins_g = write_tree(root_g, kL_true, gr_point={'T': 0.25, 'S': 0.06})
    try:
        T.evaluate(root_g, pins_g)
        record('C G_R point != sonuc -> ABORT', False, 'ABORT olmadi')
    except T.Abort as e:
        record('C G_R point != sonuc -> ABORT', 'G_R' in str(e), str(e))
    # alan hatalari -> ABORT
    root_s = os.path.join(out, 'tree_sonuc')
    pins_s = write_tree(root_s, kL_true, sonuc_patch=lambda s: s['values']['fc_S']['rows'].pop('hi'))
    try:
        T.evaluate(root_s, pins_s)
        record('C sonuc.json alan eksik -> ABORT', False, 'ABORT olmadi')
    except T.Abort as e:
        record('C sonuc.json alan eksik -> ABORT', True, str(e))
    root_d = os.path.join(out, 'tree_dup')
    pins_d = write_tree(root_d, kL_true, state_dup=True)
    try:
        T.evaluate(root_d, pins_d)
        record('C durum adi cift -> ABORT', False, 'ABORT olmadi')
    except T.Abort as e:
        record('C durum adi cift -> ABORT', 'cift' in str(e), str(e))
    if not run_model:
        return root
    # gercek kip yolu: yetki OK -> evaluate -> model kurulur -> denge dogrulamasi ABORT (x sentetik)
    yp = write_yetki(root, 'T4_20990101_e', pins)
    rc = T.main(['--run-id', 'T4_20990101_e', '--yetki', yp], root=root, pins=pins)
    od = os.path.join(root, 'cdl1', 'out', 'T4_20990101_e')
    huk = read_text(os.path.join(od, 'hukum.txt')) if os.path.isfile(os.path.join(od, 'hukum.txt')) else ''
    sums = os.path.isfile(os.path.join(od, 'SHA256SUMS'))
    record('C gercek kip yolu -> denge dogrulamasi ABORT (cikis 2, cikti + SHA256SUMS)',
           rc == 2 and 'ABORT' in huk and 'denge' in huk and sums, huk.strip())
    record('C yeniden kosu yok (ayni run_id) -> 3', T.main(['--run-id', 'T4_20990101_e', '--yetki', yp], root=root,
                                                            pins=pins) == 3)
    return root


# ------------------------------------------------------------------ D: model yolu (sentetik x)
def section_D(root):
    pins = None
    mods = T.import_models(root)
    model = T.make_model(mods)
    EM, EC = mods['e1_model'], mods['e1_core']
    x = np.array([0.5 + 0.01 * k for k in range(len(EM.STATE_NAMES))])
    rho = [BASE['tree']['rho'][k] for k in EM.REF_NAMES]
    ops = T.build_operators(mods, model, x, rho, 0.25)
    sig = ops['sig_names']
    il = [sig.index(EM.LINE + ':Il_R'), sig.index(EM.LINE + ':Il_I')]
    okC = ops['C_sig'][0, il[0]] == -1.0 and ops['C_sig'][1, il[1]] == -1.0 and np.count_nonzero(ops['C_sig']) == 2
    record('D |sigma| = 18, theta_oc/yuk/V_2 disarida, C_sigma = -Il', len(sig) == 18 and okC
           and EM.TH_OC not in sig and 'V_2:R' not in sig and not any(n in sig for n in EM.LOAD_STATE_NAMES), sig)
    record('D operator boyutlari', ops['A_sig'].shape == (18, 18) and ops['B_sig'].shape == (18, 2)
           and ops['A_L'].shape == (12, 12) and ops['A_keep'].shape == (32, 32))
    Y, cond = T.y_src(ops['A_sig'], ops['B_sig'], ops['C_sig'], 50.0)
    r5 = T.r5_terms(ops['r5'], 50.0, -0.4, 1.0, 0.5, Y)
    okr5 = 'error' not in r5 and r5['sign_identity_frozen'] <= 1e-9 * max(1.0, float(np.linalg.norm(Y, 2)))
    record('D R5 isaret ozdesligi -Y_sigma^dond = Y_src (sentetik x)', okr5, r5.get('sign_identity_frozen', r5))
    record('D K1 yapisi: J_sigma,load = 0 (tam J, sentetik x)', 'error' not in r5 and r5['max_abs_J_sigma_load'] == 0.0,
           r5.get('max_abs_J_sigma_load'))
    v5 = EC.V5(model, x, rho, 0.25)['rows']
    record('D e1_core.V5 200 satir, f izgarasi esit', len(v5) == 200 and all(
        float(v5[i]['f_Hz']) == float(EC.V5_F_HZ[i]) for i in range(200)))
    # V5'in A_L'si ile build_operators A_L'si ayni yapida mi: Y_L(f) iki yoldan
    iL = [EM.LOAD_STATE_NAMES.index(EM.L + ':ir_filter'), EM.LOAD_STATE_NAMES.index(EM.L + ':ii_filter')]
    zs = model.h(x, rho)
    Jt = model.Jx_tilde(x, zs, rho, 0.25)
    IX = {n: k for k, n in enumerate(EM.STATE_NAMES)}
    li = [IX[n] for n in EM.LOAD_STATE_NAMES]
    Bl = Jt[np.ix_(li, [IX['V_2:R'], IX['V_2:I']])] / model.M[li][:, None]
    Cl = np.zeros((2, 12))
    Cl[0, iL[0]] = Cl[1, iL[1]] = 1.0
    k = 120
    YL, _ = T.y_src(ops['A_L'], Bl, Cl, float(EC.V5_F_HZ[k]))
    YV = np.array(v5[k]['Y'], dtype=complex)
    record('D A_L tutarliligi (build_operators ile V5 ayni Y_L)', np.max(np.abs(YL - YV)) <= 1e-9 * max(
        1.0, float(np.max(np.abs(YV)))), float(np.max(np.abs(YL - YV))))
    # core'un tam yolu sentetik x ile (sonda icin V5 degerleri kullanilir; hukum anlamsizdir, yalniz yurutme)
    sn = dict(kL=1.0, G_R=dict(T=0.25, S=0.25), q_f0={}, read={})
    for X in T.POINTS:
        sn['read'][X] = {kind: dict(row=r, f_Hz=float(EC.V5_F_HZ[r]), lam=v5[r]['lam_min_H'])
                         for kind, r in (('f0', 0), ('lo', 150), ('hi', 151))}
        sn['q_f0'][X] = 0.25 + v5[0]['lam_min_H']
    Rm = T.core(EC.V5_F_HZ, sn, dict(T=ops, S=ops), dict(T=v5, S=v5), c_star=dict(T=0.5, S=0.5), full_grid=True)
    js = json.dumps(T._jsonable(Rm))
    record('D core tam yol (model operatorleri, 200 satir R1, R5) calisir ve JSON yazilabilir',
           Rm['decision_row'] in (2, 3, 4, 5, 6, 7) and len(js) > 0 and Rm['report']['R1']['T']['n_rows'] > 0,
           Rm['decision_row'])
    return pins


# ------------------------------------------------------------------ E: statik denetim negatifleri
def section_E(out):
    with open(os.path.join(HERE, 't4_run.py'), encoding='utf-8') as fh:
        src = fh.read()
    muts = [
        ('S1', 'import scipy ekle', src.replace('import numpy as np  # noqa: E402',
                                                'import numpy as np  # noqa: E402\nimport scipy  # noqa: E402', 1)),
        ('S7', 'K0b ozdeger dislamasi', src.replace('alpha = float(np.max(lam.real))',
                                                    'alpha = float(np.max(np.delete(lam, 0).real))', 1)),
        ('S6', 'model yamasi', src.replace("    zs = model.h(x, rhov)\n",
                                           "    model.Jx_tilde_sym = None\n    zs = model.h(x, rhov)\n", 1)),
        ('S6', 'sembolik yeniden turetme', src.replace("    Jf = model.J(x, rhov, GR)\n",
                                                       "    Jf = model.J_new_sym.jacobian(x)\n", 1)),
        ('S9', 'check_only icinde evaluate', src.replace("    log('PIN: %d/%d OK' % (len(rows), len(pins)))\n",
                                                         "    log('PIN: %d/%d OK' % (len(rows), len(pins)))\n"
                                                         "    evaluate(root, pins)\n", 1)),
        ('S5', 'korlenmis ad', src.replace("LBL_FULL, LBL_MIXED", "_X = 'S_state.csv'\nLBL_FULL, LBL_MIXED", 1)),
        ('S3', 'open() disarida', src.replace("def sha256_hex(data):\n",
                                              "def _oku(p):\n    return open(p).read()\n\n\ndef sha256_hex(data):\n", 1)),
    ]
    for chk, name, msrc in muts:
        if msrc == src:
            record('E %s mutasyon uygulanamadi (%s)' % (chk, name), False)
            continue
        p = os.path.join(out, 'mut_%s_%d.py' % (chk, len(RESULTS)))
        with open(p, 'w', encoding='utf-8', newline='\n') as fh:
            fh.write(msrc)
        res, _ = SC.check(p, REAL_ROOT)
        failed = [n for n, ok, _ in res if not ok]
        record('E statik negatif: %s -> %s KALIR' % (name, chk), any(n.startswith(chk) for n in failed), failed)
    res, _ = SC.check(os.path.join(HERE, 't4_run.py'), REAL_ROOT)
    record('E statik denetim gercek betikte GECER', all(ok for _, ok, _ in res), [n for n, ok, _ in res if not ok])


def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except (AttributeError, ValueError):
        pass
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', required=True)
    ap.add_argument('--skip-model', action='store_true', help='C/D model kurulumunu atla (hizli gelistirme)')
    a = ap.parse_args(argv)
    if os.path.exists(a.out) and os.listdir(a.out):
        print('--out bos olmali')
        return 2
    os.makedirs(a.out, exist_ok=True)
    for nm, fn in (('A', section_A), ('B', section_B)):
        try:
            fn()
        except Exception:
            record('%s bolumu beklenmeyen hata' % nm, False, traceback.format_exc())
    try:
        root = section_C(a.out, not a.skip_model)
        if not a.skip_model:
            section_D(root)
    except Exception:
        record('C/D bolumu beklenmeyen hata', False, traceback.format_exc())
    try:
        section_E(a.out)
    except Exception:
        record('E bolumu beklenmeyen hata', False, traceback.format_exc())
    ok = True
    lines = []
    for name, passed, detail in RESULTS:
        lines.append('%-78s %s' % (name, 'GECTI' if passed else 'KALDI'))
        if not passed:
            lines.append('    ' + str(detail)[:2000])
        ok &= passed
    lines.append('SENTETIK TEST: %s (%d durum%s)' % ('GECTI' if ok else 'KALDI', len(RESULTS),
                                                    ', model yolu atlandi' if a.skip_model else ''))
    print('\n'.join(lines))
    with open(os.path.join(a.out, 'sentetik_ozet.txt'), 'w', encoding='utf-8', newline='\n') as fh:
        fh.write('\n'.join(lines) + '\n')
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
