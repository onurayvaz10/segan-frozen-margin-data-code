"""t4_run.py icin AST statik denetimi (T4 SABIT s7 'Statik denetim').

Denetimler:
  S1  import izin listesi: ust duzeyde 10 standart modul + numpy; model modulleri (e1k_model, e1k_core, e1_core,
      e1_model) yalniz import_models() icinde; 'from' import yok; yasakli adlar (scipy, sympy, subprocess,
      importlib, e1k_run, e1_run, ...) yok.
  S2  yasakli cagrilar yok: eval, exec, compile, __import__, setattr, delattr, os.system, os.popen, os.exec*,
      os.spawn*, os.fork*.
  S3  open() yalniz _read_bytes ve _write_text icinde; pathlib/read_text yok.
  S4  PINS literal tablosu: 1-15 H-T SABIT s3 ile, 16-22 T4 SABIT s3 ile birebir; iki SABIT hash'i dogru.
  S5  korlenmis dosya adlari (S_state.csv, S_V5_admittance.csv, S_point.json) yalniz PINS tablosunda.
  S6  tam J yalniz model nesnesinin mevcut yontemiyle: 'model.' uzerinde yalniz h, Jx_tilde, J, f, M, load, net;
      sembolik/ozel nitelik (jacobian, diff, lambdify, subs, *_sym, _Jn, J_complex_step, ...) yok; model
      modulleri ya da model nesnesi uzerine atama (yama) yok; 'EC.' uzerinde yalniz V5, TH, V5_F_HZ, KEEP.
  S7  K0b: k0b() fonksiyonu var; icinde identify_ref/alpha_from/alpha_of_matrix/eig_part/delete cagrisi ve
      kosullu kavrama yok; 'np.max(lam.real)' (tum ozdegerler) kalibi var. Bu adlar betikte hic cagrilmaz.
  S8  cozucu/ODE/tarama adlari yok (odeint, solve_ivp, fsolve, newton, minimize, root, least_squares, linprog).
  S9  korleme sirasi: evaluate() yalniz main() icinde ve verify_authorization() cagrisindan sonra cagrilir;
      check_only() evaluate/import_models/make_model cagirmaz ve S rol adlarina degmez.
Kullanim: python -I t4_static_check.py [--root <research_intelligence>] [--script <t4_run.py>]
Cikis: 0 = GECTI, 1 = KALDI.
"""
import argparse
import ast
import hashlib
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
TOP_IMPORTS = {'os', 'argparse', 'csv', 'hashlib', 'io', 'json', 'math', 're', 'sys', 'traceback', 'numpy'}
MODEL_IMPORTS = {'e1k_model', 'e1k_core', 'e1_core', 'e1_model'}
FORBIDDEN_NAMES = {'scipy', 'sympy', 'sp', 'subprocess', 'importlib', 'ctypes', 'multiprocessing', 'socket',
                   'urllib', 'http', 'shutil', 'pathlib', 'pickle', 'marshal', 'e1k_run', 'e1_run', 'ER',
                   'rhab_model_import'}
FORBIDDEN_CALLS = {'eval', 'exec', 'compile', '__import__', 'execfile', 'setattr', 'delattr'}
FORBIDDEN_ATTR_CALLS = {('os', 'system'), ('os', 'popen'), ('os', 'startfile')}
FORBIDDEN_ATTR_PREFIX = ('exec', 'spawn', 'fork')
OPEN_ALLOWED_IN = {'_read_bytes', '_write_text'}
BLINDED = ('S_state.csv', 'S_V5_admittance.csv', 'S_point.json')
PTS_FULL = 'e1_k/out/SETTINGS_20261012_a/settings/S3/points/'
MODEL_ALLOWED_ATTRS = {'h', 'Jx_tilde', 'J', 'f', 'M', 'load', 'net'}
EC_ALLOWED_ATTRS = {'V5', 'TH', 'V5_F_HZ', 'KEEP'}
SYMBOLIC_ATTRS = {'jacobian', 'diff', 'lambdify', 'subs', 'J_new_sym', 'Jx_tilde_sym', 'Jz_tilde_sym', 'f_new_sym',
                  'J_fix_sym', 'f_fix_sym', '_Jn', '_Jxt', '_Jzt', '_fn', '_ft', '_ff', '_Jf', '_aux',
                  'J_complex_step', 'J_fixed', 'f_fixed', 'f_tilde', 'Jz_tilde', 'build_ftilde_k', 'build_ftilde'}
PATCH_ROOTS = {'KM', 'KC', 'EC', 'EM', 'RB', 'model', 'mods'}
K0B_FORBIDDEN = {'identify_ref', 'alpha_from', 'alpha_of_matrix', 'eig_part', 'delete'}
SOLVER_NAMES = {'odeint', 'solve_ivp', 'fsolve', 'newton', 'minimize', 'root', 'least_squares', 'linprog', 'milp',
                'power_flow'}
HT_SABIT = ('cdl1/CDL1_HT_On_Kayit_v1.0_SABIT.md', '3adc9f2b024897d386b3f074ba14f6fee5f44f07d43a7502fc4f3dd6b3543b91')
T4_SABIT = ('cdl1/CDL1_T4_On_Kayit_v1.0_SABIT.md', 'e6457498a262063a546ec00162ebef575aabfea8ab375144233c0625725f3d6d')


def sha(path):
    with open(path, 'rb') as fh:
        return hashlib.sha256(fh.read()).hexdigest()


def sabit_pins(md_text):
    """SABIT s3 tablolari: '| n | `yol` ... | bayt | `sha` |' satirlari."""
    out = []
    for line in md_text.splitlines():
        m = re.match(r'^\|\s*(\d+)\s*\|\s*`([^`]+)`[^|]*\|\s*(\d+)\s*\|\s*`([0-9a-f]{64})`\s*\|\s*$', line)
        if m:
            p = m.group(2)
            if p.startswith('…/S3/points/'):
                p = PTS_FULL + p[len('…/S3/points/'):]
            out.append((int(m.group(1)), p, int(m.group(3)), m.group(4)))
    return out


def literal_pins(tree):
    pts, pins_node = None, None
    for n in tree.body:
        if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name):
            if n.targets[0].id == '_PTS':
                pts = ast.literal_eval(n.value)
            elif n.targets[0].id == 'PINS':
                pins_node = n.value
    if pts is None or pins_node is None:
        return None
    out = []
    for el in pins_node.elts:
        no, pnode, size, h = el.elts
        if isinstance(pnode, ast.BinOp):
            if not (isinstance(pnode.left, ast.Name) and pnode.left.id == '_PTS'):
                return None
            path = pts + ast.literal_eval(pnode.right)
        else:
            path = ast.literal_eval(pnode)
        out.append((ast.literal_eval(no), path, ast.literal_eval(size), ast.literal_eval(h)))
    return out


def enclosing_funcs(tree):
    """Dugum id -> en ic fonksiyon adi."""
    out = {}

    def visit(node, cur):
        for ch in ast.iter_child_nodes(node):
            nxt = ch.name if isinstance(ch, (ast.FunctionDef, ast.AsyncFunctionDef)) else cur
            out[id(ch)] = cur
            visit(ch, nxt)
    visit(tree, None)
    return out


def call_name(n):
    f = n.func
    return f.id if isinstance(f, ast.Name) else (f.attr if isinstance(f, ast.Attribute) else None)


def root_name(node):
    while isinstance(node, (ast.Attribute, ast.Subscript)):
        node = node.value
    return node.id if isinstance(node, ast.Name) else None


def func_def(tree, name):
    hits = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name]
    return hits[0] if len(hits) == 1 else None


def check(script_path, root):
    src_bytes = open(script_path, 'rb').read()
    tree = ast.parse(src_bytes.decode('utf-8'))
    inner = enclosing_funcs(tree)
    res = []

    # S1
    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Import):
            for a in n.names:
                top = a.name.split('.')[0]
                fn = inner.get(id(n))
                if top in MODEL_IMPORTS:
                    if fn != 'import_models':
                        bad.append('%s import_models disinda (satir %d)' % (a.name, n.lineno))
                elif top not in TOP_IMPORTS:
                    bad.append(a.name)
        elif isinstance(n, ast.ImportFrom):
            bad.append('from %s' % n.module)
        elif isinstance(n, ast.Name) and n.id in FORBIDDEN_NAMES:
            bad.append(n.id)
        elif isinstance(n, ast.Attribute) and n.attr in FORBIDDEN_NAMES:
            bad.append('.' + n.attr)
    res.append(('S1 import/yasakli ad', not bad, bad))

    # S2
    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Call):
            f = n.func
            if isinstance(f, ast.Name) and f.id in FORBIDDEN_CALLS:
                bad.append(f.id)
            if isinstance(f, ast.Attribute) and isinstance(f.value, ast.Name):
                if (f.value.id, f.attr) in FORBIDDEN_ATTR_CALLS or (
                        f.value.id == 'os' and f.attr.startswith(FORBIDDEN_ATTR_PREFIX)):
                    bad.append('%s.%s' % (f.value.id, f.attr))
    res.append(('S2 yasakli cagri', not bad, bad))

    # S3
    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Call):
            name = call_name(n)
            if name in ('open', 'read_text', 'read_bytes', 'write_text', 'write_bytes', 'urlopen'):
                if not (name == 'open' and inner.get(id(n)) in OPEN_ALLOWED_IN):
                    bad.append('%s @ satir %d (fonksiyon %s)' % (name, n.lineno, inner.get(id(n))))
    res.append(('S3 dosya acma tek nokta', not bad, bad))

    # S4
    detail = []
    lp = literal_pins(tree) or []
    for (rel, exp), lo, hi in ((HT_SABIT, 1, 15), (T4_SABIT, 16, 22)):
        p = os.path.join(root, *rel.split('/'))
        got = sha(p)
        if got != exp:
            detail.append('%s sha %s' % (rel, got))
        sp = [t for t in sabit_pins(open(p, encoding='utf-8').read()) if lo <= t[0] <= hi]
        if len(sp) != hi - lo + 1:
            detail.append('%s tablosunda %d pin (beklenen %d)' % (rel, len(sp), hi - lo + 1))
        if [t for t in lp if lo <= t[0] <= hi] != sp:
            detail.append('PINS %d-%d != %s s3' % (lo, hi, rel))
    if [t[0] for t in lp] != list(range(1, 23)):
        detail.append('PINS numaralari 1..22 degil')
    sab = [n for n in tree.body if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name)
           and n.targets[0].id == 'SABIT_SHA256']
    if len(sab) != 1 or ast.literal_eval(sab[0].value) != T4_SABIT[1]:
        detail.append('SABIT_SHA256 literal')
    res.append(('S4 PINS == SABIT tablolari (22 pin) ve hashler', not detail, detail))

    # S5
    bad = []
    doc = tree.body[0].value if (tree.body and isinstance(tree.body[0], ast.Expr)) else None
    pins_ids = set()
    for n in tree.body:
        if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'PINS':
            pins_ids = {id(x) for x in ast.walk(n)}
    for n in ast.walk(tree):
        if isinstance(n, ast.Constant) and isinstance(n.value, str) and n is not doc and id(n) not in pins_ids:
            for b in BLINDED:
                if b in n.value:
                    bad.append('%s @ satir %d' % (b, n.lineno))
    res.append(('S5 korlenmis adlar yalniz PINS icinde', not bad, bad))

    # S6
    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Attribute):
            if n.attr in SYMBOLIC_ATTRS:
                bad.append('.%s @ satir %d' % (n.attr, n.lineno))
            if isinstance(n.value, ast.Name) and n.value.id == 'model' and n.attr not in MODEL_ALLOWED_ATTRS:
                bad.append('model.%s @ satir %d' % (n.attr, n.lineno))
            if isinstance(n.value, ast.Name) and n.value.id == 'EC' and n.attr not in EC_ALLOWED_ATTRS:
                bad.append('EC.%s @ satir %d' % (n.attr, n.lineno))
        targets = []
        if isinstance(n, ast.Assign):
            targets = n.targets
        elif isinstance(n, (ast.AugAssign, ast.AnnAssign)):
            targets = [n.target]
        elif isinstance(n, ast.Delete):
            targets = n.targets
        for t in targets:
            for tt in (t.elts if isinstance(t, ast.Tuple) else [t]):
                if isinstance(tt, (ast.Attribute, ast.Subscript)) and root_name(tt) in PATCH_ROOTS:
                    bad.append('yama: %s @ satir %d' % (ast.unparse(tt), n.lineno))
    res.append(('S6 tam J yalniz model.J; yama/sembolik yok', not bad, bad))

    # S7
    detail = []
    fk = func_def(tree, 'k0b')
    if fk is None:
        detail.append('k0b() yok')
    else:
        pat = False
        for n in ast.walk(fk):
            if isinstance(n, ast.Call) and call_name(n) in K0B_FORBIDDEN:
                detail.append('k0b icinde %s' % call_name(n))
            if isinstance(n, ast.comprehension) and n.ifs:
                detail.append('k0b icinde kosullu kavrama @ satir %d' % n.target.lineno)
            if (isinstance(n, ast.Call) and ast.unparse(n) == 'np.max(lam.real)'):
                pat = True
        if not pat:
            detail.append("k0b icinde 'np.max(lam.real)' yok")
    for n in ast.walk(tree):
        if isinstance(n, ast.Call) and call_name(n) in K0B_FORBIDDEN:
            detail.append('%s cagrisi @ satir %d' % (call_name(n), n.lineno))
    res.append(('S7 K0b ozdeger dislamasi yok', not detail, detail))

    # S8
    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Call) and call_name(n) in SOLVER_NAMES:
            bad.append('%s @ satir %d' % (call_name(n), n.lineno))
        if isinstance(n, ast.Attribute) and n.attr in SOLVER_NAMES:      # 'root' adli degisken serbest
            bad.append('.%s @ satir %d' % (n.attr, n.lineno))
    res.append(('S8 cozucu/ODE/tarama yok', not bad, bad))

    # S9
    detail = []
    calls_eval = [n for n in ast.walk(tree) if isinstance(n, ast.Call) and call_name(n) == 'evaluate']
    if len(calls_eval) != 1 or inner.get(id(calls_eval[0])) != 'main':
        detail.append('evaluate() cagrisi tek ve main() icinde degil')
    else:
        auth = [n for n in ast.walk(func_def(tree, 'main')) if isinstance(n, ast.Call)
                and call_name(n) == 'verify_authorization']
        if len(auth) != 1 or not auth[0].lineno < calls_eval[0].lineno:
            detail.append('verify_authorization() evaluate()dan once degil')
    fc = func_def(tree, 'check_only')
    if fc is None:
        detail.append('check_only() yok')
    else:
        for n in ast.walk(fc):
            if isinstance(n, ast.Call) and call_name(n) in ('evaluate', 'import_models', 'make_model', 'core'):
                detail.append('check_only icinde %s' % call_name(n))
            if isinstance(n, ast.Constant) and isinstance(n.value, str) and n.value.startswith('S_'):
                detail.append('check_only icinde %r' % n.value)
    for name in ('import_models', 'make_model'):
        sites = [inner.get(id(n)) for n in ast.walk(tree) if isinstance(n, ast.Call) and call_name(n) == name]
        if any(s != 'evaluate' for s in sites):
            detail.append('%s evaluate() disinda cagriliyor' % name)
    res.append(('S9 korleme sirasi (yetki -> evaluate)', not detail, detail))

    return res, hashlib.sha256(src_bytes).hexdigest()


def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except (AttributeError, ValueError):
        pass
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default=os.path.dirname(os.path.dirname(HERE)))
    ap.add_argument('--script', default=os.path.join(HERE, 't4_run.py'))
    a = ap.parse_args(argv)
    res, h = check(a.script, a.root)
    print('t4_run.py sha256: %s' % h)
    ok = True
    for name, passed, detail in res:
        print('%-48s %s%s' % (name, 'GECTI' if passed else 'KALDI', '' if passed else '  ' + '; '.join(map(str, detail))))
        ok &= passed
    print('STATIK DENETIM: %s' % ('GECTI' if ok else 'KALDI'))
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
