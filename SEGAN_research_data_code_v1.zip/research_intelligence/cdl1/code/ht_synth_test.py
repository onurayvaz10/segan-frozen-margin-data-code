"""ht_run.py sentetik testi (SABIT s7 zorunlu durumlari). Gercek S dosyalari acilmaz.

Girdi: synth/base_case.json ve synth/rhab_synth.py (el yapimi). Her durum, tabanin kopyasina
kucuk bir degisiklik uygular, --out altinda sentetik bir research_intelligence agaci yazar,
pinleri o agactan hesaplar ve ht_run.evaluate / ht_run.main'i cagirir. Ozdeger hesabi yok;
ideal-CPL degerleri elle kurulmus 2x2 (lam = +-c*) degerleridir.
Kullanim: python -I ht_synth_test.py --out <bos klasor>
Cikis: 0 = tum durumlar GECTI, 1 = en az biri KALDI.
"""
import argparse
import copy
import hashlib
import json
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import ht_run  # noqa: E402

SYN = os.path.join(HERE, 'synth')
REAL_ROOT = os.path.dirname(os.path.dirname(HERE))
GRID = [10 ** (-1 + 4 * k / 199) for k in range(200)]      # e1_core.py:36 ile ayni tanim (stdlib)
STATE_EXTRA = [('generator-101-1:ir_filter', 0.3), ('V_1:R', 1.0)]


def load_base():
    with open(os.path.join(SYN, 'base_case.json'), encoding='utf-8') as fh:
        return json.load(fh)


def rhab_text():
    with open(os.path.join(SYN, 'rhab_synth.py'), encoding='utf-8') as fh:
        return fh.read()


def bracket(fc):
    s = ht_run.select_rows(GRID, fc)
    return s['lo'], s['hi']


# ------------------------------------------------------------------ agac yazimi
def write_tree(root, case):
    pts = os.path.join(root, *ht_run._PTS.strip('/').split('/'))
    os.makedirs(pts)
    files = {}

    def put(rel, text):
        p = os.path.join(root, *rel.split('/'))
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, 'w', encoding='utf-8', newline='\n') as fh:
            fh.write(text)
        files[rel] = p

    kayit = case['kayit']
    put(ht_run.PINS[0][1], json.dumps(kayit, indent=1))
    for X in ('T', 'S'):
        P = case[X]
        put(ht_run._PTS + X + '_point.json', json.dumps(dict(
            tag=X, G_R=P['G_R'], rho=P['rho'], alpha=P['alpha'], spectral=dict(alpha=P['spectral_alpha'])), indent=1))
        rows = [('V_2:R', P['V'][0]), ('V_2:I', P['V'][1]),
                ('load1021:ir_filter', P['I'][0]), ('load1021:ii_filter', P['I'][1])] + STATE_EXTRA
        rows += [tuple(r) for r in P.get('state_extra_rows', [])]
        put(ht_run._PTS + X + '_state.csv', 'state,x_equilibrium,x_init_before_refine\n'
            + ''.join('%s,%r,0.0\n' % r for r in rows))
        f = list(P.get('grid', GRID))
        lmin = [P['lam_min']] * len(f)
        lmax = [P['lam_max']] * len(f)
        for ov in P.get('overrides', []):
            for i in ov['rows']:
                (lmin if ov['col'] == 'lmin' else lmax)[i] = ov['value']
        cols = P.get('v5_cols', ['f_Hz', 'omega', 'lam_min_H', 'lam_max_H'])
        body = ''.join('%r,%r,%r,%r\n' % (f[i], 2 * math.pi * f[i], lmin[i], lmax[i]) for i in range(len(f)))
        put(ht_run._PTS + X + '_V5_admittance.csv', ','.join(cols) + '\n' + body)
        put(ht_run._PTS + X + '_eigs.csv', 're,im\n-1.0,0.0\n')
    put('e1_k/code/e1k_model.py', '# sentetik yer tutucu\n')
    put('e1_m-e1-0/code/e1_core.py', '# sentetik yer tutucu\n')
    put('r_ha_b/code/rhab_model.py', case.get('rhab', rhab_text()))
    put('cdl1/CDL1_E1_analitik_not_v0.2.md', 'sentetik\n')
    put('e1_k/sabit/PF1_E1K_On_Kayit_v1.0_SABIT.md', 'sentetik\n')
    put('e1_k/cb/E1KCB_rapor.md', 'sentetik\n')
    pins = []
    for no, rel, _, _ in ht_run.PINS:
        with open(files[rel], 'rb') as fh:
            data = fh.read()
        pins.append((no, rel, len(data), hashlib.sha256(data).hexdigest()))
    return pins


# ------------------------------------------------------------------ durumlar
def m(fn):
    def apply(c):
        fn(c)
        return c
    return apply


def set_both_alpha(X, v):
    def f(c):
        c[X]['alpha'] = v
        c['kayit'][X]['alpha'] = v
    return f


def fc_mode(fc, im_sign_fyu=-1):
    def f(c):
        w = 2 * math.pi * fc
        c['kayit']['S']['fyu'].update(lam=[0.5, im_sign_fyu * w], f_Hz=fc)
        c['kayit']['S']['descriptive']['a_DC_CPL_pair'].update(lam=[0.5, w], f_Hz=fc)
    return f


S_LO, S_HI = bracket(100.0)
T_LO, T_HI = bracket(95.4929658551372)
F0_ROW = 0


def ov(X, col, rows, value):
    def f(c):
        c[X].setdefault('overrides', []).append(dict(col=col, rows=list(rows), value=value))
    return f


def chain(*fs):
    def f(c):
        for g in fs:
            g(c)
    return f


def rhab_sub(old, new):
    def f(c):
        t = rhab_text()
        assert old in t
        c['rhab'] = t.replace(old, new)
    return f


def del_key(path):
    def f(c):
        d = c
        for k in path[:-1]:
            d = d[k]
        del d[path[-1]]
    return f


def setk(path, v):
    def f(c):
        d = c
        for k in path[:-1]:
            d = d[k]
        d[path[-1]] = v
    return f


def grid_mut(X, fn):
    def f(c):
        g = list(GRID)
        c[X]['grid'] = fn(g)
    return f


def _swap(g):
    g[10], g[11] = g[11], g[10]
    return g


EXACT = GRID[150]

# (ad, degisiklik, dosya-sonrasi eylem, beklenen hukum, ek denetim)
CASES = [
    ('taban: ideal CPL I_q!=0, eslenik temsilci, spectral.alpha farkli', None, None, 'TUTARLI-T',
     lambda r: (all(r['values']['T2_errors'][X][k] == 0.0 for X in 'TS' for k in ('e_min', 'e_max'))
                and r['values']['mode_identity']['same_mode'] and r['report']['rho_all_equal']
                and not r['sinirda'] and r['decision_row'] == 8)),
    ('ayni mod, im isareti ayni', fc_mode(100.0, +1), None, 'TUTARLI-T', None),
    ('f_c tam izgara noktasi', fc_mode(EXACT), None, 'TUTARLI-T',
     lambda r: r['values']['fc_S']['selection'] == dict(nearest=150, lo=150, hi=150)),
    ('rho_T != rho_S (yalniz rapor)', setk(['S', 'rho', 'P_ref'], 0.9), None, 'TUTARLI-T',
     lambda r: r['report']['rho_all_equal'] is False and r['report']['rho_T_equals_rho_S']['P_ref'] is False),
    # satir 1 ABORT
    ('pin uyusmazligi', None, 'corrupt_eigs', 'ABORT', None),
    ('eksik sutun (S V5 lam_max_H)', setk(['S', 'v5_cols'], ['f_Hz', 'omega', 'lam_min_H', 'lamX']), None, 'ABORT', None),
    ('eksik sutun (T state x_equilibrium)', None, 'state_col', 'ABORT', None),
    ('alpha capraz denetimi', setk(['kayit', 'S', 'alpha'], 0.6), None, 'ABORT', None),
    ('G_R,T != 0.25', setk(['T', 'G_R'], 0.3), None, 'ABORT', None),
    ('V5 199 satir', grid_mut('S', lambda g: g[:199]), None, 'ABORT', None),
    ('V5 kesin artan degil', grid_mut('T', _swap), None, 'ABORT', None),
    ('f0 satiri yok', grid_mut('S', lambda g: [0.1000001] + g[1:]), None, 'ABORT', None),
    ('state satiri iki kez', setk(['S', 'state_extra_rows'], [['V_2:R', 1.0]]), None, 'ABORT', None),
    ('fyu.lam tipi bozuk', setk(['kayit', 'S', 'fyu', 'lam'], 'x'), None, 'ABORT', None),
    # satir 2 NOT_EVALUABLE
    ('sinif uyusmazligi', set_both_alpha('S', 0.005), None, 'NOT_EVALUABLE', None),
    ('kL literal degil', rhab_sub('base_power=100.0)\n    gfm', 'base_power=100.0 * 1)\n    gfm'), None,
     'NOT_EVALUABLE', None),
    ('kL cift eslesme', rhab_sub('    gfm =', '    load = dict(base_power=100.0)\n    gfm ='), None,
     'NOT_EVALUABLE', None),
    ('kL <= 0', rhab_sub('rf=0.01, base_power=100.0', 'rf=0.01, base_power=0.0'), None, 'NOT_EVALUABLE', None),
    ('G_R,S < 0', setk(['S', 'G_R'], -0.1), None, 'NOT_EVALUABLE', None),
    ('f_c izgara disinda', fc_mode(2000.0), None, 'NOT_EVALUABLE', None),
    ('P_L <= 0', setk(['S', 'I'], [-0.5, 0.0]), None, 'NOT_EVALUABLE', None),
    ('c* <= 0 (I=0, I_q=0)', chain(setk(['S', 'I'], [0.0, 0.0]), setk(['S', 'rho', 'Iq_ref'], 0.0)), None,
     'NOT_EVALUABLE', None),
    ('mod kimligi: farkli mod', setk(['kayit', 'S', 'fyu', 'lam'], [0.4, -628.3185307179587]), None,
     'NOT_EVALUABLE', None),
    ('mod kimligi: fyu eksik', setk(['kayit', 'S', 'fyu'], {'flag': 'belirsiz', 'reason': 'alpha tanimsiz'}), None,
     'NOT_EVALUABLE', None),
    ('mod kimligi: S a_DC_CPL_pair eksik', del_key(['kayit', 'S', 'descriptive', 'a_DC_CPL_pair']), None,
     'NOT_EVALUABLE', None),
    ('mod kimligi: T a_DC_CPL_pair eksik', del_key(['kayit', 'T', 'descriptive', 'a_DC_CPL_pair']), None,
     'NOT_EVALUABLE', None),
    # satir 3-8
    ('RET-statik (G_R,S buyuk)', setk(['S', 'G_R'], 2.0), None, 'RET-statik', None),
    ('RET-mekanizma (lam_min,S >= 0 iki satirda)', ov('S', 'lmin', (S_LO, S_HI), 0.1), None, 'RET-mekanizma', None),
    ('RET-dinamik (q_T <= q_S iki eslemede)', ov('T', 'lmin', (T_LO, T_HI), -2.0), None, 'RET-dinamik', None),
    ('BELIRSIZ (T3a karisik isaret)', chain(ov('S', 'lmin', (S_LO,), -1.0), ov('S', 'lmin', (S_HI,), 0.5)), None,
     'BELIRSIZ', lambda r: r['tests']['T3a'] == 'BELIRSIZ'),
    ('BELIRSIZ (yalniz T3b karisik)', ov('T', 'lmin', (T_LO,), -2.0), None, 'BELIRSIZ',
     lambda r: r['tests']['T3a'] == 'GEC' and r['tests']['T3b'] == 'BELIRSIZ'),
    ('KISMI-olcek (e_max,S = 0.2)', ov('S', 'lmax', (F0_ROW,), 1.2 * 1.0307764064044151), None, 'KISMI-olcek', None),
    ('SINIRDA bayragi (q_S = 0 tam)', chain(setk(['S', 'G_R'], 1.0307764064044151), setk(['T', 'lam_min'], -0.2)),
     None, 'KISMI-olcek', lambda r: any(s['compare'].startswith('T1: q_S') for s in r['sinirda'])),
]


def run_case(work, idx, case_def, base):
    name, mut, post, expect, extra = case_def
    c = copy.deepcopy(base)
    if mut:
        mut(c)
    root = os.path.join(work, 'case%02d' % idx)
    pins = write_tree(root, c)
    if post == 'corrupt_eigs':
        with open(os.path.join(root, *(ht_run._PTS + 'T_eigs.csv').split('/')), 'ab') as fh:
            fh.write(b'0\n')
    elif post == 'state_col':
        p = os.path.join(root, *(ht_run._PTS + 'T_state.csv').split('/'))
        with open(p, encoding='utf-8') as fh:
            t = fh.read().replace('x_equilibrium', 'x_eq', 1)
        with open(p, 'w', encoding='utf-8', newline='\n') as fh:
            fh.write(t)
        with open(p, 'rb') as fh:
            d = fh.read()
        pins = [(n, r, len(d), hashlib.sha256(d).hexdigest()) if r.endswith('T_state.csv') else (n, r, s, h)
                for n, r, s, h in pins]
    try:
        _, res = ht_run.evaluate(root, pins)
        got = res['verdict']
    except ht_run.Abort as e:
        res, got = dict(abort_reason=str(e)), 'ABORT'
    ok = got == expect and (extra is None or bool(extra(res)))
    return ok, got, res


def gate_tests(work, base):
    out = []
    root = os.path.join(work, 'gate')
    pins = write_tree(root, copy.deepcopy(base))
    with open(os.path.join(REAL_ROOT, *ht_run.SABIT_REL.split('/')), 'rb') as fh:
        sabit = fh.read()
    with open(os.path.join(root, *ht_run.SABIT_REL.split('/')), 'wb') as fh:
        fh.write(sabit)
    script = os.path.join(HERE, 'ht_run.py')
    rid = 'HT_20261015_a'

    def main(argv, sp=script):
        return ht_run.main(argv, root=root, pins=pins, script_path=sp)

    out.append(('kapi: yetkisiz gercek kip -> 3', main(['--run-id', rid]) == 3))
    ht_run.PARSED_PATHS.clear()
    rc = main(['--check-only'])
    out.append(('check-only -> 0 ve korlenmis S ayristirilmadi',
                rc == 0 and not any(p in ht_run.BLINDED_ROLES for p in ht_run.PARSED_PATHS)))
    rep_rel = 'cdl1/HT_kod_denetimi_v1.md'
    with open(os.path.join(root, *rep_rel.split('/')), 'w', encoding='utf-8') as fh:
        fh.write('sentetik denetim raporu\n')
    with open(os.path.join(root, *rep_rel.split('/')), 'rb') as fh:
        rep_sha = hashlib.sha256(fh.read()).hexdigest()
    with open(script, 'rb') as fh:
        s_sha = hashlib.sha256(fh.read()).hexdigest()
    yp = os.path.join(root, 'cdl1', 'HT_yetki_%s.json' % rid)

    def yetki(**kw):
        y = dict(action='ALLOW_HT_RUN', run_id=rid, sabit_sha256=ht_run.SABIT_SHA256,
                 script_sha256={'ht_run.py': s_sha}, pin_list_sha256=ht_run.pin_list_sha256(pins),
                 code_audit_report=dict(path=rep_rel, sha256=rep_sha))
        y.update(kw)
        with open(yp, 'w', encoding='utf-8') as fh:
            json.dump(y, fh)

    for label, kw in (('action yanlis', dict(action='X')), ('betik hash yanlis', dict(script_sha256={'ht_run.py': '0'})),
                      ('pin listesi hash yanlis', dict(pin_list_sha256='0')),
                      ('denetim raporu hash yanlis', dict(code_audit_report=dict(path=rep_rel, sha256='0')))):
        yetki(**kw)
        out.append(('kapi: %s -> 3' % label, main(['--run-id', rid, '--yetki', yp]) == 3))
    yetki()
    out.append(('kapi: yanlis yetki yolu -> 3',
                main(['--run-id', rid, '--yetki', os.path.join(root, 'baska.json')]) == 3))
    rc = main(['--run-id', rid, '--yetki', yp])
    od = os.path.join(root, 'cdl1', 'out', rid)
    hk = open(os.path.join(od, 'hukum.txt'), encoding='utf-8').read() if os.path.isdir(od) else ''
    out.append(('gecerli yetki -> 0, TUTARLI-T, SHA256SUMS', rc == 0 and 'TUTARLI-T' in hk
                and os.path.isfile(os.path.join(od, 'SHA256SUMS'))))
    out.append(('yeniden kosu reddi -> 3', main(['--run-id', rid, '--yetki', yp]) == 3))
    return out


def unit_tests():
    return [
        ('select_rows esitlik -> dusuk f', ht_run.select_rows([1.0, 4.0], 2.0)['nearest'] == 0
         and math.log(4.0) - math.log(2.0) == math.log(2.0) - math.log(1.0)),
        ('select_rows izgara alti -> None', ht_run.select_rows(GRID, 0.05) is None),
        ('select_rows f_c <= 0 -> None', ht_run.select_rows(GRID, 0.0) is None),
        ('f0 = 0.1 satir 0', ht_run.f0_index(GRID, 'g') == 0),
        ('SINIRDA olcegi max(1,c*)', ht_run.sinirda(1.5e-9, 2.0) and not ht_run.sinirda(1.5e-9, 1.0)),
    ]


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', required=True)
    a = ap.parse_args(argv)
    if os.path.exists(a.out) and os.listdir(a.out):
        print('--out bos olmali')
        return 1
    os.makedirs(a.out, exist_ok=True)
    base = load_base()
    allok, n = True, 0
    for i, cd in enumerate(CASES):
        ok, got, res = run_case(a.out, i, cd, base)
        n += 1
        allok &= ok
        print('%-4s %-62s beklenen=%-14s alinan=%s' % ('GEC' if ok else 'KAL', cd[0], cd[3], got))
        if not ok:
            print('     ', json.dumps(res, ensure_ascii=False)[:600])
    for name, ok in unit_tests() + gate_tests(a.out, base):
        n += 1
        allok &= bool(ok)
        print('%-4s %s' % ('GEC' if ok else 'KAL', name))
    rows = {CASES[i][3] for i in range(len(CASES))}
    need = {'ABORT', 'NOT_EVALUABLE', 'RET-statik', 'RET-mekanizma', 'RET-dinamik', 'BELIRSIZ', 'KISMI-olcek',
            'TUTARLI-T'}
    cov = need <= rows
    allok &= cov
    print('karar tablosu kapsami (8 satir): %s' % ('TAM' if cov else 'EKSIK: %s' % (need - rows)))
    print('SENTETIK TEST: %s (%d durum)' % ('GECTI' if allok else 'KALDI', n))
    return 0 if allok else 1


if __name__ == '__main__':
    sys.exit(main())
