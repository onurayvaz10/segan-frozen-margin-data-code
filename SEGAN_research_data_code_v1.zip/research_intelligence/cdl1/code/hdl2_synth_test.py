"""hdl2_run.py sentetik testi (H-DL2 SABIT s7 + U-1...U-7 + kapi/korleme/statik negatif denetimler).
Gercek PF-1 isletme noktasi hesaplanmaz: dispatch_HDL2 gercek modelde cagrilmaz, korlenmis ya da onceki sonuc
dosyasi acilmaz. Sentetik sistemler fiziksel degildir; ciktilarindaki hukumler el yapimi girdilere aittir.

Bolumler
  A  S5 bilinen yanitlari (E1 notu Ornek B, C) + negatif: hatali (1 - ic) bicimi S5'te KALIR.
  B  sentetik 7 durumlu sistem ailesi (bara + izotrop/anizotrop kaynak + gecikmeli ideal CPL) ile tam boru hatti:
     asama sirasi (secim referanstan once), kappa_tam ~ kappa_fd (H-AKT), DG*_t ~ DG*_t,port (P3 yok),
     DG*_t ~ DG*_f/(1 - kappa), karar satiri.
  C  bilerek bozulmus durumlar: S1 (ilk uye ABORT; sonraki uye K3' NE), S2 (ABORT), S3 (U-1 kL != 1: ilk uye
     ABORT; sonraki uye S3-NE), S4 (ABORT), S5 (ABORT).
     v2 (HDL2-B3 B-1): kappa'li ilk uye K2 KAL + S3 bozuk -> ABORT yok, S3-NE; sonra K1-K3'u gecen ilk uyede
     S3 bozuk -> ABORT. K1-K3 gecen ama S3 degerlendirilemeyen (K4 KAL) ilk uye isareti tuketmez.
  v2 ekleri: B sonunda N-1 (izleme kaybinda P7 degil P7_izlemesiz), C sonunda N-2 (_jsonable sonsuz/NaN).
  D  U-3 (cond(Y_tot) ~ 1e10'da S1 sahte ABORT vermez), U-4 (refine istisnasi -> K1 NE-x0).
  E  karar tablosunun 10 satiri (1 = C'de ABORT; 2-9, 8a/8b) ve (a)-(e) alt sinamalari, 2x2 ornek kappa'lariyla.
  F  H-AKT KAL yollari (izleme-KAL, H-AKT-Newton): satir 3, secim.json yazilmaz, asama 3 kosmaz; n_E < 5 -> satir 2.
  G  K7: monoton olmayan dondurulmus alpha(DG) erken pencereyi yakalar; 'sifir' -> K7-cozunurluk; monoton -> GEC.
  H  omega = 0 adayi kazanir -> K5-omega0.
  I  model yapisi (--skip-model ile atlanir): pin dogrulama + import + S3 modeli; sentetik x'te (denge degil)
     |b| = 2, |l| = 12, |sigma| = 18, kL = 1 (U-1), J ile J~ yalniz z = h(x) bagimli sutunda farkli (N-e),
     S4 yapisi.
  J  kapi: check-only (gercek kok; model import edilmez), pin ABORT, yetki reddi, yeniden kosu reddi.
  K  hdl2_static_check negatif denetimleri: mutasyonlu kopyalar ilgili denetimde KALIR.
Kullanim: python -I hdl2_synth_test.py --out <bos klasor> [--skip-model]
Cikis: 0 = tum durumlar GECTI, 1 = en az biri KALDI.
"""
import argparse
import hashlib
import json
import math
import os
import shutil
import sys
import time
import traceback

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import hdl2_run as H  # noqa: E402
import hdl2_static_check as SC  # noqa: E402

REAL_ROOT = os.path.dirname(os.path.dirname(HERE))
RESULTS = []
JP = np.array([[0.0, 1.0], [-1.0, 0.0]])
OK_LIM = 'saglaniyor'


def record(name, ok, detail=''):
    RESULTS.append((name, bool(ok), detail))


class Patch:
    """H modulunde gecici degisiklik (yalniz test; uretim kodu degismez)."""

    def __init__(self, **kw):
        self.kw, self.old = kw, {}

    def __enter__(self):
        for k, v in self.kw.items():
            self.old[k] = getattr(H, k)
            setattr(H, k, v)

    def __exit__(self, *a):
        for k, v in self.old.items():
            setattr(H, k, v)


# ------------------------------------------------------------------ sentetik sistemler
class SynthSystem:
    """7 durum: [theta(ref), V_R, V_I, is_R, is_I, iL_R, iL_I]. Bara: M_b dV/dt = i_s - kL i_L - G V + b2 z J'V;
    kaynak: M_s di_s/dt = E e_d - Z_s i_s - V, Z_s = Rs I + Xs J_E + aniso N; yuk: M_l di_L/dt = P V/|V|^2 - i_L.
    z = h(x) = 1 + zc*is_R (zc = 0: J = J~). Fiziksel degil."""

    def __init__(self, P=0.15, E=1.0, Rs=0.01, Xs=0.0, mb=0.5, ms=0.05, ml=0.05, kL=1.0, b2=0.005, zc=0.0, aniso=0.0,
                 g_sq=0.0, newton_only_at=None, alpha_bias=0.0):
        self.P, self.E, self.kL, self.b2, self.zc, self.g_sq = P, E, kL, b2, zc, g_sq
        self.alpha_bias = alpha_bias  # v2: > 0 -> K2 KAL (yalniz alpha; J, lokus, kappa degismez)
        self.newton_only_at = newton_only_at
        self.n, self.i_theta = 7, 0
        self.keep = [1, 2, 3, 4, 5, 6]
        self.b, self.sig, self.l = [1, 2], [3, 4], [5, 6]
        self.i_load_cur = (5, 6)
        self.M = np.array([1.0, mb, mb, ms, ms, ml, ml])
        self.trz = True
        self.net = dict(r=0.01, x=0.1, b_to=0.005, wb=2 * math.pi * 60)
        self.TH = dict(L1=1.0, L2=1.0, L3=(0.88, 1.10), L4=(0.98, 1.02), m_max=1.0)
        self.Zs = Rs * np.eye(2) + Xs * H.J_E + aniso * H.N_X

    def h(self, x):
        return 1.0 + self.zc * x[3]

    def ft(self, x, z, G):
        V, i_s, iL = x[1:3], x[3:5], x[5:7]
        f = np.zeros(7)
        f[1:3] = i_s - self.kL * iL - (G + self.g_sq * G * G) * V + self.b2 * z * JP @ V
        f[3:5] = np.array([self.E, 0.0]) - self.Zs @ i_s - V
        f[5:7] = self.P * V / (V @ V) - iL
        return f

    def f(self, x, G):
        return self.ft(x, self.h(x), G)

    def _jz(self, x, z, G):
        V = x[1:3]
        J = np.zeros((7, 7))
        J[1:3, 1:3] = -(G + self.g_sq * G * G) * np.eye(2) + self.b2 * z * JP
        J[1:3, 3:5] = np.eye(2)
        J[1:3, 5:7] = -self.kL * np.eye(2)
        J[3:5, 3:5] = -self.Zs
        J[3:5, 1:3] = -np.eye(2)
        v2 = V @ V
        u = V / math.sqrt(v2)
        J[5:7, 1:3] = self.P * (np.eye(2) - 2 * np.outer(u, u)) / v2
        J[5:7, 5:7] = -np.eye(2)
        return J

    def Jt(self, x, G):
        return self._jz(x, self.h(x), G)

    def J(self, x, G):
        J = self._jz(x, self.h(x), G)
        J[1:3, 3] += self.zc * self.b2 * (JP @ x[1:3])
        return J

    def newton(self, x, G):
        if self.newton_only_at is not None and G != self.newton_only_at:
            return dict(x=np.array(x, dtype=float), converged=False, n_iter=0, res=1.0)
        x = np.array(x, dtype=float)
        F = self.f(x, G)
        r, it, stop = float(np.max(np.abs(F))), 0, None
        for _ in range(30):
            if r <= 1e-12:
                break
            try:
                dx = np.linalg.solve(self.J(x, G)[np.ix_(self.keep, self.keep)], -F[self.keep])
            except np.linalg.LinAlgError:
                stop = 'singular'
                break
            xn = x.copy()
            xn[self.keep] += dx
            Fn = self.f(xn, G)
            rn = float(np.max(np.abs(Fn)))
            if not (np.isfinite(rn) and rn < r):
                stop = 'stagnation'
                break
            x, F, r = xn, Fn, rn
            it += 1
        return dict(x=x, converged=bool(r <= 1e-12 or (r <= 1e-8 and stop == 'stagnation')), n_iter=it, res=r)

    def alpha(self, x, G):
        A = self.J(x, G) / self.M[:, None]
        lam = np.linalg.eigvals(A[np.ix_(self.keep, self.keep)])
        return float(np.max(lam.real)) + self.alpha_bias, A

    def limits(self, x, G):
        V = math.hypot(x[1], x[2])
        return dict(limits=dict(L1=dict(value=0.5, status=OK_LIM), L2=dict(value=0.5, status=OK_LIM),
                                L3=dict(V_101=1.0, V_102=V, status=OK_LIM), L4=dict(value=1.0, status=OK_LIM),
                                L5=dict(value=-0.1, status=OK_LIM), L6=dict(value=0.0, status=OK_LIM)))

    def dispatch(self, G):
        x = np.zeros(7)
        x[1], x[3], x[5] = 1.0, self.P + G, self.P
        saved, self.newton_only_at = self.newton_only_at, None
        r = self.newton(x, G)
        self.newton_only_at = saved
        return dict(ok=r['converged'], x0=r['x'], rho=np.zeros(5), reason=None if r['converged'] else 'K1: nc')


def synth_specs(anisos=(0.0, 0.005), Ps=(0.15, 0.2), Gs=(0.25, 0.15)):
    out = []
    for a in anisos:
        for p in Ps:
            for g in Gs:
                out.append(dict(setting='A%g' % a, P_akt=p, G_R=g, id='a%g_P%g_G%g' % (a, p, g), aniso=a))
    return out


def synth_builder(**over):
    per = over.pop('per_member', {})

    def build(spec):
        kw = dict(P=spec['P_akt'], aniso=spec['aniso'])
        kw.update(over)
        kw.update(per.get(spec['id'], {}))
        s = SynthSystem(**kw)
        d = s.dispatch(spec['G_R'])
        if 'newton_only_at' in kw:
            s.newton_only_at = spec['G_R']
        return (s if d['ok'] else None), d
    return build


def sha_json(obj):
    return hashlib.sha256(json.dumps(H._jsonable(obj), sort_keys=True).encode('utf-8')).hexdigest()


def run_synth(specs, build):
    ev = []
    R = H.run_family(specs, build, sha_json, lambda s: None, ev)
    return R, ev


def expect_abort(name, fn, needle):
    try:
        fn()
        record(name, False, 'Abort yok')
    except H.Abort as e:
        record(name, needle in str(e), str(e))


# ------------------------------------------------------------------ A
def section_A():
    s5 = H.s5_probe()
    record('A S5 bilinen yanitlar (B, C x4, pi_x = -3/sqrt10)', s5['passed'] and len(s5['rows']) == 5,
           [round(r.get('k_L', 0), 6) for r in s5['rows']])
    rb = s5['rows'][0]
    record('A S5 Ornek B kappa_L = -1/(2 sqrt3), kappa_theta = 0',
           abs(rb['k_L'] + 1 / (2 * math.sqrt(3))) < 1e-12 and abs(rb['k_theta']) < 1e-12, rb)
    wrong = lambda c, z: float(((1.0 - 1j * c) * z).real)  # noqa: E731  (Z-1 hatali bicim)
    with Patch(kap=wrong):
        s5w = H.s5_probe()
    record('A S5 hatali (1 - ic) bicimi KALIR', not s5w['passed'], [r['passed'] for r in s5w['rows']])
    with Patch(kap=wrong):
        expect_abort('A S5 hatali bicimde run_family ABORT', lambda: run_synth(synth_specs()[:1], synth_builder()),
                     'S5')


# ------------------------------------------------------------------ B
def section_B():
    specs = synth_specs(anisos=(0.0, 0.005), Ps=(0.15, 0.2), Gs=(0.25, 0.15))[:6]
    t = time.time()
    R, ev = run_synth(specs, synth_builder())
    E = [m for m in R['members'] if m['in_E']]
    record('B 6 uyenin hepsi E (K1-K7 + S1-S4)', len(E) == 6, [(m['id'], m['ne_reason']) for m in R['members']])
    record('B asama sirasi: asama1 < secim < asama3 < ref:* < karar',
           ev.index('asama1') < ev.index('secim') < ev.index('asama3') < min(i for i, e in enumerate(ev)
                                                                         if e.startswith('ref:')) < ev.index('karar'),
           ev)
    record('B secim.json sha256 kaydi', R['secim_sha256'] == sha_json(R['selection']), R['secim_sha256'])
    hk = [(m['id'], m['kappa']['k_tam'], m['HAKT']['k_fd']) for m in E]
    record('B H-AKT: kappa_tam ~ kappa_fd (bagil <= 1e-3)',
           all(m['HAKT']['status'] == H.GEC for m in E)
           and all(abs(a - b) <= 1e-3 * max(abs(b), 1e-12) for _, a, b in hk), hk)
    iso = [m for m in E if m['setting'] == 'A0']
    ani = [m for m in E if m['setting'] != 'A0']
    record('B izotrop kaynakta kappa_theta ~ 0, anizotropta != 0',
           all(abs(m['kappa']['k_theta']) < 1e-10 for m in iso) and all(abs(m['kappa']['k_theta']) > 1e-6
                                                                         for m in ani),
           [(m['id'], m['kappa']['k_theta']) for m in E])
    record('B S3 iki yol esit (Y_x = 0 sisteminde)', all(m['kappa']['S3']['passed'] for m in E),
           [m['kappa']['S3']['diff'] for m in E])
    rf = [(m['id'], m['ref']['dGt'], m['ref']['dGt_port'], m['dGf'] / (1 - m['kappa']['k_tam'])) for m in E]
    record('B referans: alpha kaybi ~ port kaybi ~ DG*_f/(1-kappa) (<= 1e-3 DG*_f), P3 yok',
           all(m['ref']['loss'] == 'alpha' and not m['ref']['labels']['P3'] for m in E)
           and all(abs(a - b) <= 1e-3 * m['dGf'] and abs(a - c) <= 1e-3 * m['dGf']
                   for (_, a, b, c), m in zip(rf, E)), rf)
    record('B rakip 5 hesaplandi (100 adim)', all(m['rival5']['ok'] and m['rival5']['n_steps'] >= 100 for m in E),
           [m['rival5']['F5'] for m in E])
    record('B karar satiri 4 (|DG*_t - DG*_f|/DG*_f < delta_dec, kucuk kappa)',
           R['decision_row'] == 4 and R['verdict'] == 'H-DL2-ONEMSIZ', (R['decision_row'], R['verdict'],
                                                                         round(time.time() - t, 1)))
    txt = H.members_csv(R['members'])
    record('B uyeler.csv: 6 satir + baslik, L marjlari (U-5)', txt.count('\n') == 7 and 'L5_margin' in txt.split('\n')[0],
           txt.split('\n')[0][:80])
    js = json.dumps(H._jsonable(R), ensure_ascii=False)
    record('B sonuc JSON serilestirilebilir; _x0 yok', '_x0' not in js and '"members"' in js, len(js))
    # v2 N-1: izleme her noktada kaybedilirse P7 degerlendirilmez; Y2 ilk izgara noktasinda; P7_izlemesiz rapor
    m = E[0]
    sysm, _ = synth_builder()(dict(specs[0]))
    with Patch(track=lambda *a: None):
        rf1 = H.reference(sysm, m['_x0'], m['G_R'], m['dGf'], m['_crit'])
    g1 = H.ref_grid(m['G_R'], m['dGf'])[0][1]
    lb = rf1['labels']
    record('B v2 N-1: izleme kaybinda P7 None, Y2 = ilk nokta, P7_izlemesiz anahtari var',
           lb['P7'] is None and lb['Y2'] == g1 and 'P7_izlemesiz' in lb
           and (lb['P7_izlemesiz'] is None or lb['P7_izlemesiz'] > 0), lb)
    record('B v2 N-1: izleme varken P7_izlemesiz None (normal tarama)',
           all(e['ref']['labels']['P7_izlemesiz'] is None for e in E), [e['ref']['labels'] for e in E][:2])
    return R


# ------------------------------------------------------------------ C
def section_C():
    specs = synth_specs()
    # S1
    real_y = H.y_port

    def bad_y(pp, s):
        return 1.01 * real_y(pp, s)
    with Patch(y_port=bad_y):
        expect_abort('C S1 bozuk (ilk uye) -> ABORT', lambda: run_synth(specs[:1], synth_builder()), 'S1 ilk uyede')
    state = dict(n=0)

    def bad_y_second(pp, s):
        return (1.01 if state['n'] == 2 else 1.0) * real_y(pp, s)
    base = synth_builder()

    def counting(spec):
        state['n'] += 1
        return base(spec)
    with Patch(y_port=bad_y_second):
        R, ev = run_synth(specs[:2], counting)
    m2 = R['members'][1]
    record("C S1 bozuk (ikinci uye) -> o uye K3' NE, ABORT yok",
           R['members'][0]['in_E'] and not m2['in_E'] and m2['gates']['K3p']['status'] == H.KAL
           and R['decision_row'] == 2, m2['ne_reason'])
    # S2
    real_probe = H.y_probe

    def bad_probe(net, th, G, P, V, w):
        return real_probe(net, th, G, P, V, w) + 0.05 * H.N_X
    with Patch(y_probe=bad_probe):
        expect_abort('C S2 bozuk (anizotrop sonda) -> ABORT', lambda: run_synth(specs[:1], synth_builder()), 'S2')
    # S3 (U-1)
    expect_abort('C S3 kL = 1.2 (U-1) ilk uye -> ABORT', lambda: run_synth(specs[:1], synth_builder(kL=1.2)),
                 'S3 ilk')
    R, ev = run_synth(specs[:2], synth_builder(per_member={specs[1]['id']: dict(kL=1.2)}))
    m2 = R['members'][1]
    record('C S3 kL = 1.2 ikinci uye -> S3-NE etiketi, kappa_tam korunur',
           'S3-NE' in m2['labels'] and m2['in_E'] and m2['kappa']['k_tam'] is not None, m2['labels'])
    record('C kL koşu basinda raporlanir (U-1)', abs(m2['kappa']['kL'] - 1.2) < 1e-15 and
           abs(R['members'][0]['kappa']['kL'] - 1.0) < 1e-15, (m2['kappa']['kL'],))
    # v2 B-1: kappa'li ilk uye K2 KAL + S3 bozuk -> ABORT yok, S3-NE; sonraki K1-K3 uyesinde S3 bozuk -> ABORT
    bias = {specs[0]['id']: dict(kL=1.2, alpha_bias=1.0)}
    R, ev = run_synth(specs[:1], synth_builder(per_member=bias))
    m1 = R['members'][0]
    record('C v2 B-1: K2 KAL uyede S3 bozuk -> ABORT yok, S3-NE, kappa hesaplandi',
           m1['gates']['K2']['status'] == H.KAL and m1['gates']['K6']['status'] == H.GEC
           and 'S3-NE' in m1['labels'] and not m1['kappa']['S3']['passed'] and not m1['in_E'],
           (m1['ne_reason'], m1['labels']))
    bias2 = dict(bias)
    bias2[specs[1]['id']] = dict(kL=1.2)
    expect_abort('C v2 B-1: K2 KAL uyeden sonra K1-K3 gecen ilk uyede S3 bozuk -> ABORT',
                 lambda: run_synth(specs[:2], synth_builder(per_member=bias2)), 'S3 ilk K1-K3 uyesinde basarisiz: '
                 + specs[1]['id'])
    bias3 = dict(bias)
    bias3[specs[1]['id']] = dict()
    bias3[specs[2]['id']] = dict(kL=1.2)
    R, ev = run_synth(specs[:3], synth_builder(per_member=bias3))
    m3 = R['members'][2]
    record('C v2 B-1: K1-K3 gecen ilk uyede S3 gectikten sonra bozuk S3 -> S3-NE (ABORT yok)',
           R['members'][1]['in_E'] and 'S3-NE' in m3['labels'] and m3['in_E'], m3['labels'])
    # K1-K3 gecen ama S3 degerlendirilemeyen (K4 KAL: ilk lokus cagrisinda aday yok) ilk uye isareti tuketmez
    real_locus = H.locus
    lstate = dict(n=0)

    def locus_first_empty(pp, *a, **k):
        lstate['n'] += 1
        out = real_locus(pp, *a, **k)
        return dict(out, cands=[]) if lstate['n'] == 1 else out
    with Patch(locus=locus_first_empty):
        expect_abort('C v2 B-1: K4 KAL (S3 yok) K1-K3 uyesinden sonra S3 bozuk -> ABORT',
                     lambda: run_synth(specs[:2], synth_builder(per_member={specs[1]['id']: dict(kL=1.2)})),
                     'S3 ilk K1-K3 uyesinde basarisiz: ' + specs[1]['id'])
    lstate['n'] = 0
    with Patch(locus=locus_first_empty):
        Rs, _ = run_synth(specs[:1], synth_builder())
    ms = Rs['members'][0]
    record('C v2 B-1 on kosul: ilk uye K1-K3 GEC, K4 KAL, kappa yok',
           all(ms['gates'][k]['status'] == H.GEC for k in ('K1', 'K2', 'K3'))
           and ms['gates']['K4']['status'] == H.KAL and ms.get('kappa') is None, ms['ne_reason'])
    # S4
    expect_abort('C S4 G_R dogrusal degil -> ABORT', lambda: run_synth(specs[:1], synth_builder(g_sq=0.3)), 'S4')
    # v2 N-2: _jsonable sonsuz/NaN numpy skalerleri
    jv = H._jsonable(dict(a=np.float64('inf'), b=np.float64('nan'), c=np.float32(1.5), d=np.int64(3),
                          e=float('-inf')))
    try:
        json.dumps(jv, allow_nan=False)
        okj = True
    except ValueError:
        okj = False
    record('C v2 N-2: _jsonable np.floating inf/nan -> dizge; allow_nan=False ile serilesir',
           okj and jv['a'] == 'inf' and jv['b'] == 'nan' and jv['c'] == 1.5 and jv['d'] == 3 and jv['e'] == '-inf',
           jv)


# ------------------------------------------------------------------ D
def section_D():
    # U-3: Y_tot = diag(1, 1e-10) (M_b = 0, J_br = 0), r tek durum
    J = np.zeros((4, 4))
    J[1, 1], J[2, 2], J[3, 3] = -1.0, -1e-10, -1.0
    M = np.array([1.0, 0.0, 0.0, 0.01])
    s1 = H.s1_probe(J, M, [1, 2, 3], [1, 2])
    record('D U-3 cond(Y_tot) ~ 1e10: S1 sahte ABORT vermez', s1['passed'] and
           all(r['cond_Y'] > 1e9 for r in s1['rows']), [(r['d_log'], r['tol']) for r in s1['rows']])
    J2 = J.copy()
    J2[1, 2] = 0.3
    J2[3, 1] = 0.7
    J2[1, 3] = 0.2
    s1b = H.s1_probe(J2, M, [1, 2, 3], [1, 2])
    record('D S1 dogru uygulamada genel J ile gecer', s1b['passed'], [r['d_log'] for r in s1b['rows']])

    # U-4: refine istisnasi -> K1 NE-x0
    class DE(Exception):
        pass

    class FakeEC:
        DispatchError = DE

        @staticmethod
        def power_flow(P, G, net):
            return dict(converged=True, mismatch=0.0, V2=complex(1.0, 0.0))

        @staticmethod
        def load_init(P0, V2, load):
            return dict(Vref_dc=1.0, Iq_ref=0.0)

        @staticmethod
        def newton_theta_fixed(model, x, rho, G):
            return dict(x=x, converged=True, res=0.0, n_iter=0, criterion='tol')

    class FakeModel:
        net = dict(Sbase=100.0)
        load = dict(base_power=100.0)

    class FakeDisp:
        def __init__(self, exc):
            self.exc = exc

        def _assemble(self, pf, li):
            return np.zeros(3), dict(p_e=0.0, q_e=0.0, v_refr=1.0)

        def refine(self, x, rho, G, kind):
            raise self.exc('sentetik')
    for exc in (np.linalg.LinAlgError, ValueError, ZeroDivisionError, DE):
        rec = H.dispatch_HDL2(FakeEC, FakeModel, FakeDisp(exc), 0.65, 0.25)
        record('D U-4 refine %s -> K1 NE-x0' % exc.__name__, not rec['ok'] and rec['reason'].startswith('K1: ')
               and exc.__name__ in rec['reason'], rec['reason'])
    try:
        H.dispatch_HDL2(FakeEC, FakeModel, FakeDisp(KeyError), 0.65, 0.25)
        record('D U-4 beklenmeyen istisna yukari cikar (tek kosuyu tuketir)', False)
    except KeyError:
        record('D U-4 beklenmeyen istisna yukari cikar (tek kosuyu tuketir)', True)
    st = H.stage1_member(dict(setting='X', P_akt=0.65, G_R=0.25, id='x'), None,
                         dict(ok=False, reason='K1: LinAlgError: sentetik'), dict(s1_first_done=False,
                                                                                  s3_first_done=False))
    record('D K1 NE uye kaydi', not st['in_E'] and st['ne_reason'].startswith('K1'), st['ne_reason'])


# ------------------------------------------------------------------ E
KC_D3 = dict(k_V=0.5270462766947299, k_L=-0.4216370213557839)    # E1 notu Ornek C, d0 = 3
KC_D0 = dict(k_V=2.0 / 3.0, k_L=2.0 / 3.0)                       # Ornek C, d0 = 0
KB = dict(k_V=-1.0 / (2.0 * math.sqrt(3.0)), k_L=-1.0 / (2.0 * math.sqrt(3.0)))   # Ornek B


def mk(i, k_tam, kv=None, G=0.25, dGf=0.1, dGt=None, censored=False, pred=None):
    kv = kv or dict(k_V=k_tam, k_L=k_tam)
    if dGt is None and not censored:
        dGt = dGf / (1.0 - k_tam) if k_tam < 1 else 2 * dGf
    tie = H.TIE_K * dGf
    ref = dict(dGt=dGt, censored=censored, dgmax_is_GR=bool(G <= 2 * dGf), tie=tie)
    sg = 1 if censored else (0 if abs(dGt - dGf) <= tie else (1 if dGt > dGf else -1))
    return dict(id='m%02d' % i, G_R=G, dGf=dGf, kappa=dict(k_tam=k_tam, k_L=kv['k_L'], k_V=kv['k_V']), ref=ref,
                rival5=dict(ok=True, pred=sg if pred is None else pred, F5=0.0, n_steps=100, n_newton=200))


def run_tests(E):
    sel = H.selection(E)
    T = H.evaluate_tests(E, sel)
    return H.decide(len(E), [], T), T, sel


def section_E():
    record('E satir 2 (n_E = 4 < 5)', H.decide(4, [], None)[0] == 2, H.decide(4, [], None))
    record('E satir 3 (H-AKT KAL)', H.decide(5, ['m00'], None)[0] == 3, H.decide(5, ['m00'], None)[1])
    # satir 4: farklar < delta_dec
    E = [mk(i, 0.01) for i in range(5)]
    d, T, _ = run_tests(E)
    record('E satir 4 H-DL2-ONEMSIZ', d[0] == 4 and T['d']['onemsiz'], d)
    # satir 5: |k_tam| < tau, fark >= delta_dec
    E = [mk(i, 0.04, dGt=0.12) for i in range(5)]
    d, T, _ = run_tests(E)
    record('E satir 5 H-DL2-ESIK-ALTI', d[0] == 5, d)
    # satir 6: (a-tam) uyusmazlik
    E = [mk(i, 0.3) for i in range(4)] + [mk(4, -0.3, dGt=0.12)]
    d, T, _ = run_tests(E)
    record('E satir 6 H-DL2-RET-kural', d[0] == 6 and T['a_tam']['mismatches'] == ['m04']
           and T['a_tam']['n_mismatch_optimistic'] == 1, (d, T['a_tam']))
    # satir 7: (a-tam) tutarli, (a-L) uyusmaz (Ornek C d0 = 3: k_V > 0, k_L < 0)
    E = [mk(i, 0.3, KC_D0) for i in range(4)] + [mk(4, 0.3, KC_D3)]
    d, T, _ = run_tests(E)
    record('E satir 7 H-DL2-RET-mekanizma ((a-L) uyusmazlik)', d[0] == 7 and T['a_L']['mismatches'] == ['m04'], d)
    E = [mk(i, 0.3, dict(k_V=0.01, k_L=0.01)) for i in range(5)]
    d, T, _ = run_tests(E)
    record('E satir 7 (|k_L| >= tau uye yok)', d[0] == 7 and T['a_L']['n'] == 0, d)
    # satir 8a: yalniz muhafazakar
    E = [mk(i, 0.3, KC_D0) for i in range(5)]
    d, T, sel = run_tests(E)
    record('E satir 8a H-DL2-TEK-YON[-] (s- yok)', d[0] == '8a' and sel['s_minus'] is None, (d, sel['s_plus']))
    # satir 8b: yalniz iyimser
    E = [mk(i, KB['k_L'], KB) for i in range(5)]
    d, T, sel = run_tests(E)
    record('E satir 8b H-DL2-TEK-YON[+] (s+ yok)', d[0] == '8b' and sel['s_plus'] is None, (d, sel['s_minus']))
    # satir 9: iki yon, tutarli
    E = [mk(0, 0.3, KC_D0), mk(1, 0.2, dict(k_V=0.2, k_L=0.7)), mk(2, KB['k_L'], KB),
         mk(3, -0.42, dict(k_V=-0.4, k_L=-0.42)), mk(4, 0.1)]
    d, T, sel = run_tests(E)
    record('E satir 9 H-DL2-TUTARLI; s+ = argmax k_L, s- = argmin k_L', d[0] == 9 and sel['s_plus'] == 'm01'
           and sel['s_minus'] == 'm03' and T['b']['status'] == H.GEC, (d, sel['s_plus'], sel['s_minus']))
    # esitlikte s4.2 sirasinda ilk uye
    E = [mk(0, 0.3, KC_D0), mk(1, 0.3, KC_D0), mk(2, KB['k_L'], KB), mk(3, KB['k_L'], KB), mk(4, 0.1)]
    sel = H.selection(E)
    record('E secim esitlikte ilk uye', sel['s_plus'] == 'm00' and sel['s_minus'] == 'm02', sel)
    # (b')
    def bp(signs):
        E = [mk(i, 0.1) for i in range(3)]
        for j, s in enumerate(signs):
            dGt = 0.1 / (1 + 0.4) if s < 0 else 0.1 / (1 - 0.4)
            E.append(mk(3 + j, -0.42, KC_D3, dGt=dGt))
        return H.evaluate_tests(E, H.selection(E))['b_prime']['status']
    record("E (b') GEC (referans k_L ile)", bp([-1, -1]) == H.GEC, bp([-1, -1]))
    record("E (b') YANLISLANDI (referans k_V ile)", bp([1, 1]) == 'YANLISLANDI', bp([1, 1]))
    record("E (b') BELIRSIZ (karisik)", bp([-1, 1]) == H.BEL, bp([-1, 1]))
    record("E (b') NE (D bos)", bp([]) == H.NE, bp([]))
    # (c)
    def cst(kind):
        E = []
        for i in range(4):
            k = 0.3
            f = 0.03
            if kind == 'GEC' or (kind == 'KISMI' and i < 2):
                t = f / (1 - k)
            else:
                t = f * (1 - 0.5)
            E.append(mk(i, k, G=0.25, dGf=f, dGt=t))
        E.append(mk(9, 0.0, G=0.25, dGf=0.2))
        return H.evaluate_tests(E, H.selection(E))['c']['status']
    record('E (c) GEC', cst('GEC') == H.GEC, cst('GEC'))
    record('E (c) KAL', cst('KAL') == H.KAL, cst('KAL'))
    record('E (c) KISMI', cst('KISMI') == 'KISMI', cst('KISMI'))
    E = [mk(i, 0.3, G=0.25, dGf=0.03) for i in range(2)] + [mk(5, 0.0, dGf=0.2) for _ in range(3)]
    record('E (c) NE (|C| < 3)', H.evaluate_tests(E, H.selection(E))['c']['status'] == H.NE)
    E = [mk(i, 0.3, G=0.25, dGf=0.03) for i in range(3)] + [mk(5 + i, 0.3, G=0.25, dGf=0.03, censored=True)
                                                           for i in range(4)]
    record('E (c) NE (kucuk-DG bolgesinin yarisindan fazlasi sansurlu)',
           H.evaluate_tests(E, H.selection(E))['c']['status'] == H.NE)
    # (d) d-belirsiz ve sansur-sinirda
    E = [mk(i, 0.01) for i in range(4)] + [mk(4, 0.01, G=0.1001, dGf=0.1, censored=True)]
    d, T, _ = run_tests(E)
    m = E[4]
    record('E (d) sansur-sinirda BERABERE + d-belirsiz -> ONEMSIZ degil (satir 5)',
           m['ref_sign'] == 0 and m['sansur_sinirda'] and m['d_belirsiz'] and not T['d']['onemsiz'] and d[0] == 5,
           (m['ref_sign'], T['d'], d[0]))
    E = [mk(i, 0.01) for i in range(4)] + [mk(4, 0.01, G=0.104, dGf=0.1, censored=True)]
    d, T, _ = run_tests(E)
    m = E[4]
    record('E (d) sansurlu, G_R < 1.05 DG*_f: isaret +, d-belirsiz', m['ref_sign'] == 1 and m['d_belirsiz']
           and not T['d']['onemsiz'], (m['ref_sign'], T['d']['d_belirsiz']))
    E = [mk(i, 0.3, KC_D0) for i in range(4)] + [mk(4, 0.3, KC_D0, G=0.25, dGf=0.1, censored=True)]
    d, T, _ = run_tests(E)
    record('E sansurlu (DG_max = 2 DG*_f) isaret + sayilir', E[4]['ref_sign'] == 1 and not E[4]['d_belirsiz'], d)
    # BERABERE uyusmazlik sayilir
    E = [mk(i, 0.3, KC_D0) for i in range(4)] + [mk(4, 0.3, KC_D0, dGt=0.1001)]
    d, T, _ = run_tests(E)
    record('E BERABERE (a)da uyusmazlik', d[0] == 6 and 'm04' in T['a_tam']['mismatches'], d)
    # (e)
    E = [mk(0, 0.3, KC_D0), mk(1, 0.2, dict(k_V=0.2, k_L=0.7), pred=-1), mk(2, KB['k_L'], KB),
         mk(3, -0.42, dict(k_V=-0.4, k_L=-0.42)), mk(4, 0.1)]
    T = H.evaluate_tests(E, H.selection(E))
    record('E (e) oranlar ve ikinci denge sayilari', T['e']['rival5_E'] == dict(n=5, agree=4)
           and T['e']['S3_tam_E']['agree'] == 5 and T['e']['second_equilibria']['S3'] == 0
           and 'T-4' in T['e']['note'], T['e']['rival5_E'])


# ------------------------------------------------------------------ F
def section_F():
    specs = synth_specs()[:6]
    with Patch(TRACK_DW=1e-15):
        R, ev = run_synth(specs, synth_builder())
    record('F izleme-KAL -> satir 3, secim/asama 3 yok',
           R['decision_row'] == 3 and 'secim' not in ev and not any(e.startswith('ref:') for e in ev)
           and R['selection'] is None and all(m['HAKT']['reason'] == 'izleme-KAL' for m in R['members']), ev)
    R, ev = run_synth(specs, synth_builder(newton_only_at=True))
    record('F H-AKT-Newton -> satir 3, secim/asama 3 yok',
           R['decision_row'] == 3 and 'secim' not in ev and R['n_E'] == 6
           and all(m['HAKT']['reason'] == 'H-AKT-Newton' for m in R['members']), [m['HAKT'] for m in R['members']])
    R, ev = run_synth(specs[:3], synth_builder())
    record('F n_E = 3 < 5 -> satir 2, asama 3 yok', R['decision_row'] == 2 and 'secim' not in ev, R['verdict'])


# ------------------------------------------------------------------ G
class AlphaStub:
    def __init__(self, G, dGf, window=None, zero_at=None):
        self.G, self.dGf, self.window, self.zero_at = G, dGf, window, zero_at

    def alpha(self, x, Gp):
        dg = self.G - Gp
        a = -1.0 + dg / self.dGf
        if self.window and self.window[0] * self.dGf <= dg <= self.window[1] * self.dGf:
            a = 0.5
        if self.zero_at is not None and abs(dg - self.zero_at * self.dGf) < 1e-12:
            a = 0.0
        return a, None


def section_G():
    G, f = 0.25, 0.1
    k = H.k7_check(AlphaStub(G, f), None, G, f, 1e-6)
    # stub'da alpha = -1 + DG/DG*_f; 'kararli' siniri alpha < -alpha_tab (1e-6) -> DG*_f (1 - 1e-6)
    record('G K7 monoton -> GEC, DG*_f,ss ~ DG*_f (1 - alpha_tab)', k['passed']
           and abs(k['dGf_ss'] - f * (1 - 1e-6)) <= 1e-6 * f, k['dGf_ss'])
    k = H.k7_check(AlphaStub(G, f, window=(0.40, 0.45)), None, G, f, 1e-6)
    record('G K7 erken kararsizlik penceresi -> K7-uyumsuz (ii)', (not k['passed']) and k['reason'] == 'K7-uyumsuz'
           and k['cond_i'] and not k['cond_ii'] and k['grid_first_not_stable'] == 81, k['grid_first_not_stable'])
    k = H.k7_check(AlphaStub(G, f, zero_at=0.5 * (1 - H.TAU7)), None, G, f, 1e-6)
    record('G K7 sifir sinifi -> K7-cozunurluk', (not k['passed']) and k['reason'] == 'K7-cozunurluk', k['reason'])
    k = H.k7_check(AlphaStub(G, 2 * f), None, G, f, 1e-6)
    record('G K7 (i) saglanmaz -> K7-uyumsuz', (not k['passed']) and not k['cond_i'], k['class_hi'])
    record('G alpha_class tanimsiz/sifir/kararli/kararsiz',
           [H.alpha_class(a, 1e-3) for a in (None, 0.0, -1.0, 1.0)] == ['tanimsiz', 'sifir', 'kararli', 'kararsiz'])


# ------------------------------------------------------------------ H
class W0Stub(SynthSystem):
    """Dogrusal 5 durum: [theta, V_R, V_I, r1, r2]; Y_tot(jw) = jw m_b I + D, D = diag(0.1, 0.5) G = 0.25'te."""

    def __init__(self):
        super().__init__()
        self.n, self.keep = 5, [1, 2, 3, 4]
        self.b, self.l, self.sig, self.i_load_cur = [1, 2], [3, 4], [], (3, 4)
        self.M = np.array([1.0, 0.5, 0.5, 0.1, 0.1])
        self.xs = np.array([0.0, 1.0, 0.0, 0.1, 0.0])

    def _J(self, G):
        J = np.zeros((5, 5))
        J[1:3, 1:3] = -(np.diag([-0.15, 0.25]) + G * np.eye(2))
        J[3:5, 3:5] = -np.eye(2)
        return J

    def f(self, x, G):
        return self._J(G) @ (np.asarray(x) - self.xs)

    def J(self, x, G):
        return self._J(G)

    def Jt(self, x, G):
        return self._J(G)


def section_H():
    s = W0Stub()
    pp = H.port_parts(s.J(s.xs, 0.25), s.M, s.b, [3, 4])
    lc = H.locus(pp)
    c = H.min_cand(lc['cands'])
    record('H lokus: omega = 0 adaylari (0.1, 0.5), omega > 0 kesisim yok',
           sorted(round(x['rho'], 12) for x in lc['cands']) == [0.1, 0.5] and c['kind'] == 'w0', lc['cands'])
    rec = H.stage1_member(dict(setting='W', P_akt=0.65, G_R=0.25, id='w0'), s, dict(ok=True, x0=s.xs.copy(),
                                                                                    rho=np.zeros(5)),
                          dict(s1_first_done=False, s3_first_done=False))
    record('H omega = 0 kazanir -> K5-omega0 (NE-x0)', not rec['in_E'] and rec['ne_reason'] == 'K5-omega0'
           and rec['gates']['K4']['status'] == H.GEC, rec['ne_reason'])


# ------------------------------------------------------------------ I
def section_I():
    rows = H.verify_pins(REAL_ROOT, H.PINS)
    record('I pinler 10/10', len(rows) == 10)
    mods = H.import_models(REAL_ROOT)
    EM = mods['e1_model']
    model = H.make_model(mods, 'S3')
    x = np.zeros(len(EM.STATE_NAMES))
    ix = {n: k for k, n in enumerate(EM.STATE_NAMES)}
    for nm, v in (('V_1:R', 1.0), ('V_2:R', 0.97), ('V_2:I', -0.05), (EM.L + ':v_dc', 0.9),
                  (EM.L + ':vr_filter', 0.96), (EM.L + ':ir_filter', 0.5), (EM.L + ':ir_cnv', 0.5)):
        x[ix[nm]] = v
    rho = np.array([0.5, 0.0, 1.0, 0.9, 0.0])
    s = H.RealSystem(mods, model, rho)
    record('I |b| = 2, |l| = 12, |sigma| = 18, keep = 32', (len(s.b), len(s.l), len(s.sig), len(s.keep)) ==
           (2, 12, 18, 32))
    record('I kL = 1 (U-1, rhab_model base_power = Sbase)', s.kL == 1.0, s.kL)
    Jf = s.J(x, 0.25)
    D = Jf - s.Jt(x, 0.25)
    # farkli sembolik yollarin (cse) yuvarlama farki 1e-12 bagil esigin altinda sayilir
    cols = sorted(set(np.nonzero(np.abs(D) > 1e-12 * max(1.0, float(np.max(np.abs(Jf)))))[1].tolist()))
    record('I J - J~ yalniz z = h(x) bagimli sutun(lar)da (p_oc) (N-e)',
           [EM.STATE_NAMES[c] for c in cols] == [EM.G + ':p_oc'], [EM.STATE_NAMES[c] for c in cols])
    record('I theta_oc satiri sifir', s.trz)
    s4 = H.s4_probe(s, x, 0.25)
    record('I S4 yapisi (sentetik x; denge degil)', s4['passed'], s4)
    lim = s.limits(x, 0.25)
    record('I limits L1-L6 anahtarlari ve marjlar', set(lim['limits']) >= set(H.LIM_KEYS) | {'L6'}
           and set(H.margins(lim, s.TH)) == set(H.LIM_KEYS))


# ------------------------------------------------------------------ J
def section_J(out):
    code = H.main(['--check-only'], root=REAL_ROOT)
    record('J check-only gercek kok -> 0', code == 0, code)
    root = os.path.join(out, 'root')
    for rel in [H.SABIT_REL] + [p[1] for p in H.PINS]:
        dst = os.path.join(root, *rel.split('/'))
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copyfile(os.path.join(REAL_ROOT, *rel.split('/')), dst)
    record('J check-only sentetik kok (tam kopya) -> 0', H.main(['--check-only'], root=root) == 0)
    bad = os.path.join(root, *H.PINS[5][1].split('/'))
    with open(bad, 'ab') as fh:
        fh.write(b'\n# bozuk\n')
    record('J check-only pin bozuk -> 2', H.main(['--check-only'], root=root) == 2)
    script = os.path.join(HERE, 'hdl2_run.py')
    rep = os.path.join(root, 'cdl1', 'HDL2_kod_denetimi_SENTETIK.md')
    with open(rep, 'w', encoding='utf-8') as fh:
        fh.write('sentetik\n')
    run_id = 'HDL2_20990101_a'
    y = dict(action='ALLOW_HDL2_RUN', run_id=run_id, sabit_sha256=H.SABIT_SHA256,
             script_sha256={'hdl2_run.py': H.sha256_hex(open(script, 'rb').read())},
             pin_list_sha256=H.pin_list_sha256(H.PINS),
             code_audit_report=dict(path='cdl1/HDL2_kod_denetimi_SENTETIK.md',
                                    sha256=H.sha256_hex(open(rep, 'rb').read())))
    yp = os.path.join(root, 'cdl1', 'HDL2_yetki_%s.json' % run_id)
    with open(yp, 'w', encoding='utf-8') as fh:
        json.dump(y, fh)
    record('J yetkisiz gercek kip -> 3', H.main(['--run-id', run_id], root=root) == 3)
    record('J bicimsiz run_id -> 3', H.main(['--run-id', 'X', '--yetki', yp], root=root) == 3)
    y2 = dict(y, action='ALLOW_T4_RUN')
    yp2 = os.path.join(root, 'cdl1', 'HDL2_yetki_HDL2_20990101_b.json')
    with open(yp2, 'w', encoding='utf-8') as fh:
        json.dump(dict(y2, run_id='HDL2_20990101_b'), fh)
    record('J yanlis action -> 3', H.main(['--run-id', 'HDL2_20990101_b', '--yetki', yp2], root=root) == 3)
    code = H.main(['--run-id', run_id, '--yetki', yp], root=root, script_path=script)
    od = os.path.join(root, 'cdl1', 'out', run_id)
    hk = open(os.path.join(od, 'hukum.txt'), encoding='utf-8').read() if os.path.isdir(od) else ''
    record('J gecerli yetki + bozuk pin -> ABORT (2), model import edilmeden; ciktilar yazildi',
           code == 2 and 'ABORT' in hk and 'pin 6' in hk and os.path.isfile(os.path.join(od, 'SHA256SUMS')), hk)
    record('J ayni run_id yeniden -> 3 (yeniden kosu yok)',
           H.main(['--run-id', run_id, '--yetki', yp], root=root, script_path=script) == 3)


# ------------------------------------------------------------------ K
MUTATIONS = [
    ('S1', 'import json  # noqa: E402\n', 'import json  # noqa: E402\nimport scipy  # noqa: E402\n'),
    ('S2', "    rec = dict(ok=False, reason=None, P_akt=P_akt, G_R=G_R)\n",
     "    rec = dict(ok=False, reason=None, P_akt=P_akt, G_R=G_R)\n    eval('1')\n"),
    ('S3', "    pin_rows = verify_pins(root, pins)\n", "    open('x')\n    pin_rows = verify_pins(root, pins)\n"),
    ('S4', "(5, 'e1_k/code/e1k_run.py', 50378,", "(5, 'e1_k/code/e1k_run.py', 50379,"),
    ('S5', "    pin_rows = verify_pins(root, pins)\n",
     "    _ = 'S_state' + '.csv'\n    pin_rows = verify_pins(root, pins)\n"),
    ('S6', "        x_init, gi = disp._assemble(pf, li)",
     "        model.f = None\n        x_init, gi = disp._assemble(pf, li)"),
    ('S7', "li['Vref_dc'], li['Iq_ref']], dtype=float)  # adim 4", "EM.V_STAR, li['Iq_ref']], dtype=float)  # adim 4"),
    ('S8', "x_ref, hist, _ = disp.refine(x_init, rho, G_R, 'new')",
     "x_ref, hist, _ = disp.refine(x_init, rho, G_R, 'fixed')"),
    ('S9', "    log('pin_list_sha256: %s' % pin_list_sha256(pins))\n    return 0\n",
     "    log('pin_list_sha256: %s' % pin_list_sha256(pins))\n    import_models(root)\n    return 0\n"),
    ('S10', "    rec = dict(ok=False, reason=None, P_akt=P_akt, G_R=G_R)\n",
     "    rec = dict(ok=False, reason=None, P_akt=P_akt, G_R=G_R)\n    np.brentq = None\n"),
]


def section_K(out):
    src = open(os.path.join(HERE, 'hdl2_run.py'), encoding='utf-8').read()
    res, _ = SC.check(os.path.join(HERE, 'hdl2_run.py'), REAL_ROOT)
    record('K statik denetim orijinalde GECTI', all(p for _, p, _ in res), [(n, d) for n, p, d in res if not p])
    mdir = os.path.join(out, 'mutasyon')
    os.makedirs(mdir, exist_ok=True)
    for key, old, new in MUTATIONS:
        if src.count(old) != 1:
            record('K mutasyon %s uygulanabilir' % key, False, 'eslesme %d' % src.count(old))
            continue
        p = os.path.join(mdir, 'hdl2_run_%s.py' % key)
        with open(p, 'w', encoding='utf-8') as fh:
            fh.write(src.replace(old, new))
        res, _ = SC.check(p, REAL_ROOT)
        failed = [n.split()[0] for n, passed, _ in res if not passed]
        record('K mutasyon %s -> %s KALIR' % (key, key), key in failed, failed)


def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except (AttributeError, ValueError):
        pass
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', required=True)
    ap.add_argument('--skip-model', action='store_true')
    a = ap.parse_args(argv)
    if os.path.exists(a.out) and os.listdir(a.out):
        print('--out bos olmali')
        return 1
    os.makedirs(a.out, exist_ok=True)
    t0 = time.time()
    sections = [('A', section_A, ()), ('B', section_B, ()), ('C', section_C, ()), ('D', section_D, ()),
                ('E', section_E, ()), ('F', section_F, ()), ('G', section_G, ()), ('H', section_H, ()),
                ('J', section_J, (a.out,)), ('K', section_K, (a.out,))]
    if not a.skip_model:
        sections.insert(8, ('I', section_I, ()))
    for name, fn, args in sections:
        t = time.time()
        try:
            fn(*args)
        except Exception:
            record('%s bolumu beklenmeyen hata' % name, False, traceback.format_exc())
        print('[bolum %s: %.1f s]' % (name, time.time() - t), flush=True)
    ok = all(r[1] for r in RESULTS)
    for name, passed, detail in RESULTS:
        print('%-75s %s%s' % (name, 'GECTI' if passed else 'KALDI', '' if passed else '  ' + str(detail)[:600]))
    with open(os.path.join(a.out, 'sentetik_sonuc.json'), 'w', encoding='utf-8') as fh:
        json.dump([dict(name=n, passed=p, detail=str(d)[:2000]) for n, p, d in RESULTS], fh, indent=1,
                  ensure_ascii=False)
    print('SENTETIK TEST: %s (%d durum, %.0f s)' % ('GECTI' if ok else 'KALDI', len(RESULTS), time.time() - t0))
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
