# El yapimi sentetik rhab_model.py yerine gecen dosya (B1). Yalniz ast.parse ile okunur; calistirilmaz.
import math


def parameters():
    Vb, Pb = 380.0, 10000.0
    load = dict(r_load=1.0, rf=0.01, base_power=100.0)
    gfm = dict(Rp=0.02, base_power=100.0)
    net = dict(r=0.01, x=0.1, V1=1.0, Sbase=100.0)
    return load, gfm, net
