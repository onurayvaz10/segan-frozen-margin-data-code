"""ht_run.py icin AST statik denetimi (SABIT s7 'Yurutmeden once').

Denetimler:
  S1  import izin listesi (11 standart modul; B1-h) ve yasakli adlar (numpy, scipy, sympy,
      subprocess, model modulleri ...) yok.
  S2  yasakli cagrilar yok: eval, exec, compile, __import__, os.system, os.popen, os.exec*,
      os.spawn*, importlib.*.
  S3  open() yalniz _read_bytes ve _write_text icinde cagrilir; pathlib/read_text yok.
  S4  ht_run.PINS literal tablosu SABIT s3 tablosuyla (K-2.1 tam yol) birebir ayni; SABIT hash'i dogru.
  S5  korlenmis dosya adlari (S_state.csv, S_V5_admittance.csv, S_point.json) betikte yalniz
      PINS tablosunda gecer.
  S6  ozdeger/linalg cagrisi yok (eig, eigvals, solve, linalg, odeint, solve_ivp adlari).
Kullanim: python -I ht_static_check.py [--root <research_intelligence>]
Cikis: 0 = GECTI, 1 = KALDI.
"""
import argparse
import ast
import hashlib
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ALLOWED_IMPORTS = {'argparse', 'ast', 'csv', 'hashlib', 'io', 'json', 'math', 'os', 're', 'sys', 'traceback'}
FORBIDDEN_NAMES = {'numpy', 'np', 'scipy', 'sympy', 'sp', 'subprocess', 'importlib', 'ctypes', 'multiprocessing',
                   'socket', 'urllib', 'http', 'shutil', 'pathlib', 'e1k_model', 'e1_core', 'rhab_model',
                   'e1k_run', 'pickle', 'marshal'}
FORBIDDEN_CALLS = {'eval', 'exec', 'compile', '__import__', 'execfile'}
FORBIDDEN_ATTR_CALLS = {('os', 'system'), ('os', 'popen'), ('os', 'startfile')}
FORBIDDEN_ATTR_PREFIX = ('exec', 'spawn', 'fork')
NUMERIC_NAMES = {'eig', 'eigvals', 'eigh', 'linalg', 'solve', 'odeint', 'solve_ivp', 'fsolve'}
OPEN_ALLOWED_IN = {'_read_bytes', '_write_text'}
BLINDED = ('S_state.csv', 'S_V5_admittance.csv', 'S_point.json')
PTS_FULL = 'e1_k/out/SETTINGS_20261012_a/settings/S3/points/'


def sha(path):
    with open(path, 'rb') as fh:
        return hashlib.sha256(fh.read()).hexdigest()


def sabit_pins(md_text):
    """SABIT s3 tablosu: '| n | `yol` ... | bayt | `sha` |' satirlari."""
    out = []
    for line in md_text.splitlines():
        m = re.match(r'^\|\s*(\d+)\s*\|\s*`([^`]+)`[^|]*\|\s*(\d+)\s*\|\s*`([0-9a-f]{64})`\s*\|\s*$', line)
        if m:
            p = m.group(2)
            if p.startswith('…/S3/points/'):
                p = PTS_FULL + p[len('…/S3/points/'):]
            out.append((int(m.group(1)), p, int(m.group(3)), m.group(4)))
    return out


def literal_pins(tree):
    """PINS = [...] atamasini, _PTS sabitini cozerek literal olarak okur."""
    pts, pins_node = None, None
    for n in tree.body:
        if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name):
            if n.targets[0].id == '_PTS':
                pts = ast.literal_eval(n.value)
            elif n.targets[0].id == 'PINS':
                pins_node = n.value
    if pts is None or pins_node is None:
        return None
    out = []
    for el in pins_node.elts:
        no, pnode, size, h = el.elts
        if isinstance(pnode, ast.BinOp):
            if not (isinstance(pnode.left, ast.Name) and pnode.left.id == '_PTS'):
                return None
            path = pts + ast.literal_eval(pnode.right)
        else:
            path = ast.literal_eval(pnode)
        out.append((ast.literal_eval(no), path, ast.literal_eval(size), ast.literal_eval(h)))
    return out


def innermost_funcs(tree):
    out = {}

    def visit(node, cur):
        for ch in ast.iter_child_nodes(node):
            nxt = ch.name if isinstance(ch, (ast.FunctionDef, ast.AsyncFunctionDef)) else cur
            out[id(ch)] = cur
            visit(ch, nxt)
    visit(tree, None)
    return out


def check(script_path, root):
    src_bytes = open(script_path, 'rb').read()
    src = src_bytes.decode('utf-8')
    tree = ast.parse(src)
    res = []

    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Import):
            bad += [a.name for a in n.names if a.name.split('.')[0] not in ALLOWED_IMPORTS]
        elif isinstance(n, ast.ImportFrom):
            bad.append('from %s' % n.module)
        elif isinstance(n, ast.Name) and n.id in FORBIDDEN_NAMES:
            bad.append(n.id)
        elif isinstance(n, ast.Attribute) and n.attr in FORBIDDEN_NAMES:
            bad.append('.' + n.attr)
    res.append(('S1 import/yasakli ad', not bad, bad))

    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Call):
            f = n.func
            if isinstance(f, ast.Name) and f.id in FORBIDDEN_CALLS:
                bad.append(f.id)
            if isinstance(f, ast.Attribute) and isinstance(f.value, ast.Name):
                if (f.value.id, f.attr) in FORBIDDEN_ATTR_CALLS or (
                        f.value.id == 'os' and f.attr.startswith(FORBIDDEN_ATTR_PREFIX)):
                    bad.append('%s.%s' % (f.value.id, f.attr))
    res.append(('S2 yasakli cagri', not bad, bad))

    inner = innermost_funcs(tree)
    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Call):
            f = n.func
            name = f.id if isinstance(f, ast.Name) else (f.attr if isinstance(f, ast.Attribute) else None)
            if name in ('open', 'read_text', 'read_bytes', 'write_text', 'write_bytes', 'urlopen'):
                if not (name == 'open' and inner.get(id(n)) in OPEN_ALLOWED_IN):
                    bad.append('%s @ satir %d (fonksiyon %s)' % (name, n.lineno, inner.get(id(n))))
    res.append(('S3 dosya acma tek nokta', not bad, bad))

    sabit_path = os.path.join(root, 'cdl1', 'CDL1_HT_On_Kayit_v1.0_SABIT.md')
    sabit_sha = sha(sabit_path)
    exp_sha = '3adc9f2b024897d386b3f074ba14f6fee5f44f07d43a7502fc4f3dd6b3543b91'
    sp = sabit_pins(open(sabit_path, encoding='utf-8').read())
    lp = literal_pins(tree)
    detail = []
    if sabit_sha != exp_sha:
        detail.append('SABIT sha %s' % sabit_sha)
    if len(sp) != 15:
        detail.append('SABIT tablosunda %d pin' % len(sp))
    if lp != sp:
        detail.append('PINS != SABIT s3')
    res.append(('S4 PINS == SABIT s3 (15 pin) ve SABIT hash', not detail, detail))

    bad = []
    doc = tree.body[0].value if (tree.body and isinstance(tree.body[0], ast.Expr)) else None
    pins_ids = set()
    for n in tree.body:
        if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'PINS':
            pins_ids = {id(x) for x in ast.walk(n)}
    for n in ast.walk(tree):
        if isinstance(n, ast.Constant) and isinstance(n.value, str) and n is not doc and id(n) not in pins_ids:
            for b in BLINDED:
                if b in n.value:
                    bad.append('%s @ satir %d' % (b, n.lineno))
    res.append(('S5 korlenmis adlar yalniz PINS icinde', not bad, bad))

    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Call):
            f = n.func
            name = f.id if isinstance(f, ast.Name) else (f.attr if isinstance(f, ast.Attribute) else None)
            if name in NUMERIC_NAMES:
                bad.append('%s @ satir %d' % (name, n.lineno))
    res.append(('S6 ozdeger/cozucu cagrisi yok', not bad, bad))

    return res, hashlib.sha256(src_bytes).hexdigest()


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default=os.path.dirname(os.path.dirname(HERE)))
    ap.add_argument('--script', default=os.path.join(HERE, 'ht_run.py'))
    a = ap.parse_args(argv)
    res, h = check(a.script, a.root)
    print('ht_run.py sha256: %s' % h)
    ok = True
    for name, passed, detail in res:
        print('%-45s %s%s' % (name, 'GECTI' if passed else 'KALDI', '' if passed else '  ' + '; '.join(map(str, detail))))
        ok &= passed
    print('STATIK DENETIM: %s' % ('GECTI' if ok else 'KALDI'))
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
