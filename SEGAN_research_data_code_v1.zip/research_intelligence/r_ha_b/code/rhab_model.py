"""R-HA-B — independent Python/SymPy implementation of the PSID v0.10.8 two-bus model:
Droop GFM (VoltageModeControl, LCL, AverageConverter, FixedDCSource) + 12-state ActiveConstantPowerLoad
+ dynamic pi-line with bus-voltage dynamics, ConstantFrequency (omega_sys = 1).

Equations follow RHA_B_denklem_esleme.md (source file/line mapping). Nothing here calls PSID/Julia,
copies a PSID Jacobian, or imports an R-HA state vector. Parameters are re-derived from the author's data files.
"""
import math

import numpy as np
import sympy as sp

WB = 2 * math.pi * 60.0          # device.jl:803 / filter_models.jl:19
W_SYS = 1.0                       # ConstantFrequency (caches.jl:94, global pointer 0)

G = 'generator-101-1'
L = 'load1021'
LINE = 'BUS 1-BUS 2-i_1'
GFM_STATES = ['θ_oc', 'p_oc', 'q_oc', 'ξd_ic', 'ξq_ic', 'γd_ic', 'γq_ic', 'ϕd_ic',
              'ϕq_ic', 'ir_cnv', 'ii_cnv', 'vr_filter', 'vi_filter', 'ir_filter', 'ii_filter']
LOAD_STATES = ['θ_pll', 'ϵ_pll', 'η', 'v_dc', 'γd', 'γq', 'ir_cnv', 'ii_cnv', 'vr_filter',
               'vi_filter', 'ir_filter', 'ii_filter']
STATE_NAMES = (['V_1:R', 'V_2:R', 'V_1:I', 'V_2:I', LINE + ':Il_R', LINE + ':Il_I']
               + [G + ':' + s for s in GFM_STATES] + [L + ':' + s for s in LOAD_STATES])
N = len(STATE_NAMES)
REF_NAMES = ['P_ref_gfm', 'Q_ref_gfm', 'V_ref_gfm', 'V_ref_dc', 'Q_ref_load']


def parameters():
    """Author data (load_data.jl:56-66 + active_cpl; inverter_data.jl; OMIB_Load.raw)."""
    Ob = 2 * math.pi * 60
    Vb, Pb = 380.0, 10000.0
    Ib = Pb / Vb
    Zb = Vb / Ib
    Lb = Zb / Ob
    Cb = 1 / (Zb * Ob)
    Vb_dc = math.sqrt(8) / math.sqrt(3) * Vb
    Ib_dc = Pb / Vb_dc
    Zb_dc = Vb_dc / Ib_dc
    Cb_dc = 1 / (Zb_dc * Ob)
    load = dict(r_load=70.0 / Zb_dc, c_dc=2040e-6 / Cb_dc, rf=0.1 / Zb, lf=2.3e-3 / Lb, cf=8.8e-6 / Cb,
                rg=0.03 / Zb, lg=0.93e-3 / Lb, kp_pll=0.4, ki_pll=4.69, kpv=0.5 * (Vb_dc / Ib_dc),
                kiv=150.0 * (Vb_dc / Ib_dc), kpc=15.0 * (Ib / Vb), kic=30000.0 * (Ib / Vb), base_power=100.0)
    gfm = dict(Rp=0.02, wz=2 * math.pi * 20, kq=0.05, wf=2 * math.pi * 20, kpv=0.59, kiv=736.0, kffv=0.0,
               rv=0.0, lv=0.2, kpc=1.27, kic=14.3, kffi=0.0, wad=50.0, kad=0.2, lf=0.08, rf=0.003, cf=0.074,
               lg=0.2, rg=0.01, Vdc=690.0, w_ref=1.0, is_not_reference=0.0, base_power=100.0)
    net = dict(r=0.01, x=0.1, b_from=0.01 / 2, b_to=0.01 / 2, V1=1.0, Sbase=100.0)
    return load, gfm, net


def park(th, r, i):
    """ri_dq(th + pi/2): d = cos*r + sin*i ; q = -sin*r + cos*i."""
    return sp.cos(th) * r + sp.sin(th) * i, -sp.sin(th) * r + sp.cos(th) * i


def inv_park(th, d, q):
    """dq_ri(th + pi/2): r = cos*d - sin*q ; i = sin*d + cos*q."""
    return sp.cos(th) * d - sp.sin(th) * q, sp.sin(th) * d + sp.cos(th) * q


def build_symbolic():
    load, gfm, net = parameters()
    x = sp.symbols('x0:%d' % N)
    X = dict(zip(STATE_NAMES, x))
    refs = sp.symbols(' '.join(REF_NAMES))
    Pref, Qref, Vref, Vref_dc, Iq_ref = refs
    w = W_SYS
    f = {}
    Vr1, Vr2, Vi1, Vi2 = X['V_1:R'], X['V_2:R'], X['V_1:I'], X['V_2:I']

    # ---- GFM (outer_control_models.jl:611-698; inner_control_models.jl:147-254; converter; LCL) ----
    g = {s: X[G + ':' + s] for s in GFM_STATES}
    th = g['θ_oc']
    Irc, Iic, Vrf, Vif, Irf, Iif = (g[k] for k in ['ir_cnv', 'ii_cnv', 'vr_filter', 'vi_filter', 'ir_filter', 'ii_filter'])
    p_e = Irf * Vrf + Iif * Vif
    q_e = -Iif * Vrf + Irf * Vif
    w_oc = gfm['w_ref'] + gfm['Rp'] * (Pref - g['p_oc'])
    f[G + ':θ_oc'] = gfm['is_not_reference'] * WB * (w_oc - w)
    f[G + ':p_oc'] = gfm['wz'] * (p_e - g['p_oc'])
    f[G + ':q_oc'] = gfm['wf'] * (q_e - g['q_oc'])
    V_oc = Vref + gfm['kq'] * (Qref - g['q_oc'])
    Idf, Iqf = park(th, Irf, Iif)
    Idc, Iqc = park(th, Irc, Iic)
    Vdf, Vqf = park(th, Vrf, Vif)
    Vd_ref = V_oc - gfm['rv'] * Idf + w_oc * gfm['lv'] * Iqf
    Vq_ref = -gfm['rv'] * Iqf - w_oc * gfm['lv'] * Idf
    Id_pi = gfm['kpv'] * (Vd_ref - Vdf) + gfm['kiv'] * g['ξd_ic']
    Iq_pi = gfm['kpv'] * (Vq_ref - Vqf) + gfm['kiv'] * g['ξq_ic']
    f[G + ':ξd_ic'] = Vd_ref - Vdf
    f[G + ':ξq_ic'] = Vq_ref - Vqf
    Idc_ref = Id_pi - gfm['cf'] * w_oc * Vqf + gfm['kffi'] * Idf
    Iqc_ref = Iq_pi + gfm['cf'] * w_oc * Vdf + gfm['kffi'] * Iqf
    Vd_pi = gfm['kpc'] * (Idc_ref - Idc) + gfm['kic'] * g['γd_ic']
    Vq_pi = gfm['kpc'] * (Iqc_ref - Iqc) + gfm['kic'] * g['γq_ic']
    f[G + ':γd_ic'] = Idc_ref - Idc
    f[G + ':γq_ic'] = Iqc_ref - Iqc
    Vdc_ref = (Vd_pi - w_oc * gfm['lf'] * Iqc + gfm['kffv'] * Vdf - gfm['kad'] * (Vdf - g['ϕd_ic']))
    Vqc_ref = (Vq_pi + w_oc * gfm['lf'] * Idc + gfm['kffv'] * Vqf - gfm['kad'] * (Vqf - g['ϕq_ic']))
    f[G + ':ϕd_ic'] = gfm['wad'] * (Vdf - g['ϕd_ic'])
    f[G + ':ϕq_ic'] = gfm['wad'] * (Vqf - g['ϕq_ic'])
    md, mq = Vdc_ref / gfm['Vdc'], Vqc_ref / gfm['Vdc']          # inner_control_models.jl:251-252
    mr, mi = inv_park(th, md, mq)                               # converter_models.jl:31
    Vr_cnv, Vi_cnv = mr * gfm['Vdc'], mi * gfm['Vdc']           # converter_models.jl:34-35
    f[G + ':ir_cnv'] = Vr_cnv - Vrf - gfm['rf'] * Irc + gfm['lf'] * w * Iic
    f[G + ':ii_cnv'] = Vi_cnv - Vif - gfm['rf'] * Iic - gfm['lf'] * w * Irc
    f[G + ':vr_filter'] = Irc - Irf + gfm['cf'] * w * Vif
    f[G + ':vi_filter'] = Iic - Iif - gfm['cf'] * w * Vrf
    f[G + ':ir_filter'] = Vrf - Vr1 - gfm['rg'] * Irf + gfm['lg'] * w * Iif
    f[G + ':ii_filter'] = Vif - Vi1 - gfm['rg'] * Iif - gfm['lg'] * w * Irf
    I_gfm = (gfm['base_power'] / net['Sbase']) * Irf, (gfm['base_power'] / net['Sbase']) * Iif

    # ---- Active load (device.jl:824-936) ----
    l = {s: X[L + ':' + s] for s in LOAD_STATES}
    thp = l['θ_pll']
    lIrc, lIic, lVrf, lVif, lIrf, lIif = (l[k] for k in ['ir_cnv', 'ii_cnv', 'vr_filter', 'vi_filter', 'ir_filter', 'ii_filter'])
    lIdc, lIqc = park(thp, lIrc, lIic)
    Vdp, Vqp = park(thp, lVrf, lVif)
    dw = load['kp_pll'] * Vqp + load['ki_pll'] * l['ϵ_pll']
    w_pll = dw + w
    f[L + ':θ_pll'] = WB * dw
    f[L + ':ϵ_pll'] = Vqp
    Id_ref = load['kpv'] * (Vref_dc - l['v_dc']) + load['kiv'] * l['η']
    f[L + ':η'] = Vref_dc - l['v_dc']
    Vd_unc = load['kpc'] * (-Id_ref + lIdc) + load['kic'] * l['γd']
    Vq_unc = load['kpc'] * (-Iq_ref + lIqc) + load['kic'] * l['γq']
    f[L + ':γd'] = -Id_ref + lIdc
    f[L + ':γq'] = -Iq_ref + lIqc
    Vd_c = Vd_unc + w_pll * load['lf'] * lIqc
    Vq_c = Vq_unc - w_pll * load['lf'] * lIdc
    lVr_c, lVi_c = inv_park(thp, Vd_c, Vq_c)
    P_cnv = lVr_c * lIrc + lVi_c * lIic
    f[L + ':v_dc'] = (WB / load['c_dc']) * (P_cnv / l['v_dc'] - l['v_dc'] / load['r_load'])
    f[L + ':ir_cnv'] = lVrf - lVr_c - load['rf'] * lIrc + load['lf'] * w * lIic
    f[L + ':ii_cnv'] = lVif - lVi_c - load['rf'] * lIic - load['lf'] * w * lIrc
    f[L + ':vr_filter'] = lIrf - lIrc + load['cf'] * w * lVif
    f[L + ':vi_filter'] = lIif - lIic - load['cf'] * w * lVrf
    f[L + ':ir_filter'] = Vr2 - lVrf - load['rg'] * lIrf + load['lg'] * w * lIif
    f[L + ':ii_filter'] = Vi2 - lVif - load['rg'] * lIif - load['lg'] * w * lIrf
    I_load = (load['base_power'] / net['Sbase']) * lIrf, (load['base_power'] / net['Sbase']) * lIif

    # ---- Dynamic line (dynline_model.jl:1-28) ----
    IlR, IlI = X[LINE + ':Il_R'], X[LINE + ':Il_I']
    R, Xl = net['r'], net['x']
    f[LINE + ':Il_R'] = (WB / Xl) * ((Vr1 - Vr2) - (R * IlR - Xl * IlI))
    f[LINE + ':Il_I'] = (WB / Xl) * ((Vi1 - Vi2) - (R * IlI + Xl * IlR))

    # ---- Network (network_model.jl; system.jl): f_V = I_balance - j*b*V ----
    I1r = I_gfm[0] - IlR
    I1i = I_gfm[1] - IlI
    I2r = -I_load[0] + IlR
    I2i = -I_load[1] + IlI
    b1, b2 = net['b_from'], net['b_to']
    f['V_1:R'] = I1r + b1 * Vi1
    f['V_1:I'] = I1i - b1 * Vr1
    f['V_2:R'] = I2r + b2 * Vi2
    f['V_2:I'] = I2i - b2 * Vr2

    fvec = sp.Matrix([f[nm] for nm in STATE_NAMES])
    M = np.ones(N)
    M[STATE_NAMES.index('V_1:R')] = M[STATE_NAMES.index('V_1:I')] = b1 / WB
    M[STATE_NAMES.index('V_2:R')] = M[STATE_NAMES.index('V_2:I')] = b2 / WB
    for pre, p in ((G, gfm), (L, load)):
        for s, val in (('ir_cnv', p['lf']), ('ii_cnv', p['lf']), ('vr_filter', p['cf']), ('vi_filter', p['cf']),
                       ('ir_filter', p['lg']), ('ii_filter', p['lg'])):
            M[STATE_NAMES.index(pre + ':' + s)] = val / WB
    aux = dict(P_cnv=P_cnv, Vq_pll=Vqp, p_e=p_e, q_e=q_e, w_oc=w_oc)
    return x, refs, fvec, M, aux


class Model:
    def __init__(self):
        self.load, self.gfm, self.net = parameters()
        x, refs, fvec, M, aux = build_symbolic()
        self.x_sym, self.refs_sym, self.f_sym, self.M = x, refs, fvec, M
        self.J_sym = fvec.jacobian(sp.Matrix(x))
        args = list(x) + list(refs)
        self._f = sp.lambdify(args, fvec, modules='numpy', cse=True)
        self._J = sp.lambdify(args, self.J_sym, modules='numpy', cse=True)
        self._aux = {k: sp.lambdify(args, v, modules='numpy') for k, v in aux.items()}
        self.i_theta = STATE_NAMES.index(G + ':θ_oc')
        self.theta_row_structurally_zero = (fvec[self.i_theta] == 0) and all(
            e == 0 for e in self.J_sym.row(self.i_theta))

    def f(self, x, refs):
        return np.array(self._f(*x, *refs), dtype=np.result_type(np.asarray(x), float)).reshape(-1)

    def J(self, x, refs):
        return np.array(self._J(*x, *refs), dtype=float)

    def aux(self, name, x, refs):
        return complex(self._aux[name](*x, *refs)).real

    def J_complex_step(self, x, refs, h):
        Jc = np.zeros((N, N))
        for k in range(N):
            xc = np.array(x, dtype=complex)
            xc[k] += 1j * h
            Jc[:, k] = np.imag(self.f(xc, refs)) / h
        return Jc


# ------------------------------- initialisation (per P_L) -------------------------------
def power_flow(P_L, net, tol=1e-14, maxit=50):
    """Two-bus AC power flow with the PSY pi-line Ybus (ybus_calculations.jl:12-33).
    Bus 101 slack V = 1.0∠0; bus 102 PQ with P = P_L, Q = 0. Newton in rectangular coordinates."""
    ys = 1 / complex(net['r'], net['x'])
    Y11, Y12, Y22 = ys + 1j * net['b_from'], -ys, ys + 1j * net['b_to']
    V1 = complex(net['V1'], 0.0)
    S_load = complex(P_L, 0.0)

    def mismatch(e, fq):
        V2 = complex(e, fq)
        S2 = V2 * np.conj(Y12 * V1 + Y22 * V2)   # injected at bus 102
        m = S2 + S_load
        return np.array([m.real, m.imag])

    e, fq = 1.0, 0.0
    hist = []
    for it in range(maxit):
        m = mismatch(e, fq)
        hist.append(float(np.max(np.abs(m))))
        if hist[-1] <= tol:
            break
        hd = 1e-7
        Jm = np.column_stack([(mismatch(e + hd, fq) - mismatch(e - hd, fq)) / (2 * hd),
                              (mismatch(e, fq + hd) - mismatch(e, fq - hd)) / (2 * hd)])
        de, df = np.linalg.solve(Jm, -m)
        e, fq = e + de, fq + df
    V2 = complex(e, fq)
    S_gen = V1 * np.conj(Y11 * V1 + Y12 * V2)
    return dict(V1=V1, V2=V2, S_gen=S_gen, iters=len(hist), mismatch_hist=hist,
                converged=hist[-1] <= tol)


def _newton(fun, jac, z0, tol=1e-14, maxit=50):
    z = np.array(z0, dtype=float)
    hist = []
    for _ in range(maxit):
        r = fun(z)
        hist.append(float(np.max(np.abs(r))))
        if hist[-1] <= tol:
            break
        z = z - np.linalg.solve(jac(z), r)
    return z, hist


def _gfm_inner_system(gfm):
    """init_inner.jl:52-104 (omega_oc = omega_ref = 1); unknowns th, v_ref, xi_d, xi_q, g_d, g_q, ph_d, ph_q."""
    z = sp.symbols('z0:8')
    th, v_refr, xid, xiq, gd, gq, phd, phq = z
    pin = sp.symbols('Irf Iif Irc Iic Vrf Vif Vrc0 Vic0')
    Irf, Iif, Irc, Iic, Vrf, Vif, Vrc0, Vic0 = pin
    w_oc = gfm['w_ref']
    Idf, Iqf = park(th, Irf, Iif)
    Idc, Iqc = park(th, Irc, Iic)
    Vdf, Vqf = park(th, Vrf, Vif)
    Vdc0, Vqc0 = park(th, Vrc0, Vic0)
    Vd_ref = v_refr - gfm['rv'] * Idf + w_oc * gfm['lv'] * Iqf
    Vq_ref = -gfm['rv'] * Iqf - w_oc * gfm['lv'] * Idf
    Idc_ref = gfm['kpv'] * (Vd_ref - Vdf) + gfm['kiv'] * xid - gfm['cf'] * w_oc * Vqf + gfm['kffi'] * Idf
    Iqc_ref = gfm['kpv'] * (Vq_ref - Vqf) + gfm['kiv'] * xiq + gfm['cf'] * w_oc * Vdf + gfm['kffi'] * Iqf
    Vd_cnv_ref = (gfm['kpc'] * (Idc_ref - Idc) + gfm['kic'] * gd - w_oc * gfm['lf'] * Iqc + gfm['kffv'] * Vdf
                  - gfm['kad'] * (Vdf - phd))
    Vq_cnv_ref = (gfm['kpc'] * (Iqc_ref - Iqc) + gfm['kic'] * gq + w_oc * gfm['lf'] * Idc + gfm['kffv'] * Vqf
                  - gfm['kad'] * (Vqf - phq))
    out = sp.Matrix([Vd_ref - Vdf, Vq_ref - Vqf, Idc_ref - Idc, Iqc_ref - Iqc, Vdf - phd, Vqf - phq,
                     Vd_cnv_ref - Vdc0, Vq_cnv_ref - Vqc0])
    F = sp.lambdify(list(z) + list(pin), out, modules='numpy')
    Jz = sp.lambdify(list(z) + list(pin), out.jacobian(sp.Matrix(z)), modules='numpy')
    return F, Jz


class Initialiser:
    def __init__(self, model):
        self.m = model
        self._inner_F, self._inner_J = _gfm_inner_system(model.gfm)

    def operating_point(self, P_L):
        m = self.m
        load, gfm, net = m.load, m.gfm, m.net
        rec = dict(P_L=P_L)
        pf = power_flow(P_L, net)
        rec['pf'] = pf
        V1, V2, S0 = pf['V1'], pf['V2'], pf['S_gen']
        w = gfm['w_ref']
        # GFM filter (init_filter.jl): closed-form solution of the 6 linear equations
        I = np.conj(S0 / V1)
        Irf, Iif = I.real, I.imag
        Vrf = V1.real + gfm['rg'] * Irf - w * gfm['lg'] * Iif
        Vif = V1.imag + gfm['rg'] * Iif + w * gfm['lg'] * Irf
        Irc = Irf - w * gfm['cf'] * Vif
        Iic = Iif + w * gfm['cf'] * Vrf
        Vrc = Vrf + gfm['rf'] * Irc - w * gfm['lf'] * Iic
        Vic = Vif + gfm['rf'] * Iic + w * gfm['lf'] * Irc
        # outer (init_outer.jl:63-122)
        th0 = math.atan2(Vic, Vrc)
        p_e = Irf * Vrf + Iif * Vif
        q_e = -Iif * Vrf + Irf * Vif
        # inner (init_inner.jl): Newton from [th0, 1, 0, ...]
        pin = [Irf, Iif, Irc, Iic, Vrf, Vif, Vrc, Vic]
        zsol, inner_hist = _newton(lambda z: np.array(self._inner_F(*z, *pin), dtype=float).reshape(-1),
                                   lambda z: np.array(self._inner_J(*z, *pin), dtype=float),
                                   [th0, 1.0, 0, 0, 0, 0, 0, 0])
        th, v_refr, xid, xiq, gd, gq, phd, phq = zsol
        # active load (init_device.jl:384-483); closed-form solution of the 5 equations
        P0 = P_L * net['Sbase'] / load['base_power']
        S = complex(P0, 0.0)
        Il = np.conj(S / V2)
        Vf0 = V2 - Il * complex(load['rg'], load['lg'])
        Ic0 = Il - 1j * load['cf'] * Vf0
        Vc0 = Vf0 - Ic0 * complex(load['rf'], load['lf'])
        Pc0 = Vc0.real * Ic0.real + Vc0.imag * Ic0.imag
        Vref_dc = math.sqrt(Pc0 * load['r_load'])
        thp = math.atan2(Vf0.imag, Vf0.real)
        c, s_ = math.cos(thp), math.sin(thp)
        Id = c * Ic0.real + s_ * Ic0.imag
        Iq = -s_ * Ic0.real + c * Ic0.imag
        Vd0 = c * Vc0.real + s_ * Vc0.imag
        Vq0 = -s_ * Vc0.real + c * Vc0.imag
        eta = Id / load['kiv']
        Iq_ref = Iq
        g_q = (Vq0 + load['lf'] * Id) / load['kic']
        g_d = (Vd0 - load['lf'] * Iq) / load['kic']
        # line (init_device.jl:167-189)
        Iline = (V1 - V2) / complex(net['r'], net['x'])
        vals = {'V_1:R': V1.real, 'V_1:I': V1.imag, 'V_2:R': V2.real, 'V_2:I': V2.imag,
                LINE + ':Il_R': Iline.real, LINE + ':Il_I': Iline.imag}
        gv = dict(zip(GFM_STATES, [th, p_e, q_e, xid, xiq, gd, gq, phd, phq, Irc, Iic, Vrf, Vif, Irf, Iif]))
        lv = dict(zip(LOAD_STATES, [thp, 0.0, eta, Vref_dc, g_d, g_q, Ic0.real, Ic0.imag, Vf0.real, Vf0.imag,
                                    Il.real, Il.imag]))
        vals.update({G + ':' + k: v for k, v in gv.items()})
        vals.update({L + ':' + k: v for k, v in lv.items()})
        x0 = np.array([vals[nm] for nm in STATE_NAMES], dtype=float)
        refs = np.array([p_e, q_e, v_refr, Vref_dc, Iq_ref], dtype=float)
        rec.update(refs=dict(zip(REF_NAMES, refs.tolist())), inner_newton_hist=inner_hist,
                   theta0_guess=th0, P_cnv0=Pc0)
        # system refinement (nlsolve_wrapper.jl:116-152): theta_oc fixed (its row is identically zero)
        keep = [k for k in range(N) if k != m.i_theta]
        res0 = float(np.max(np.abs(m.f(x0, refs))))
        x = x0.copy()
        hist = [res0]
        for _ in range(20):
            F = m.f(x, refs)
            if np.max(np.abs(F)) <= 1e-13:
                break
            Jk = m.J(x, refs)[np.ix_(keep, keep)]
            cand = x.copy()
            cand[keep] += np.linalg.solve(Jk, -F[keep])
            newres = float(np.max(np.abs(m.f(cand, refs))))
            hist.append(newres)
            if newres >= hist[-2]:      # no improvement: keep the previous iterate
                break
            x = cand
        rec['refine_hist'] = hist
        rec['x_init'] = x0
        return x, refs, rec
