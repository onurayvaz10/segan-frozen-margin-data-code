"""E1 M-E1-0 core procedures. Fixed pre-registration sha256 11c08c3e... (section numbers below refer to it).

Dispatch (§3.1), candidate feasibility (§3.2, §4, §5.1a), post-shed continuation (§3.3), alpha and spectral
validity (§5.0, §5.1b, §5.2), V1-V5 (§8), gates D/Lim/N/Mrj and F decision (§6), categories and effect (§7).
All thresholds are the fixed pre-registered values (TH below); nothing here tunes them.
"""
import math

import numpy as np
from scipy.optimize import linear_sum_assignment

from e1_model import (RB, ANGLE_STATES, G, GFM_STATES, I_PM, I_THETA, IX, L, LINE, LOAD_STATE_NAMES, LOAD_STATES, N,
                      RI_PAIRS, STATE_NAMES, TH_PLL, V_DC, V_STAR)

# ------------------------------------------------------------------------------------------------------------
# Fixed pre-registered constants (§3, §4, §5, §8). DO NOT CHANGE.
# ------------------------------------------------------------------------------------------------------------
TH = dict(
    pf_mismatch=1e-14, oned=1e-12, closure=1e-6, res=1e-8, vq=1e-8,          # §5.1a
    EJ=1e-8, backward=1e-10, zero=1e-8, ref_part=0.99,                         # §5.1b, §5.0
    eta_alpha=1e-2, eps_margin=5.0, eps_effect=5.0,                            # §5.2-§5.4
    v1_h=1e-10, v3=1e-10, v4_rel=1e-10, v4_eig=1e-9,                           # §8
    delta_L=1e-6, tau_dc=1e-6, delta_dc=1e-7,                                  # §4
    L1=1.0, L2=1.0, L3=(0.88, 1.10), L4=(0.98, 1.02), m_max=1.0,               # §4
    newton_tol=1e-12, newton_stag=1e-8, newton_maxit=30, halvings=5, n_steps=20, cond_branch=1e12,  # §3.3
    refine_stop=1e-13, refine_maxit=20,                                        # §3.1 step 4 (as R-HA-B)
)
CANDIDATES = (0.25, 0.20, 0.15, 0.10, 0.05)                                    # §3.2, order fixed
CS_STEPS = (1e-20, 1e-18)                                                       # §5.1b
P_AKT_BRACKET = (0.6, 0.9)                                                      # §3.1 step 3
ONED_BISECT_WIDTH = 1e-6        # implementation detail (§3.1: "ikiye bölme ve ardından sekant")
ONED_MAXIT = 60
V4_PHIS = (0.3, -1.1)                                                           # §8 V4
V4_SEED = 20261012
V4_DELTA = 1e-3
V5_F_HZ = np.logspace(-1, 3, 200)                                               # §8 V5
KEEP = [k for k in range(N) if k != I_THETA]                                    # theta_oc fixed (§3.1, §3.3)

OK, VIOL, BORDER = 'saglaniyor', 'ihlal', 'sinirda'


class DispatchError(Exception):
    pass


def ej(J1, J2):
    E = np.abs(J1 - J2) / (1 + np.maximum(np.abs(J1), np.abs(J2)))
    i, j = np.unravel_index(np.argmax(E), E.shape)
    return float(E[i, j]), STATE_NAMES[i] if E.shape[0] == N else i, STATE_NAMES[j] if E.shape[1] == N else j


# ------------------------------------------------------------------------------------------------------------
# §3.1 dispatch
# ------------------------------------------------------------------------------------------------------------
def power_flow(P_akt, G_R, net, tol=TH['pf_mismatch'], maxit=50):
    """Bus 101 slack 1.0∠0; bus 102 load P = P_akt + G_R |V2|^2, Q = 0 (pi-line Ybus as rhab_model.power_flow)."""
    ys = 1 / complex(net['r'], net['x'])
    Y11, Y12, Y22 = ys + 1j * net['b_from'], -ys, ys + 1j * net['b_to']
    V1 = complex(net['V1'], 0.0)

    def mismatch(e, fq):
        V2 = complex(e, fq)
        S2 = V2 * np.conj(Y12 * V1 + Y22 * V2)          # injected at bus 102
        m = S2 + complex(P_akt + G_R * (e * e + fq * fq), 0.0)
        return np.array([m.real, m.imag])

    e, fq = 1.0, 0.0
    hist = []
    for it in range(maxit + 1):
        m = mismatch(e, fq)
        hist.append(float(np.max(np.abs(m))))
        if hist[-1] <= tol or it == maxit:
            break
        hd = 1e-7
        Jm = np.column_stack([(mismatch(e + hd, fq) - mismatch(e - hd, fq)) / (2 * hd),
                              (mismatch(e, fq + hd) - mismatch(e, fq - hd)) / (2 * hd)])
        de, df = np.linalg.solve(Jm, -m)
        e, fq = e + de, fq + df
    V2 = complex(e, fq)
    S_gen = V1 * np.conj(Y11 * V1 + Y12 * V2)
    return dict(V1=V1, V2=V2, S_gen=S_gen, iters=len(hist), mismatch_hist=hist, mismatch=hist[-1],
                converged=hist[-1] <= tol, P_akt=P_akt, G_R=G_R)


def load_init(P0, V2, load):
    """Active-load initialisation (rhab_model.Initialiser / init_device.jl:384-483), critical load only."""
    S = complex(P0, 0.0)
    Il = np.conj(S / V2)
    Vf0 = V2 - Il * complex(load['rg'], load['lg'])
    Ic0 = Il - 1j * load['cf'] * Vf0
    Vc0 = Vf0 - Ic0 * complex(load['rf'], load['lf'])
    Pc0 = Vc0.real * Ic0.real + Vc0.imag * Ic0.imag
    Vref_dc = math.sqrt(Pc0 * load['r_load'])
    thp = math.atan2(Vf0.imag, Vf0.real)
    c, s_ = math.cos(thp), math.sin(thp)
    Id = c * Ic0.real + s_ * Ic0.imag
    Iq = -s_ * Ic0.real + c * Ic0.imag
    Vd0 = c * Vc0.real + s_ * Vc0.imag
    Vq0 = -s_ * Vc0.real + c * Vc0.imag
    return dict(Il=Il, Vf0=Vf0, Ic0=Ic0, Vc0=Vc0, P_cnv0=Pc0, Vref_dc=Vref_dc, thp=thp,
                eta=Id / load['kiv'], Iq_ref=Iq, g_q=(Vq0 + load['lf'] * Id) / load['kic'],
                g_d=(Vd0 - load['lf'] * Iq) / load['kic'])


class Dispatcher:
    """Device initialisation equations identical to rhab_model.Initialiser (validated in R-HA-B), with G_R in the
    power flow and in the bus-102 balance only; the active load is initialised with P_0 = P_akt only."""

    def __init__(self, model):
        self.m = model
        self._inner_F, self._inner_J = RB._gfm_inner_system(model.gfm)

    def _assemble(self, pf, li):
        m = self.m
        gfm, net = m.gfm, m.net
        V1, V2, S0 = pf['V1'], pf['V2'], pf['S_gen']
        w = gfm['w_ref']
        I = np.conj(S0 / V1)
        Irf, Iif = I.real, I.imag
        Vrf = V1.real + gfm['rg'] * Irf - w * gfm['lg'] * Iif
        Vif = V1.imag + gfm['rg'] * Iif + w * gfm['lg'] * Irf
        Irc = Irf - w * gfm['cf'] * Vif
        Iic = Iif + w * gfm['cf'] * Vrf
        Vrc = Vrf + gfm['rf'] * Irc - w * gfm['lf'] * Iic
        Vic = Vif + gfm['rf'] * Iic + w * gfm['lf'] * Irc
        th0 = math.atan2(Vic, Vrc)
        p_e = Irf * Vrf + Iif * Vif
        q_e = -Iif * Vrf + Irf * Vif
        pin = [Irf, Iif, Irc, Iic, Vrf, Vif, Vrc, Vic]
        zsol, inner_hist = RB._newton(lambda zz: np.array(self._inner_F(*zz, *pin), dtype=float).reshape(-1),
                                      lambda zz: np.array(self._inner_J(*zz, *pin), dtype=float),
                                      [th0, 1.0, 0, 0, 0, 0, 0, 0])
        th, v_refr, xid, xiq, gd, gq, phd, phq = zsol
        Iline = (V1 - V2) / complex(net['r'], net['x'])
        vals = {'V_1:R': V1.real, 'V_1:I': V1.imag, 'V_2:R': V2.real, 'V_2:I': V2.imag,
                LINE + ':Il_R': Iline.real, LINE + ':Il_I': Iline.imag}
        gv = dict(zip(GFM_STATES, [th, p_e, q_e, xid, xiq, gd, gq, phd, phq, Irc, Iic, Vrf, Vif, Irf, Iif]))
        lv = dict(zip(LOAD_STATES, [li['thp'], 0.0, li['eta'], li['Vref_dc'], li['g_d'], li['g_q'], li['Ic0'].real,
                                    li['Ic0'].imag, li['Vf0'].real, li['Vf0'].imag, li['Il'].real, li['Il'].imag]))
        vals.update({G + ':' + k: v for k, v in gv.items()})
        vals.update({L + ':' + k: v for k, v in lv.items()})
        x0 = np.array([vals[nm] for nm in STATE_NAMES], dtype=float)
        return x0, dict(p_e=p_e, q_e=q_e, v_refr=v_refr, inner_newton_hist=inner_hist, theta0_guess=th0)

    def refine(self, x0, rho, GR, kind):
        """§3.1 step 4 (as R-HA-B): theta_oc fixed, 32-state Newton, accept only improving steps, stop at 1e-13.
        Returns all accepted iterates (needed for e_num (iii))."""
        fn = self.m.f if kind == 'new' else self.m.f_fixed
        Jn = self.m.J if kind == 'new' else self.m.J_fixed
        x = x0.copy()
        r = float(np.max(np.abs(fn(x, rho, GR))))
        hist = [dict(res=r, accepted=True)]
        iterates = [x.copy()]
        for _ in range(TH['refine_maxit']):
            if r <= TH['refine_stop']:
                break
            F = fn(x, rho, GR)
            Jk = Jn(x, rho, GR)[np.ix_(KEEP, KEEP)]
            cand = x.copy()
            cand[KEEP] += np.linalg.solve(Jk, -F[KEEP])
            rn = float(np.max(np.abs(fn(cand, rho, GR))))
            if not (rn < r):
                hist.append(dict(res=rn, accepted=False))
                break
            x, r = cand, rn
            hist.append(dict(res=r, accepted=True))
            iterates.append(x.copy())
        return x, hist, iterates

    def dispatch_E1(self, G_R):
        """§3.1 with the 1-D outer solve V_ref,dc(P_akt) = v*. Raises nothing; returns ok flag + reason."""
        m = self.m
        rec = dict(kind='E1', G_R=G_R, oned_log=[], ok=False, reason=None)

        def g(P):
            pf = power_flow(P, G_R, m.net)
            if not pf['converged']:
                raise DispatchError(f'power flow not converged at P_akt={P!r} (mismatch {pf["mismatch"]!r})')
            li = load_init(P * m.net['Sbase'] / m.load['base_power'], pf['V2'], m.load)
            val = li['Vref_dc'] - V_STAR
            rec['oned_log'].append(dict(P_akt=P, g=val, pf_mismatch=pf['mismatch']))
            return val

        try:
            a, b = P_AKT_BRACKET
            ga, gb = g(a), g(b)
            if not (ga * gb < 0):
                rec['reason'] = 'E-dagitim: [0.6, 0.9] araliginda isaret degisimi yok'
                return rec
            it = 0
            while b - a > ONED_BISECT_WIDTH and it < ONED_MAXIT:          # bisection
                mid = (a + b) / 2
                gm = g(mid)
                if gm == 0.0:
                    a = b = mid
                    ga = gb = 0.0
                    break
                if (gm < 0) == (ga < 0):
                    a, ga = mid, gm
                else:
                    b, gb = mid, gm
                it += 1
            p0, g0, p1, g1 = a, ga, b, gb                                  # secant (bracket-safeguarded)
            P_akt, gP = (p1, g1) if abs(g1) < abs(g0) else (p0, g0)
            sit = 0
            while abs(gP) > TH['oned'] and sit < ONED_MAXIT and g1 != g0:
                p2 = p1 - g1 * (p1 - p0) / (g1 - g0)
                if not (min(a, b) <= p2 <= max(a, b)):
                    p2 = (a + b) / 2
                g2 = g(p2)
                if (g2 < 0) == (ga < 0):
                    a, ga = p2, g2
                else:
                    b, gb = p2, g2
                p0, g0, p1, g1 = p1, g1, p2, g2
                P_akt, gP = p2, g2
                sit += 1
            rec.update(P_akt=P_akt, oned_residual=abs(gP), oned_bisect_iters=it, oned_secant_iters=sit)
            if abs(gP) > TH['oned']:
                rec['reason'] = f'E-dagitim: 1-B cozum toleransa ulasmadi (|g|={abs(gP)!r})'
                return rec
            pf = power_flow(P_akt, G_R, m.net)
            li = load_init(P_akt * m.net['Sbase'] / m.load['base_power'], pf['V2'], m.load)
            x0, gi = self._assemble(pf, li)
            # rho_T (§3.1 step 5): V_ref,dc is the pre-registered v* (the 1-D solve makes the init value equal to it
            # within 1e-12); P_ref = p_e, Q_ref = q_e, V_ref from the inner initialisation, Iq_ref from load init.
            rho = np.array([gi['p_e'], gi['q_e'], gi['v_refr'], V_STAR, li['Iq_ref']], dtype=float)
            x, hist, iterates = self.refine(x0, rho, G_R, 'new')
            rec.update(ok=True, pf=pf, load_init=dict(P_cnv0=li['P_cnv0'], Vref_dc_init=li['Vref_dc']),
                       gfm_init=gi, x_init=x0, x=x, rho=rho, refine_hist=hist, iterates=iterates)
            return rec
        except (DispatchError, np.linalg.LinAlgError, ValueError, ZeroDivisionError) as exc:
            rec['reason'] = f'E-dagitim: {type(exc).__name__}: {exc}'
            return rec

    def dispatch_RHA(self, P_L):
        """V0 only: R-HA-type re-dispatch with load setpoint P_L, G_R = 0, fixed-frequency model f_tilde(x, 1)."""
        m = self.m
        pf = power_flow(P_L, 0.0, m.net)
        li = load_init(P_L * m.net['Sbase'] / m.load['base_power'], pf['V2'], m.load)
        x0, gi = self._assemble(pf, li)
        rho = np.array([gi['p_e'], gi['q_e'], gi['v_refr'], li['Vref_dc'], li['Iq_ref']], dtype=float)
        x, hist, iterates = self.refine(x0, rho, 0.0, 'fixed')
        return dict(kind='RHA', P_L=P_L, G_R=0.0, ok=pf['converged'], pf=pf, x_init=x0, x=x, rho=rho,
                    refine_hist=hist, iterates=iterates, gfm_init=gi,
                    load_init=dict(P_cnv0=li['P_cnv0'], Vref_dc_init=li['Vref_dc']))


# ------------------------------------------------------------------------------------------------------------
# §5.1a checks and §4 limits
# ------------------------------------------------------------------------------------------------------------
def bus_powers(x, GR):
    V1 = complex(x[IX['V_1:R']], x[IX['V_1:I']])
    V2 = complex(x[IX['V_2:R']], x[IX['V_2:I']])
    IfG = complex(x[IX[G + ':ir_filter']], x[IX[G + ':ii_filter']])
    IfL = complex(x[IX[L + ':ir_filter']], x[IX[L + ':ii_filter']])
    SG = V1 * np.conj(IfG)
    S_act = V2 * np.conj(IfL)                       # drawn by the active load
    S_R = GR * abs(V2) ** 2                         # drawn by G_R
    return dict(V1=V1, V2=V2, P_G=SG.real, Q_G=SG.imag, S_G=abs(SG), P_act=S_act.real, Q_act=S_act.imag,
                P_R=S_R, P_102=S_act.real + S_R, Q_102=S_act.imag)


def checks_51a(model, x, rho, GR, point, disp=None, kind='new'):
    """point in {'T','S'}; T: all six checks; S: residual, PLL, finiteness (others 'uygulanamaz')."""
    fn = model.f if kind == 'new' else model.f_fixed
    F = fn(x, rho, GR)
    out = {}
    if point == 'T':
        pfm = disp['pf']['mismatch']
        out['pf_mismatch'] = dict(applicable=True, value=pfm, passed=pfm <= TH['pf_mismatch'])
        if disp['kind'] == 'E1':
            out['oned'] = dict(applicable=True, value=disp['oned_residual'], passed=disp['oned_residual'] <= TH['oned'])
            bp = bus_powers(x, GR)
            target = disp['P_akt'] + bp['P_R']
            dP = abs(bp['P_102'] - target)
            out['closure'] = dict(applicable=True, value=dP, passed=dP <= TH['closure'])
        else:
            out['oned'] = dict(applicable=False, note='V0 (R-HA-type) dispatch has no 1-D solve')
            bp = bus_powers(x, GR)
            dP = abs(bp['P_102'] - disp['P_L'])
            out['closure'] = dict(applicable=True, value=dP, passed=dP <= TH['closure'])
    else:
        for k in ('pf_mismatch', 'oned', 'closure'):
            out[k] = dict(applicable=False, note='S yeniden dagitilmaz (§5.1a): uygulanamaz')
    res = float(np.max(np.abs(F)))
    out['residual'] = dict(applicable=True, value=res, passed=res <= TH['res'],
                           ode_rhs_inf=float(np.max(np.abs(F / model.M))))
    vq = model.aux('Vq_pll', x, rho, GR)
    out['pll'] = dict(applicable=True, value=abs(vq), passed=abs(vq) <= TH['vq'])
    fin = bool(np.all(np.isfinite(x)) and np.all(np.isfinite(rho)) and np.all(np.isfinite(F)))
    out['finite'] = dict(applicable=True, passed=fin)
    out['all_applicable_passed'] = all(v['passed'] for k, v in out.items() if isinstance(v, dict) and v.get('applicable'))
    return out, F


def cmp_upper(v, u, d=TH['delta_L']):
    return OK if v <= u - d else (VIOL if v >= u + d else BORDER)


def cmp_lower(v, lo, d=TH['delta_L']):
    return OK if v >= lo + d else (VIOL if v <= lo - d else BORDER)


def combine(*st):
    return VIOL if VIOL in st else (BORDER if BORDER in st else OK)


def l6_status(e_dc):
    """§4 L6: e_dc <= tau_dc (zero included) ok; e_dc >= tau_dc + delta_dc violation; otherwise borderline."""
    if e_dc <= TH['tau_dc']:
        return OK
    if e_dc >= TH['tau_dc'] + TH['delta_dc']:
        return VIOL
    return BORDER


def limits(model, x, rho, GR):
    """§4 decision limits L1-L6 (each separately) + report-only quantities."""
    def mag(a, b):
        return math.hypot(x[IX[a]], x[IX[b]])
    IcG, IfG = mag(G + ':ir_cnv', G + ':ii_cnv'), mag(G + ':ir_filter', G + ':ii_filter')
    IcL, IfL = mag(L + ':ir_cnv', L + ':ii_cnv'), mag(L + ':ir_filter', L + ':ii_filter')
    V1m, V2m = mag('V_1:R', 'V_1:I'), mag('V_2:R', 'V_2:I')
    wF = model.h(x, rho)
    VcL = math.hypot(model.aux('Vd_c_L', x, rho, GR), model.aux('Vq_c_L', x, rho, GR))
    vdc = x[IX[V_DC]]
    g5 = VcL - TH['m_max'] * vdc
    e_dc = abs(vdc - V_STAR)
    limit_rows = {}
    limit_rows['L1'] = dict(value=max(IcG, IfG), I_c=IcG, I_f=IfG, status=cmp_upper(max(IcG, IfG), TH['L1']))
    limit_rows['L2'] = dict(value=max(IcL, IfL), I_c=IcL, I_f=IfL, status=cmp_upper(max(IcL, IfL), TH['L2']))
    s3 = [combine(cmp_lower(v, TH['L3'][0]), cmp_upper(v, TH['L3'][1])) for v in (V1m, V2m)]
    limit_rows['L3'] = dict(V_101=V1m, V_102=V2m, status_101=s3[0], status_102=s3[1], status=combine(*s3))
    limit_rows['L4'] = dict(value=wF, f_Hz=60.0 * wF, status=combine(cmp_lower(wF, TH['L4'][0]), cmp_upper(wF, TH['L4'][1])))
    limit_rows['L5'] = dict(value=g5, Vc_L=VcL, v_dc=vdc, status=cmp_upper(g5, 0.0))
    limit_rows['L6'] = dict(value=e_dc, status=l6_status(e_dc))
    Lim = combine(*[limit_rows[k]['status'] for k in ('L1', 'L2', 'L3', 'L4', 'L5', 'L6')])
    bp = bus_powers(x, GR)
    VcG = math.hypot(model.aux('Vd_cnv_G', x, rho, GR), model.aux('Vq_cnv_G', x, rho, GR))
    report = dict(V_cnv_G=VcG, S_G=bp['S_G'], P_G=bp['P_G'], Q_G=bp['Q_G'], P_102=bp['P_102'], Q_102=bp['Q_102'],
                  P_act=bp['P_act'], Q_act=bp['Q_act'], P_R=bp['P_R'], omega_F=wF, f_Hz=60.0 * wF,
                  eps_pll=x[IX[L + ':' + LOAD_STATES[1]]], P_dc=vdc ** 2 / model.load['r_load'],
                  ansi_A_101=bool(0.95 <= V1m <= 1.05), ansi_A_102=bool(0.95 <= V2m <= 1.05),
                  theta_oc=x[I_THETA], delta_pll=x[IX[TH_PLL]], p_e=model.aux('p_e', x, rho, GR),
                  q_e=model.aux('q_e', x, rho, GR))
    return dict(limits=limit_rows, Lim=Lim, report=report)


# ------------------------------------------------------------------------------------------------------------
# §3.3 post-shed continuation
# ------------------------------------------------------------------------------------------------------------
def newton_theta_fixed(model, x0, rho, GR):
    """32-unknown Newton with the analytic chained Jacobian (§3.3). Acceptance: ||F||_inf <= 1e-12, or on
    stagnation (non-decreasing residual, or maxit reached) ||F||_inf <= 1e-8. Keeps all iterates."""
    x = x0.copy()
    F = model.f(x, rho, GR)
    r = float(np.max(np.abs(F)))
    hist, iterates, stop = [r], [x.copy()], None
    for _ in range(TH['newton_maxit']):
        if r <= TH['newton_tol']:
            stop = 'tol'
            break
        try:
            Jk = model.J(x, rho, GR)[np.ix_(KEEP, KEEP)]
            dx = np.linalg.solve(Jk, -F[KEEP])
        except np.linalg.LinAlgError:
            stop = 'singular'
            break
        xn = x.copy()
        xn[KEEP] += dx
        Fn = model.f(xn, rho, GR)
        rn = float(np.max(np.abs(Fn)))
        if not (np.isfinite(rn) and rn < r):
            stop = 'stagnation'
            break
        x, F, r = xn, Fn, rn
        hist.append(r)
        iterates.append(x.copy())
    else:
        stop = 'maxit'
    if r <= TH['newton_tol']:
        crit = 'tol'
    elif r <= TH['newton_stag'] and stop in ('stagnation', 'maxit'):
        crit = 'stagnation<=1e-8'
    else:
        crit = None
    return dict(x=x, converged=crit is not None, criterion=crit, stop=stop, res=r, hist=hist,
                iterates=iterates, n_iter=len(hist) - 1)


def jac_diag(model, x, rho, GR):
    Jk = model.J(x, rho, GR)[np.ix_(KEEP, KEEP)]
    sign, logdet = np.linalg.slogdet(Jk)
    return int(sign), float(logdet), float(np.linalg.cond(Jk))


def continuation(model, xT, rho, GR_T):
    """§3.3: G_R(lambda) = (1 - lambda) G_R,T, lambda = k/20; on failure the interval is split into 2^h substeps
    (h = 1..5). No eigenvalues are computed along the path."""
    nst = TH['n_steps']
    s0, l0, c0 = jac_diag(model, xT, rho, GR_T)
    log = [dict(lam=0.0, G_R=GR_T, res=float(np.max(np.abs(model.f(xT, rho, GR_T)))), n_iter=0, halvings=0,
                det_sign=s0, logabsdet=l0, cond=c0, criterion='start', x=xT.copy())]
    x = xT.copy()
    last_newton = None
    for i in range(1, nst + 1):
        success = False
        for hv in range(0, TH['halvings'] + 1):
            nsub = 2 ** hv
            xs, sub_logs, ok, res_i = x.copy(), [], True, None
            for j in range(1, nsub + 1):
                lam = (i - 1 + j / nsub) / nst
                GR = (1.0 - lam) * GR_T
                res_i = newton_theta_fixed(model, xs, rho, GR)
                if not res_i['converged']:
                    ok = False
                    sub_logs.append(dict(lam=lam, G_R=GR, res=res_i['res'], n_iter=res_i['n_iter'], halvings=hv,
                                         criterion=None, stop=res_i['stop'], converged=False,
                                         x=res_i['x'].copy(), res_hist=list(res_i['hist'])))
                    break
                xs = res_i['x']
                sg, ld, cd = jac_diag(model, xs, rho, GR)
                sub_logs.append(dict(lam=lam, G_R=GR, res=res_i['res'], n_iter=res_i['n_iter'], halvings=hv,
                                     det_sign=sg, logabsdet=ld, cond=cd, criterion=res_i['criterion'],
                                     stop=res_i['stop'], converged=True, x=xs.copy()))
            if ok:
                success = True
                x = xs
                last_newton = res_i
                log.extend(sub_logs)
                break
            log.extend([dict(sl, attempt_failed=True) for sl in sub_logs])
        if not success:
            conv = [e for e in log if e.get('converged', True) and 'det_sign' in e and not e.get('attempt_failed')]
            signs = [e['det_sign'] for e in conv]
            sign_change = any(signs[k] != signs[k - 1] for k in range(1, len(signs)))
            # §3.3: det sign change along lambda OR cond > 1e12 at any converged point, then no convergence
            high_cond = any(e['cond'] > TH['cond_branch'] for e in conv)
            reason = 'E-dal?' if (sign_change or high_cond) else 'E-cozucu'
            return dict(reached=False, reason=reason, failed_interval=(i - 1, i), log=log, x=x,
                        det_sign_change=sign_change, high_cond=high_cond)
    conv = [e for e in log if 'det_sign' in e and not e.get('attempt_failed')]
    signs = [e['det_sign'] for e in conv]
    return dict(reached=True, reason=None, log=log, x=x, last_newton=last_newton,
                det_sign_change=any(signs[k] != signs[k - 1] for k in range(1, len(signs))),
                max_cond=max(e['cond'] for e in conv))


# ------------------------------------------------------------------------------------------------------------
# §5.0 alpha, §5.1b spectral validity, §5.2 e_num
# ------------------------------------------------------------------------------------------------------------
def eig_part(A):
    lam, R = np.linalg.eig(A)
    W = np.linalg.inv(R)
    PFm = np.abs(R * W.T)
    PFn = PFm / PFm.sum(axis=0, keepdims=True)
    return lam, R, W, PFn


def identify_ref(lam, PFn, theta_row_zero):
    """§5.0 / §5.1b reference-mode identity: theta_oc row structurally zero AND exactly one |lambda| <= 1e-8 AND
    its theta_oc eigen-normalised participation >= 0.99. No other mode is ever removed."""
    zero_idx = [i for i in range(len(lam)) if abs(lam[i]) <= TH['zero']]
    theta_part = float(PFn[I_THETA, zero_idx[0]]) if len(zero_idx) == 1 else None
    ok = bool(theta_row_zero) and len(zero_idx) == 1 and theta_part >= TH['ref_part']
    return dict(ok=ok, idx=zero_idx[0] if ok else None, n_zero=len(zero_idx), zero_idx=zero_idx,
                theta_part=theta_part, theta_row_zero=bool(theta_row_zero))


def alpha_from(lam, ref):
    """alpha(K) = max Re over P(K) = sigma(A) minus {lambda_ref}; critical mode = member with Re = alpha and Im >= 0
    (largest Im if several). Undefined if the reference identity failed (raw max reported separately)."""
    raw = float(np.max(lam.real))
    if not ref['ok']:
        return dict(defined=False, alpha=None, icrit=None, raw_max_re=raw, n_physical=None)
    P = [i for i in range(len(lam)) if i != ref['idx']]
    a = float(max(lam[i].real for i in P))
    cand = [i for i in P if lam[i].real == a]
    pos = [i for i in cand if lam[i].imag >= 0]
    icrit = max(pos or cand, key=lambda i: lam[i].imag)
    return dict(defined=True, alpha=a, icrit=icrit, raw_max_re=raw, n_physical=len(P),
                crit_choice_note=None if pos else 'no Im>=0 member with Re=alpha; largest-Im member taken')


def alpha_of_matrix(A, theta_row_zero):
    lam, R, W, PFn = eig_part(A)
    ref = identify_ref(lam, PFn, theta_row_zero)
    return alpha_from(lam, ref), lam, ref


def spectral(model, x, rho, GR, kind='new', pair=None, enum=True):
    """Full spectral analysis of the fixed T or final S (never of candidates). kind='fixed' only for V0."""
    Jfun = model.J if kind == 'new' else model.J_fixed
    trz = model.theta_row_zero[kind]
    M = model.M
    J = Jfun(x, rho, GR)
    A = J / M[:, None]
    lam, R, W, PFn = eig_part(A)
    normA = float(np.linalg.norm(A, 2))
    backward = np.array([np.linalg.norm(A @ R[:, i] - lam[i] * R[:, i]) /
                         ((normA + abs(lam[i])) * np.linalg.norm(R[:, i])) for i in range(N)])
    kappa = np.array([np.linalg.norm(W[i, :]) * np.linalg.norm(R[:, i]) for i in range(N)])
    ref = identify_ref(lam, PFn, trz)
    al = alpha_from(lam, ref)
    out = dict(kind=kind, J=J, A=A, lam=lam, R=R, W=W, PFn=PFn, normA=normA, backward=backward, kappa=kappa,
               ref=ref, alpha=al, finite=bool(np.all(np.isfinite(J)) and np.all(np.isfinite(lam))
                                             and np.all(np.isfinite(R))))
    if not enum:
        return out
    # V2: chained-Jacobian complex-step check
    cs = {}
    Jcs = {}
    for hstep in CS_STEPS:
        Jc = model.J_complex_step(x, rho, GR, hstep, model=kind)
        Jcs[hstep] = Jc
        e, rn, cn = ej(J, Jc)
        cs[repr(hstep)] = dict(E_J=e, worst_eq=rn, worst_state=cn, passed=e <= TH['EJ'])
    out['V2'] = dict(steps=cs, passed=all(v['passed'] for v in cs.values()))
    # e_num (§5.2): all three components must be available; a missing component is NOT counted as zero.
    comp = {}
    k = al['icrit']
    if al['defined']:
        comp['i'] = dict(available=True, value=float(kappa[k] * backward[k] * (normA + abs(lam[k]))))
        Jc = Jcs[CS_STEPS[0]]
        trz_cs = bool(np.all(Jc[I_THETA, :] == 0.0))
        al_cs, _, ref_cs = alpha_of_matrix(Jc / M[:, None], trz_cs)
        if al_cs['defined']:
            comp['ii'] = dict(available=True, value=abs(al['alpha'] - al_cs['alpha']), alpha_cs=al_cs['alpha'])
        else:
            comp['ii'] = dict(available=False, reason='reference identity failed for the complex-step Jacobian',
                              ref_cs=ref_cs)
        if pair is not None and pair.get('x_prev') is not None:
            al_p, _, ref_p = alpha_of_matrix(Jfun(pair['x_prev'], rho, GR) / M[:, None], trz)
            if al_p['defined']:
                comp['iii'] = dict(available=True, value=abs(al['alpha'] - al_p['alpha']), alpha_prev=al_p['alpha'],
                                   pair_kind=pair['kind'])
            else:
                comp['iii'] = dict(available=False, reason='reference identity failed at x_prev', pair_kind=pair['kind'])
        else:
            comp['iii'] = dict(available=False, reason=(pair or {}).get('reason', 'no Newton pair'))
    else:
        for c in ('i', 'ii', 'iii'):
            comp[c] = dict(available=False, reason='alpha undefined (reference identity failed)')
    complete = all(c['available'] for c in comp.values())
    e_num = max(c['value'] for c in comp.values()) if complete else None
    out['e_num'] = dict(components=comp, complete=complete, value=e_num,
                        passed=bool(complete and e_num <= TH['eta_alpha'] / 10))
    return out


def newton_pair(model, x_last, iterates, rho, GR):
    """Last two Newton states for e_num (iii). If the solver accepted >= 1 update, the pair is (iterates[-2],
    iterates[-1]). If no update was taken (already converged), one diagnostic Newton step from x_last is computed
    (not accepted into the state) so that (iii) is evaluated, never silently set to zero. If even that fails the
    component is reported missing (-> e_num incomplete -> N invalid)."""
    if len(iterates) >= 2:
        return dict(kind='accepted_pair', x_prev=iterates[-2], x_last=iterates[-1])
    try:
        F = model.f(x_last, rho, GR)
        Jk = model.J(x_last, rho, GR)[np.ix_(KEEP, KEEP)]
        xd = x_last.copy()
        xd[KEEP] += np.linalg.solve(Jk, -F[KEEP])
        if not np.all(np.isfinite(xd)):
            raise ValueError('non-finite diagnostic step')
        return dict(kind='diagnostic_step', x_prev=xd, x_last=x_last,
                    step_inf=float(np.max(np.abs(xd - x_last))))
    except (np.linalg.LinAlgError, ValueError) as exc:
        return dict(kind='missing', x_prev=None, reason=f'diagnostic Newton step failed: {exc}')


# ------------------------------------------------------------------------------------------------------------
# §8 V1, V3, V4, V5
# ------------------------------------------------------------------------------------------------------------
def V1(model, x, rho, GR):
    res = float(np.max(np.abs(model.f(x, rho, GR))))
    hdev = abs(model.h(x, rho) - 1.0)
    return dict(residual=res, h_minus_1=hdev, passed=res <= TH['res'] and hdev <= TH['v1_h'])


def V3(model, x, rho, GR):
    M = model.M
    A_new = model.J(x, rho, GR) / M[:, None]
    A_fix = model.Jx_tilde(x, 1.0, rho, GR) / M[:, None]
    E = np.zeros((N, N))
    E[:, I_PM] = -model.gfm['Rp'] * model.Jz_tilde(x, 1.0, rho, GR) / M
    e, rn, cn = ej(A_new - A_fix, E)
    D = A_new - A_fix
    other_cols = float(np.max(np.abs(np.delete(D, I_PM, axis=1))))
    return dict(metric=e, worst_row=rn, worst_col=cn, max_abs_outside_pm_col=other_cols, passed=e <= TH['v3'])


def T_phi(x, phi):
    c, s = math.cos(phi), math.sin(phi)
    y = np.array(x, dtype=float).copy()
    for a, b in RI_PAIRS:
        r, i = x[IX[a]], x[IX[b]]
        y[IX[a]], y[IX[b]] = c * r - s * i, s * r + c * i
    for ang in ANGLE_STATES:
        y[IX[ang]] = x[IX[ang]] + phi
    return y


def D_phi(v, phi):
    c, s = math.cos(phi), math.sin(phi)
    y = np.array(v, dtype=float).copy()
    for a, b in RI_PAIRS:
        r, i = v[IX[a]], v[IX[b]]
        y[IX[a]], y[IX[b]] = c * r - s * i, s * r + c * i
    return y


def match_spectra(l1, l2):
    C = np.abs(l1[:, None] - l2[None, :])
    r, c = linear_sum_assignment(C)
    return [(int(i), int(j), float(abs(l1[i] - l2[j]))) for i, j in zip(r, c)]


def V4(model, x, rho, GR, spec):
    rng = np.random.default_rng(V4_SEED)
    v = rng.standard_normal(N)
    x_pert = x + V4_DELTA * v / np.linalg.norm(v)
    tests = []
    for phi in V4_PHIS:
        for lab, base in (('equilibrium', x), ('perturbed', x_pert)):
            fb = model.f(base, rho, GR)
            err = float(np.max(np.abs(model.f(T_phi(base, phi), rho, GR) - D_phi(fb, phi))))
            tol = TH['v4_rel'] * max(1.0, float(np.max(np.abs(fb))))
            tests.append(dict(phi=phi, point=lab, err=err, tol=tol, passed=err <= tol))
    eq = []
    for phi in V4_PHIS:
        xr = T_phi(x, phi)
        res_r = float(np.max(np.abs(model.f(xr, rho, GR))))
        p0, p1 = bus_powers(x, GR), bus_powers(xr, GR)
        pw = {}
        for kname in ('P_G', 'Q_G', 'P_102', 'Q_102', 'P_act', 'Q_act'):
            d = abs(p1[kname] - p0[kname])
            pw[kname] = dict(diff=d, passed=d <= TH['v4_rel'] * max(1.0, abs(p0[kname])))
        sr = spectral(model, xr, rho, GR, enum=False)
        okref = spec['ref']['ok'] and sr['ref']['ok']
        if okref:
            l0 = np.delete(spec['lam'], spec['ref']['idx'])
            l1 = np.delete(sr['lam'], sr['ref']['idx'])
            mt = match_spectra(l0, l1)
            worst = max(d / (1 + abs(l0[i])) for i, j, d in mt)
            spec_ok = all(d <= TH['v4_eig'] * (1 + abs(l0[i])) for i, j, d in mt)
        else:
            worst, spec_ok = None, False
        eq.append(dict(phi=phi, residual_rotated=res_r, residual_passed=res_r <= TH['res'], powers=pw,
                       powers_passed=all(p['passed'] for p in pw.values()), ref_ok_both=okref,
                       spectrum_worst_rel=worst, spectrum_passed=spec_ok))
    passed = all(t['passed'] for t in tests) and all(e['residual_passed'] and e['powers_passed'] and
                                                    e['spectrum_passed'] for e in eq)
    return dict(tests=tests, equilibrium=eq, passed=passed, seed=V4_SEED, delta_norm=V4_DELTA)


def V5(model, x, rho, GR):
    """Descriptive port admittance of the active load at bus 102 (frame frequency held at its equilibrium value)."""
    zs = model.h(x, rho)
    Jx = model.Jx_tilde(x, zs, rho, GR)
    iL = [IX[n] for n in LOAD_STATE_NAMES]
    iV = [IX['V_2:R'], IX['V_2:I']]
    ML = model.M[iL]
    A_L = Jx[np.ix_(iL, iL)] / ML[:, None]
    B = Jx[np.ix_(iL, iV)] / ML[:, None]
    C = np.zeros((2, len(iL)))
    C[0, LOAD_STATE_NAMES.index(L + ':ir_filter')] = 1.0
    C[1, LOAD_STATE_NAMES.index(L + ':ii_filter')] = 1.0
    rows = []
    I12 = np.eye(len(iL))
    for fhz in V5_F_HZ:
        w = 2 * math.pi * fhz
        Y = C @ np.linalg.solve(1j * w * I12 - A_L, B)
        H = (Y + Y.conj().T) / 2
        ev = np.linalg.eigvalsh(H)
        rows.append(dict(f_Hz=float(fhz), omega=w, lam_min_H=float(ev[0]), lam_max_H=float(ev[1]),
                         Y=[[complex(Y[a, b]) for b in range(2)] for a in range(2)]))
    return dict(z_star=zs, rows=rows, min_lam_min_H=min(r['lam_min_H'] for r in rows),
                f_at_min=rows[int(np.argmin([r['lam_min_H'] for r in rows]))]['f_Hz'])


# ------------------------------------------------------------------------------------------------------------
# §6 gates, F decision; §7 categories and effect
# ------------------------------------------------------------------------------------------------------------
def mrj(alpha):
    e, n = TH['eps_margin'], TH['eta_alpha']
    if alpha <= -e - n:
        return 'Mrj-saglaniyor'
    if alpha >= -e + n:
        return 'Mrj-ihlal'
    return 'Mrj-belirsiz'


def sign_subtype(alpha):
    n = TH['eta_alpha']
    if alpha >= n:
        return 'kararsiz'
    if abs(alpha) < n:
        return 'sifira_yakin'
    return 'marj_kaybi_kararli'


def F_decision(D, Lim, Nok, M):
    if not D:
        return 'F-degerlendirilemez'
    if Lim == VIOL or (Nok and M == 'Mrj-ihlal'):
        return 'F-ret'
    if Lim == OK and Nok and M == 'Mrj-saglaniyor':
        return 'F-onay'
    return 'F-belirsiz'


def category_71(Tdec, S):
    """§7.1 two-step disjoint table. S: dict(D, Lim, N, Mrj)."""
    if Tdec == 'F-ret':
        return dict(step=1, row=None, category='Uygulanamaz: T notin F (onayli)')
    if Tdec != 'F-onay':
        return dict(step=1, row=None, category='Degerlendirilemez: T uyeligi belirlenemedi (T notin F kaniti degil)')
    if not S['D']:
        return dict(step=2, row='1', category='Degerlendirilemez - atma sonrasi denge kurulamadi')
    Lim, Nok, M = S['Lim'], S['N'], S['Mrj']
    if Lim == OK:
        if not Nok:
            return dict(step=2, row='8', category='Degerlendirilemez - spektral sayisal gecerlilik yok')
        return {'Mrj-ihlal': dict(step=2, row='2', category='Saf mekanizma ihlali [M]'),
                'Mrj-saglaniyor': dict(step=2, row='6', category='Ihlal yok (S in F onayli)'),
                'Mrj-belirsiz': dict(step=2, row='7', category='Belirsiz - marj bandinda')}[M]
    if Lim == VIOL:
        if Nok and M == 'Mrj-ihlal':
            return dict(step=2, row='3', category='Karma ihlal [L+M]')
        if Nok and M == 'Mrj-saglaniyor':
            return dict(step=2, row='4', category='Yalniz sinir ihlali [L]')
        return dict(step=2, row='5', category='Sinir ihlali; kararlilik belirsiz ya da degerlendirilemez [L+?]')
    if Nok and M == 'Mrj-ihlal':
        return dict(step=2, row='9a', category='Marj ihlali; sinirlar sinirda [M + L?] (F-ret kesin; mekanizma atfi belirsiz)')
    return dict(step=2, row='9b', category='Belirsiz - sinirda')


def effect_72(T, S):
    """§7.2: requires valid D and N (and defined alpha) at both points."""
    valid = T['D'] and T['N'] and S['D'] and S['N'] and T['alpha'] is not None and S['alpha'] is not None
    if not valid:
        raw = (S.get('alpha_raw') - T.get('alpha_raw')) if (S.get('alpha_raw') is not None and
                                                            T.get('alpha_raw') is not None) else None
        return dict(decision='degerlendirilemez', d_alpha=None, d_alpha_raw_flagged=raw)
    d = S['alpha'] - T['alpha']
    e, n = TH['eps_effect'], TH['eta_alpha']
    if d >= e + n:
        dec = 'anlamli_kotulesme'
    elif d <= -e - n:
        dec = 'anlamli_iyilesme'
    elif abs(d) <= e - n:
        dec = 'anlamsiz'
    else:
        dec = 'belirsiz'
    return dict(decision=dec, d_alpha=d)


def group_of(name):
    dev, st = name.split(':', 1)
    if dev == L:
        if st in (LOAD_STATES[2], 'v_dc'):
            return 'G_DC'
        if st in (LOAD_STATES[0], LOAD_STATES[1]):
            return 'G_PLL'
        if st in (LOAD_STATES[4], LOAD_STATES[5], 'ir_cnv', 'ii_cnv'):
            return 'G_LCC'
        return 'G_LF'
    if dev == G:
        return 'G_GFM'
    return 'G_NET'


GROUPS = ['G_DC', 'G_PLL', 'G_LCC', 'G_LF', 'G_NET', 'G_GFM']
