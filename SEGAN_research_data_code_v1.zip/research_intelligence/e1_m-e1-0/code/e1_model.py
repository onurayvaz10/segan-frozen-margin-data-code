"""E1 M-E1-0 model: f_tilde(x, z; rho, G_R) and the chained new model f(x) = f_tilde(x, h(x)).

Fixed pre-registration: e1_m-e1-0/sabit/PF1_E1_On_Kayit_M-E1-0_v1.0_SABIT.md
(sha256 11c08c3ebf9a40aa27d5165a1912eea30777ee639e50a02ed667a4015606a84b), §2.4-§2.6.

* z (frame frequency) enters ONLY the designated frame terms (pre-reg §2.5 table, bold z):
  both LCL cross-coupling terms, line reactance terms, bus shunt terms, and the load PLL angle row.
* The GFM inner/outer controller keeps omega_oc = h(x) = omega_ref + R_p (P_ref - p_m) as an x-dependence.
* The load PLL absolute frequency is 1 + dw (nominal feed-forward); delta_pll' = omega_b (1 + dw - z).
* theta_oc row is identically 0 in f_tilde (and therefore in both models).
* G_R enters only the bus-102 rows.
New model (E1):            f(x)      = f_tilde(x, h(x))  -> Jacobian by symbolic chain rule.
Fixed comparison model (V0): f_tilde(x, 1)                 (with G_R = 0 identical to the R-HA-B model).
Parameters, Park transforms and state names are imported unchanged from the validated R-HA-B module.
"""
import math
import sys
from pathlib import Path

import numpy as np
import sympy as sp

RHAB_CODE = Path(__file__).resolve().parents[2] / 'r_ha_b' / 'code'
sys.path.insert(0, str(RHAB_CODE))
import rhab_model as RB  # noqa: E402  (validated, unchanged; sha256 db9dd3fd...)
from rhab_model import G, L, LINE, GFM_STATES, LOAD_STATES, STATE_NAMES, N, WB, park, inv_park  # noqa: E402

REF_NAMES = ['P_ref', 'Q_ref', 'V_ref', 'V_ref_dc', 'Iq_ref']
IX = {nm: k for k, nm in enumerate(STATE_NAMES)}

TH_OC = G + ':' + GFM_STATES[0]
P_M = G + ':' + GFM_STATES[1]
TH_PLL = L + ':' + LOAD_STATES[0]
EPS_PLL = L + ':' + LOAD_STATES[1]
V_DC = L + ':' + LOAD_STATES[3]
I_THETA = IX[TH_OC]
I_PM = IX[P_M]

# pre-reg §2.3: v* = 700 / (sqrt(8/3) * 380), evaluated with the same base expression as the load parameters
# (load_data.jl:63 'sqrt(8)/sqrt(3) * Vb', used by rhab_model.parameters for r_load, k_pv, ...).
VB_DC = math.sqrt(8) / math.sqrt(3) * 380.0
V_STAR = 700.0 / VB_DC

# Rows that must contain z (pre-reg §2.5 bold z; §2.6 d f_tilde/dz table)
Z_ROWS_EXPECTED = (
    [G + ':' + s for s in ('ir_cnv', 'ii_cnv', 'vr_filter', 'vi_filter', 'ir_filter', 'ii_filter')]
    + [L + ':' + s for s in ('ir_cnv', 'ii_cnv', 'vr_filter', 'vi_filter', 'ir_filter', 'ii_filter')]
    + [TH_PLL, LINE + ':Il_R', LINE + ':Il_I', 'V_1:R', 'V_1:I', 'V_2:R', 'V_2:I'])
GR_ROWS_EXPECTED = ['V_2:R', 'V_2:I']

# RI pairs and angle states for V4 (pre-reg §8)
RI_PAIRS = [('V_1:R', 'V_1:I'), ('V_2:R', 'V_2:I'), (LINE + ':Il_R', LINE + ':Il_I')] + \
           [(p + ':' + a, p + ':' + b) for p in (G, L)
            for a, b in (('ir_cnv', 'ii_cnv'), ('vr_filter', 'vi_filter'), ('ir_filter', 'ii_filter'))]
ANGLE_STATES = [TH_OC, TH_PLL]
LOAD_STATE_NAMES = [L + ':' + s for s in LOAD_STATES]


def mass_vector(load, gfm, net):
    """Diagonal of M (identical construction to rhab_model.build_symbolic; pre-reg §2.5)."""
    M = np.ones(N)
    M[IX['V_1:R']] = M[IX['V_1:I']] = net['b_from'] / WB
    M[IX['V_2:R']] = M[IX['V_2:I']] = net['b_to'] / WB
    for pre, p in ((G, gfm), (L, load)):
        for s, val in (('ir_cnv', p['lf']), ('ii_cnv', p['lf']), ('vr_filter', p['cf']), ('vi_filter', p['cf']),
                       ('ir_filter', p['lg']), ('ii_filter', p['lg'])):
            M[IX[pre + ':' + s]] = val / WB
    return M


def build_ftilde():
    load, gfm, net = RB.parameters()
    x = sp.symbols('x0:%d' % N)
    X = dict(zip(STATE_NAMES, x))
    z = sp.Symbol('z')
    GR = sp.Symbol('G_R')
    rho = sp.symbols(' '.join(REF_NAMES))
    Pref, Qref, Vref, Vref_dc, Iq_ref = rho
    f = {}
    Vr1, Vr2, Vi1, Vi2 = X['V_1:R'], X['V_2:R'], X['V_1:I'], X['V_2:I']

    # ---- GFM (pre-reg §2.5 abbreviations; h kept as x-dependence) ----
    g = [X[G + ':' + s] for s in GFM_STATES]
    th, pm, qm, xid, xiq, gd, gq, phd, phq, Irc, Iic, Vrf, Vif, Irf, Iif = g
    h = gfm['w_ref'] + gfm['Rp'] * (Pref - pm)
    p_e = Irf * Vrf + Iif * Vif
    q_e = -Iif * Vrf + Irf * Vif
    f[TH_OC] = sp.Integer(0)
    f[P_M] = gfm['wz'] * (p_e - pm)
    f[G + ':' + GFM_STATES[2]] = gfm['wf'] * (q_e - qm)
    V_oc = Vref + gfm['kq'] * (Qref - qm)
    Idf, Iqf = park(th, Irf, Iif)
    Idc, Iqc = park(th, Irc, Iic)
    Vdf, Vqf = park(th, Vrf, Vif)
    Vd_ref = V_oc - gfm['rv'] * Idf + h * gfm['lv'] * Iqf
    Vq_ref = -gfm['rv'] * Iqf - h * gfm['lv'] * Idf
    Id_pi = gfm['kpv'] * (Vd_ref - Vdf) + gfm['kiv'] * xid
    Iq_pi = gfm['kpv'] * (Vq_ref - Vqf) + gfm['kiv'] * xiq
    f[G + ':' + GFM_STATES[3]] = Vd_ref - Vdf
    f[G + ':' + GFM_STATES[4]] = Vq_ref - Vqf
    Idc_ref = Id_pi - gfm['cf'] * h * Vqf + gfm['kffi'] * Idf
    Iqc_ref = Iq_pi + gfm['cf'] * h * Vdf + gfm['kffi'] * Iqf
    Vd_pi = gfm['kpc'] * (Idc_ref - Idc) + gfm['kic'] * gd
    Vq_pi = gfm['kpc'] * (Iqc_ref - Iqc) + gfm['kic'] * gq
    f[G + ':' + GFM_STATES[5]] = Idc_ref - Idc
    f[G + ':' + GFM_STATES[6]] = Iqc_ref - Iqc
    Vd_cnv = Vd_pi - h * gfm['lf'] * Iqc + gfm['kffv'] * Vdf - gfm['kad'] * (Vdf - phd)
    Vq_cnv = Vq_pi + h * gfm['lf'] * Idc + gfm['kffv'] * Vqf - gfm['kad'] * (Vqf - phq)
    f[G + ':' + GFM_STATES[7]] = gfm['wad'] * (Vdf - phd)
    f[G + ':' + GFM_STATES[8]] = gfm['wad'] * (Vqf - phq)
    md, mq = Vd_cnv / gfm['Vdc'], Vq_cnv / gfm['Vdc']           # inner_control_models.jl:251-252
    mr, mi = inv_park(th, md, mq)                               # converter_models.jl:31
    Vr_cnv, Vi_cnv = mr * gfm['Vdc'], mi * gfm['Vdc']
    f[G + ':ir_cnv'] = Vr_cnv - Vrf - gfm['rf'] * Irc + z * gfm['lf'] * Iic
    f[G + ':ii_cnv'] = Vi_cnv - Vif - gfm['rf'] * Iic - z * gfm['lf'] * Irc
    f[G + ':vr_filter'] = Irc - Irf + z * gfm['cf'] * Vif
    f[G + ':vi_filter'] = Iic - Iif - z * gfm['cf'] * Vrf
    f[G + ':ir_filter'] = Vrf - Vr1 - gfm['rg'] * Irf + z * gfm['lg'] * Iif
    f[G + ':ii_filter'] = Vif - Vi1 - gfm['rg'] * Iif - z * gfm['lg'] * Irf
    kG = gfm['base_power'] / net['Sbase']

    # ---- Active load ----
    l = [X[L + ':' + s] for s in LOAD_STATES]
    thp, eps, eta, vdc, lgd, lgq, lIrc, lIic, lVrf, lVif, lIrf, lIif = l
    lIdc, lIqc = park(thp, lIrc, lIic)
    Vdp, Vqp = park(thp, lVrf, lVif)
    dw = load['kp_pll'] * Vqp + load['ki_pll'] * eps
    w_abs = 1 + dw
    f[TH_PLL] = WB * (1 + dw - z)
    f[EPS_PLL] = Vqp
    Id_ref = load['kpv'] * (Vref_dc - vdc) + load['kiv'] * eta
    f[L + ':' + LOAD_STATES[2]] = Vref_dc - vdc
    Vd_unc = load['kpc'] * (-Id_ref + lIdc) + load['kic'] * lgd
    Vq_unc = load['kpc'] * (-Iq_ref + lIqc) + load['kic'] * lgq
    f[L + ':' + LOAD_STATES[4]] = -Id_ref + lIdc
    f[L + ':' + LOAD_STATES[5]] = -Iq_ref + lIqc
    Vd_c = Vd_unc + w_abs * load['lf'] * lIqc
    Vq_c = Vq_unc - w_abs * load['lf'] * lIdc
    lVr_c, lVi_c = inv_park(thp, Vd_c, Vq_c)
    P_cnv = lVr_c * lIrc + lVi_c * lIic
    f[V_DC] = (WB / load['c_dc']) * (P_cnv / vdc - vdc / load['r_load'])
    f[L + ':ir_cnv'] = lVrf - lVr_c - load['rf'] * lIrc + z * load['lf'] * lIic
    f[L + ':ii_cnv'] = lVif - lVi_c - load['rf'] * lIic - z * load['lf'] * lIrc
    f[L + ':vr_filter'] = lIrf - lIrc + z * load['cf'] * lVif
    f[L + ':vi_filter'] = lIif - lIic - z * load['cf'] * lVrf
    f[L + ':ir_filter'] = Vr2 - lVrf - load['rg'] * lIrf + z * load['lg'] * lIif
    f[L + ':ii_filter'] = Vi2 - lVif - load['rg'] * lIif - z * load['lg'] * lIrf
    kL = load['base_power'] / net['Sbase']

    # ---- Line (M = 1, source row scaling) ----
    IlR, IlI = X[LINE + ':Il_R'], X[LINE + ':Il_I']
    R, Xl = net['r'], net['x']
    f[LINE + ':Il_R'] = (WB / Xl) * ((Vr1 - Vr2) - R * IlR + z * Xl * IlI)
    f[LINE + ':Il_I'] = (WB / Xl) * ((Vi1 - Vi2) - R * IlI - z * Xl * IlR)

    # ---- Buses (M = b/omega_b); G_R only at bus 102 ----
    b1, b2 = net['b_from'], net['b_to']
    f['V_1:R'] = kG * Irf - IlR + z * b1 * Vi1
    f['V_1:I'] = kG * Iif - IlI - z * b1 * Vr1
    f['V_2:R'] = -kL * lIrf + IlR - GR * Vr2 + z * b2 * Vi2
    f['V_2:I'] = -kL * lIif + IlI - GR * Vi2 - z * b2 * Vr2

    fvec = sp.Matrix([f[nm] for nm in STATE_NAMES])
    aux = dict(h=h, p_e=p_e, q_e=q_e, Vq_pll=Vqp, dw=dw, P_cnv=P_cnv, Vd_c_L=Vd_c, Vq_c_L=Vq_c,
               Vd_cnv_G=Vd_cnv, Vq_cnv_G=Vq_cnv)
    return dict(x=x, z=z, GR=GR, rho=rho, fvec=fvec, h=h, aux=aux, M=mass_vector(load, gfm, net),
                load=load, gfm=gfm, net=net)


class E1Model:
    def __init__(self):
        s = build_ftilde()
        self.s = s
        self.load, self.gfm, self.net, self.M = s['load'], s['gfm'], s['net'], s['M']
        x, z, GR, rho, fvec, h = s['x'], s['z'], s['GR'], s['rho'], s['fvec'], s['h']
        X = sp.Matrix(x)
        self.Jx_tilde_sym = fvec.jacobian(X)
        self.Jz_tilde_sym = fvec.diff(z)
        self.f_new_sym = fvec.subs(z, h)                      # f(x) = f_tilde(x, h(x))
        self.J_new_sym = self.f_new_sym.jacobian(X)           # symbolic chain rule (pre-reg §2.6)
        self.f_fix_sym = fvec.subs(z, 1)                      # f_tilde(x, 1)
        self.J_fix_sym = self.f_fix_sym.jacobian(X)
        at = list(x) + [z] + list(rho) + [GR]
        an = list(x) + list(rho) + [GR]
        self._ft = sp.lambdify(at, fvec, modules='numpy', cse=True)
        self._Jxt = sp.lambdify(at, self.Jx_tilde_sym, modules='numpy', cse=True)
        self._Jzt = sp.lambdify(at, self.Jz_tilde_sym, modules='numpy', cse=True)
        self._fn = sp.lambdify(an, self.f_new_sym, modules='numpy', cse=True)
        self._Jn = sp.lambdify(an, self.J_new_sym, modules='numpy', cse=True)
        self._ff = sp.lambdify(an, self.f_fix_sym, modules='numpy', cse=True)
        self._Jf = sp.lambdify(an, self.J_fix_sym, modules='numpy', cse=True)
        self._aux = {k: sp.lambdify(an, v, modules='numpy') for k, v in s['aux'].items()}
        # ---- structural facts (pre-reg §2.5, §5.0) ----
        self.theta_row_zero = {
            'f_tilde': fvec[I_THETA] == 0 and all(e == 0 for e in self.Jx_tilde_sym.row(I_THETA))
                       and self.Jz_tilde_sym[I_THETA] == 0,
            'new': self.f_new_sym[I_THETA] == 0 and all(e == 0 for e in self.J_new_sym.row(I_THETA)),
            'fixed': self.f_fix_sym[I_THETA] == 0 and all(e == 0 for e in self.J_fix_sym.row(I_THETA)),
        }
        self.z_rows = [STATE_NAMES[k] for k in range(N) if self.Jz_tilde_sym[k] != 0]
        self.gr_rows = [STATE_NAMES[k] for k in range(N) if fvec[k].has(GR)]
        self.aux_free_of_z = all(not v.has(z) for v in s['aux'].values())

    # ---- evaluations (rho: 5-vector, GR: float) ----
    @staticmethod
    def _vec(fn, args, dtype):
        return np.array(fn(*args), dtype=dtype).reshape(-1)

    def f_tilde(self, x, z, rho, GR):
        return self._vec(self._ft, list(x) + [z] + list(rho) + [GR], np.result_type(np.asarray(x), float))

    def Jx_tilde(self, x, z, rho, GR):
        return np.array(self._Jxt(*(list(x) + [z] + list(rho) + [GR])), dtype=float)

    def Jz_tilde(self, x, z, rho, GR):
        return self._vec(self._Jzt, list(x) + [z] + list(rho) + [GR], float)

    def f(self, x, rho, GR):
        """New model f(x) = f_tilde(x, h(x)); accepts complex x (complex-step)."""
        return self._vec(self._fn, list(x) + list(rho) + [GR], np.result_type(np.asarray(x), float))

    def J(self, x, rho, GR):
        return np.array(self._Jn(*(list(x) + list(rho) + [GR])), dtype=float)

    def f_fixed(self, x, rho, GR):
        return self._vec(self._ff, list(x) + list(rho) + [GR], np.result_type(np.asarray(x), float))

    def J_fixed(self, x, rho, GR):
        return np.array(self._Jf(*(list(x) + list(rho) + [GR])), dtype=float)

    def aux(self, name, x, rho, GR=0.0):
        return float(np.real(self._aux[name](*(list(x) + list(rho) + [GR]))))

    def h(self, x, rho):
        return self.aux('h', x, rho)

    def J_complex_step(self, x, rho, GR, hstep, model='new'):
        fn = self.f if model == 'new' else self.f_fixed
        Jc = np.zeros((N, N))
        for k in range(N):
            xc = np.array(x, dtype=complex)
            xc[k] += 1j * hstep
            Jc[:, k] = np.imag(fn(xc, rho, GR)) / hstep
        return Jc
