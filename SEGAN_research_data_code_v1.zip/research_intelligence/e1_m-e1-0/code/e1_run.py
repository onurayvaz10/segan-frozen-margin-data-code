"""E1 M-E1-0 runner. Fixed pre-registration sha256 11c08c3e... (section numbers below refer to it).

Modes
  check : syntax + import check, structural model facts, decision-logic self-test on synthetic inputs only
          (no operating point, no candidate, no post-shed quantity is computed).
  v0    : §8 V0 fixed-frequency regression against R-HA-B A3 (f_tilde(x, 1), G_R = 0, R-HA-type re-dispatch,
          P = 1.45 / 1.46) with the R-HA-B v1.0 criteria.
  e1    : §9 full execution V0 -> candidates (§3.2) -> fixed T -> S (§3.3) -> §6/§7 classification.
          Refuses to start without --audit-note (the code-audit note; its sha256 is recorded).
Every run writes a NEW folder out/<RUN_ID> (refuses if it exists): code snapshot, execution record, stdout copy,
raw records and SHA256SUMS.txt. Nothing existing is overwritten; out/RUNS_INDEX.csv is append-only.

Usage: python -I e1_run.py check|v0|e1 [--run-id ID] [--audit-note PATH]
"""
import os
for _v in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[_v] = '1'

import sys


def apply_low_load():
    """Low-load protocol (BelowNormal priority, affinity 0xF0000) applied to this process before NumPy loads."""
    info = dict(platform=sys.platform, requested=dict(priority='BELOW_NORMAL', affinity='0xf0000'))
    if sys.platform != 'win32':
        return info
    import ctypes
    from ctypes import wintypes
    k32 = ctypes.WinDLL('kernel32', use_last_error=True)
    k32.GetCurrentProcess.restype = wintypes.HANDLE
    k32.SetPriorityClass.argtypes = [wintypes.HANDLE, wintypes.DWORD]
    k32.GetPriorityClass.argtypes = [wintypes.HANDLE]
    k32.SetProcessAffinityMask.argtypes = [wintypes.HANDLE, ctypes.c_size_t]
    k32.GetProcessAffinityMask.argtypes = [wintypes.HANDLE, ctypes.POINTER(ctypes.c_size_t),
                                           ctypes.POINTER(ctypes.c_size_t)]
    h = k32.GetCurrentProcess()
    info['set_priority_ok'] = bool(k32.SetPriorityClass(h, 0x00004000))
    info['set_affinity_ok'] = bool(k32.SetProcessAffinityMask(h, 0xF0000))
    pm, sm = ctypes.c_size_t(), ctypes.c_size_t()
    k32.GetProcessAffinityMask(h, ctypes.byref(pm), ctypes.byref(sm))
    info.update(priority_class=hex(k32.GetPriorityClass(h)), affinity_mask=hex(pm.value), system_mask=hex(sm.value))
    return info


LOW_LOAD = apply_low_load()

import argparse  # noqa: E402
import csv  # noqa: E402
import datetime  # noqa: E402
import hashlib  # noqa: E402
import io  # noqa: E402
import json  # noqa: E402
import math  # noqa: E402
import platform  # noqa: E402
import shutil  # noqa: E402
import time  # noqa: E402
import traceback  # noqa: E402
from contextlib import redirect_stdout  # noqa: E402
from pathlib import Path  # noqa: E402

CODE = Path(__file__).resolve().parent
sys.path.insert(0, str(CODE))

import numpy as np  # noqa: E402
import scipy  # noqa: E402
import sympy  # noqa: E402
from scipy.optimize import linear_sum_assignment  # noqa: E402

import e1_model as EM  # noqa: E402  (inserts the validated r_ha_b/code path)
import e1_core as EC  # noqa: E402
from e1_model import I_THETA, N, REF_NAMES, STATE_NAMES, RB  # noqa: E402

E1ROOT = CODE.parent
RI = E1ROOT.parent
OUT = E1ROOT / 'out'
SABIT = E1ROOT / 'sabit' / 'PF1_E1_On_Kayit_M-E1-0_v1.0_SABIT.md'
RHAB_OUT = RI / 'r_ha_b' / 'out'
RHAB_MODEL = RI / 'r_ha_b' / 'code' / 'rhab_model.py'
CODE_FILES = ('e1_model.py', 'e1_core.py', 'e1_run.py')

# Fixed inputs; a mismatch stops the run before any computation.
EXPECTED = {
    'sabit_on_kayit': (SABIT, '11c08c3ebf9a40aa27d5165a1912eea30777ee639e50a02ed667a4015606a84b'),
    'rhab_model.py': (RHAB_MODEL, 'db9dd3fdf510a21606a25060e423421dec977ce29dfd4fcadffb38eb9e1c9825'),
    'A_summary.json': (RHAB_OUT / 'A_summary.json', 'ab7abb51ecae681734bc4a13562d52e77e4e1025ab41b18d07dbfa8dae821214'),
}
A3_FILES = [f'A_{lab}_{k}.csv' for lab in ('Ps', 'Pu') for k in ('eigs', 'participation', 'state', 'jacobian')]
E1_MODEL_INTERIM = '0ba6571559b557090e693aa007a57d69cbaf409122ea7602fbe7e1edefe9a15b'

# §8 V0: R-HA-B v1.0 criteria (pre-registration §8 / §5.1 note)
V0_TH = dict(eig_abs=1e-3, eig_rel=1e-5, crit_re=1e-3, group=0.005, part_l1=0.02, res=1e-8)
V0_POINTS = (('Ps', 1.45), ('Pu', 1.46))


# ------------------------------------------------------------------------------------------------------------
# utilities
# ------------------------------------------------------------------------------------------------------------
def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def num(v):
    if v is None:
        return ''
    return repr(float(v))


def jsonable(v):
    if v is None or isinstance(v, (str, bool)):
        return v
    if isinstance(v, np.bool_):
        return bool(v)
    if isinstance(v, (np.integer, int)):
        return int(v)
    if isinstance(v, (np.floating, float)):
        return float(v)
    if isinstance(v, (complex, np.complexfloating)):
        return [float(v.real), float(v.imag)]
    if isinstance(v, np.ndarray):
        return [jsonable(t) for t in v.tolist()]
    if isinstance(v, dict):
        return {str(k): jsonable(t) for k, t in v.items()}
    if isinstance(v, (list, tuple, set)):
        return [jsonable(t) for t in v]
    return repr(v)


def dump(path, obj):
    path = Path(path)
    if path.exists():
        raise FileExistsError(path)
    path.write_text(json.dumps(jsonable(obj), indent=1, ensure_ascii=False), encoding='utf-8')


class Tee:
    def __init__(self, *streams):
        self.streams = streams

    def write(self, s):
        for st in self.streams:
            st.write(s)
        return len(s)

    def flush(self):
        for st in self.streams:
            st.flush()


def environment_record():
    buf = io.StringIO()
    with redirect_stdout(buf):
        np.show_config()
    return dict(python=sys.version, executable=sys.executable, isolated=bool(sys.flags.isolated),
                platform=platform.platform(), numpy=np.__version__, scipy=scipy.__version__, sympy=sympy.__version__,
                numpy_config=buf.getvalue(), low_load=LOW_LOAD, pid=os.getpid(),
                threads={v: os.environ.get(v) for v in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS')})


def preflight():
    rec, ok = {}, True
    for k, (p, h) in EXPECTED.items():
        got = sha(p) if Path(p).exists() else None
        rec[k] = dict(path=str(p), expected=h, got=got, match=got == h)
        ok &= got == h
    sums = {}
    sp = RHAB_OUT / 'SHA256SUMS.txt'
    for line in sp.read_text(encoding='utf-8-sig').splitlines():     # R-HA-B manifest was written with a BOM
        if line.strip():
            hh, name = line.split(maxsplit=1)
            sums[name.strip().lstrip('*')] = hh.lower()
    for f in A3_FILES:
        got = sha(RHAB_OUT / f)
        rec[f] = dict(expected_from_rhab_SHA256SUMS=sums.get(f), got=got, match=sums.get(f) == got)
        ok &= sums.get(f) == got
    rec['rhab_SHA256SUMS.txt'] = dict(got=sha(sp))
    code = {f: sha(CODE / f) for f in CODE_FILES}
    rec['code_sha256'] = code
    rec['e1_model_matches_interim_audit'] = code['e1_model.py'] == E1_MODEL_INTERIM
    return ok, rec


class Run:
    def __init__(self, mode, run_id):
        OUT.mkdir(exist_ok=True)
        self.dir = OUT / run_id
        self.dir.mkdir(exist_ok=False)              # refuses an existing RUN_ID: nothing is overwritten
        self.mode, self.id = mode, run_id
        self.t0 = time.time()
        self.log = open(self.dir / 'stdout.txt', 'w', encoding='utf-8')
        sys.stdout.reconfigure(encoding='utf-8')
        self._stdout = sys.stdout
        sys.stdout = Tee(self._stdout, self.log)
        snap = self.dir / 'code_snapshot'
        snap.mkdir()
        for f in CODE_FILES:
            shutil.copy2(CODE / f, snap / f)
        self.record = dict(run_id=run_id, mode=mode, argv=sys.argv,
                           started=datetime.datetime.now().astimezone().isoformat(timespec='seconds'),
                           pre_registration=str(SABIT), env=environment_record(), stages={})

    def save(self):
        p = self.dir / 'yurutme_kaydi.json'
        tmp = self.dir / 'yurutme_kaydi.json.part'
        tmp.write_text(json.dumps(jsonable(self.record), indent=1, ensure_ascii=False), encoding='utf-8')
        os.replace(tmp, p)                          # the execution record itself is updated stage by stage

    def finish(self, status):
        self.record.update(status=status, finished=datetime.datetime.now().astimezone().isoformat(timespec='seconds'),
                           wall_s=time.time() - self.t0)
        self.save()
        print(f'[{self.id}] status: {status}')
        sys.stdout = self._stdout
        self.log.close()
        files = sorted(p for p in self.dir.rglob('*') if p.is_file() and p.name != 'SHA256SUMS.txt')
        with open(self.dir / 'SHA256SUMS.txt', 'w', encoding='utf-8', newline='\n') as fh:
            for p in files:
                fh.write(f'{sha(p)}  {p.relative_to(self.dir).as_posix()}\n')
        idx = OUT / 'RUNS_INDEX.csv'
        new = not idx.exists()
        with open(idx, 'a', newline='', encoding='utf-8') as fh:
            w = csv.writer(fh)
            if new:
                w.writerow(['run_id', 'mode', 'started', 'finished', 'status', 'manifest_sha256'])
            w.writerow([self.id, self.mode, self.record['started'], self.record['finished'], status,
                        sha(self.dir / 'SHA256SUMS.txt')])


# ------------------------------------------------------------------------------------------------------------
# writers (B3 format, extended)
# ------------------------------------------------------------------------------------------------------------
def write_state(d, tag, x, x_start, start_label, F, M):
    with open(d / f'{tag}_state.csv', 'w', newline='', encoding='utf-8') as fh:
        w = csv.writer(fh)
        w.writerow(['state', 'x_equilibrium', start_label, 'F_residual', 'M', 'ode_rhs_F_over_M'])
        for k, nm in enumerate(STATE_NAMES):
            w.writerow([nm, num(x[k]), num(x_start[k]), num(F[k]), num(M[k]), num(F[k] / M[k])])


def write_spectral(d, tag, spec):
    lam, PFn = spec['lam'], spec['PFn']
    ref_idx = spec['ref']['idx']
    icrit = spec['alpha']['icrit']
    with open(d / f'{tag}_jacobian.csv', 'w', newline='', encoding='utf-8') as fh:
        w = csv.writer(fh)
        w.writerow(['row\\col'] + STATE_NAMES)
        for k, nm in enumerate(STATE_NAMES):
            w.writerow([nm] + [num(v) for v in spec['J'][k]])
    order = sorted(range(N), key=lambda i: (-lam[i].real, -lam[i].imag))
    with open(d / f'{tag}_eigs.csv', 'w', newline='', encoding='utf-8') as fh:
        w = csv.writer(fh)
        w.writerow(['idx', 're', 'im', 'abs', 'f_Hz', 'zeta', 'backward_residual', 'kappa', 'is_ref_mode',
                    'is_critical', 'top1', 'p1', 'top2', 'p2'])
        for i in order:
            o = np.argsort(-PFn[:, i])
            a = abs(lam[i])
            w.writerow([i, num(lam[i].real), num(lam[i].imag), num(a), num(abs(lam[i].imag) / (2 * math.pi)),
                        num(-lam[i].real / a) if a > 0 else '', num(spec['backward'][i]), num(spec['kappa'][i]),
                        i == ref_idx, i == icrit, STATE_NAMES[o[0]], num(PFn[o[0], i]), STATE_NAMES[o[1]],
                        num(PFn[o[1], i])])
    with open(d / f'{tag}_participation.csv', 'w', newline='', encoding='utf-8') as fh:
        w = csv.writer(fh)
        w.writerow(['state'] + [f'mode{i}({lam[i].real:.6g}{lam[i].imag:+.6g}j)' for i in order])
        for k, nm in enumerate(STATE_NAMES):
            w.writerow([nm] + [num(PFn[k, i]) for i in order])


def write_newton_pair(d, tag, pair):
    with open(d / f'{tag}_newton_pair.csv', 'w', newline='', encoding='utf-8') as fh:
        w = csv.writer(fh)
        w.writerow(['state', 'x_prev', 'x_last'])
        for k, nm in enumerate(STATE_NAMES):
            w.writerow([nm, num(pair['x_prev'][k]) if pair.get('x_prev') is not None else '',
                        num(pair['x_last'][k]) if pair.get('x_last') is not None else ''])


def write_v5(d, tag, v5):
    if not v5.get('available', True):
        (d / f'{tag}_V5_unavailable.txt').write_text('available=False\n' + v5['traceback'], encoding='utf-8')
        return
    with open(d / f'{tag}_V5_admittance.csv', 'w', newline='', encoding='utf-8') as fh:
        w = csv.writer(fh)
        w.writerow(['f_Hz', 'omega', 'lam_min_H', 'lam_max_H', 'Y11_re', 'Y11_im', 'Y12_re', 'Y12_im', 'Y21_re',
                    'Y21_im', 'Y22_re', 'Y22_im'])
        for r in v5['rows']:
            Y = r['Y']
            w.writerow([num(r['f_Hz']), num(r['omega']), num(r['lam_min_H']), num(r['lam_max_H'])]
                       + [num(c) for a in range(2) for b in range(2) for c in (Y[a][b].real, Y[a][b].imag)])


def crit_participation(spec):
    ic = spec['alpha']['icrit'] if spec['alpha']['defined'] else None
    if ic is None:
        return None
    p = {STATE_NAMES[k]: float(spec['PFn'][k, ic]) for k in range(N)}
    shares = {g: sum(v for s, v in p.items() if EC.group_of(s) == g) for g in EC.GROUPS}
    return dict(vector=p, group_shares=shares, top2=sorted(p, key=lambda s: -p[s])[:2])


def spectral_summary(spec):
    al = spec['alpha']
    out = dict(alpha=al['alpha'], alpha_defined=al['defined'], raw_max_re_flagged=al['raw_max_re'],
               ref=spec['ref'], normA2=spec['normA'], backward_max=float(np.max(spec['backward'])),
               finite=spec['finite'], crit_choice_note=al.get('crit_choice_note'))
    if al['defined']:
        lc = spec['lam'][al['icrit']]
        out['critical'] = dict(idx=al['icrit'], lam=lc, f_Hz=abs(lc.imag) / (2 * math.pi),
                               zeta=-lc.real / abs(lc) if abs(lc) > 0 else None, kappa=spec['kappa'][al['icrit']],
                               backward=spec['backward'][al['icrit']])
    if 'V2' in spec:
        out['V2'] = spec['V2']
    if 'e_num' in spec:
        out['e_num'] = spec['e_num']
    return out


# ------------------------------------------------------------------------------------------------------------
# check mode
# ------------------------------------------------------------------------------------------------------------
def logic_selftest():
    OK, VIOL, BORDER = EC.OK, EC.VIOL, EC.BORDER
    t = {}
    expect_F = {'1': 'F-degerlendirilemez', '2': 'F-ret', '3': 'F-ret', '4': 'F-ret', '5': 'F-ret', '9a': 'F-ret',
                '6': 'F-onay', '7': 'F-belirsiz', '8': 'F-belirsiz', '9b': 'F-belirsiz'}
    seen, bad = set(), []
    for D in (True, False):
        for Lim in (OK, VIOL, BORDER):
            for Nok in (True, False):
                for M in (('Mrj-saglaniyor', 'Mrj-ihlal', 'Mrj-belirsiz') if Nok else (None,)):
                    c = EC.category_71('F-onay', dict(D=D, Lim=Lim, N=Nok, Mrj=M))
                    f = EC.F_decision(D, Lim, Nok, M)
                    seen.add(c['row'])
                    if expect_F[c['row']] != f:
                        bad.append(dict(D=D, Lim=Lim, N=Nok, Mrj=M, row=c['row'], F=f))
    t['s71_step2_rows_vs_F_consistency'] = dict(passed=not bad and seen == set(expect_F), rows_seen=sorted(seen),
                                               mismatches=bad)
    s1 = {k: EC.category_71(k, dict(D=True, Lim=OK, N=True, Mrj='Mrj-saglaniyor'))
          for k in ('F-ret', 'F-belirsiz', 'F-degerlendirilemez')}
    t['s71_step1'] = dict(passed=s1['F-ret']['category'].startswith('Uygulanamaz') and
                          all(s1[k]['category'].startswith('Degerlendirilemez') for k in ('F-belirsiz',
                                                                                          'F-degerlendirilemez')),
                          out=s1)
    lim_cases = [
        (EC.cmp_upper(1 - 2e-6, 1.0), OK), (EC.cmp_upper(1 + 2e-6, 1.0), VIOL), (EC.cmp_upper(1.0, 1.0), BORDER),
        (EC.cmp_upper(1 + 5e-7, 1.0), BORDER), (EC.cmp_upper(-2e-6, 0.0), OK), (EC.cmp_upper(2e-6, 0.0), VIOL),
        (EC.cmp_lower(0.88 + 2e-6, 0.88), OK), (EC.cmp_lower(0.88 - 2e-6, 0.88), VIOL),
        (EC.cmp_lower(0.88, 0.88), BORDER),
        (EC.l6_status(0.0), OK), (EC.l6_status(1e-6), OK), (EC.l6_status(1.05e-6), BORDER),
        (EC.l6_status(1.2e-6), VIOL),
        (EC.combine(OK, BORDER, OK), BORDER), (EC.combine(BORDER, VIOL), VIOL), (EC.combine(OK, OK), OK)]
    t['s4_limit_rules'] = dict(passed=all(a == b for a, b in lim_cases), cases=lim_cases)
    mr = [(EC.mrj(-5.02), 'Mrj-saglaniyor'), (EC.mrj(-4.98), 'Mrj-ihlal'), (EC.mrj(-5.0), 'Mrj-belirsiz'),
          (EC.mrj(-5.005), 'Mrj-belirsiz'), (EC.mrj(-4.995), 'Mrj-belirsiz')]
    t['s61_mrj'] = dict(passed=all(a == b for a, b in mr), cases=mr)
    st = [(EC.sign_subtype(0.02), 'kararsiz'), (EC.sign_subtype(0.0), 'sifira_yakin'),
          (EC.sign_subtype(-1.0), 'marj_kaybi_kararli')]
    t['s61_sign_subtype'] = dict(passed=all(a == b for a, b in st), cases=st)

    def eff(aT, aS, ok=True):
        return EC.effect_72(dict(D=True, N=ok, alpha=aT if ok else None, alpha_raw=aT),
                            dict(D=True, N=True, alpha=aS, alpha_raw=aS))['decision']
    ef = [(eff(-5.02, -4.98), 'anlamsiz'), (eff(-10.0, -4.98), 'anlamli_kotulesme'),
          (eff(-4.98, -10.0), 'anlamli_iyilesme'), (eff(-10.0, -5.0), 'belirsiz'),
          (eff(-10.0, -5.0, ok=False), 'degerlendirilemez')]
    t['s72_effect'] = dict(passed=all(a == b for a, b in ef), cases=ef)
    # §5.0 alpha / reference identity on synthetic spectra (no model point)
    lam = np.array([0.0 + 0j, -1 + 2j, -1 - 2j, -0.5 + 0j])
    PF = np.zeros((N, 4))
    PF[I_THETA, 0] = 1.0
    r_ok = EC.identify_ref(lam, PF, True)
    a_ok = EC.alpha_from(lam, r_ok)
    lam2 = np.array([0.0 + 0j, 5e-9 + 0j, -1 + 2j, -1 - 2j])
    PF2 = np.zeros((N, 4))
    PF2[I_THETA, 0] = 1.0
    r_two = EC.identify_ref(lam2, PF2, True)
    a_two = EC.alpha_from(lam2, r_two)
    PF3 = np.zeros((N, 4))
    PF3[I_THETA, 0] = 0.5
    r_low = EC.identify_ref(lam, PF3, True)
    lam4 = np.array([0.0 + 0j, 0.3 - 2j, 0.3 + 2j, -0.5 + 0j])
    a_pair = EC.alpha_from(lam4, EC.identify_ref(lam4, PF, True))
    t['s50_alpha_ref'] = dict(
        passed=(r_ok['ok'] and a_ok['alpha'] == -0.5 and a_ok['icrit'] == 3 and not r_two['ok']
                and not a_two['defined'] and not r_low['ok'] and not EC.identify_ref(lam, PF, False)['ok']
                and a_pair['icrit'] == 2),
        cases=dict(ref_ok=r_ok, alpha_ok=a_ok, two_zero_modes_ref=r_two, two_zero_modes_alpha=a_two,
                   low_theta_participation=r_low, conjugate_pick=a_pair))
    t['all_passed'] = all(v['passed'] for v in t.values())
    return t


def mode_check(run):
    rec = run.record['stages']
    syn = {}
    for f in CODE_FILES:
        try:
            compile((CODE / f).read_text(encoding='utf-8'), str(CODE / f), 'exec')
            syn[f] = 'ok'
        except SyntaxError as exc:
            syn[f] = f'SyntaxError: {exc}'
    rec['syntax'] = syn
    rec['imports'] = dict(e1_model=EM.__file__, e1_core=EC.__file__, rhab_model=RB.__file__)
    t0 = time.time()
    model = EM.E1Model()
    rec['model_build_s'] = time.time() - t0
    st = dict(theta_row_zero=model.theta_row_zero,
              z_rows_match=sorted(model.z_rows) == sorted(EM.Z_ROWS_EXPECTED), n_z_rows=len(model.z_rows),
              z_rows=model.z_rows, gr_rows=model.gr_rows, gr_rows_match=model.gr_rows == EM.GR_ROWS_EXPECTED,
              aux_free_of_z=model.aux_free_of_z, M_positive=bool(np.all(model.M > 0)))
    st['passed'] = (all(model.theta_row_zero.values()) and st['z_rows_match'] and st['gr_rows_match']
                    and st['aux_free_of_z'] and st['M_positive'])
    rec['structure'] = st
    rec['constants'] = dict(TH=EC.TH, CANDIDATES=EC.CANDIDATES, CS_STEPS=EC.CS_STEPS, P_AKT_BRACKET=EC.P_AKT_BRACKET,
                            ONED_BISECT_WIDTH=EC.ONED_BISECT_WIDTH, ONED_MAXIT=EC.ONED_MAXIT, V4_PHIS=EC.V4_PHIS,
                            V4_SEED=EC.V4_SEED, V4_DELTA=EC.V4_DELTA, V5_n=len(EC.V5_F_HZ),
                            V5_range=(EC.V5_F_HZ[0], EC.V5_F_HZ[-1]), V_STAR=EM.V_STAR, VB_DC=EM.VB_DC,
                            parameters=dict(load=model.load, gfm=model.gfm, net=model.net), V0_TH=V0_TH)
    rec['logic_selftest'] = logic_selftest()
    ok = all(v == 'ok' for v in syn.values()) and st['passed'] and rec['logic_selftest']['all_passed']
    print(json.dumps(jsonable(dict(syntax=syn, structure_passed=st['passed'], z_rows=len(model.z_rows),
                                   logic=dict((k, v['passed']) for k, v in rec['logic_selftest'].items()
                                              if isinstance(v, dict)), model_build_s=rec['model_build_s'])),
                     indent=1, ensure_ascii=False))
    return 'CHECK GECTI' if ok else 'CHECK BASARISIZ'


# ------------------------------------------------------------------------------------------------------------
# V0 (§8)
# ------------------------------------------------------------------------------------------------------------
def load_a3(label):
    rows = list(csv.DictReader(open(RHAB_OUT / f'A_{label}_eigs.csv', encoding='utf-8')))
    lam = np.array([complex(float(r['re']), float(r['im'])) for r in rows])
    ref = np.array([r['is_ref_mode'] in ('True', 'true') for r in rows])
    idx = [int(r['idx']) for r in rows]
    prow = list(csv.DictReader(open(RHAB_OUT / f'A_{label}_participation.csv', encoding='utf-8')))
    p = {r['state']: float(r['p_B_posIm']) for r in prow}
    grp = {r['state']: r['group_RHA'] for r in prow}
    srow = list(csv.DictReader(open(RHAB_OUT / f'A_{label}_state.csv', encoding='utf-8')))
    xs = {r['state']: float(r['x_equilibrium']) for r in srow}
    xi = {r['state']: float(r['x_init_before_refine']) for r in srow}
    jrow = list(csv.reader(open(RHAB_OUT / f'A_{label}_jacobian.csv', encoding='utf-8')))
    jcols = jrow[0][1:]
    J = {(r[0], c): float(v) for r in jrow[1:] for c, v in zip(jcols, r[1:])}
    summ = json.loads((RHAB_OUT / 'A_summary.json').read_text(encoding='utf-8'))['points'][label]
    return dict(lam=lam, ref=ref, idx=idx, p=p, grp=grp, x=xs, x_init=xi, J=J, summary=summ)


def v0_point(model, disp, label, P, d):
    dp = disp.dispatch_RHA(P)
    x, rho = dp['x'], dp['rho']
    chk, F = EC.checks_51a(model, x, rho, 0.0, 'T', disp=dp, kind='fixed')
    spec = EC.spectral(model, x, rho, 0.0, kind='fixed', enum=False)
    A3 = load_a3(label)
    lamA, refA = A3['lam'], A3['ref']
    iA = [i for i in range(len(lamA)) if not refA[i]]
    lam = spec['lam']
    ref_ok = spec['ref']['ok']
    iB = [i for i in range(N) if i != spec['ref']['idx']] if ref_ok else list(range(N))
    tolA = np.array([V0_TH['eig_abs'] + V0_TH['eig_rel'] * abs(lamA[a]) for a in iA])
    C = np.array([[abs(lam[b] - lamA[a]) / tolA[j] for j, a in enumerate(iA)] for b in iB])
    rb, ca = linear_sum_assignment(C)
    rows = []
    for r, c in zip(rb, ca):
        b, a = iB[r], iA[c]
        dist = abs(lam[b] - lamA[a])
        rows.append(dict(b=b, a=a, lamB=lam[b], lamA=lamA[a], dist=dist, tol=tolA[c], ok=dist <= tolA[c]))
    match_ok = ref_ok and int(np.sum(refA)) == 1 and len(rows) == 32 and all(r['ok'] for r in rows)
    amaxA = max(lamA[a].real for a in iA)
    aA = max([a for a in iA if lamA[a].real == amaxA], key=lambda a: lamA[a].imag)
    al = spec['alpha']
    icrit = al['icrit']
    pB = crit_participation(spec)
    if al['defined']:
        crit_re = abs(lam[icrit].real - lamA[aA].real)
        groups = sorted(set(A3['grp'].values()))
        shB = {g: sum(pB['vector'][s] for s in STATE_NAMES if A3['grp'][s] == g) for g in groups}
        shA = {g: sum(A3['p'][s] for s in STATE_NAMES if A3['grp'][s] == g) for g in groups}
        gdiff = max(abs(shB[g] - shA[g]) for g in groups)
        l1 = sum(abs(pB['vector'][s] - A3['p'][s]) for s in STATE_NAMES)
        partner = [r['b'] for r in rows if r['a'] == aA]
        crit_identity = bool(partner) and partner[0] == icrit
    else:
        crit_re = gdiff = l1 = None
        shB = shA = None
        crit_identity = False
    res = float(np.max(np.abs(F)))
    crit = {
        'eig_32_matched': dict(passed=bool(match_ok), value=f'{sum(r["ok"] for r in rows)}/32',
                               ref_identified=ref_ok, a3_ref_count=int(np.sum(refA)),
                               max_dist=max(r['dist'] for r in rows)),
        'critical_re_diff': dict(passed=crit_re is not None and crit_re <= V0_TH['crit_re'], value=crit_re),
        'group_share_diff': dict(passed=gdiff is not None and gdiff <= V0_TH['group'], value=gdiff),
        'participation_L1': dict(passed=l1 is not None and l1 <= V0_TH['part_l1'], value=l1),
        'residual': dict(passed=res <= V0_TH['res'], value=res),
    }
    passed = all(v['passed'] for v in crit.values())
    # observations (not criteria): bitwise identity, complex-step Jacobian, 5.1a diagnostics, group mapping
    xa = np.array([A3['x'][s] for s in STATE_NAMES])
    xia = np.array([A3['x_init'][s] for s in STATE_NAMES])
    Ja = np.array([[A3['J'][(r, c)] for c in STATE_NAMES] for r in STATE_NAMES])
    refsA = list(A3['summary']['refs'].values())
    pf_rb = RB.power_flow(P, model.net)
    obs = dict(
        x_bitwise_equal=int(np.sum(x == xa)), x_max_abs_diff=float(np.max(np.abs(x - xa))),
        x_init_bitwise_equal=int(np.sum(dp['x_init'] == xia)), x_init_max_abs_diff=float(np.max(np.abs(dp['x_init'] - xia))),
        J_bitwise_equal=int(np.sum(spec['J'] == Ja)), J_max_abs_diff=float(np.max(np.abs(spec['J'] - Ja))),
        refs_bitwise_equal=[bool(a == b) for a, b in zip(rho.tolist(), refsA)],
        eig_bitwise_equal_matched=int(sum(r['dist'] == 0.0 for r in rows)),
        critical_identity_matched=crit_identity, alpha_E1_def=al['alpha'], alpha_A3=A3['summary']['alpha'],
        crit_A3_from_eigs=lamA[aA], crit_A3_summary=A3['summary']['crit'],
        power_flow_V2_equal_rhab=bool(pf_rb['V2'] == dp['pf']['V2']),
        group_mapping_equal_RHA=all(EC.group_of(s) == A3['grp'][s] for s in STATE_NAMES),
        h_minus_1=model.h(x, rho) - 1.0, checks_51a_fixed=chk, refine_hist=dp['refine_hist'],
        group_shares_E1=shB, group_shares_A3=shA)
    E = {}
    for hstep in EC.CS_STEPS:
        e, rn, cn = EC.ej(spec['J'], model.J_complex_step(x, rho, 0.0, hstep, model='fixed'))
        E[repr(hstep)] = dict(E_J=e, worst_eq=rn, worst_state=cn)
    obs['jac_complex_step_fixed'] = E
    tag = f'V0_{label}'
    write_state(d, tag, x, dp['x_init'], 'x_init_before_refine', F, model.M)
    write_spectral(d, tag, spec)
    with open(d / f'{tag}_eig_match.csv', 'w', newline='', encoding='utf-8') as fh:
        w = csv.writer(fh)
        w.writerow(['idx_E1', 'idx_A3', 're_E1', 'im_E1', 're_A3', 'im_A3', 'dist', 'tol', 'ok'])
        for r in sorted(rows, key=lambda r: -r['lamA'].real):
            w.writerow([r['b'], A3['idx'][r['a']], num(r['lamB'].real), num(r['lamB'].imag), num(r['lamA'].real),
                        num(r['lamA'].imag), num(r['dist']), num(r['tol']), r['ok']])
    summary = dict(label=label, P=P, rho=dict(zip(REF_NAMES, rho.tolist())),
                   pf=dict(V2=dp['pf']['V2'], mismatch_hist=dp['pf']['mismatch_hist']),
                   spectral=spectral_summary(spec), critical_participation=pB, criteria=crit, passed=passed,
                   observations=obs)
    dump(d / f'{tag}_point.json', summary)
    print(f'V0 {label} P={P}: passed={passed} | ' + ', '.join(f'{k}={v["passed"]}' for k, v in crit.items())
          + f' | alpha={al["alpha"]!r}, x bitwise {obs["x_bitwise_equal"]}/33, J bitwise {obs["J_bitwise_equal"]}/1089')
    return passed, summary


def run_v0(run, model, disp, sub='V0'):
    d = run.dir / sub
    d.mkdir()
    res = {}
    for label, P in V0_POINTS:
        ok, s = v0_point(model, disp, label, P, d)
        res[label] = dict(passed=ok, criteria=s['criteria'], alpha=s['spectral']['alpha'])
    passed = all(v['passed'] for v in res.values())
    run.record['stages']['V0'] = dict(passed=passed, points=res, folder=sub)
    run.save()
    return passed


def mode_v0(run):
    t0 = time.time()
    model = EM.E1Model()
    run.record['stages']['model_build_s'] = time.time() - t0
    disp = EC.Dispatcher(model)
    ok = run_v0(run, model, disp)
    return 'V0 GECTI' if ok else 'V0 GECMEDI'


# ------------------------------------------------------------------------------------------------------------
# E1 (§9) -- NOT to be run before the code audit (enforced by --audit-note)
# ------------------------------------------------------------------------------------------------------------
def n_gate(spec, extra):
    parts = dict(V2=bool(spec['V2']['passed']),
                 backward_all=bool(np.all(spec['backward'] <= EC.TH['backward'])),
                 finite=bool(spec['finite']), ref_identity=bool(spec['ref']['ok']),
                 e_num=bool(spec['e_num']['passed']))
    parts.update(extra)
    return all(parts.values()), parts


def strip_status(lim):
    return {k: {kk: vv for kk, vv in v.items() if not kk.startswith('status')} for k, v in lim['limits'].items()}


def f_reason(D, Lim, Nok, M, F):
    return f'D={"gecerli" if D else "gecersiz"}; Lim={Lim}; N={"gecerli" if Nok else "gecersiz"}; Mrj={M} -> {F}'


def evaluate_point(model, x, rho, GR, point, pair, D, d, tag, x_start, start_label):
    """Fixed T or final S with D valid: Lim, full spectral (§5.1b), V2-V5, N, Mrj, F."""
    F = model.f(x, rho, GR)
    write_state(d, tag, x, x_start, start_label, F, model.M)
    lim = EC.limits(model, x, rho, GR)
    spec = EC.spectral(model, x, rho, GR, kind='new', pair=pair)
    extra = {}
    v3 = None
    if point == 'T':
        v3 = EC.V3(model, x, rho, GR)
        extra['V3'] = bool(v3['passed'])
    v4 = EC.V4(model, x, rho, GR, spec)
    extra['V4'] = bool(v4['passed'])
    try:                                   # V5 is descriptive: a failure is recorded, never gating
        v5 = EC.V5(model, x, rho, GR)
        v5['available'] = True
    except Exception:
        v5 = dict(available=False, traceback=traceback.format_exc())
        print(f'V5 {tag}: available=False\n{v5["traceback"]}')
    Nok, nparts = n_gate(spec, extra)
    alpha = spec['alpha']['alpha'] if Nok else None
    M = EC.mrj(alpha) if Nok else None
    Fdec = EC.F_decision(D, lim['Lim'], Nok, M)
    sub = EC.sign_subtype(alpha) if (Nok and M == 'Mrj-ihlal') else None
    write_spectral(d, tag, spec)
    write_newton_pair(d, tag, pair)
    write_v5(d, tag, v5)
    return dict(lim=lim, spec=spec, V3=v3, V4=v4, V5=v5, N=Nok, N_parts=nparts, alpha=alpha, Mrj=M, F=Fdec,
                sign_subtype=sub, crit_part=crit_participation(spec) if spec['alpha']['defined'] else None)


def point_record(tag, GR, rho, D, D_reason, chk, ev, v1=None, x=None):
    r = dict(tag=tag, G_R=GR, rho=dict(zip(REF_NAMES, rho.tolist())), D=D, D_reason=D_reason, checks_51a=chk)
    if v1 is not None:
        r['V1'] = v1
    if ev is None:
        r.update(N=None, Mrj=None, F='F-degerlendirilemez', F_reason=f_reason(False, None, False, None,
                                                                                'F-degerlendirilemez'))
        return r
    r.update(limits=ev['lim']['limits'], Lim=ev['lim']['Lim'], report=ev['lim']['report'], N=ev['N'],
             N_parts=ev['N_parts'], spectral=spectral_summary(ev['spec']), alpha=ev['alpha'], Mrj=ev['Mrj'],
             sign_subtype=ev['sign_subtype'], F=ev['F'], F_reason=f_reason(D, ev['lim']['Lim'], ev['N'], ev['Mrj'],
                                                                         ev['F']),
             V3=ev['V3'], V4=ev['V4'], V5=(dict(available=True, z_star=ev['V5']['z_star'], min_lam_min_H=ev['V5']['min_lam_min_H'],
                                                 f_at_min=ev['V5']['f_at_min']) if ev['V5'].get('available', True)
                 else dict(available=False, traceback=ev['V5']['traceback'])),
             critical_participation=ev['crit_part'])
    return r


def mode_e1(run, audit_note):
    st = run.record['stages']
    st['audit_note'] = dict(path=str(audit_note), sha256=sha(audit_note))
    t0 = time.time()
    model = EM.E1Model()
    st['model_build_s'] = time.time() - t0
    disp = EC.Dispatcher(model)
    run.save()
    # 1. V0 (global pre-gate)
    if not run_v0(run, model, disp):
        return 'V0 GECMEDI: E1 yurutulmedi (§10)'
    # 2. candidate selection (§3.2): dispatch + 5.1a + L1-L6 only; no spectral quantity
    cd = run.dir / 'candidates'
    cd.mkdir()
    cands, chosen = [], None
    for k, G_R in enumerate(EC.CANDIDATES):
        dd = disp.dispatch_E1(G_R)
        c = dict(k=k, G_R_T=G_R, dispatch_ok=dd['ok'], dispatch_reason=dd['reason'], oned_log=dd['oned_log'])
        if dd['ok']:
            chk, F = EC.checks_51a(model, dd['x'], dd['rho'], G_R, 'T', disp=dd)
            lim = EC.limits(model, dd['x'], dd['rho'], G_R)
            D = chk['all_applicable_passed']
            c.update(P_akt=dd['P_akt'], oned_residual=dd['oned_residual'], rho=dict(zip(REF_NAMES, dd['rho'].tolist())),
                     pf=dict(V2=dd['pf']['V2'], S_gen=dd['pf']['S_gen'], mismatch_hist=dd['pf']['mismatch_hist']),
                     gfm_inner_newton_hist=dd['gfm_init']['inner_newton_hist'], refine_hist=dd['refine_hist'],
                     load_init=dd['load_init'], checks_51a=chk, D=D)
            if D:
                c.update(limits=lim['limits'], Lim=lim['Lim'], report=lim['report'])
                c['decision'] = {EC.OK: 'uygun', EC.VIOL: 'ihlal ile elendi',
                                 EC.BORDER: 'sinirda nedeniyle elendi'}[lim['Lim']]
            else:
                failed = [kk for kk, v in chk.items() if isinstance(v, dict) and v.get('applicable') and not v['passed']]
                c.update(raw_limit_values_unlabelled=strip_status(lim), D_reason='E-gecersiz: ' + ', '.join(failed),
                         decision='D basarisiz')
            write_state(cd, f'cand_{k}_GR{G_R}', dd['x'], dd['x_init'], 'x_init_before_refine', F, model.M)
        else:
            c.update(D=False, D_reason=dd['reason'], decision='D basarisiz')
        dump(cd / f'cand_{k}_GR{G_R}.json', c)
        cands.append(c)
        print(f'aday {k}: G_R,T={G_R} -> {c["decision"]}')
        if c['decision'] == 'uygun':
            chosen = (k, G_R, dd)
            break
    st['candidates'] = [dict(k=c['k'], G_R_T=c['G_R_T'], decision=c['decision'], Lim=c.get('Lim'),
                             D_reason=c.get('D_reason')) for c in cands]
    st['candidates_not_evaluated'] = list(EC.CANDIDATES[len(cands):])
    run.save()
    if chosen is None:
        st['result'] = 'bu kurulumda uygun baslangic bulunamadi'
        return 'E1 TAMAM: bu kurulumda uygun baslangic bulunamadi'
    k, G_T, dd = chosen
    st['fixed_candidate'] = dict(k=k, G_R_T=G_T)
    run.save()
    # 3. fixed T
    pd = run.dir / 'points'
    pd.mkdir()
    xT, rho = dd['x'], dd['rho']
    chkT, _ = EC.checks_51a(model, xT, rho, G_T, 'T', disp=dd)
    v1 = EC.V1(model, xT, rho, G_T)
    D_T = bool(chkT['all_applicable_passed'] and v1['passed'])
    pairT = EC.newton_pair(model, xT, dd['iterates'], rho, G_T)
    evT = evaluate_point(model, xT, rho, G_T, 'T', pairT, D_T, pd, 'T', dd['x_init'], 'x_init_before_refine') \
        if D_T else None
    recT = point_record('T', G_T, rho, D_T, None if D_T else 'E-gecersiz (V1 veya 5.1a)', chkT, evT, v1=v1)
    recT['newton_pair_kind'] = pairT['kind']
    dump(pd / 'T_point.json', recT)
    st['T'] = {k2: recT.get(k2) for k2 in ('D', 'D_reason', 'Lim', 'N', 'N_parts', 'alpha', 'Mrj', 'F', 'F_reason')}
    run.save()
    print(f'T: {recT["F_reason"]}')
    # 4. S by continuation (no eigenvalues on the path)
    if not D_T:
        recS = dict(tag='S', D=False, D_reason='T dengesi gecersiz: surekleme baslatilamadi', F='F-degerlendirilemez')
        evS = None
    else:
        cont = EC.continuation(model, xT, rho, G_T)
        with open(run.dir / 'continuation_log.csv', 'w', newline='', encoding='utf-8') as fh:
            w = csv.writer(fh)
            keys = ['lam', 'G_R', 'res', 'n_iter', 'halvings', 'det_sign', 'logabsdet', 'cond', 'criterion', 'stop',
                    'converged', 'attempt_failed']
            w.writerow(['step'] + keys + STATE_NAMES)
            for i, e in enumerate(cont['log']):
                xs = e.get('x')
                w.writerow([i] + [e.get(kk) if not isinstance(e.get(kk), float) else num(e.get(kk)) for kk in keys]
                           + ([num(v) for v in xs] if xs is not None else [''] * N))
        failed_hist = [dict(step=i, lam=e['lam'], G_R=e['G_R'], halvings=e['halvings'], stop=e.get('stop'),
                            res_hist=e['res_hist']) for i, e in enumerate(cont['log']) if e.get('res_hist')]
        dump(run.dir / 'continuation_failed_newton_history.json', failed_hist)
        st['continuation'] = {k2: cont.get(k2) for k2 in ('reached', 'reason', 'failed_interval', 'det_sign_change',
                                                          'high_cond', 'max_cond')}
        if cont['reached']:
            xS = cont['x']
            GR_S = cont['log'][-1]['G_R']
            chkS, _ = EC.checks_51a(model, xS, rho, GR_S, 'S')
            D_S = bool(chkS['all_applicable_passed'])
            if D_S:
                ln = cont['last_newton']
                pairS = EC.newton_pair(model, xS, ln['iterates'], rho, GR_S)
                evS = evaluate_point(model, xS, rho, GR_S, 'S', pairS, True, pd, 'S', ln['iterates'][0],
                                     'x_newton_start_lambda_1')
                recS = point_record('S', GR_S, rho, True, None, chkS, evS)
                recS['newton_pair_kind'] = pairS['kind']
            else:
                failed = [kk for kk, v in chkS.items() if isinstance(v, dict) and v.get('applicable') and not v['passed']]
                evS = None
                recS = point_record('S', GR_S, rho, False, 'E-gecersiz: ' + ', '.join(failed), chkS, None)
        else:
            evS = None
            recS = dict(tag='S', D=False, D_reason=cont['reason'], F='F-degerlendirilemez',
                        note='D basarisizligi "degerlendirilemez" sonucudur; S notin F degildir (§3.3)')
        dump(pd / 'S_point.json', recS)
    st['S'] = {k2: recS.get(k2) for k2 in ('D', 'D_reason', 'Lim', 'N', 'N_parts', 'alpha', 'Mrj', 'F', 'F_reason')}
    run.save()
    print(f'S: D={recS.get("D")} reason={recS.get("D_reason")} F={recS.get("F")}')
    # 5. classification (§7.1), effect (§7.2), three axes (§7.3)
    Sstate = dict(D=bool(recS.get('D')), Lim=recS.get('Lim'), N=bool(recS.get('N')), Mrj=recS.get('Mrj'))
    cat = EC.category_71(recT['F'], Sstate)
    eff = EC.effect_72(dict(D=D_T, N=bool(recT.get('N')), alpha=recT.get('alpha'),
                            alpha_raw=evT['spec']['alpha']['raw_max_re'] if evT else None),
                       dict(D=Sstate['D'], N=Sstate['N'], alpha=recS.get('alpha'),
                            alpha_raw=evS['spec']['alpha']['raw_max_re'] if evS else None))
    same_mode = None
    if evT and evS and evT['crit_part'] and evS['crit_part']:
        pT, pS = evT['crit_part'], evS['crit_part']
        same_mode = dict(participation_L1=sum(abs(pT['vector'][s] - pS['vector'][s]) for s in STATE_NAMES),
                         group_shares_T=pT['group_shares'], group_shares_S=pS['group_shares'],
                         top2_T=pT['top2'], top2_S=pS['top2'])
    st['classification'] = dict(
        axis_a_category=cat, axis_b_validity=dict(V0=st['V0']['passed'], T=dict(D=D_T, N=recT.get('N')),
                                                   S=dict(D=recS.get('D'), N=recS.get('N'))),
        axis_c_effect=eff, critical_mode_T_vs_S_descriptive=same_mode,
        note='Hicbir sonuc E2ye otomatik gecis degildir (§7.3); asama karari denetim ve arastirmaci tarafindan verilir.')
    run.save()
    print(json.dumps(jsonable(st['classification']), indent=1, ensure_ascii=False))
    return 'E1 TAMAM: ' + cat['category']


# ------------------------------------------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('mode', choices=['check', 'v0', 'e1'])
    ap.add_argument('--run-id')
    ap.add_argument('--audit-note')
    a = ap.parse_args()
    sys.stdout.reconfigure(encoding='utf-8')
    if a.mode == 'e1' and not (a.audit_note and Path(a.audit_note).is_file()):
        print('REFUSED: e1 mode requires --audit-note <code-audit note>. E1 is not run before the code audit.')
        return 3
    run_id = a.run_id or f'{a.mode.upper()}_{datetime.datetime.now().strftime("%Y%m%d_%H%M%S")}'
    try:
        run = Run(a.mode, run_id)
    except FileExistsError:
        print(f'REFUSED: out/{run_id} already exists; outputs are never overwritten. Use a new --run-id.')
        return 4
    ok, pre = preflight()
    ll = LOW_LOAD
    if sys.platform == 'win32' and not (ll.get('set_priority_ok') and ll.get('set_affinity_ok')
                                        and ll.get('priority_class') == '0x4000' and ll.get('affinity_mask') == '0xf0000'):
        run.record['preflight'] = pre
        print('LOW-LOAD PROTOCOL NOT APPLIED: ' + json.dumps(ll))
        run.finish('DUSUK YUK UYGULANMADI: hesap baslatilmadi')
        return 6
    run.record['preflight'] = pre
    run.save()
    if not ok:
        print(json.dumps(jsonable(pre), indent=1, ensure_ascii=False))
        run.finish('PREFLIGHT BASARISIZ: hesap yapilmadi')
        return 2
    try:
        if a.mode == 'check':
            status = mode_check(run)
        elif a.mode == 'v0':
            status = mode_v0(run)
        else:
            status = mode_e1(run, Path(a.audit_note))
    except Exception:  # keep the record of an aborted run
        run.record['exception'] = traceback.format_exc()
        print(run.record['exception'])
        run.finish('HATA: calisma yarida kaldi (kayit korunur)')
        return 1
    run.finish(status)
    # check / V0 failures are verification failures -> non-zero exit; a valid negative E1 result is not an error
    return 5 if status in ('CHECK BASARISIZ', 'V0 GECMEDI') or status.startswith('V0 GECMEDI') else 0


if __name__ == '__main__':
    sys.exit(main())
