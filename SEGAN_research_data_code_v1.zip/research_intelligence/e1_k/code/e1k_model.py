"""E1-K model: M-E1-0 with an EXPLICIT per-model injection of the load DC-voltage-loop gains (kpv, kiv).

Pre-registration: PF1_E1K_On_Kayit_v1.0.md (sha256 cb924a2f...). Legacy sources are imported UNCHANGED and are not patched.

* `build_ftilde_k(load_overrides)` is a VERBATIM copy of `e1_model.build_ftilde()` (legacy lines 71-167) except for the single
  parameter line: after `RB.parameters()` returns fresh dicts, the load dict is copied and only the keys named in
  `load_overrides` are replaced. Nothing global is modified; every model object owns its own parameters, symbols and
  lambdified functions (no leakage between conditions). `e1k_static` verifies the verbatim property by source comparison.
* `E1KModel` subclasses the legacy `E1Model` and re-implements ONLY `__init__` (verbatim copy of legacy lines 171-202 with
  the builder call replaced). All evaluation methods (f, J, f_fixed, J_fixed, aux, h, J_complex_step, ...) are inherited.
* The legacy reference (L0) is built with `load_overrides=None`: parameters exactly as `rhab_model.parameters()`.
"""
import sys
from pathlib import Path

import numpy as np
import sympy as sp

LEGACY_CODE = Path(__file__).resolve().parents[2] / 'e1_m-e1-0' / 'code'
if str(LEGACY_CODE) not in sys.path:
    sys.path.insert(0, str(LEGACY_CODE))
import e1_model as LM  # noqa: E402  (legacy, unchanged; sha256 pinned by the runner)
from e1_model import (RB, REF_NAMES, STATE_NAMES, N, WB, G, L, LINE, GFM_STATES, LOAD_STATES, TH_OC, P_M, TH_PLL,  # noqa: E402
                      EPS_PLL, V_DC, I_THETA, mass_vector, park, inv_park)

# keys of the load dict that E1-K is allowed to override (pre-registration §2: only kpv and kiv)
ALLOWED_OVERRIDES = ('kpv', 'kiv')


def build_ftilde_k(load_overrides=None):
    load, gfm, net = RB.parameters()
    # --- E1-K explicit injection (the only difference from the legacy builder) ---
    load = dict(load)
    for _k, _v in (load_overrides or {}).items():
        if _k not in ALLOWED_OVERRIDES:
            raise KeyError(f'E1-K may override only {ALLOWED_OVERRIDES}, got {_k!r}')
        load[_k] = float(_v)
    # --- end injection ---
    x = sp.symbols('x0:%d' % N)
    X = dict(zip(STATE_NAMES, x))
    z = sp.Symbol('z')
    GR = sp.Symbol('G_R')
    rho = sp.symbols(' '.join(REF_NAMES))
    Pref, Qref, Vref, Vref_dc, Iq_ref = rho
    f = {}
    Vr1, Vr2, Vi1, Vi2 = X['V_1:R'], X['V_2:R'], X['V_1:I'], X['V_2:I']

    # ---- GFM (pre-reg §2.5 abbreviations; h kept as x-dependence) ----
    g = [X[G + ':' + s] for s in GFM_STATES]
    th, pm, qm, xid, xiq, gd, gq, phd, phq, Irc, Iic, Vrf, Vif, Irf, Iif = g
    h = gfm['w_ref'] + gfm['Rp'] * (Pref - pm)
    p_e = Irf * Vrf + Iif * Vif
    q_e = -Iif * Vrf + Irf * Vif
    f[TH_OC] = sp.Integer(0)
    f[P_M] = gfm['wz'] * (p_e - pm)
    f[G + ':' + GFM_STATES[2]] = gfm['wf'] * (q_e - qm)
    V_oc = Vref + gfm['kq'] * (Qref - qm)
    Idf, Iqf = park(th, Irf, Iif)
    Idc, Iqc = park(th, Irc, Iic)
    Vdf, Vqf = park(th, Vrf, Vif)
    Vd_ref = V_oc - gfm['rv'] * Idf + h * gfm['lv'] * Iqf
    Vq_ref = -gfm['rv'] * Iqf - h * gfm['lv'] * Idf
    Id_pi = gfm['kpv'] * (Vd_ref - Vdf) + gfm['kiv'] * xid
    Iq_pi = gfm['kpv'] * (Vq_ref - Vqf) + gfm['kiv'] * xiq
    f[G + ':' + GFM_STATES[3]] = Vd_ref - Vdf
    f[G + ':' + GFM_STATES[4]] = Vq_ref - Vqf
    Idc_ref = Id_pi - gfm['cf'] * h * Vqf + gfm['kffi'] * Idf
    Iqc_ref = Iq_pi + gfm['cf'] * h * Vdf + gfm['kffi'] * Iqf
    Vd_pi = gfm['kpc'] * (Idc_ref - Idc) + gfm['kic'] * gd
    Vq_pi = gfm['kpc'] * (Iqc_ref - Iqc) + gfm['kic'] * gq
    f[G + ':' + GFM_STATES[5]] = Idc_ref - Idc
    f[G + ':' + GFM_STATES[6]] = Iqc_ref - Iqc
    Vd_cnv = Vd_pi - h * gfm['lf'] * Iqc + gfm['kffv'] * Vdf - gfm['kad'] * (Vdf - phd)
    Vq_cnv = Vq_pi + h * gfm['lf'] * Idc + gfm['kffv'] * Vqf - gfm['kad'] * (Vqf - phq)
    f[G + ':' + GFM_STATES[7]] = gfm['wad'] * (Vdf - phd)
    f[G + ':' + GFM_STATES[8]] = gfm['wad'] * (Vqf - phq)
    md, mq = Vd_cnv / gfm['Vdc'], Vq_cnv / gfm['Vdc']           # inner_control_models.jl:251-252
    mr, mi = inv_park(th, md, mq)                               # converter_models.jl:31
    Vr_cnv, Vi_cnv = mr * gfm['Vdc'], mi * gfm['Vdc']
    f[G + ':ir_cnv'] = Vr_cnv - Vrf - gfm['rf'] * Irc + z * gfm['lf'] * Iic
    f[G + ':ii_cnv'] = Vi_cnv - Vif - gfm['rf'] * Iic - z * gfm['lf'] * Irc
    f[G + ':vr_filter'] = Irc - Irf + z * gfm['cf'] * Vif
    f[G + ':vi_filter'] = Iic - Iif - z * gfm['cf'] * Vrf
    f[G + ':ir_filter'] = Vrf - Vr1 - gfm['rg'] * Irf + z * gfm['lg'] * Iif
    f[G + ':ii_filter'] = Vif - Vi1 - gfm['rg'] * Iif - z * gfm['lg'] * Irf
    kG = gfm['base_power'] / net['Sbase']

    # ---- Active load ----
    l = [X[L + ':' + s] for s in LOAD_STATES]
    thp, eps, eta, vdc, lgd, lgq, lIrc, lIic, lVrf, lVif, lIrf, lIif = l
    lIdc, lIqc = park(thp, lIrc, lIic)
    Vdp, Vqp = park(thp, lVrf, lVif)
    dw = load['kp_pll'] * Vqp + load['ki_pll'] * eps
    w_abs = 1 + dw
    f[TH_PLL] = WB * (1 + dw - z)
    f[EPS_PLL] = Vqp
    Id_ref = load['kpv'] * (Vref_dc - vdc) + load['kiv'] * eta
    f[L + ':' + LOAD_STATES[2]] = Vref_dc - vdc
    Vd_unc = load['kpc'] * (-Id_ref + lIdc) + load['kic'] * lgd
    Vq_unc = load['kpc'] * (-Iq_ref + lIqc) + load['kic'] * lgq
    f[L + ':' + LOAD_STATES[4]] = -Id_ref + lIdc
    f[L + ':' + LOAD_STATES[5]] = -Iq_ref + lIqc
    Vd_c = Vd_unc + w_abs * load['lf'] * lIqc
    Vq_c = Vq_unc - w_abs * load['lf'] * lIdc
    lVr_c, lVi_c = inv_park(thp, Vd_c, Vq_c)
    P_cnv = lVr_c * lIrc + lVi_c * lIic
    f[V_DC] = (WB / load['c_dc']) * (P_cnv / vdc - vdc / load['r_load'])
    f[L + ':ir_cnv'] = lVrf - lVr_c - load['rf'] * lIrc + z * load['lf'] * lIic
    f[L + ':ii_cnv'] = lVif - lVi_c - load['rf'] * lIic - z * load['lf'] * lIrc
    f[L + ':vr_filter'] = lIrf - lIrc + z * load['cf'] * lVif
    f[L + ':vi_filter'] = lIif - lIic - z * load['cf'] * lVrf
    f[L + ':ir_filter'] = Vr2 - lVrf - load['rg'] * lIrf + z * load['lg'] * lIif
    f[L + ':ii_filter'] = Vi2 - lVif - load['rg'] * lIif - z * load['lg'] * lIrf
    kL = load['base_power'] / net['Sbase']

    # ---- Line (M = 1, source row scaling) ----
    IlR, IlI = X[LINE + ':Il_R'], X[LINE + ':Il_I']
    R, Xl = net['r'], net['x']
    f[LINE + ':Il_R'] = (WB / Xl) * ((Vr1 - Vr2) - R * IlR + z * Xl * IlI)
    f[LINE + ':Il_I'] = (WB / Xl) * ((Vi1 - Vi2) - R * IlI - z * Xl * IlR)

    # ---- Buses (M = b/omega_b); G_R only at bus 102 ----
    b1, b2 = net['b_from'], net['b_to']
    f['V_1:R'] = kG * Irf - IlR + z * b1 * Vi1
    f['V_1:I'] = kG * Iif - IlI - z * b1 * Vr1
    f['V_2:R'] = -kL * lIrf + IlR - GR * Vr2 + z * b2 * Vi2
    f['V_2:I'] = -kL * lIif + IlI - GR * Vi2 - z * b2 * Vr2

    fvec = sp.Matrix([f[nm] for nm in STATE_NAMES])
    aux = dict(h=h, p_e=p_e, q_e=q_e, Vq_pll=Vqp, dw=dw, P_cnv=P_cnv, Vd_c_L=Vd_c, Vq_c_L=Vq_c,
               Vd_cnv_G=Vd_cnv, Vq_cnv_G=Vq_cnv)
    return dict(x=x, z=z, GR=GR, rho=rho, fvec=fvec, h=h, aux=aux, M=mass_vector(load, gfm, net),
                load=load, gfm=gfm, net=net)


class E1KModel(LM.E1Model):
    """Legacy E1Model with explicit gain injection. Only __init__ is re-implemented (verbatim copy otherwise)."""

    def __init__(self, label, load_overrides=None):
        s = build_ftilde_k(load_overrides)
        self.s = s
        self.load, self.gfm, self.net, self.M = s['load'], s['gfm'], s['net'], s['M']
        x, z, GR, rho, fvec, h = s['x'], s['z'], s['GR'], s['rho'], s['fvec'], s['h']
        X = sp.Matrix(x)
        self.Jx_tilde_sym = fvec.jacobian(X)
        self.Jz_tilde_sym = fvec.diff(z)
        self.f_new_sym = fvec.subs(z, h)                      # f(x) = f_tilde(x, h(x))
        self.J_new_sym = self.f_new_sym.jacobian(X)           # symbolic chain rule (pre-reg §2.6)
        self.f_fix_sym = fvec.subs(z, 1)                      # f_tilde(x, 1)
        self.J_fix_sym = self.f_fix_sym.jacobian(X)
        at = list(x) + [z] + list(rho) + [GR]
        an = list(x) + list(rho) + [GR]
        self._ft = sp.lambdify(at, fvec, modules='numpy', cse=True)
        self._Jxt = sp.lambdify(at, self.Jx_tilde_sym, modules='numpy', cse=True)
        self._Jzt = sp.lambdify(at, self.Jz_tilde_sym, modules='numpy', cse=True)
        self._fn = sp.lambdify(an, self.f_new_sym, modules='numpy', cse=True)
        self._Jn = sp.lambdify(an, self.J_new_sym, modules='numpy', cse=True)
        self._ff = sp.lambdify(an, self.f_fix_sym, modules='numpy', cse=True)
        self._Jf = sp.lambdify(an, self.J_fix_sym, modules='numpy', cse=True)
        self._aux = {k: sp.lambdify(an, v, modules='numpy') for k, v in s['aux'].items()}
        # ---- structural facts (pre-reg §2.5, §5.0) ----
        self.theta_row_zero = {
            'f_tilde': fvec[I_THETA] == 0 and all(e == 0 for e in self.Jx_tilde_sym.row(I_THETA))
                       and self.Jz_tilde_sym[I_THETA] == 0,
            'new': self.f_new_sym[I_THETA] == 0 and all(e == 0 for e in self.J_new_sym.row(I_THETA)),
            'fixed': self.f_fix_sym[I_THETA] == 0 and all(e == 0 for e in self.J_fix_sym.row(I_THETA)),
        }
        self.z_rows = [STATE_NAMES[k] for k in range(N) if self.Jz_tilde_sym[k] != 0]
        self.gr_rows = [STATE_NAMES[k] for k in range(N) if fvec[k].has(GR)]
        self.aux_free_of_z = all(not v.has(z) for v in s['aux'].values())
        self.label = label
        self.load_overrides = dict(load_overrides or {})