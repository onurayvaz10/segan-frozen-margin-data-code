"""E1-K pure logic (settings, unit mapping, status labels, hypotheses, gate comparators).

Pre-registration: PF1_E1K_On_Kayit_v1.0.md (sha256 cb924a2f415021e2d354eaead2a0e854d2072f700b2123d01d9aff1e6dfdeb96).
Section numbers below refer to it. Nothing here builds a model, solves an equilibrium or computes an eigenvalue: this module
only holds the frozen constants and the decision rules, so it can be inspected and (later, when authorised) self-tested
without any physics computation. All numbers below are copied from the protocol; none is tuned.
"""
import math
from dataclasses import dataclass

import numpy as np

# ------------------------------------------------------------------------------------------------------------
# Frozen constants (§2, §3, §4, §1.2). DO NOT CHANGE.
# ------------------------------------------------------------------------------------------------------------
G_R_T = 0.25                      # §3
TAU_REG = 1e-6                    # §4: absolute alpha difference, s^-1  [P]
TAU_MAP = 1e-12                   # §4: relative, unit mapping           [P]
TAU_INV = 1e-9                    # §4: normalised, state/ref/limit fields [P]
ETA_ALPHA = 1e-2                  # E1 §5.2 (unchanged)
EPS_EFFECT = 5.0                  # E1 §5.4 (unchanged)
E_NUM_MAX = ETA_ALPHA / 10        # E1 §5.1b N gate (unchanged); operational error budget per alpha (§1.2)
SPREAD_SUPPORT = EPS_EFFECT + ETA_ALPHA   # 5.01  (§1.2)
SPREAD_NULL = EPS_EFFECT - ETA_ALPHA      # 4.99  (§1.2)
BUDGET_DELTA = 2 * E_NUM_MAX      # operational total for one Delta-alpha (<= 2.0e-3)
BUDGET_PAIR = 4 * E_NUM_MAX       # operational total for a difference of two Delta-alpha (<= 4.0e-3)
GAIN_RATIO = 1.0 / 300.0          # K_pv / K_iv in every source setting (Table 3.10)


@dataclass(frozen=True)
class Setting:
    code: str
    name: str
    kind: str                     # 'normal' | 'stres' | 'referans'
    k_iv_si: object               # A/(V s)  (None for the legacy reference L0)
    k_pv_si: object               # A/V


# §2 source list: Bottrell 2014, Table 3.10 (printed p.149), sec. 3.7.1. Frozen; nothing is added or removed.
SETTINGS = (
    Setting('S1', 'Dusuk', 'normal', 15.0, 0.05),
    Setting('S2', 'Kaynak nominali', 'normal', 150.0, 0.5),
    Setting('S3', 'Yuksek', 'normal', 600.0, 2.0),
    Setting('S4', 'Stres', 'stres', 2700.0, 9.0),
)
LEGACY = Setting('L0', 'Yazar modeli nominali (referans)', 'referans', None, None)
NORMAL = tuple(s.code for s in SETTINGS if s.kind == 'normal')   # decision set for H-K0/H-K1/H-K2
ALL_CODES = tuple(s.code for s in SETTINGS) + (LEGACY.code,)


# ------------------------------------------------------------------------------------------------------------
# §2 unit mapping: K_pu = K_SI * V_b,dc / I_b   (I_b = S_b / V_b; V_b,dc = sqrt(8)/sqrt(3) * V_b, as load_data.jl:57-63)
# ------------------------------------------------------------------------------------------------------------
def base_quantities():
    Vb, Pb = 380.0, 10000.0
    Ib = Pb / Vb
    Vb_dc = math.sqrt(8) / math.sqrt(3) * Vb
    return dict(Vb=Vb, Pb=Pb, Ib=Ib, Vb_dc=Vb_dc, factor=Vb_dc / Ib)


def pu_gains(setting):
    """Return (kpv_pu, kiv_pu) for a source setting. Not defined for the legacy reference (it is never injected)."""
    if setting.k_iv_si is None:
        raise ValueError('legacy reference L0 has no SI gains; it is built without injection')
    f = base_quantities()['factor']
    return setting.k_pv_si * f, setting.k_iv_si * f


def rel_diff(a, b):
    m = max(abs(a), abs(b))
    return 0.0 if m == 0 else abs(a - b) / m


def norm_diff(a, b):
    """Normalisation of §4: |a-b| / (1 + max(|a|, |b|))."""
    return abs(a - b) / (1.0 + max(abs(a), abs(b)))


def gmap_checks(settings, injected):
    """G-MAP (§4.3). `injected` maps code -> (kpv_pu, kiv_pu) actually stored in the model object."""
    bq = base_quantities()
    rows, ok = [], True
    for s in settings:
        kpv_i, kiv_i = injected[s.code]
        # independent evaluation (different operation order and sqrt(8/3) instead of sqrt(8)/sqrt(3))
        ind = math.sqrt(8.0 / 3.0) * bq['Vb'] * bq['Vb'] / bq['Pb']
        d_pv, d_iv = rel_diff(kpv_i, s.k_pv_si * ind), rel_diff(kiv_i, s.k_iv_si * ind)
        back_pv = kpv_i * bq['Ib'] / bq['Vb_dc']
        back_iv = kiv_i * bq['Ib'] / bq['Vb_dc']
        r_pv, r_iv = rel_diff(back_pv, s.k_pv_si), rel_diff(back_iv, s.k_iv_si)
        ratio = rel_diff(kpv_i / kiv_i, GAIN_RATIO)
        passed = max(d_pv, d_iv, r_pv, r_iv, ratio) <= TAU_MAP
        ok &= passed
        rows.append(dict(code=s.code, kpv_pu=kpv_i, kiv_pu=kiv_i, rel_forward_pv=d_pv, rel_forward_iv=d_iv,
                         rel_back_pv=r_pv, rel_back_iv=r_iv, rel_ratio=ratio, passed=passed))
    return ok, rows


# ------------------------------------------------------------------------------------------------------------
# §1.1 setting status: priority-ordered, mutually exclusive
# ------------------------------------------------------------------------------------------------------------
ST_A = 'HATA/CALISTIRILMADI'
ST_B = 'T-D-GECERSIZ'
ST_C = 'T-N-GECERSIZ'
ST_D = 'T-UYGUN-DEGIL'
ST_E = 'S-D-GECERSIZ'
ST_F = 'S-N-GECERSIZ'
ST_G = 'TAM'
F_ONAY, F_RET = 'F-onay', 'F-ret'
SPECTRAL_ROWS = ('2', '3', '9a')          # E1 §7.1 rows that rest on a proven spectral margin violation
ROW_ATTRIBUTION = {
    '2': 'saf mekanizma ihlali [M]',
    '3': 'karma ihlal [L+M]',
    '4': 'yalniz sinir ihlali [L]',
    '5': 'sinir ihlali; kararlilik belirsiz ya da degerlendirilemez [L+?]',
    '9a': 'marj ihlali; sinirlar sinirda [M + L?] (F-ret kesin; mekanizma atfi belirsiz)',
}


def setting_status(rec):
    """rec: {'exec': 'TAMAMLANDI'|'HATA'|'CALISTIRILMADI', 'T': {D,N,F,...}, 'S': {D,N,F,...} or None}."""
    if rec.get('exec') != 'TAMAMLANDI':
        return ST_A
    T, S = rec['T'], rec.get('S')
    if not T.get('D'):
        return ST_B
    if not T.get('N'):
        return ST_C
    if T.get('F') != F_ONAY:
        return ST_D
    if S is None or not S.get('D'):
        return ST_E
    if not S.get('N'):
        return ST_F
    return ST_G


# ------------------------------------------------------------------------------------------------------------
# §1.2-§1.3 hypotheses (normal settings only; S4 and L0 never enter)
# ------------------------------------------------------------------------------------------------------------
def _normal(recs):
    return {c: recs[c] for c in NORMAL if c in recs}


def hk0(recs):
    """Null supported only on full coverage: all three normal settings TAM, S row 6 and 'anlamsiz'."""
    n = _normal(recs)
    stat = {c: setting_status(r) for c, r in n.items()}
    full = len(n) == len(NORMAL) and all(s == ST_G for s in stat.values())
    if not full:
        return dict(decision='desteklenmedi_kapsam_eksik', statuses=stat,
                    note='Herhangi bir normal ayar TAM degil: null desteklenmez; kapsam eksik / degerlendirilemez.')
    per = []
    for c in n:
        row, eff = n[c]['S']['category_row'], n[c]['effect_decision']
        reasons = []
        if row != '6':
            reasons.append(f'S kategorisi satir {row} (satir 6 degil)')
        if eff != 'anlamsiz':
            reasons.append(f'etki karari "{eff}" (anlamsiz degil)')
        per.append(dict(code=c, category_row=row, effect_decision=eff, satisfied=not reasons, reasons=reasons))
    ok = all(p['satisfied'] for p in per)
    # Neutral label: failing the null criterion is NOT a finding of a significant effect (an uncertain margin, row 7,
    # or an uncertain effect band is not an observed effect). The support condition itself is unchanged.
    return dict(decision='desteklendi' if ok else 'desteklenmedi_olcut_saglanmadi', statuses=stat, per_setting=per,
                note='Yalnizca on-kayitli olcute gore anlamli etki/ihlal gozlenmedi anlamina gelir.' if ok else
                'Tam kapsamda satir 6 / anlamsiz kosulu ayar bazinda saglanmadi (nedenler per_setting alaninda). '
                'Belirsizlik (satir 7, belirsiz etki bandi) anlamli etki gozlemi sayilmaz.')


def hk1(recs):
    """Existence: a normal setting with T F-onay and proven F-ret at S (D valid at S). TAM is NOT required."""
    n = _normal(recs)
    elig, cands = [], []
    for c, r in n.items():
        if r.get('exec') != 'TAMAMLANDI':
            continue
        T, S = r['T'], r.get('S')
        if not (T.get('D') and T.get('N') and T.get('F') == F_ONAY):
            continue                                     # statuses (b)(c)(d) never enter H-K1
        cands.append(c)
        if S is not None and S.get('D') and S.get('F') == F_RET:
            row = S['category_row']
            # N valid alone is not a mechanism: spectral margin violation only for rows 2 (pure), 3 (mixed), 9a (limits borderline)
            spectral = bool(S.get('N')) and row in SPECTRAL_ROWS
            elig.append(dict(code=c, row=row, attribution=ROW_ATTRIBUTION.get(row, 'tanimsiz satir'),
                             pure_mechanism=(row == '2'), spectral_mechanism=spectral,
                             note='yalniz sinir ihlali [L]: F-ret bulgusu, spektral mekanizma degil' if row == '4' else
                             ('sinir ihlali; kararlilik belirsiz/degerlendirilemez [L+?]: yalniz F-ret bulgusu, spektral '
                              'mekanizma degil' if row == '5' else '')))
    return dict(decision='destekleniyor' if elig else 'desteklenmiyor', eligible=elig, T_onay_settings=cands,
                note='H-K1 genel kume fizibilitesi, fiziksel gecerlilik veya yontem katkisi kaniti degildir.')


def _alpha_pair(rec):
    T, S = rec.get('T') or {}, rec.get('S') or {}
    if rec.get('exec') != 'TAMAMLANDI':
        return None
    if not (T.get('D') and T.get('N') and S and S.get('D') and S.get('N')):
        return None
    if T.get('alpha') is None or S.get('alpha') is None:
        return None
    return T['alpha'], S['alpha']


def hk2(recs):
    """Dependence of Delta-alpha on the gain: comparative [P] rule of §1.2. T F-onay is NOT required for V."""
    n = _normal(recs)
    V, d, pairs = [], {}, {}
    for c, r in n.items():
        ap = _alpha_pair(r)
        if ap is None:
            continue
        V.append(c)
        d[c] = ap[1] - ap[0]
        pairs[c] = ap
    out = dict(V=V, delta_alpha=d, n_V=len(V))
    # defensive e_num record check (upstream N gate guarantees it; a missing / non-finite / exceeding record yields no decision)
    bad = []
    for c in V:
        for pt in ('T', 'S'):
            e = n[c][pt].get('e_num')
            if e is None or not isinstance(e, (int, float, np.floating)) or not math.isfinite(float(e)) or float(e) > E_NUM_MAX:
                bad.append(dict(code=c, point=pt, e_num=e))
    if bad:
        out.update(decision='yorumlanamaz', spread=None, reason='e_num kaydi eksik, sonlu degil veya butceyi asiyor',
                   bad_e_num_records=bad)
        return out
    if len(V) < 2:
        out.update(decision='degerlendirilemez', spread=None, reason='|V| < 2')
        return out
    hi = max(V, key=lambda c: d[c])
    lo = min(V, key=lambda c: d[c])
    spread = d[hi] - d[lo]
    en = {c: (n[c]['T'].get('e_num'), n[c]['S'].get('e_num')) for c in (hi, lo)}
    comp = all(v is not None for t in en.values() for v in t)
    B = sum(v for t in en.values() for v in t) if comp else None
    out.update(spread=spread, argmax=hi, argmin=lo, e_num_endpoints=en, budget_pair_recorded=B,
               budget_policy_pair=BUDGET_PAIR, budget_complete=comp,
               budget_within_policy=(B is not None and B <= BUDGET_PAIR), guard_eta_alpha=ETA_ALPHA)
    if spread >= SPREAD_SUPPORT:
        out['decision'] = 'destekleniyor'
    elif spread <= SPREAD_NULL and len(V) == len(NORMAL):
        out['decision'] = 'anlamli_bagimlilik_gozlenmedi'
    elif spread <= SPREAD_NULL:
        out['decision'] = 'degerlendirilemez'
        out['reason'] = '|V| = 2 ve spread <= 4.99 (tam kapsam yok)'
    else:
        out['decision'] = 'belirsiz'
    out['note'] = ('Karar matematiksel model icinde, e_num operasyonel butce politikasi kosuluyla verilir; sertifikali '
                   'hata siniri veya fiziksel saglamlik iddiasi yoktur. "Bagimlilik yoktur" iddiasi yapilmaz.')
    return out


# ------------------------------------------------------------------------------------------------------------
# Gate comparators (pure)
# ------------------------------------------------------------------------------------------------------------
def compare_numeric(a, b, names=None):
    a, b = np.asarray(a, dtype=float).ravel(), np.asarray(b, dtype=float).ravel()
    if a.shape != b.shape:
        return dict(ok=False, max_norm_diff=None, worst=None, reason=f'shape {a.shape} vs {b.shape}')
    nd = np.array([norm_diff(x, y) for x, y in zip(a, b)]) if a.size else np.zeros(0)
    k = int(np.argmax(nd)) if nd.size else None
    return dict(ok=bool(nd.size == 0 or float(np.max(nd)) <= TAU_INV), max_norm_diff=float(np.max(nd)) if nd.size else 0.0,
                worst=(names[k] if (names is not None and k is not None) else k))


def reg_compare(new, old):
    """G-REG (§4.2). Each side: dict(alpha_T, alpha_S, xT, xS, rho, lim_T, lim_S, labels). Absolute alpha differences."""
    r = {}
    r['alpha_T_abs_diff'] = abs(new['alpha_T'] - old['alpha_T'])
    r['alpha_S_abs_diff'] = abs(new['alpha_S'] - old['alpha_S'])
    r['alpha_T_ok'] = bool(r['alpha_T_abs_diff'] <= TAU_REG)
    r['alpha_S_ok'] = bool(r['alpha_S_abs_diff'] <= TAU_REG)
    r['xT'] = compare_numeric(new['xT'], old['xT'], new.get('state_names'))
    r['xS'] = compare_numeric(new['xS'], old['xS'], new.get('state_names'))
    r['rho'] = compare_numeric(new['rho'], old['rho'], new.get('ref_names'))
    keys = sorted(set(new['lim_T']) | set(old['lim_T']))
    r['lim_T'] = compare_numeric([new['lim_T'][k] for k in keys], [old['lim_T'][k] for k in keys], keys)
    r['lim_S'] = compare_numeric([new['lim_S'][k] for k in keys], [old['lim_S'][k] for k in keys], keys)
    lab_keys = sorted(set(new['labels']) | set(old['labels']))
    mism = [k for k in lab_keys if new['labels'].get(k) != old['labels'].get(k)]
    r['labels'] = dict(ok=not mism, mismatches={k: (new['labels'].get(k), old['labels'].get(k)) for k in mism})
    r['passed'] = bool(r['alpha_T_ok'] and r['alpha_S_ok'] and r['xT']['ok'] and r['xS']['ok'] and r['rho']['ok']
                       and r['lim_T']['ok'] and r['lim_S']['ok'] and r['labels']['ok'])
    return r


def inv_compare(ref, pt, eta_index, kiv_ref, kiv_pt, state_names=None):
    """G-INV (§4.4) for one point (T or S) of a setting against the reference setting S2.
    ref/pt: dict(x, rho, P_akt, lim_values{...}, labels{...}). Only eta is excluded; Boolean/label fields: exact equality."""
    keep = [k for k in range(len(ref['x'])) if k != eta_index]
    xs_ref = np.asarray(ref['x'], dtype=float)[keep]
    xs_pt = np.asarray(pt['x'], dtype=float)[keep]
    names = [state_names[k] for k in keep] if state_names is not None else None
    out = {}
    out['states_except_eta'] = compare_numeric(xs_pt, xs_ref, names)
    eta_ok = norm_diff(kiv_pt * pt['x'][eta_index], kiv_ref * ref['x'][eta_index])
    out['eta_scaling'] = dict(ok=bool(eta_ok <= TAU_INV), norm_diff=eta_ok)
    out['rho'] = compare_numeric(pt['rho'], ref['rho'])
    if ref.get('P_akt') is not None and pt.get('P_akt') is not None:
        d = norm_diff(pt['P_akt'], ref['P_akt'])
        out['P_akt'] = dict(ok=bool(d <= TAU_INV), norm_diff=d)
    keys = sorted(set(ref['lim_values']) | set(pt['lim_values']))
    out['lim_values'] = compare_numeric([pt['lim_values'][k] for k in keys], [ref['lim_values'][k] for k in keys], keys)
    lab_keys = sorted(set(ref['labels']) | set(pt['labels']))
    mism = [k for k in lab_keys if ref['labels'].get(k) != pt['labels'].get(k)]
    out['labels_exact'] = dict(ok=not mism, mismatches={k: (pt['labels'].get(k), ref['labels'].get(k)) for k in mism})
    out['passed'] = all(v.get('ok', True) for v in out.values() if isinstance(v, dict))
    return out
