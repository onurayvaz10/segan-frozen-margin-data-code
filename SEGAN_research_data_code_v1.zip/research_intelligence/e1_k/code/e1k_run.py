"""E1-K runner. Pre-registration PF1_E1K_On_Kayit_v1.0.md (sha256 cb924a2f415021e2d354eaead2a0e854d2072f700b2123d01d9aff1e6dfdeb96).

Section numbers below ("§n") refer to that protocol. Legacy E1/R-HA/R-HA-B sources are IMPORTED UNCHANGED (hash-pinned) and
are never written to; every output goes to a NEW folder e1_k/out/<RUN_ID> (an existing RUN_ID is refused).

Modes (sequence of the hand-over note: protocol -> code audit -> gates -> settings -> raw-result audit):
  static    : compile + AST + import + source-verbatim + constants-vs-protocol + hash-pin checks. No model is built, no
              equilibrium, eigenvalue or simulation is computed. (The only mode authorised at code-delivery time.)
  gates     : G-V0 -> L0 regression pipeline + G-REG -> G-MAP (§4.1-§4.3). Needs --audit-note.
  settings  : S1..S4 pipelines -> G-INV -> status labels and H-K0/H-K1/H-K2 (§1, §4.4, §7). Needs --audit-note and
              --gates-run <RUN_ID of a PASSED gates run> (its manifest and code snapshot are re-verified).
No mode contains E1-K-X (excluded by the protocol). Thresholds and the setting list are fixed in e1k_core.py.

Usage: python -I e1k_run.py static|gates|settings [--run-id ID] [--audit-note PATH] [--gates-run ID]
"""
import os
for _v in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[_v] = '1'

import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
E1K = HERE.parent
RI = HERE.parents[1]
E1ROOT = RI / 'e1_m-e1-0'
LEGACY_CODE = E1ROOT / 'code'
for _p in (str(HERE), str(LEGACY_CODE)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import e1_run as ER   # noqa: E402  legacy runner module: imported for its helper functions; applies the low-load protocol on import
import argparse  # noqa: E402
import ast  # noqa: E402
import csv  # noqa: E402
import datetime  # noqa: E402
import hashlib  # noqa: E402
import inspect  # noqa: E402
import json  # noqa: E402
import math  # noqa: E402
import re  # noqa: E402
import shutil  # noqa: E402
import time  # noqa: E402
import traceback  # noqa: E402

import numpy as np  # noqa: E402

import e1_core as EC  # noqa: E402  legacy core (unchanged)
import e1_model as EM  # noqa: E402  legacy model (unchanged)
import e1k_core as KC  # noqa: E402
import e1k_model as KM  # noqa: E402
from e1_model import N, REF_NAMES, STATE_NAMES, RB, L as LOAD_ID  # noqa: E402

OUT = E1K / 'out'
PROTOCOL = RI / 'PF1_E1K_On_Kayit_v1.0.md'
PROTOCOL_SABIT = E1K / 'sabit' / 'PF1_E1K_On_Kayit_v1.0_SABIT.md'
E1_RUN = E1ROOT / 'out' / 'E1_20261012_a'
RHAB_OUT = RI / 'r_ha_b' / 'out'
E1K_FILES = ('e1k_core.py', 'e1k_model.py', 'e1k_run.py')

# Pinned inputs (a mismatch stops the run before any computation)
PINS = {
    'protokol_v1.0': (PROTOCOL, 'cb924a2f415021e2d354eaead2a0e854d2072f700b2123d01d9aff1e6dfdeb96'),
    'protokol_v1.0_SABIT': (PROTOCOL_SABIT, 'cb924a2f415021e2d354eaead2a0e854d2072f700b2123d01d9aff1e6dfdeb96'),
    'E1_sabit_on_kayit': (E1ROOT / 'sabit' / 'PF1_E1_On_Kayit_M-E1-0_v1.0_SABIT.md',
                          '11c08c3ebf9a40aa27d5165a1912eea30777ee639e50a02ed667a4015606a84b'),
    'legacy e1_model.py': (LEGACY_CODE / 'e1_model.py', '0ba6571559b557090e693aa007a57d69cbaf409122ea7602fbe7e1edefe9a15b'),
    'legacy e1_core.py': (LEGACY_CODE / 'e1_core.py', 'f1b9191cb05a2b4e08ffaba1ac4a44e3e9b50a21040055e96fe7b3f72fb34819'),
    'legacy e1_run.py': (LEGACY_CODE / 'e1_run.py', '3d087257646472e741d199998c691fba0fa56afa454d05714acc73924925b593'),
    'rhab_model.py': (RI / 'r_ha_b' / 'code' / 'rhab_model.py',
                      'db9dd3fdf510a21606a25060e423421dec977ce29dfd4fcadffb38eb9e1c9825'),
    'A_summary.json': (RHAB_OUT / 'A_summary.json', 'ab7abb51ecae681734bc4a13562d52e77e4e1025ab41b18d07dbfa8dae821214'),
    'E1_20261012_a manifest': (E1_RUN / 'SHA256SUMS.txt',
                               '9f825f58fbef887f982c42b6f487ccf5cef677282731ce24291b4bc575b395da'),
}
E1_RUN_FILES_USED = ('points/T_point.json', 'points/S_point.json', 'points/T_state.csv', 'points/S_state.csv',
                     'yurutme_kaydi.json')


# ------------------------------------------------------------------------------------------------------------
# utilities
# ------------------------------------------------------------------------------------------------------------
def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def read_manifest(path, encoding='utf-8-sig'):
    out = {}
    for line in Path(path).read_text(encoding=encoding).splitlines():
        if line.strip():
            h, name = line.split(maxsplit=1)
            out[name.strip().lstrip('*')] = h.lower()
    return out


def preflight(check_a3=True, check_e1_files=True):
    rec, ok = {}, True
    for k, (p, h) in PINS.items():
        got = sha(p) if Path(p).exists() else None
        rec[k] = dict(path=str(p), expected=h, got=got, match=got == h)
        ok &= got == h
    if check_a3:
        sums = read_manifest(RHAB_OUT / 'SHA256SUMS.txt')
        for f in ER.A3_FILES:
            got = sha(RHAB_OUT / f)
            rec[f] = dict(expected_from_rhab_SHA256SUMS=sums.get(f), got=got, match=sums.get(f) == got)
            ok &= sums.get(f) == got
    if check_e1_files:
        sums = read_manifest(E1_RUN / 'SHA256SUMS.txt')
        for f in E1_RUN_FILES_USED:
            got = sha(E1_RUN / f)
            rec['E1_20261012_a/' + f] = dict(expected_from_manifest=sums.get(f), got=got, match=sums.get(f) == got)
            ok &= sums.get(f) == got
    rec['e1k_code_sha256'] = {f: sha(HERE / f) for f in E1K_FILES}
    return ok, rec


def under(path, root):
    try:
        Path(path).resolve().relative_to(Path(root).resolve())
        return True
    except ValueError:
        return False


RUN_ID_RE = re.compile(r'[A-Za-z0-9](?:[A-Za-z0-9_.-]*[A-Za-z0-9_-])?')
WIN_RESERVED = {'CON', 'PRN', 'AUX', 'NUL', *(f'COM{i}' for i in range(1, 10)), *(f'LPT{i}' for i in range(1, 10))}


def validate_run_id(run_id):
    """A valid RUN_ID is ONE file-name component: no slash/backslash, no '.'/'..', not absolute, no drive, no trailing dot,
    no Windows device name. Returns the id or raises ValueError (nothing is created before this check)."""
    if not isinstance(run_id, str) or not run_id or run_id in ('.', '..'):
        raise ValueError(f'invalid RUN_ID {run_id!r}')
    if not RUN_ID_RE.fullmatch(run_id):
        raise ValueError(f'RUN_ID {run_id!r} must match {RUN_ID_RE.pattern}')
    p = Path(run_id)
    if p.is_absolute() or p.drive or len(p.parts) != 1 or p.name != run_id:
        raise ValueError(f'RUN_ID {run_id!r} must be a single relative path component')
    if run_id.split('.')[0].upper() in WIN_RESERVED:
        raise ValueError(f'RUN_ID {run_id!r} is a reserved device name')
    return run_id


class Run:
    """New output folder per execution; never overwrites; manifest at the end."""

    def __init__(self, mode, run_id):
        assert under(OUT, E1K) and not under(OUT, E1ROOT), 'output root must be inside e1_k and outside legacy folders'
        validate_run_id(run_id)
        target = OUT / run_id
        if target.resolve().parent != OUT.resolve():           # the resolved final path must lie DIRECTLY under OUT
            raise ValueError(f'RUN_ID {run_id!r} resolves outside {OUT}')
        OUT.mkdir(exist_ok=True)
        self.dir = target
        self.dir.mkdir(exist_ok=False)
        self.mode, self.id = mode, run_id
        self.t0 = time.time()
        self.log = open(self.dir / 'stdout.txt', 'w', encoding='utf-8')
        sys.stdout.reconfigure(encoding='utf-8')
        self._stdout = sys.stdout
        sys.stdout = ER.Tee(self._stdout, self.log)
        snap = self.dir / 'code_snapshot'
        snap.mkdir()
        for f in E1K_FILES:
            shutil.copy2(HERE / f, snap / f)
        self.record = dict(run_id=run_id, mode=mode, argv=sys.argv,
                           started=datetime.datetime.now().astimezone().isoformat(timespec='seconds'),
                           protocol=str(PROTOCOL_SABIT), env=ER.environment_record(), stages={})

    def save(self):
        p = self.dir / 'yurutme_kaydi.json'
        tmp = self.dir / 'yurutme_kaydi.json.part'
        tmp.write_text(json.dumps(ER.jsonable(self.record), indent=1, ensure_ascii=False), encoding='utf-8')
        os.replace(tmp, p)

    def finish(self, status):
        self.record.update(status=status, finished=datetime.datetime.now().astimezone().isoformat(timespec='seconds'),
                           wall_s=time.time() - self.t0)
        self.save()
        print(f'[{self.id}] status: {status}')
        sys.stdout = self._stdout
        self.log.close()
        files = sorted(p for p in self.dir.rglob('*') if p.is_file() and p.name != 'SHA256SUMS.txt')
        with open(self.dir / 'SHA256SUMS.txt', 'w', encoding='utf-8', newline='\n') as fh:
            for p in files:
                fh.write(f'{sha(p)}  {p.relative_to(self.dir).as_posix()}\n')
        idx = OUT / 'RUNS_INDEX.csv'
        new = not idx.exists()
        with open(idx, 'a', newline='', encoding='utf-8') as fh:
            w = csv.writer(fh)
            if new:
                w.writerow(['run_id', 'mode', 'started', 'finished', 'status', 'manifest_sha256'])
            w.writerow([self.id, self.mode, self.record['started'], self.record['finished'], status,
                        sha(self.dir / 'SHA256SUMS.txt')])


# ------------------------------------------------------------------------------------------------------------
# static mode (no physics)
# ------------------------------------------------------------------------------------------------------------
ALIASES = {'RB', 'LM', 'EC', 'ER', 'EM', 'KM', 'KC', 'np', 'sys', 'os', 'math', 'sp'}
FORBIDDEN_CALLS = {'setattr', 'delattr', 'exec', 'eval', 'reload', '__import__'}


def ast_scan(path):
    tree = ast.parse(Path(path).read_text(encoding='utf-8'), filename=str(path))
    problems = []
    for node in ast.walk(tree):
        targets = []
        if isinstance(node, ast.Assign):
            targets = node.targets
        elif isinstance(node, (ast.AugAssign, ast.AnnAssign)):
            targets = [node.target]
        elif isinstance(node, ast.Delete):
            targets = node.targets
        flat = []
        for t in targets:
            flat.extend(t.elts if isinstance(t, (ast.Tuple, ast.List)) else [t])
        for t in flat:
            if isinstance(t, ast.Attribute):          # direct attribute assignment (os.environ[...] = ... is a Subscript: allowed)
                root = t
                while isinstance(root, ast.Attribute):
                    root = root.value
                if isinstance(root, ast.Name) and root.id == 'sys' and t.attr == 'stdout':
                    continue                              # console tee for the run log: not a model/parameter patch
                if isinstance(root, ast.Name) and root.id in ALIASES:
                    problems.append(f'{path.name}:{node.lineno}: attribute assignment on imported module {root.id}')
        if isinstance(node, ast.Call):
            f = node.func
            name = f.id if isinstance(f, ast.Name) else (f.attr if isinstance(f, ast.Attribute) else None)
            if name in FORBIDDEN_CALLS:
                problems.append(f'{path.name}:{node.lineno}: forbidden call {name}')
        if isinstance(node, ast.Global):
            problems.append(f'{path.name}:{node.lineno}: global statement')
    # no model construction or run at import time
    for node in tree.body:
        for sub in ast.walk(node):
            if isinstance(node, (ast.FunctionDef, ast.ClassDef, ast.Import, ast.ImportFrom)):
                break
            if isinstance(sub, ast.Call):
                f = sub.func
                name = f.id if isinstance(f, ast.Name) else (f.attr if isinstance(f, ast.Attribute) else '')
                if name in ('E1KModel', 'E1Model', 'Dispatcher', 'build_ftilde_k', 'continuation', 'spectral'):
                    problems.append(f'{path.name}:{sub.lineno}: module-level call {name}')
    return problems


def parse_sci(cell):
    sup = {'⁰': '0', '¹': '1', '²': '2', '³': '3', '⁴': '4', '⁵': '5', '⁶': '6', '⁷': '7', '⁸': '8', '⁹': '9'}
    m = re.search(r'(\d+(?:\.\d+)?)×10(⁻)?([⁰¹²³⁴⁵⁶⁷⁸⁹]+)', cell)
    if not m:
        return None
    e = int(''.join(sup[c] for c in m.group(3)))
    return float(m.group(1)) * 10.0 ** (-e if m.group(2) else e)


def protocol_constants_check():
    txt = PROTOCOL.read_text(encoding='utf-8')
    res = {}
    for sym, const in (('τ_REG', KC.TAU_REG), ('τ_MAP', KC.TAU_MAP), ('τ_INV', KC.TAU_INV)):
        m = re.search(r'^\|\s*' + sym + r'\s*\|\s*([^|]+)\|', txt, flags=re.M)
        val = parse_sci(m.group(1)) if m else None
        res[sym] = dict(protocol=val, code=const, match=val is not None and math.isclose(val, const, rel_tol=1e-12))
    rows = re.findall(r'^\|\s*(S[1-4])\s*\|[^|]*\|\s*([0-9.]+)\s*\|\s*([0-9.]+)\s*\|', txt, flags=re.M)
    prot = {c: (float(a), float(b)) for c, a, b in rows}
    for s in KC.SETTINGS:
        got = prot.get(s.code)
        res[s.code] = dict(protocol_K_iv_K_pv=got, code=(s.k_iv_si, s.k_pv_si), match=got == (s.k_iv_si, s.k_pv_si))
    res['G_R_T'] = dict(code=KC.G_R_T, match=('G_R,T = 0.25' in txt or 'G_R,T = 0.25 p.u.' in txt) and KC.G_R_T == 0.25)
    res['spread'] = dict(code=(KC.SPREAD_SUPPORT, KC.SPREAD_NULL),
                         match=('5.01' in txt and '4.99' in txt and math.isclose(KC.SPREAD_SUPPORT, 5.01, rel_tol=1e-12)
                                and math.isclose(KC.SPREAD_NULL, 4.99, rel_tol=1e-12)))
    res['legacy_thresholds'] = dict(code=(KC.ETA_ALPHA, KC.EPS_EFFECT), legacy=(EC.TH['eta_alpha'], EC.TH['eps_effect']),
                                    match=(KC.ETA_ALPHA == EC.TH['eta_alpha'] and KC.EPS_EFFECT == EC.TH['eps_effect']
                                           and KC.EPS_EFFECT == EC.TH['eps_margin']))
    res['budget'] = dict(code=(KC.BUDGET_DELTA, KC.BUDGET_PAIR), match=(math.isclose(KC.BUDGET_DELTA, 2e-3) and
                                                                         math.isclose(KC.BUDGET_PAIR, 4e-3)))
    res['E_NUM_MAX'] = dict(code=KC.E_NUM_MAX, legacy=EC.TH['eta_alpha'] / 10,
                            match=math.isclose(KC.E_NUM_MAX, EC.TH['eta_alpha'] / 10, rel_tol=1e-12))
    return res


def verbatim_check():
    """e1k_model must equal the legacy sources except for the declared injection / signature lines."""
    legacy_fn = inspect.getsource(EM.build_ftilde).rstrip('\n')
    new_fn = inspect.getsource(KM.build_ftilde_k).rstrip('\n')
    exp_fn = legacy_fn.replace('def build_ftilde():', 'def build_ftilde_k(load_overrides=None):')
    old_line = '    load, gfm, net = RB.parameters()'
    inj = (old_line + '\n    # --- E1-K explicit injection (the only difference from the legacy builder) ---\n'
           '    load = dict(load)\n    for _k, _v in (load_overrides or {}).items():\n'
           '        if _k not in ALLOWED_OVERRIDES:\n'
           "            raise KeyError(f'E1-K may override only {ALLOWED_OVERRIDES}, got {_k!r}')\n"
           '        load[_k] = float(_v)\n    # --- end injection ---')
    exp_fn = exp_fn.replace(old_line, inj)
    legacy_init = inspect.getsource(EM.E1Model.__init__).rstrip('\n')
    new_init = inspect.getsource(KM.E1KModel.__init__).rstrip('\n')
    exp_init = legacy_init.replace('    def __init__(self):', '    def __init__(self, label, load_overrides=None):')
    exp_init = exp_init.replace('        s = build_ftilde()', '        s = build_ftilde_k(load_overrides)')
    exp_init += '\n        self.label = label\n        self.load_overrides = dict(load_overrides or {})'
    own = {n for n in vars(KM.E1KModel) if not n.startswith('__') or n == '__init__'}
    return dict(builder_identical_except_injection=(new_fn == exp_fn),
                init_identical_except_signature_and_label=(new_init == exp_init),
                E1KModel_own_attributes=sorted(own),
                inherits_methods=all(hasattr(KM.E1KModel, m) for m in ('f', 'J', 'f_fixed', 'J_fixed', 'aux', 'h',
                                                                         'J_complex_step', 'Jx_tilde', 'Jz_tilde')))



def mode_static(run):
    st = run.record['stages']
    syn = {}
    for f in E1K_FILES:
        try:
            compile((HERE / f).read_text(encoding='utf-8'), str(HERE / f), 'exec')
            syn[f] = 'ok'
        except SyntaxError as exc:
            syn[f] = f'SyntaxError: {exc}'
    st['syntax'] = syn
    st['imports'] = dict(e1_core=EC.__file__, e1_model=EM.__file__, e1_run=ER.__file__, e1k_core=KC.__file__,
                         e1k_model=KM.__file__, rhab_model=RB.__file__)
    st['ast'] = {f: ast_scan(HERE / f) for f in E1K_FILES}
    st['verbatim'] = verbatim_check()
    st['constants_vs_protocol'] = protocol_constants_check()
    st['output_root'] = dict(OUT=str(OUT), inside_e1_k=under(OUT, E1K), outside_legacy=not under(OUT, E1ROOT))
    ok_syn = all(v == 'ok' for v in syn.values())
    ok_ast = all(len(v) == 0 for v in st['ast'].values())
    vb = st['verbatim']
    ok_vb = vb['builder_identical_except_injection'] and vb['init_identical_except_signature_and_label'] and \
        vb['E1KModel_own_attributes'] == ['__init__'] and vb['inherits_methods']
    ok_c = all(v['match'] for v in st['constants_vs_protocol'].values())
    ok_o = st['output_root']['inside_e1_k'] and st['output_root']['outside_legacy']
    st['static_passed'] = dict(syntax=ok_syn, ast=ok_ast, verbatim=ok_vb, constants=ok_c, output_root=ok_o)
    print(json.dumps(ER.jsonable(dict(syntax=syn, ast_problems=st['ast'], verbatim=vb,
                                      constants={k: v['match'] for k, v in st['constants_vs_protocol'].items()},
                                      output_root=st['output_root'], passed=st['static_passed'])),
                     indent=1, ensure_ascii=False))
    return 'STATIC GECTI' if all(st['static_passed'].values()) else 'STATIC BASARISIZ'


# ------------------------------------------------------------------------------------------------------------
# helpers shared by gates and settings
# ------------------------------------------------------------------------------------------------------------
def build_model(spec):
    """Explicit per-model gain injection. L0 (legacy reference) is built WITHOUT injection."""
    if spec.code == KC.LEGACY.code:
        return KM.E1KModel(spec.code, None)
    kpv, kiv = KC.pu_gains(spec)
    return KM.E1KModel(spec.code, dict(kpv=kpv, kiv=kiv))


def lim_values(limits):
    return {'L1': limits['L1']['value'], 'L2': limits['L2']['value'], 'L3_V101': limits['L3']['V_101'],
            'L3_V102': limits['L3']['V_102'], 'L4': limits['L4']['value'], 'L5_g5': limits['L5']['value'],
            'L6_edc': limits['L6']['value']}


def lim_labels(limits, Lim, prefix):
    lab = {f'{prefix}.L1': limits['L1']['status'], f'{prefix}.L2': limits['L2']['status'],
           f'{prefix}.L3.101': limits['L3']['status_101'], f'{prefix}.L3.102': limits['L3']['status_102'],
           f'{prefix}.L3': limits['L3']['status'], f'{prefix}.L4': limits['L4']['status'],
           f'{prefix}.L5': limits['L5']['status'], f'{prefix}.L6': limits['L6']['status'], f'{prefix}.Lim': Lim}
    return lab


def bool51a(chk, prefix):
    return {f'{prefix}.51a.{k}': bool(v['passed']) for k, v in chk.items()
            if isinstance(v, dict) and v.get('applicable') and 'passed' in v}


def descriptives(spec):
    """§5 secondary descriptive endpoints (a)-(c); (d) V5 is stored by the point record. They never decide anything."""
    lam, PFn = spec['lam'], spec['PFn']
    ref = spec['ref']['idx']
    iv = STATE_NAMES.index(EM.V_DC)
    ie = STATE_NAMES.index(LOAD_ID + ':η')
    cand = [i for i in range(len(lam)) if i != ref and lam[i].imag > 0]
    out = {}
    if cand:
        a = max(cand, key=lambda i: PFn[iv, i] + PFn[ie, i])
        out['a_DC_CPL_pair'] = dict(idx=a, lam=lam[a], f_Hz=abs(lam[a].imag) / (2 * math.pi),
                                    zeta=-lam[a].real / abs(lam[a]), pf_vdc_plus_eta=float(PFn[iv, a] + PFn[ie, a]))
    hf = []
    for i in cand:
        k = int(np.argmax(PFn[:, i]))
        if STATE_NAMES[k].startswith('V_2:'):
            hf.append(dict(idx=i, lam=lam[i], f_Hz=abs(lam[i].imag) / (2 * math.pi), zeta=-lam[i].real / abs(lam[i]),
                           top1=STATE_NAMES[k]))
    out['b_bus102_pairs'] = hf
    out['c_modes_re_ge_minus50'] = [dict(idx=i, lam=lam[i]) for i in range(len(lam)) if i != ref and lam[i].real >= -50.0]
    return out


def fyu_flag(spec, crit_part):
    """§6: physical-interpretation suitability flag of the alpha-defining mode. Default 'belirsiz' (no validated band)."""
    al = spec['alpha']
    if not al['defined']:
        return dict(flag='belirsiz', reason='alpha tanimsiz')
    lc = spec['lam'][al['icrit']]
    return dict(flag='belirsiz', f_Hz=abs(lc.imag) / (2 * math.pi), lam=lc,
                top2=crit_part['top2'] if crit_part else None,
                group_shares=crit_part['group_shares'] if crit_part else None,
                note='Matematiksel model sonucu; olumlu gercekci mekanizma kaniti veya asama gecisi gerekcesi sayilmaz.')


# ------------------------------------------------------------------------------------------------------------
# per-setting pipeline (E1 §9 steps 3-5 with G_R,T fixed; no candidate loop) -- same calls as the legacy runner
# ------------------------------------------------------------------------------------------------------------
def persist_dispatch_raw(sdir, dd):
    """Every field the dispatcher returned (pf, 1-D log, init, refinement history, iterates, ...), success or not."""
    ER.dump(sdir / 'dispatch_raw.json', dd)


def persist_point_state(d, tag, model, x, x_start, start_label, rho, GR):
    """State / residual (F and F/M) / M record of an equilibrium that exists, whether or not its D gate passed.
    No spectral quantity is computed here."""
    Path(d).mkdir(parents=True, exist_ok=True)
    p = Path(d) / f'{tag}_state.csv'
    if not p.exists():
        ER.write_state(Path(d), tag, x, x_start, start_label, model.f(x, rho, GR), model.M)


def persist_continuation(sdir, model, rho, xT, cont):
    """Continuation log, failed-Newton histories and a result record; the last accepted state if S was not reached."""
    with open(sdir / 'continuation_log.csv', 'w', newline='', encoding='utf-8') as fh:
        w = csv.writer(fh)
        keys = ['lam', 'G_R', 'res', 'n_iter', 'halvings', 'det_sign', 'logabsdet', 'cond', 'criterion', 'stop',
                'converged', 'attempt_failed']
        w.writerow(['step'] + keys + STATE_NAMES)
        for i, e in enumerate(cont['log']):
            xs = e.get('x')
            w.writerow([i] + [e.get(kk) if not isinstance(e.get(kk), float) else ER.num(e.get(kk)) for kk in keys]
                       + ([ER.num(v) for v in xs] if xs is not None else [''] * N))
    failed_hist = [dict(step=i, lam=e['lam'], G_R=e['G_R'], halvings=e['halvings'], stop=e.get('stop'),
                        res_hist=e['res_hist']) for i, e in enumerate(cont['log']) if e.get('res_hist')]
    ER.dump(sdir / 'continuation_failed_newton_history.json', failed_hist)
    summary = {k: cont.get(k) for k in ('reached', 'reason', 'failed_interval', 'det_sign_change', 'high_cond',
                                        'max_cond')}
    if not cont['reached']:
        acc = [e for e in cont['log'] if e.get('det_sign') is not None and not e.get('attempt_failed')]
        GR_last = acc[-1]['G_R'] if acc else None
        summary['last_accepted_G_R'] = GR_last
        if GR_last is not None:
            persist_point_state(sdir / 'points', 'S_last_accepted', model, cont['x'], xT, 'x_T_start', rho, GR_last)
    ER.dump(sdir / 'continuation_result.json', summary)
    return summary


def persist_exception(sdir, tb, rec):
    """Traceback and whatever partial record exists, independent of success."""
    sdir = Path(sdir)
    sdir.mkdir(parents=True, exist_ok=True)
    (sdir / 'exception.txt').write_text(tb, encoding='utf-8')
    p = sdir / 'partial_record.json'
    if not p.exists():
        ER.dump(p, rec)


def write_not_run_records(run, reason, codes=None):
    """Explicit CALISTIRILMADI record (file + stages) for every setting that was not run."""
    codes = list(codes) if codes is not None else [s.code for s in KC.SETTINGS]
    sdir = run.dir / 'settings'
    sdir.mkdir(exist_ok=True)
    st = run.record['stages']
    st.setdefault('not_run', {})
    st.setdefault('settings_records', {})
    for c in codes:
        r = dict(code=c, exec='CALISTIRILMADI', reason=reason, T=None, S=None, status=KC.ST_A)
        p = sdir / f'{c}_kayit.json'
        if not p.exists():
            ER.dump(p, r)
        st['not_run'][c] = reason
        st['settings_records'][c] = dict(exec='CALISTIRILMADI', status=KC.ST_A, reason=reason)
    run.save()


def run_setting(code, model, sdir, rec, raw):
    """`rec` and `raw` are created by the caller and filled progressively, so that a code exception still leaves the
    partial record (and the files already written) available."""
    sdir = Path(sdir)
    pd = sdir / 'points'
    pd.mkdir(parents=True, exist_ok=True)
    disp = EC.Dispatcher(model)
    G_T = KC.G_R_T
    dd = disp.dispatch_E1(G_T)
    persist_dispatch_raw(sdir, dd)
    rec['dispatch'] = dict(ok=dd['ok'], reason=dd['reason'], oned_log=dd['oned_log'], P_akt=dd.get('P_akt'),
                           oned_residual=dd.get('oned_residual'), refine_hist=dd.get('refine_hist'))
    evT = evS = None
    D_T = False
    if not dd['ok']:
        recT = dict(tag='T', D=False, D_reason=dd['reason'], F='F-degerlendirilemez', N=None, alpha=None,
                    note='dispatch basarisiz; mevcut ham alanlar dispatch_raw.json icinde')
        ER.dump(pd / 'T_point.json', recT)
        rec['T'] = dict(D=False, N=None, F='F-degerlendirilemez', D_reason=dd['reason'], alpha=None, e_num=None)
        rec['S_not_run_reason'] = 'T D gecersiz (dagitim)'
        print(f'[{code}] T: dispatch basarisiz: {dd["reason"]}')
    else:
        xT, rho = dd['x'], dd['rho']
        chkT, _ = EC.checks_51a(model, xT, rho, G_T, 'T', disp=dd)
        v1 = EC.V1(model, xT, rho, G_T)
        D_T = bool(chkT['all_applicable_passed'] and v1['passed'])
        if not D_T:
            persist_point_state(pd, 'T', model, xT, dd['x_init'], 'x_init_before_refine', rho, G_T)
        pairT = EC.newton_pair(model, xT, dd['iterates'], rho, G_T)
        evT = ER.evaluate_point(model, xT, rho, G_T, 'T', pairT, D_T, pd, 'T', dd['x_init'], 'x_init_before_refine') \
            if D_T else None
        recT = ER.point_record('T', G_T, rho, D_T, None if D_T else 'E-gecersiz (V1 veya 5.1a)', chkT, evT, v1=v1)
        recT['newton_pair_kind'] = pairT['kind']
        ER.dump(pd / 'T_point.json', recT)
        T = {k: recT.get(k) for k in ('D', 'D_reason', 'Lim', 'N', 'N_parts', 'alpha', 'Mrj', 'F', 'F_reason')}
        T['e_num'] = evT['spec']['e_num']['value'] if evT else None
        if evT:
            T['fyu'] = fyu_flag(evT['spec'], evT['crit_part'])
            T['descriptive'] = descriptives(evT['spec'])
            T['V5'] = recT.get('V5')
        rec['T'] = T
        raw['T'] = dict(x=xT.copy(), rho=rho.copy(), P_akt=dd['P_akt'], D=D_T,
                        lim_values=lim_values(evT['lim']['limits']) if evT else None,
                        labels=({**lim_labels(evT['lim']['limits'], evT['lim']['Lim'], 'T'), **bool51a(chkT, 'T')}
                                if evT else None))
        print(f'[{code}] T: {recT["F_reason"]}')
        if not D_T:
            rec['S_not_run_reason'] = 'T D gecersiz (V1 veya 5.1a)'
        else:
            cont = EC.continuation(model, xT, rho, G_T)
            rec['continuation'] = persist_continuation(sdir, model, rho, xT, cont)
            if cont['reached']:
                xS = cont['x']
                GR_S = cont['log'][-1]['G_R']
                chkS, _ = EC.checks_51a(model, xS, rho, GR_S, 'S')
                D_S = bool(chkS['all_applicable_passed'])
                ln = cont['last_newton']
                ER.dump(sdir / 'S_newton_raw.json', {k: ln.get(k) for k in ('converged', 'criterion', 'stop', 'res',
                                                                             'hist', 'iterates', 'n_iter')})
                if D_S:
                    pairS = EC.newton_pair(model, xS, ln['iterates'], rho, GR_S)
                    evS = ER.evaluate_point(model, xS, rho, GR_S, 'S', pairS, True, pd, 'S', ln['iterates'][0],
                                            'x_newton_start_lambda_1')
                    recS = ER.point_record('S', GR_S, rho, True, None, chkS, evS)
                    recS['newton_pair_kind'] = pairS['kind']
                    raw['S'] = dict(x=xS.copy(), rho=rho.copy(), P_akt=None, D=True,
                                    lim_values=lim_values(evS['lim']['limits']),
                                    labels={**lim_labels(evS['lim']['limits'], evS['lim']['Lim'], 'S'),
                                            **bool51a(chkS, 'S')})
                else:
                    persist_point_state(pd, 'S', model, xS, ln['iterates'][0], 'x_newton_start_lambda_1', rho, GR_S)
                    failed = [kk for kk, v in chkS.items() if isinstance(v, dict) and v.get('applicable')
                              and not v['passed']]
                    recS = ER.point_record('S', GR_S, rho, False, 'E-gecersiz: ' + ', '.join(failed), chkS, None)
                    raw['S'] = dict(x=xS.copy(), rho=rho.copy(), P_akt=None, D=False, lim_values=None, labels=None)
            else:
                recS = dict(tag='S', D=False, D_reason=cont['reason'], F='F-degerlendirilemez',
                            note='D basarisizligi "degerlendirilemez" sonucudur; S notin F degildir (E1 §3.3)')
            ER.dump(pd / 'S_point.json', recS)
            S = {k: recS.get(k) for k in ('D', 'D_reason', 'Lim', 'N', 'N_parts', 'alpha', 'Mrj', 'F', 'F_reason')}
            S['e_num'] = evS['spec']['e_num']['value'] if evS else None
            if evS:
                S['fyu'] = fyu_flag(evS['spec'], evS['crit_part'])
                S['descriptive'] = descriptives(evS['spec'])
                S['V5'] = recS.get('V5')
            rec['S'] = S
            print(f'[{code}] S: D={recS.get("D")} reason={recS.get("D_reason")} F={recS.get("F")}')
    Sstate = dict(D=bool((rec['S'] or {}).get('D')), Lim=(rec['S'] or {}).get('Lim'),
                  N=bool((rec['S'] or {}).get('N')), Mrj=(rec['S'] or {}).get('Mrj'))
    cat = EC.category_71(recT['F'], Sstate)
    eff = EC.effect_72(dict(D=D_T, N=bool(recT.get('N')), alpha=recT.get('alpha'),
                            alpha_raw=evT['spec']['alpha']['raw_max_re'] if evT else None),
                       dict(D=Sstate['D'], N=Sstate['N'], alpha=(rec['S'] or {}).get('alpha'),
                            alpha_raw=evS['spec']['alpha']['raw_max_re'] if evS else None))
    rec['category'] = cat
    rec['effect'] = eff
    rec['effect_decision'] = eff['decision']
    if rec['S'] is not None:
        rec['S']['category_row'] = cat.get('row')
    if evT and evS and evT['crit_part'] and evS['crit_part']:
        pT, pS = evT['crit_part'], evS['crit_part']
        rec['critical_mode_T_vs_S_descriptive'] = dict(
            participation_L1=sum(abs(pT['vector'][s] - pS['vector'][s]) for s in STATE_NAMES),
            group_shares_T=pT['group_shares'], group_shares_S=pS['group_shares'], top2_T=pT['top2'], top2_S=pS['top2'])
    return rec, raw


def load_legacy_e1():
    """Recorded E1 values (E1_20261012_a), manifest-verified in preflight. Returns the schema used by reg_compare."""
    T = json.loads((E1_RUN / 'points' / 'T_point.json').read_text(encoding='utf-8'))
    S = json.loads((E1_RUN / 'points' / 'S_point.json').read_text(encoding='utf-8'))
    cls = json.loads((E1_RUN / 'yurutme_kaydi.json').read_text(encoding='utf-8'))['stages']['classification']

    def states(f):
        rows = list(csv.DictReader(open(E1_RUN / 'points' / f, encoding='utf-8')))
        assert [r['state'] for r in rows] == list(STATE_NAMES)
        return np.array([float(r['x_equilibrium']) for r in rows])

    labels = {}
    for pre, P in (('T', T), ('S', S)):
        for k in ('D', 'N', 'Mrj', 'F', 'Lim'):
            labels[f'{pre}.{k}'] = P.get(k)
        lab = lim_labels(P['limits'], P['Lim'], pre)
        labels.update({k: v for k, v in lab.items() if not k.endswith('.Lim')})
    labels['category_row'] = cls['axis_a_category'].get('row')
    labels['category'] = cls['axis_a_category'].get('category')
    labels['effect_decision'] = cls['axis_c_effect'].get('decision')
    return dict(alpha_T=T['alpha'], alpha_S=S['alpha'], xT=states('T_state.csv'), xS=states('S_state.csv'),
                rho=np.array([T['rho'][k] for k in REF_NAMES]), lim_T=lim_values(T['limits']), lim_S=lim_values(S['limits']),
                labels=labels, state_names=list(STATE_NAMES), ref_names=list(REF_NAMES))


def legacy_record():
    """L0 reference row built from the recorded E1 run (read-only; not re-interpreted)."""
    T = json.loads((E1_RUN / 'points' / 'T_point.json').read_text(encoding='utf-8'))
    S = json.loads((E1_RUN / 'points' / 'S_point.json').read_text(encoding='utf-8'))
    cls = json.loads((E1_RUN / 'yurutme_kaydi.json').read_text(encoding='utf-8'))['stages']['classification']

    def pt(P):
        d = {k: P.get(k) for k in ('D', 'Lim', 'N', 'Mrj', 'F', 'alpha')}
        d['e_num'] = ((P.get('spectral') or {}).get('e_num') or {}).get('value')
        return d
    rec = dict(code='L0', exec='TAMAMLANDI', T=pt(T), S=pt(S), category=cls['axis_a_category'],
               effect=cls['axis_c_effect'], effect_decision=cls['axis_c_effect'].get('decision'),
               source='E1_20261012_a (kayit; yeniden yorumlanmaz)')
    rec['S']['category_row'] = cls['axis_a_category'].get('row')
    return rec


def new_as_reg(rec, raw):
    """Build the reg_compare schema from a fresh L0 pipeline result."""
    labels = {}
    for pre in ('T', 'S'):
        P = rec[pre]
        for k in ('D', 'N', 'Mrj', 'F', 'Lim'):
            labels[f'{pre}.{k}'] = P.get(k)
        lab = (raw[pre] or {}).get('labels') or {}
        labels.update({k: v for k, v in lab.items() if k.startswith(pre + '.L') and not k.endswith('.Lim')})
    labels['category_row'] = rec['category'].get('row')
    labels['category'] = rec['category'].get('category')
    labels['effect_decision'] = rec['effect_decision']
    return dict(alpha_T=rec['T']['alpha'], alpha_S=rec['S']['alpha'], xT=raw['T']['x'], xS=raw['S']['x'], rho=raw['T']['rho'],
                lim_T=raw['T']['lim_values'], lim_S=raw['S']['lim_values'], labels=labels,
                state_names=list(STATE_NAMES), ref_names=list(REF_NAMES))


# ------------------------------------------------------------------------------------------------------------
# gates mode (§4.1-§4.3)
# ------------------------------------------------------------------------------------------------------------
def mode_gates(run, audit_note):
    st = run.record['stages']
    st['audit_note'] = dict(path=str(audit_note), sha256=sha(audit_note))
    t0 = time.time()
    model_L0 = build_model(KC.LEGACY)
    st['model_build_L0_s'] = time.time() - t0
    run.save()
    # G-V0 (global pre-gate): legacy gains, fixed-frequency regression against R-HA-B A3 (E1 §8 V0)
    disp0 = EC.Dispatcher(model_L0)
    gv0 = ER.run_v0(run, model_L0, disp0, sub='G-V0')
    st['G-V0'] = dict(passed=gv0)
    run.save()
    if not gv0:
        st['gates_all_passed'] = False
        write_not_run_records(run, 'CALISTIRILMADI (G-V0 basarisiz)')
        return 'G-V0 GECMEDI: G-REG/G-MAP ve ayarlar calistirilmadi'
    # G-REG: the legacy-gain model reproduces the recorded E1 values (code regression; does not reinterpret L0)
    sdir = run.dir / 'G-REG' / 'L0'
    sdir.mkdir(parents=True)
    rec = dict(code='L0', exec='TAMAMLANDI', T=None, S=None, category=None, effect_decision=None)
    raw = dict(T=None, S=None)
    try:
        run_setting('L0', model_L0, sdir, rec, raw)
    except Exception:
        persist_exception(sdir, traceback.format_exc(), rec)
        st['gates_all_passed'] = False
        write_not_run_records(run, 'CALISTIRILMADI (G-REG: L0 boru hatti istisnasi)')
        raise
    ER.dump(run.dir / 'G-REG' / 'L0_kayit.json', rec)
    st['G-REG_pipeline_status'] = ER.jsonable(dict(T=rec['T'] and rec['T'].get('F'), S=rec['S'] and rec['S'].get('F')))
    if rec['T'] is None or rec['S'] is None or raw['T'] is None or raw['S'] is None or not raw['T'].get('lim_values') \
            or not raw['S'].get('lim_values') or rec['T'].get('alpha') is None or rec['S'].get('alpha') is None:
        st['G-REG'] = dict(passed=False, reason='L0 pipeline T/S eksik; karsilastirma yapilamadi')
        st['gates_all_passed'] = False
        write_not_run_records(run, 'CALISTIRILMADI (G-REG: L0 pipeline eksik)')
        return 'G-REG GECMEDI (L0 pipeline eksik)'
    reg = KC.reg_compare(new_as_reg(rec, raw), load_legacy_e1())
    ER.dump(run.dir / 'G-REG' / 'G-REG_comparison.json', reg)
    st['G-REG'] = dict(passed=reg['passed'], alpha_T_abs_diff=reg['alpha_T_abs_diff'],
                       alpha_S_abs_diff=reg['alpha_S_abs_diff'], labels_ok=reg['labels']['ok'])
    run.save()
    print(f'G-REG: passed={reg["passed"]} |dalpha_T|={reg["alpha_T_abs_diff"]!r} |dalpha_S|={reg["alpha_S_abs_diff"]!r}')
    if not reg['passed']:
        st['gates_all_passed'] = False
        write_not_run_records(run, 'CALISTIRILMADI (G-REG basarisiz)')
        return 'G-REG GECMEDI: G-MAP ve ayarlar calistirilmadi'
    # G-MAP: unit mapping of the models actually built for S1..S4 and 'only kpv, kiv differ' check
    inj, models_ok = {}, True
    base_load, base_gfm, base_net = RB.parameters()
    others = []
    for s in KC.SETTINGS:
        m = build_model(s)
        inj[s.code] = (m.load['kpv'], m.load['kiv'])
        same = all(m.load[k] == v for k, v in base_load.items() if k not in ('kpv', 'kiv')) and \
            m.gfm == base_gfm and m.net == base_net
        others.append(dict(code=s.code, only_kpv_kiv_differ=bool(same)))
        models_ok &= bool(same)
    ok_map, rows = KC.gmap_checks(KC.SETTINGS, inj)
    ER.dump(run.dir / 'G-MAP.json', dict(rows=rows, only_kpv_kiv_differ=others, factor=KC.base_quantities()))
    st['G-MAP'] = dict(passed=bool(ok_map and models_ok))
    print(f'G-MAP: passed={st["G-MAP"]["passed"]}')
    st['gates_all_passed'] = bool(st['G-MAP']['passed'])
    if not st['gates_all_passed']:
        write_not_run_records(run, 'CALISTIRILMADI (G-MAP basarisiz)')
    run.save()
    return 'GATES GECTI' if st['gates_all_passed'] else 'G-MAP GECMEDI'


# ------------------------------------------------------------------------------------------------------------
# settings mode (§1, §4.4, §7)
# ------------------------------------------------------------------------------------------------------------
def verify_gates_run(run_id):
    validate_run_id(run_id)
    d = OUT / run_id
    if d.resolve().parent != OUT.resolve():
        raise ValueError(f'gates run {run_id!r} resolves outside {OUT}')
    rec = json.loads((d / 'yurutme_kaydi.json').read_text(encoding='utf-8'))
    ok = rec.get('mode') == 'gates' and rec.get('stages', {}).get('gates_all_passed') is True
    man = read_manifest(d / 'SHA256SUMS.txt', encoding='utf-8')
    bad = [n for n, h in man.items() if sha(d / n) != h]
    snap_ok = all(sha(d / 'code_snapshot' / f) == sha(HERE / f) for f in E1K_FILES)
    return dict(run_id=run_id, mode=rec.get('mode'), gates_all_passed=rec.get('stages', {}).get('gates_all_passed'),
                manifest_files=len(man), manifest_mismatch=bad, code_snapshot_matches_current_code=snap_ok,
                accepted=bool(ok and not bad and snap_ok), manifest_sha256=sha(d / 'SHA256SUMS.txt'))


def ginv_all(raws, models):
    ref = raws.get('S2')
    out = dict(reference='S2', pairs={}, d_differences=[], not_comparable=[])
    if ref is None or ref['T'] is None or not ref['T'].get('D') or ref['T'].get('lim_values') is None:
        out.update(passed=False, reason='referans ayar S2 icin gecerli T kaydi yok')
        return out
    passed = True
    for code, raw in raws.items():
        if code == 'S2':
            continue
        for pt in ('T', 'S'):
            a, b = ref.get(pt), raw.get(pt)
            if a is None or b is None or not a.get('D') or not b.get('D') or a.get('lim_values') is None \
                    or b.get('lim_values') is None:
                out['not_comparable'].append(f'{code}.{pt}')
                if (a is not None and b is not None) and bool(a.get('D')) != bool(b.get('D')):
                    out['d_differences'].append(f'{code}.{pt}: D {b.get("D")} vs S2 {a.get("D")}')
                continue
            cmp_ = KC.inv_compare(a, b, STATE_NAMES.index(LOAD_ID + ':η'), models['S2']['kiv'], models[code]['kiv'],
                                  state_names=STATE_NAMES)
            out['pairs'][f'{code}.{pt}'] = cmp_
            passed &= cmp_['passed']
    out['passed'] = bool(passed)
    return out


def write_summary(run, recs, hyp, gates_info, ginv):
    fields = ['code', 'kind', 'kpv_pu', 'kiv_pu', 'status', 'T_D', 'T_Lim', 'T_N', 'T_Mrj', 'T_F', 'T_alpha', 'T_e_num',
              'S_D', 'S_Lim', 'S_N', 'S_Mrj', 'S_F', 'S_alpha', 'S_e_num', 'category_row', 'category', 'effect_decision',
              'delta_alpha', 'FYU_T', 'FYU_S']
    with open(run.dir / 'ozet.csv', 'w', newline='', encoding='utf-8') as fh:
        w = csv.writer(fh)
        w.writerow(fields)
        lp = RB.parameters()[0]
        rows = [(s.code, s.kind, KC.pu_gains(s), recs[s.code]) for s in KC.SETTINGS]
        rows.append((KC.LEGACY.code, KC.LEGACY.kind, (lp['kpv'], lp['kiv']), legacy_record()))
        for code, kind, (kp, ki), r in rows:
            T, S = r.get('T') or {}, r.get('S') or {}
            eff = r.get('effect') or {}
            w.writerow([code, kind, ER.num(kp), ER.num(ki), KC.setting_status(r), T.get('D'), T.get('Lim'), T.get('N'),
                        T.get('Mrj'), T.get('F'), '' if T.get('alpha') is None else ER.num(T['alpha']),
                        '' if T.get('e_num') is None else ER.num(T['e_num']), S.get('D'), S.get('Lim'), S.get('N'),
                        S.get('Mrj'), S.get('F'), '' if S.get('alpha') is None else ER.num(S['alpha']),
                        '' if S.get('e_num') is None else ER.num(S['e_num']), S.get('category_row'),
                        (r.get('category') or {}).get('category'), r.get('effect_decision'),
                        '' if eff.get('d_alpha') is None else ER.num(eff['d_alpha']),
                        (T.get('fyu') or {}).get('flag'), (S.get('fyu') or {}).get('flag')])
    ER.dump(run.dir / 'ozet.json', dict(gates=gates_info, G_INV=ginv, hypotheses=hyp,
                                        statuses={**{c: KC.setting_status(r) for c, r in recs.items()},
                                                  'L0': KC.setting_status(legacy_record())},
                                        L0_reference='E1_20261012_a kaydi (yeniden yorumlanmaz); regresyon: gates calismasi',
                                        note='Hicbir sonuc sonraki asamaya otomatik gecis degildir (protokol §8).'))


def mode_settings(run, audit_note, gates_run):
    st = run.record['stages']
    st['audit_note'] = dict(path=str(audit_note), sha256=sha(audit_note))
    gi = verify_gates_run(gates_run)
    st['gates_run'] = gi
    run.save()
    if not gi['accepted']:
        write_not_run_records(run, 'CALISTIRILMADI (gates dogrulamasi basarisiz)')
        return 'GATES KAYDI KABUL EDILMEDI: ayarlar calistirilmadi'
    recs, raws, kivs = {}, {}, {}
    stop = None
    (run.dir / 'settings').mkdir(exist_ok=True)
    st.setdefault('settings_records', {})
    for s in KC.SETTINGS:                                  # fixed order S1, S2, S3, S4
        if stop:
            reason = f'CALISTIRILMADI (kod istisnasi: {stop} ayarinda)'
            recs[s.code] = dict(code=s.code, exec='CALISTIRILMADI', reason=reason, T=None, S=None)
            st.setdefault('not_run', {})[s.code] = reason
        else:
            sdir = run.dir / 'settings' / s.code
            sdir.mkdir(parents=True)
            rec = dict(code=s.code, exec='TAMAMLANDI', T=None, S=None, category=None, effect_decision=None)
            raw = dict(T=None, S=None)
            try:
                t0 = time.time()
                model = build_model(s)
                kivs[s.code] = dict(kpv=model.load['kpv'], kiv=model.load['kiv'])
                rec['gains_pu'] = kivs[s.code]
                run_setting(s.code, model, sdir, rec, raw)
                rec['model_build_and_run_s'] = time.time() - t0
                raws[s.code] = raw
            except Exception:
                tb = traceback.format_exc()
                print(tb)
                persist_exception(sdir, tb, rec)            # traceback + partial record; files already written stay
                rec['exec'] = 'HATA'
                rec['traceback'] = tb
                raws[s.code] = raw
                stop = s.code
            recs[s.code] = rec
        ER.dump(run.dir / 'settings' / f'{s.code}_kayit.json', recs[s.code])
        st['settings_records'][s.code] = dict(exec=recs[s.code]['exec'], status=KC.setting_status(recs[s.code]),
                                              reason=recs[s.code].get('reason'))
        st[s.code] = dict(exec=recs[s.code]['exec'], status=KC.setting_status(recs[s.code]))
        run.save()
    if stop:
        st['G-INV'] = dict(passed=None, reason='CALISTIRILMADI (hata)')
        hyp = dict(yorumlanmaz='kod istisnasi: G-INV ve hipotez karari verilmedi')
        st['hypotheses'] = hyp
        write_summary(run, recs, hyp, gi, st['G-INV'])
        run.save()
        return f'HATA: {stop} ayarinda istisna; kalan ayarlar calistirilmadi (kayit korundu)'
    ginv = ginv_all(raws, {c: kivs[c] for c in kivs})
    ER.dump(run.dir / 'G-INV.json', ginv)
    st['G-INV'] = dict(passed=ginv['passed'], d_differences=ginv['d_differences'], not_comparable=ginv['not_comparable'])
    run.save()
    print(f'G-INV: passed={ginv["passed"]}')
    normal = {c: recs[c] for c in KC.NORMAL}
    if ginv['passed']:
        hyp = dict(H_K0=KC.hk0(normal), H_K1=KC.hk1(normal), H_K2=KC.hk2(normal),
                   S4_stres_ayri='S4 hicbir hipotezin karar kumesine girmez; satiri ozet.csv ve ayar kaydinda ayrica raporlanir')
    else:
        hyp = dict(yorumlanmaz='G-INV basarisiz: siniflandirma "yorumlanmaz" etiketiyle saklandi; hipotez karari verilmedi')
    st['hypotheses'] = hyp
    write_summary(run, recs, hyp, gi, st['G-INV'])
    run.save()
    return 'SETTINGS TAMAM; G-INV ' + ('GECTI' if ginv['passed'] else 'GECMEDI')


# ------------------------------------------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('mode', choices=['static', 'gates', 'settings'])
    ap.add_argument('--run-id')
    ap.add_argument('--audit-note')
    ap.add_argument('--gates-run')
    a = ap.parse_args()
    sys.stdout.reconfigure(encoding='utf-8')
    if a.mode in ('gates', 'settings') and not (a.audit_note and Path(a.audit_note).is_file()):
        print(f'REFUSED: {a.mode} mode requires --audit-note <code-audit note>. Not run before the code audit.')
        return 3
    if a.mode == 'settings' and not a.gates_run:
        print('REFUSED: settings mode requires --gates-run <RUN_ID of a passed gates run>.')
        return 3
    run_id = a.run_id or f'{a.mode.upper()}_{datetime.datetime.now().strftime("%Y%m%d_%H%M%S")}'
    try:
        validate_run_id(run_id)
        if a.mode == 'settings':
            validate_run_id(a.gates_run)
    except ValueError as exc:
        print(f'REFUSED: {exc}')
        return 4
    try:
        run = Run(a.mode, run_id)
    except FileExistsError:
        print(f'REFUSED: out/{run_id} already exists; outputs are never overwritten. Use a new --run-id.')
        return 4
    except ValueError as exc:
        print(f'REFUSED: {exc}')
        return 4
    ok, pre = preflight(check_a3=(a.mode != 'static'), check_e1_files=(a.mode != 'static'))
    run.record['preflight'] = pre
    run.save()
    ll = ER.LOW_LOAD
    if sys.platform == 'win32' and not (ll.get('set_priority_ok') and ll.get('set_affinity_ok')
                                        and ll.get('priority_class') == '0x4000' and ll.get('affinity_mask') == '0xf0000'):
        print('LOW-LOAD PROTOCOL NOT APPLIED: ' + json.dumps(ll))
        if a.mode != 'static':
            write_not_run_records(run, 'CALISTIRILMADI (dusuk yuk protokolu uygulanmadi)')
        run.finish('DUSUK YUK UYGULANMADI: hesap baslatilmadi')
        return 6
    if not ok:
        print(json.dumps(ER.jsonable({k: v for k, v in pre.items() if isinstance(v, dict) and v.get('match') is False}),
                         indent=1, ensure_ascii=False))
        if a.mode != 'static':
            write_not_run_records(run, 'CALISTIRILMADI (on kontrol/hash eslesmesi basarisiz)')
        run.finish('PREFLIGHT BASARISIZ: hesap yapilmadi')
        return 2
    try:
        if a.mode == 'static':
            status = mode_static(run)
        elif a.mode == 'gates':
            status = mode_gates(run, Path(a.audit_note))
        else:
            status = mode_settings(run, Path(a.audit_note), a.gates_run)
    except Exception:
        run.record['exception'] = traceback.format_exc()
        print(run.record['exception'])
        if (a.mode == 'gates' and 'not_run' not in run.record['stages']) or \
                (a.mode == 'settings' and 'settings_records' not in run.record['stages']):
            try:
                write_not_run_records(run, f'CALISTIRILMADI ({a.mode} kipinde kod istisnasi)')
            except Exception:
                run.record['not_run_record_error'] = traceback.format_exc()
        run.finish('HATA: calisma yarida kaldi (kayit korunur)')
        return 1
    run.finish(status)
    bad = ('BASARISIZ', 'GECMEDI', 'KABUL EDILMEDI', 'HATA')
    return 5 if any(b in status for b in bad) else 0


if __name__ == '__main__':
    sys.exit(main())
