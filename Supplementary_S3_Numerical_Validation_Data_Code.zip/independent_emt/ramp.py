"""Fixed, exploratory 0.25 s conductance ramp; no endpoint classification."""
from __future__ import annotations
import json
from pathlib import Path
import sys
import time
import numpy as np
from model import References, Settings
from switching import PWMConfig, simulate

base = Path(__file__).parent
plan = json.loads((base / "ramp_plan.json").read_text(encoding="utf-8"))
case_name = sys.argv[1]
steps = int(sys.argv[2])
duration = float(sys.argv[3]) if len(sys.argv) > 3 else plan["exploratory_duration_s"]
case = plan["cases"][case_name]
assert steps in plan["steps_per_period"]
cal = json.loads((base / f"calibration_{case['calibration_id']}.json").read_text(encoding="utf-8"))
assert abs(cal["g_resistive"] - case["g_initial_pu"]) < 1e-12
refs = cal["references"]
x0 = np.asarray(cal["initial_state_independent_order"], dtype=float)
r = References(*refs["setpoints"], theta_g=refs["theta_g"])
cfg = Settings(**cal["settings"])
def conductance(t: float) -> float:
    return case["g_initial_pu"] - case["dG_pu"] * min(max(t, 0.0) / plan["ramp_duration_s"], 1.0)
stem = f"ramp_{case_name}_{steps}_{duration:g}s"
start = time.perf_counter()
try:
    result = simulate(x0, r, conductance, duration, cfg=cfg, pwm=PWMConfig(steps_per_period=steps))
    trace = np.column_stack([result["time"], result["v_bus2"], result["v_dc"]])
    np.savetxt(base / f"{stem}.csv", trace, fmt="%.12g", delimiter=",",
               header="time_s,v_bus2_pu,v_dc_pu", comments="")
    summary = {
        "status": "completed", "case": case_name, "steps_per_period": steps,
        "duration_s": duration, "wall_s": time.perf_counter() - start,
        "final_conductance_pu": conductance(duration),
        "end_bus2_pu": float(result["v_bus2"][-1]),
        "end_dc_pu": float(result["v_dc"][-1]),
        "peak_modulation": result["max_modulation"].tolist(),
        "saturated_fraction_of_segments": result["saturated_fraction"].tolist(),
        "raw_tail_peak_to_peak_pu": result["raw_tail_max_pu"] - result["raw_tail_min_pu"],
        "switching_crossings": result["switching_crossings"],
        "integrated_energy_residual_pu_seconds": result["integrated_energy_residual_pu_seconds"],
        "endpoint_classified": False,
    }
except Exception as exc:
    summary = {"status": "failed", "case": case_name, "steps_per_period": steps,
               "duration_s": duration, "wall_s": time.perf_counter() - start,
               "error_type": type(exc).__name__, "error": str(exc), "endpoint_classified": False}
(base / f"{stem}.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
print(json.dumps(summary, indent=2))
if summary["status"] != "completed":
    raise SystemExit(1)
