"""Reproducible scientific figure for the classifier boundary artifact."""
from __future__ import annotations
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

base = Path(__file__).parent
case = "F2-0.65-0.20_A_between"
a = np.loadtxt(base / f"average_{case}.csv", delimiter=",", skiprows=1)
t, v = a[:, 0], a[:, 1]
same = np.convolve(v, np.ones(5)/5, mode="same")
edge = np.convolve(np.pad(v, (2, 2), mode="edge"), np.ones(5)/5, mode="valid")
mask = t >= 2.746
fig, ax = plt.subplots(figsize=(8, 3.7), dpi=180)
ax.plot(t[mask], v[mask], label="Raw averaged-model voltage", color="#24627a", lw=1.7)
ax.plot(t[mask], same[mask], "o-", label="Frozen 2-ms filter (zero padding)", color="#ad4f3a", lw=1.4, ms=3)
ax.plot(t[mask], edge[mask], "--", label="Edge-preserving diagnostic", color="#4d7a4c", lw=1.7)
ax.axvline(2.7492, color="#999999", ls=":", lw=0.8)
ax.set(xlabel="Time (s)", ylabel="Bus 2 voltage (pu)",
       title="The frozen end filter creates a false late envelope")
ax.grid(alpha=0.22)
ax.legend(loc="lower left", fontsize=8)
fig.tight_layout()
fig.savefig(base / "classifier_boundary.png")
plt.close(fig)
