"""Evaluate gates that were fixed in ramp_plan.json before running ramp.py."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

base = Path(__file__).parent
plan = json.loads((base / "ramp_plan.json").read_text(encoding="utf-8"))
gates = plan["numeric_gates"]
out = {}
for case_name in plan["cases"]:
    summaries = {}
    traces = {}
    for n in plan["steps_per_period"]:
        stem = f"ramp_{case_name}_{n}_0.5s"
        summaries[n] = json.loads((base / f"{stem}.json").read_text(encoding="utf-8"))
        traces[n] = np.loadtxt(base / f"{stem}.csv", delimiter=",", skiprows=1)
    assert all(s["status"] == "completed" for s in summaries.values())
    assert all(np.array_equal(traces[20][:, 0], traces[n][:, 0]) for n in (40, 80))
    pair = {}
    for n, m in ((20, 40), (40, 80)):
        dv = traces[n][:, 1] - traces[m][:, 1]
        pair[f"{n}_vs_{m}"] = {
            "bus_rmse_pu": float(np.sqrt(np.mean(dv**2))),
            "bus_max_abs_pu": float(np.max(np.abs(dv))),
            "dc_rmse_pu": float(np.sqrt(np.mean((traces[n][:, 2]-traces[m][:, 2])**2))),
        }
    per_run = {str(n): {
        "energy_gate": abs(summaries[n]["integrated_energy_residual_pu_seconds"]) <= gates["energy_residual_abs_pu_seconds_max"],
        "modulation_gate": max(summaries[n]["peak_modulation"]) <= gates["converter_peak_modulation_max"],
        "dc_gate": float(np.min(traces[n][:, 2])) > gates["dc_voltage_min_pu"],
        "sample_clock_error_s": float(np.max(np.abs(traces[n][:, 0] - np.arange(1, len(traces[n])+1)*8/20000))),
    } for n in summaries}
    out[case_name] = {
        "comparisons": pair, "per_run_gates": per_run,
        "convergence_gate": pair["40_vs_80"]["bus_rmse_pu"] <= gates["same_time_bus_rmse_40_vs_80_pu_max"],
    }
(base / "ramp_checks.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
print(json.dumps(out, indent=2))
