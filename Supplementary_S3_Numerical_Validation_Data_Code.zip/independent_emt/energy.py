"""Physical storage and boundary power in the Appendix B per-unit system."""
from __future__ import annotations
import numpy as np
from model import Settings, W_BASE, state_view


def stored_energy(x: np.ndarray, c: Settings) -> float:
    s = state_view(x)
    weighted = (
        c.b_bus * (abs(s["v1"]) ** 2 + abs(s["v2"]) ** 2)
        + c.x_line * abs(s["line_i"]) ** 2
        + c.gfm_lf * abs(s["g_i_c"]) ** 2
        + c.gfm_cf * abs(s["g_v_f"]) ** 2
        + c.gfm_lg * abs(s["g_i_f"]) ** 2
        + c.cpl_lf * abs(s["c_i_c"]) ** 2
        + c.cpl_cf * abs(s["c_v_f"]) ** 2
        + c.cpl_lg * abs(s["c_i_f"]) ** 2
        + c.c_dc * s["v_dc"] ** 2
    )
    return float(weighted / (2 * W_BASE))


def energy_rate(x: np.ndarray, dx: np.ndarray, c: Settings) -> float:
    pairs = [
        (0, c.b_bus), (2, c.b_bus), (4, c.x_line),
        (14, c.gfm_lf), (16, c.gfm_cf), (18, c.gfm_lg),
        (26, c.cpl_lf), (28, c.cpl_cf), (30, c.cpl_lg),
    ]
    acc = sum(weight * (x[k] * dx[k] + x[k + 1] * dx[k + 1]) for k, weight in pairs)
    acc += c.c_dc * x[23] * dx[23]
    return float(acc / W_BASE)


def external_power(x: np.ndarray, c: Settings, g: float,
                   converter_voltages: tuple[complex, complex]) -> float:
    s = state_view(x)
    vg, vc = converter_voltages
    power_in = (vg * s["g_i_c"].conjugate()).real
    resistive = (
        c.gfm_rf * abs(s["g_i_c"]) ** 2 + c.gfm_rg * abs(s["g_i_f"]) ** 2
        + c.r_line * abs(s["line_i"]) ** 2
        + c.cpl_rf * abs(s["c_i_c"]) ** 2 + c.cpl_rg * abs(s["c_i_f"]) ** 2
        + g * abs(s["v2"]) ** 2 + s["v_dc"] ** 2 / c.r_load
    )
    return float(power_in - resistive)
