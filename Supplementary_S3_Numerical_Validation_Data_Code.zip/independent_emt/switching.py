"""Three-phase PWM integration, separate from the archived switching implementation.

Controller samples are held for one period. An explicit RK4 electrical integrator
uses the actual two-level pole voltages in each stage and can halve its step for
convergence checks. No outcome classification is implemented here yet.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
from pathlib import Path
from typing import Callable
import numpy as np
from model import References, Settings, commands, rhs
from energy import stored_energy, external_power
from voltage_mean import IntegralCycleMean


@dataclass(frozen=True)
class PWMConfig:
    f_switch: float = 20_000.0
    steps_per_period: int = 40
    zero_sequence: bool = True


PHASE = np.array([1.0 + 0j, complex(-0.5, -math.sqrt(3) / 2), complex(-0.5, math.sqrt(3) / 2)])


def pole_voltage(command: complex, dc_voltage: float, frame_angle: float, carrier_phase: float,
                 zero_sequence: bool = True) -> tuple[complex, float]:
    if dc_voltage <= 0:
        raise ValueError("DC voltage must be positive")
    stationary = command * complex(math.cos(frame_angle), math.sin(frame_angle))
    refs = np.real(stationary * PHASE)
    if zero_sequence:
        refs = refs - 0.5 * (refs.max() + refs.min())
    modulation = refs / dc_voltage
    peak = float(np.abs(modulation).max())
    triangle = 1.0 - 4.0 * abs((carrier_phase % 1.0) - 0.5)
    legs = np.where(modulation > triangle, dc_voltage, -dc_voltage)
    space = (2.0 / 3.0) * np.dot(legs, PHASE.conjugate())
    common = space * complex(math.cos(frame_angle), -math.sin(frame_angle))
    return common, peak


def _modulation(command: complex, dc_voltage: float, frame_angle: float, zero_sequence: bool) -> np.ndarray:
    stationary = command * complex(math.cos(frame_angle), math.sin(frame_angle))
    phase_ref = np.real(stationary * PHASE)
    if zero_sequence:
        phase_ref -= 0.5 * (phase_ref.max() + phase_ref.min())
    return phase_ref / dc_voltage


def _triangle(phase: float) -> float:
    return 1.0 - 4.0 * abs((phase % 1.0) - 0.5)


def _crossing_fractions(t: float, dt: float, angle: float, angular_rate: float,
                        command: complex, dc_voltage: float, pwm: PWMConfig) -> list[float]:
    """Locate each pole transition within the step by interpolation, not grid rounding."""
    m0 = _modulation(command, dc_voltage, angle, pwm.zero_sequence)
    m1 = _modulation(command, dc_voltage, angle + angular_rate * dt, pwm.zero_sequence)
    c0 = _triangle((t + 1e-14) * pwm.f_switch)
    c1 = _triangle((t + dt - 1e-14) * pwm.f_switch)
    d0, d1 = m0 - c0, m1 - c1
    out = []
    for a, b in zip(d0, d1):
        if a * b < 0:
            frac = float(a / (a - b))
            if 1e-8 < frac < 1 - 1e-8:
                out.append(frac)
    return out


def simulate(x0: np.ndarray, refs: References, conductance: float | Callable[[float], float], seconds: float,
             cfg: Settings = Settings(), pwm: PWMConfig = PWMConfig(),
             record_periods: int = 8, checkpoint_path: Path | None = None,
             checkpoint_tag: str = "", checkpoint_every: float = 0.25,
             resume: bool = False, checkpoint_callback: Callable[[float],None] | None = None) -> dict:
    if seconds <= 0 or record_periods <= 0:
        raise ValueError("positive simulation duration and record interval required")
    dt = 1.0 / (pwm.f_switch * pwm.steps_per_period)
    steps = int(round(seconds / dt))
    x = np.asarray(x0, dtype=float).copy()
    applied = commands(x, refs, cfg)[:2]
    pending = applied
    electrical_angle = 0.0
    time_out, voltage_out, dc_out = [], [], []
    bus_d_out,bus_q_out,angle_out=[],[],[]
    cycle_d_out,cycle_q_out=[],[]
    cycle_mean=IntegralCycleMean(dt,x[2],x[3])
    max_modulation = np.zeros(2)
    saturated_evaluations = np.zeros(2, dtype=int)
    n_evaluations = 0
    crossing_count = 0
    energy_initial = stored_energy(x, cfg)
    integrated_boundary_energy = 0.0
    tail_min = math.inf
    tail_max = -math.inf
    start_step=0
    if checkpoint_path is not None:
        checkpoint_path=Path(checkpoint_path)
        checkpoint_path.parent.mkdir(parents=True,exist_ok=True)
        checkpoint_stride=max(1,int(round(checkpoint_every/dt)))
        if resume and checkpoint_path.exists():
            with np.load(checkpoint_path,allow_pickle=False) as saved:
                if (str(saved["tag"])!=checkpoint_tag or int(saved["steps"])!=steps
                    or float(saved["dt"])!=dt or int(saved["record_periods"])!=record_periods):
                    raise ValueError("checkpoint input fingerprint mismatch")
                start_step=int(saved["next_step"]);x=saved["x"].copy()
                applied=tuple(saved["applied"].tolist());pending=tuple(saved["pending"].tolist())
                electrical_angle=float(saved["electrical_angle"])
                max_modulation=saved["max_modulation"].copy()
                saturated_evaluations=saved["saturated_evaluations"].copy()
                n_evaluations=int(saved["n_evaluations"]);crossing_count=int(saved["crossing_count"])
                energy_initial=float(saved["energy_initial"])
                integrated_boundary_energy=float(saved["integrated_boundary_energy"])
                tail_min=float(saved["tail_min"]);tail_max=float(saved["tail_max"])
                time_out=saved["time_out"].tolist();voltage_out=saved["voltage_out"].tolist()
                dc_out=saved["dc_out"].tolist();bus_d_out=saved["bus_d_out"].tolist()
                bus_q_out=saved["bus_q_out"].tolist();angle_out=saved["angle_out"].tolist()
                cycle_mean.restore(saved)
                if cycle_mean.step!=start_step:raise ValueError("voltage integral checkpoint clock mismatch")
                cycle_d_out=saved["cycle_d_out"].tolist();cycle_q_out=saved["cycle_q_out"].tolist()

    def g_at(t: float) -> float:
        return float(conductance(t)) if callable(conductance) else float(conductance)

    def derivative(t: float, state: np.ndarray, voltages: tuple[complex, complex]):
        dx = rhs(t, state, refs, g_at(t), cfg, voltages)
        w = 1.0 + cfg.gfm_rp * (refs.p - state[6])
        return dx, 2 * math.pi * 60.0 * w

    for k in range(start_step,steps):
        if k and k % pwm.steps_per_period == 0:
            applied = pending
            pending = commands(x, refs, cfg)[:2]
        t = k * dt
        w_start = 1.0 + cfg.gfm_rp * (refs.p - x[6])
        angular_rate = 2 * math.pi * 60.0 * w_start
        bounds = [0.0, 1.0]
        bounds += _crossing_fractions(t, dt, electrical_angle, angular_rate,
                                      applied[0], cfg.gfm_dc, pwm)
        bounds += _crossing_fractions(t, dt, electrical_angle, angular_rate,
                                      applied[1], x[23], pwm)
        bounds = sorted(set(bounds))
        crossing_count += len(bounds) - 2
        d_integral_step=0.0;q_integral_step=0.0
        for lo, hi in zip(bounds[:-1], bounds[1:]):
            h = (hi - lo) * dt
            if h <= 0:
                continue
            mid_t = t + 0.5 * (lo + hi) * dt
            mid_angle = electrical_angle + 0.5 * h * angular_rate
            vg, mg = pole_voltage(applied[0], cfg.gfm_dc, mid_angle,
                                  mid_t * pwm.f_switch, pwm.zero_sequence)
            vc, mc = pole_voltage(applied[1], x[23], mid_angle,
                                  mid_t * pwm.f_switch, pwm.zero_sequence)
            mods = np.array([mg, mc])
            max_modulation[:] = np.maximum(max_modulation, mods)
            saturated_evaluations[:] += mods > 1.0
            n_evaluations += 1
            fixed_voltages = (vg, vc)
            a, wa = derivative(t + lo * dt, x, fixed_voltages)
            xa = x + h * a / 2
            b, wb = derivative(t + lo * dt + h / 2, xa, fixed_voltages)
            xb = x + h * b / 2
            c, wc = derivative(t + lo * dt + h / 2, xb, fixed_voltages)
            xc = x + h * c
            d, wd = derivative(t + hi * dt, xc, fixed_voltages)
            integrated_boundary_energy += h * (
                external_power(x, cfg, g_at(t + lo * dt), fixed_voltages)
                + 2 * external_power(xa, cfg, g_at(t + lo * dt + h / 2), fixed_voltages)
                + 2 * external_power(xb, cfg, g_at(t + lo * dt + h / 2), fixed_voltages)
                + external_power(xc, cfg, g_at(t + hi * dt), fixed_voltages)) / 6
            d_integral_step+=float(h*(x[2]+2*xa[2]+2*xb[2]+xc[2])/6)
            q_integral_step+=float(h*(x[3]+2*xa[3]+2*xb[3]+xc[3])/6)
            x += h * (a + 2 * b + 2 * c + d) / 6
            electrical_angle += h * (wa + 2 * wb + 2 * wc + wd) / 6
            if t + hi * dt >= seconds - 0.02:
                bus = abs(complex(x[2], x[3]))
                tail_min = min(tail_min, bus)
                tail_max = max(tail_max, bus)
        if not np.all(np.isfinite(x)) or x[23] <= 0:
            raise FloatingPointError(f"invalid state at t={t + dt:.7f} s")
        cycle_mean.push(k+1,d_integral_step,q_integral_step)
        # Record at the same physical carrier boundary for every resolution.
        # A k % interval == 0 test instead shifts samples by one varying dt.
        if (k + 1) % (pwm.steps_per_period * record_periods) == 0:
            time_out.append(t + dt)
            voltage_out.append(abs(complex(x[2], x[3])))
            dc_out.append(float(x[23]))
            bus_d_out.append(float(x[2]));bus_q_out.append(float(x[3]));angle_out.append(float(electrical_angle))
            md,mq=cycle_mean.value();cycle_d_out.append(md);cycle_q_out.append(mq)
        if checkpoint_path is not None and ((k+1)%checkpoint_stride==0 or k+1==steps):
            temporary=checkpoint_path.with_name(checkpoint_path.name+".next.npz")
            np.savez_compressed(temporary,tag=checkpoint_tag,steps=steps,dt=dt,record_periods=record_periods,
                next_step=k+1,x=x,applied=np.asarray(applied),pending=np.asarray(pending),
                electrical_angle=electrical_angle,max_modulation=max_modulation,
                saturated_evaluations=saturated_evaluations,n_evaluations=n_evaluations,
                crossing_count=crossing_count,energy_initial=energy_initial,
                integrated_boundary_energy=integrated_boundary_energy,tail_min=tail_min,tail_max=tail_max,
                time_out=np.asarray(time_out),voltage_out=np.asarray(voltage_out),dc_out=np.asarray(dc_out),
                bus_d_out=np.asarray(bus_d_out),bus_q_out=np.asarray(bus_q_out),angle_out=np.asarray(angle_out),
                cycle_d_out=np.asarray(cycle_d_out),cycle_q_out=np.asarray(cycle_q_out),**cycle_mean.snapshot())
            temporary.replace(checkpoint_path)
            if checkpoint_callback is not None:checkpoint_callback((k+1)*dt)
    return {
        "time": np.asarray(time_out), "v_bus2": np.asarray(voltage_out),
        "v_dc": np.asarray(dc_out), "final_state": x,
        "v_bus2_d":np.asarray(bus_d_out),"v_bus2_q":np.asarray(bus_q_out),
        "electrical_angle":np.asarray(angle_out),
        "v_bus2_d_cycle_mean":np.asarray(cycle_d_out),"v_bus2_q_cycle_mean":np.asarray(cycle_q_out),
        "max_modulation": max_modulation,
        "saturated_fraction": saturated_evaluations / max(n_evaluations, 1),
        "n_rhs": n_evaluations,
        "switching_crossings": crossing_count,
        "subsegments": n_evaluations,
        "raw_tail_min_pu": tail_min,
        "raw_tail_max_pu": tail_max,
        "stored_energy_initial_pu_seconds": energy_initial,
        "stored_energy_final_pu_seconds": stored_energy(x, cfg),
        "integrated_boundary_energy_pu_seconds": integrated_boundary_energy,
        "integrated_energy_residual_pu_seconds": stored_energy(x, cfg) - energy_initial - integrated_boundary_energy,
    }
