"""No-shedding numerical convergence pilot; not an outcome study."""
from __future__ import annotations
import json
from pathlib import Path
import sys
import time
import numpy as np
from model import References, Settings
from switching import PWMConfig, simulate

steps = int(sys.argv[1])
duration = float(sys.argv[2]) if len(sys.argv) > 2 else 0.1
case_id = sys.argv[3] if len(sys.argv) > 3 else "F2-0.65-0.20"
base = Path(__file__).parent
stem = f"pilot_{case_id}_{steps}" + ("" if duration == 0.1 else f"_{duration:g}s")
cal = json.loads((base / f"calibration_{case_id}.json").read_text(encoding="utf-8"))
refs = cal["references"]
x = np.asarray(cal["initial_state_independent_order"], dtype=float)
r = References(*refs["setpoints"], theta_g=refs["theta_g"])
start = time.perf_counter()
result = simulate(x, r, cal["g_resistive"], duration,
                  cfg=Settings(**cal["settings"]), pwm=PWMConfig(steps_per_period=steps))
trace = np.column_stack([result["time"], result["v_bus2"], result["v_dc"]])
np.savetxt(base / f"{stem}.csv", trace, fmt="%.12g", delimiter=",", header="time_s,v_bus2_pu,v_dc_pu", comments="")
tail = result["time"] >= duration - 0.02
summary = {
    "run_type": "no_shedding_numerical_pilot", "case_id": case_id, "duration_s": duration,
    "steps_per_switching_period": steps,
    "dt_s": 1.0 / (20_000 * steps),
    "wall_s": time.perf_counter() - start,
    "initial_bus2_pu": float(abs(complex(x[2], x[3]))),
    "end_bus2_pu": float(result["v_bus2"][-1]),
    "tail_bus2_mean_pu": float(result["v_bus2"][tail].mean()),
    "tail_bus2_min_pu": float(result["v_bus2"][tail].min()),
    "tail_bus2_max_pu": float(result["v_bus2"][tail].max()),
    "end_dc_pu": float(result["v_dc"][-1]),
    "peak_modulation": result["max_modulation"].tolist(),
    "saturated_fraction": result["saturated_fraction"].tolist(),
    "switching_crossings": result["switching_crossings"],
    "subsegments": result["subsegments"],
    "raw_tail_min_pu": result["raw_tail_min_pu"],
    "raw_tail_max_pu": result["raw_tail_max_pu"],
    "raw_tail_peak_to_peak_pu": result["raw_tail_max_pu"] - result["raw_tail_min_pu"],
    "stored_energy_initial_pu_seconds": result["stored_energy_initial_pu_seconds"],
    "stored_energy_final_pu_seconds": result["stored_energy_final_pu_seconds"],
    "integrated_boundary_energy_pu_seconds": result["integrated_boundary_energy_pu_seconds"],
    "integrated_energy_residual_pu_seconds": result["integrated_energy_residual_pu_seconds"],
}
(base / f"{stem}.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
print(json.dumps(summary, indent=2))
