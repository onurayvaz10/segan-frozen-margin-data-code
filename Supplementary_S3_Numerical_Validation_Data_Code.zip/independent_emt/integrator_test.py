"""Separate smooth-ODE RK4 test to isolate PWM-event error."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
from model import References, Settings, rhs

base = Path(__file__).parent
out = {}
for case_id in ("F2-0.65-0.20", "A2-F00993"):
    cal = json.loads((base / f"calibration_{case_id}.json").read_text(encoding="utf-8"))
    refs = cal["references"]
    r = References(*refs["setpoints"], theta_g=refs["theta_g"])
    cfg = Settings(**cal["settings"])
    x0 = np.asarray(cal["initial_state_independent_order"], dtype=float)
    x0[2] -= 0.001
    x0[23] += 0.0002
    g = cal["g_resistive"]
    f = lambda t, x: rhs(t, x, r, g, cfg)
    duration = 0.01
    reference = solve_ivp(f, (0, duration), x0, method="Radau", t_eval=[duration],
                          rtol=1e-12, atol=1e-13, max_step=1e-5)
    if not reference.success:
        raise RuntimeError(reference.message)
    rows = {}
    for n in (20, 40, 80):
        h = 1 / (20_000 * n)
        x = x0.copy()
        for k in range(int(round(duration / h))):
            t = k * h
            a = f(t, x)
            b = f(t+h/2, x+h*a/2)
            c = f(t+h/2, x+h*b/2)
            d = f(t+h, x+h*c)
            x += h * (a+2*b+2*c+d)/6
        err = x-reference.y[:, -1]
        rows[str(n)] = {"full_state_max_abs_pu": float(np.max(np.abs(err))),
                        "bus_voltage_abs_pu": float(abs(abs(complex(x[2], x[3]))-abs(complex(reference.y[2,-1],reference.y[3,-1]))))}
    out[case_id] = {"reference_method": "Radau", "rtol": 1e-12, "atol": 1e-13,
                    "perturbation": {"bus2_real_pu": -0.001, "dc_pu": 0.0002},
                    "duration_s": duration, "errors": rows}
(base / "integrator_test.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
print(json.dumps(out, indent=2))
