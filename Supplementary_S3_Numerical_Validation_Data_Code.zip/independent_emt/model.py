"""Independent two-bus GFM/active-rectifier model transcribed from S2 Appendix B.

This module deliberately imports none of the authors' solver or EMT code. All
electrical states are complex vectors in the common droop frame; the 32 real
states are arranged by physical subsystem rather than by the source layout.
The code is a verification scaffold, not a validated EMT result.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
import numpy as np

W_BASE = 2 * math.pi * 60.0
V_BASE = 380.0
S_BASE = 10_000.0
I_BASE = S_BASE / V_BASE
Z_BASE = V_BASE / I_BASE
L_BASE = Z_BASE / W_BASE
C_BASE = 1.0 / (Z_BASE * W_BASE)
VDC_BASE = math.sqrt(8.0 / 3.0) * V_BASE
IDC_BASE = S_BASE / VDC_BASE
ZDC_BASE = VDC_BASE / IDC_BASE
CDC_BASE = 1.0 / (ZDC_BASE * W_BASE)


@dataclass(frozen=True)
class Settings:
    r_line: float = 0.01
    x_line: float = 0.1
    b_bus: float = 0.005
    r_load: float = 70.0 / ZDC_BASE
    c_dc: float = 2040e-6 / CDC_BASE
    gfm_dc: float = 690.0 / VDC_BASE
    gfm_rp: float = 0.02
    gfm_kq: float = 0.05
    gfm_w_p: float = 2 * math.pi * 20
    gfm_w_q: float = 2 * math.pi * 20
    gfm_rv: float = 0.0
    gfm_lv: float = 0.2
    gfm_kpv: float = 0.59
    gfm_kiv: float = 736.0
    gfm_kpc: float = 1.27
    gfm_kic: float = 14.3
    gfm_w_ad: float = 50.0
    gfm_k_ad: float = 0.2
    gfm_lf: float = 0.08
    gfm_rf: float = 0.003
    gfm_cf: float = 0.074
    gfm_lg: float = 0.2
    gfm_rg: float = 0.01
    cpl_lf: float = 2.3e-3 / L_BASE
    cpl_rf: float = 0.1 / Z_BASE
    cpl_cf: float = 8.8e-6 / C_BASE
    cpl_lg: float = 0.93e-3 / L_BASE
    cpl_rg: float = 0.03 / Z_BASE
    cpl_kpc: float = 15.0 / Z_BASE
    cpl_kic: float = 30_000.0 / Z_BASE
    cpl_kp_pll: float = 0.4
    cpl_ki_pll: float = 4.69
    cpl_kpv: float = 2.0 * VDC_BASE / I_BASE
    cpl_kiv: float = 600.0 * VDC_BASE / I_BASE


@dataclass(frozen=True)
class References:
    p: float
    q: float
    v: float
    vdc: float
    iq: float
    theta_g: float = 0.0


def _c(x: np.ndarray, k: int) -> complex:
    return complex(x[k], x[k + 1])


def _put(d: np.ndarray, k: int, v: complex) -> None:
    d[k], d[k + 1] = v.real, v.imag


def state_view(x: np.ndarray) -> dict[str, complex | float]:
    if x.shape != (32,):
        raise ValueError("expected 32 physical states")
    return {
        "v1": _c(x, 0), "v2": _c(x, 2), "line_i": _c(x, 4),
        "p_m": x[6], "q_m": x[7], "g_v_int": _c(x, 8),
        "g_i_int": _c(x, 10), "g_damp": _c(x, 12),
        "g_i_c": _c(x, 14), "g_v_f": _c(x, 16), "g_i_f": _c(x, 18),
        "pll_theta": x[20], "pll_int": x[21], "dc_int": x[22],
        "v_dc": x[23], "c_i_int": _c(x, 24), "c_i_c": _c(x, 26),
        "c_v_f": _c(x, 28), "c_i_f": _c(x, 30),
    }


def commands(x: np.ndarray, refs: References, cfg: Settings = Settings()) -> tuple[complex, complex, float, float]:
    """Continuous controller voltage commands in the common frame."""
    s = state_view(x)
    w = 1.0 + cfg.gfm_rp * (refs.p - s["p_m"])
    g_local = complex(math.cos(refs.theta_g), -math.sin(refs.theta_g))
    g_if = s["g_i_f"] * g_local
    g_vf = s["g_v_f"] * g_local
    g_ic = s["g_i_c"] * g_local
    v_target = refs.v + cfg.gfm_kq * (refs.q - s["q_m"])
    v_target = v_target - (cfg.gfm_rv + 1j * w * cfg.gfm_lv) * g_if
    i_target = (cfg.gfm_kpv * (v_target - g_vf)
                + cfg.gfm_kiv * s["g_v_int"] + 1j * w * cfg.gfm_cf * g_vf)
    v_g_local = (cfg.gfm_kpc * (i_target - g_ic) + cfg.gfm_kic * s["g_i_int"]
           + 1j * w * cfg.gfm_lf * g_ic
           - cfg.gfm_k_ad * (g_vf - s["g_damp"]))
    v_g = v_g_local * g_local.conjugate()
    local = complex(math.cos(s["pll_theta"]), -math.sin(s["pll_theta"]))
    vq = (s["c_v_f"] * local).imag
    dw = cfg.cpl_kp_pll * vq + cfg.cpl_ki_pll * s["pll_int"]
    local_i = s["c_i_c"] * local
    i_ref = complex(cfg.cpl_kpv * (refs.vdc - s["v_dc"]) + cfg.cpl_kiv * s["dc_int"], refs.iq)
    v_c_local = cfg.cpl_kpc * (local_i - i_ref) + cfg.cpl_kic * s["c_i_int"] - 1j * (1.0 + dw) * cfg.cpl_lf * local_i
    v_c = v_c_local * local.conjugate()
    return v_g, v_c, w, dw


def rhs(t: float, x: np.ndarray, refs: References, g_resistive: float,
        cfg: Settings = Settings(), converter_voltages: tuple[complex, complex] | None = None) -> np.ndarray:
    """Physical ODE in seconds; override converter voltages for switching EMT."""
    s = state_view(x)
    v_g_cmd, v_c_cmd, w, dw = commands(x, refs, cfg)
    v_g, v_c = converter_voltages if converter_voltages is not None else (v_g_cmd, v_c_cmd)
    d = np.zeros(32)
    # GFM droop, PI loops, and LCL, from S2 B.1.
    p_q = s["g_v_f"] * s["g_i_f"].conjugate()
    d[6] = cfg.gfm_w_p * (p_q.real - s["p_m"])
    d[7] = cfg.gfm_w_q * (p_q.imag - s["q_m"])
    g_local = complex(math.cos(refs.theta_g), -math.sin(refs.theta_g))
    g_if = s["g_i_f"] * g_local
    g_vf = s["g_v_f"] * g_local
    g_ic = s["g_i_c"] * g_local
    v_target = refs.v + cfg.gfm_kq * (refs.q - s["q_m"])
    v_target = v_target - (cfg.gfm_rv + 1j * w * cfg.gfm_lv) * g_if
    e_v = v_target - g_vf
    i_target = cfg.gfm_kpv * e_v + cfg.gfm_kiv * s["g_v_int"] + 1j * w * cfg.gfm_cf * g_vf
    _put(d, 8, e_v)
    _put(d, 10, i_target - g_ic)
    _put(d, 12, cfg.gfm_w_ad * (g_vf - s["g_damp"]))
    _put(d, 14, W_BASE / cfg.gfm_lf * (v_g - s["g_v_f"] - (cfg.gfm_rf + 1j * w * cfg.gfm_lf) * s["g_i_c"]))
    _put(d, 16, W_BASE / cfg.gfm_cf * (s["g_i_c"] - s["g_i_f"] - 1j * w * cfg.gfm_cf * s["g_v_f"]))
    _put(d, 18, W_BASE / cfg.gfm_lg * (s["g_v_f"] - s["v1"] - (cfg.gfm_rg + 1j * w * cfg.gfm_lg) * s["g_i_f"]))
    # Active rectifier, DC link and LCL.
    local = complex(math.cos(s["pll_theta"]), -math.sin(s["pll_theta"]))
    vq = (s["c_v_f"] * local).imag
    d[20] = W_BASE * (1.0 + dw - w)
    d[21] = vq
    d[22] = refs.vdc - s["v_dc"]
    dc_current_ref = cfg.cpl_kpv * (refs.vdc - s["v_dc"]) + cfg.cpl_kiv * s["dc_int"]
    _put(d, 24, s["c_i_c"] * local - complex(dc_current_ref, refs.iq))
    if s["v_dc"] <= 0:
        raise ValueError("DC link voltage is nonpositive")
    p_dc = (v_c * s["c_i_c"].conjugate()).real
    d[23] = W_BASE / cfg.c_dc * (p_dc / s["v_dc"] - s["v_dc"] / cfg.r_load)
    _put(d, 26, W_BASE / cfg.cpl_lf * (s["c_v_f"] - v_c - (cfg.cpl_rf + 1j * w * cfg.cpl_lf) * s["c_i_c"]))
    _put(d, 28, W_BASE / cfg.cpl_cf * (s["c_i_f"] - s["c_i_c"] - 1j * w * cfg.cpl_cf * s["c_v_f"]))
    _put(d, 30, W_BASE / cfg.cpl_lg * (s["v2"] - s["c_v_f"] - (cfg.cpl_rg + 1j * w * cfg.cpl_lg) * s["c_i_f"]))
    # Dynamic pi line and capacitor-shunt bus balances.
    _put(d, 4, W_BASE / cfg.x_line * (s["v1"] - s["v2"] - (cfg.r_line + 1j * w * cfg.x_line) * s["line_i"]))
    _put(d, 0, W_BASE / cfg.b_bus * (s["g_i_f"] - s["line_i"] - 1j * w * cfg.b_bus * s["v1"]))
    _put(d, 2, W_BASE / cfg.b_bus * (s["line_i"] - s["c_i_f"] - (g_resistive + 1j * w * cfg.b_bus) * s["v2"]))
    return d
