"""Analytic two-level PWM checks with constant commands and DC bus."""
from __future__ import annotations
import json
import math
from pathlib import Path
import numpy as np
from switching import PHASE, _modulation, pole_voltage


def analytic_cycle(command: complex, dc: float, angle: float) -> tuple[complex, int]:
    mods = _modulation(command, dc, angle, True)
    if np.max(np.abs(mods)) >= 1:
        raise ValueError("analytic linear-modulation test requires no clipping")
    crossings = sorted({0.0, 1.0} | {(float(m) + 1) / 4 for m in mods}
                       | {(3 - float(m)) / 4 for m in mods})
    mean = 0j
    for a, b in zip(crossings[:-1], crossings[1:]):
        v, _ = pole_voltage(command, dc, angle, (a + b) / 2)
        mean += (b - a) * v
    return mean, len(crossings) - 2


def main() -> None:
    rng = np.random.default_rng(20261028)
    errors = []
    counts = []
    for _ in range(100):
        dc = float(rng.uniform(0.8, 1.3))
        angle = float(rng.uniform(-math.pi, math.pi))
        magnitude = float(rng.uniform(0.02, 0.8 * dc))
        cmd = magnitude * complex(math.cos(angle), math.sin(angle))
        mean, crossings = analytic_cycle(cmd, dc, angle)
        errors.append(abs(mean - cmd))
        counts.append(crossings)
    result = {"cases": len(errors), "max_average_voltage_error_pu": max(errors),
              "crossing_counts": sorted(set(counts)),
              "pass": max(errors) < 1e-12 and set(counts) == {6}}
    Path(__file__).with_name("pwm_tests.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))
    if not result["pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
