"""One-cycle dq mean from integrated voltages, with equilibrium prehistory."""
import math
import numpy as np


class IntegralCycleMean:
    def __init__(self, dt, initial_d, initial_q, window=1/60):
        self.dt=float(dt);self.window=float(window)
        self.initial_d=float(initial_d);self.initial_q=float(initial_q)
        self.n=math.ceil(self.window/self.dt)+2
        self.ring_d=np.zeros(self.n);self.ring_q=np.zeros(self.n)
        self.integral_d=0.0;self.integral_q=0.0;self.step=0

    def push(self, step, integral_d_increment, integral_q_increment):
        if step!=self.step+1:raise ValueError("nonconsecutive voltage-integral step")
        self.integral_d+=integral_d_increment;self.integral_q+=integral_q_increment
        self.ring_d[step%self.n]=self.integral_d;self.ring_q[step%self.n]=self.integral_q
        self.step=step

    def value(self):
        past=self.step-self.window/self.dt
        if past<0:
            d=self.initial_d*past*self.dt;q=self.initial_q*past*self.dt
        else:
            left=math.floor(past);fraction=past-left
            d=(1-fraction)*self.ring_d[left%self.n]+fraction*self.ring_d[(left+1)%self.n]
            q=(1-fraction)*self.ring_q[left%self.n]+fraction*self.ring_q[(left+1)%self.n]
        return (self.integral_d-d)/self.window,(self.integral_q-q)/self.window

    def snapshot(self):
        return {"cycle_step":self.step,"cycle_integral_d":self.integral_d,"cycle_integral_q":self.integral_q,
                "cycle_ring_d":self.ring_d,"cycle_ring_q":self.ring_q,
                "cycle_initial_d":self.initial_d,"cycle_initial_q":self.initial_q}

    def restore(self, state):
        self.step=int(state["cycle_step"])
        self.integral_d=float(state["cycle_integral_d"]);self.integral_q=float(state["cycle_integral_q"])
        self.ring_d=state["cycle_ring_d"].copy();self.ring_q=state["cycle_ring_q"].copy()
        self.initial_d=float(state["cycle_initial_d"]);self.initial_q=float(state["cycle_initial_q"])
        if len(self.ring_d)!=self.n or len(self.ring_q)!=self.n:raise ValueError("voltage integral ring size mismatch")
