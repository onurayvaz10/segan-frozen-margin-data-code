param(
    [Parameter(Mandatory=$true)][ValidateSet('build','audit','baseline','ramp')][string]$Operation,
    [Parameter(Mandatory=$true)][ValidateSet('F2-0.65-0.20','A2-F00993','F2-0.60-0.20')][string]$Case,
    [Parameter(Mandatory=$true)][ValidateSet('0.25','0.125','0.0625','0.05','0.025')][string]$StepUs
)
$ErrorActionPreference='Stop'
$experimentPath=Split-Path -Parent $PSScriptRoot
$runDirectory=Join-Path $experimentPath 'guarded_native_runs'
New-Item -ItemType Directory -Path $runDirectory -Force | Out-Null
$stamp=Get-Date -Format 'yyyyMMdd_HHmmss'
$name=$Case+'_'+$Operation+'_'+$StepUs.Replace('.','p')+'us_'+$stamp
$runStart=Get-Date
$env:TYPHOONPATH='C:\Program Files\Typhoon HIL Control Center 2026.3'
$env:PATH=(Join-Path $env:TYPHOONPATH 'compilers\windows\vhil\gcc\bin')+';'+$env:PATH
$env:OPENBLAS_NUM_THREADS='1'
$env:OMP_NUM_THREADS='1'
$env:SEGAN_STOP_FILE=Join-Path $runDirectory ($name+'.stop')
$nativePython=Join-Path $env:TYPHOONPATH 'python3_portable\python.exe'
switch ($Operation) {
    'build' {$script='build_plant.py'; $extra=' --drive closed'}
    'audit' {$script='audit_model.py'; $extra=''}
    default {$script='run_validation.py';$extra=' --scenario '+$Operation}
}
$arguments='"'+(Join-Path $experimentPath $script)+'" --case '+$Case+' --step-us '+$StepUs+$extra
$runProcess=Start-Process -FilePath $nativePython -ArgumentList $arguments -PassThru -WindowStyle Hidden -RedirectStandardOutput (Join-Path $runDirectory ($name+'_stdout.txt')) -RedirectStandardError (Join-Path $runDirectory ($name+'_stderr.txt'))
$observations=@()
$stopReason='completed'
while (-not $runProcess.HasExited) {
    Start-Sleep -Seconds 5
    $runProcess.Refresh()
    $newEvents=@(Get-WinEvent -FilterHashtable @{LogName='System';ProviderName='Microsoft-Windows-WHEA-Logger';StartTime=$runStart} -ErrorAction SilentlyContinue)
    $observations += [pscustomobject]@{time=(Get-Date).ToString('o');new_whea_count=$newEvents.Count;cpu_seconds=$runProcess.TotalProcessorTime.TotalSeconds}
    if ($newEvents.Count -gt 0 -or ((Get-Date)-$runStart).TotalSeconds -gt 1040) {
        $stopReason=if ($newEvents.Count -gt 0) {'new_whea_stop'} else {'wall_time_limit_stop'}
        $stopReason | Set-Content -LiteralPath $env:SEGAN_STOP_FILE -Encoding utf8
        if ($newEvents.Count -gt 0) {
            $newEvents | ForEach-Object {[pscustomobject]@{time=$_.TimeCreated.ToString('o');id=$_.Id;message=$_.Message;xml=$_.ToXml()}} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $runDirectory ($name+'_new_whea.json')) -Encoding utf8
        }
        if (-not $runProcess.WaitForExit(8000)) {
            Stop-Process -Id $runProcess.Id
            if ($Operation -in @('baseline','ramp')) {
                $cleanup=Start-Process -FilePath $nativePython -ArgumentList '-c "import typhoon.api.hil as h; h.stop_simulation()"' -PassThru -WindowStyle Hidden
                if (-not $cleanup.WaitForExit(10000)) {Stop-Process -Id $cleanup.Id}
            }
        }
        break
    }
}
$runProcess.WaitForExit()
$result=[pscustomobject]@{operation=$Operation;case=$Case;step_us=$StepUs;start=$runStart.ToString('o');end=(Get-Date).ToString('o');stop_reason=$stopReason;exit_code=$runProcess.ExitCode;observations=$observations}
$result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $runDirectory ($name+'_guard.json')) -Encoding utf8
$result | Select-Object operation,case,step_us,start,end,stop_reason,exit_code | ConvertTo-Json
if ($stopReason -ne 'completed' -or $runProcess.ExitCode -ne 0) {exit 1}
exit 0
