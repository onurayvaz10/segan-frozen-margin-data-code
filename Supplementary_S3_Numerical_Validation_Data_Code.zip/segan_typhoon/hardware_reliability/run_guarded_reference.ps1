param(
    [Parameter(Mandatory=$true)][ValidateSet('F2-0.65-0.20','A2-F00993','F2-0.60-0.20')][string]$Case,
    [ValidateSet('independent_reference_balanced','independent_reference_integral')][string]$OutputLabel='independent_reference_integral'
)
$ErrorActionPreference = 'Stop'
$diagnosticPath = $PSScriptRoot
$experimentPath = Split-Path -Parent $diagnosticPath
$referencePath = Join-Path $experimentPath $OutputLabel
New-Item -ItemType Directory -Path $referencePath -Force | Out-Null
$runStart = Get-Date
$env:OPENBLAS_NUM_THREADS = '1'
$env:OMP_NUM_THREADS = '1'
$probeExe = 'C:\Users\onura\AppData\Local\Programs\Python\Python313\python.exe'
$arguments = '"' + (Join-Path $experimentPath 'reference_capture.py') + '" --case ' + $Case + ' --scenario ramp --fresh --output-dir "' + $referencePath + '"'
if ($Case -eq 'F2-0.60-0.20') {$arguments+=' --freeze-new-case'}
$runProcess = Start-Process -FilePath $probeExe -ArgumentList $arguments -PassThru -WindowStyle Hidden -RedirectStandardOutput (Join-Path $referencePath ($Case+'_stdout.txt')) -RedirectStandardError (Join-Path $referencePath ($Case+'_stderr.txt'))
$observations = @()
$stopReason = 'completed'
while (-not $runProcess.HasExited) {
    Start-Sleep -Seconds 5
    $runProcess.Refresh()
    $newEvents = @(Get-WinEvent -FilterHashtable @{LogName='System';ProviderName='Microsoft-Windows-WHEA-Logger';StartTime=$runStart} -ErrorAction SilentlyContinue)
    $observations += [pscustomobject]@{time=(Get-Date).ToString('o');elapsed_seconds=((Get-Date)-$runStart).TotalSeconds;new_whea_count=$newEvents.Count;cpu_seconds=$runProcess.TotalProcessorTime.TotalSeconds}
    if ($newEvents.Count -gt 0) {
        $stopReason = 'new_whea_stop'
        $newEvents | ForEach-Object {[pscustomobject]@{time=$_.TimeCreated.ToString('o');id=$_.Id;message=$_.Message;xml=$_.ToXml()}} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $referencePath ($Case+'_new_whea.json')) -Encoding utf8
        if (-not $runProcess.HasExited) {Stop-Process -Id $runProcess.Id}
        break
    }
    if (((Get-Date)-$runStart).TotalSeconds -gt 1500) {
        $stopReason = 'wall_time_limit_stop'
        if (-not $runProcess.HasExited) {Stop-Process -Id $runProcess.Id}
        break
    }
}
$runProcess.WaitForExit()
$result = [pscustomobject]@{start=$runStart.ToString('o');end=(Get-Date).ToString('o');stop_reason=$stopReason;exit_code=$runProcess.ExitCode;observations=$observations;windows_power_scheme=(powercfg /getactivescheme | Out-String).Trim();oem_profile='Office observed before guarded calculations'}
$result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $referencePath ($Case+'_guard.json')) -Encoding utf8
$result | Select-Object start,end,stop_reason,exit_code | ConvertTo-Json
if ($stopReason -ne 'completed' -or $runProcess.ExitCode -ne 0) {exit 1}
exit 0
