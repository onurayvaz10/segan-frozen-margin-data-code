"""Plot full-duration quantitative comparisons; numerical gates stay in JSON."""
from pathlib import Path
import argparse
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
HERE=Path(__file__).resolve().parent
ap=argparse.ArgumentParser()
ap.add_argument("--case",required=True,choices=("F2-0.65-0.20","A2-F00993","F2-0.60-0.20"))
args=ap.parse_args()
directory=HERE/"comparison_results"
summary=json.loads((directory/f"{args.case}.json").read_text())
a=np.load(directory/f"{args.case}_aligned.npz")
t=a["time_s"]
if t[-1]<2.749:raise ValueError("Refusing to plot an incomplete trajectory as a full experiment")
fig,ax=plt.subplots(3,1,figsize=(7.2,7.4),sharex=True,layout="constrained")
fine=summary["fine_step_us"];coarse=summary["coarse_step_us"]
ax[0].plot(t,a["reference_bus"],color="#202b33",lw=1.25,label="Independent event-aware PWM, 80 substeps")
ax[0].plot(t,a["virtual_hil_bus"],color="#186c9c",lw=0.9,label=f"Actual Virtual HIL, {fine:g} us")
ax[0].plot(t,a["coarse_bus"],color="#9d6252",lw=0.8,alpha=.8,label=f"Actual Virtual HIL, {coarse:g} us")
ax[0].set_ylabel("Bus 2 voltage (pu)\n1-cycle mean dq magnitude")
ax[0].legend(fontsize=8,loc="best")
ax[1].plot(t,a["reference_dc"],color="#202b33",lw=1.25,label="Independent PWM")
ax[1].plot(t,a["virtual_hil_dc"],color="#186c9c",lw=.9,label="Virtual HIL")
ax[1].set_ylabel("DC voltage (pu)")
ax[1].ticklabel_format(axis="y",style="plain",useOffset=False)
ax[2].plot(t,a["virtual_hil_bus"]-a["reference_bus"],color="#186c9c",lw=.8,label="Virtual HIL - independent PWM")
ax[2].plot(t,a["virtual_hil_bus"]-a["coarse_bus"],color="#9d6252",lw=.8,label="Fine - coarse Virtual HIL")
ax[2].set_ylabel("Bus voltage difference (pu)")
ax[2].set_xlabel("Simulation time (s)")
ax[2].legend(fontsize=8,loc="best")
for axis in ax:
    axis.axvline(.25,color="#78868c",ls=":",lw=.8)
    axis.grid(alpha=.22)
    axis.set_xlim(0,2.75)
    axis.tick_params(labelsize=8)
title=f"{args.case}: offline software simulation, no hardware HIL"
fig.suptitle(title,fontsize=11)
fig.savefig(directory/f"{args.case}_comparison.png",dpi=300)
fig.savefig(directory/f"{args.case}_comparison.svg")
version=f"{args.case}_dt{str(fine).replace('.','p')}_vs_{str(coarse).replace('.','p')}us"
fig.savefig(directory/f"{version}_comparison.png",dpi=300)
fig.savefig(directory/f"{version}_comparison.svg")
plt.close(fig)
print(json.dumps({"case":args.case,"all_numeric_gates_passed":summary["all_numeric_gates_passed"],
                  "step_refinement_rmse_pu":summary["step_refinement_bus_rmse_pu"],
                  "dynamic_bus_rmse_pu":summary["dynamic_bus_rmse_pu"],
                  "dynamic_dc_rmse_pu":summary["dynamic_dc_rmse_pu"]},indent=2))
