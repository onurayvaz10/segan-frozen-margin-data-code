"""Record the unchanged independent PWM solver every 50 us for RMS filtering."""
from pathlib import Path
import argparse
import hashlib
import faulthandler
import json
import sys
import time
from datetime import datetime
import numpy as np

HERE=Path(__file__).resolve().parent
REF=HERE.parent/"independent_emt"
sys.path.insert(0,str(REF))
from model import Settings,References
from switching import simulate,PWMConfig

ap=argparse.ArgumentParser()
ap.add_argument("--case",choices=("F2-0.65-0.20","A2-F00993","F2-0.60-0.20"),required=True)
ap.add_argument("--scenario",choices=("baseline","ramp"),required=True)
ap.add_argument("--output-dir", type=Path, default=HERE/"independent_reference")
ap.add_argument("--fresh", action="store_true", help="Start from equilibrium; preserve earlier checkpoints elsewhere")
ap.add_argument("--freeze-new-case",action="store_true",help="Freeze a predeclared additional case with no prior source CSV")
args=ap.parse_args()
cal=json.loads((REF/f"calibration_{args.case}.json").read_text())
plan=json.loads((REF/"ramp_plan.json").read_text())
key,entry=next((k,v) for k,v in plan["cases"].items() if v["calibration_id"]==args.case)
oldpath=REF/f"ramp_{key}_80_2.75s.csv"
if args.scenario=="ramp" and not oldpath.exists() and not (args.case=="F2-0.60-0.20" and args.freeze_new_case):
    raise FileNotFoundError(f"required archived comparison trace missing: {oldpath}")
refs=References(*cal["references"]["setpoints"],theta_g=cal["references"]["theta_g"])
x0=np.asarray(cal["initial_state_independent_order"])
duration=0.5 if args.scenario=="baseline" else 2.75
delta=0 if args.scenario=="baseline" else entry["dG_pu"]
conductance=lambda t:cal["g_resistive"]-delta*min(t/0.25,1.0)
start=time.monotonic()
outdir=args.output_dir.resolve()
outdir.mkdir(exist_ok=True)
path=outdir/f"{args.case}_{args.scenario}_80_50us.npz"
fingerprint=hashlib.sha256((json.dumps(cal,sort_keys=True)+json.dumps(entry,sort_keys=True)+args.scenario
    +(REF/"switching.py").read_text()+(REF/"model.py").read_text()+(REF/"voltage_mean.py").read_text()).encode()).hexdigest()
crash_file=(outdir/f"{args.case}_{args.scenario}_crash.txt").open("a",encoding="utf-8")
faulthandler.enable(file=crash_file)
result=simulate(x0,refs,conductance,duration,Settings(**cal["settings"]),PWMConfig(steps_per_period=80),
    record_periods=1,checkpoint_path=path.with_suffix(".checkpoint.npz"),checkpoint_tag=fingerprint,
    resume=not args.fresh,checkpoint_callback=lambda t:print(f"{args.case} {args.scenario}: saved through t={t:.3f} s",flush=True))
np.savez_compressed(path,time_s=result["time"],vbus2_d_pu=result["v_bus2_d"],
                    vbus2_q_pu=result["v_bus2_q"],electrical_angle_rad=result["electrical_angle"],
                    vdc_pu=result["v_dc"],initial_vbus2_d_pu=x0[2],initial_vbus2_q_pu=x0[3],
                    vbus2_d_cycle_mean_pu=result["v_bus2_d_cycle_mean"],
                    vbus2_q_cycle_mean_pu=result["v_bus2_q_cycle_mean"])
summary={"case":args.case,"scenario":args.scenario,"duration_s":duration,"steps_per_pwm":80,
         "completed_at":datetime.now().astimezone().isoformat(),
         "record_period_s":50e-6,"wall_seconds":time.monotonic()-start,
         "voltage_observable":"one-cycle dq mean from RK4 subsegment integrals and equilibrium prehistory; ring interpolation at electrical substep",
         "python_version":sys.version,"numpy_version":np.__version__,
         "energy_residual_pu_s":result["integrated_energy_residual_pu_seconds"],
         "max_modulation":result["max_modulation"].tolist(),"npz_sha256":hashlib.sha256(path.read_bytes()).hexdigest()}
summary["input_sha256"]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
    (REF/"model.py",REF/"switching.py",REF/"energy.py",REF/"voltage_mean.py",REF/f"calibration_{args.case}.json",REF/"ramp_plan.json",Path(__file__))}
if args.scenario=="ramp":
    selected=np.arange(7,len(result["time"]),8)
    actual=np.column_stack((result["time"][selected],result["v_bus2"][selected],result["v_dc"][selected]))
    if oldpath.exists():
        old=np.loadtxt(oldpath,delimiter=",",skiprows=1)
        if old.shape!=actual.shape:raise ValueError(f"reference shape changed: {old.shape} vs {actual.shape}")
        errors=np.max(abs(old-actual),axis=0)
        summary["agreement_with_archived_csv_max_abs_by_column"]=errors.tolist()
        if np.any(errors>1e-10):raise ValueError(f"reference reproduction differs: {errors}")
    else:
        summary["new_case_reference_frozen_before_native"]=True
        summary["new_reference_checks"]={"finite":bool(np.isfinite(actual).all()),
            "positive_dc":bool(np.min(result["v_dc"])>0),
            "modulation":bool(np.max(result["max_modulation"])<=1),
            "energy":bool(abs(result["integrated_energy_residual_pu_seconds"])<=1e-8)}
        if not all(summary["new_reference_checks"].values()):raise ValueError("new independent reference failed physical checks")
        np.savetxt(path.with_suffix(".reference.csv"),actual,delimiter=",",header="time_s,vbus2_pu,vdc_pu",comments="",fmt="%.12g")
(path.with_suffix(".json")).write_text(json.dumps(summary,indent=2),encoding="utf-8")
print(json.dumps(summary,indent=2),flush=True)
