"""Inspect generated compiler properties, separately from requested TSE values."""
from pathlib import Path
import argparse
import hashlib
import json
HERE=Path(__file__).resolve().parent
ap=argparse.ArgumentParser()
ap.add_argument("--case",default="F2-0.65-0.20")
ap.add_argument("--step-us",required=True,type=float)
args=ap.parse_args()
tag=str(args.step_us).replace('.','p')
stem=f"segan_closed_{args.case}_dt{tag}us"
target=HERE/(stem+" Target files")
path=target/(stem+".json")
model=json.loads(path.read_text())
changes=[]
controller_properties=[]
def walk(value,path,context=()):
    if isinstance(value,dict):
        label={key:value[key] for key in ("name","fqn","type","component_type") if key in value and isinstance(value[key],(str,int,float))}
        ctx=(*context,label) if label else context
        specified=value.get("specified_value")
        actual=value.get("value")
        if (value.get("name")=="execution_rate" and isinstance(specified,(float,int))
            and isinstance(actual,(float,int)) and abs(actual-specified)>1e-15):
            changes.append({"path":path,"context":list(ctx[-5:]),"compiled_property":value})
        if value.get("name")=="SEGAN_Controller":
            controller_properties.append({"path":path,"properties":[p for p in value.get("properties",[]) if p.get("name")=="execution_rate"]})
        for key,item in value.items():walk(item,path+"/"+str(key),ctx)
    elif isinstance(value,list):
        for i,item in enumerate(value):walk(item,path+f"/{i}",context)
walk(model,"")
controller_rates=[p["value"] for node in controller_properties for p in node["properties"]]
controller_rate_matches=(len(controller_rates)==1 and abs(controller_rates[0]-args.step_us*1e-6)<1e-15)
out={"case":args.case,"requested_circuit_step_us":args.step_us,
     "compiled_json_sha256":hashlib.sha256(path.read_bytes()).hexdigest(),
     "cpd_sha256":hashlib.sha256((target/(stem+".cpd")).read_bytes()).hexdigest(),
     "adjusted_execution_properties":changes,
     "no_execution_adjustments":len(changes)==0,
     "controller_execution_rates_s":controller_rates,
     "controller_rate_matches_requested_step":controller_rate_matches,
     "compiled_timing_valid":len(changes)==0 and controller_rate_matches,
     "interpretation":"Adjusted compiler properties require explicit timing validation; requested schematic properties alone are insufficient. This check does not by itself establish the runtime scheduling effect."}
(HERE/(stem+".compiled_timing.json")).write_text(json.dumps(out,indent=2),encoding="utf-8")
print(json.dumps({"step_us":args.step_us,"adjustment_count":len(changes),"first_changes":changes[:2],"controller_nodes":controller_properties},indent=2))
if not out["compiled_timing_valid"]:raise SystemExit(1)
