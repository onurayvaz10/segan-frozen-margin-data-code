"""Audit actual Virtual HIL data against frozen gates and independent PWM data."""
from pathlib import Path
import argparse
import hashlib
import json
import numpy as np

HERE=Path(__file__).resolve().parent
PROTO=json.loads((HERE.parent/"virtual_hil_protocol.json").read_text())
G=PROTO["simulation_gates"]
ap=argparse.ArgumentParser()
ap.add_argument("--case",choices=("F2-0.65-0.20","A2-F00993","F2-0.60-0.20"),required=True)
ap.add_argument("--fine-us",type=float,default=0.125)
ap.add_argument("--coarse-us",type=float,default=0.25)
ap.add_argument("--reference-dir",type=Path,default=HERE/"independent_reference")
ap.add_argument("--step-only",action="store_true",help="Audit native refinement and physics without claiming independent comparison")
args=ap.parse_args()

def read_run(scenario,step):
    tag=str(step).replace(".","p")
    directory=HERE/"validation_runs"/f"{args.case}_{scenario}_{tag}us"
    a=np.genfromtxt(directory/"capture.csv",delimiter=",",names=True)
    out={name:np.asarray(a[name]) for name in a.dtype.names}
    missing=set(PROTO["required_capture_columns"])-set(out)
    if missing:raise ValueError(f"missing columns {missing} in {directory}")
    t=out["time_s"]
    if len(t)<2 or not np.isfinite(a.view(float)).all() or np.any(np.diff(t)<=0):
        raise ValueError(f"invalid capture in {directory}")
    status=json.loads((directory/"run_status.json").read_text())
    if status["status"]!="actual_virtual_hil_capture_saved":raise ValueError("run not completed")
    stem=f"segan_closed_{args.case}_dt{tag}us"
    timing=json.loads((HERE/(stem+".compiled_timing.json")).read_text())
    if not timing["compiled_timing_valid"] or timing["cpd_sha256"]!=status["cpd_sha256"]:
        raise ValueError("run has no valid matching compiled-timing audit")
    status["compiled_timing_validated"]=True
    if hashlib.sha256((directory/"capture.csv").read_bytes()).hexdigest()!=status["capture_sha256"]:
        raise ValueError("capture hash does not match completed-run metadata")
    interval=G["comparison_record_s"]
    duration=G["no_shedding_duration_s"] if scenario=="baseline" else G["total_ramp_duration_s"]
    tolerance=G["time_alignment_max_s"]
    if (len(t)!=int(round(duration/interval)) or abs(t[0]-interval)>tolerance
        or abs(t[-1]-duration)>tolerance or np.max(abs(np.diff(t)-interval))>tolerance):
        raise ValueError(f"incomplete or mistimed capture in {directory}")
    return out,status

def integral_at(t,y,F,q,prehistory):
    q=np.asarray(q)
    idx=np.clip(np.searchsorted(t,q,side="right")-1,0,len(t)-2)
    h=q-t[idx]
    slope=(y[idx+1]-y[idx])/(t[idx+1]-t[idx])
    value=F[idx]+y[idx]*h+0.5*slope*h*h
    return np.where(q<0,prehistory*q,value)

def reference(scenario,query):
    path=args.reference_dir/f"{args.case}_{scenario}_80_50us.npz"
    summary=json.loads(path.with_suffix(".json").read_text())
    if hashlib.sha256(path.read_bytes()).hexdigest()!=summary["npz_sha256"]:
        raise ValueError("independent reference hash mismatch")
    if scenario=="ramp":
        if "agreement_with_archived_csv_max_abs_by_column" in summary:
            if max(summary["agreement_with_archived_csv_max_abs_by_column"])>1e-10:
                raise ValueError("independent reference did not reproduce its archived trace")
        elif not (summary.get("new_case_reference_frozen_before_native") and all(summary["new_reference_checks"].values())):
            raise ValueError("new reference not frozen or its physical checks failed")
    a=np.load(path)
    t=np.r_[0.0,a["time_s"]]
    if (not np.isfinite(t).all() or np.any(np.diff(t)<=0) or t[-1]<max(query)-1e-9
        or np.max(abs(np.diff(t)-50e-6))>1e-9):
        raise ValueError("independent reference is incomplete or has an invalid sample clock")
    mean=[]
    for component in ("d","q"):
        initial=float(a[f"initial_vbus2_{component}_pu"])
        if f"vbus2_{component}_cycle_mean_pu" not in a:
            raise ValueError("reference lacks a subsegment-integrated cycle mean; legacy PWM-stroboscopic averaging is diagnostic only")
        y=np.r_[initial,a[f"vbus2_{component}_cycle_mean_pu"]]
        mean.append(np.interp(query,t,y))
    bus=np.hypot(*mean)
    cal=json.loads((HERE.parent/"independent_emt"/f"calibration_{args.case}.json").read_text())
    dc=np.interp(query,t,np.r_[cal["initial_state_independent_order"][23],a["vdc_pu"]])
    return bus,dc

def energy(a):
    delta=float(a["stored_energy_pu_s"][-1]-a["stored_energy_pu_s"][0])
    net=float(a["integrated_balance_pu_s"][-1]-a["integrated_balance_pu_s"][0])
    supplied=float(a["supplied_energy_pu_s"][-1]-a["supplied_energy_pu_s"][0])
    residual=delta-net
    relative=abs(residual)/max(abs(supplied),abs(float(a["stored_energy_pu_s"][0])),1e-9)
    return {"storage_change_pu_s":delta,"net_boundary_energy_pu_s":net,
            "supplied_energy_pu_s":supplied,"residual_pu_s":residual,"relative_error":relative}

def physical(a,status):
    peak=float(max(a["peak_gfm_mod"][-1],a["peak_rectifier_mod"][-1]))
    dc_min=float(a["minimum_dc_pu"][-1])
    failed_flags=[name for name in ("FL_ARITHMETIC_OVERFLOW","FL_DEAD_TIME","FL_SP_EXC_OCCURRED","FL_COMP_INT_OVERRUN")
                  if status["flags"].get(name) is not False]
    return {"peak_modulation":peak,"minimum_dc_pu":dc_min,"failed_flags":failed_flags,
            "energy":energy(a)}

baseline,bs=read_run("baseline",args.fine_us)
fine,fs=read_run("ramp",args.fine_us)
coarse,cs=read_run("ramp",args.coarse_us)
t=fine["time_s"]
rmse=lambda x:float(np.sqrt(np.mean(np.asarray(x)**2)))
coarse_v=np.interp(t,coarse["time_s"],coarse["vbus2_ll_rms_pu"])
step_error=rmse(fine["vbus2_ll_rms_pu"]-coarse_v)
if args.step_only:
    pa=physical(fine,fs);pb=physical(baseline,bs)
    gates={"step_refinement":step_error<=G["typhoon_step_refinement_bus2_rmse_max_pu"],
           "modulation":max(pa["peak_modulation"],pb["peak_modulation"])<=G["peak_modulation_max"],
           "positive_dc":min(pa["minimum_dc_pu"],pb["minimum_dc_pu"])>0,
           "energy":max(pa["energy"]["relative_error"],pb["energy"]["relative_error"])<=G["energy_balance_relative_error_max"],
           "runtime_flags":not(pa["failed_flags"] or pb["failed_flags"]),
           "compiled_timing":all(s["compiled_timing_validated"] for s in (bs,fs,cs))}
    out={"scope":"Native step refinement and physical consistency only; not an independent comparison",
         "case":args.case,"fine_step_us":args.fine_us,"coarse_step_us":args.coarse_us,
         "step_refinement_bus_rmse_pu":step_error,"baseline":pb,"ramp":pa,"gates":gates,
         "all_refinement_and_physical_gates_passed":all(gates.values())}
    output=HERE/"comparison_results"/f"refinement_{args.case}_dt{str(args.fine_us).replace('.','p')}_vs_{str(args.coarse_us).replace('.','p')}us.json"
    output.write_text(json.dumps(out,indent=2),encoding="utf-8")
    print(json.dumps(out,indent=2))
    raise SystemExit(0 if all(gates.values()) else 1)
ref_v,ref_dc=reference("ramp",t)
cal=json.loads((HERE.parent/"independent_emt"/f"calibration_{args.case}.json").read_text())
x0=cal["initial_state_independent_order"]
tail=baseline["time_s"]>=0.4
steady_bus_error=abs(float(np.mean(baseline["vbus2_ll_rms_pu"][tail]))-float(np.hypot(x0[2],x0[3])))
steady_dc_error=abs(float(np.mean(baseline["vdc_pu"][tail]))-x0[23])
noise=float(np.max(abs(baseline["vbus2_ll_rms_pu"][tail]-np.median(baseline["vbus2_ll_rms_pu"][tail]))))
post=json.loads((HERE.parent/"independent_emt"/"post_equilibrium.json").read_text())
plan=json.loads((HERE.parent/"independent_emt"/"ramp_plan.json").read_text())
key=next(k for k,v in plan["cases"].items() if v["calibration_id"]==args.case)
target=post[key]["post_equilibrium_bus2_pu"]
def envelope(start,stop):
    values=[]
    for left in np.arange(start,stop-1e-9,0.05):
        window=(t>=left)&(t<left+0.05)
        if not window.any():raise ValueError("empty envelope window")
        values.append(np.max(abs(fine["vbus2_ll_rms_pu"][window]-target)))
    return float(np.mean(values))
early=envelope(0.75,1.25);late=envelope(2.25,2.75)
ratio=late/early if early>0 else None
threshold=G["minimum_resolved_envelope_to_noise_ratio"]*noise
label="undetermined"
if early>threshold:
    if late<=threshold or ratio<0.8:label="decaying"
    elif ratio>1.2:label="growing"
pa=physical(fine,fs);pb=physical(baseline,bs)
bus_error=rmse(fine["vbus2_ll_rms_pu"]-ref_v)
dc_error=rmse(fine["vdc_pu"]-ref_dc)
gates={
    "steady_bus":steady_bus_error<=G["steady_bus2_ll_rms_abs_error_max_pu"],
    "steady_dc":steady_dc_error<=G["steady_dc_abs_error_max_pu"],
    "dynamic_bus":bus_error<=G["dynamic_bus2_ll_rms_rmse_max_pu"],
    "dynamic_dc":dc_error<=G["dynamic_dc_rmse_max_pu"],
    "step_refinement":step_error<=G["typhoon_step_refinement_bus2_rmse_max_pu"],
    "modulation":max(pa["peak_modulation"],pb["peak_modulation"])<=G["peak_modulation_max"],
    "positive_dc":min(pa["minimum_dc_pu"],pb["minimum_dc_pu"])>0,
    "energy":max(pa["energy"]["relative_error"],pb["energy"]["relative_error"])<=G["energy_balance_relative_error_max"],
    "runtime_flags":not(pa["failed_flags"] or pb["failed_flags"]),
    "compiled_timing":all(s["compiled_timing_validated"] for s in (bs,fs,cs)),
}
out={"case":args.case,"platform":"Virtual HIL offline simulation, no hardware HIL",
     "acceptance_scope":"Numeric gate audit only. Hardware WHEA events and earlier runtime crashes require an explicit reliability assessment; passing numeric gates does not certify the host.",
     "fine_step_us":args.fine_us,"coarse_step_us":args.coarse_us,
     "steady_bus_abs_error_pu":steady_bus_error,"steady_dc_abs_error_pu":steady_dc_error,
     "dynamic_bus_rmse_pu":bus_error,"dynamic_dc_rmse_pu":dc_error,
     "step_refinement_bus_rmse_pu":step_error,"baseline":pb,"ramp":pa,
     "stability_diagnostic":{"noise_floor_pu":noise,"early_envelope_pu":early,"late_envelope_pu":late,
                             "late_over_early":ratio,"label":label},
     "gates":gates,"all_numeric_gates_passed":all(gates.values())}
out["input_capture_sha256"]={"baseline":bs["capture_sha256"],"fine_ramp":fs["capture_sha256"],"coarse_ramp":cs["capture_sha256"]}
out["independent_reference_sha256"]=hashlib.sha256((args.reference_dir/f"{args.case}_ramp_80_50us.npz").read_bytes()).hexdigest()
out["voltage_observable"]="matched one-cycle dq mean: RK4 subsegment integrals in the independent solver; circuit-step moving window in Virtual HIL; equilibrium prehistory"
outdir=HERE/"comparison_results";outdir.mkdir(exist_ok=True)
version=f"{args.case}_dt{str(args.fine_us).replace('.','p')}_vs_{str(args.coarse_us).replace('.','p')}us"
serialized=json.dumps(out,indent=2)
(outdir/f"{version}.json").write_text(serialized,encoding="utf-8")
(outdir/f"{args.case}.json").write_text(serialized,encoding="utf-8")
np.savez_compressed(outdir/f"{version}_aligned.npz",time_s=t,reference_bus=ref_v,
                    virtual_hil_bus=fine["vbus2_ll_rms_pu"],coarse_bus=coarse_v,
                    reference_dc=ref_dc,virtual_hil_dc=fine["vdc_pu"])
(outdir/f"{args.case}_aligned.npz").write_bytes((outdir/f"{version}_aligned.npz").read_bytes())
print(json.dumps(out,indent=2))
if not out["all_numeric_gates_passed"]:raise SystemExit(1)
