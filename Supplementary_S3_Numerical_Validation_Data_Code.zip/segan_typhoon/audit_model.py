"""Read back compiled SEGAN model parameters and controller text through the API."""
from pathlib import Path
import argparse
import hashlib
import json
import math
from typhoon.api.schematic_editor import SchematicAPI
from controller_code import config

HERE=Path(__file__).resolve().parent
ap=argparse.ArgumentParser()
ap.add_argument("--case",choices=("F2-0.65-0.20","A2-F00993","F2-0.60-0.20"),required=True)
ap.add_argument("--step-us",type=float,required=True)
args=ap.parse_args()
dt=args.step_us*1e-6
stem=f"segan_closed_{args.case}_dt{str(args.step_us).replace('.','p')}us"
tse=HERE/(stem+".tse");target=HERE/(stem+" Target files")
cal=json.loads((HERE.parent/"independent_emt"/f"calibration_{args.case}.json").read_text())
c=cal["settings"];x=cal["initial_state_independent_order"]
z=380**2/10000;wb=2*math.pi*60;lb=z/wb;cb=1/(z*wb);vdcb=math.sqrt(8/3)*380;zdc=vdcb**2/10000
expected=[("GFM_DC_Source","init_const_value",c["gfm_dc"]*vdcb),
          ("Rect_DC_R","resistance",c["r_load"]*zdc),
          ("Rect_DC_C","capacitance",c["c_dc"]/(zdc*wb)),
          ("Rect_DC_C","initial_voltage",x[23]*vdcb)]
def project(idx,base,k):
    ph=(0,-2*math.pi/3,2*math.pi/3)[k]
    return math.sqrt(2/3)*base*(x[idx]*math.cos(ph)-x[idx+1]*math.sin(ph))
for k,p in enumerate("ABC"):
    for label,param,scale in (("GFM_Rf","gfm_rf",z),("GFM_Rg","gfm_rg",z),
                               ("Line_R","r_line",z),("Rect_Rf","cpl_rf",z),("Rect_Rg","cpl_rg",z)):
        expected.append((p+"_"+label,"resistance",c[param]*scale))
    expected.append((p+"_Bus2_Load","resistance",z/cal["g_resistive"]))
    for label,param,idx in (("GFM_Lf","gfm_lf",14),("GFM_Lg","gfm_lg",18),
                             ("Line_L","x_line",4),("Rect_Lf","cpl_lf",26),("Rect_Lg","cpl_lg",30)):
        expected += [(p+"_"+label,"inductance",c[param]*lb),
                     (p+"_"+label,"initial_current",project(idx,10000/380,k))]
    for label,param,idx in (("GFM_Cf","gfm_cf",16),("Bus1_C","b_bus",0),
                             ("Bus2_C","b_bus",2),("Rect_Cf","cpl_cf",28)):
        expected += [(p+"_"+label,"capacitance",c[param]*cb),
                     (p+"_"+label,"initial_voltage",project(idx,380,k))]
m=SchematicAPI();m.load(str(tse))
checks=[]
for name,prop,value in expected:
    component=m.get_item(name,item_type="component")
    actual=float(m.get_property_value(m.prop(component,prop)))
    checks.append({"component":name,"property":prop,"expected_SI":value,"actual_SI":actual,
                   "passed":abs(actual-value)<=1e-12*max(1,abs(value))})
controller=m.get_item("SEGAN_Controller",item_type="component")
for key,value in config(cal,dt).items():
    if key in ("add_src_path_full",):continue
    actual=m.get_property_value(m.prop(controller,key))
    if key in ("output_fnc","update_fnc","init_fnc","global_variables"):
        passed=str(actual).replace("\r\n","\n").strip()==str(value).strip()
        checks.append({"controller_property":key,"passed":passed})
models={"hil_device":"VHIL+","enb_pole_shift":False,"user_real_type_precision":"double precision"}
for name,wanted in models.items():
    actual=m.get_model_property_value(name)
    checks.append({"model_property":name,"expected":wanted,"actual":actual,"passed":actual==wanted})
actual_step=float(m.get_model_property_value("simulation_time_step"))
checks.append({"model_property":"simulation_time_step","expected":dt,"actual":actual_step,
               "passed":abs(actual_step-dt)<1e-16})
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for filename in ("controller_math.c","controller_math.h"):
    live=HERE/"controller_src"/filename
    compiled=target/"ext-src"/"_segan_controller"/"sources"/"controller_src"/filename
    checks.append({"compiled_dependency":filename,"passed":sha(live)==sha(compiled)})
out={"case":args.case,"step_us":args.step_us,"tse_sha256":sha(tse),
     "cpd_sha256":sha(target/(stem+".cpd")),"checks":checks,"all_passed":all(a["passed"] for a in checks)}
(HERE/(stem+".audit.json")).write_text(json.dumps(out,indent=2),encoding="utf-8")
print(json.dumps({"case":args.case,"step_us":args.step_us,"checks":len(checks),"all_passed":out["all_passed"]},indent=2))
if not out["all_passed"]:raise SystemExit(1)
