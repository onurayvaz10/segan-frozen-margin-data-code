"""Verify that a saved PWM checkpoint resumes without changing any result bit."""
from pathlib import Path
import sys
import json
import numpy as np
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/"independent_emt"))
from model import Settings,References
from switching import simulate,PWMConfig
cal=json.loads((HERE.parent/"independent_emt"/"calibration_F2-0.65-0.20.json").read_text())
x=np.asarray(cal["initial_state_independent_order"]);x[2]+=0.001
r=References(*cal["references"]["setpoints"],theta_g=cal["references"]["theta_g"])
g=lambda t:0.2-0.01*min(t/0.0025,1)
kwargs=dict(cfg=Settings(**cal["settings"]),pwm=PWMConfig(steps_per_period=80),record_periods=1)
fresh=simulate(x,r,g,0.0025,**kwargs)
class DeliberateInterruption(Exception):pass
def stop(t):raise DeliberateInterruption()
checkpoint=HERE/"checkpoint_test.npz"
try:
    simulate(x,r,g,0.0025,**kwargs,checkpoint_path=checkpoint,checkpoint_tag="resume_test_v1",
             checkpoint_every=0.001,checkpoint_callback=stop)
except DeliberateInterruption:pass
resumed=simulate(x,r,g,0.0025,**kwargs,checkpoint_path=checkpoint,checkpoint_tag="resume_test_v1",
                 checkpoint_every=0.001,resume=True)
names=("time","v_bus2","v_dc","v_bus2_d","v_bus2_q","electrical_angle","final_state","max_modulation","v_bus2_d_cycle_mean","v_bus2_q_cycle_mean")
checks={name:bool(np.array_equal(fresh[name],resumed[name])) for name in names}
checks["energy_integral"]=fresh["integrated_boundary_energy_pu_seconds"]==resumed["integrated_boundary_energy_pu_seconds"]
checks["switching_crossings"]=fresh["switching_crossings"]==resumed["switching_crossings"]
result={"checks":checks,"all_bitwise_identical":all(checks.values()),"purpose":"checkpoint integrity"}
(HERE/"checkpoint_resume_checks.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
print(json.dumps(result,indent=2))
if not result["all_bitwise_identical"]:raise SystemExit(1)
