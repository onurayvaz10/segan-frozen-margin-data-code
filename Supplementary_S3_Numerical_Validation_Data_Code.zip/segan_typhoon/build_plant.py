"""Build a SEGAN-parameter two-bus switched electrical plant in Typhoon.

This is a plant integration checkpoint. Its open-loop sinusoidal commands are
deliberately NOT the paper's droop/PLL/PI controls, so its outputs must never
be compared with the paper's stability-boundary claims.
"""
from __future__ import annotations
from math import pi, sqrt, cos, sin, atan2
from pathlib import Path
import json
import argparse
from typhoon.api.schematic_editor import SchematicAPI

HERE = Path(__file__).resolve().parent
ap=argparse.ArgumentParser()
ap.add_argument("--drive",choices=("sinus","fixed","closed"),default="sinus")
ap.add_argument("--step-us",type=float,choices=(1.0,0.5,0.25,0.125,0.0625,0.05,0.025),default=1.0)
ap.add_argument("--case",choices=("F2-0.65-0.20","A2-F00993","F2-0.60-0.20"),default="F2-0.65-0.20")
args=ap.parse_args()
stem={"sinus":"segan_plant_checkpoint","fixed":"segan_fixed_command_gatecheck",
      "closed":"segan_closed_"+args.case}[args.drive]
if args.case!="F2-0.65-0.20" and args.drive!="closed":
    stem+="_"+args.case
TSE = HERE / (stem+".tse")
if args.step_us!=1.0:
    TSE=TSE.with_name(TSE.stem+"_dt"+str(args.step_us).replace(".","p")+"us.tse")
RATE="50e-6" if args.drive=="sinus" else str(args.step_us*1e-6)
S_BASE = 10000.0
V_LL = 380.0
W = 2*pi*60
Z = V_LL**2/S_BASE
L_BASE = Z/W
C_BASE = 1/(Z*W)
VDC_BASE = sqrt(8/3)*V_LL
cal=json.loads((HERE.parent/"independent_emt"/("calibration_"+args.case+".json")).read_text())
cfg=cal["settings"]
x=cal["initial_state_independent_order"]
def cx(i): return complex(x[i],x[i+1])
def phase_si(value,base,index):
    theta=(0,-2*pi/3,2*pi/3)[index]
    return sqrt(2/3)*base*(value.real*cos(theta)-value.imag*sin(theta))
vg_cmd=cx(16)+complex(cal["settings"]["gfm_rf"],cal["settings"]["gfm_lf"])*cx(14)
vc_cmd=cx(28)-complex(cal["settings"]["cpl_rf"],cal["settings"]["cpl_lf"])*cx(26)

m = SchematicAPI()
m.create_new_model(name="SEGAN two-bus plant checkpoint")
m.set_model_property_value("hil_device", "VHIL+")
m.set_model_property_value("hil_configuration_id", "1")
m.set_model_property_value("simulation_time_step",str(args.step_us*1e-6))
m.set_model_property_value("enb_pole_shift", False)
if args.drive=="closed":
    m.set_model_property_value("user_real_type_precision","double precision")
print("created model and set VHIL+ configuration",flush=True)

parts = {}
feedback={}
def add(kind, name, x, y, **values):
    obj = m.create_component("core/"+kind, name=name, position=(x,y))
    if obj is None:
        raise RuntimeError(f"failed to create {name}: {kind}")
    parts[name]=obj
    for key,value in values.items():
        ok=m.set_property_value(m.prop(obj,key),str(value))
        if ok is False:
            raise RuntimeError(f"failed to set {name}.{key}={value}")
    return obj

def node(name,x,y):
    obj=m.create_junction(name=name,position=(x,y))
    parts[name]=obj
    return obj

def t(obj,port): return m.term(obj,port)
def wire(a,b):
    result=m.create_connection(a,b)
    if result is None:
        raise RuntimeError("connection failed")

def branch(kind,name,x,y,value,property_name,p,n):
    obj=add(kind,name,x,y,**{property_name:value})
    wire(p,t(obj,"p_node")); wire(t(obj,"n_node"),n)
    return obj

def current_tap(label,phase,xpos,ypos,upstream):
    name=f"{phase}_{label}_Feedback"
    sensor=add("Current Measurement",name,xpos,ypos,sig_output=True,execution_rate=RATE)
    downstream=node(name+"_Node",xpos+30,ypos)
    wire(upstream,t(sensor,"p_node"));wire(t(sensor,"n_node"),downstream)
    feedback[f"{label}_{phase.lower()}"]=name
    return downstream

def voltage_tap(label,phase,xpos,ypos,positive,neutral):
    name=f"{phase}_{label}_Feedback"
    sensor=add("Voltage Measurement",name,xpos,ypos,sig_output=True,execution_rate=RATE)
    wire(positive,t(sensor,"p_node"));wire(neutral,t(sensor,"n_node"))
    feedback[f"{label}_{phase.lower()}"]=name

gfm=add("Three Phase Inverter","GFM_PWM",6650,8160,
        ctrl_src=("Internal modulator" if args.drive=="sinus" else "Model"),carrier_freq=20000,
        d_time=0,ref_sig_min_max="[-1.0, 1.0]",fvd=False,losses_estimation=False,
        execution_rate=RATE)
rect=add("Three Phase Inverter","Rectifier_PWM",10000,8160,
         ctrl_src=("Internal modulator" if args.drive=="sinus" else "Model"),carrier_freq=20000,
         d_time=0,ref_sig_min_max="[-1.0, 1.0]",fvd=False,losses_estimation=False,
         execution_rate=RATE)
gfm_vdc=add("Voltage Source","GFM_DC_Source",6250,8400,
            init_source_nature="Constant",init_const_value=cfg["gfm_dc"]*VDC_BASE)
gnd_dc1=add("Ground","GFM_DC_Ground",6230,8550)
if args.drive=="closed":
    idc_sensor=add("Current Measurement","GFM_DC_Current_Feedback",6400,8400,
                   sig_output=True,execution_rate=RATE)
    wire(t(gfm_vdc,"p_node"),t(idc_sensor,"p_node"));wire(t(idc_sensor,"n_node"),t(gfm,"pos_out"))
    feedback["idc_g"]="GFM_DC_Current_Feedback"
else:
    wire(t(gfm_vdc,"p_node"),t(gfm,"pos_out"))
wire(t(gfm_vdc,"n_node"),t(gfm,"neg_out"))
wire(t(gfm_vdc,"n_node"),t(gnd_dc1,"node"))

rect_pos=node("Rect_DC_Pos",10140,8380)
rect_neg=node("Rect_DC_Neg",10140,8560)
wire(t(rect,"pos_out"),rect_pos)
wire(t(rect,"neg_out"),rect_neg)
rect_cap=branch("Capacitor","Rect_DC_C",10300,8450,cfg["c_dc"]/(VDC_BASE**2/S_BASE*W),"capacitance",rect_pos,rect_neg)
m.set_property_value(m.prop(rect_cap,"initial_voltage"),str(x[23]*VDC_BASE))
branch("Resistor","Rect_DC_R",10450,8450,cfg["r_load"]*VDC_BASE**2/S_BASE,"resistance",rect_pos,rect_neg)
# The rectifier DC circuit floats. Grounding both converter DC negatives would
# add a common-mode return path absent from the positive-sequence SEGAN model.
vdc=add("Voltage Measurement","Rect_DC_Meas",10600,8460,sig_output=True,execution_rate=RATE)
wire(rect_pos,t(vdc,"p_node")); wire(rect_neg,t(vdc,"n_node"))
probe=add("Probe","Rect_DC_Probe",10700,8460)
wire(t(vdc,"out"),t(probe,"in"))

neutrals={tag:node(tag+"_Floating_Neutral",7800+i*160,8650)
          for i,tag in enumerate(("GFM_Cf","Bus1_C","Bus2_C","Rect_Cf","Bus2_Load"))}
print("created DC branches and floating-neutral nodes",flush=True)
for index,phase in enumerate("ABC"):
    y=7750+index*180
    n0=node(f"{phase}_GFM_Pole",6800,y)
    ncg=node(f"{phase}_GFM_Cap",7450,y)
    nb1=node(f"{phase}_Bus1",8000,y)
    nb2=node(f"{phase}_Bus2",8650,y)
    ncr=node(f"{phase}_Rect_Cap",9250,y)
    nr=node(f"{phase}_Rect_Pole",9800,y)
    wire(t(gfm,phase.lower()+"_in"),n0)
    gic_start=current_tap("gic",phase,6830,y,n0) if args.drive=="closed" else n0
    gif_start=current_tap("gif",phase,7480,y,ncg) if args.drive=="closed" else ncg
    cic_start=current_tap("cic",phase,9280,y,ncr) if args.drive=="closed" else ncr
    if args.drive=="closed":
        voltage_tap("gvf",phase,7390,y+70,ncg,neutrals["GFM_Cf"])
        voltage_tap("cvf",phase,9190,y+70,ncr,neutrals["Rect_Cf"])
        voltage_tap("v1",phase,7950,y+70,nb1,neutrals["Bus1_C"])
    branch("Resistor",f"{phase}_GFM_Rf",6920,y,cfg["gfm_rf"]*Z,"resistance",gic_start,
           (a:=node(f"{phase}_GFM_Rf_Lf",7000,y)))
    gfm_lf=branch("Inductor",f"{phase}_GFM_Lf",7150,y,cfg["gfm_lf"]*L_BASE,"inductance",a,ncg)
    m.set_property_value(m.prop(gfm_lf,"initial_current"),str(phase_si(cx(14),S_BASE/V_LL,index)))
    gfm_lg=branch("Inductor",f"{phase}_GFM_Lg",7600,y,cfg["gfm_lg"]*L_BASE,"inductance",gif_start,
           (b:=node(f"{phase}_GFM_Lg_Rg",7720,y)))
    m.set_property_value(m.prop(gfm_lg,"initial_current"),str(phase_si(cx(18),S_BASE/V_LL,index)))
    branch("Resistor",f"{phase}_GFM_Rg",7830,y,cfg["gfm_rg"]*Z,"resistance",b,nb1)
    line_start=current_tap("linei",phase,8030,y,nb1) if args.drive=="closed" else nb1
    cif_start=current_tap("cif",phase,8680,y,nb2) if args.drive=="closed" else nb2
    branch("Resistor",f"{phase}_Line_R",8150,y,cfg["r_line"]*Z,"resistance",line_start,
           (c:=node(f"{phase}_Line_R_L",8250,y)))
    line_l=branch("Inductor",f"{phase}_Line_L",8420,y,cfg["x_line"]*L_BASE,"inductance",c,nb2)
    m.set_property_value(m.prop(line_l,"initial_current"),str(phase_si(cx(4),S_BASE/V_LL,index)))
    branch("Resistor",f"{phase}_Rect_Rg",8770,y,cfg["cpl_rg"]*Z,"resistance",cif_start,
           (d:=node(f"{phase}_Rect_Rg_Lg",8890,y)))
    rect_lg=branch("Inductor",f"{phase}_Rect_Lg",9070,y,cfg["cpl_lg"]*L_BASE,"inductance",d,ncr)
    m.set_property_value(m.prop(rect_lg,"initial_current"),str(phase_si(cx(30),S_BASE/V_LL,index)))
    rect_lf=branch("Inductor",f"{phase}_Rect_Lf",9380,y,cfg["cpl_lf"]*L_BASE,"inductance",cic_start,
           (e:=node(f"{phase}_Rect_Lf_Rf",9500,y)))
    m.set_property_value(m.prop(rect_lf,"initial_current"),str(phase_si(cx(26),S_BASE/V_LL,index)))
    branch("Resistor",f"{phase}_Rect_Rf",9660,y,cfg["cpl_rf"]*Z,"resistance",e,nr)
    wire(nr,t(rect,phase.lower()+"_in"))
    for tag,where,cap,space in (("GFM_Cf",ncg,cfg["gfm_cf"]*C_BASE,cx(16)),
                                ("Bus1_C",nb1,cfg["b_bus"]*C_BASE,cx(0)),
                                ("Bus2_C",nb2,cfg["b_bus"]*C_BASE,cx(2)),
                                ("Rect_Cf",ncr,cfg["cpl_cf"]*C_BASE,cx(28))):
        shunt=branch("Capacitor",f"{phase}_{tag}",6200+index*30,y+70,cap,"capacitance",where,neutrals[tag])
        m.set_property_value(m.prop(shunt,"initial_voltage"),str(phase_si(space,V_LL,index)))
    branch("Resistor",f"{phase}_Bus2_Load",8710,y+70,Z/cal["g_resistive"],"resistance",nb2,neutrals["Bus2_Load"])
    vm=add("Voltage Measurement",f"{phase}_Bus2_V_Meas",8770,y+120,sig_output=True,
           execution_rate=(RATE if args.drive=="closed" else "100e-6"))
    wire(nb2,t(vm,"p_node")); wire(t(vm,"n_node"),neutrals["Bus2_Load"])
    vp=add("Probe",f"{phase}_Bus2_V",8890,y+120)
    wire(t(vm,"out"),t(vp,"in"))
    if args.drive=="closed":
        feedback[f"v2_{phase.lower()}"]=f"{phase}_Bus2_V_Meas"
        injection=add("Signal Controlled Current Source",f"{phase}_Shed_Injection",8750,y+230,execution_rate=RATE)
        inj_sensor=add("Current Measurement",f"{phase}_Injection_Current",8840,y+230,sig_output=True,execution_rate=RATE)
        wire(t(injection,"p_node"),t(inj_sensor,"p_node"));wire(t(inj_sensor,"n_node"),nb2)
        wire(t(injection,"n_node"),neutrals["Bus2_Load"])
        feedback[f"inj_{phase.lower()}"]=f"{phase}_Injection_Current"
    print(f"completed physical phase {phase}",flush=True)

if args.drive=="sinus":
    enable=add("Constant","PWM_Enable",7600,8750,value=1,execution_rate=RATE)
    wire(t(enable,"out"),t(gfm,"En"));wire(t(enable,"out"),t(rect,"En"))
    for index,phase in enumerate("ABC"):
        angle=(0,-120,120)[index]
        sg=add("Sinusoidal Source",f"GFM_{phase}_openloop",7200,8700+index*55,
               amplitude=abs(vg_cmd)/cfg["gfm_dc"],frequency=60,
               phase=90+angle+atan2(vg_cmd.imag,vg_cmd.real)*180/pi,execution_rate=RATE)
        sr=add("Sinusoidal Source",f"Rect_{phase}_openloop",9300,8700+index*55,
               amplitude=abs(vc_cmd)/x[23],frequency=60,
               phase=90+angle+atan2(vc_cmd.imag,vc_cmd.real)*180/pi,execution_rate=RATE)
        wire(t(sg,"out"),t(gfm,"In"+phase))
        wire(t(sr,"out"),t(rect,"In"+phase))
elif args.drive=="fixed":
    clock=add("Clock","Simulation_Clock",7500,9100,execution_rate=RATE)
    code=f"""real rg[3], rc[3], mxg, mng, mxc, mnc, ph, tri, z;
int k;
for (k=0;k<3;k++) {{
    ph={W:.17g}*clock_s-(2.0*3.14159265358979323846/3.0)*k;
    rg[k]=({vg_cmd.real:.17g}*cos(ph)-({vg_cmd.imag:.17g})*sin(ph))/{cfg['gfm_dc']:.17g};
    rc[k]=({vc_cmd.real:.17g}*cos(ph)-({vc_cmd.imag:.17g})*sin(ph))/(dc/{VDC_BASE:.17g});
}}
mxg=fmax(rg[0],fmax(rg[1],rg[2])); mng=fmin(rg[0],fmin(rg[1],rg[2]));
mxc=fmax(rc[0],fmax(rc[1],rc[2])); mnc=fmin(rc[0],fmin(rc[1],rc[2]));
z=fmod(clock_s*20000.0,1.0); tri=1.0-4.0*fabs(z-0.5);
mg=0;mc=0;
for(k=0;k<3;k++) {{
    rg[k]-=0.5*(mxg+mng); rc[k]-=0.5*(mxc+mnc);
    mg=fmax(mg,fabs(rg[k]));mc=fmax(mc,fabs(rc[k]));
    g[2*k]=(rg[k]>tri)?1.0:0.0; g[2*k+1]=1.0-g[2*k];
    c[2*k]=(rc[k]>tri)?1.0:0.0; c[2*k+1]=1.0-c[2*k];
}}"""
    gate=add("C function","Fixed_Command_PWM",8400,9100,
             input_terminals="real clock_s;real dc;",input_terminals_dimensions="(1,);(1,)",
             input_terminals_feedthrough="True;True",
             output_terminals="real g;real c;real mg;real mc;",
             output_terminals_dimensions="(6,);(6,);(1,);(1,)",
             output_terminals_feedthrough="True;True;True;True",
             output_fnc=code,execution_rate=RATE)
    # Reopen the saved component so Typhoon rebuilds C-function dynamic ports.
    m.save_as(str(TSE))
    m.load(str(TSE))
    gate=m.get_item("Fixed_Command_PWM",item_type="component")
    clock=m.get_item("Simulation_Clock",item_type="component")
    vdc=m.get_item("Rect_DC_Meas",item_type="component")
    gfm=m.get_item("GFM_PWM",item_type="component")
    rect=m.get_item("Rectifier_PWM",item_type="component")
    wire(t(clock,"out"),t(gate,"clock_s"));wire(t(vdc,"out"),t(gate,"dc"))
    wire(t(gate,"g"),t(gfm,"s_ctrl"));wire(t(gate,"c"),t(rect,"s_ctrl"))
    for idx,signal in enumerate(("mg","mc")):
        monitor=add("Probe","PWM_"+signal,9000,9150+idx*60)
        wire(t(gate,signal),t(monitor,"in"))
else:
    from controller_code import config as controller_config,OUTPUTS
    shed=add("SCADA Input","Shed_dG",7800,9450,def_value=0,unit="pu",execution_rate=RATE)
    control=add("C function","SEGAN_Controller",8400,9300,
                **controller_config(cal,args.step_us*1e-6))
    m.save_as(str(TSE))
    m.load(str(TSE))
    control=m.get_item("SEGAN_Controller",item_type="component")
    gfm=m.get_item("GFM_PWM",item_type="component")
    rect=m.get_item("Rectifier_PWM",item_type="component")
    vdc=m.get_item("Rect_DC_Meas",item_type="component")
    shed=m.get_item("Shed_dG",item_type="component")
    for port,sensor_name in feedback.items():
        sensor=m.get_item(sensor_name,item_type="component")
        wire(t(sensor,"out"),t(control,port))
    wire(t(vdc,"out"),t(control,"dc"))
    wire(t(shed,"out"),t(control,"shed_dg"))
    wire(t(control,"g"),t(gfm,"s_ctrl"));wire(t(control,"c"),t(rect,"s_ctrl"))
    for phase in "ABC":
        injection=m.get_item(f"{phase}_Shed_Injection",item_type="component")
        wire(t(control,"i"+phase.lower()),t(injection,"in"))
    for idx,signal in enumerate(name for name,size in OUTPUTS if size==1):
        monitor=add("Probe","Control_"+signal,9300,9200+idx*60,execution_rate=RATE)
        wire(t(control,signal),t(monitor,"in"))

m.save_as(str(TSE))
print(f"saved {TSE} with {len(parts)} components/junctions",flush=True)
ok=m.compile()
print(f"compile={ok} compiled={m.get_compiled_model_file(str(TSE))}",flush=True)
if not ok:
    raise RuntimeError("SEGAN plant checkpoint did not compile")
