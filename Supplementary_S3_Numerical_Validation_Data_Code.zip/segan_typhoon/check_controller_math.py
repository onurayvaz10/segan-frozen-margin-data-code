"""Verify the C controller transcription against the frozen Python equations."""
from pathlib import Path
import ctypes
import json
import os
import subprocess
import sys
import numpy as np

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/"independent_emt"))
from model import Settings,References,commands,rhs
from energy import stored_energy,external_power
from controller_code import CFG_NAMES

gcc=Path(r"C:\Program Files\Typhoon HIL Control Center 2026.3\compilers\windows\vhil\gcc\bin\gcc.exe")
dll=HERE/"controller_math.dll"
environment=os.environ.copy()
environment["PATH"]=str(gcc.parent)+os.pathsep+environment.get("PATH","")
result=subprocess.run([str(gcc),"-shared","-O2","-static-libgcc","-Wl,--export-all-symbols",
                       str(HERE/"controller_src"/"controller_math.c"),"-o",str(dll)],capture_output=True,text=True,env=environment)
if result.returncode:
    raise RuntimeError(f"gcc exit {result.returncode}: {result.stderr}")
lib=ctypes.CDLL(str(dll))
fn=lib.segan_control_math
ptr=ctypes.POINTER(ctypes.c_double)
fn.argtypes=[ptr,ptr,ptr,ptr,ptr]
energy_fn=lib.segan_energy_math
energy_fn.argtypes=[ptr,ptr,ctypes.c_double,ctypes.c_double,ctypes.c_double,ptr]
idx=np.array([6,7,8,9,10,11,12,13,20,21,22,24,25])
rng=np.random.default_rng(20261028)
audit=[]
for case in ("F2-0.65-0.20","A2-F00993","F2-0.60-0.20"):
    cal=json.loads((HERE.parent/"independent_emt"/f"calibration_{case}.json").read_text())
    x0=np.asarray(cal["initial_state_independent_order"],dtype=np.float64)
    r=np.asarray(cal["references"]["setpoints"]+[cal["references"]["theta_g"]],dtype=np.float64)
    ref=References(*r[:5],theta_g=r[5])
    settings=Settings(**cal["settings"])
    cfg=np.asarray([cal["settings"][name] for name in CFG_NAMES],dtype=np.float64)
    max_u=max_d=max_energy=max_power=0.0
    for trial in range(101):
        x=x0.copy() if trial==0 else x0+rng.normal(0,1e-4,32)
        u=np.zeros(6,dtype=np.float64);d=np.zeros(32,dtype=np.float64)
        fn(x.ctypes.data_as(ptr),r.ctypes.data_as(ptr),cfg.ctypes.data_as(ptr),u.ctypes.data_as(ptr),d.ctypes.data_as(ptr))
        vg,vc,w,dw=commands(x,ref,settings)
        expected=np.array([vg.real,vg.imag,vc.real,vc.imag,w,dw])
        expected_d=rhs(0,x,ref,cal["g_resistive"],settings)
        max_u=max(max_u,float(np.max(abs(u-expected))))
        max_d=max(max_d,float(np.max(abs(d[idx]-expected_d[idx]))))
        power_in=(vg*complex(x[14],-x[15])).real
        values=np.zeros(4,dtype=np.float64)
        injected=0.003
        vdc_source=settings.gfm_dc*np.sqrt(8/3)*380
        energy_fn(x.ctypes.data_as(ptr),cfg.ctypes.data_as(ptr),cal["g_resistive"],injected,power_in*10000/vdc_source,
                  values.ctypes.data_as(ptr))
        max_energy=max(max_energy,abs(float(values[0])-stored_energy(x,settings)))
        expected_power=external_power(x,settings,cal["g_resistive"],(vg,vc))+injected
        max_power=max(max_power,abs(float(values[1]-values[2]-values[3])-expected_power))
    audit.append({"case":case,"trials":101,"max_command_abs_error":max_u,
                  "max_controller_derivative_abs_error_per_s":max_d,
                  "max_stored_energy_abs_error_pu_s":max_energy,
                  "max_net_power_abs_error_pu":max_power,
                  "passed":max_u<1e-11 and max_d<1e-10 and max_energy<1e-11 and max_power<1e-11})
out={"scope":"controller equation transcription only; no physical-plant validation",
     "checks":audit,"all_passed":all(a["passed"] for a in audit)}
(HERE/"controller_math_checks.json").write_text(json.dumps(out,indent=2),encoding="utf-8")
print(json.dumps(out,indent=2))
if not out["all_passed"]:
    raise SystemExit(1)
