"""Analytical averaging, checkpoint and unchanged-state checks for the observable."""
from pathlib import Path
import json
import math
import sys
import numpy as np
HERE=Path(__file__).resolve().parent
REF=HERE.parent/"independent_emt"
sys.path.insert(0,str(REF))
from voltage_mean import IntegralCycleMean
from model import Settings,References
from switching import simulate,PWMConfig

dt=1/(20000*80);window=1/60;omega=2*math.pi*20000
def Fd(t):return t+0.05*t*t+0.003*math.sin(omega*t)/omega if t>=0 else 1.003*t
def Fq(t):return -0.2*t+0.002*math.sin(2*math.pi*600*t)/(2*math.pi*600) if t>=0 else -0.198*t
mean=IntegralCycleMean(dt,1.003,-.198)
errors=[]
for k in range(1,32001):
    t=k*dt;previous=(k-1)*dt
    mean.push(k,Fd(t)-Fd(previous),Fq(t)-Fq(previous))
    if k%80==0:
        actual=np.asarray(mean.value())
        expected=np.array([(Fd(t)-Fd(t-window))/window,(Fq(t)-Fq(t-window))/window])
        errors.append(abs(actual-expected))
analytic_error=np.max(errors,axis=0)
# Bound for linear interpolation of the integral: dt^2 max|voltage derivative|/(8T).
bound=dt*dt*(0.1+.003*omega)/(8*window)
cal=json.loads((REF/"calibration_F2-0.65-0.20.json").read_text())
plan=json.loads((REF/"ramp_plan.json").read_text())
entry=plan["cases"]["F2-0.65-0.20_A_between"]
refs=References(*cal["references"]["setpoints"],theta_g=cal["references"]["theta_g"])
result=simulate(np.asarray(cal["initial_state_independent_order"]),refs,
    lambda t:cal["g_resistive"]-entry["dG_pu"]*min(t/.25,1),.01,
    Settings(**cal["settings"]),PWMConfig(steps_per_period=80),record_periods=1)
old=np.load(HERE/"independent_reference_balanced"/"F2-0.65-0.20_ramp_80_50us.npz")
mapping={"time":"time_s","v_bus2_d":"vbus2_d_pu","v_bus2_q":"vbus2_q_pu","v_dc":"vdc_pu","electrical_angle":"electrical_angle_rad"}
unchanged={name:bool(np.array_equal(result[name],old[oldname][:len(result[name])])) for name,oldname in mapping.items()}
summary={"analytic_mean_max_abs_error_dq_pu":analytic_error.tolist(),
         "analytic_interpolation_bound_pu":bound,"analytic_check_passed":bool(np.all(analytic_error<=bound+1e-11)),
         "unchanged_physical_trajectory_bitwise_checks":unchanged,
         "scope":"Observable only; the electrical/controller integration and state updates are unchanged.",
         "all_passed":bool(np.all(analytic_error<=bound+1e-11)) and all(unchanged.values())}
(HERE/"voltage_observable_checks.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
print(json.dumps(summary,indent=2))
if not summary["all_passed"]:raise SystemExit(1)
