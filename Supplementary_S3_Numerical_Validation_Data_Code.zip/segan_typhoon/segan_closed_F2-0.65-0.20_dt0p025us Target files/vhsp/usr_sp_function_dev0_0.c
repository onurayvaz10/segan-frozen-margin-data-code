// generated using template: cop_main.template---------------------------------------------
/******************************************************************************************
**
**  Module Name: cop_main.c
**  NOTE: Automatically generated file. DO NOT MODIFY!
**  Description:
**            Main file
**
******************************************************************************************/
// generated using template: arm/custom_include.template-----------------------------------


#ifdef __cplusplus
#include <limits>

extern "C" {
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <stdint.h>
#include <complex.h>
#include <time.h>
#include <stdarg.h>

// x86 libraries:
#include "../include/sp_functions_dev0.h"


#ifdef __cplusplus
}
#endif

#include "controller_math.h"


// ----------------------------------------------------------------------------------------                // generated using template:generic_macros.template-----------------------------------------
/*********************** Macros (Inline Functions) Definitions ***************************/

// ----------------------------------------------------------------------------------------

#ifndef MAX
#define MAX(value, limit) (((value) > (limit)) ? (value) : (limit))
#endif
#ifndef MIN
#define MIN(value, limit) (((value) < (limit)) ? (value) : (limit))
#endif

// generated using template: VirtualHIL/custom_defines.template----------------------------

typedef unsigned char X_UnInt8;
typedef char X_Int8;
typedef signed short X_Int16;
typedef unsigned short X_UnInt16;
typedef int X_Int32;
typedef unsigned int X_UnInt32;
typedef unsigned int uint;
typedef double real;

// ----------------------------------------------------------------------------------------
// generated using template: custom_consts.template----------------------------------------

// arithmetic constants
#define C_SQRT_2                    1.4142135623730950488016887242097f
#define C_SQRT_3                    1.7320508075688772935274463415059f
#define C_PI                        3.1415926535897932384626433832795f
#define C_E                         2.7182818284590452353602874713527f
#define C_2PI                       6.283185307179586476925286766559f

//@cmp.def.start
//component defines










































































//@cmp.def.end


//-----------------------------------------------------------------------------------------
// generated using template: common_variables.template-------------------------------------
// true global variables





// const variables
static const int _a_bus2_v_meas_va1__n_rd_as = 13107200;
static const unsigned int _a_bus2_v_meas_va1__p_addr = 23;
static const char* _a_bus2_v_meas_va1__p_sig_output = "True";

static const int _a_injection_current_ia1__n_rd_as = 13107200;
static const unsigned int _a_injection_current_ia1__p_addr = 36;
static const char* _a_injection_current_ia1__p_sig_output = "True";

static const int _a_cic_feedback_ia1__n_rd_as = 13107200;
static const unsigned int _a_cic_feedback_ia1__p_addr = 37;
static const char* _a_cic_feedback_ia1__p_sig_output = "True";

static const int _a_cif_feedback_ia1__n_rd_as = 13107200;
static const unsigned int _a_cif_feedback_ia1__p_addr = 38;
static const char* _a_cif_feedback_ia1__p_sig_output = "True";

static const int _a_cvf_feedback_va1__n_rd_as = 13107200;
static const unsigned int _a_cvf_feedback_va1__p_addr = 24;
static const char* _a_cvf_feedback_va1__p_sig_output = "True";

static const int _a_gic_feedback_ia1__n_rd_as = 13107200;
static const unsigned int _a_gic_feedback_ia1__p_addr = 39;
static const char* _a_gic_feedback_ia1__p_sig_output = "True";

static const int _a_gif_feedback_ia1__n_rd_as = 13107200;
static const unsigned int _a_gif_feedback_ia1__p_addr = 40;
static const char* _a_gif_feedback_ia1__p_sig_output = "True";

static const int _a_gvf_feedback_va1__n_rd_as = 13107200;
static const unsigned int _a_gvf_feedback_va1__p_addr = 25;
static const char* _a_gvf_feedback_va1__p_sig_output = "True";

static const int _a_linei_feedback_ia1__n_rd_as = 13107200;
static const unsigned int _a_linei_feedback_ia1__p_addr = 41;
static const char* _a_linei_feedback_ia1__p_sig_output = "True";

static const int _a_v1_feedback_va1__n_rd_as = 13107200;
static const unsigned int _a_v1_feedback_va1__p_addr = 26;
static const char* _a_v1_feedback_va1__p_sig_output = "True";

static const int _b_bus2_v_meas_va1__n_rd_as = 13107200;
static const unsigned int _b_bus2_v_meas_va1__p_addr = 27;
static const char* _b_bus2_v_meas_va1__p_sig_output = "True";

static const int _b_injection_current_ia1__n_rd_as = 13107200;
static const unsigned int _b_injection_current_ia1__p_addr = 42;
static const char* _b_injection_current_ia1__p_sig_output = "True";

static const int _b_cic_feedback_ia1__n_rd_as = 13107200;
static const unsigned int _b_cic_feedback_ia1__p_addr = 43;
static const char* _b_cic_feedback_ia1__p_sig_output = "True";

static const int _b_cif_feedback_ia1__n_rd_as = 13107200;
static const unsigned int _b_cif_feedback_ia1__p_addr = 44;
static const char* _b_cif_feedback_ia1__p_sig_output = "True";

static const int _b_cvf_feedback_va1__n_rd_as = 13107200;
static const unsigned int _b_cvf_feedback_va1__p_addr = 28;
static const char* _b_cvf_feedback_va1__p_sig_output = "True";

static const int _b_gic_feedback_ia1__n_rd_as = 13107200;
static const unsigned int _b_gic_feedback_ia1__p_addr = 45;
static const char* _b_gic_feedback_ia1__p_sig_output = "True";

static const int _b_gif_feedback_ia1__n_rd_as = 13107200;
static const unsigned int _b_gif_feedback_ia1__p_addr = 46;
static const char* _b_gif_feedback_ia1__p_sig_output = "True";

static const int _b_gvf_feedback_va1__n_rd_as = 13107200;
static const unsigned int _b_gvf_feedback_va1__p_addr = 29;
static const char* _b_gvf_feedback_va1__p_sig_output = "True";

static const int _b_linei_feedback_ia1__n_rd_as = 13107200;
static const unsigned int _b_linei_feedback_ia1__p_addr = 47;
static const char* _b_linei_feedback_ia1__p_sig_output = "True";

static const int _b_v1_feedback_va1__n_rd_as = 13107200;
static const unsigned int _b_v1_feedback_va1__p_addr = 30;
static const char* _b_v1_feedback_va1__p_sig_output = "True";

static const int _c_bus2_v_meas_va1__n_rd_as = 13107200;
static const unsigned int _c_bus2_v_meas_va1__p_addr = 31;
static const char* _c_bus2_v_meas_va1__p_sig_output = "True";

static const int _c_injection_current_ia1__n_rd_as = 13107200;
static const unsigned int _c_injection_current_ia1__p_addr = 48;
static const char* _c_injection_current_ia1__p_sig_output = "True";

static const int _c_cic_feedback_ia1__n_rd_as = 13107200;
static const unsigned int _c_cic_feedback_ia1__p_addr = 49;
static const char* _c_cic_feedback_ia1__p_sig_output = "True";

static const int _c_cif_feedback_ia1__n_rd_as = 13107200;
static const unsigned int _c_cif_feedback_ia1__p_addr = 50;
static const char* _c_cif_feedback_ia1__p_sig_output = "True";

static const int _c_cvf_feedback_va1__n_rd_as = 13107200;
static const unsigned int _c_cvf_feedback_va1__p_addr = 32;
static const char* _c_cvf_feedback_va1__p_sig_output = "True";

static const int _c_gic_feedback_ia1__n_rd_as = 13107200;
static const unsigned int _c_gic_feedback_ia1__p_addr = 51;
static const char* _c_gic_feedback_ia1__p_sig_output = "True";

static const int _c_gif_feedback_ia1__n_rd_as = 13107200;
static const unsigned int _c_gif_feedback_ia1__p_addr = 52;
static const char* _c_gif_feedback_ia1__p_sig_output = "True";

static const int _c_gvf_feedback_va1__n_rd_as = 13107200;
static const unsigned int _c_gvf_feedback_va1__p_addr = 33;
static const char* _c_gvf_feedback_va1__p_sig_output = "True";

static const int _c_linei_feedback_ia1__n_rd_as = 13107200;
static const unsigned int _c_linei_feedback_ia1__p_addr = 53;
static const char* _c_linei_feedback_ia1__p_sig_output = "True";

static const int _c_v1_feedback_va1__n_rd_as = 13107200;
static const unsigned int _c_v1_feedback_va1__p_addr = 34;
static const char* _c_v1_feedback_va1__p_sig_output = "True";

static const int _gfm_dc_current_feedback_ia1__n_rd_as = 13107200;
static const unsigned int _gfm_dc_current_feedback_ia1__p_addr = 54;
static const char* _gfm_dc_current_feedback_ia1__p_sig_output = "True";

static const int _rect_dc_meas_va1__n_rd_as = 13107200;
static const unsigned int _rect_dc_meas_va1__p_addr = 35;
static const char* _rect_dc_meas_va1__p_sig_output = "True";

static const int _a_bus2_v__n_out_size = 1;
static const unsigned int _a_bus2_v__p_addr = 32768;

static const int _b_bus2_v__n_out_size = 1;
static const unsigned int _b_bus2_v__p_addr = 32769;

static const int _c_bus2_v__n_out_size = 1;
static const unsigned int _c_bus2_v__p_addr = 32770;

static const int _rect_dc_probe__n_out_size = 1;
static const unsigned int _rect_dc_probe__p_addr = 32795;

static const int _a_shed_injection_is1__n_rd_ds = 16252928;
static const int _a_shed_injection_is1__n_spc_baseaddr = 134217728;
static const int _a_shed_injection_is1__n_spc_do_baseaddr = 1052;
static const int _a_shed_injection_is1__n_spc_do_mem_width = 92;
static const int _a_shed_injection_is1__n_spc_dt = 2621440;
static const int _a_shed_injection_is1__n_spc_dt_sw_ctrl_val = 256;
static const int _a_shed_injection_is1__n_spc_off = 4194304;
static const int _a_shed_injection_is1__n_spc_sp = 2883584;
static const int _a_shed_injection_is1__n_spc_tv = 3145728;
static const char* _a_shed_injection_is1__n_val_of_type = "signal controlled";
static const unsigned int _a_shed_injection_is1__p_addr = 0;
static const unsigned int _a_shed_injection_is1__p_dtsm_nb = 0;
static const char* _a_shed_injection_is1__p_enable_fb_out = "False";
static const unsigned int _a_shed_injection_is1__p_spc_nb = 0;

static const int _b_shed_injection_is1__n_rd_ds = 16252928;
static const int _b_shed_injection_is1__n_spc_baseaddr = 134217728;
static const int _b_shed_injection_is1__n_spc_do_baseaddr = 1052;
static const int _b_shed_injection_is1__n_spc_do_mem_width = 92;
static const int _b_shed_injection_is1__n_spc_dt = 2621440;
static const int _b_shed_injection_is1__n_spc_dt_sw_ctrl_val = 256;
static const int _b_shed_injection_is1__n_spc_off = 4194304;
static const int _b_shed_injection_is1__n_spc_sp = 2883584;
static const int _b_shed_injection_is1__n_spc_tv = 3145728;
static const char* _b_shed_injection_is1__n_val_of_type = "signal controlled";
static const unsigned int _b_shed_injection_is1__p_addr = 1;
static const unsigned int _b_shed_injection_is1__p_dtsm_nb = 0;
static const char* _b_shed_injection_is1__p_enable_fb_out = "False";
static const unsigned int _b_shed_injection_is1__p_spc_nb = 0;

static const int _c_shed_injection_is1__n_rd_ds = 16252928;
static const int _c_shed_injection_is1__n_spc_baseaddr = 134217728;
static const int _c_shed_injection_is1__n_spc_do_baseaddr = 1052;
static const int _c_shed_injection_is1__n_spc_do_mem_width = 92;
static const int _c_shed_injection_is1__n_spc_dt = 2621440;
static const int _c_shed_injection_is1__n_spc_dt_sw_ctrl_val = 256;
static const int _c_shed_injection_is1__n_spc_off = 4194304;
static const int _c_shed_injection_is1__n_spc_sp = 2883584;
static const int _c_shed_injection_is1__n_spc_tv = 3145728;
static const char* _c_shed_injection_is1__n_val_of_type = "signal controlled";
static const unsigned int _c_shed_injection_is1__p_addr = 2;
static const unsigned int _c_shed_injection_is1__p_dtsm_nb = 0;
static const char* _c_shed_injection_is1__p_enable_fb_out = "False";
static const unsigned int _c_shed_injection_is1__p_spc_nb = 0;

static const int _control_balance_pu_s__n_out_size = 1;
static const unsigned int _control_balance_pu_s__p_addr = 32771;

static const int _control_conductance_pu__n_out_size = 1;
static const unsigned int _control_conductance_pu__p_addr = 32772;

static const int _control_dc_pu__n_out_size = 1;
static const unsigned int _control_dc_pu__p_addr = 32773;

static const int _control_feedback_ready__n_out_size = 1;
static const unsigned int _control_feedback_ready__p_addr = 32774;

static const int _control_frequency_pu__n_out_size = 1;
static const unsigned int _control_frequency_pu__p_addr = 32775;

static const int _control_ia__n_out_size = 1;
static const unsigned int _control_ia__p_addr = 32776;

static const int _control_ib__n_out_size = 1;
static const unsigned int _control_ib__p_addr = 32777;

static const int _control_ic__n_out_size = 1;
static const unsigned int _control_ic__p_addr = 32778;

static const int _control_mc__n_out_size = 1;
static const unsigned int _control_mc__p_addr = 32779;

static const int _control_mg__n_out_size = 1;
static const unsigned int _control_mg__p_addr = 32780;

static const int _control_minimum_dc_pu__n_out_size = 1;
static const unsigned int _control_minimum_dc_pu__p_addr = 32781;

static const int _control_p_filtered__n_out_size = 1;
static const unsigned int _control_p_filtered__p_addr = 32782;

static const int _control_p_gfm_mean_pu__n_out_size = 1;
static const unsigned int _control_p_gfm_mean_pu__p_addr = 32783;

static const int _control_p_gfm_pu__n_out_size = 1;
static const unsigned int _control_p_gfm_pu__p_addr = 32784;

static const int _control_p_load_mean_pu__n_out_size = 1;
static const unsigned int _control_p_load_mean_pu__p_addr = 32785;

static const int _control_p_load_pu__n_out_size = 1;
static const unsigned int _control_p_load_pu__p_addr = 32786;

static const int _control_p_losses_mean_pu__n_out_size = 1;
static const unsigned int _control_p_losses_mean_pu__p_addr = 32787;

static const int _control_p_losses_pu__n_out_size = 1;
static const unsigned int _control_p_losses_pu__p_addr = 32788;

static const int _control_peak_gfm_mod__n_out_size = 1;
static const unsigned int _control_peak_gfm_mod__p_addr = 32789;

static const int _control_peak_rectifier_mod__n_out_size = 1;
static const unsigned int _control_peak_rectifier_mod__p_addr = 32790;

static const int _control_simulation_clock_s__n_out_size = 1;
static const unsigned int _control_simulation_clock_s__p_addr = 32791;

static const int _control_stored_energy_pu_s__n_out_size = 1;
static const unsigned int _control_stored_energy_pu_s__p_addr = 32792;

static const int _control_supplied_energy_pu_s__n_out_size = 1;
static const unsigned int _control_supplied_energy_pu_s__p_addr = 32793;

static const int _control_vbus2_ll_rms_pu__n_out_size = 1;
static const unsigned int _control_vbus2_ll_rms_pu__p_addr = 32794;

static const int _gfm_pwm_bus_split1__n_num_of_outputs = 3;
static const int _gfm_pwm_bus_split1__n_prev_len[3] = {0, 2, 4};


static const int _rectifier_pwm_bus_split1__n_num_of_outputs = 3;
static const int _rectifier_pwm_bus_split1__n_prev_len[3] = {0, 2, 4};


static const int _gfm_pwm_phase_a_igbt_leg_global_gds_ovs_fsm_wrapper1__n_ctrl_spc_ts_map_reg = 46;
static const int _gfm_pwm_phase_a_igbt_leg_global_gds_ovs_fsm_wrapper1__n_hil_spc_unit_offset_val = 1048576;
static const int _gfm_pwm_phase_a_igbt_leg_global_gds_ovs_fsm_wrapper1__n_hil_unit_offset_val = 134217728;
static const int _gfm_pwm_phase_a_igbt_leg_global_gds_ovs_fsm_wrapper1__n_hil_unit_params_val = 4194304;
static const int _gfm_pwm_phase_a_igbt_leg_global_gds_ovs_fsm_wrapper1__n_spc_ts_map_params_val = 32;
static const int _gfm_pwm_phase_a_igbt_leg_global_gds_ovs_fsm_wrapper1__n_value_spc_ts_map_reg = 47;
static const int _gfm_pwm_phase_a_igbt_leg_global_gds_ovs_fsm_wrapper1__p_fsm_num = 0;
static const int _gfm_pwm_phase_a_igbt_leg_global_gds_ovs_fsm_wrapper1__p_spc_num = 0;

static const int _gfm_pwm_phase_b_igbt_leg_global_gds_ovs_fsm_wrapper1__n_ctrl_spc_ts_map_reg = 46;
static const int _gfm_pwm_phase_b_igbt_leg_global_gds_ovs_fsm_wrapper1__n_hil_spc_unit_offset_val = 1048576;
static const int _gfm_pwm_phase_b_igbt_leg_global_gds_ovs_fsm_wrapper1__n_hil_unit_offset_val = 134217728;
static const int _gfm_pwm_phase_b_igbt_leg_global_gds_ovs_fsm_wrapper1__n_hil_unit_params_val = 4194304;
static const int _gfm_pwm_phase_b_igbt_leg_global_gds_ovs_fsm_wrapper1__n_spc_ts_map_params_val = 32;
static const int _gfm_pwm_phase_b_igbt_leg_global_gds_ovs_fsm_wrapper1__n_value_spc_ts_map_reg = 47;
static const int _gfm_pwm_phase_b_igbt_leg_global_gds_ovs_fsm_wrapper1__p_fsm_num = 1;
static const int _gfm_pwm_phase_b_igbt_leg_global_gds_ovs_fsm_wrapper1__p_spc_num = 0;

static const int _gfm_pwm_phase_c_igbt_leg_global_gds_ovs_fsm_wrapper1__n_ctrl_spc_ts_map_reg = 46;
static const int _gfm_pwm_phase_c_igbt_leg_global_gds_ovs_fsm_wrapper1__n_hil_spc_unit_offset_val = 1048576;
static const int _gfm_pwm_phase_c_igbt_leg_global_gds_ovs_fsm_wrapper1__n_hil_unit_offset_val = 134217728;
static const int _gfm_pwm_phase_c_igbt_leg_global_gds_ovs_fsm_wrapper1__n_hil_unit_params_val = 4194304;
static const int _gfm_pwm_phase_c_igbt_leg_global_gds_ovs_fsm_wrapper1__n_spc_ts_map_params_val = 32;
static const int _gfm_pwm_phase_c_igbt_leg_global_gds_ovs_fsm_wrapper1__n_value_spc_ts_map_reg = 47;
static const int _gfm_pwm_phase_c_igbt_leg_global_gds_ovs_fsm_wrapper1__p_fsm_num = 2;
static const int _gfm_pwm_phase_c_igbt_leg_global_gds_ovs_fsm_wrapper1__p_spc_num = 0;

static const int _rectifier_pwm_phase_a_igbt_leg_global_gds_ovs_fsm_wrapper1__n_ctrl_spc_ts_map_reg = 46;
static const int _rectifier_pwm_phase_a_igbt_leg_global_gds_ovs_fsm_wrapper1__n_hil_spc_unit_offset_val = 1048576;
static const int _rectifier_pwm_phase_a_igbt_leg_global_gds_ovs_fsm_wrapper1__n_hil_unit_offset_val = 134217728;
static const int _rectifier_pwm_phase_a_igbt_leg_global_gds_ovs_fsm_wrapper1__n_hil_unit_params_val = 4194304;
static const int _rectifier_pwm_phase_a_igbt_leg_global_gds_ovs_fsm_wrapper1__n_spc_ts_map_params_val = 32;
static const int _rectifier_pwm_phase_a_igbt_leg_global_gds_ovs_fsm_wrapper1__n_value_spc_ts_map_reg = 47;
static const int _rectifier_pwm_phase_a_igbt_leg_global_gds_ovs_fsm_wrapper1__p_fsm_num = 3;
static const int _rectifier_pwm_phase_a_igbt_leg_global_gds_ovs_fsm_wrapper1__p_spc_num = 0;

static const int _rectifier_pwm_phase_b_igbt_leg_global_gds_ovs_fsm_wrapper1__n_ctrl_spc_ts_map_reg = 46;
static const int _rectifier_pwm_phase_b_igbt_leg_global_gds_ovs_fsm_wrapper1__n_hil_spc_unit_offset_val = 1048576;
static const int _rectifier_pwm_phase_b_igbt_leg_global_gds_ovs_fsm_wrapper1__n_hil_unit_offset_val = 134217728;
static const int _rectifier_pwm_phase_b_igbt_leg_global_gds_ovs_fsm_wrapper1__n_hil_unit_params_val = 4194304;
static const int _rectifier_pwm_phase_b_igbt_leg_global_gds_ovs_fsm_wrapper1__n_spc_ts_map_params_val = 32;
static const int _rectifier_pwm_phase_b_igbt_leg_global_gds_ovs_fsm_wrapper1__n_value_spc_ts_map_reg = 47;
static const int _rectifier_pwm_phase_b_igbt_leg_global_gds_ovs_fsm_wrapper1__p_fsm_num = 4;
static const int _rectifier_pwm_phase_b_igbt_leg_global_gds_ovs_fsm_wrapper1__p_spc_num = 0;

static const int _rectifier_pwm_phase_c_igbt_leg_global_gds_ovs_fsm_wrapper1__n_ctrl_spc_ts_map_reg = 46;
static const int _rectifier_pwm_phase_c_igbt_leg_global_gds_ovs_fsm_wrapper1__n_hil_spc_unit_offset_val = 1048576;
static const int _rectifier_pwm_phase_c_igbt_leg_global_gds_ovs_fsm_wrapper1__n_hil_unit_offset_val = 134217728;
static const int _rectifier_pwm_phase_c_igbt_leg_global_gds_ovs_fsm_wrapper1__n_hil_unit_params_val = 4194304;
static const int _rectifier_pwm_phase_c_igbt_leg_global_gds_ovs_fsm_wrapper1__n_spc_ts_map_params_val = 32;
static const int _rectifier_pwm_phase_c_igbt_leg_global_gds_ovs_fsm_wrapper1__n_value_spc_ts_map_reg = 47;
static const int _rectifier_pwm_phase_c_igbt_leg_global_gds_ovs_fsm_wrapper1__p_fsm_num = 5;
static const int _rectifier_pwm_phase_c_igbt_leg_global_gds_ovs_fsm_wrapper1__p_spc_num = 0;


//@cmp.var.start
// variables
real _a_bus2_v_meas_va1__out;
real _a_injection_current_ia1__out;
real _a_cic_feedback_ia1__out;
real _a_cif_feedback_ia1__out;
real _a_cvf_feedback_va1__out;
real _a_gic_feedback_ia1__out;
real _a_gif_feedback_ia1__out;
real _a_gvf_feedback_va1__out;
real _a_linei_feedback_ia1__out;
real _a_v1_feedback_va1__out;
real _b_bus2_v_meas_va1__out;
real _b_injection_current_ia1__out;
real _b_cic_feedback_ia1__out;
real _b_cif_feedback_ia1__out;
real _b_cvf_feedback_va1__out;
real _b_gic_feedback_ia1__out;
real _b_gif_feedback_ia1__out;
real _b_gvf_feedback_va1__out;
real _b_linei_feedback_ia1__out;
real _b_v1_feedback_va1__out;
real _c_bus2_v_meas_va1__out;
real _c_injection_current_ia1__out;
real _c_cic_feedback_ia1__out;
real _c_cif_feedback_ia1__out;
real _c_cvf_feedback_va1__out;
real _c_gic_feedback_ia1__out;
real _c_gif_feedback_ia1__out;
real _c_gvf_feedback_va1__out;
real _c_linei_feedback_ia1__out;
real _c_v1_feedback_va1__out;
real _gfm_dc_current_feedback_ia1__out;
real _rect_dc_meas_va1__out;
double _shed_dg__out;












double _segan_controller__cic_a;
double _segan_controller__cic_b;
double _segan_controller__cic_c;
double _segan_controller__cif_a;
double _segan_controller__cif_b;
double _segan_controller__cif_c;
double _segan_controller__cvf_a;
double _segan_controller__cvf_b;
double _segan_controller__cvf_c;
double _segan_controller__dc;
double _segan_controller__gic_a;
double _segan_controller__gic_b;
double _segan_controller__gic_c;
double _segan_controller__gif_a;
double _segan_controller__gif_b;
double _segan_controller__gif_c;
double _segan_controller__gvf_a;
double _segan_controller__gvf_b;
double _segan_controller__gvf_c;
double _segan_controller__idc_g;
double _segan_controller__inj_a;
double _segan_controller__inj_b;
double _segan_controller__inj_c;
double _segan_controller__linei_a;
double _segan_controller__linei_b;
double _segan_controller__linei_c;
double _segan_controller__shed_dg;
double _segan_controller__v1_a;
double _segan_controller__v1_b;
double _segan_controller__v1_c;
double _segan_controller__v2_a;
double _segan_controller__v2_b;
double _segan_controller__v2_c;

double _segan_controller__balance_pu_s;
double _segan_controller__c[6];
double _segan_controller__conductance_pu;
double _segan_controller__dc_pu;
double _segan_controller__feedback_ready;
double _segan_controller__frequency_pu;
double _segan_controller__g[6];
double _segan_controller__ia;
double _segan_controller__ib;
double _segan_controller__ic;
double _segan_controller__mc;
double _segan_controller__mg;
double _segan_controller__minimum_dc_pu;
double _segan_controller__p_filtered;
double _segan_controller__p_gfm_mean_pu;
double _segan_controller__p_gfm_pu;
double _segan_controller__p_load_mean_pu;
double _segan_controller__p_load_pu;
double _segan_controller__p_losses_mean_pu;
double _segan_controller__p_losses_pu;
double _segan_controller__peak_gfm_mod;
double _segan_controller__peak_rectifier_mod;
double _segan_controller__simulation_clock_s;
double _segan_controller__stored_energy_pu_s;
double _segan_controller__supplied_energy_pu_s;
double _segan_controller__vbus2_ll_rms_pu;












































































static real _gfm_pwm_bus_split1__out[2];
static real _gfm_pwm_bus_split1__out1[2];
static real _gfm_pwm_bus_split1__out2[2];
static real _rectifier_pwm_bus_split1__out[2];
static real _rectifier_pwm_bus_split1__out1[2];
static real _rectifier_pwm_bus_split1__out2[2];






//@cmp.var.end

//@cmp.svar.start
// state variables












































































































double _segan_controller__sx[32];

double _segan_controller__dx[32];

double _segan_controller__u[6];

double _segan_controller__applied[4];

double _segan_controller__pending[4];

double _segan_controller__theta;

X_Int32 _segan_controller__carrier_tick;

X_Int32 _segan_controller__elapsed_tick;

X_Int32 _segan_controller__window_index;

double _segan_controller__audit_values[4];

double _segan_controller__netpower;

double _segan_controller__prevnet;

double _segan_controller__balance_state;

double _segan_controller__balance_now;

double _segan_controller__peakg_state;

double _segan_controller__peakc_state;

double _segan_controller__mindc_state;

double _segan_controller__pacc_in;

double _segan_controller__pacc_load;

double _segan_controller__pacc_loss;

double _segan_controller__pmean_in;

double _segan_controller__pmean_load;

double _segan_controller__pmean_loss;

double _segan_controller__input_energy_state;

double _segan_controller__input_energy_now;

double _segan_controller__prevpin;

double _segan_controller__v2d_buffer[666667];

double _segan_controller__v2q_buffer[666667];

double _segan_controller__window_d_sum;

double _segan_controller__window_q_sum;

double _segan_controller__window_d_new;

double _segan_controller__window_q_new;













































































































//@cmp.svar.end

// IO shared variables

//
// Tunable parameters
//
static struct Tunable_params {
} __attribute__((__packed__)) tunable_params;

void *tunable_params_dev0_cpu0_ptr = &tunable_params;

// Dll function pointers
#if defined(_WIN64)
#else
// Define handles for loading dlls
#endif





// generated using template: \templates\virtual_hil\fmi_custom_logger_fncs.template---------------------------------
#include <stdarg.h>



//
// DMA buffers
//





































































































































































































































































































// generated using template: virtual_hil/custom_functions.template---------------------------------
void ReInit_user_sp_cpu0_dev0() {
#if DEBUG_MODE
    printf("\n\rReInitTimer");
#endif
    //@cmp.init.block.start
    {
        HIL_OutAO(0x8000, 0);
    }
    {
        HIL_OutAO(0x8001, 0);
    }
    {
        HIL_OutAO(0x8002, 0);
    }
    {
        HIL_OutAO(0x801b, 0);
    }
    {
        int  j;
        _segan_controller__sx [ 0 ] = 1 ;
        _segan_controller__dx [ 0 ] = 0 ;
        _segan_controller__sx [ 1 ] = - 5.538573885029171e-23 ;
        _segan_controller__dx [ 1 ] = 0 ;
        _segan_controller__sx [ 2 ] = 0.98464501635366675 ;
        _segan_controller__dx [ 2 ] = 0 ;
        _segan_controller__sx [ 3 ] = - 0.08458243392700053 ;
        _segan_controller__dx [ 3 ] = 0 ;
        _segan_controller__sx [ 4 ] = 0.85265279496667168 ;
        _segan_controller__dx [ 4 ] = 0 ;
        _segan_controller__sx [ 5 ] = - 0.068284556966665452 ;
        _segan_controller__dx [ 5 ] = 0 ;
        _segan_controller__sx [ 6 ] = 0.85996301220582116 ;
        _segan_controller__dx [ 6 ] = 0 ;
        _segan_controller__sx [ 7 ] = 0.20948890174965429 ;
        _segan_controller__dx [ 7 ] = 0 ;
        _segan_controller__sx [ 8 ] = 0.0010734815794299286 ;
        _segan_controller__dx [ 8 ] = 0 ;
        _segan_controller__sx [ 9 ] = - 0.00044400764063214684 ;
        _segan_controller__dx [ 9 ] = 0 ;
        _segan_controller__sx [ 10 ] = 0.071712908360468203 ;
        _segan_controller__dx [ 10 ] = 0 ;
        _segan_controller__sx [ 11 ] = - 0.011102778429811971 ;
        _segan_controller__dx [ 11 ] = 0 ;
        _segan_controller__sx [ 12 ] = 1.0230892625668688 ;
        _segan_controller__dx [ 12 ] = 0 ;
        _segan_controller__sx [ 13 ] = - 0.15801648849208549 ;
        _segan_controller__dx [ 13 ] = 0 ;
        _segan_controller__sx [ 14 ] = 0.84008036417332033 ;
        _segan_controller__dx [ 14 ] = 0 ;
        _segan_controller__sx [ 15 ] = 0.012283017544716534 ;
        _segan_controller__dx [ 15 ] = 0 ;
        _segan_controller__sx [ 16 ] = 1.0211834393429997 ;
        _segan_controller__dx [ 16 ] = 0 ;
        _segan_controller__sx [ 17 ] = 0.16989771342366769 ;
        _segan_controller__dx [ 17 ] = 0 ;
        _segan_controller__sx [ 18 ] = 0.85265279496667168 ;
        _segan_controller__dx [ 18 ] = 0 ;
        _segan_controller__sx [ 19 ] = - 0.063284556966665462 ;
        _segan_controller__dx [ 19 ] = 0 ;
        _segan_controller__sx [ 20 ] = - 0.10187080675492161 ;
        _segan_controller__dx [ 20 ] = 0 ;
        _segan_controller__sx [ 21 ] = - 3.5467048952525496e-18 ;
        _segan_controller__dx [ 21 ] = 0 ;
        _segan_controller__sx [ 22 ] = 4.6481223629626167e-05 ;
        _segan_controller__dx [ 22 ] = 0 ;
        _segan_controller__sx [ 23 ] = 1.083752015411515 ;
        _segan_controller__dx [ 23 ] = 0 ;
        _segan_controller__sx [ 24 ] = 0.00047290025503105422 ;
        _segan_controller__dx [ 24 ] = 0 ;
        _segan_controller__sx [ 25 ] = 1.2214237280228431e-07 ;
        _segan_controller__dx [ 25 ] = 0 ;
        _segan_controller__sx [ 26 ] = 0.65049235974302999 ;
        _segan_controller__dx [ 26 ] = 0 ;
        _segan_controller__sx [ 27 ] = - 0.10333003665270064 ;
        _segan_controller__dx [ 27 ] = 0 ;
        _segan_controller__sx [ 28 ] = 0.98191684097556575 ;
        _segan_controller__dx [ 28 ] = 0 ;
        _segan_controller__sx [ 29 ] = - 0.10037612435772839 ;
        _segan_controller__dx [ 29 ] = 0 ;
        _segan_controller__sx [ 30 ] = 0.65530087952630334 ;
        _segan_controller__dx [ 30 ] = 0 ;
        _segan_controller__sx [ 31 ] = - 0.056291295263033683 ;
        _segan_controller__dx [ 31 ] = 0 ;
        _segan_controller__applied [ 0 ] = 1.0227210390319423 ;
        _segan_controller__pending [ 0 ] = 1.0227210390319423 ;
        _segan_controller__applied [ 1 ] = 0.23714099161016747 ;
        _segan_controller__pending [ 1 ] = 0.23714099161016747 ;
        _segan_controller__applied [ 2 ] = 0.97120738114383098 ;
        _segan_controller__pending [ 2 ] = 0.97120738114383098 ;
        _segan_controller__applied [ 3 ] = - 0.13872069731231201 ;
        _segan_controller__pending [ 3 ] = - 0.13872069731231201 ;
        _segan_controller__theta = 0 ;
        _segan_controller__carrier_tick = 0 ;
        _segan_controller__elapsed_tick = 0 ;
        _segan_controller__window_index = 0 ;
        _segan_controller__balance_state = 0 ;
        _segan_controller__prevnet = 0 ;
        _segan_controller__window_d_sum = 666667.0 * _segan_controller__sx [ 2 ] ;
        _segan_controller__window_q_sum = 666667.0 * _segan_controller__sx [ 3 ] ;
        for ( j = 0 ; j < 666667 ; j ++ )     {
            _segan_controller__v2d_buffer [ j ] = _segan_controller__sx [ 2 ] ;
            _segan_controller__v2q_buffer [ j ] = _segan_controller__sx [ 3 ] ;
        }
        _segan_controller__peakg_state = 0 ;
        _segan_controller__peakc_state = 0 ;
        _segan_controller__mindc_state = 1.083752015411515 ;
        _segan_controller__pacc_in = 0 ;
        _segan_controller__pacc_load = 0 ;
        _segan_controller__pacc_loss = 0 ;
        _segan_controller__pmean_in = 0 ;
        _segan_controller__pmean_load = 0 ;
        _segan_controller__pmean_loss = 0 ;
        _segan_controller__input_energy_state = 0 ;
        _segan_controller__prevpin = 0 ;
    }
    {
        HIL_OutFloat(0x82c0000, 0.0);
    }
    {
        HIL_OutFloat(0x82c0001, 0.0);
    }
    {
        HIL_OutFloat(0x82c0002, 0.0);
    }
    {
        HIL_OutAO(0x8003, 0);
    }
    {
        HIL_OutAO(0x8004, 0);
    }
    {
        HIL_OutAO(0x8005, 0);
    }
    {
        HIL_OutAO(0x8006, 0);
    }
    {
        HIL_OutAO(0x8007, 0);
    }
    {
        HIL_OutAO(0x8008, 0);
    }
    {
        HIL_OutAO(0x8009, 0);
    }
    {
        HIL_OutAO(0x800a, 0);
    }
    {
        HIL_OutAO(0x800b, 0);
    }
    {
        HIL_OutAO(0x800c, 0);
    }
    {
        HIL_OutAO(0x800d, 0);
    }
    {
        HIL_OutAO(0x800e, 0);
    }
    {
        HIL_OutAO(0x800f, 0);
    }
    {
        HIL_OutAO(0x8010, 0);
    }
    {
        HIL_OutAO(0x8011, 0);
    }
    {
        HIL_OutAO(0x8012, 0);
    }
    {
        HIL_OutAO(0x8013, 0);
    }
    {
        HIL_OutAO(0x8014, 0);
    }
    {
        HIL_OutAO(0x8015, 0);
    }
    {
        HIL_OutAO(0x8016, 0);
    }
    {
        HIL_OutAO(0x8017, 0);
    }
    {
        HIL_OutAO(0x8018, 0);
    }
    {
        HIL_OutAO(0x8019, 0);
    }
    {
        HIL_OutAO(0x801a, 0);
    }
    {
        {
            HIL_OutInt32(0x810002e, 3);
        }
    }
    {
        {
            HIL_OutInt32(0x810004e, 3);
        }
    }
    {
        {
            HIL_OutInt32(0x810006e, 3);
        }
    }
    {
        {
            HIL_OutInt32(0x810008e, 3);
        }
    }
    {
        {
            HIL_OutInt32(0x81000ae, 3);
        }
    }
    {
        {
            HIL_OutInt32(0x81000ce, 3);
        }
    }
    //@cmp.init.block.end
}


// Dll function pointers and dll reload function
#if defined(_WIN64)
// Define method for reloading dll functions
void ReloadDllFunctions_user_sp_cpu0_dev0(void) {
    // Load each library and setup function pointers
}

void FreeDllFunctions_user_sp_cpu0_dev0(void) {
}

#else
// Define method for reloading dll functions
void ReloadDllFunctions_user_sp_cpu0_dev0(void) {
    // Load each library and setup function pointers
}

void FreeDllFunctions_user_sp_cpu0_dev0(void) {
}
#endif

void load_fmi_libraries_user_sp_cpu0_dev0(void) {
#if defined(_WIN64)
#else
#endif
}


void ReInit_sp_scope_user_sp_cpu0_dev0() {
    // initialise SP Scope buffer pointer
}


// generated using template: virtual_hil/common_timer_counter_handler.template-------------------------

/*****************************************************************************************/
/**
* This function is the handler which performs processing for the timer counter.
* It is called from an interrupt context such that the amount of processing
* performed should be minimized.  It is called when the timer counter expires
* if interrupts are enabled.
*
*
* @param    None
*
* @return   None
*
* @note     None
*
*****************************************************************************************/

void TimerCounterHandler_0_user_sp_cpu0_dev0() {
#if DEBUG_MODE
    printf("\n\rTimerCounterHandler_0");
#endif
    //////////////////////////////////////////////////////////////////////////
    // Output block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.out.block.start
    // Generated from the component: A_Bus2_V_Meas.Va1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc80017);
        _a_bus2_v_meas_va1__out = tac_tmp1;
    }
    // Generated from the component: A_Injection_Current.Ia1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc80024);
        _a_injection_current_ia1__out = tac_tmp1;
    }
    // Generated from the component: A_cic_Feedback.Ia1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc80025);
        _a_cic_feedback_ia1__out = tac_tmp1;
    }
    // Generated from the component: A_cif_Feedback.Ia1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc80026);
        _a_cif_feedback_ia1__out = tac_tmp1;
    }
    // Generated from the component: A_cvf_Feedback.Va1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc80018);
        _a_cvf_feedback_va1__out = tac_tmp1;
    }
    // Generated from the component: A_gic_Feedback.Ia1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc80027);
        _a_gic_feedback_ia1__out = tac_tmp1;
    }
    // Generated from the component: A_gif_Feedback.Ia1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc80028);
        _a_gif_feedback_ia1__out = tac_tmp1;
    }
    // Generated from the component: A_gvf_Feedback.Va1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc80019);
        _a_gvf_feedback_va1__out = tac_tmp1;
    }
    // Generated from the component: A_linei_Feedback.Ia1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc80029);
        _a_linei_feedback_ia1__out = tac_tmp1;
    }
    // Generated from the component: A_v1_Feedback.Va1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc8001a);
        _a_v1_feedback_va1__out = tac_tmp1;
    }
    // Generated from the component: B_Bus2_V_Meas.Va1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc8001b);
        _b_bus2_v_meas_va1__out = tac_tmp1;
    }
    // Generated from the component: B_Injection_Current.Ia1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc8002a);
        _b_injection_current_ia1__out = tac_tmp1;
    }
    // Generated from the component: B_cic_Feedback.Ia1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc8002b);
        _b_cic_feedback_ia1__out = tac_tmp1;
    }
    // Generated from the component: B_cif_Feedback.Ia1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc8002c);
        _b_cif_feedback_ia1__out = tac_tmp1;
    }
    // Generated from the component: B_cvf_Feedback.Va1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc8001c);
        _b_cvf_feedback_va1__out = tac_tmp1;
    }
    // Generated from the component: B_gic_Feedback.Ia1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc8002d);
        _b_gic_feedback_ia1__out = tac_tmp1;
    }
    // Generated from the component: B_gif_Feedback.Ia1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc8002e);
        _b_gif_feedback_ia1__out = tac_tmp1;
    }
    // Generated from the component: B_gvf_Feedback.Va1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc8001d);
        _b_gvf_feedback_va1__out = tac_tmp1;
    }
    // Generated from the component: B_linei_Feedback.Ia1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc8002f);
        _b_linei_feedback_ia1__out = tac_tmp1;
    }
    // Generated from the component: B_v1_Feedback.Va1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc8001e);
        _b_v1_feedback_va1__out = tac_tmp1;
    }
    // Generated from the component: C_Bus2_V_Meas.Va1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc8001f);
        _c_bus2_v_meas_va1__out = tac_tmp1;
    }
    // Generated from the component: C_Injection_Current.Ia1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc80030);
        _c_injection_current_ia1__out = tac_tmp1;
    }
    // Generated from the component: C_cic_Feedback.Ia1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc80031);
        _c_cic_feedback_ia1__out = tac_tmp1;
    }
    // Generated from the component: C_cif_Feedback.Ia1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc80032);
        _c_cif_feedback_ia1__out = tac_tmp1;
    }
    // Generated from the component: C_cvf_Feedback.Va1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc80020);
        _c_cvf_feedback_va1__out = tac_tmp1;
    }
    // Generated from the component: C_gic_Feedback.Ia1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc80033);
        _c_gic_feedback_ia1__out = tac_tmp1;
    }
    // Generated from the component: C_gif_Feedback.Ia1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc80034);
        _c_gif_feedback_ia1__out = tac_tmp1;
    }
    // Generated from the component: C_gvf_Feedback.Va1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc80021);
        _c_gvf_feedback_va1__out = tac_tmp1;
    }
    // Generated from the component: C_linei_Feedback.Ia1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc80035);
        _c_linei_feedback_ia1__out = tac_tmp1;
    }
    // Generated from the component: C_v1_Feedback.Va1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc80022);
        _c_v1_feedback_va1__out = tac_tmp1;
    }
    // Generated from the component: GFM_DC_Current_Feedback.Ia1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc80036);
        _gfm_dc_current_feedback_ia1__out = tac_tmp1;
    }
    // Generated from the component: Rect_DC_Meas.Va1
    {
        real tac_tmp1;
        tac_tmp1 = HIL_InFloat(0xc80023);
        _rect_dc_meas_va1__out = tac_tmp1;
    }
    // Generated from the component: Shed_dG
    _shed_dg__out = XIo_InFloat(0x2f800000);
    // Generated from the component: A_Bus2_V
    {
        HIL_OutAO(0x8000, _a_bus2_v_meas_va1__out);
    }
    // Generated from the component: B_Bus2_V
    {
        HIL_OutAO(0x8001, _b_bus2_v_meas_va1__out);
    }
    // Generated from the component: C_Bus2_V
    {
        HIL_OutAO(0x8002, _c_bus2_v_meas_va1__out);
    }
    // Generated from the component: Rect_DC_Probe
    {
        HIL_OutAO(0x801b, _rect_dc_meas_va1__out);
    }
    // Generated from the component: SEGAN_Controller
    _segan_controller__cic_a = _a_cic_feedback_ia1__out;
    _segan_controller__cic_b = _b_cic_feedback_ia1__out;
    _segan_controller__cic_c = _c_cic_feedback_ia1__out;
    _segan_controller__cif_a = _a_cif_feedback_ia1__out;
    _segan_controller__cif_b = _b_cif_feedback_ia1__out;
    _segan_controller__cif_c = _c_cif_feedback_ia1__out;
    _segan_controller__cvf_a = _a_cvf_feedback_va1__out;
    _segan_controller__cvf_b = _b_cvf_feedback_va1__out;
    _segan_controller__cvf_c = _c_cvf_feedback_va1__out;
    _segan_controller__dc = _rect_dc_meas_va1__out;
    _segan_controller__gic_a = _a_gic_feedback_ia1__out;
    _segan_controller__gic_b = _b_gic_feedback_ia1__out;
    _segan_controller__gic_c = _c_gic_feedback_ia1__out;
    _segan_controller__gif_a = _a_gif_feedback_ia1__out;
    _segan_controller__gif_b = _b_gif_feedback_ia1__out;
    _segan_controller__gif_c = _c_gif_feedback_ia1__out;
    _segan_controller__gvf_a = _a_gvf_feedback_va1__out;
    _segan_controller__gvf_b = _b_gvf_feedback_va1__out;
    _segan_controller__gvf_c = _c_gvf_feedback_va1__out;
    _segan_controller__idc_g = _gfm_dc_current_feedback_ia1__out;
    _segan_controller__inj_a = _a_injection_current_ia1__out;
    _segan_controller__inj_b = _b_injection_current_ia1__out;
    _segan_controller__inj_c = _c_injection_current_ia1__out;
    _segan_controller__linei_a = _a_linei_feedback_ia1__out;
    _segan_controller__linei_b = _b_linei_feedback_ia1__out;
    _segan_controller__linei_c = _c_linei_feedback_ia1__out;
    _segan_controller__shed_dg = _shed_dg__out;
    _segan_controller__v1_a = _a_v1_feedback_va1__out;
    _segan_controller__v1_b = _b_v1_feedback_va1__out;
    _segan_controller__v1_c = _c_v1_feedback_va1__out;
    _segan_controller__v2_a = _a_bus2_v_meas_va1__out;
    _segan_controller__v2_b = _b_bus2_v_meas_va1__out;
    _segan_controller__v2_c = _c_bus2_v_meas_va1__out;
    {
        real  rr [ 6 ] , cfg [ 34 ] , rg [ 3 ] , rc [ 3 ] , mxg , mng , mxc , mnc , ph , tri , alpha , beta , removed_g , injected_power;
        int  k;
        rr [ 0 ] = 0.85996301220582116 ;
        rr [ 1 ] = 0.20948890174965429 ;
        rr [ 2 ] = 1.0884471872679209 ;
        rr [ 3 ] = 1.083752015411515 ;
        rr [ 4 ] = - 0.036642711840683483 ;
        rr [ 5 ] = 0.31810277326686631 ;
        cfg [ 0 ] = 0.01 ;
        cfg [ 1 ] = 0.10000000000000001 ;
        cfg [ 2 ] = 0.0050000000000000001 ;
        cfg [ 3 ] = 1.8178670360110802 ;
        cfg [ 4 ] = 29.614009520763741 ;
        cfg [ 5 ] = 1.1119394227107848 ;
        cfg [ 6 ] = 0.02 ;
        cfg [ 7 ] = 0.050000000000000003 ;
        cfg [ 8 ] = 125.66370614359172 ;
        cfg [ 9 ] = 125.66370614359172 ;
        cfg [ 10 ] = 0 ;
        cfg [ 11 ] = 0.20000000000000001 ;
        cfg [ 12 ] = 0.58999999999999997 ;
        cfg [ 13 ] = 736 ;
        cfg [ 14 ] = 1.27 ;
        cfg [ 15 ] = 14.300000000000001 ;
        cfg [ 16 ] = 50 ;
        cfg [ 17 ] = 0.20000000000000001 ;
        cfg [ 18 ] = 0.080000000000000002 ;
        cfg [ 19 ] = 0.0030000000000000001 ;
        cfg [ 20 ] = 0.073999999999999996 ;
        cfg [ 21 ] = 0.20000000000000001 ;
        cfg [ 22 ] = 0.01 ;
        cfg [ 23 ] = 0.060047061799915702 ;
        cfg [ 24 ] = 0.0069252077562326868 ;
        cfg [ 25 ] = 0.047905015401235471 ;
        cfg [ 26 ] = 0.024279898901705045 ;
        cfg [ 27 ] = 0.0020775623268698058 ;
        cfg [ 28 ] = 1.0387811634349029 ;
        cfg [ 29 ] = 2077.5623268698059 ;
        cfg [ 30 ] = 0.40000000000000002 ;
        cfg [ 31 ] = 4.6900000000000004 ;
        cfg [ 32 ] = 47.160842514385457 ;
        cfg [ 33 ] = 14148.252754315638 ;
        if ( _segan_controller__elapsed_tick > 0 )     {
            alpha = 0.81649658092772603273 * ( _segan_controller__gvf_a - 0.5 * _segan_controller__gvf_b - 0.5 * _segan_controller__gvf_c ) / 380 ;
            beta = 0.70710678118654752440 * ( _segan_controller__gvf_b - _segan_controller__gvf_c ) / 380 ;
            _segan_controller__sx [ 16 ] = alpha * cos ( _segan_controller__theta ) + beta * sin ( _segan_controller__theta ) ;
            _segan_controller__sx [ 17 ] = - alpha * sin ( _segan_controller__theta ) + beta * cos ( _segan_controller__theta ) ;
            alpha = 0.81649658092772603273 * ( _segan_controller__gic_a - 0.5 * _segan_controller__gic_b - 0.5 * _segan_controller__gic_c ) / 26.315789473684209 ;
            beta = 0.70710678118654752440 * ( _segan_controller__gic_b - _segan_controller__gic_c ) / 26.315789473684209 ;
            _segan_controller__sx [ 14 ] = alpha * cos ( _segan_controller__theta ) + beta * sin ( _segan_controller__theta ) ;
            _segan_controller__sx [ 15 ] = - alpha * sin ( _segan_controller__theta ) + beta * cos ( _segan_controller__theta ) ;
            alpha = 0.81649658092772603273 * ( _segan_controller__gif_a - 0.5 * _segan_controller__gif_b - 0.5 * _segan_controller__gif_c ) / 26.315789473684209 ;
            beta = 0.70710678118654752440 * ( _segan_controller__gif_b - _segan_controller__gif_c ) / 26.315789473684209 ;
            _segan_controller__sx [ 18 ] = alpha * cos ( _segan_controller__theta ) + beta * sin ( _segan_controller__theta ) ;
            _segan_controller__sx [ 19 ] = - alpha * sin ( _segan_controller__theta ) + beta * cos ( _segan_controller__theta ) ;
            alpha = 0.81649658092772603273 * ( _segan_controller__cvf_a - 0.5 * _segan_controller__cvf_b - 0.5 * _segan_controller__cvf_c ) / 380 ;
            beta = 0.70710678118654752440 * ( _segan_controller__cvf_b - _segan_controller__cvf_c ) / 380 ;
            _segan_controller__sx [ 28 ] = alpha * cos ( _segan_controller__theta ) + beta * sin ( _segan_controller__theta ) ;
            _segan_controller__sx [ 29 ] = - alpha * sin ( _segan_controller__theta ) + beta * cos ( _segan_controller__theta ) ;
            alpha = 0.81649658092772603273 * ( _segan_controller__cic_a - 0.5 * _segan_controller__cic_b - 0.5 * _segan_controller__cic_c ) / 26.315789473684209 ;
            beta = 0.70710678118654752440 * ( _segan_controller__cic_b - _segan_controller__cic_c ) / 26.315789473684209 ;
            _segan_controller__sx [ 26 ] = alpha * cos ( _segan_controller__theta ) + beta * sin ( _segan_controller__theta ) ;
            _segan_controller__sx [ 27 ] = - alpha * sin ( _segan_controller__theta ) + beta * cos ( _segan_controller__theta ) ;
            alpha = 0.81649658092772603273 * ( _segan_controller__v1_a - 0.5 * _segan_controller__v1_b - 0.5 * _segan_controller__v1_c ) / 380 ;
            beta = 0.70710678118654752440 * ( _segan_controller__v1_b - _segan_controller__v1_c ) / 380 ;
            _segan_controller__sx [ 0 ] = alpha * cos ( _segan_controller__theta ) + beta * sin ( _segan_controller__theta ) ;
            _segan_controller__sx [ 1 ] = - alpha * sin ( _segan_controller__theta ) + beta * cos ( _segan_controller__theta ) ;
            alpha = 0.81649658092772603273 * ( _segan_controller__v2_a - 0.5 * _segan_controller__v2_b - 0.5 * _segan_controller__v2_c ) / 380 ;
            beta = 0.70710678118654752440 * ( _segan_controller__v2_b - _segan_controller__v2_c ) / 380 ;
            _segan_controller__sx [ 2 ] = alpha * cos ( _segan_controller__theta ) + beta * sin ( _segan_controller__theta ) ;
            _segan_controller__sx [ 3 ] = - alpha * sin ( _segan_controller__theta ) + beta * cos ( _segan_controller__theta ) ;
            alpha = 0.81649658092772603273 * ( _segan_controller__linei_a - 0.5 * _segan_controller__linei_b - 0.5 * _segan_controller__linei_c ) / 26.315789473684209 ;
            beta = 0.70710678118654752440 * ( _segan_controller__linei_b - _segan_controller__linei_c ) / 26.315789473684209 ;
            _segan_controller__sx [ 4 ] = alpha * cos ( _segan_controller__theta ) + beta * sin ( _segan_controller__theta ) ;
            _segan_controller__sx [ 5 ] = - alpha * sin ( _segan_controller__theta ) + beta * cos ( _segan_controller__theta ) ;
            alpha = 0.81649658092772603273 * ( _segan_controller__cif_a - 0.5 * _segan_controller__cif_b - 0.5 * _segan_controller__cif_c ) / 26.315789473684209 ;
            beta = 0.70710678118654752440 * ( _segan_controller__cif_b - _segan_controller__cif_c ) / 26.315789473684209 ;
            _segan_controller__sx [ 30 ] = alpha * cos ( _segan_controller__theta ) + beta * sin ( _segan_controller__theta ) ;
            _segan_controller__sx [ 31 ] = - alpha * sin ( _segan_controller__theta ) + beta * cos ( _segan_controller__theta ) ;
            _segan_controller__sx [ 23 ] = _segan_controller__dc / 620.5374015050718 ;
        }
        segan_control_math ( _segan_controller__sx , rr , cfg , _segan_controller__u , _segan_controller__dx ) ;
        _segan_controller__simulation_clock_s = ( ( real  ) _segan_controller__elapsed_tick ) * 2.4999999999999999e-08 ;
        _segan_controller__feedback_ready = ( _segan_controller__elapsed_tick > 0 ) ? 1.0 : 0.0 ;
        for ( k = 0 ; k < 3 ; k ++ )     {
            ph = _segan_controller__theta - ( 2.0 * 3.14159265358979323846 / 3.0 ) * k ;
            rg [ k ] = ( _segan_controller__applied [ 0 ] * cos ( ph ) - _segan_controller__applied [ 1 ] * sin ( ph ) ) / cfg [ 5 ] ;
            rc [ k ] = ( _segan_controller__applied [ 2 ] * cos ( ph ) - _segan_controller__applied [ 3 ] * sin ( ph ) ) / _segan_controller__sx [ 23 ] ;
        }
        mxg = fmax ( rg [ 0 ] , fmax ( rg [ 1 ] , rg [ 2 ] ) ) ;
        mng = fmin ( rg [ 0 ] , fmin ( rg [ 1 ] , rg [ 2 ] ) ) ;
        mxc = fmax ( rc [ 0 ] , fmax ( rc [ 1 ] , rc [ 2 ] ) ) ;
        mnc = fmin ( rc [ 0 ] , fmin ( rc [ 1 ] , rc [ 2 ] ) ) ;
        tri = 1.0 - 4.0 * fabs ( ( ( real  ) _segan_controller__carrier_tick ) / 2000.0 - 0.5 ) ;
        _segan_controller__mg = 0 ;
        _segan_controller__mc = 0 ;
        for ( k = 0 ; k < 3 ; k ++ )     {
            rg [ k ] -= 0.5 * ( mxg + mng ) ;
            rc [ k ] -= 0.5 * ( mxc + mnc ) ;
            _segan_controller__mg = fmax ( _segan_controller__mg , fabs ( rg [ k ] ) ) ;
            _segan_controller__mc = fmax ( _segan_controller__mc , fabs ( rc [ k ] ) ) ;
            _segan_controller__g [ 2 * k ] = ( rg [ k ] > tri ) ? 1.0 : 0.0 ;
            _segan_controller__g [ 2 * k + 1 ] = 1.0 - _segan_controller__g [ 2 * k ] ;
            _segan_controller__c [ 2 * k ] = ( rc [ k ] > tri ) ? 1.0 : 0.0 ;
            _segan_controller__c [ 2 * k + 1 ] = 1.0 - _segan_controller__c [ 2 * k ] ;
        }
        _segan_controller__frequency_pu = _segan_controller__u [ 4 ] ;
        _segan_controller__p_filtered = _segan_controller__sx [ 6 ] ;
        _segan_controller__dc_pu = _segan_controller__sx [ 23 ] ;
        _segan_controller__peak_gfm_mod = fmax ( _segan_controller__peakg_state , _segan_controller__mg ) ;
        _segan_controller__peak_rectifier_mod = fmax ( _segan_controller__peakc_state , _segan_controller__mc ) ;
        _segan_controller__minimum_dc_pu = fmin ( _segan_controller__mindc_state , _segan_controller__dc_pu ) ;
        removed_g = _segan_controller__shed_dg * fmin ( 1.0 , ( ( real  ) _segan_controller__elapsed_tick ) * 2.4999999999999999e-08 / 0.25 ) ;
        _segan_controller__conductance_pu = 0.20000000000000001 - removed_g ;
        _segan_controller__ia = removed_g * _segan_controller__v2_a / 14.44 ;
        _segan_controller__ib = removed_g * _segan_controller__v2_b / 14.44 ;
        _segan_controller__ic = removed_g * _segan_controller__v2_c / 14.44 ;
        injected_power = ( _segan_controller__v2_a * _segan_controller__inj_a + _segan_controller__v2_b * _segan_controller__inj_b + _segan_controller__v2_c * _segan_controller__inj_c ) / 10000.0 ;
        segan_energy_math ( _segan_controller__sx , cfg , 0.20000000000000001 , injected_power , _segan_controller__idc_g , _segan_controller__audit_values ) ;
        _segan_controller__stored_energy_pu_s = _segan_controller__audit_values [ 0 ] ;
        _segan_controller__p_gfm_pu = _segan_controller__audit_values [ 1 ] ;
        _segan_controller__p_load_pu = _segan_controller__audit_values [ 2 ] ;
        _segan_controller__p_losses_pu = _segan_controller__audit_values [ 3 ] ;
        _segan_controller__netpower = _segan_controller__p_gfm_pu - _segan_controller__p_load_pu - _segan_controller__p_losses_pu ;
        _segan_controller__balance_now = _segan_controller__balance_state ;
        if ( _segan_controller__elapsed_tick > 0 ) _segan_controller__balance_now += 0.5 * 2.4999999999999999e-08 * ( _segan_controller__prevnet + _segan_controller__netpower ) ;
        _segan_controller__balance_pu_s = _segan_controller__balance_now ;
        _segan_controller__input_energy_now = _segan_controller__input_energy_state ;
        if ( _segan_controller__elapsed_tick > 0 ) _segan_controller__input_energy_now += 0.5 * 2.4999999999999999e-08 * ( _segan_controller__prevpin + _segan_controller__p_gfm_pu ) ;
        _segan_controller__supplied_energy_pu_s = _segan_controller__input_energy_now ;
        _segan_controller__p_gfm_mean_pu = _segan_controller__pmean_in ;
        _segan_controller__p_load_mean_pu = _segan_controller__pmean_load ;
        _segan_controller__p_losses_mean_pu = _segan_controller__pmean_loss ;
        _segan_controller__window_d_new = _segan_controller__window_d_sum - _segan_controller__v2d_buffer [ _segan_controller__window_index ] + _segan_controller__sx [ 2 ] ;
        _segan_controller__window_q_new = _segan_controller__window_q_sum - _segan_controller__v2q_buffer [ _segan_controller__window_index ] + _segan_controller__sx [ 3 ] ;
        _segan_controller__vbus2_ll_rms_pu = sqrt ( _segan_controller__window_d_new * _segan_controller__window_d_new + _segan_controller__window_q_new * _segan_controller__window_q_new ) / 666667.0 ;
    }
    // Generated from the component: A_Shed_Injection.Is1
    {
        {
            HIL_OutFloat(0x82c0000, _segan_controller__ia);
        }
    }
    // Generated from the component: B_Shed_Injection.Is1
    {
        {
            HIL_OutFloat(0x82c0001, _segan_controller__ib);
        }
    }
    // Generated from the component: C_Shed_Injection.Is1
    {
        {
            HIL_OutFloat(0x82c0002, _segan_controller__ic);
        }
    }
    // Generated from the component: Control_balance_pu_s
    {
        HIL_OutAO(0x8003, _segan_controller__balance_pu_s);
    }
    // Generated from the component: Control_conductance_pu
    {
        HIL_OutAO(0x8004, _segan_controller__conductance_pu);
    }
    // Generated from the component: Control_dc_pu
    {
        HIL_OutAO(0x8005, _segan_controller__dc_pu);
    }
    // Generated from the component: Control_feedback_ready
    {
        HIL_OutAO(0x8006, _segan_controller__feedback_ready);
    }
    // Generated from the component: Control_frequency_pu
    {
        HIL_OutAO(0x8007, _segan_controller__frequency_pu);
    }
    // Generated from the component: Control_ia
    {
        HIL_OutAO(0x8008, _segan_controller__ia);
    }
    // Generated from the component: Control_ib
    {
        HIL_OutAO(0x8009, _segan_controller__ib);
    }
    // Generated from the component: Control_ic
    {
        HIL_OutAO(0x800a, _segan_controller__ic);
    }
    // Generated from the component: Control_mc
    {
        HIL_OutAO(0x800b, _segan_controller__mc);
    }
    // Generated from the component: Control_mg
    {
        HIL_OutAO(0x800c, _segan_controller__mg);
    }
    // Generated from the component: Control_minimum_dc_pu
    {
        HIL_OutAO(0x800d, _segan_controller__minimum_dc_pu);
    }
    // Generated from the component: Control_p_filtered
    {
        HIL_OutAO(0x800e, _segan_controller__p_filtered);
    }
    // Generated from the component: Control_p_gfm_mean_pu
    {
        HIL_OutAO(0x800f, _segan_controller__p_gfm_mean_pu);
    }
    // Generated from the component: Control_p_gfm_pu
    {
        HIL_OutAO(0x8010, _segan_controller__p_gfm_pu);
    }
    // Generated from the component: Control_p_load_mean_pu
    {
        HIL_OutAO(0x8011, _segan_controller__p_load_mean_pu);
    }
    // Generated from the component: Control_p_load_pu
    {
        HIL_OutAO(0x8012, _segan_controller__p_load_pu);
    }
    // Generated from the component: Control_p_losses_mean_pu
    {
        HIL_OutAO(0x8013, _segan_controller__p_losses_mean_pu);
    }
    // Generated from the component: Control_p_losses_pu
    {
        HIL_OutAO(0x8014, _segan_controller__p_losses_pu);
    }
    // Generated from the component: Control_peak_gfm_mod
    {
        HIL_OutAO(0x8015, _segan_controller__peak_gfm_mod);
    }
    // Generated from the component: Control_peak_rectifier_mod
    {
        HIL_OutAO(0x8016, _segan_controller__peak_rectifier_mod);
    }
    // Generated from the component: Control_simulation_clock_s
    {
        HIL_OutAO(0x8017, _segan_controller__simulation_clock_s);
    }
    // Generated from the component: Control_stored_energy_pu_s
    {
        HIL_OutAO(0x8018, _segan_controller__stored_energy_pu_s);
    }
    // Generated from the component: Control_supplied_energy_pu_s
    {
        HIL_OutAO(0x8019, _segan_controller__supplied_energy_pu_s);
    }
    // Generated from the component: Control_vbus2_ll_rms_pu
    {
        HIL_OutAO(0x801a, _segan_controller__vbus2_ll_rms_pu);
    }
    // Generated from the component: GFM_PWM.Bus_Split1
    {
        int tmp1;
        for(tmp1 = 0; tmp1 < 2; tmp1 += 1) {
            _gfm_pwm_bus_split1__out[tmp1] = _segan_controller__g[(_gfm_pwm_bus_split1__n_prev_len[0] + tmp1)];
        }
        int tmp2;
        for(tmp2 = 0; tmp2 < 2; tmp2 += 1) {
            _gfm_pwm_bus_split1__out1[tmp2] = _segan_controller__g[(_gfm_pwm_bus_split1__n_prev_len[1] + tmp2)];
        }
        int tmp3;
        for(tmp3 = 0; tmp3 < 2; tmp3 += 1) {
            _gfm_pwm_bus_split1__out2[tmp3] = _segan_controller__g[(_gfm_pwm_bus_split1__n_prev_len[2] + tmp3)];
        }
    }
    // Generated from the component: Rectifier_PWM.Bus_Split1
    {
        int tmp1;
        for(tmp1 = 0; tmp1 < 2; tmp1 += 1) {
            _rectifier_pwm_bus_split1__out[tmp1] = _segan_controller__c[(_rectifier_pwm_bus_split1__n_prev_len[0] + tmp1)];
        }
        int tmp2;
        for(tmp2 = 0; tmp2 < 2; tmp2 += 1) {
            _rectifier_pwm_bus_split1__out1[tmp2] = _segan_controller__c[(_rectifier_pwm_bus_split1__n_prev_len[1] + tmp2)];
        }
        int tmp3;
        for(tmp3 = 0; tmp3 < 2; tmp3 += 1) {
            _rectifier_pwm_bus_split1__out2[tmp3] = _segan_controller__c[(_rectifier_pwm_bus_split1__n_prev_len[2] + tmp3)];
        }
    }
    // Generated from the component: GFM_PWM.Phase A.IGBT Leg global gds ovs.FSM_Wrapper1
    {
        {
            int s_ctrl_val[2];
            int t_tmp1;
            for(t_tmp1 = 0; t_tmp1 < 2; t_tmp1++) {
                s_ctrl_val[t_tmp1] = 0;
            }
            s_ctrl_val[0] = ((int) ((unsigned char) (_gfm_pwm_bus_split1__out[0] != 0)));
            s_ctrl_val[1] = ((int) ((unsigned char) (_gfm_pwm_bus_split1__out[1] != 0)));
            int tac_tmp1 = 2 * s_ctrl_val[0];
            int tac_tmp2 = tac_tmp1 + s_ctrl_val[1];
            HIL_OutInt32(0x810002f, tac_tmp2);
        }
    }
    // Generated from the component: GFM_PWM.Phase B.IGBT Leg global gds ovs.FSM_Wrapper1
    {
        {
            int s_ctrl_val[2];
            int t_tmp1;
            for(t_tmp1 = 0; t_tmp1 < 2; t_tmp1++) {
                s_ctrl_val[t_tmp1] = 0;
            }
            s_ctrl_val[0] = ((int) ((unsigned char) (_gfm_pwm_bus_split1__out1[0] != 0)));
            s_ctrl_val[1] = ((int) ((unsigned char) (_gfm_pwm_bus_split1__out1[1] != 0)));
            int tac_tmp1 = 2 * s_ctrl_val[0];
            int tac_tmp2 = tac_tmp1 + s_ctrl_val[1];
            HIL_OutInt32(0x810004f, tac_tmp2);
        }
    }
    // Generated from the component: GFM_PWM.Phase C.IGBT Leg global gds ovs.FSM_Wrapper1
    {
        {
            int s_ctrl_val[2];
            int t_tmp1;
            for(t_tmp1 = 0; t_tmp1 < 2; t_tmp1++) {
                s_ctrl_val[t_tmp1] = 0;
            }
            s_ctrl_val[0] = ((int) ((unsigned char) (_gfm_pwm_bus_split1__out2[0] != 0)));
            s_ctrl_val[1] = ((int) ((unsigned char) (_gfm_pwm_bus_split1__out2[1] != 0)));
            int tac_tmp1 = 2 * s_ctrl_val[0];
            int tac_tmp2 = tac_tmp1 + s_ctrl_val[1];
            HIL_OutInt32(0x810006f, tac_tmp2);
        }
    }
    // Generated from the component: Rectifier_PWM.Phase A.IGBT Leg global gds ovs.FSM_Wrapper1
    {
        {
            int s_ctrl_val[2];
            int t_tmp1;
            for(t_tmp1 = 0; t_tmp1 < 2; t_tmp1++) {
                s_ctrl_val[t_tmp1] = 0;
            }
            s_ctrl_val[0] = ((int) ((unsigned char) (_rectifier_pwm_bus_split1__out[0] != 0)));
            s_ctrl_val[1] = ((int) ((unsigned char) (_rectifier_pwm_bus_split1__out[1] != 0)));
            int tac_tmp1 = 2 * s_ctrl_val[0];
            int tac_tmp2 = tac_tmp1 + s_ctrl_val[1];
            HIL_OutInt32(0x810008f, tac_tmp2);
        }
    }
    // Generated from the component: Rectifier_PWM.Phase B.IGBT Leg global gds ovs.FSM_Wrapper1
    {
        {
            int s_ctrl_val[2];
            int t_tmp1;
            for(t_tmp1 = 0; t_tmp1 < 2; t_tmp1++) {
                s_ctrl_val[t_tmp1] = 0;
            }
            s_ctrl_val[0] = ((int) ((unsigned char) (_rectifier_pwm_bus_split1__out1[0] != 0)));
            s_ctrl_val[1] = ((int) ((unsigned char) (_rectifier_pwm_bus_split1__out1[1] != 0)));
            int tac_tmp1 = 2 * s_ctrl_val[0];
            int tac_tmp2 = tac_tmp1 + s_ctrl_val[1];
            HIL_OutInt32(0x81000af, tac_tmp2);
        }
    }
    // Generated from the component: Rectifier_PWM.Phase C.IGBT Leg global gds ovs.FSM_Wrapper1
    {
        {
            int s_ctrl_val[2];
            int t_tmp1;
            for(t_tmp1 = 0; t_tmp1 < 2; t_tmp1++) {
                s_ctrl_val[t_tmp1] = 0;
            }
            s_ctrl_val[0] = ((int) ((unsigned char) (_rectifier_pwm_bus_split1__out2[0] != 0)));
            s_ctrl_val[1] = ((int) ((unsigned char) (_rectifier_pwm_bus_split1__out2[1] != 0)));
            int tac_tmp1 = 2 * s_ctrl_val[0];
            int tac_tmp2 = tac_tmp1 + s_ctrl_val[1];
            HIL_OutInt32(0x81000cf, tac_tmp2);
        }
    }
//@cmp.out.block.end
    //////////////////////////////////////////////////////////////////////////
    // Update block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.update.block.start
    // Generated from the component: A_Bus2_V_Meas.Va1
    // Generated from the component: A_Injection_Current.Ia1
    // Generated from the component: A_cic_Feedback.Ia1
    // Generated from the component: A_cif_Feedback.Ia1
    // Generated from the component: A_cvf_Feedback.Va1
    // Generated from the component: A_gic_Feedback.Ia1
    // Generated from the component: A_gif_Feedback.Ia1
    // Generated from the component: A_gvf_Feedback.Va1
    // Generated from the component: A_linei_Feedback.Ia1
    // Generated from the component: A_v1_Feedback.Va1
    // Generated from the component: B_Bus2_V_Meas.Va1
    // Generated from the component: B_Injection_Current.Ia1
    // Generated from the component: B_cic_Feedback.Ia1
    // Generated from the component: B_cif_Feedback.Ia1
    // Generated from the component: B_cvf_Feedback.Va1
    // Generated from the component: B_gic_Feedback.Ia1
    // Generated from the component: B_gif_Feedback.Ia1
    // Generated from the component: B_gvf_Feedback.Va1
    // Generated from the component: B_linei_Feedback.Ia1
    // Generated from the component: B_v1_Feedback.Va1
    // Generated from the component: C_Bus2_V_Meas.Va1
    // Generated from the component: C_Injection_Current.Ia1
    // Generated from the component: C_cic_Feedback.Ia1
    // Generated from the component: C_cif_Feedback.Ia1
    // Generated from the component: C_cvf_Feedback.Va1
    // Generated from the component: C_gic_Feedback.Ia1
    // Generated from the component: C_gif_Feedback.Ia1
    // Generated from the component: C_gvf_Feedback.Va1
    // Generated from the component: C_linei_Feedback.Ia1
    // Generated from the component: C_v1_Feedback.Va1
    // Generated from the component: GFM_DC_Current_Feedback.Ia1
    // Generated from the component: Rect_DC_Meas.Va1
    // Generated from the component: A_Bus2_V
    // Generated from the component: B_Bus2_V
    // Generated from the component: C_Bus2_V
    // Generated from the component: Rect_DC_Probe
    // Generated from the component: SEGAN_Controller
    {
        int  j;
        _segan_controller__sx [ 6 ] += 2.4999999999999999e-08 * _segan_controller__dx [ 6 ] ;
        _segan_controller__sx [ 7 ] += 2.4999999999999999e-08 * _segan_controller__dx [ 7 ] ;
        _segan_controller__sx [ 8 ] += 2.4999999999999999e-08 * _segan_controller__dx [ 8 ] ;
        _segan_controller__sx [ 9 ] += 2.4999999999999999e-08 * _segan_controller__dx [ 9 ] ;
        _segan_controller__sx [ 10 ] += 2.4999999999999999e-08 * _segan_controller__dx [ 10 ] ;
        _segan_controller__sx [ 11 ] += 2.4999999999999999e-08 * _segan_controller__dx [ 11 ] ;
        _segan_controller__sx [ 12 ] += 2.4999999999999999e-08 * _segan_controller__dx [ 12 ] ;
        _segan_controller__sx [ 13 ] += 2.4999999999999999e-08 * _segan_controller__dx [ 13 ] ;
        _segan_controller__sx [ 20 ] += 2.4999999999999999e-08 * _segan_controller__dx [ 20 ] ;
        _segan_controller__sx [ 21 ] += 2.4999999999999999e-08 * _segan_controller__dx [ 21 ] ;
        _segan_controller__sx [ 22 ] += 2.4999999999999999e-08 * _segan_controller__dx [ 22 ] ;
        _segan_controller__sx [ 24 ] += 2.4999999999999999e-08 * _segan_controller__dx [ 24 ] ;
        _segan_controller__sx [ 25 ] += 2.4999999999999999e-08 * _segan_controller__dx [ 25 ] ;
        _segan_controller__theta += 2.4999999999999999e-08 * 376.99111843077515 * _segan_controller__u [ 4 ] ;
        if ( _segan_controller__theta > 6.28318530717958647692 ) _segan_controller__theta -= 6.28318530717958647692 ;
        _segan_controller__pacc_in += 2.4999999999999999e-08 * _segan_controller__p_gfm_pu ;
        _segan_controller__pacc_load += 2.4999999999999999e-08 * _segan_controller__p_load_pu ;
        _segan_controller__pacc_loss += 2.4999999999999999e-08 * _segan_controller__p_losses_pu ;
        _segan_controller__carrier_tick ++ ;
        if ( _segan_controller__carrier_tick >= 2000 )     {
            _segan_controller__carrier_tick = 0 ;
            _segan_controller__pmean_in = _segan_controller__pacc_in / 50e-6 ;
            _segan_controller__pmean_load = _segan_controller__pacc_load / 50e-6 ;
            _segan_controller__pmean_loss = _segan_controller__pacc_loss / 50e-6 ;
            _segan_controller__pacc_in = 0 ;
            _segan_controller__pacc_load = 0 ;
            _segan_controller__pacc_loss = 0 ;
            for ( j = 0 ; j < 4 ; j ++ )         {
                _segan_controller__applied [ j ] = _segan_controller__pending [ j ] ;
                _segan_controller__pending [ j ] = _segan_controller__u [ j ] ;
            }
        }
        _segan_controller__v2d_buffer [ _segan_controller__window_index ] = _segan_controller__sx [ 2 ] ;
        _segan_controller__v2q_buffer [ _segan_controller__window_index ] = _segan_controller__sx [ 3 ] ;
        _segan_controller__window_d_sum = _segan_controller__window_d_new ;
        _segan_controller__window_q_sum = _segan_controller__window_q_new ;
        _segan_controller__window_index ++ ;
        if ( _segan_controller__window_index >= 666667 ) _segan_controller__window_index = 0 ;
        _segan_controller__balance_state = _segan_controller__balance_now ;
        _segan_controller__prevnet = _segan_controller__netpower ;
        _segan_controller__elapsed_tick ++ ;
        _segan_controller__input_energy_state = _segan_controller__input_energy_now ;
        _segan_controller__prevpin = _segan_controller__p_gfm_pu ;
        _segan_controller__peakg_state = _segan_controller__peak_gfm_mod ;
        _segan_controller__peakc_state = _segan_controller__peak_rectifier_mod ;
        _segan_controller__mindc_state = _segan_controller__minimum_dc_pu ;
    }
    // Generated from the component: A_Shed_Injection.Is1
    // Generated from the component: B_Shed_Injection.Is1
    // Generated from the component: C_Shed_Injection.Is1
    // Generated from the component: Control_balance_pu_s
    // Generated from the component: Control_conductance_pu
    // Generated from the component: Control_dc_pu
    // Generated from the component: Control_feedback_ready
    // Generated from the component: Control_frequency_pu
    // Generated from the component: Control_ia
    // Generated from the component: Control_ib
    // Generated from the component: Control_ic
    // Generated from the component: Control_mc
    // Generated from the component: Control_mg
    // Generated from the component: Control_minimum_dc_pu
    // Generated from the component: Control_p_filtered
    // Generated from the component: Control_p_gfm_mean_pu
    // Generated from the component: Control_p_gfm_pu
    // Generated from the component: Control_p_load_mean_pu
    // Generated from the component: Control_p_load_pu
    // Generated from the component: Control_p_losses_mean_pu
    // Generated from the component: Control_p_losses_pu
    // Generated from the component: Control_peak_gfm_mod
    // Generated from the component: Control_peak_rectifier_mod
    // Generated from the component: Control_simulation_clock_s
    // Generated from the component: Control_stored_energy_pu_s
    // Generated from the component: Control_supplied_energy_pu_s
    // Generated from the component: Control_vbus2_ll_rms_pu
    // Generated from the component: GFM_PWM.Bus_Split1
    // Generated from the component: Rectifier_PWM.Bus_Split1
    // Generated from the component: GFM_PWM.Phase A.IGBT Leg global gds ovs.FSM_Wrapper1
    // Generated from the component: GFM_PWM.Phase B.IGBT Leg global gds ovs.FSM_Wrapper1
    // Generated from the component: GFM_PWM.Phase C.IGBT Leg global gds ovs.FSM_Wrapper1
    // Generated from the component: Rectifier_PWM.Phase A.IGBT Leg global gds ovs.FSM_Wrapper1
    // Generated from the component: Rectifier_PWM.Phase B.IGBT Leg global gds ovs.FSM_Wrapper1
    // Generated from the component: Rectifier_PWM.Phase C.IGBT Leg global gds ovs.FSM_Wrapper1
    //@cmp.update.block.end
}
// ----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------