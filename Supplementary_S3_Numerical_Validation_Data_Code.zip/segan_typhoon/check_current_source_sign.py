"""Determine the controlled-current-source sign using a 10-V/10-ohm circuit."""
from pathlib import Path
import json
import time
from typhoon.api.schematic_editor import SchematicAPI
from typhoon.api import hil

HERE=Path(__file__).resolve().parent
TSE=HERE/"current_source_sign_test.tse"
m=SchematicAPI();m.create_new_model(name="controlled current sign test")
m.set_model_property_value("simulation_time_step","1e-6")
m.set_model_property_value("enb_pole_shift",False)
def add(kind,name,pos,**props):
    obj=m.create_component("core/"+kind,name=name,position=pos)
    for key,value in props.items():m.set_property_value(m.prop(obj,key),str(value))
    return obj
def term(obj,name):return m.term(obj,name)
def wire(a,b):m.create_connection(a,b)
v=add("Voltage Source","V10",(7800,8000),init_const_value=10)
i=add("Current Measurement","Source_Current",(8000,8000),sig_output=True,execution_rate="1e-6")
r=add("Resistor","R10",(8200,8100),resistance=10)
c=add("Signal Controlled Current Source","I1",(8400,8100),execution_rate="1e-6")
k=add("Constant","One_Amp",(8600,8100),value=1,execution_rate="1e-6")
g=add("Ground","Ground",(8000,8300))
n=m.create_junction(name="Positive",position=(8200,8000))
wire(term(v,"p_node"),term(i,"p_node"));wire(term(i,"n_node"),n)
wire(n,term(r,"p_node"));wire(n,term(c,"p_node"))
wire(term(r,"n_node"),term(g,"node"));wire(term(c,"n_node"),term(g,"node"))
wire(term(v,"n_node"),term(g,"node"));wire(term(k,"out"),term(c,"in"))
m.save_as(str(TSE))
if not m.compile():raise RuntimeError("sign test compile failed")
if not hil.load_model(file=m.get_compiled_model_file(str(TSE)),vhil_device=True):
    raise RuntimeError("sign test load failed")
hil.start_simulation()
try:
    deadline=time.monotonic()+15
    while hil.get_sim_time()<0.002 and time.monotonic()<deadline:time.sleep(0.02)
    read=float(hil.read_analog_signal("Source_Current"))
finally:hil.stop_simulation()
out={"source_v":10,"resistor_ohm":10,"controlled_source_command_a":1,
     "voltage_source_outward_current_a":read,
     "positive_command_flows_p_to_n":abs(read-2)<1e-5,
     "positive_command_flows_n_to_p":abs(read)<1e-5}
(HERE/"current_source_sign_result.json").write_text(json.dumps(out,indent=2),encoding="utf-8")
print(json.dumps(out,indent=2))
if not(out["positive_command_flows_p_to_n"] or out["positive_command_flows_n_to_p"]):
    raise RuntimeError("unresolved controlled-source sign")
