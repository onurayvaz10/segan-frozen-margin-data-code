"""Generate the Typhoon C-function wrapper for the checked SEGAN controller.

Electrical energy storage and converter/DC dynamics remain Typhoon components.
Controller states integrate with the circuit step; common-frame voltage commands
are sampled every 50 us and applied after one complete PWM period.
"""
from pathlib import Path

HERE=Path(__file__).resolve().parent
CONTROL_IDX=[6,7,8,9,10,11,12,13,20,21,22,24,25]
CFG_NAMES=["r_line","x_line","b_bus","r_load","c_dc","gfm_dc","gfm_rp","gfm_kq","gfm_w_p","gfm_w_q",
           "gfm_rv","gfm_lv","gfm_kpv","gfm_kiv","gfm_kpc","gfm_kic","gfm_w_ad","gfm_k_ad",
           "gfm_lf","gfm_rf","gfm_cf","gfm_lg","gfm_rg","cpl_lf","cpl_rf","cpl_cf","cpl_lg","cpl_rg",
           "cpl_kpc","cpl_kic","cpl_kp_pll","cpl_ki_pll","cpl_kpv","cpl_kiv"]
INPUTS=[f"{group}_{phase}" for group in ("gvf","gic","gif","cvf","cic","v1","v2","linei","cif","inj") for phase in "abc"]+["dc","idc_g","shed_dg"]
OUTPUTS=[("g",6),("c",6)]+[(name,1) for name in
    ("mg","mc","frequency_pu","p_filtered","dc_pu","ia","ib","ic","conductance_pu",
     "vbus2_ll_rms_pu","p_gfm_pu","p_load_pu","p_losses_pu","stored_energy_pu_s","balance_pu_s")]
OUTPUTS += [("peak_gfm_mod",1),("peak_rectifier_mod",1),("minimum_dc_pu",1)]
OUTPUTS += [(name,1) for name in ("p_gfm_mean_pu","p_load_mean_pu","p_losses_mean_pu","supplied_energy_pu_s")]
OUTPUTS += [("simulation_clock_s",1),("feedback_ready",1)]

def config(cal,dt):
    x=cal["initial_state_independent_order"]
    r=cal["references"]["setpoints"]+[cal["references"]["theta_g"]]
    s=cal["settings"]
    z=lambda k:complex(x[k],x[k+1])
    vg=z(16)+complex(s["gfm_rf"],s["gfm_lf"])*z(14)
    vc=z(28)-complex(s["cpl_rf"],s["cpl_lf"])*z(26)
    initial_u=[vg.real,vg.imag,vc.real,vc.imag]
    n=int(round(50e-6/dt))
    nw=int(round((1/60)/dt))
    if abs(n*dt-50e-6)>1e-14:
        raise ValueError("circuit step must divide the PWM period")
    arb=""
    init="int j;\n"+"\n".join(f"sx[{i}]={value:.17g}; dx[{i}]=0;" for i,value in enumerate(x))
    init+="\n"+"\n".join(f"applied[{i}]={value:.17g}; pending[{i}]={value:.17g};" for i,value in enumerate(initial_u))
    init+=f"\ntheta=0;carrier_tick=0;elapsed_tick=0;window_index=0;balance_state=0;prevnet=0;\nwindow_d_sum={nw}.0*sx[2];window_q_sum={nw}.0*sx[3];\n"
    init+=f"for(j=0;j<{nw};j++){{v2d_buffer[j]=sx[2];v2q_buffer[j]=sx[3];}}"
    init+=f"\npeakg_state=0;peakc_state=0;mindc_state={x[23]:.17g};"
    init+="\npacc_in=0;pacc_load=0;pacc_loss=0;pmean_in=0;pmean_load=0;pmean_loss=0;input_energy_state=0;prevpin=0;"
    out=f"real rr[6],cfg[{len(CFG_NAMES)}],rg[3],rc[3],mxg,mng,mxc,mnc,ph,tri,alpha,beta,removed_g,injected_power; int k;\n"
    out+="\n".join(f"rr[{i}]={v:.17g};" for i,v in enumerate(r))+"\n"
    out+="\n".join(f"cfg[{i}]={s[name]:.17g};" for i,name in enumerate(CFG_NAMES))+"\n"
    out+="if(elapsed_tick>0){\n"
    for group,idx,base in (("gvf",16,380.0),("gic",14,10000/380),
                           ("gif",18,10000/380),("cvf",28,380.0),("cic",26,10000/380),
                           ("v1",0,380.0),("v2",2,380.0),("linei",4,10000/380),("cif",30,10000/380)):
        out+=f"alpha=0.81649658092772603273*({group}_a-0.5*{group}_b-0.5*{group}_c)/{base:.17g};\n"
        out+=f"beta=0.70710678118654752440*({group}_b-{group}_c)/{base:.17g};\n"
        out+=f"sx[{idx}]=alpha*cos(theta)+beta*sin(theta);sx[{idx+1}]=-alpha*sin(theta)+beta*cos(theta);\n"
    out+="sx[23]=dc/620.5374015050718;\n}\nsegan_control_math(sx,rr,cfg,u,dx);\n"
    out+=f"simulation_clock_s=((real)elapsed_tick)*{dt:.17g};feedback_ready=(elapsed_tick>0)?1.0:0.0;\n"
    out+="""
for(k=0;k<3;k++){
    ph=theta-(2.0*3.14159265358979323846/3.0)*k;
    rg[k]=(applied[0]*cos(ph)-applied[1]*sin(ph))/cfg[5];
    rc[k]=(applied[2]*cos(ph)-applied[3]*sin(ph))/sx[23];
}
mxg=fmax(rg[0],fmax(rg[1],rg[2]));mng=fmin(rg[0],fmin(rg[1],rg[2]));
mxc=fmax(rc[0],fmax(rc[1],rc[2]));mnc=fmin(rc[0],fmin(rc[1],rc[2]));
"""
    out+=f"tri=1.0-4.0*fabs(((real)carrier_tick)/{n}.0-0.5);\n"
    out+="""
mg=0;mc=0;
for(k=0;k<3;k++){
    rg[k]-=0.5*(mxg+mng);rc[k]-=0.5*(mxc+mnc);
    mg=fmax(mg,fabs(rg[k]));mc=fmax(mc,fabs(rc[k]));
    g[2*k]=(rg[k]>tri)?1.0:0.0;g[2*k+1]=1.0-g[2*k];
    c[2*k]=(rc[k]>tri)?1.0:0.0;c[2*k+1]=1.0-c[2*k];
}
frequency_pu=u[4];p_filtered=sx[6];dc_pu=sx[23];
peak_gfm_mod=fmax(peakg_state,mg);peak_rectifier_mod=fmax(peakc_state,mc);minimum_dc_pu=fmin(mindc_state,dc_pu);
"""
    out+=f"removed_g=shed_dg*fmin(1.0,((real)elapsed_tick)*{dt:.17g}/0.25);\n"
    out+=f"conductance_pu={cal['g_resistive']:.17g}-removed_g;\n"
    out+="ia=removed_g*v2_a/14.44;ib=removed_g*v2_b/14.44;ic=removed_g*v2_c/14.44;\n"
    out+="injected_power=(v2_a*inj_a+v2_b*inj_b+v2_c*inj_c)/10000.0;\n"
    out+=f"segan_energy_math(sx,cfg,{cal['g_resistive']:.17g},injected_power,idc_g,audit_values);\n"
    out+="stored_energy_pu_s=audit_values[0];p_gfm_pu=audit_values[1];p_load_pu=audit_values[2];p_losses_pu=audit_values[3];\n"
    out+="netpower=p_gfm_pu-p_load_pu-p_losses_pu;balance_now=balance_state;\n"
    out+=f"if(elapsed_tick>0)balance_now+=0.5*{dt:.17g}*(prevnet+netpower);balance_pu_s=balance_now;\n"
    out+=f"input_energy_now=input_energy_state;if(elapsed_tick>0)input_energy_now+=0.5*{dt:.17g}*(prevpin+p_gfm_pu);supplied_energy_pu_s=input_energy_now;\n"
    out+="p_gfm_mean_pu=pmean_in;p_load_mean_pu=pmean_load;p_losses_mean_pu=pmean_loss;\n"
    out+="window_d_new=window_d_sum-v2d_buffer[window_index]+sx[2];window_q_new=window_q_sum-v2q_buffer[window_index]+sx[3];\n"
    out+=f"vbus2_ll_rms_pu=sqrt(window_d_new*window_d_new+window_q_new*window_q_new)/{nw}.0;\n"
    update="int j;\n"+"\n".join(f"sx[{i}]+={dt:.17g}*dx[{i}];" for i in CONTROL_IDX)
    update+=f"\ntheta+={dt:.17g}*376.99111843077515*u[4];\n"
    update+="if(theta>6.28318530717958647692)theta-=6.28318530717958647692;\n"
    update+=f"pacc_in+={dt:.17g}*p_gfm_pu;pacc_load+={dt:.17g}*p_load_pu;pacc_loss+={dt:.17g}*p_losses_pu;\n"
    update+=f"carrier_tick++;if(carrier_tick>={n}){{carrier_tick=0;\n"
    update+="pmean_in=pacc_in/50e-6;pmean_load=pacc_load/50e-6;pmean_loss=pacc_loss/50e-6;pacc_in=0;pacc_load=0;pacc_loss=0;\n"
    update+="for(j=0;j<4;j++){applied[j]=pending[j];pending[j]=u[j];}}"
    update+="\nv2d_buffer[window_index]=sx[2];v2q_buffer[window_index]=sx[3];window_d_sum=window_d_new;window_q_sum=window_q_new;\n"
    update+=f"window_index++;if(window_index>={nw})window_index=0;\n"
    update+="balance_state=balance_now;prevnet=netpower;elapsed_tick++;"
    update+="input_energy_state=input_energy_now;prevpin=p_gfm_pu;"
    update+="peakg_state=peak_gfm_mod;peakc_state=peak_rectifier_mod;mindc_state=minimum_dc_pu;"
    return {
        "input_terminals":"".join(f"real {name};" for name in INPUTS),
        "input_terminals_dimensions":";".join(["(1,)"]*len(INPUTS)),
        "input_terminals_feedthrough":";".join(["True"]*len(INPUTS)),
        "output_terminals":"".join(f"real {name};" for name,size in OUTPUTS),
        "output_terminals_dimensions":";".join(f"({size},)" for name,size in OUTPUTS),
        "output_terminals_feedthrough":";".join(["True"]*len(OUTPUTS)),
        "global_variables":("real sx[32];real dx[32];real u[6];real applied[4];real pending[4];real theta;int carrier_tick;"
                            "int elapsed_tick;int window_index;real audit_values[4];real netpower;real prevnet;real balance_state;real balance_now;"
                            "real peakg_state;real peakc_state;real mindc_state;"
                            "real pacc_in;real pacc_load;real pacc_loss;real pmean_in;real pmean_load;real pmean_loss;real input_energy_state;real input_energy_now;real prevpin;"
                            f"real v2d_buffer[{nw}];real v2q_buffer[{nw}];real window_d_sum;real window_q_sum;real window_d_new;real window_q_new;"),
        "arb_defs":arb,"init_fnc":init,"output_fnc":out,"update_fnc":update,
        "execution_rate":str(dt),"add_src_path":"controller_src",
        "add_src_path_full":str(HERE/"controller_src"),
    }
