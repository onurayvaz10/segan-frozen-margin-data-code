"""Execute the predeclared baseline or 2.75-s load ramp in actual Virtual HIL."""
from __future__ import annotations
from pathlib import Path
import os
import argparse
import hashlib
import json
import time
import numpy as np
from typhoon.api import hil

HERE=Path(__file__).resolve().parent
ap=argparse.ArgumentParser()
ap.add_argument("--case",choices=("F2-0.65-0.20","A2-F00993","F2-0.60-0.20"),required=True)
ap.add_argument("--step-us",type=float,choices=(0.5,0.25,0.125,0.0625,0.05,0.025),required=True)
ap.add_argument("--scenario",choices=("baseline","ramp"),required=True)
args=ap.parse_args()
step=args.step_us*1e-6
tag=str(args.step_us).replace(".","p")
model_name=f"segan_closed_{args.case}_dt{tag}us"
cpd=HERE/(model_name+" Target files")/(model_name+".cpd")
run_name=f"{args.case}_{args.scenario}_{tag}us"
outdir=HERE/"validation_runs"/run_name
outdir.mkdir(parents=True,exist_ok=True)
plan=json.loads((HERE.parent/"independent_emt"/"ramp_plan.json").read_text())
entry=next(v for v in plan["cases"].values() if v["calibration_id"]==args.case)
delta=entry["dG_pu"] if args.scenario=="ramp" else 0.0
duration=2.75 if args.scenario=="ramp" else 0.5
record=0.0004
decimation=int(round(record/step))
samples=int(round(duration/record))+1
samples += samples%2
mapping={
    "Control_vbus2_ll_rms_pu":"vbus2_ll_rms_pu",
    "Control_dc_pu":"vdc_pu","Control_mg":"gfm_mod","Control_mc":"rectifier_mod",
    "Control_p_gfm_mean_pu":"p_gfm_pu","Control_p_load_mean_pu":"p_load_pu",
    "Control_p_losses_mean_pu":"p_losses_pu","Control_stored_energy_pu_s":"stored_energy_pu_s",
    "Control_balance_pu_s":"integrated_balance_pu_s",
    "Control_conductance_pu":"conductance_pu","Control_frequency_pu":"frequency_pu",
    "Control_peak_gfm_mod":"peak_gfm_mod","Control_peak_rectifier_mod":"peak_rectifier_mod",
    "Control_minimum_dc_pu":"minimum_dc_pu",
    "Control_supplied_energy_pu_s":"supplied_energy_pu_s",
    "Control_simulation_clock_s":"model_clock_s",
    "Control_feedback_ready":"feedback_ready",
}
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
summary={"case":args.case,"scenario":args.scenario,"circuit_step_s":step,
         "record_interval_s":record,"duration_s":duration,"shed_dG_pu":delta,
         "platform":"Typhoon Virtual HIL offline software simulation",
         "cpd":str(cpd),"cpd_sha256":sha(cpd),"status":"started"}
audit_path=HERE/(model_name+".audit.json")
audit=json.loads(audit_path.read_text())
if not audit["all_passed"] or audit["cpd_sha256"]!=summary["cpd_sha256"]:
    raise RuntimeError("model parameter/code audit missing, failed or stale")
summary["model_audit_sha256"]=sha(audit_path)
timing_path=HERE/(model_name+".compiled_timing.json")
timing=json.loads(timing_path.read_text())
compiled_json=cpd.with_suffix(".json")
if (not timing["compiled_timing_valid"] or timing["compiled_json_sha256"]!=sha(compiled_json)
    or timing["cpd_sha256"]!=summary["cpd_sha256"]):
    raise RuntimeError("compiled execution-rate audit missing, adjusted or stale")
summary["compiled_timing_audit_sha256"]=sha(timing_path)
if args.case=="F2-0.60-0.20":
    independent=HERE/"independent_reference_integral"/f"{args.case}_ramp_80_50us.npz"
    reference_info=json.loads(independent.with_suffix(".json").read_text())
    if (not reference_info.get("new_case_reference_frozen_before_native")
        or not all(reference_info["new_reference_checks"].values())
        or reference_info["npz_sha256"]!=sha(independent)):
        raise RuntimeError("additional operating point requires a frozen passing independent reference before native simulation")
    summary["preexisting_independent_reference_sha256"]=sha(independent)
summary["input_sha256"]={
    "tse":sha(HERE/(model_name+".tse")),
    "controller_c":sha(HERE/"controller_src"/"controller_math.c"),
    "controller_h":sha(HERE/"controller_src"/"controller_math.h"),
    "calibration":sha(HERE.parent/"independent_emt"/f"calibration_{args.case}.json"),
    "protocol":sha(HERE.parent/"virtual_hil_protocol.json"),
}
try:
    if not hil.load_model(file=str(cpd),vhil_device=True):
        raise RuntimeError("Virtual HIL load_model failed")
    if hil.set_scada_input_value("Shed_dG",delta) is False:
        raise RuntimeError("Shed_dG initialization failed")
    buffer=[]
    ok=hil.start_capture([decimation,len(mapping),samples,False],["Forced"],[list(mapping),[]],
                         dataBuffer=buffer,fileName=str(outdir/"vendor_raw_capture.csv"),
                         executeAt=0.0,timeFormat=hil.TF_ABSOLUTE_TIME)
    if not ok:raise RuntimeError("capture preparation failed")
    hil.start_simulation()
    try:
        deadline=time.monotonic()+900
        busy=hil.capture_in_progress()
        while busy and time.monotonic()<deadline:
            time.sleep(0.2)
            stop_file=os.environ.get("SEGAN_STOP_FILE")
            if stop_file and Path(stop_file).exists():
                raise RuntimeError("hardware reliability guard requested simulation stop")
            busy=hil.capture_in_progress()
        if busy:raise TimeoutError("Virtual HIL capture exceeded 900 wall seconds")
        if len(buffer)!=1:raise RuntimeError(f"expected one capture buffer, got {len(buffer)}")
        names,values,meta=buffer[0]
        trigger_ns=int(meta["trigger_timestamp_sim_time"])
        values=np.asarray(values)
        reported_t=np.asarray(meta["x_data"],dtype=float)+trigger_ns*1e-9
        t=np.asarray(values[list(names).index("Control_simulation_clock_s")],dtype=float)
        if values.shape!=(len(mapping),len(t)):
            raise ValueError(f"unexpected capture array shape {values.shape}")
        keep=t<=duration+2e-6
        t=t[keep];values=values[:,keep]
        if not np.isfinite(values).all():raise FloatingPointError("nonfinite captured data")
        np.savez_compressed(outdir/"capture.npz",time_s=t,signal_names=np.asarray(names),values=values,
                            vendor_reported_time_s=reported_t[keep],
                            trigger_sim_ns=trigger_ns)
        ordered=[mapping[name] for name in names]
        csv=outdir/"capture.csv"
        np.savetxt(csv,np.column_stack((t,values.T)),delimiter=",",fmt="%.12g",
                   header=",".join(["time_s"]+ordered),comments="")
        flags={name:hil.get_flag_status(getattr(hil,name)) for name in
               ("FL_ARITHMETIC_OVERFLOW","FL_DEAD_TIME","FL_SP_EXC_OCCURRED","FL_COMP_INT_OVERRUN")}
        summary.update(status="actual_virtual_hil_capture_saved",capture_rows=len(t),
                       first_time_s=float(t[0]),last_time_s=float(t[-1]),
                       trigger_timestamp_sim_time_ns=trigger_ns,flags=flags,
                       vendor_time_vs_model_time_offset_first_s=float(reported_t[0]-t[0]),
                       capture_sha256=sha(csv),simulation_time_when_read_s=float(hil.get_sim_time()))
    finally:
        hil.stop_simulation()
except Exception as exc:
    summary["status"]="failed"
    summary["error"]=f"{type(exc).__name__}: {exc}"
    raise
finally:
    (outdir/"run_status.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
    print(json.dumps(summary,indent=2),flush=True)
