/* SEGAN controller only. Electrical dynamics are Typhoon circuit components. */
#include <math.h>
#include "controller_math.h"
#ifndef SEGAN_IN_TYPHOON
typedef double real;
#endif
/* r=[P*,Q*,V*,Vdc*,Iq*,theta_g]; u=[Vgd,Vgq,Vcd,Vcq,w,dw]. */
void segan_control_math(const real*x,const real*r,const real*cfg,real*u,real*d){
    real wb=376.99111843077515,zbase=14.44,vdcbase=620.5374015050718;
    real ibase=10000.0/380.0,ct=cos(r[5]),st=sin(r[5]);
    real vlr=x[16]*ct+x[17]*st,vli=-x[16]*st+x[17]*ct;
    real ilr=x[18]*ct+x[19]*st,ili=-x[18]*st+x[19]*ct;
    real icr=x[14]*ct+x[15]*st,ici=-x[14]*st+x[15]*ct;
    real w=1.0+cfg[SG_GFM_RP]*(r[0]-x[6]);
    real evr=r[2]+cfg[SG_GFM_KQ]*(r[1]-x[7])-cfg[SG_GFM_RV]*ilr+w*cfg[SG_GFM_LV]*ili-vlr;
    real evi=-cfg[SG_GFM_RV]*ili-w*cfg[SG_GFM_LV]*ilr-vli;
    real itr=cfg[SG_GFM_KPV]*evr+cfg[SG_GFM_KIV]*x[8]-w*cfg[SG_GFM_CF]*vli;
    real iti=cfg[SG_GFM_KPV]*evi+cfg[SG_GFM_KIV]*x[9]+w*cfg[SG_GFM_CF]*vlr;
    real eir=itr-icr,eii=iti-ici;
    real vgr=cfg[SG_GFM_KPC]*eir+cfg[SG_GFM_KIC]*x[10]-w*cfg[SG_GFM_LF]*ici-cfg[SG_GFM_K_AD]*(vlr-x[12]);
    real vgi=cfg[SG_GFM_KPC]*eii+cfg[SG_GFM_KIC]*x[11]+w*cfg[SG_GFM_LF]*icr-cfg[SG_GFM_K_AD]*(vli-x[13]);
    real cp=cos(x[20]),sp=sin(x[20]);
    real vq=-x[28]*sp+x[29]*cp;
    real dw=cfg[SG_CPL_KP_PLL]*vq+cfg[SG_CPL_KI_PLL]*x[21];
    real cilr=x[26]*cp+x[27]*sp,cili=-x[26]*sp+x[27]*cp;
    real idref=cfg[SG_CPL_KPV]*(r[3]-x[23])+cfg[SG_CPL_KIV]*x[22];
    real cer=cilr-idref,cei=cili-r[4];
    real lf=cfg[SG_CPL_LF];
    real vcr=cfg[SG_CPL_KPC]*cer+cfg[SG_CPL_KIC]*x[24]+(1.0+dw)*lf*cili;
    real vci=cfg[SG_CPL_KPC]*cei+cfg[SG_CPL_KIC]*x[25]-(1.0+dw)*lf*cilr;
    int k;
    for(k=0;k<32;k++)d[k]=0;
    d[6]=cfg[SG_GFM_W_P]*(x[16]*x[18]+x[17]*x[19]-x[6]);
    d[7]=cfg[SG_GFM_W_Q]*(x[17]*x[18]-x[16]*x[19]-x[7]);
    d[8]=evr;d[9]=evi;d[10]=eir;d[11]=eii;
    d[12]=cfg[SG_GFM_W_AD]*(vlr-x[12]);d[13]=cfg[SG_GFM_W_AD]*(vli-x[13]);
    d[20]=wb*(1.0+dw-w);d[21]=vq;d[22]=r[3]-x[23];d[24]=cer;d[25]=cei;
    u[0]=vgr*ct-vgi*st;u[1]=vgr*st+vgi*ct;
    u[2]=vcr*cp-vci*sp;u[3]=vcr*sp+vci*cp;u[4]=w;u[5]=dw;
}

void segan_energy_math(const real*x,const real*cfg,real g0,real injected_power,real idc_g,real*out){
    real wb=376.99111843077515,z=14.44,vdcbase=620.5374015050718;
    real lbase=z/wb, cbase=1.0/(z*wb), zdc=vdcbase*vdcbase/10000.0;
    real v1=x[0]*x[0]+x[1]*x[1],v2=x[2]*x[2]+x[3]*x[3];
    real il=x[4]*x[4]+x[5]*x[5],gic=x[14]*x[14]+x[15]*x[15];
    real gvf=x[16]*x[16]+x[17]*x[17],gif=x[18]*x[18]+x[19]*x[19];
    real cic=x[26]*x[26]+x[27]*x[27],cvf=x[28]*x[28]+x[29]*x[29];
    real cif=x[30]*x[30]+x[31]*x[31],dc2=x[23]*x[23];
    out[0]=(cfg[SG_B_BUS]*(v1+v2)+cfg[SG_X_LINE]*il+cfg[SG_GFM_LF]*gic+cfg[SG_GFM_CF]*gvf+cfg[SG_GFM_LG]*gif
           +cfg[SG_CPL_LF]*cic+cfg[SG_CPL_CF]*cvf+cfg[SG_CPL_LG]*cif+cfg[SG_C_DC]*dc2)/(2.0*wb);
    out[1]=(cfg[SG_GFM_DC]*vdcbase)*idc_g/10000.0;
    out[2]=g0*v2+dc2/cfg[SG_R_LOAD]-injected_power;
    out[3]=cfg[SG_GFM_RF]*gic+cfg[SG_GFM_RG]*gif+cfg[SG_R_LINE]*il+cfg[SG_CPL_RF]*cic+cfg[SG_CPL_RG]*cif;
}
