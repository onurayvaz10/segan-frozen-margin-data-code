#ifndef SEGAN_CONTROLLER_MATH_H
#define SEGAN_CONTROLLER_MATH_H
enum {SG_R_LINE,SG_X_LINE,SG_B_BUS,SG_R_LOAD,SG_C_DC,SG_GFM_DC,
SG_GFM_RP,SG_GFM_KQ,SG_GFM_W_P,SG_GFM_W_Q,SG_GFM_RV,SG_GFM_LV,
SG_GFM_KPV,SG_GFM_KIV,SG_GFM_KPC,SG_GFM_KIC,SG_GFM_W_AD,SG_GFM_K_AD,
SG_GFM_LF,SG_GFM_RF,SG_GFM_CF,SG_GFM_LG,SG_GFM_RG,
SG_CPL_LF,SG_CPL_RF,SG_CPL_CF,SG_CPL_LG,SG_CPL_RG,
SG_CPL_KPC,SG_CPL_KIC,SG_CPL_KP_PLL,SG_CPL_KI_PLL,SG_CPL_KPV,SG_CPL_KIV};
void segan_control_math(const double*x,const double*r,const double*cfg,double*u,double*d);
void segan_energy_math(const double*x,const double*cfg,double g0,double injected_power,double idc_g,double*out);
#endif
