"""Support-preserving Y5 endpoint correction, supplemental version v4.

The frozen classifier is retained separately. No fabricated boundary samples,
new noise threshold, or changed envelope bin is introduced here. A zero early
envelope cannot establish decay and therefore returns an abstention.
"""
import numpy as np

VERSION='support-preserving-v4'
W=5

def centered_mean(v):
    v=np.asarray(v,dtype=float)
    result=np.full(len(v),np.nan)
    if len(v)>=W:result[2:-2]=np.convolve(v,np.ones(W)/W,mode='valid')
    return result

def classify_mean(ts,vs,eq,Tr=0.25,T=2.75,broke=False,rounding=0.0):
    ts=np.asarray(ts,dtype=float); vs=np.asarray(vs,dtype=float)
    dev=abs(vs-eq);n=len(ts)
    out={'version':VERSION,'label':'undetermined','R':None,'reason':None}
    if n!=len(vs) or n<11:
        out['reason']='insufficient_record';return out
    if np.any(~np.isfinite(ts)) or np.any(np.diff(ts)<=0) or not np.isfinite(vs[2:-2]).all():
        out['reason']='invalid_record';return out
    inner=float(np.max(dev[5:-5]));out['interior_max_pu']=inner
    if inner>0.5 or broke or ts[-1]<T-1e-3:
        out.update(label='diverged',reason='original_interior_or_early_stop_gate');return out
    supported=np.arange(n);supported=(supported>=2)&(supported<n-2)
    envelopes=[]
    for a,b in ((Tr+0.5,Tr+1.0),(T-0.5,T)):
        peaks=[]
        for u in np.arange(a,b-1e-9,0.05):
            mask=supported&(ts>=u)&(ts<u+0.05)
            if not mask.any():out['reason']='missing_envelope_bin';return out
            peaks.append(float(np.max(dev[mask])))
        envelopes.append(float(np.mean(peaks)))
    early,late=envelopes;out.update(early_envelope_pu=early,late_envelope_pu=late)
    if early<=rounding:
        out['reason']='early_envelope_unresolved';return out
    ratio=late/early
    lo=max(0,late-rounding)/(early+rounding)
    hi=(late+rounding)/(early-rounding)
    label='growing' if ratio>1.2 else 'decaying' if ratio<0.8 else 'undetermined'
    robust=(lo>1.2 if label=='growing' else hi<0.8 if label=='decaying' else lo>=0.8 and hi<=1.2)
    out.update(label=label,R=ratio,R_rounding_interval=[lo,hi],label_robust_to_rounding=bool(robust),reason='original_ratio_thresholds_on_supported_centers')
    return out

def classify(ts,vb,eq,Tr=0.25,T=2.75):
    return classify_mean(ts,centered_mean(vb),eq,Tr,T)
