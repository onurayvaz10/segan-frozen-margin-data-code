"""Independent arithmetic audit of retained raw captures; no simulator run."""
from pathlib import Path
import json, hashlib, csv
import numpy as np

B=Path(__file__).resolve().parent;WORK=B if (B/'segan_typhoon').exists() else B.parent;VH=WORK/'segan_typhoon';N=WORK/'independent_emt';OUT=B/'analysis';OUT.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
protocol=read(WORK/'virtual_hil_protocol.json');gates=protocol['simulation_gates'];plan=read(N/'ramp_plan.json');post=read(N/'post_equilibrium.json')
cases=['F2-0.65-0.20','A2-F00993','F2-0.60-0.20'];results={}
for case in cases:
 runs={};checks=[]
 for scenario,step in [('baseline','0p025'),('ramp','0p025'),('ramp','0p05')]:
  d=VH/'validation_runs'/f'{case}_{scenario}_{step}us';a=np.genfromtxt(d/'capture.csv',delimiter=',',names=True);s=read(d/'run_status.json');t=a['time_s']
  stem=f'segan_closed_{case}_dt{step}us';timing=read(VH/(stem+'.compiled_timing.json'))
  assert sha(d/'capture.csv')==s['capture_sha256']
  assert timing['compiled_timing_valid'] and timing['no_execution_adjustments'] and timing['cpd_sha256']==s['cpd_sha256']
  assert timing['controller_execution_rates_s']==[s['circuit_step_s']]
  compiled=VH/(stem+' Target files')/(stem+'.json');cpd=VH/(stem+' Target files')/(stem+'.cpd')
  assert sha(compiled)==timing['compiled_json_sha256'] and sha(cpd)==timing['cpd_sha256']
  expected_duration=0.5 if scenario=='baseline' else 2.75
  assert len(t)==round(expected_duration/0.0004) and abs(t[-1]-expected_duration)<2e-6 and np.all(np.diff(t)>0)
  clockerror=float(np.max(abs(t-np.arange(1,len(t)+1)*0.0004)));assert clockerror<2e-6
  assert all(s['flags'][k] is False for k in ['FL_ARITHMETIC_OVERFLOW','FL_DEAD_TIME','FL_SP_EXC_OCCURRED','FL_COMP_INT_OVERRUN'])
  runs[(scenario,step)]=a;checks.append({'scenario':scenario,'step_s':s['circuit_step_s'],'max_record_clock_error_s':clockerror,'capture_and_compiled_hashes_verified':True,'no_adjusted_rates':True,'controller_actual_rate_s':timing['controller_execution_rates_s'][0]})
 fine=runs['ramp','0p025'];base=runs['baseline','0p025'];coarse=runs['ramp','0p05'];t=fine['time_s'];tail=base['time_s']>=0.4
 path=VH/'independent_reference_integral'/f'{case}_ramp_80_50us.npz';meta=read(path.with_suffix('.json'));assert sha(path)==meta['npz_sha256']
 r=np.load(path);rt=np.r_[0,r['time_s']];means=[]
 for k in ['d','q']:
  means.append(np.interp(t,rt,np.r_[r[f'initial_vbus2_{k}_pu'],r[f'vbus2_{k}_cycle_mean_pu']]))
 refbus=np.hypot(*means);cal=read(N/f'calibration_{case}.json');x0=cal['initial_state_independent_order'];refdc=np.interp(t,rt,np.r_[x0[23],r['vdc_pu']])
 rmse=lambda x:float(np.sqrt(np.mean(x*x)))
 metric={'steady_bus_abs_error_pu':abs(float(np.mean(base['vbus2_ll_rms_pu'][tail]))-np.hypot(x0[2],x0[3])),
 'steady_dc_abs_error_pu':abs(float(np.mean(base['vdc_pu'][tail]))-x0[23]),'dynamic_bus_rmse_pu':rmse(fine['vbus2_ll_rms_pu']-refbus),'dynamic_dc_rmse_pu':rmse(fine['vdc_pu']-refdc),'step_refinement_bus_rmse_pu':rmse(fine['vbus2_ll_rms_pu']-np.interp(t,coarse['time_s'],coarse['vbus2_ll_rms_pu']))}
 old=read(VH/'comparison_results'/f'{case}.json')
 for k,val in metric.items():assert abs(val-old[k])<1e-12,(case,k,val,old[k])
 physics={}
 for label,a in [('baseline',base),('ramp',fine)]:
  delta=float(a['stored_energy_pu_s'][-1]-a['stored_energy_pu_s'][0]);net=float(a['integrated_balance_pu_s'][-1]-a['integrated_balance_pu_s'][0]);supply=float(a['supplied_energy_pu_s'][-1]-a['supplied_energy_pu_s'][0]);res=delta-net;rel=abs(res)/max(abs(supply),abs(float(a['stored_energy_pu_s'][0])),1e-9)
  peak=float(max(a['peak_gfm_mod'][-1],a['peak_rectifier_mod'][-1]));dc=float(a['minimum_dc_pu'][-1]);physics[label]={'energy_relative':rel,'energy_residual_pu_s':res,'peak_modulation':peak,'minimum_dc_pu':dc}
  assert abs(rel-old[label]['energy']['relative_error'])<1e-12 and peak==old[label]['peak_modulation'] and dc==old[label]['minimum_dc_pu']
 key=next(k for k,v in plan['cases'].items() if v['calibration_id']==case);target=post[key]['post_equilibrium_bus2_pu']
 def env(a,b):return float(np.mean([np.max(abs(fine['vbus2_ll_rms_pu'][(t>=u)&(t<u+0.05)]-target)) for u in np.arange(a,b-1e-9,0.05)]))
 noise=float(np.max(abs(base['vbus2_ll_rms_pu'][tail]-np.median(base['vbus2_ll_rms_pu'][tail]))));early=env(0.75,1.25);late=env(2.25,2.75);ratio=late/early
 label='undetermined'
 if early>5*noise:
  if late<=5*noise or ratio<0.8:label='decaying'
  elif ratio>1.2:label='growing'
 assert label==old['stability_diagnostic']['label']
 recomputed={'steady_bus':metric['steady_bus_abs_error_pu']<=gates['steady_bus2_ll_rms_abs_error_max_pu'],'steady_dc':metric['steady_dc_abs_error_pu']<=gates['steady_dc_abs_error_max_pu'],'dynamic_bus':metric['dynamic_bus_rmse_pu']<=gates['dynamic_bus2_ll_rms_rmse_max_pu'],'dynamic_dc':metric['dynamic_dc_rmse_pu']<=gates['dynamic_dc_rmse_max_pu'],'step_refinement':metric['step_refinement_bus_rmse_pu']<=gates['typhoon_step_refinement_bus2_rmse_max_pu'],'modulation':max(x['peak_modulation'] for x in physics.values())<=gates['peak_modulation_max'],'positive_dc':min(x['minimum_dc_pu'] for x in physics.values())>0,'energy':max(x['energy_relative'] for x in physics.values())<=gates['energy_balance_relative_error_max'],'runtime_flags':True,'compiled_timing':True}
 recomputed={k:bool(v) for k,v in recomputed.items()}
 assert recomputed==old['gates']
 stability={'noise_pu':noise,'early_pu':early,'late_pu':late,'ratio':ratio,'early_over_noise':early/noise,'label':label,'fine_coarse_RMSE_over_early':metric['step_refinement_bus_rmse_pu']/early}
 # Clarify that a sampled decimated variance is not a guaranteed error bound
 # on the continuous switching voltage or an eigenvalue estimate.
 results[case]={'metrics':metric,'physics':physics,'clock_checks':checks,'stability':stability,'all_reported_metrics_reproduced':True,'unchanged_original_gates':old['gates'],'recomputed_gates':recomputed,'numeric_pass':all(recomputed.values()),'reference_sha256':sha(path),'native_window_duration_error_s':{'25ns':round((1/60)/25e-9)*25e-9-1/60,'50ns':round((1/60)/50e-9)*50e-9-1/60}}
(OUT/'virtual_hil_raw_audit.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
print(json.dumps({c:{**r['metrics'],'stability':r['stability']} for c,r in results.items()},indent=2))
