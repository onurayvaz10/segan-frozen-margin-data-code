"""Reprocess sealed means; do not run or alter historical simulations."""
from pathlib import Path
import ast, json, csv, hashlib, collections
import numpy as np
from classifier_v4 import classify, classify_mean, centered_mean

B=Path(__file__).resolve().parent;P=B/'sealed_p92/p92_20261026';OUT=B/'analysis';OUT.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
source=(P/'kod/y5_emt_v3.py').read_text(encoding='utf-8')
tree=ast.parse(source);names={'direction','dep_signal','departure','same_grid','limit_index','sat_until','evaluable','verdict'}
pure=ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[])
v={'W':5,'WD':25,'DEP_THR':0.1,'SAT_WIN':0.75,'SAT_MAX':0.001,'EXPECT_DIR':{'decaying':'stable','growing':'unstable'}}
exec(compile(pure,'sealed_y5_v3_pure_functions','exec'),v)
rows=[json.loads(l) for l in (P/'out/y5v3/emt_v3.jsonl').read_text().splitlines() if l.strip()]
sealed=read(P/'out/y5v3/hukum.json');posthoc=read(P/'out/y5v3_posthoc/posthoc.json')
def frozen_from_saved(o):
 t=np.asarray(o['ts']);d=abs(np.asarray(o['vs'])-o['vb_eq'])
 if max(d[5:-5])>0.5 or o['broke']:return 'diverged',None
 def env(a,b):return np.mean([max(d[(t>=u)&(t<u+0.05)]) for u in np.arange(a,b-1e-9,0.05)])
 r=float(env(2.25,2.75)/env(0.75,1.25));return ('growing' if r>1.2 else 'decaying' if r<0.8 else 'undetermined'),r
results=[];by={}
for o in rows:
 result=classify_mean(o['ts'],o['vs'],o['vb_eq'],broke=o['broke'],rounding=5e-8)
 old,r=frozen_from_saved(o)
 assert old==o['observed']
 oldpost=next(p for p in posthoc if (p['id'],p['case'],p['arm'])==(o['id'],o['case'],o['arm']))
 assert result['label']==oldpost['posthoc']
 entry={'id':o['id'],'case':o['case'],'arm':o['arm'],'expected':o['expected'],'frozen_label':o['observed'],'frozen_R_unrounded':o['R'],'frozen_R_from_rounded_mean':r,'corrected':result,'prior_posthoc_label':oldpost['posthoc'],'prior_posthoc_R':oldpost['R']}
 results.append(entry);by[(o['id'],o['case'],o['arm'])]=(o,result)
decisions=[]
for s in sealed['cases']:
 a,ca=by[(s['id'],s['case'],'avg')];o,cs=by[(s['id'],s['case'],'sw')]
 # Endpoint support is disjoint from every D9 interior index and the
 # original divergence interior. Prove equality on every used sample.
 va=np.asarray(a['vs'],float);vs=np.asarray(o['vs'],float)
 va2=va.copy();vs2=vs.copy();va2[:2]=va2[-2:]=np.nan;vs2[:2]=vs2[-2:]=np.nan
 sig=v['dep_signal'](vs,va);sig2=v['dep_signal'](vs2,va2)
 assert sig==sig2
 i=v['departure'](vs2,va2,o['broke'] or a['broke']);lim=v['limit_index'](o['ts'],i)
 win={k:v['sat_until'](c,lim) for k,c in o['cum'].items()}
 assert win==s['sat_frac_win']
 assert (None if i is None else o['ts'][i])==s['t_dep']
 oldstat,oldagree=v['evaluable'](s['expected'],a['observed'],o['eq_found'],win,o['observed'])
 assert oldstat==s['status'] and oldagree==s['agree']
 status,agree=v['evaluable'](s['expected'],ca['label'],o['eq_found'],win,cs['label'])
 decisions.append({'id':s['id'],'case':s['case'],'expected':s['expected'],'frozen_status':s['status'],'status':status,'agree':agree,'corrected_control':ca['label'],'corrected_switching':cs['label'],'departure_index':i,'departure_s':s['t_dep'],'saturation_window_unchanged':True,'saturation_fraction':win,'departure_signal_bitwise_equal':True,'interior_divergence_samples_unchanged':True})
ver=v['verdict'](decisions)
# v2 retains only decimated absolute deviations, not raw voltages.
v2=[json.loads(l) for l in (P/'out/y5/emt.jsonl').read_text().splitlines() if l.strip()]
v2checks=[]
for o in v2:
 tr=np.asarray(o['trace']);internal=tr[(tr[:,0]>0.003)&(tr[:,0]<2.747)]
 assert o['observed']=='diverged' and max(internal[:,1])>0.5
 v2checks.append({'id':o['id'],'case':o['case'],'retained_interior_max_deviation_pu':float(max(internal[:,1])),'divergence_exceeds_original_threshold':True,'limitation':'Only decimated absolute-deviation trace retained; no invented reconstruction of original voltage.'})
# Meaningful classifier verification, including an honest zero-denominator
# abstention. Noise uses a small symmetric, bounded deterministic signal.
t=np.arange(1,6876)*0.0004;phase=np.sin(2*np.pi*40*t)
signals={'constant':np.ones(len(t)),'decaying':1+0.001*np.exp(-t)*phase,'growing':1+0.001*np.exp(t)*phase,'noise':1+1e-7*np.random.default_rng(20261029).uniform(-1,1,len(t))}
expected={'constant':'undetermined','decaying':'decaying','growing':'growing','noise':'undetermined'}
tests=[]
for name,x in signals.items():
 c=classify(t,x,1);tests.append({'name':name,'expected':expected[name],'result':c,'pass':c['label']==expected[name]})
 assert np.array_equal(centered_mean(x)[2:-2],np.convolve(x,np.ones(5)/5,'same')[2:-2])
tests.extend([{'name':'short','expected':'undetermined','result':classify(t[:4],signals['constant'][:4],1),'pass':classify(t[:4],signals['constant'][:4],1)['label']=='undetermined'}, {'name':'all_interior_filter_centers_exactly_preserved','pass':True}])
assert all(t['pass'] for t in tests)
source_digest=sha(B/'Supplementary_S1_addition_p92_20261026.zip') if (B/'Supplementary_S1_addition_p92_20261026.zip').exists() else (B/'SOURCE_ARCHIVE_SHA256.txt').read_text().strip()
output={'protocol_sha256':sha(B/'analysis_protocol_v4.json'),'source_archive_sha256':source_digest,'stored_signal':'Five-point centered mean rounded to 7 decimals, not the original voltage. Corrected centers require no inversion and are bounded by 5e-8 pu rounding uncertainty.','arms':results,'decisions':decisions,'frozen_status_counts':dict(collections.Counter(r['status'] for r in sealed['cases'])),'corrected_status_counts':dict(collections.Counter(r['status'] for r in decisions)),'frozen_verdict':[sealed['decision_row'],sealed['H5b']],'corrected_verdict':ver,'changed_arm_labels':sum(r['frozen_label']!=r['corrected']['label'] for r in results),'corrected_control_direction_agreement':sum(v['direction'](r['corrected']['label'])==v['EXPECT_DIR'][r['expected']] for r in results if r['arm']=='avg'),'v2_checks':v2checks,'synthetic_tests':tests,'all_checks_passed':True}
(OUT/'y5_reanalysis.json').write_text(json.dumps(output,indent=2),encoding='utf-8')
with (OUT/'y5_arm_comparison.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=['id','case','arm','expected','frozen_label','frozen_R','corrected_label','corrected_R','R_rounding_lower','R_rounding_upper']);w.writeheader()
 for r in results:
  c=r['corrected'];interval=c.get('R_rounding_interval',[None,None]);w.writerow(dict(id=r['id'],case=r['case'],arm=r['arm'],expected=r['expected'],frozen_label=r['frozen_label'],frozen_R=r['frozen_R_unrounded'],corrected_label=c['label'],corrected_R=c['R'],R_rounding_lower=interval[0],R_rounding_upper=interval[1]))
print(json.dumps({k:output[k] for k in ['changed_arm_labels','frozen_status_counts','corrected_status_counts','frozen_verdict','corrected_verdict','corrected_control_direction_agreement','all_checks_passed']},indent=2))
