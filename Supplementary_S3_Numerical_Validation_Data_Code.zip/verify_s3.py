from pathlib import Path
import hashlib,json,sys
b=Path(__file__).resolve().parent
m=json.loads((b/'manifest.json').read_text(encoding='utf-8'))
bad=[]
for name,digest in m['sha256'].items():
 p=b/name
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:bad.append(name)
print(json.dumps({'files_checked':len(m['sha256']),'failures':bad,'pass':not bad},indent=2))
sys.exit(1 if bad else 0)
