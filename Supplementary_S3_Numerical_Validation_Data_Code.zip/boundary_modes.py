"""Prospectively fixed four-point averaged local-mode supplement."""
from pathlib import Path
import sys,json,hashlib
import numpy as np
B=Path(__file__).resolve().parent;N=(B if (B/'independent_emt').exists() else B.parent)/'independent_emt';sys.path.insert(0,str(N))
from model import rhs,References,Settings
plan=json.loads((B/'analysis_protocol_v4.json').read_text())['extra_averaged_boundary_analysis']
rows=[json.loads(l) for l in (B/'sealed_p92/p92_20261026/out/y5v3/emt_v3.jsonl').read_text().splitlines() if l.strip()]
def jac(f,x,h):
 result=np.empty((len(x),len(x)))
 for j in range(len(x)):
  step=h*max(abs(x[j]),1);v=np.zeros(len(x));v[j]=step;result[:,j]=(f(x+v)-f(x-v))/(2*step)
 return result
out=[]
for case in plan['cases']:
 cal=json.loads((N/f'calibration_{case}.json').read_text());refs=References(*cal['references']['setpoints'],theta_g=cal['references']['theta_g']);cfg=Settings(**cal['settings']);x0=np.array(cal['initial_state_independent_order']);gt=next(r['dGt'] for r in rows if r['id']==case);g=cal['g_resistive']
 for mult in plan['shed_multipliers_of_archived_reference_margin']:
  dg=mult*gt;x=x0.copy();ok=True;residual=None
  for frac in np.arange(1,21)/20:
   f=lambda v:rhs(0,v,refs,g-dg*frac,cfg)
   for iteration in range(30):
    y=f(x);residual=float(np.max(abs(y)))
    if residual<1e-9:break
    change=np.linalg.solve(jac(f,x,1e-6),-y)
    accepted=False
    for reduction in [1,.5,.25,.125,.0625,.03125]:
     candidate=x+reduction*change
     if candidate[23]>0 and max(abs(f(candidate)))<residual:x=candidate;accepted=True;break
    if not accepted:break
   residual=float(np.max(abs(f(x))))
   if residual>plan['equilibrium_residual_inf_max_per_s']:ok=False;break
  record={'case':case,'margin_multiplier':mult,'archived_reference_margin_pu':gt,'shed_pu':dg,'positive_remaining_conductance':bool(g-dg>0),'equilibrium_found':ok,'residual_inf_per_s':residual}
  if ok:
   eigs=[np.linalg.eigvals(jac(f,x,h)) for h in plan['central_jacobian_relative_steps']];alphas=[float(max(e.real)) for e in eigs];delta=abs(alphas[0]-alphas[1]);stable=alphas[-1]<-0.001;unstable=alphas[-1]>0.001
   k=int(np.argmax(eigs[-1].real));dom=eigs[-1][k]
   record.update(spectral_abscissa_per_s=alphas,finite_difference_agreement_per_s=delta,dominant_imaginary_per_s=float(abs(dom.imag)),dominant_frequency_hz=float(abs(dom.imag)/(2*np.pi)),label=('stable_local_average' if stable else 'unstable_local_average' if unstable else 'undetermined') if delta<=.001 else 'undetermined',local_time_constant_s=float(1/abs(alphas[-1])) if alphas[-1]!=0 else None,post_equilibrium=x.tolist())
  out.append(record)
result={'scope':plan['scope'],'protocol_sha256':hashlib.sha256((B/'analysis_protocol_v4.json').read_bytes()).hexdigest(),'points':out,'not_a_switched_boundary_test':True}
(B/'analysis/averaged_boundary_modes.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps([{k:v for k,v in r.items() if k!='post_equilibrium'} for r in out],indent=2))
