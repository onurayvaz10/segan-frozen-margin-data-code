"""New figures of the development round (all numbers read from the files named below; nothing is typed in).

fig_kappa_sign.png      (a) distribution of kappa_hat in the Sobol sets of A2, B2, C and the search end points;
                        (b) observed relative frozen-margin error vs predicted kappa/(1-kappa), by family, with the
                            four direction quadrants (TSV run).
fig_accuracy_cost.png   (a) MAE vs median wall-clock time per estimator (Pareto), (b) |relative error| of the
                        first- and second-order estimates vs eps2 with the eps2/4 prediction.
fig_current_limit.png   (a) change of kappa, frozen and reference margins vs limiter utilisation at x0,
                        (b) abrupt-shedding envelopes with and without current limiting.
fig_estimator_errors.png signed relative errors of the seven estimators by kappa stratum (supplementary).
Sources: out/p2_explore_*.jsonl, out/p3_boundary_*.jsonl, out/tsv/TSV_a/analysis/points.csv and estimators.csv,
out/p12_cost.csv, out/p5_current_limit_A.csv, out/p5_traces_B.csv. Output: sekil/*.png at 600 dpi.
"""
import csv
import json
import os
import math
import sys
from pathlib import Path

import matplotlib
import numpy as np

matplotlib.use('Agg')
import matplotlib.pyplot as plt  # noqa: E402

HERE = Path(__file__).resolve().parent
OUT = Path(os.environ.get('G91_OUT', str(HERE.parent / 'out')))
FIG = HERE.parent / 'sekil'
FIG.mkdir(exist_ok=True)
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8.5, 'axes.titlesize': 9, 'axes.labelsize': 8.5,
                     'legend.fontsize': 7.5, 'xtick.labelsize': 7.5, 'ytick.labelsize': 7.5,
                     'mathtext.fontset': 'dejavusans', 'axes.linewidth': 0.7, 'savefig.bbox': 'tight',
                     'savefig.pad_inches': 0.03})
W2 = 7.48
COL = {'A2': '#1b9e77', 'B2': '#d95f02', 'C': '#7570b3', 'F2': '#444444'}
DPI = 600


def save(fig, name):
    fig.savefig(FIG / f'{name}.png', dpi=DPI)
    plt.close(fig)
    print('wrote', name)


def panel(ax, s, x=-0.12, y=1.03):
    ax.text(x, y, s, transform=ax.transAxes, fontsize=9.5, fontweight='bold', va='bottom')


def fnum(v):
    try:
        x = float(v)
        return x if math.isfinite(x) else float('nan')
    except (TypeError, ValueError):
        return float('nan')


def load_jsonl(p):
    return [json.loads(l) for l in open(p, encoding='utf-8')] if p.exists() else []


def fig_kappa_sign():
    pts = list(csv.DictReader(open(OUT / 'tsv' / 'TSV_a' / 'analysis' / 'points.csv', encoding='utf-8')))
    fig, (a, b) = plt.subplots(1, 2, figsize=(W2, 2.9), gridspec_kw=dict(width_ratios=[1, 1.15], wspace=0.32))
    fams = ['A2', 'B2', 'C']
    for i, s in enumerate(fams):
        k = np.array([fnum(r['kappa']) for r in pts if r['system'] == s and r['source'] != 'search'])
        ks = np.array([fnum(r['kappa']) for r in pts if r['system'] == s and r['source'] == 'search'])
        y = i + np.random.default_rng(i).uniform(-0.18, 0.18, len(k))
        a.scatter(k, y, s=5, color=COL[s], alpha=0.55, lw=0, label=None)
        a.scatter(ks, i + 0.32 + 0 * ks, s=14, marker='v', facecolor='none', edgecolor=COL[s], lw=0.8)
    a.axvspan(-0.05, 0.05, color='#bbbbbb', alpha=0.35, lw=0)
    a.axvline(0, color='k', lw=0.6)
    a.set_yticks(range(3), fams)
    a.set_xlabel(r'first-order coefficient $\hat\kappa$')
    a.set_xlim(-0.6, 1.2)
    a.set_ylim(-0.6, 2.7)
    panel(a, '(a)')
    for s in fams:
        rr = [r for r in pts if r['system'] == s and abs(fnum(r['kappa'])) >= 0.05 and r['ref_sign'] not in ('0', '0.0')]
        x = np.array([min(fnum(r['kappa']) / (1 - fnum(r['kappa'])), 1.45) if fnum(r['kappa']) < 1 else 1.45 for r in rr])
        yv = np.array([fnum(r['rel_err']) for r in rr])
        src = np.array([r['source'] for r in rr])
        m = src != 'search'
        b.scatter(x[m], 100 * yv[m], s=7, color=COL[s], alpha=0.65, lw=0, label=f'{s} (sampled)')
        b.scatter(x[~m], 100 * yv[~m], s=16, marker='v', facecolor='none', edgecolor=COL[s], lw=0.8,
                  label=f'{s} (search)')
    b.axhline(0, color='k', lw=0.6)
    b.axvline(0, color='k', lw=0.6)
    b.set_xlim(-0.3, 1.5)
    b.set_ylim(-20, 106)
    b.set_xlabel(r'predicted relative shift $\hat\kappa/(1-\hat\kappa)$ (clipped at 1.45)')
    b.set_ylabel(r'observed $(\Delta G_t^*-\Delta G_f^*)/\Delta G_f^*$ (%)')
    xl = b.get_xlim()
    yl = b.get_ylim()
    b.text(0.03, 0.04, 'predicted optimistic,\nobserved optimistic', transform=b.transAxes, fontsize=6.4, va='bottom')
    b.text(0.97, 0.96, 'predicted conservative,\nobserved conservative', transform=b.transAxes, fontsize=6.4,
           va='top', ha='right')
    b.legend(loc='upper left', fontsize=6.2, ncol=1, frameon=False, bbox_to_anchor=(0.0, 0.93))
    panel(b, '(b)')
    save(fig, 'fig_kappa_sign')


def fig_accuracy_cost():
    est = [r for r in csv.DictReader(open(OUT / 'tsv' / 'TSV_a' / 'analysis' / 'estimators.csv', encoding='utf-8'))]
    cost = list(csv.DictReader(open(OUT / 'p12_cost.csv', encoding='utf-8')))
    pts = list(csv.DictReader(open(OUT / 'tsv' / 'TSV_a' / 'analysis' / 'points.csv', encoding='utf-8')))
    fig, (a, b) = plt.subplots(1, 2, figsize=(W2, 2.9), gridspec_kw=dict(wspace=0.32))
    names = dict(frozen='frozen', first_order='first order', first_order_noc='first order, no $c$ term',
                 first_order_L='load-side first order', second_order='second order', secant_1='secant, 1 solve',
                 secant_2='secant, 2 solves')
    cmap = {'frozen': 'frozen', 'first_order': 'first_order', 'first_order_noc': 'first_order',
            'first_order_L': 'first_order', 'second_order': 'second_order', 'secant_1': 'secant_1',
            'secant_2': 'secant_2'}
    for fam, mk in (('A2', 'o'), ('B2', 's'), ('C', '^')):
        tmed = {}
        for e in set(cmap.values()) | {'reference'}:
            v = [fnum(r['wall_median']) for r in cost if r['family'] == fam and r['estimator'] == e]
            if v:
                tmed[e] = float(np.median(v))
        for r in est:
            if r['set'] != fam or r['estimator'] not in cmap or cmap[r['estimator']] not in tmed:
                continue
            a.scatter(tmed[cmap[r['estimator']]], fnum(r['MAE']), marker=mk, s=22, color=COL[fam], lw=0, alpha=0.85)
            if fam == 'C':
                a.annotate(names[r['estimator']], (tmed[cmap[r['estimator']]], fnum(r['MAE'])), fontsize=5.8,
                           xytext=(3, 2), textcoords='offset points')
        if 'reference' in tmed:
            a.axvline(tmed['reference'], color=COL[fam], lw=0.8, ls=':')
    a.set_xscale('log')
    a.set_yscale('log')
    a.set_xticks([1, 2, 4, 8], ['1', '2', '4', '8'])
    a.minorticks_off()
    a.set_xlabel('median wall-clock time per point (s)')
    a.set_ylabel('MAE against the reference (pu)')
    a.text(0.02, 0.02, 'dotted: reference continuation', transform=a.transAxes, fontsize=6.2)
    for fam, mk in (('A2', 'o'), ('B2', 's'), ('C', '^')):
        a.scatter([], [], marker=mk, color=COL[fam], s=18, label=fam)
    a.legend(frameon=False, loc='upper right')
    panel(a, '(a)')
    rr = [r for r in pts if r.get('censored') in ('False', 'false', '0', '') and abs(fnum(r['kappa'])) >= 0.05
          and math.isfinite(fnum(r['eps2'])) and fnum(r['eps2']) > 0]
    e2 = np.array([fnum(r['eps2']) for r in rr])
    e1 = np.array([abs(fnum(r['relerr_first_order'])) for r in rr])
    e2n = np.array([abs(fnum(r['relerr_second_order'])) for r in rr])
    b.scatter(e2, 100 * e1, s=6, color='#2b5d8c', alpha=0.6, lw=0, label='first order')
    b.scatter(e2, 100 * e2n, s=6, color='#c0392b', alpha=0.6, lw=0, label='second order')
    xx = np.logspace(math.log10(max(e2.min(), 1e-4)), math.log10(e2.max()), 50)
    b.plot(xx, 100 * xx / 4, color='k', lw=0.8, ls='--', label=r'$\varepsilon_2/4$')
    b.set_xscale('log')
    b.set_yscale('log')
    b.set_xlabel(r'curvature indicator $\varepsilon_2=-2\hat\rho^{\prime\prime}\Delta G_f^*/(1-\hat\kappa)^2$')
    b.set_ylabel('|relative error| (%)')
    b.legend(frameon=False, loc='lower right')
    panel(b, '(b)')
    save(fig, 'fig_accuracy_cost')


def fig_current_limit():
    A = list(csv.DictReader(open(OUT / 'p5_current_limit_A.csv', encoding='utf-8')))
    base = {r['member']: r for r in A if r['scenario'] == 'L0'}
    fig, (a, b) = plt.subplots(1, 2, figsize=(W2, 2.9), gridspec_kw=dict(wspace=0.34))
    for key, mk, lab in (('kappa', 'o', r'$\hat\kappa$'), ('dGf', 's', r'$\Delta G_f^*$'), ('dGt', '^', r'$\Delta G_t^*$')):
        for pp, fc in (('p20', 'none'), ('p8', 'k')):
            xs, ys = [], []
            for r in A:
                if not r['scenario'].startswith('GFM') or not r['scenario'].endswith(pp) or r.get('excl') not in ('', None):
                    continue
                b0 = base[r['member']]
                u = fnum(r['u_gfm_x0'])
                v, v0 = fnum(r.get(key)), fnum(b0.get(key))
                if math.isfinite(u) and math.isfinite(v) and math.isfinite(v0) and v0 != 0:
                    xs.append(u)
                    ys.append(100 * abs(v - v0) / abs(v0))
            a.scatter(xs, np.maximum(ys, 1e-9), marker=mk, s=16, facecolor=fc, edgecolor='k', lw=0.7,
                      label=lab + (' ($p$ = 20)' if pp == 'p20' else ' ($p$ = 8)'))
    a.axhline(1.0, color='#888888', lw=0.5, ls=':')
    a.set_yscale('log')
    a.set_xlabel(r'limiter utilisation at $x_0$, $|i_{ref}|/I_{max}$')
    a.set_ylabel('relative change vs. no limiter (%)')
    a.set_ylim(1e-7, 1e7)
    a.legend(frameon=False, loc='upper left', fontsize=6.0, ncol=3, columnspacing=0.8, handletextpad=0.3)
    panel(a, '(a)')
    tr = list(csv.DictReader(open(OUT / 'p5_traces_B.csv', encoding='utf-8')))
    sty = {'L0': ('-', 'no limiter'), 'GFM_I1.2_p20': ('--', r'GFM $I_{max}$ = 1.2'),
           'GFM_I1_p20': (':', r'GFM $I_{max}$ = 1.0'), 'CPL_I1_p20': ((0, (5, 1, 1, 1)), r'CPL $I_{max}$ = 1.0')}
    cc = {'frozen': '#1b9e77', 'recorded_reference': '#c0392b'}
    for sc, (ls, lab) in sty.items():
        for case, colr in cc.items():
            t = np.array([fnum(r['time_s']) for r in tr if r['scenario'] == sc and r['case'] == case])
            v = np.array([abs(fnum(r['bus_voltage_dev_pu'])) for r in tr if r['scenario'] == sc and r['case'] == case])
            if not len(t):
                continue
            edges = np.arange(0, t.max() - 0.05 + 1e-9, 0.05)          # complete 50-ms windows only
            env = np.array([v[(t >= e0) & (t < e0 + 0.05)].max() for e0 in edges])
            b.plot(edges + 0.025, env, ls=ls, color=colr, lw=1.0, label=lab if case == 'frozen' else None)
            if sc == 'L0' and case == 'recorded_reference':
                b.plot(t.max(), min(env[-1], 1.5), marker='x', color=colr, ms=6, mew=1.2)
    b.set_yscale('log')
    b.set_ylim(1e-6, 3)
    b.set_xlim(0, 3)
    b.set_xlabel('time after the shedding step (s)')
    b.set_ylabel('50-ms envelope of |bus voltage deviation| (pu)')
    b.legend(frameon=False, fontsize=6.2, loc='center right')
    panel(b, '(b)')
    save(fig, 'fig_current_limit')


def fig_estimator_errors():
    pts = list(csv.DictReader(open(OUT / 'tsv' / 'TSV_a' / 'analysis' / 'points.csv', encoding='utf-8')))
    rr = [r for r in pts if r.get('censored') in ('False', 'false', '0', '') and abs(fnum(r['kappa'])) >= 0.05]
    names = ['frozen', 'first_order', 'first_order_noc', 'first_order_L', 'second_order', 'secant_1', 'secant_2']
    labels = ['frozen', 'first\norder', 'first, no\n$c$ term', 'load-side\nfirst', 'second\norder', 'secant\n1 solve',
              'secant\n2 solves']
    fig, axs = plt.subplots(1, 2, figsize=(W2, 2.8), sharey=True, gridspec_kw=dict(wspace=0.08))
    for ax, grp, ttl in ((axs[0], lambda r: fnum(r['kappa']) < 0, r'$\hat\kappa<0$'),
                         (axs[1], lambda r: fnum(r['kappa']) > 0, r'$\hat\kappa>0$')):
        data = [[100 * fnum(r['relerr_' + n]) for r in rr if grp(r) and math.isfinite(fnum(r['relerr_' + n]))] for n in names]
        ax.boxplot(data, whis=(0, 100), widths=0.55, medianprops=dict(color='k'), boxprops=dict(lw=0.7),
                   whiskerprops=dict(lw=0.7), capprops=dict(lw=0.7))
        ax.set_xticks(range(1, len(names) + 1), labels, fontsize=6.4)
        ax.axhline(0, color='k', lw=0.5)
        ax.set_title(f'{ttl} (n = {sum(1 for r in rr if grp(r))})')
        ax.set_yscale('symlog', linthresh=1)
    axs[0].set_ylabel('signed relative error (%)')
    save(fig, 'fig_estimator_errors')


if __name__ == '__main__':
    which = sys.argv[1:] or ['kappa_sign', 'accuracy_cost', 'current_limit', 'estimator_errors']
    for w in which:
        globals()['fig_' + w]()
