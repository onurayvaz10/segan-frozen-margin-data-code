"""Phase 1 audit: physical operating quantities of the sealed PSV evaluable points and of the 79 F2 members.

The sealed PSV gate G2 checked bus voltages, source apparent power and total load only. This script recomputes, for
every PSV point that passed Stage 1 (95 evaluable + 7 abstentions), the remaining K1 limits of the study (CPL current,
frame frequency, CPL modulation index) and the DC-link deviation from 700 V. Nothing sealed is modified.
Writes out/p1_psv_operating_audit.csv and out/p1_audit_summary.json.
"""
import csv
import json
import os
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
RI = HERE.parents[1]
OUT = Path(os.environ.get('G91_OUT', str(HERE.parent / 'out')))
sys.path.insert(0, str(HERE))
import ext_common as C  # noqa: E402
import ext_engine as X  # noqa: E402

st1 = json.load(open(RI / 'revizyon_20261025/psv/out/PSV_20261025_a/stage1.json', encoding='utf-8'))
st2 = {}
for line in open(RI / 'revizyon_20261025/psv/out/PSV_20261025_a/stage2.jsonl', encoding='utf-8'):
    o = json.loads(line)
    st2[o['id']] = o
rows = []
for q in st1:
    if q.get('excl') is not None:
        continue
    lay, G, P = C.BUILDERS['psv' + q['system']](q)
    d = X.dispatch(lay, P, G, tol=1e-12)
    oq = C.operating_quantities(lay, d['x'], d['refs'], G, P)
    gate = C.physical_gate(oq, strict=True)
    o = st2.get(q['id'], {})
    rows.append(dict(id=q['id'], system=q['system'], abstain=q['abstain'], kappa=q['kappa'], Vmin=oq['Vmin'],
                     Vmax=oq['Vmax'], z=oq['z'], I_gfm=oq['I_gfm'], I_cpl_max=max(oq['I_cpl']),
                     m_cpl_max=max(oq['m_cpl']), m_gfm=oq['m_gfm'], vdc_dev_min=min(oq['vdc_dev']),
                     vdc_dev_max=max(oq['vdc_dev']), strict_gate=gate or '', ref_sign=o.get('ref_sign'),
                     rel_err=o.get('rel_err')))
with open(OUT / 'p1_psv_operating_audit.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0]))
    w.writeheader()
    w.writerows(rows)
ev = [r for r in rows if not r['abstain']]
summ = dict(n_stage1_passed=len(rows), n_evaluable=len(ev))
for s in ('A', 'B', 'all'):
    E_ = [r for r in ev if s == 'all' or r['system'] == s]
    fails = {}
    for r in E_:
        fails[r['strict_gate'] or 'pass'] = fails.get(r['strict_gate'] or 'pass', 0) + 1
    summ[s] = dict(n=len(E_), strict_gate=fails, m_cpl_max_range=[min(r['m_cpl_max'] for r in E_), max(r['m_cpl_max'] for r in E_)],
                   vdc_dev_range=[min(r['vdc_dev_min'] for r in E_), max(r['vdc_dev_max'] for r in E_)],
                   n_overmod=sum(r['m_cpl_max'] > 1 for r in E_))
    pv = [r for r in E_ if not r['strict_gate']]
    summ[s]['physically_valid'] = len(pv)
    summ[s]['valid_kappa_neg'] = sum(r['kappa'] < 0 for r in pv)
    summ[s]['valid_ref_neg'] = sum(r['ref_sign'] == -1 for r in pv)
neg = [r for r in rows if r['kappa'] < 0]
summ['kappa_negative_point'] = neg
# F2: the sealed K1 gate already contained the modulation limit; recompute the range for the record
f2 = [m for m in json.load(open(RI / 'cdl1/out/HDL2b_20261021_a/sonuc.json', encoding='utf-8'))['members'] if m.get('in_E')]
mm = []
for m in f2:
    lay, G, P = C.build_F2(m['P_akt'], m['G_R'])
    d = X.dispatch(lay, P, G, tol=1e-12)
    oq = C.operating_quantities(lay, d['x'], d['refs'], G, P)
    mm.append((oq['m_cpl'][0], oq['vdc_dev'][0], oq['I_cpl'][0], C.physical_gate(oq, True)))
summ['F2'] = dict(n=len(mm), m_cpl_range=[min(a for a, *_ in mm), max(a for a, *_ in mm)],
                  vdc_dev_range=[min(b for _, b, *_ in mm), max(b for _, b, *_ in mm)],
                  strict_gate={k: sum(1 for *_, g in mm if (g or 'pass') == k) for k in set((g or 'pass') for *_, g in mm)})
(OUT / 'p1_audit_summary.json').write_text(json.dumps(summ, indent=1, default=float), encoding='utf-8')
print(json.dumps(summ, indent=1, default=float))
