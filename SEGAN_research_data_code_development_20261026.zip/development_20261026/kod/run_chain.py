"""Run a sequence of resumable compute steps, each as its own subprocess, retrying a step that ends with a non-zero
exit code (e.g. an intermittent native crash) up to RETRIES times. Every step resumes from its own output file, so
a retry never recomputes a finished point. Usage: python -I run_chain.py "p2_explore.py C" "p2_summary.py" ..."""
import os
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = Path(os.environ.get('G91_OUT', str(HERE.parent / 'out')))
RETRIES = 5


def log(msg):
    with open(OUT / 'chain.txt', 'a', encoding='utf-8') as f:
        f.write(time.strftime('%H:%M:%S ') + msg + '\n')


for step in sys.argv[1:]:
    args = step.split()
    for attempt in range(1, RETRIES + 1):
        r = subprocess.run([sys.executable, '-I'] + args, cwd=HERE, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        err = r.stderr.decode('utf-8', 'replace')[-600:]
        log(f'{step} attempt {attempt} exit {r.returncode}' + (f' stderr: {err!r}' if r.returncode else ''))
        if r.returncode == 0:
            break
    else:
        log(f'{step} FAILED after {RETRIES} attempts; chain stopped')
        sys.exit(1)
log('chain done')
