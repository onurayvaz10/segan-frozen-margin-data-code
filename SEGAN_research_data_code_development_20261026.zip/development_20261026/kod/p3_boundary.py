"""Phase 3: sensitivity-guided search for physically valid kappa < 0 points (predictor only; no reference computed).

Seeds: per family, the evaluable Sobol points (out/p2_explore_<s>.jsonl) with kappa < KSEED, ordered by kappa, kept
only if their normalised parameter vector is at least DMIN away (Euclidean, unit cube) from every seed kept before.
From each seed a projected normalised-gradient descent on kappa runs inside the sampling box (log parameters in log
coordinates): forward-difference gradient (step 0.01 of the box), trial steps 0.20, 0.10, 0.05, 0.025 along
-grad/|grad|, a step accepted only if the new point passes every Stage-1 gate (strict physical gate) and lowers
kappa. The search stops at kappa <= KSTOP, after NIT iterations, or when no step is accepted. Every evaluated point
is written to out/p3_boundary_<s>.jsonl with its seed id (cluster) and iteration; the end point of each seed is
flagged. Resumes from the file.
Usage: python -I p3_boundary.py A2 B2 C
"""
import json
import os
import math
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
OUT = Path(os.environ.get('G91_OUT', str(HERE.parent / 'out')))
sys.path.insert(0, str(HERE))
import ext_common as C  # noqa: E402
from p2_explore import SPACES, clean  # noqa: E402

KSEED, DMIN, KSTOP, NIT, NSEED = 0.15, 0.35, -0.10, 12, 25
LIMITS = {'C': (8, 12)}          # (iterations, seeds) for the 70-state system C (cost); A2, B2 use (NIT, NSEED)
STEPS = (0.20, 0.10, 0.05, 0.025)
FD = 0.01


def to_u(system, sp):
    u = []
    for nm, lo, hi, lg in SPACES[system]:
        v = sp[nm]
        u.append((math.log(v) - math.log(lo)) / (math.log(hi) - math.log(lo)) if lg else (v - lo) / (hi - lo))
    return np.array(u)


def from_u(system, u, base):
    sp = dict(base)
    for (nm, lo, hi, lg), ui in zip(SPACES[system], np.clip(u, 0.0, 1.0)):
        sp[nm] = float(math.exp(math.log(lo) + ui * (math.log(hi) - math.log(lo)))) if lg else float(lo + ui * (hi - lo))
    return sp


def evaluate(system, sp):
    lay, G, P = C.BUILDERS[system](sp)
    try:
        return C.stage1(lay, G, P, rec=dict(sp), strict=True)
    except Exception as exc:  # noqa: BLE001
        return dict(sp, excl='error:' + type(exc).__name__)


def seeds(system):
    ev = [json.loads(l) for l in open(OUT / f'p2_explore_{system}.jsonl', encoding='utf-8')]
    ev = sorted([r for r in ev if r.get('excl') is None and r['kappa'] < KSEED], key=lambda r: r['kappa'])
    kept = []
    for r in ev:
        u = to_u(system, r)
        if all(np.linalg.norm(u - to_u(system, k)) >= DMIN for k in kept):
            kept.append(r)
        if len(kept) >= LIMITS.get(system, (NIT, NSEED))[1]:
            break
    return kept


def run(system):
    path = OUT / f'p3_boundary_{system}.jsonl'
    done = set()
    if path.exists():
        for l in open(path, encoding='utf-8'):
            o = json.loads(l)
            if o.get('endpoint'):
                done.add(o['seed'])
    t0 = time.perf_counter()
    with open(path, 'a', encoding='utf-8') as f:
        for sd in seeds(system):
            if sd['id'] in done:
                continue
            base = dict(id=None, system=system)
            u = to_u(system, sd)
            cur = dict(sd)
            n_eval = 0
            for it in range(LIMITS.get(system, (NIT, NSEED))[0]):
                if cur['kappa'] <= KSTOP:
                    break
                g = np.zeros_like(u)
                for i in range(len(u)):
                    du = FD if u[i] + FD <= 1.0 else -FD
                    up = u.copy()
                    up[i] += du
                    r = evaluate(system, from_u(system, up, base))
                    n_eval += 1
                    g[i] = (r['kappa'] - cur['kappa']) / du if r.get('excl') is None else 0.0
                if not np.any(g):
                    break
                dirn = -g / np.linalg.norm(g)
                acc = None
                for st in STEPS:
                    un = np.clip(u + st * dirn, 0.0, 1.0)
                    r = evaluate(system, from_u(system, un, base))
                    n_eval += 1
                    r.update(seed=sd['id'], iteration=it + 1, step=st, endpoint=False)
                    f.write(json.dumps(clean(r), default=float) + '\n')
                    if r.get('excl') is None and r['kappa'] < cur['kappa']:
                        acc = (un, r)
                        break
                if acc is None:
                    break
                u, cur = acc
                C.plog(f"{system} {sd['id']} it {it + 1} kappa {cur['kappa']:.4f}", OUT / 'progress.txt')
            end = dict(cur)
            end.update(seed=sd['id'], seed_kappa=sd['kappa'], endpoint=True, n_eval=n_eval,
                       id=f"{system}-S{sd['id'].split('-')[1]}")
            f.write(json.dumps(clean(end), default=float) + '\n')
            f.flush()
            C.plog(f"{system} seed {sd['id']} from {sd['kappa']:.4f} to {cur['kappa']:.4f} "
                   f"{time.perf_counter() - t0:.0f}s", OUT / 'progress.txt')


if __name__ == '__main__':
    C.lower_priority()
    for s in sys.argv[1:]:
        run(s)
