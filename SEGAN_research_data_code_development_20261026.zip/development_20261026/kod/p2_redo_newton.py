"""Recompute the Stage-1 records excluded as 'G6-newton' after the Newton acceptance fix (stagnation at the round-off
floor below 1e-9 accepted; needed by the 70-state system C). Records are replaced in place (backup *.bak_newton).
Predictor only. Usage: python -I p2_redo_newton.py"""
import json
import os
import shutil
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = Path(os.environ.get('G91_OUT', str(HERE.parent / 'out')))
sys.path.insert(0, str(HERE))
import ext_common as C  # noqa: E402
from p2_explore import SPACES, clean  # noqa: E402

C.lower_priority()
for s in ('A2', 'B2', 'C'):
    for fname in (f'p2_explore_{s}.jsonl', f'p2_focus_{s}.jsonl'):
        p = OUT / fname
        if not p.exists():
            continue
        recs = [json.loads(l) for l in open(p, encoding='utf-8') if l.strip()]
        todo = [i for i, r in enumerate(recs) if r.get('excl') == 'G6-newton']
        if not todo:
            continue
        shutil.copy(p, str(p) + '.bak_newton')
        t0 = time.perf_counter()
        for i in todo:
            sp = {k: recs[i][k] for k, *_ in SPACES[s]}
            sp.update(id=recs[i]['id'], system=s)
            lay, G, P = C.BUILDERS[s](sp)
            recs[i] = clean(C.stage1(lay, G, P, rec=dict(sp), strict=True))
        with open(p, 'w', encoding='utf-8') as f:
            for r in recs:
                f.write(json.dumps(r, default=float) + '\n')
        n_ev = sum(1 for i in todo if recs[i].get('excl') is None)
        C.plog(f'redo {fname}: {len(todo)} recomputed, {n_ev} now evaluable, {time.perf_counter() - t0:.0f}s', OUT / 'progress.txt')
C.plog('redo done', OUT / 'progress.txt')
