"""Phase 2 summary (predictor only): prevalence of kappa < 0 and the mechanism map.

Reads out/p2_explore_<s>.jsonl and out/p2_oat.csv. Writes
  out/p2_prevalence.csv      gate outcomes, evaluable count, kappa quantiles and counts of kappa < 0, < -tau per family
  out/p2_mechanism.csv       median and IQR of kappa_V, kappa_theta, kappa_rest, Re eta, -c Im eta, c, omega, pi_d,
                             |pi_x|, anisotropy in the strata kappa < tau / kappa >= tau (Sobol evaluable points)
  out/p2_rank_corr.csv       Spearman correlation of every sampled parameter with kappa and its parts
  out/p2_oat_flips.csv       one-at-a-time sweeps in which kappa changes sign or crosses +-tau
"""
import csv
import json
import math
import os
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
OUT = Path(os.environ.get('G91_OUT', str(HERE.parent / 'out')))
sys.path.insert(0, str(HERE))
from p2_explore import SPACES  # noqa: E402

TAU = 0.05


def sp(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    return float(np.corrcoef(np.argsort(np.argsort(a)), np.argsort(np.argsort(b)))[0, 1])


def wcsv(name, rows):
    keys = []
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    with open(OUT / name, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


prev, mech, corr = [], [], []
for s in ('A2', 'B2', 'C'):
    rs = [json.loads(l) for l in open(OUT / f'p2_explore_{s}.jsonl', encoding='utf-8')]
    ex = {}
    for r in rs:
        ex[r.get('excl') or 'evaluable'] = ex.get(r.get('excl') or 'evaluable', 0) + 1
    ev = [r for r in rs if r.get('excl') is None]
    k = np.array([r['kappa'] for r in ev])
    row = dict(family=s, n=len(rs), n_evaluable=len(ev), n_kappa_neg=int(np.sum(k < 0)), n_kappa_lt_minus_tau=int(np.sum(k <= -TAU)),
               n_abstain=int(np.sum(abs(k) < TAU)), frac_neg=float(np.mean(k < 0)) if len(k) else float('nan'),
               kappa_q05=float(np.percentile(k, 5)), kappa_median=float(np.median(k)), kappa_q95=float(np.percentile(k, 95)))
    row.update({'gate_' + kk: v for kk, v in sorted(ex.items())})
    prev.append(row)
    for name, grp in (('kappa<tau', [r for r in ev if r['kappa'] < TAU]), ('kappa>=tau', [r for r in ev if r['kappa'] >= TAU])):
        m = dict(family=s, stratum=name, n=len(grp))
        for q in ('kappa_V', 'kappa_theta', 'kappa_rest', 'eta_re', 'c', 'omega', 'pi_d_re', 'pi_x_abs', 'aniso', 'xi_d', 'xi_q'):
            v = np.array([r[q] for r in grp])
            if len(v):
                m[q + '_median'] = float(np.median(v))
                m[q + '_q25'] = float(np.percentile(v, 25))
                m[q + '_q75'] = float(np.percentile(v, 75))
        v = np.array([-r['c'] * r['eta_im'] for r in grp])
        if len(v):
            m['minus_c_Im_eta_median'] = float(np.median(v))
        mech.append(m)
    kk = np.array([r['kappa'] for r in ev])
    parts = dict(kappa=kk, kappa_V=np.array([r['kappa_V'] for r in ev]), kappa_theta=np.array([r['kappa_theta'] for r in ev]),
                 kappa_rest=np.array([r['kappa_rest'] for r in ev]), Re_eta=np.array([r['eta_re'] for r in ev]),
                 minus_c_Im_eta=np.array([-r['c'] * r['eta_im'] for r in ev]))
    for nm, lo, hi, lg in SPACES[s]:
        x = np.array([r[nm] for r in ev])
        c = dict(family=s, parameter=nm)
        c.update({q: sp(x, v) for q, v in parts.items()})
        corr.append(c)
wcsv('p2_prevalence.csv', prev)
wcsv('p2_mechanism.csv', mech)
wcsv('p2_rank_corr.csv', corr)
flips = []
if (OUT / 'p2_oat.csv').exists():
    rows = list(csv.DictReader(open(OUT / 'p2_oat.csv', encoding='utf-8')))
    keyf = {}
    for r in rows:
        keyf.setdefault((r['system'], r['base'], r['param']), []).append(r)
    for (s, b, p), rr in keyf.items():
        kv = [(float(r['value']), float(r['kappa'])) for r in rr if r['kappa'] not in ('', 'None')]
        if len(kv) < 2:
            continue
        ks = [k for _, k in kv]
        flips.append(dict(system=s, base=b, param=p, kappa_min=min(ks), kappa_max=max(ks),
                          value_at_min=kv[int(np.argmin(ks))][0], value_at_max=kv[int(np.argmax(ks))][0],
                          changes_sign=min(ks) < 0 < max(ks), crosses_minus_tau=min(ks) <= -TAU < max(ks),
                          n_valid=len(kv), n_phys_flag=sum(1 for r in rr if r['phys_gate'] not in ('', 'None'))))
    wcsv('p2_oat_flips.csv', flips)
for r in prev:
    print(r)
