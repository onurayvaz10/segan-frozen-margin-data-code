"""Phase 3b: coarse-to-fine (focused) Sobol sampling of the low-kappa region (predictor only; no reference).

Rule (fixed before running): for each family, take the Stage-1-evaluable points of the wide Sobol exploration whose
kappa lies in the lowest decile (at least 20 points); for every parameter, the focused interval is the 5th-95th
percentile range of that subset in normalized coordinates (unit cube, logarithmic coordinates for logarithmic
parameters), widened symmetrically to at least 0.10 and clipped to the original box. 2^11 = 2048 scrambled Sobol
points (seeds 2026102611/12/13) are drawn in the focused box and evaluated with the Stage-1 gates and predictors.
Writes out/p3b_box_<s>.json and out/p2_focus_<s>.jsonl (ids <s>-F#####); resumes from the file.
Usage: python -I p3b_focused.py A2 B2 C
"""
import json
import math
import os
import sys
import time
import traceback
from pathlib import Path

import numpy as np
from scipy.stats import qmc

HERE = Path(__file__).resolve().parent
OUT = Path(os.environ.get('G91_OUT', str(HERE.parent / 'out')))
sys.path.insert(0, str(HERE))
import ext_common as C  # noqa: E402
from p2_explore import SPACES, clean  # noqa: E402
from p3_boundary import to_u  # noqa: E402

SEEDS = {'A2': 2026102611, 'B2': 2026102612, 'C': 2026102613}
M = {'A2': 11, 'B2': 11, 'C': 10}       # 2048, 2048 and (cost of the 70-state model) 1024 points


def box(system):
    ev = [json.loads(l) for l in open(OUT / f'p2_explore_{system}.jsonl', encoding='utf-8')]
    ev = [r for r in ev if r.get('excl') is None]
    k = np.array([r['kappa'] for r in ev])
    n = max(20, int(math.ceil(0.10 * len(ev))))
    low = [ev[i] for i in np.argsort(k)[:n]]
    U = np.array([to_u(system, r) for r in low])
    lo, hi = np.percentile(U, 5, axis=0), np.percentile(U, 95, axis=0)
    for i in range(len(lo)):
        if hi[i] - lo[i] < 0.10:
            m = 0.5 * (lo[i] + hi[i])
            lo[i], hi[i] = m - 0.05, m + 0.05
    lo, hi = np.clip(lo, 0, 1), np.clip(hi, 0, 1)
    doc = dict(system=system, n_wide_evaluable=len(ev), n_low=n, kappa_cut=float(np.sort(k)[n - 1]),
               box={nm: [float(a), float(b)] for (nm, *_), a, b in zip(SPACES[system], lo, hi)})
    (OUT / f'p3b_box_{system}.json').write_text(json.dumps(doc, indent=1), encoding='utf-8')
    return lo, hi


def run(system):
    lo, hi = box(system)
    sp = SPACES[system]
    u = qmc.Sobol(d=len(sp), scramble=True, seed=SEEDS[system]).random_base2(M[system])
    path = OUT / f'p2_focus_{system}.jsonl'
    done = set()
    if path.exists():
        for l in open(path, encoding='utf-8'):
            try:
                done.add(json.loads(l)['id'])
            except ValueError:
                pass
    t0 = time.perf_counter()
    with open(path, 'a', encoding='utf-8') as f:
        for i, row in enumerate(u):
            pid = f'{system}-F{i:05d}'
            if pid in done:
                continue
            uu = lo + row * (hi - lo)
            d = dict(id=pid, system=system)
            for (nm, a, b, lg), ui in zip(sp, uu):
                d[nm] = float(math.exp(math.log(a) + ui * (math.log(b) - math.log(a)))) if lg else float(a + ui * (b - a))
            try:
                lay, G, P = C.BUILDERS[system](d)
                r = C.stage1(lay, G, P, rec=dict(d), strict=True)
            except Exception as exc:  # noqa: BLE001
                r = dict(d, excl='error', error=f'{type(exc).__name__}: {exc}', tb=traceback.format_exc()[-400:])
            f.write(json.dumps(clean(r), default=float) + '\n')
            f.flush()
            if (i + 1) % 100 == 0:
                C.plog(f'focus {system} {i + 1} {time.perf_counter() - t0:.0f}s', OUT / 'progress.txt')
    C.plog(f'focus {system} done', OUT / 'progress.txt')


if __name__ == '__main__':
    C.lower_priority()
    for s in sys.argv[1:]:
        run(s)
