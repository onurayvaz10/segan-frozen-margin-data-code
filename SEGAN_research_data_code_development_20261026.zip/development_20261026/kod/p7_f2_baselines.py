"""Phase 7 (post hoc, original family F2): additional comparator estimators on the 79 evaluable sealed members.

For each member of F2 (original model, setting S3) the Stage-1 predictors are recomputed with the extended engine
(identical to the validated separately coded engine in base mode) and the comparators that the sealed run did not
record are added: the first-order estimate without the crossing-frequency term (Re eta only), the load-side
first-order estimate, and the one- and two-solve secant estimators on F_min. The sealed reference dGt of the
historical run is used as the reference (not recomputed). Writes out/p7_f2_baselines.csv.
"""
import csv
import json
import os
import math
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
RI = HERE.parents[1]
OUT = Path(os.environ.get('G91_OUT', str(HERE.parent / 'out')))
sys.path.insert(0, str(HERE))
import ext_common as C  # noqa: E402
import ext_engine as X  # noqa: E402

C.lower_priority()
sealed = [m for m in json.load(open(RI / 'cdl1/out/HDL2b_20261021_a/sonuc.json', encoding='utf-8'))['members'] if m.get('in_E')]
rows = []
for m in sealed:
    lay, G, P = C.build_F2(m['P_akt'], m['G_R'])
    r = C.stage1(lay, G, P, rec={}, strict=False)
    d = X.dispatch(lay, P, G, tol=1e-12)
    x0, refs = d['x'], d['refs']
    th = float(np.arctan2(x0[lay.ix['V1:I']], x0[lay.ix['V1:R']]))
    dGf = r['dGf']
    F1, _ = C.F_min_at(lay, x0, refs, G, dGf, th)
    s1 = s2 = None
    if F1 is not None and math.isfinite(F1) and F1 < dGf:
        s1 = dGf * dGf / (dGf - F1)
        F2, _ = C.F_min_at(lay, x0, refs, G, s1, th)
        if F2 is not None and math.isfinite(F2):
            s2 = s1 - F2 * (s1 - dGf) / (F2 - F1)
    row = dict(id=m['id'], P_set=m['P_akt'], G_R=m['G_R'], dGref=m['ref']['dGt'], dGf=dGf, kappa=r['kappa'],
               kappa_noc=r['kappa_noc'], kappa_L=r['kappa_L'], eps2=r['eps2'], dG1st=r['dG1st'], dG1st_noc=r['dG1st_noc'],
               dG1st_L=r['dG1st_L'], dG2nd=r['dG2nd'], dG_sec1=s1, dG_sec2=s2, F_single=F1, gap_rel=r['gap_rel'],
               cond_J=r['cond_J'], dGf_over_GR=r['dGf_over_GR'], dv_rel_at_margin=r['dv_rel_at_margin'],
               xi_norm_state=r['xi_norm_state'], kappa_rest=r['kappa_rest'], c=r['c'], omega=r['omega'])
    rows.append(row)
    print(m['id'], round(dGf, 5), round(m['ref']['dGt'], 5), s1, s2, flush=True)
with open(OUT / 'p7_f2_baselines.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0]))
    w.writeheader()
    w.writerows(rows)
for k in ('dGf', 'dG1st', 'dG1st_noc', 'dG1st_L', 'dG2nd', 'dG_sec1', 'dG_sec2'):
    e = np.array([r[k] - r['dGref'] for r in rows if r[k] is not None])
    print(k, 'n', len(e), 'MAE %.5f' % np.mean(np.abs(e)), 'max %.5f' % np.max(np.abs(e)), 'over', int(np.sum(e > 0)))
