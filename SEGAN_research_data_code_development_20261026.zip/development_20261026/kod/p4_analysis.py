"""Phase 4/7/8/9 analysis of the two-sign validation run (fixed before the run; protocol TSV_PROTOKOL_v1.txt §5-§7).

Usage: python -I p4_analysis.py TSV_a     (reads out/tsv/selection.json and out/tsv/TSV_a/stage2.jsonl)
       python -I p4_analysis.py --synth   (known-answer tests of the decision table and of the statistics)
Writes out/tsv/TSV_a/analysis/: points.csv, directional.csv, estimators.csv, envelope.csv, failures.csv,
results.json. Statistics: Wilson intervals, exact McNemar, cluster bootstrap (percentile and BCa, 4000 resamples,
seed 20261026) with clusters = Sobol point or search seed; effect sizes and intervals are primary, p-values only
for the pre-specified McNemar comparisons.
"""
import csv
import json
import os
import math
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
TSV = Path(os.environ.get('G91_OUT', str(HERE.parent / 'out'))) / 'tsv'
TAU_K = 0.05
B_BOOT, SEED = 4000, 20261026
PRESEEN = {'C-F00004', 'B2-F00005'}     # Stage-2 outcome computed before hashing (timing; protocol section 6a)
EST = [('frozen', 'dGf', 0), ('first_order', 'dG1st', 0), ('first_order_noc', 'dG1st_noc', 0),
       ('first_order_L', 'dG1st_L', 0), ('second_order', 'dG2nd', 2), ('secant_1', 'dG_sec1', 1),
       ('secant_2', 'dG_sec2', 2)]
INDICATORS = ['eps2', 'abs_kappa', 'kappa_ratio', 'dGf_over_GR', 'gap_rel', 'log10_cond_J', 'dv_rel_at_margin',
              'shift_norm']


# --------------------------------------------------------------------------------------------- statistics
def wilson(k, n, z=1.959963984540054):
    if n == 0:
        return (float('nan'), float('nan'))
    p = k / n
    den = 1 + z * z / n
    c = (p + z * z / (2 * n)) / den
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return (c - h, c + h)


def mcnemar_exact(b, c):
    n = b + c
    if n == 0:
        return 1.0
    k = min(b, c)
    return min(1.0, 2 * sum(math.comb(n, i) for i in range(k + 1)) / 2 ** n)


def mcc(tp, tn, fp, fn):
    den = math.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    return (tp * tn - fp * fn) / den if den > 0 else 0.0


def _phi_inv(p):
    # Acklam-type rational approximation is unnecessary here: use erfinv via numpy-free bisection on erf
    lo, hi = -10.0, 10.0
    for _ in range(100):
        m = 0.5 * (lo + hi)
        if 0.5 * (1 + math.erf(m / math.sqrt(2))) < p:
            lo = m
        else:
            hi = m
    return 0.5 * (lo + hi)


def _phi(x):
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))


def cluster_boot(rows, stat, B=B_BOOT, seed=SEED):
    """Cluster bootstrap of stat(rows): returns estimate, percentile 95% CI and BCa 95% CI (jackknife over clusters)."""
    cl = {}
    for r in rows:
        cl.setdefault(r['cluster'], []).append(r)
    keys = sorted(cl)
    est = stat(rows)
    if not keys or est is None or not math.isfinite(est):
        return dict(est=est, pct=(float('nan'),) * 2, bca=(float('nan'),) * 2, n_clusters=len(keys))
    rng = np.random.default_rng(seed)
    bs = []
    for _ in range(B):
        pick = rng.integers(0, len(keys), len(keys))
        rr = [x for i in pick for x in cl[keys[i]]]
        v = stat(rr)
        if v is not None and math.isfinite(v):
            bs.append(v)
    bs = np.array(bs)
    pct = (float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5)))
    try:
        prop = float(np.mean(bs < est)) + 0.5 * float(np.mean(bs == est))
        prop = min(max(prop, 1.0 / (len(bs) + 1)), 1 - 1.0 / (len(bs) + 1))
        z0 = _phi_inv(prop)
        jk = []
        for k in keys:
            rr = [x for kk in keys if kk != k for x in cl[kk]]
            v = stat(rr)
            if v is not None and math.isfinite(v):
                jk.append(v)
        jk = np.array(jk)
        d = jk.mean() - jk
        a = float(np.sum(d ** 3) / (6 * np.sum(d ** 2) ** 1.5)) if np.sum(d ** 2) > 0 else 0.0
        out = []
        for q in (0.025, 0.975):
            zq = _phi_inv(q)
            adj = _phi(z0 + (z0 + zq) / (1 - a * (z0 + zq)))
            out.append(float(np.percentile(bs, 100 * min(max(adj, 0.0), 1.0))))
        bca = tuple(out)
    except Exception:  # noqa: BLE001
        bca = (float('nan'), float('nan'))
    return dict(est=float(est), pct=pct, bca=bca, n_clusters=len(keys), n_boot=int(len(bs)))


def spearman(x, y):
    x, y = np.asarray(x, float), np.asarray(y, float)
    m = np.isfinite(x) & np.isfinite(y)
    if m.sum() < 3:
        return float('nan')
    rx = np.argsort(np.argsort(x[m]))
    ry = np.argsort(np.argsort(y[m]))
    return float(np.corrcoef(rx, ry)[0, 1])


# --------------------------------------------------------------------------------------------- directional
PRED = dict(R1_kappa=lambda r: 1 if r['kappa'] > 0 else -1, R2_const_plus=lambda r: 1, R3_const_minus=lambda r: -1,
            R4_re_eta=lambda r: 1 if r['kappa_noc'] > 0 else -1, R5_kappa_L=lambda r: 1 if r['kappa_L'] > 0 else -1)


def directional(rows):
    """rows: primary set (|kappa| >= tau, ref_sign in {-1, +1})."""
    n = len(rows)
    out = dict(n=n, n_minus=sum(r['kappa'] < 0 for r in rows), n_plus=sum(r['kappa'] > 0 for r in rows),
               n_ref_minus=sum(r['ref_sign'] == -1 for r in rows))
    corr = {k: [f(r) == r['ref_sign'] for r in rows] for k, f in PRED.items()}
    for k, v in corr.items():
        out[f'acc_{k}'] = sum(v) / n if n else float('nan')
        out[f'wilson_{k}'] = wilson(sum(v), n)
    neg = [r for r in rows if r['kappa'] < 0]
    pos = [r for r in rows if r['kappa'] > 0]
    out['agree_kappa_neg'] = (sum(r['ref_sign'] == -1 for r in neg), len(neg))
    out['agree_kappa_pos'] = (sum(r['ref_sign'] == 1 for r in pos), len(pos))
    out['wilson_kappa_neg'] = wilson(*out['agree_kappa_neg'])
    out['wilson_kappa_pos'] = wilson(*out['agree_kappa_pos'])
    tp = sum(1 for r in rows if r['kappa'] > 0 and r['ref_sign'] == 1)
    tn = sum(1 for r in rows if r['kappa'] < 0 and r['ref_sign'] == -1)
    fp = sum(1 for r in rows if r['kappa'] > 0 and r['ref_sign'] == -1)
    fn = sum(1 for r in rows if r['kappa'] < 0 and r['ref_sign'] == 1)
    out['confusion'] = dict(pred_plus_obs_plus=tp, pred_minus_obs_minus=tn, pred_plus_obs_minus=fp,
                            pred_minus_obs_plus=fn)
    sens = tp / (tp + fn) if tp + fn else float('nan')     # observed-conservative recall
    spec = tn / (tn + fp) if tn + fp else float('nan')     # observed-optimistic recall
    out['recall_obs_plus'], out['recall_obs_minus'] = sens, spec
    out['balanced_acc_R1'] = 0.5 * (sens + spec) if not (math.isnan(sens) or math.isnan(spec)) else float('nan')
    out['mcc_R1'] = mcc(tp, tn, fp, fn)

    def mcn(other):
        b = sum(1 for i in range(n) if corr['R1_kappa'][i] and not corr[other][i])
        c = sum(1 for i in range(n) if not corr['R1_kappa'][i] and corr[other][i])
        return dict(b=b, c=c, p=mcnemar_exact(b, c))

    best = 'R2_const_plus' if out['acc_R2_const_plus'] >= out['acc_R3_const_minus'] else 'R3_const_minus'
    out['best_constant'] = best
    out['mcnemar_vs_best_constant'] = mcn(best)
    out['mcnemar_vs_R4'] = mcn('R4_re_eta')
    out['mcnemar_vs_R5'] = mcn('R5_kappa_L')
    out['counterexamples_R1'] = sorted(r['id'] for r in rows if PRED['R1_kappa'](r) != r['ref_sign'])

    def bal(rr):
        t = sum(1 for r in rr if r['kappa'] > 0 and r['ref_sign'] == 1)
        tn_ = sum(1 for r in rr if r['kappa'] < 0 and r['ref_sign'] == -1)
        p_ = sum(1 for r in rr if r['ref_sign'] == 1)
        m_ = sum(1 for r in rr if r['ref_sign'] == -1)
        return 0.5 * (t / p_ + tn_ / m_) if p_ and m_ else None
    out['balanced_acc_R1_cluster_boot'] = cluster_boot(rows, bal)
    return out


def decide(ev):
    """Decision table of the protocol (rows 2-5, as the PSV table)."""
    if ev['n_minus'] < 10 or ev['n_plus'] < 10:
        return 2, 'NOT EVALUABLE - sign diversity insufficient'
    best = ev['best_constant']
    if ev['mcnemar_vs_best_constant']['p'] >= 0.01 or ev['acc_R1_kappa'] <= ev[f'acc_{best}']:
        return 3, 'NOT SUPPORTED - no discrimination beyond a constant rule'
    an, nn = ev['agree_kappa_neg']
    ap, npos = ev['agree_kappa_pos']
    if ev['wilson_R1_kappa'][0] >= 0.75 and an / nn >= 0.75 and ap / npos >= 0.75:
        return 4, 'SUPPORTED - sign kappa discriminates direction in the tested families'
    return 5, 'PARTIAL - discriminates but fails a stratum or the accuracy bound'


# --------------------------------------------------------------------------------------------- magnitude
def est_rows(rows, key):
    out = []
    for r in rows:
        v = r.get(key)
        if v is None or not math.isfinite(v):
            continue
        out.append(dict(r, e=v - r['dGref'], ae=abs(v - r['dGref']), rel=(v - r['dGref']) / r['dGref']))
    return out


def estimator_table(rows, label):
    res = []
    for name, key, n_eq in EST:
        er = est_rows(rows, key)
        if not er:
            continue
        ae = np.array([x['ae'] for x in er])
        rel = np.array([x['rel'] for x in er])
        mae = cluster_boot(er, lambda rr: float(np.mean([x['ae'] for x in rr])) if rr else None)
        res.append(dict(set=label, estimator=name, extra_equilibria=n_eq, n=len(er), n_missing=len(rows) - len(er),
                        MAE=float(ae.mean()), MAE_lo=mae['bca'][0], MAE_hi=mae['bca'][1],
                        RMSE=float(np.sqrt(np.mean(ae ** 2))), median_AE=float(np.median(ae)),
                        IQR_AE=float(np.percentile(ae, 75) - np.percentile(ae, 25)), max_AE=float(ae.max()),
                        mean_rel_pct=float(100 * np.mean(np.abs(rel))), median_rel_pct=float(100 * np.median(rel)),
                        p95_abs_rel_pct=float(100 * np.percentile(np.abs(rel), 95)),
                        overshoot=int(np.sum(rel > 0)), overshoot_frac=float(np.mean(rel > 0))))
    return res


def paired_mae_diff(rows, key_a, key_b):
    """MAE(a) - MAE(b) on the points where both exist, cluster bootstrap BCa."""
    rr = [r for r in rows if r.get(key_a) is not None and r.get(key_b) is not None
          and math.isfinite(r[key_a]) and math.isfinite(r[key_b])]

    def st(x):
        if not x:
            return None
        return float(np.mean([abs(r[key_a] - r['dGref']) - abs(r[key_b] - r['dGref']) for r in x]))
    return cluster_boot(rr, st)


# --------------------------------------------------------------------------------------------- driver
def derive(r):
    r['abs_kappa'] = abs(r['kappa'])
    r['kappa_ratio'] = r['kappa'] / (1 - r['kappa']) if r['kappa'] < 1 else float('inf')
    r['log10_cond_J'] = math.log10(r['cond_J']) if r.get('cond_J') else float('nan')
    r['shift_norm'] = r.get('xi_norm_state', float('nan')) * r['dGf']
    r['obs_rel_shift'] = r['rel_err'] if r.get('rel_err') is not None else float('nan')
    for name, key, _ in EST:
        v = r.get(key)
        r['relerr_' + name] = (v - r['dGref']) / r['dGref'] if v is not None and math.isfinite(v) else float('nan')
    return r


def analyse(run_id):
    sel = {p['id']: p for p in json.loads((TSV / 'selection.json').read_text(encoding='utf-8'))['points']}
    st2 = [json.loads(l) for l in open(TSV / run_id / 'stage2.jsonl', encoding='utf-8')]
    A = TSV / run_id / 'analysis'
    A.mkdir(exist_ok=True)
    rows, excluded = [], []
    for o in st2:
        if o.get('label') or o.get('ref_sign') is None:
            excluded.append(dict(id=o['id'], label=o.get('label'), error=o.get('error')))
            continue
        rows.append(derive(dict(sel[o['id']], **o)))
    res = dict(run_id=run_id, n_selected=len(sel), n_stage2=len(st2), excluded=excluded)
    res['ties'] = [r['id'] for r in rows if r['ref_sign'] == 0]
    prim = [r for r in rows if abs(r['kappa']) >= TAU_K and r['ref_sign'] != 0]
    band = [r for r in rows if abs(r['kappa']) < TAU_K]
    res['abstain_band'] = dict(n=len(band), obs_minus=sum(r['ref_sign'] == -1 for r in band),
                               obs_plus=sum(r['ref_sign'] == 1 for r in band), obs_tie=sum(r['ref_sign'] == 0 for r in band))
    for r in rows:
        r['pre_seen'] = r['id'] in PRESEEN
    scopes = dict(pooled=prim, pooled_excl_preseen=[r for r in prim if r['id'] not in PRESEEN],
                  sobol=[r for r in prim if r['source'] == 'sobol'],
                  focused=[r for r in prim if r['source'] == 'focused'],
                  search=[r for r in prim if r['source'] == 'search'])
    for s in ('A2', 'B2', 'C'):
        scopes[s] = [r for r in prim if r['system'] == s]
    dirrows = []
    res['directional'] = {}
    for k, rr in scopes.items():
        ev = directional(rr)
        row, verdict = decide(ev)
        ev.update(decision_row=row, verdict=verdict)
        res['directional'][k] = ev
        dirrows.append(dict(scope=k, n=ev['n'], n_kappa_minus=ev['n_minus'], n_kappa_plus=ev['n_plus'],
                            agree_minus=ev['agree_kappa_neg'][0], agree_plus=ev['agree_kappa_pos'][0],
                            acc_R1=ev['acc_R1_kappa'], acc_const_plus=ev['acc_R2_const_plus'],
                            acc_R4=ev['acc_R4_re_eta'], acc_R5=ev['acc_R5_kappa_L'],
                            balanced_acc=ev['balanced_acc_R1'], mcc=ev['mcc_R1'],
                            mcnemar_p_vs_const=ev['mcnemar_vs_best_constant']['p'],
                            mcnemar_p_vs_R4=ev['mcnemar_vs_R4']['p'], verdict=verdict))
    # bias direction of frozen and first-order margins by kappa sign (median and IQR of signed relative error)
    bias = {}
    for grp, rr in (('kappa_neg', [r for r in prim if r['kappa'] < 0]), ('kappa_pos', [r for r in prim if r['kappa'] > 0])):
        unc = [r for r in rr if not r.get('censored')]
        d = {}
        for name, key, _ in EST[:2] + EST[4:5]:
            v = np.array([r['relerr_' + name] for r in unc if math.isfinite(r['relerr_' + name])])
            if len(v):
                med = cluster_boot([dict(r, _v=r['relerr_' + name]) for r in unc if math.isfinite(r['relerr_' + name])],
                                   lambda x: float(np.median([y['_v'] for y in x])) if x else None)
                d[name] = dict(n=len(v), median=float(np.median(v)), q25=float(np.percentile(v, 25)),
                               q75=float(np.percentile(v, 75)), frac_positive=float(np.mean(v > 0)), median_ci=med['bca'])
        bias[grp] = d
    res['bias_direction'] = bias
    # magnitude estimators on uncensored, non-fold points
    unc = [r for r in prim if not r.get('censored') and not r.get('fold')]
    est = []
    for label, rr in (('all', unc), ('kappa_neg', [r for r in unc if r['kappa'] < 0]),
                      ('kappa_pos', [r for r in unc if r['kappa'] > 0]), ('A2', [r for r in unc if r['system'] == 'A2']),
                      ('B2', [r for r in unc if r['system'] == 'B2']), ('C', [r for r in unc if r['system'] == 'C'])):
        est += estimator_table(rr, label)
    res['paired'] = {f'{a}-{b}': paired_mae_diff(unc, ka, kb) for a, ka, b, kb in
                     (('second_order', 'dG2nd', 'frozen', 'dGf'), ('first_order', 'dG1st', 'frozen', 'dGf'),
                      ('second_order', 'dG2nd', 'secant_1', 'dG_sec1'), ('first_order', 'dG1st', 'first_order_noc', 'dG1st_noc'),
                      ('secant_2', 'dG_sec2', 'second_order', 'dG2nd'))}
    res['censored'] = sum(1 for r in prim if r.get('censored'))
    res['fold'] = sum(1 for r in prim if r.get('fold'))
    # validity envelope (first and second order; uncensored)
    env = []
    for name in ('first_order', 'second_order'):
        y = [abs(r['relerr_' + name]) for r in unc]
        for ind in INDICATORS:
            x = [r.get(ind, float('nan')) for r in unc]
            rr = [dict(r, _x=xi, _y=yi) for r, xi, yi in zip(unc, x, y) if math.isfinite(xi) and math.isfinite(yi)]
            sp = cluster_boot(rr, lambda z: spearman([a['_x'] for a in z], [a['_y'] for a in z]) if len(z) > 3 else None)
            within = []
            for s in ('A2', 'B2', 'C'):
                zz = [a for a in rr if a['system'] == s]
                within.append(spearman([a['_x'] for a in zz], [a['_y'] for a in zz]) if len(zz) > 3 else float('nan'))
            env.append(dict(estimator=name, indicator=ind, n=len(rr), spearman=sp['est'], ci_lo=sp['bca'][0],
                            ci_hi=sp['bca'][1], spearman_A2=within[0], spearman_B2=within[1], spearman_C=within[2]))
    # empirical envelope by eps2 bands and by |kappa| bands
    bands = []
    for ind, edges in (('eps2', [0, 0.05, 0.1, 0.2, 0.5, float('inf')]), ('abs_kappa', [0.05, 0.1, 0.2, 0.4, float('inf')]),
                       ('dGf_over_GR', [0, 0.25, 0.5, 0.75, 1.0])):
        for lo, hi in zip(edges[:-1], edges[1:]):
            rr = [r for r in unc if math.isfinite(r.get(ind, float('nan'))) and lo <= r[ind] < hi]
            if not rr:
                continue
            row = dict(indicator=ind, lo=lo, hi=hi, n=len(rr))
            for name in ('frozen', 'first_order', 'second_order', 'secant_1'):
                v = np.array([abs(r['relerr_' + name]) for r in rr if math.isfinite(r['relerr_' + name])])
                if len(v):
                    row[f'{name}_median_pct'] = float(100 * np.median(v))
                    row[f'{name}_p90_pct'] = float(100 * np.percentile(v, 90))
                    row[f'{name}_max_pct'] = float(100 * v.max())
            bands.append(row)
    res['envelope_bands'] = bands
    # first-order error vs the second-order prediction eps2/4 (Eq. 18 expansion)
    xx = np.array([r['eps2'] / 4 for r in unc if math.isfinite(r['eps2']) and math.isfinite(r['relerr_first_order'])])
    yy = np.array([r['relerr_first_order'] for r in unc if math.isfinite(r['eps2']) and math.isfinite(r['relerr_first_order'])])
    if len(xx) > 3:
        slope = float(np.sum(xx * yy) / np.sum(xx * xx))
        res['first_order_vs_eps2_over_4'] = dict(n=len(xx), slope_through_origin=slope,
                                                 spearman=spearman(xx, yy),
                                                 frac_within_factor2=float(np.mean((yy > 0.5 * xx) & (yy < 2 * xx))))
    # pooled vs within-system correlation of predicted and observed relative shift (Simpson check)
    pr = [r for r in unc if math.isfinite(r['kappa_ratio'])]
    pooled = spearman([r['kappa_ratio'] for r in pr], [r['obs_rel_shift'] for r in pr])
    pear = float(np.corrcoef([r['kappa_ratio'] for r in pr], [r['obs_rel_shift'] for r in pr])[0, 1]) if len(pr) > 3 else float('nan')
    cen = []
    for s in ('A2', 'B2', 'C'):
        zz = [r for r in pr if r['system'] == s]
        if len(zz) > 3:
            mx = np.mean([r['kappa_ratio'] for r in zz])
            my = np.mean([r['obs_rel_shift'] for r in zz])
            cen += [(r['kappa_ratio'] - mx, r['obs_rel_shift'] - my) for r in zz]
    res['simpson_check'] = dict(pooled_spearman=pooled, pooled_pearson=pear,
                                within_system_pearson=float(np.corrcoef(*zip(*cen))[0, 1]) if len(cen) > 3 else float('nan'))
    # failure cases
    fails = []
    def add(tag, rr):
        for r in rr:
            fails.append(dict(tag=tag, id=r['id'], system=r['system'], source=r['source'], kappa=r['kappa'],
                              kappa_noc=r['kappa_noc'], ref_sign=r['ref_sign'], dGf=r['dGf'], dGref=r['dGref'],
                              relerr_first=r['relerr_first_order'], relerr_second=r['relerr_second_order'],
                              eps2=r['eps2'], gap_rel=r['gap_rel'], log10_cond_J=r['log10_cond_J'],
                              dGf_over_GR=r['dGf_over_GR'], c=r['c'], omega=r['omega'], kappa_rest=r['kappa_rest'],
                              kappa_theta=r['kappa_theta'], censored=r.get('censored'), status=r.get('ref_status')))
    add('worst5_abs_first', sorted(unc, key=lambda r: -abs(r['dG1st'] - r['dGref']) if math.isfinite(r['dG1st']) else 0)[:5])
    add('worst5_abs_second', sorted(unc, key=lambda r: -abs(r['dG2nd'] - r['dGref']) if r.get('dG2nd') else 0)[:5])
    add('worst_rel_first', sorted(unc, key=lambda r: -abs(r['relerr_first_order']) if math.isfinite(r['relerr_first_order']) else 0)[:1])
    add('wrong_direction_R1', [r for r in prim if PRED['R1_kappa'](r) != r['ref_sign']])
    add('abstain_band', band)
    add('second_order_overshoot_gt10pct', [r for r in unc if math.isfinite(r['relerr_second_order']) and r['relerr_second_order'] > 0.10])
    res['n_failures_rows'] = len(fails)
    # write
    keys = sorted({k for r in rows for k in r if not isinstance(r[k], (dict, list))})
    with open(A / 'points.csv', 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=keys, extrasaction='ignore')
        w.writeheader()
        w.writerows(rows)
    for fn, data in (('directional.csv', dirrows), ('estimators.csv', est), ('envelope.csv', env),
                     ('envelope_bands.csv', bands), ('failures.csv', fails)):
        if data:
            kk = []
            for d in data:
                for k in d:
                    if k not in kk:
                        kk.append(k)
            with open(A / fn, 'w', newline='', encoding='utf-8') as f:
                w = csv.DictWriter(f, fieldnames=kk)
                w.writeheader()
                w.writerows(data)
    (A / 'results.json').write_text(json.dumps(res, indent=1, default=float), encoding='utf-8')
    for d in dirrows:
        print(d)
    return res


def synth():
    ok = []

    def mk(k, s, sysn='A2', cl=None, i=[0]):
        i[0] += 1
        return dict(id=f'S{i[0]}', cluster=cl or f'c{i[0]}', system=sysn, kappa=k, kappa_noc=k, kappa_L=k, ref_sign=s)
    rows = [mk(0.2, 1) for _ in range(15)] + [mk(-0.2, -1) for _ in range(15)]
    ev = directional(rows)
    ok.append(('row4 perfect', decide(ev)[0] == 4 and ev['mcc_R1'] == 1.0 and abs(ev['balanced_acc_R1'] - 1) < 1e-12))
    rows = [mk(0.2, 1) for _ in range(20)] + [mk(-0.2, -1) for _ in range(5)]
    ok.append(('row2', decide(directional(rows))[0] == 2))
    rows = [mk(0.2, 1) for _ in range(15)] + [mk(-0.2, 1) for _ in range(15)]
    ok.append(('row3', decide(directional(rows))[0] == 3))
    rows = [mk(0.2, 1) for _ in range(40)] + [mk(-0.2, -1) for _ in range(40)] + [mk(-0.2, 1) for _ in range(15)]
    ev = directional(rows)
    ok.append(('row5', decide(ev)[0] == 5))
    lo, hi = wilson(8, 10)
    ok.append(('wilson', abs(lo - 0.4902) < 1e-3 and abs(hi - 0.9433) < 1e-3))
    ok.append(('mcnemar', abs(mcnemar_exact(8, 1) - 0.0390625) < 1e-12))
    rr = [dict(cluster=f'c{i}', v=float(i)) for i in range(50)]
    cb = cluster_boot(rr, lambda x: float(np.mean([y['v'] for y in x])), B=2000)
    ok.append(('cluster boot mean CI covers 24.5', cb['bca'][0] < 24.5 < cb['bca'][1] and cb['pct'][0] < 24.5 < cb['pct'][1]))
    rr2 = [dict(cluster='a', v=0.0) for _ in range(30)] + [dict(cluster='b', v=1.0) for _ in range(30)]
    cb2 = cluster_boot(rr2, lambda x: float(np.mean([y['v'] for y in x])), B=2000)
    ok.append(('cluster boot respects clusters (wide CI)', cb2['pct'][0] <= 0.0 + 1e-12 and cb2['pct'][1] >= 1.0 - 1e-12))
    ok.append(('spearman', abs(spearman([1, 2, 3, 4], [10, 20, 30, 40]) - 1) < 1e-12))
    rows = [dict(id='x', cluster='x', dGref=1.0, dGf=0.8, dG1st=1.1, dG2nd=0.99, dG_sec1=1.0, dG_sec2=1.0,
                 dG1st_noc=0.9, dG1st_L=1.2)]
    t = {d['estimator']: d for d in estimator_table(rows, 's')}
    ok.append(('estimator table', abs(t['frozen']['MAE'] - 0.2) < 1e-12 and t['first_order']['overshoot'] == 1))
    for n, v in ok:
        print(('PASS ' if v else 'FAIL ') + n)
    good = all(v for _, v in ok)
    print('SYNTH', 'PASS' if good else 'FAIL', f'{sum(v for _, v in ok)}/{len(ok)}')
    return good


if __name__ == '__main__':
    if sys.argv[1] == '--synth':
        sys.exit(0 if synth() else 1)
    analyse(sys.argv[1])
