"""Phase 4: selection and single Stage-2 run of the two-sign validation (protocol kod/../protokol/TSV_PROTOKOL_v1.txt).

Modes
  --select           build out/tsv/selection.json from the Stage-1 records (predictor only) by the protocol rule
  --check-only       verify the pinned hashes (protocol, engine, common module, this script, analysis script,
                     selection) against the authorization file; no model is built
  --run TSV_a        exactly one Stage-2 run into out/tsv/TSV_a/ (refused if the folder contains a finished run);
                     a run interrupted by a crash resumes from its own stage2.jsonl (deterministic computations)
Imports numpy, ext_engine and ext_common. BLAS threads 1.
"""
import argparse
import hashlib
import json
import math
import os
import sys
import time
import traceback
from pathlib import Path

os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['MKL_NUM_THREADS'] = '1'
import numpy as np  # noqa: E402

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OUT = Path(os.environ.get('G91_OUT', str(HERE.parent / 'out')))
TSV = OUT / 'tsv'
PROTOCOL = ROOT / 'protokol' / 'TSV_PROTOKOL_v1.txt'
AUTH = ROOT / 'protokol' / 'TSV_yetki_TSV_a.json'
sys.path.insert(0, str(HERE))
import ext_common as C  # noqa: E402
from p2_explore import clean  # noqa: E402
import p3_boundary as B  # noqa: E402

SYSTEMS = ('A2', 'B2', 'C')
NPOS = 150          # at most this many kappa >= tau points per family and source (deterministic random sample)
PIN_FILES = dict(protocol=PROTOCOL, engine=HERE / 'ext_engine.py', common=HERE / 'ext_common.py',
                 runner=HERE / 'p4_stage2.py', analysis=HERE / 'p4_analysis.py', selection=TSV / 'selection.json')


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def load_jsonl(p):
    return [json.loads(l) for l in open(p, encoding='utf-8')] if Path(p).exists() else []


def select():
    """Protocol section 3: every Stage-1-evaluable Sobol point (any kappa) and every boundary-search end point that
    is Stage-1-evaluable. Cluster = the Sobol point itself, or for an end point the Sobol seed it started from."""
    sel = []
    counts = {}
    for si, s in enumerate(SYSTEMS):
        for src, fname in (('sobol', f'p2_explore_{s}.jsonl'), ('focused', f'p2_focus_{s}.jsonl')):
            ev = sorted([r for r in load_jsonl(OUT / fname) if r.get('excl') is None], key=lambda r: r['id'])
            low = [r for r in ev if r['kappa'] < C.TAU_K]                 # all kappa < tau (negative and abstention band)
            pos = [r for r in ev if r['kappa'] >= C.TAU_K]
            rng = np.random.default_rng(20261027 + 10 * si + (src == 'focused'))
            if len(pos) > NPOS:
                pos = [pos[i] for i in sorted(rng.choice(len(pos), size=NPOS, replace=False))]
            counts[f'{s}:{src}'] = dict(evaluable=len(ev), kappa_below_tau=len(low), positives_selected=len(pos))
            for r in low + pos:
                sel.append(dict(r, source=src, cluster=r['id']))
        ends = [r for r in load_jsonl(OUT / f'p3_boundary_{s}.jsonl') if r.get('endpoint') and r.get('excl') is None]
        kept = []
        for r in sorted(ends, key=lambda r: r['id']):
            # an end point that never left its seed is the Sobol point itself; near-identical end points of two
            # seeds (normalized distance < 0.02) are counted once (first by id)
            if abs(r['kappa'] - r['seed_kappa']) < 1e-15:
                continue
            u = B.to_u(s, r)
            if any(np.linalg.norm(u - B.to_u(s, k)) < 0.02 for k in kept):
                continue
            kept.append(r)
            sel.append(dict(r, source='search', cluster=r['seed']))
    sel = sorted(sel, key=lambda r: (r['system'], r['source'], r['id']))
    TSV.mkdir(parents=True, exist_ok=True)
    doc = dict(rule='protocol section 3', n=len(sel), counts=counts, points=[clean(r) for r in sel])
    (TSV / 'selection.json').write_text(json.dumps(doc, indent=0, default=float), encoding='utf-8')
    print('selection', len(sel), {s: sum(1 for r in sel if r['system'] == s) for s in SYSTEMS},
          'kappa<0:', sum(1 for r in sel if r['kappa'] < 0), 'sha256', sha(TSV / 'selection.json'))


def check_only():
    if not AUTH.exists():
        print('authorization file missing')
        return False
    a = json.loads(AUTH.read_text(encoding='utf-8'))
    ok = a.get('action') == 'ALLOW_TSV_RUN' and a.get('run_id') == 'TSV_a'
    for k, p in PIN_FILES.items():
        got = sha(p) if Path(p).exists() else 'MISSING'
        good = got == a.get('pins', {}).get(k)
        ok &= good
        print(f'{k:10s} {got} {"OK" if good else "MISMATCH"}')
    return ok


def run(run_id):
    if run_id != 'TSV_a':
        print('refused: run id must be TSV_a')
        return 3
    out = TSV / run_id
    if (out / 'exit_code.txt').exists():
        print('refused: finished run exists (no re-run)')
        return 3
    if not check_only():
        print('ABORT: pins or authorization')
        return 2
    out.mkdir(parents=True, exist_ok=True)
    sel = json.loads((TSV / 'selection.json').read_text(encoding='utf-8'))['points']
    done = {o['id'] for o in load_jsonl(out / 'stage2.jsonl')}
    log = open(out / 'log.txt', 'a', encoding='utf-8')
    t0 = time.perf_counter()
    exit_code = 1
    try:
        with open(out / 'stage2.jsonl', 'a', encoding='utf-8') as f2:
            for k, rec in enumerate(sel):
                if rec['id'] in done:
                    continue
                spec = {kk: v for kk, v in rec.items()}
                o = dict(id=rec['id'], system=rec['system'], source=rec['source'], cluster=rec['cluster'])
                try:
                    lay, G, P = C.BUILDERS[rec['system']](spec)
                    r1 = C.stage1(lay, G, P, rec={}, strict=True)
                    pin_ok = (r1.get('excl') is None and abs(r1['kappa'] - rec['kappa']) <= 1e-9 * max(1, abs(rec['kappa']))
                              and abs(r1['dGf'] - rec['dGf']) <= 1e-10)
                    o['stage1_pin_ok'] = bool(pin_ok)
                    if not pin_ok:
                        o['label'] = 'stage1-mismatch'
                    else:
                        o.update(C.stage2(lay, G, P, r1, with_exact=False))
                except Exception as exc:  # noqa: BLE001
                    o.update(label='error', error=f'{type(exc).__name__}: {exc}', tb=traceback.format_exc()[-500:])
                f2.write(json.dumps(clean(o), default=float) + '\n')
                f2.flush()
                msg = f"{k + 1}/{len(sel)} {rec['id']} kappa={rec['kappa']:.4f} ref_sign={o.get('ref_sign')} " \
                      f"rel_err={o.get('rel_err')} t={time.perf_counter() - t0:.0f}s"
                print(msg, flush=True)
                log.write(msg + '\n')
                log.flush()
        exit_code = 0
        return 0
    except Exception:  # noqa: BLE001
        (out / 'crash.txt').write_text(traceback.format_exc(), encoding='utf-8')
        return 1
    finally:
        log.close()
        if exit_code == 0:
            env = dict(python=sys.version.split()[0], numpy=np.__version__, blas_threads=1,
                       runtime_s=time.perf_counter() - t0, pins={k: sha(p) for k, p in PIN_FILES.items()})
            (out / 'environment.json').write_text(json.dumps(env, indent=1), encoding='utf-8')
            (out / 'exit_code.txt').write_text('0', encoding='utf-8')
            with open(out / 'SHA256SUMS', 'w', encoding='utf-8', newline='\n') as f:
                for p in sorted(out.iterdir()):
                    if p.name != 'SHA256SUMS':
                        f.write(f'{sha(p)}  {p.name}\n')


if __name__ == '__main__':
    C.lower_priority()
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument('--select', action='store_true')
    g.add_argument('--check-only', action='store_true')
    g.add_argument('--run')
    a = ap.parse_args()
    if a.select:
        select()
        sys.exit(0)
    if a.check_only:
        sys.exit(0 if check_only() else 2)
    sys.exit(run(a.run))
