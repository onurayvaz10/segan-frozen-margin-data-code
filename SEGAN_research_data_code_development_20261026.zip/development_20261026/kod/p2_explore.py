"""Phase 2b: predictor-only Sobol exploration of the physically sized families A2, B2 and the meshed system C.

For each candidate point only Stage-1 quantities are computed (x0 and x(+-h); no reference, no outcome). Points are
written one per line to out/p2_explore_<system>.jsonl; an interrupted run resumes from the file.
Usage: python -I p2_explore.py A2 B2 C   (scrambled Sobol, seeds fixed below, 2^m points per system)
"""
import json
import os
import math
import sys
import time
import traceback
from pathlib import Path

import numpy as np
from scipy.stats import qmc

HERE = Path(__file__).resolve().parent
OUT = Path(os.environ.get('G91_OUT', str(HERE.parent / 'out')))
sys.path.insert(0, str(HERE))
import ext_common as C  # noqa: E402

# (name, lo, hi, log)
SPACES = {
    'A2': [('Kiv', 15, 2700, True), ('s_pll', 0.25, 4, True), ('s_cc', 0.5, 2, True), ('lv', 0.05, 0.40, False),
           ('rv', 0.0, 0.10, False), ('s_v', 0.5, 2, True), ('s_line', 0.5, 3, True), ('rx', 0.1, 3.0, True),
           ('kq', 0.02, 0.10, False), ('Rp', 0.01, 0.05, False), ('P_set', 0.45, 0.75, False),
           ('G_R', 0.05, 0.35, False)],
    'B2': [('P1', 0.10, 0.35, False), ('P2', 0.20, 0.45, False), ('G2', 0.0, 0.15, False), ('G_R', 0.05, 0.30, False),
           ('s_l1', 0.5, 2.5, True), ('s_l2', 0.5, 2.5, True), ('rx', 0.1, 3.0, True), ('Kiv1', 15, 2700, True),
           ('Kiv2', 15, 2700, True), ('s_pll1', 0.25, 4, True), ('s_pll2', 0.25, 4, True), ('lv', 0.05, 0.40, False)],
    'C': [('P1', 0.10, 0.30, False), ('P2', 0.10, 0.30, False), ('P3', 0.15, 0.45, False), ('G1', 0.0, 0.10, False),
          ('G3', 0.0, 0.10, False), ('G_R', 0.05, 0.30, False), ('z_trunk', 0.02, 0.08, False),
          ('rx_trunk', 0.2, 1.0, False), ('z_loop', 0.02, 0.10, False), ('rx', 0.5, 3.0, True),
          ('f23', 0.5, 2.0, True), ('f34', 0.5, 2.0, True), ('f14', 0.5, 2.0, True), ('Kiv1', 15, 2700, True),
          ('Kiv2', 15, 2700, True), ('Kiv3', 15, 2700, True), ('s_pll1', 0.25, 4, True), ('s_pll2', 0.25, 4, True),
          ('s_pll3', 0.25, 4, True), ('lv', 0.05, 0.40, False)],
}
SEEDS = {'A2': 2026102501, 'B2': 2026102502, 'C': 2026102503}
M_LOG2 = {'A2': 12, 'B2': 12, 'C': 12}


def points(system):
    sp = SPACES[system]
    u = qmc.Sobol(d=len(sp), scramble=True, seed=SEEDS[system]).random_base2(M_LOG2[system])
    out = []
    for i, row in enumerate(u):
        d = dict(id=f'{system}-{i:05d}', system=system)
        for (nm, lo, hi, lg), ui in zip(sp, row):
            d[nm] = float(math.exp(math.log(lo) + ui * (math.log(hi) - math.log(lo)))) if lg else float(lo + ui * (hi - lo))
        out.append(d)
    return out


def clean(r):
    o = {}
    for k, v in r.items():
        if isinstance(v, (np.floating,)):
            v = float(v)
        elif isinstance(v, (np.integer,)):
            v = int(v)
        elif isinstance(v, complex):
            v = [v.real, v.imag]
        o[k] = v
    return o


def run(system):
    path = OUT / f'p2_explore_{system}.jsonl'
    done = set()
    if path.exists():
        for line in open(path, encoding='utf-8'):
            done.add(json.loads(line)['id'])
    pts = points(system)
    t0 = time.perf_counter()
    n_new = 0
    with open(path, 'a', encoding='utf-8') as f:
        for sp in pts:
            if sp['id'] in done:
                continue
            try:
                lay, G, P = C.BUILDERS[system](sp)
                r = C.stage1(lay, G, P, rec=dict(sp), strict=True)
            except Exception as exc:  # noqa: BLE001
                r = dict(sp, excl='error', error=f'{type(exc).__name__}: {exc}', tb=traceback.format_exc()[-400:])
            f.write(json.dumps(clean(r), default=float) + '\n')
            f.flush()
            n_new += 1
            if n_new % 100 == 0:
                C.plog(f'{system} {n_new} {time.perf_counter() - t0:.0f}s', OUT / 'progress.txt')
    C.plog(f'{system} done {n_new} {time.perf_counter() - t0:.0f}s', OUT / 'progress.txt')


if __name__ == '__main__':
    C.lower_priority()
    for s in sys.argv[1:]:
        run(s)
