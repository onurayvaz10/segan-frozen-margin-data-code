"""Phase 12: computational cost of the estimators (post hoc benchmark; timings are machine dependent).

Points: six F2 members (original model; the members of the earlier cost benchmark) and, per new family, the first
two Stage-1-evaluable Sobol points with kappa >= tau and the first one with kappa <= -tau (by id) of the selection.
Each estimator is computed from scratch (dispatch included), once as warm-up and then REPS times; the median,
minimum and maximum wall-clock and CPU times are recorded together with the counts of nonlinear equilibrium solves,
Jacobian evaluations, full frequency scans and dense eigenvalue problems.
Estimators: frozen; first order (kappa, also gives Re eta only and kappa_L at no extra cost); second order
(+2 equilibria); secant_1 (+1 equilibrium, +1 scan; also gives the single-step sign); secant_2 (+2, +2);
reference continuation (relative tolerance, 0.01 dGf grid, bisection 1e-9).
Writes out/p12_cost.csv and out/p12_environment.json.
"""
import csv
import json
import math
import os
import platform
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
OUT = Path(os.environ.get('G91_OUT', str(HERE.parent / 'out')))
sys.path.insert(0, str(HERE))
import ext_common as C  # noqa: E402
import ext_engine as X  # noqa: E402

REPS = 5
F2_MEMBERS = [(0.55, 0.34), (0.60, 0.34), (0.625, 0.34), (0.65, 0.34), (0.675, 0.32), (0.70, 0.29)]


class Counter:
    """Wraps engine functions to count calls (restored after use)."""
    names = ('newton_fixed_refs', 'jac', 'crossings', 'spectral_abscissa')

    def __enter__(self):
        self.n = {k: 0 for k in self.names}
        self.orig = {k: getattr(X, k) for k in self.names}
        for k in self.names:
            def wrap(*a, _k=k, **kw):
                self.n[_k] += 1
                return self.orig[_k](*a, **kw)
            setattr(X, k, wrap)
        return self

    def __exit__(self, *a):
        for k in self.names:
            setattr(X, k, self.orig[k])


def frozen(lay, G, P):
    d = X.dispatch(lay, P, G, tol=1e-12)
    x0, refs = d['x'], d['refs']
    sb = lay.sysd['shed_bus']
    Jm = X.jac(lay, x0, refs, G)
    th = float(np.arctan2(x0[lay.ix[f'V{sb}:I']], x0[lay.ix[f'V{sb}:R']]))
    fm = X.frozen_margin(lay, Jm, th, G[sb])
    return dict(x0=x0, refs=refs, th=th, fm=fm, value=fm['rho'])


def first(lay, G, P):
    f = frozen(lay, G, P)
    k = X.kappa_hat(lay, f['x0'], f['refs'], G, f['th'], f['fm'])
    f.update(k=k, value=f['fm']['rho'] / (1 - k['kappa']))
    return f


def second(lay, G, P):
    f = first(lay, G, P)
    sb = lay.sysd['shed_bus']
    h = 1e-3 * f['fm']['rho']
    rr = {}
    for sg in (1, -1):
        Gk = G.copy()
        Gk[sb] -= sg * h
        xs = X.newton_fixed_refs(lay, f['x0'], f['refs'], Gk)[0]
        rr[sg] = X.rho_at(lay, xs, f['refs'], G, f['th'], f['fm'])['rho']
    kfd = (rr[1] - rr[-1]) / (2 * h)
    curv = (rr[1] - 2 * f['fm']['rho'] + rr[-1]) / h ** 2
    f['value'] = C.quad_root(f['fm']['rho'], kfd, curv)
    return f


def secant(lay, G, P, n):
    f = frozen(lay, G, P)
    dGf = f['value']
    F1, _ = C.F_min_at(lay, f['x0'], f['refs'], G, dGf, f['th'])
    s = dGf * dGf / (dGf - F1)
    if n == 2:
        F2, _ = C.F_min_at(lay, f['x0'], f['refs'], G, s, f['th'])
        s = s - F2 * (s - dGf) / (F2 - F1)
    f['value'] = s
    return f


def reference(lay, G, P):
    f = frozen(lay, G, P)
    sb = lay.sysd['shed_bus']
    dGf = f['value']
    R = X.reference_margin(lay, f['x0'], f['refs'], G, min(G[sb], 2 * dGf), 0.01 * dGf, tol=1e-9, alpha_tab='rel')
    f['value'] = R['dGt']
    return f


ESTS = [('frozen', frozen), ('first_order', first), ('second_order', second),
        ('secant_1', lambda l, g, p: secant(l, g, p, 1)), ('secant_2', lambda l, g, p: secant(l, g, p, 2)),
        ('reference', reference)]


def points():
    pts = [('F2', f'S3_P{p:g}_G{g:g}', C.build_F2(p, g)) for p, g in F2_MEMBERS]
    sel = json.loads((OUT / 'tsv' / 'selection.json').read_text(encoding='utf-8'))['points']
    for s in ('A2', 'B2', 'C'):
        sob = sorted([r for r in sel if r['system'] == s and r['source'] == 'sobol'], key=lambda r: r['id'])
        pos = [r for r in sob if r['kappa'] >= C.TAU_K][:2]
        neg = [r for r in sorted([r for r in sel if r['system'] == s], key=lambda r: r['id']) if r['kappa'] <= -C.TAU_K][:1]
        for r in pos + neg:
            pts.append((s, r['id'], C.BUILDERS[s](r)))
    return pts


def main():
    C.lower_priority()
    rows = []
    for fam, pid, (lay, G, P) in points():
        for name, fn in ESTS:
            fn(lay, G, P)                                   # warm-up
            wall, cpu = [], []
            for _ in range(REPS):
                with Counter() as cn:
                    t0, c0 = time.perf_counter(), time.process_time()
                    v = fn(lay, G, P)['value']
                    wall.append(time.perf_counter() - t0)
                    cpu.append(time.process_time() - c0)
            rows.append(dict(family=fam, id=pid, n_states_reduced=lay.n - 1, estimator=name, value=v,
                             equilibrium_solves=cn.n['newton_fixed_refs'], jacobians=cn.n['jac'],
                             full_scans=cn.n['crossings'], state_eig=cn.n['spectral_abscissa'],
                             wall_median=float(np.median(wall)), wall_min=float(np.min(wall)),
                             wall_max=float(np.max(wall)), cpu_median=float(np.median(cpu)), reps=REPS))
            print(fam, pid, name, f"{rows[-1]['wall_median']:.3f}s", cn.n, flush=True)
    with open(OUT / 'p12_cost.csv', 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    env = dict(python=sys.version.split()[0], numpy=np.__version__, platform=platform.platform(),
               processor=platform.processor(), cpu_count=os.cpu_count(), blas_threads=os.environ.get('OPENBLAS_NUM_THREADS'),
               reps=REPS, warmup=1, timer='time.perf_counter / time.process_time', date=time.strftime('%Y-%m-%d %H:%M'))
    (OUT / 'p12_environment.json').write_text(json.dumps(env, indent=1), encoding='utf-8')


if __name__ == '__main__':
    main()
