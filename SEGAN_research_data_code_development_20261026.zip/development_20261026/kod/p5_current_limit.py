"""Phase 5: current-limiting realism test (post hoc, not protocol-fixed).

Part A (small signal). Six evaluable F2 members (one per P_set, including the reference member (0.65, 0.20)) with
  L0: base model (no limiter);
  GFM limiter on the inner current reference, i_lim = i_ref (1 + (|i_ref|/Imax)^p)^(-1/p), back-calculation
  anti-windup kaw = kiv/kpv, Imax in {1.5, 1.2, 1.1, 1.0, 0.95, 0.90} pu with p = 20 and Imax in {1.2, 1.0} with p = 8;
  CPL limiter on (Idr, Iq_ref), Imax in {1.0, 0.75} pu, p = 20.
The controller set-points are those of the base dispatch (the same controllers with a limiter added); the equilibrium
with the limiter is solved with these set-points fixed. For every case: equilibrium shift, spectral abscissa,
frozen margin, crossing frequency, kappa, first/second-order estimates, reference margin and errors, and the limiter
utilisation |i_ref|/Imax at x0 and at x(dGt).
Part B (large signal). Abrupt shedding of the member (0.65, 0.20) from the common pre-shedding equilibrium by the
frozen, quadratic, recorded-reference and tangent amounts (Radau, rtol 1e-7, atol 1e-9, max step 5 ms, 3 s, as the
original check), without limiter (must reproduce the published behaviour) and with GFM Imax 1.2 / 1.0 and CPL
Imax 1.0. A run is called divergent when the bus-voltage deviation exceeds 1 pu (event) or the solver fails.
Writes out/p5_current_limit_A.csv, out/p5_current_limit_B.json, out/p5_traces_B.csv.
"""
import csv
import json
import os
import math
import sys
import time
from pathlib import Path

import numpy as np
from scipy.integrate import solve_ivp

HERE = Path(__file__).resolve().parent
RI = HERE.parents[1]
OUT = Path(os.environ.get('G91_OUT', str(HERE.parent / 'out')))
sys.path.insert(0, str(HERE))
import ext_common as C  # noqa: E402
import ext_engine as X  # noqa: E402

MEMBERS = [(0.55, 0.34), (0.60, 0.27), (0.625, 0.22), (0.65, 0.20), (0.675, 0.18), (0.70, 0.29)]


def gfm_lim(Imax, p):
    g = X.base_parameters()['gfm']
    return dict(Imax=Imax, p=p, kaw=g['kiv'] / g['kpv'])


def cpl_lim(Imax, p):
    q = X.base_parameters()['cpl']
    return dict(Imax=Imax, p=p, kaw=q['kiv'] / q['kpv'])


SCEN = [('L0', None, None)]
SCEN += [(f'GFM_I{I:g}_p20', gfm_lim(I, 20.0), None) for I in (1.5, 1.2, 1.1, 1.0, 0.95, 0.90)]
SCEN += [(f'GFM_I{I:g}_p8', gfm_lim(I, 8.0), None) for I in (1.2, 1.0)]
SCEN += [(f'CPL_I{I:g}_p20', None, cpl_lim(I, 20.0)) for I in (1.0, 0.75)]


def util(lay, x, refs, G):
    """|i_ref|/Imax of the GFM and of the CPL current references at state x (NaN if no limiter)."""
    s = lay.sysd
    ix = lay.ix
    g = s['par']['gfm']
    out = {}
    z = g['w_ref'] + g['Rp'] * (refs[0] - x[ix['G:pm']])
    th = x[ix['G:th']]
    Idf, Iqf = X.park(th, x[ix['G:Irf']], x[ix['G:Iif']])
    Vdf, Vqf = X.park(th, x[ix['G:Vrf']], x[ix['G:Vif']])
    Voc = refs[2] + g['kq'] * (refs[1] - x[ix['G:qm']])
    Vdr = Voc - g['rv'] * Idf + z * g['lv'] * Iqf
    Vqr = -g['rv'] * Iqf - z * g['lv'] * Idf
    Idcr = g['kpv'] * (Vdr - Vdf) + g['kiv'] * x[ix['G:xid']] - g['cf'] * z * Vqf + g['kffi'] * Idf
    Iqcr = g['kpv'] * (Vqr - Vqf) + g['kiv'] * x[ix['G:xiq']] + g['cf'] * z * Vdf + g['kffi'] * Iqf
    lim = s.get('gfm_ilim')
    out['u_gfm'] = math.hypot(Idcr, Iqcr) / lim['Imax'] if lim else float('nan')
    out['i_gfm_ref'] = math.hypot(Idcr, Iqcr)
    q = s['cpls'][0]['par']
    Idr = q['kpv'] * (refs[3] - x[ix['C0:vdc']]) + q['kiv'] * x[ix['C0:eta']]
    clim = q.get('ilim')
    out['i_cpl_ref'] = math.hypot(Idr, refs[4])
    out['u_cpl'] = math.hypot(Idr, refs[4]) / clim['Imax'] if clim else float('nan')
    return out


def part_A():
    rows = []
    for P_set, G_R in MEMBERS:
        lay0, G, P = C.build_F2(P_set, G_R)
        d0 = X.dispatch(lay0, P, G, tol=1e-12)
        x00, refs = d0['x'], d0['refs']
        for name, gl, cl in SCEN:
            t0 = time.perf_counter()
            lay, G, P = C.build_F2(P_set, G_R, ilim=gl, cpl_ilim=cl)
            row = dict(member=f'S3_P{P_set:g}_G{G_R:g}', P_set=P_set, G_R=G_R, scenario=name,
                       Imax_gfm=gl['Imax'] if gl else None, p_gfm=gl['p'] if gl else None,
                       Imax_cpl=cl['Imax'] if cl else None)
            x0, ok, it, _ = X.newton_fixed_refs(lay, x00, refs, G)
            if not ok:
                row['status'] = 'no equilibrium with imposed set-points'
                rows.append(row)
                continue
            ix = lay.ix
            row['dV_bus'] = math.hypot(x0[ix['V1:R']], x0[ix['V1:I']]) - math.hypot(x00[ix['V1:R']], x00[ix['V1:I']])
            row['dx_rel'] = float(np.linalg.norm(x0 - x00) / np.linalg.norm(x00))
            row.update({k + '_x0': v for k, v in util(lay, x0, refs, G).items()})
            r = C.stage1_at(lay, G, P, x0, refs, rec={}, strict=False)
            row['excl'] = r.get('excl')
            for k in ('alpha0', 'dGf', 'omega', 'c', 'kappa', 'kappa_L', 'kappa_V', 'kappa_theta', 'k_fd', 'curv',
                      'dG1st', 'dG2nd', 'eps2', 'Vmin'):
                row[k] = r.get(k)
            if r.get('excl') is None:
                s2 = C.stage2(lay, G, P, r, with_exact=False, x0=x0, refs=refs)
                row.update(dGt=s2['dGref'], ref_status=s2['ref_status'], ref_sign=s2['ref_sign'],
                           F_single=s2['F_single'], dG_sec1=s2['dG_sec1'])
                if s2['ref_status'] == 'alpha':
                    Gk = G.copy()
                    Gk[1] -= s2['dGref']
                    xt, okt, _, _ = X.newton_fixed_refs(lay, x0, refs, Gk)
                    if okt:
                        row.update({k + '_xt': v for k, v in util(lay, xt, refs, Gk).items()})
                for k in ('dGf', 'dG1st', 'dG2nd', 'dG_sec1'):
                    v = row.get(k)
                    row['err_' + k] = (v - s2['dGref']) if v is not None and math.isfinite(v) else None
                row['pred_sign_ok'] = (1 if r['kappa'] > 0 else -1) == s2['ref_sign']
            row['t_s'] = time.perf_counter() - t0
            rows.append(row)
            print(row['member'], name, row.get('excl'), row.get('dGf'), row.get('kappa'), row.get('dGt'),
                  f"u0={row.get('u_gfm_x0')}", flush=True)
    keys = []
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    with open(OUT / 'p5_current_limit_A.csv', 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)
    return rows


def simulate(lay, x_pre, refs, G_post, x_eq, T_end=3.0):
    ix = lay.ix
    n = lay.n
    Minv = 1.0 / lay.M
    bR, bI = ix['V1:R'], ix['V1:I']
    vb_eq = math.hypot(x_eq[bR], x_eq[bI])

    def f(t, x):
        return Minv * X.rhs(lay, x, refs, G_post)

    def jac(t, x):
        return Minv[:, None] * X.jac(lay, x, refs, G_post)

    def ev(t, x):
        return 1.0 - abs(math.hypot(x[bR], x[bI]) - vb_eq)
    ev.terminal = True
    T = np.linspace(0, T_end, int(round(T_end * 1000)) + 1)
    sol = solve_ivp(f, (0, T_end), x_pre, t_eval=T, method='Radau', rtol=1e-7, atol=1e-9, max_step=0.005,
                    jac=jac, events=ev)
    vb = np.hypot(sol.y[bR], sol.y[bI]) - vb_eq
    vdc = sol.y[ix['C0:vdc']] - x_eq[ix['C0:vdc']]
    return sol, vb, vdc


def part_B(rowsA):
    P_set, G_R = 0.65, 0.20
    lay0, G, P = C.build_F2(P_set, G_R)
    d0 = X.dispatch(lay0, P, G, tol=1e-12)
    x_pre, refs = d0['x'], d0['refs']
    rA = [r for r in rowsA if r['member'] == 'S3_P0.65_G0.2' and r['scenario'] == 'L0'][0]
    cases = [('frozen', rA['dGf']), ('quadratic', rA['dG2nd']), ('recorded_reference', rA['dGt']),
             ('tangent', rA['dG1st'])]
    scen = [('L0', None, None), ('GFM_I1.2_p20', gfm_lim(1.2, 20.0), None), ('GFM_I1_p20', gfm_lim(1.0, 20.0), None),
            ('CPL_I1_p20', None, cpl_lim(1.0, 20.0)), ('GFM_I1_CPL_I1', gfm_lim(1.0, 20.0), cpl_lim(1.0, 20.0))]
    summ = dict(member='S3_P0.65_G0.20', method='Radau', rtol=1e-7, atol=1e-9, max_step_s=0.005, T_end_s=3.0,
                divergence='bus-voltage deviation > 1 pu (terminal event) or solver failure', runs=[])
    traces = []
    for sname, gl, cl in scen:
        lay, G, P = C.build_F2(P_set, G_R, ilim=gl, cpl_ilim=cl)
        xp, okp, _, _ = X.newton_fixed_refs(lay, x_pre, refs, G)
        for cname, dg in cases:
            Gp = G.copy()
            Gp[1] -= dg
            xe, oke, _, _ = X.newton_fixed_refs(lay, xp, refs, Gp)
            t0 = time.perf_counter()
            sol, vb, vdc = simulate(lay, xp, refs, Gp, xe)
            ev_t = float(sol.t_events[0][0]) if len(sol.t_events[0]) else None
            env = []
            for a in np.arange(0, 3.0, 0.25):
                msk = (sol.t >= a) & (sol.t < a + 0.25)
                env.append(float(np.abs(vb[msk]).max()) if msk.any() else None)
            # peak limiter utilisation over the trajectory
            umax_g = umax_c = float('nan')
            if gl or cl:
                us = [util(lay, sol.y[:, j], refs, Gp) for j in range(0, sol.y.shape[1], 5)]
                umax_g = max((u['u_gfm'] for u in us), default=float('nan'))
                umax_c = max((u['u_cpl'] for u in us), default=float('nan'))
            ru = dict(scenario=sname, case=cname, dG=dg, equilibrium_found=bool(oke), success=bool(sol.success),
                      message=str(sol.message), diverged_at_s=ev_t, last_time_s=float(sol.t[-1]),
                      peak_dev_first_250ms=env[0], envelope_250ms=env, final_dev=float(abs(vb[-1])),
                      u_gfm_peak=umax_g, u_cpl_peak=umax_c, t_wall_s=time.perf_counter() - t0)
            summ['runs'].append(ru)
            print(sname, cname, ru['success'], ev_t, ru['last_time_s'], env[0], env[-1], umax_g, umax_c, flush=True)
            for j in range(0, len(sol.t), 2):
                traces.append([sname, cname, float(sol.t[j]), float(vb[j]), float(vdc[j])])
    (OUT / 'p5_current_limit_B.json').write_text(json.dumps(summ, indent=1, default=float), encoding='utf-8')
    with open(OUT / 'p5_traces_B.csv', 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['scenario', 'case', 'time_s', 'bus_voltage_dev_pu', 'vdc_dev_pu'])
        w.writerows(traces)


if __name__ == '__main__':
    C.lower_priority()
    rowsA = part_A()
    part_B(rowsA)
