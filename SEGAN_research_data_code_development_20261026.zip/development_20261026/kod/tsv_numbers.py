"""Collect the numbers quoted in the manuscript from the TSV analysis outputs and the cost benchmark
(writes out/tsv/TSV_a/analysis/quoted_numbers.json and prints them)."""
import csv
import json
import math
import os
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
OUT = Path(os.environ.get('G91_OUT', str(HERE.parent / 'out')))
A = OUT / 'tsv' / 'TSV_a' / 'analysis'
res = json.load(open(A / 'results.json', encoding='utf-8'))
pts = list(csv.DictReader(open(A / 'points.csv', encoding='utf-8')))
est = list(csv.DictReader(open(A / 'estimators.csv', encoding='utf-8')))


def f(x):
    try:
        v = float(x)
        return v if math.isfinite(v) else float('nan')
    except (TypeError, ValueError):
        return float('nan')


q = {}
d = res['directional']
for k in ('pooled', 'pooled_excl_preseen', 'sobol', 'focused', 'search', 'A2', 'B2', 'C'):
    e = d[k]
    q[k] = dict(n=e['n'], n_minus=e['n_minus'], n_plus=e['n_plus'], agree_neg=e['agree_kappa_neg'], agree_pos=e['agree_kappa_pos'],
                wilson_neg=e['wilson_kappa_neg'], wilson_pos=e['wilson_kappa_pos'], acc_R1=e['acc_R1_kappa'],
                acc_const=e['acc_R2_const_plus'], acc_R4=e['acc_R4_re_eta'], acc_R5=e['acc_R5_kappa_L'],
                bal=e['balanced_acc_R1'], bal_ci=e['balanced_acc_R1_cluster_boot']['bca'], mcc=e['mcc_R1'],
                p_const=e['mcnemar_vs_best_constant']['p'], mcn_const=e['mcnemar_vs_best_constant'],
                p_R4=e['mcnemar_vs_R4']['p'], mcn_R4=e['mcnemar_vs_R4'], p_R5=e['mcnemar_vs_R5']['p'],
                verdict=e['verdict'], row=e['decision_row'], confusion=e['confusion'], cex=e['counterexamples_R1'],
                wilson_R1=e['wilson_R1_kappa'])
q['abstain_band'] = res['abstain_band']
q['ties'] = res['ties']
q['excluded'] = res['excluded']
q['censored'] = res['censored']
q['fold'] = res['fold']
q['bias'] = res['bias_direction']
q['paired'] = {k: dict(est=v['est'], bca=v['bca']) for k, v in res['paired'].items()}
q['eps2_rel'] = res.get('first_order_vs_eps2_over_4')
q['simpson'] = res['simpson_check']
# abstention band: does the sign of kappa still match?
band = [r for r in pts if abs(f(r['kappa'])) < 0.05]
bm = [r for r in band if r['ref_sign'] not in ('0', '0.0')]
q['band_sign_match'] = (sum(1 for r in bm if (1 if f(r['kappa']) > 0 else -1) == int(float(r['ref_sign']))), len(bm))
neg = [r for r in pts if f(r['kappa']) <= -0.05 and r['ref_sign'] not in ('0', '0.0')]
rel = [100 * f(r['rel_err']) for r in neg]
q['neg_rel_err_pct_range'] = [min(rel), max(rel)] if rel else None
pos = [r for r in pts if f(r['kappa']) >= 0.05 and r['ref_sign'] not in ('0', '0.0') and r.get('censored') in ('False', 'false')]
relp = [100 * f(r['rel_err']) for r in pos]
q['pos_rel_err_pct_median_range'] = [float(np.median(relp)), min(relp), max(relp)] if relp else None
q['estimators'] = {(r['set'] + ':' + r['estimator']): dict(n=r['n'], MAE=f(r['MAE']), lo=f(r['MAE_lo']), hi=f(r['MAE_hi']),
                                                            mrel=f(r['mean_rel_pct']), p95=f(r['p95_abs_rel_pct']),
                                                            over=r['overshoot'], maxAE=f(r['max_AE'])) for r in est}
bands = list(csv.DictReader(open(A / 'envelope_bands.csv', encoding='utf-8')))
q['bands'] = bands
cost = OUT / 'p12_cost.csv'
if cost.exists():
    C = list(csv.DictReader(open(cost, encoding='utf-8')))
    agg = {}
    for r in C:
        agg.setdefault((r['family'], r['estimator']), []).append(f(r['wall_median']))
        agg.setdefault((r['family'], r['estimator'] + ':eq'), []).append(f(r['equilibrium_solves']))
    q['cost'] = {f'{a}:{b}': [min(v), max(v)] for (a, b), v in agg.items()}
(A / 'quoted_numbers.json').write_text(json.dumps(q, indent=1, default=float), encoding='utf-8')
print(json.dumps(q, indent=1, default=float)[:12000])
