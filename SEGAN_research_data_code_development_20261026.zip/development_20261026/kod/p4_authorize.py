"""Write the authorization file of the single TSV run: SHA-256 pins of the protocol, engine, common module, run and
analysis scripts and of the selection file, with a time stamp. Refuses to overwrite an existing authorization."""
import hashlib
import json
import os
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OUT = Path(os.environ.get('G91_OUT', str(ROOT / 'out')))
AUTH = ROOT / 'protokol' / 'TSV_yetki_TSV_a.json'
PINS = dict(protocol=ROOT / 'protokol' / 'TSV_PROTOKOL_v1.txt', engine=HERE / 'ext_engine.py',
            common=HERE / 'ext_common.py', runner=HERE / 'p4_stage2.py', analysis=HERE / 'p4_analysis.py',
            selection=OUT / 'tsv' / 'selection.json')


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


if AUTH.exists():
    print('refused: authorization exists')
    sys.exit(3)
doc = dict(action='ALLOW_TSV_RUN', run_id='TSV_a', created=time.strftime('%Y-%m-%d %H:%M:%S'),
           basis='protocol TSV v1.0 (2026-10-26) hashed before any '
                 'reference of the families A2, B2, C was computed',
           pins={k: sha(p) for k, p in PINS.items()},
           selection_note='selection.json lives in the computation output directory and is copied to S1 with the run')
AUTH.write_text(json.dumps(doc, indent=1), encoding='utf-8')
print(json.dumps(doc, indent=1))
