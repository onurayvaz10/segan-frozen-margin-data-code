"""Summary of the current-limiting study (reads out/p5_current_limit_A.csv and _B.json; writes
out/p5_summary_scenarios.csv and out/p5_summary.json). No new computation."""
import csv
import json
import math
import os
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
OUT = Path(os.environ.get('G91_OUT', str(HERE.parent / 'out')))


def f(x):
    try:
        v = float(x)
        return v if math.isfinite(v) else float('nan')
    except (TypeError, ValueError):
        return float('nan')


A = list(csv.DictReader(open(OUT / 'p5_current_limit_A.csv', encoding='utf-8')))
base = {r['member']: r for r in A if r['scenario'] == 'L0'}
order = []
for r in A:
    if r['scenario'] not in order:
        order.append(r['scenario'])
rows = []
signs = dict(n=0, agree=0, neg=0, neg_agree=0, fails=[])
for sc in order:
    rr = [r for r in A if r['scenario'] == sc]
    ok = [r for r in rr if r.get('excl') in ('', None) and r.get('dGt') not in ('', None)]
    u = [f(r['u_gfm_x0']) if sc.startswith('GFM') or sc == 'L0' else f(r['u_cpl_x0']) for r in rr]
    u = [x for x in u if math.isfinite(x)]

    def rel(key):
        v = [abs(f(r[key]) - f(base[r['member']][key])) / abs(f(base[r['member']][key])) for r in ok]
        v = [x for x in v if math.isfinite(x)]
        return max(v) if v else float('nan')
    row = dict(scenario=sc, members=len(rr), evaluated=len(ok),
               no_equilibrium=sum(1 for r in rr if (r.get('status') or '').startswith('no equilibrium')),
               excluded=sum(1 for r in rr if r.get('excl') not in ('', None)),
               u0_min=min(u) if u else float('nan'), u0_max=max(u) if u else float('nan'),
               max_rel_change_dGf=rel('dGf'), max_rel_change_kappa=rel('kappa'), max_rel_change_dGt=rel('dGt'),
               kappa_min=min((f(r['kappa']) for r in ok), default=float('nan')),
               kappa_max=max((f(r['kappa']) for r in ok), default=float('nan')),
               sign_agree=sum(1 for r in ok if r.get('pred_sign_ok') == 'True'),
               frozen_optimistic=sum(1 for r in ok if f(r['dGt']) < f(r['dGf'])))
    rows.append(row)
    if sc != 'L0':
        for r in ok:
            signs['n'] += 1
            signs['agree'] += r.get('pred_sign_ok') == 'True'
            if f(r['kappa']) < 0:
                signs['neg'] += 1
                signs['neg_agree'] += r.get('pred_sign_ok') == 'True'
            if r.get('pred_sign_ok') != 'True':
                signs['fails'].append(dict(member=r['member'], scenario=sc, kappa=f(r['kappa']), dGf=f(r['dGf']),
                                           dGt=f(r['dGt']), eps2=f(r['eps2']), u0=f(r['u_gfm_x0'])))
with open(OUT / 'p5_summary_scenarios.csv', 'w', newline='', encoding='utf-8') as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0]))
    w.writeheader()
    w.writerows(rows)
B = json.load(open(OUT / 'p5_current_limit_B.json', encoding='utf-8'))
largesig = []
for r in B['runs']:
    env = [x for x in r['envelope_250ms'] if x is not None]
    if r['diverged_at_s'] is not None:
        outcome = f"diverged at {r['diverged_at_s']:.2f} s"
    elif env[-1] < 1e-6:
        outcome = 'decayed'
    elif env[-1] < 0.5 * env[0] and env[-1] < env[-4]:
        outcome = f'decaying slowly (last envelope {env[-1]:.1e} pu)'
    else:
        outcome = f'sustained oscillation ({env[-1]:.2f} pu)'
    largesig.append(dict(scenario=r['scenario'], case=r['case'], dG=r['dG'], outcome=outcome,
                         u_gfm_peak=r['u_gfm_peak'], u_cpl_peak=r['u_cpl_peak']))
summ = dict(scenarios=rows, sign_rule=signs, large_signal=largesig)
(OUT / 'p5_summary.json').write_text(json.dumps(summ, indent=1, default=float), encoding='utf-8')
for r in rows:
    print(r)
print(signs)
for r in largesig:
    print(r)
