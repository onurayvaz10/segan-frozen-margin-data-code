"""Phase 2a: exploratory look at the predictor-only Stage-1 records of the sealed PSV run (no reference quantities).

Reads psv/out/PSV_20261025_a/stage1.json (kappa, c, eta at x0 only) and prints how kappa and its two parts
(Re eta, -c Im eta) vary with each sampled parameter. Uses no outcome (Stage-2) field.
"""
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
ST1 = ROOT / 'revizyon_20261025' / 'psv' / 'out' / 'PSV_20261025_a' / 'stage1.json'

recs = json.loads(ST1.read_text(encoding='utf-8'))
ev = [r for r in recs if r.get('excl') is None]
print('evaluable+abstain', len(ev))
for sysname, keys in (('A', ['Kiv', 's_pll', 's_cc', 'lv', 'rv', 's_v', 's_line', 'kq', 'Rp', 'P_set', 'G_R']),
                      ('B', ['P1', 'P2', 'G2', 'G_R', 's_l1', 's_l2', 'Kiv1', 'Kiv2', 's_pll1', 's_pll2', 'lv'])):
    E = [r for r in ev if r['system'] == sysname]
    k = np.array([r['kappa'] for r in E])
    re = np.array([r['eta_re'] for r in E])
    cim = np.array([-r['c'] * r['eta_im'] for r in E])
    c = np.array([r['c'] for r in E])
    om = np.array([r['omega'] for r in E])
    print(f'--- system {sysname}: n={len(E)} kappa [{k.min():.3f},{k.max():.3f}] median {np.median(k):.3f}')
    print(f'    c [{c.min():.3f},{c.max():.3f}]  omega [{om.min():.0f},{om.max():.0f}]  Re eta [{re.min():.3f},{re.max():.3f}]'
          f'  -c Im eta [{cim.min():.3f},{cim.max():.3f}]')
    for kk in keys:
        x = np.array([r[kk] for r in E])
        lx = np.log(x) if kk in ('Kiv', 's_pll', 's_cc', 's_v', 's_line', 'Kiv1', 'Kiv2', 's_pll1', 's_pll2', 's_l1', 's_l2') else x
        rk = np.corrcoef(np.argsort(np.argsort(lx)), np.argsort(np.argsort(k)))[0, 1]
        rc = np.corrcoef(np.argsort(np.argsort(lx)), np.argsort(np.argsort(cim)))[0, 1]
        rr = np.corrcoef(np.argsort(np.argsort(lx)), np.argsort(np.argsort(re)))[0, 1]
        print(f'    {kk:7s} Spearman kappa {rk:+.2f}  -cIm {rc:+.2f}  Re {rr:+.2f}')
    lo = sorted(E, key=lambda r: r['kappa'])[:6]
    for r in lo:
        print('    low:', r['id'], {kk: round(r[kk], 4) for kk in keys}, 'k', round(r['kappa'], 4), 'c', round(r['c'], 3),
              'w', round(r['omega'], 1), 'Re', round(r['eta_re'], 4), 'Im', round(r['eta_im'], 4))
# where do G4 exclusions sit (dGf beyond G_R): dGf vs G_R
g4 = [r for r in recs if r.get('excl') == 'G4' and r.get('dGf') is not None]
print('G4 with dGf known', len(g4), 'ratio dGf/G_R median', np.median([r['dGf'] / r['G_R'] for r in g4]))
sys.exit(0)
