"""Regression and known-answer tests of the extended engine (run before any new computation).

1. With all extensions off, ext_engine reproduces ind_engine bit for bit (rhs, Jacobian, dispatch, frozen margin,
   kappa) on the original member S3_P0.65_G0.20 and on two PSV points (one per system).
2. ext_common.stage1 reproduces the sealed F2 values (dGf, omega, kappa) of three members and the sealed PSV
   Stage-1 values of the two PSV points (lenient strictness, as the PSV gates).
3. A GFM limiter with Imax = 1e3 changes nothing measurable (relative 1e-10); the CPL limiter likewise.
4. Q_set = 0 path equals the default; Q_set != 0 gives the requested reactive power.
5. Ideal-CPL decomposition: kappa_L of the sealed record (k_L) is reproduced for the original member.
6. Smooth limiter: scale factor known answers.
Writes out/t0_regression.json. Exit 0 only if every check passes.
"""
import json
import math
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
RI = HERE.parents[1]
sys.path.insert(0, str(HERE))
sys.path.insert(1, str(RI / 'revizyon_20261025' / 'bagimsiz'))
import ext_engine as X  # noqa: E402
import ext_common as C  # noqa: E402
import ind_engine as E  # noqa: E402

res = []


def check(name, cond, detail=''):
    res.append(dict(name=name, ok=bool(cond), detail=str(detail)))
    print(('PASS ' if cond else 'FAIL ') + name, detail, flush=True)


sealed = {m['id']: m for m in json.load(open(RI / 'cdl1/out/HDL2b_20261021_a/sonuc.json', encoding='utf-8'))['members']}
rec = sealed['S3_P0.65_G0.20']
G = np.array([0.0, rec['G_R']])
layE = E.Layout(E.two_bus_system())
layX = X.Layout(X.two_bus_system())
dE = E.dispatch(layE, [rec['P_akt']], G)
dX = X.dispatch(layX, [rec['P_akt']], G)
check('dispatch identical', np.array_equal(dE['x'], dX['x']) and np.array_equal(dE['refs'], dX['refs']))
rng = np.random.default_rng(1)
xr = dE['x'] + 1e-3 * rng.standard_normal(layE.n)
check('rhs identical at a perturbed state', np.array_equal(E.rhs(layE, xr, dE['refs'], G), X.rhs(layX, xr, dE['refs'], G)))
JE, JX = E.jac(layE, dE['x'], dE['refs'], G), X.jac(layX, dX['x'], dX['refs'], G)
check('Jacobian identical', np.array_equal(JE, JX))
th = float(np.arctan2(dE['x'][layE.ix['V1:I']], dE['x'][layE.ix['V1:R']]))
fE, fX = E.frozen_margin(layE, JE, th, G[1]), X.frozen_margin(layX, JX, th, G[1])
check('frozen margin identical', fE['rho'] == fX['rho'] and fE['omega'] == fX['omega'])
kE, kX = E.kappa_hat(layE, dE['x'], dE['refs'], G, th, fE), X.kappa_hat(layX, dX['x'], dX['refs'], G, th, fX)
check('kappa identical', kE['kappa'] == kX['kappa'])

# 2. sealed F2 values through ext_common.stage1 (strict gate: the F2 members are inside K1 by construction)
for mid in ('S3_P0.55_G0.34', 'S3_P0.65_G0.20', 'S3_P0.70_G0.29'):
    m = sealed[mid]
    lay, Gm, P = C.build_F2(m['P_akt'], m['G_R'])
    r = C.stage1(lay, Gm, P, strict=True)
    ok = (r.get('excl') is None and abs(r['dGf'] - m['dGf']) <= 1e-8 * m['dGf']
          and abs(r['omega'] - m['omega_star']) <= 1e-8 * m['omega_star']
          and abs(r['kappa'] - m['kappa']['k_tam']) <= 1e-6 * abs(m['kappa']['k_tam']))
    check(f'stage1 reproduces sealed {mid}', ok, f"excl={r.get('excl')} k={r.get('kappa')} vs {m['kappa']['k_tam']}")
    if mid == 'S3_P0.65_G0.20':
        kL = m['kappa'].get('k_L')
        check('ideal-CPL decomposition reproduces sealed kappa_L', kL is not None and abs(r['kappa_L'] - kL) <= 1e-3 * abs(kL),
              f"{r['kappa_L']} vs {kL}")

# PSV Stage-1 values
st1 = {q['id']: q for q in json.load(open(RI / 'revizyon_20261025/psv/out/PSV_20261025_a/stage1.json', encoding='utf-8'))}
for pid in ('A126', 'B202'):
    q = st1[pid]
    lay, Gq, P = C.BUILDERS['psv' + q['system']](q)
    r = C.stage1(lay, Gq, P, strict=False)
    ok = r.get('excl') is None and abs(r['kappa'] - q['kappa']) <= 1e-9 * max(1, abs(q['kappa'])) and abs(r['dGf'] - q['dGf']) <= 1e-12
    check(f'stage1 reproduces PSV {pid}', ok, f"{r.get('kappa')} vs {q['kappa']}")

# 3. limiter with huge Imax
for kind in ('gfm', 'cpl'):
    lim = dict(Imax=1e3, p=20.0, kaw=1000.0)
    lay, Gm, P = C.build_F2(0.65, 0.20, ilim=lim if kind == 'gfm' else None, cpl_ilim=lim if kind == 'cpl' else None)
    r = C.stage1(lay, Gm, P)
    m = sealed['S3_P0.65_G0.20']
    check(f'{kind} limiter Imax=1e3 leaves results unchanged',
          abs(r['dGf'] - m['dGf']) <= 1e-9 * m['dGf'] and abs(r['kappa'] - m['kappa']['k_tam']) <= 1e-7,
          f"dGf {r['dGf']} kappa {r['kappa']}")

# 4. reactive power
lay = X.Layout(X.two_bus_system())
lay.sysd['cpls'][0]['Q_set'] = 0.1
d = X.dispatch(lay, [0.65], G, tol=1e-12)
x = d['x']
Vr, Vi, Ir, Ii = x[lay.ix['V1:R']], x[lay.ix['V1:I']], x[lay.ix['C0:Irf']], x[lay.ix['C0:Iif']]
check('Q_set honoured', d['ok'] and abs((Vi * Ir - Vr * Ii) - 0.1) < 1e-10 and abs((Vr * Ir + Vi * Ii) - 0.65) < 1e-10)

# 6. limiter scale known answers
s1 = X._soft_scale(3.0, 4.0, 5.0, 2.0)
check('soft scale at |i| = Imax, p = 2', abs(s1 - 2 ** -0.5) < 1e-15)
s2 = X._soft_scale(0.6, 0.0, 1.0, 1000.0)
check('soft scale ~1 well below the limit (p = 1000)', abs(s2 - 1.0) < 1e-12)
s3 = X._soft_scale(2.0, 0.0, 1.0, 1000.0)
check('soft scale ~Imax/|i| above the limit (p = 1000)', abs(2.0 * s3 - 1.0) < 1e-3)

ok = all(r['ok'] for r in res)
(HERE.parent / 'out').mkdir(exist_ok=True)
(HERE.parent / 'out' / 't0_regression.json').write_text(json.dumps(dict(ok=ok, checks=res), indent=1), encoding='utf-8')
print('T0', 'PASS' if ok else 'FAIL', f"{sum(r['ok'] for r in res)}/{len(res)}")
sys.exit(0 if ok else 1)
