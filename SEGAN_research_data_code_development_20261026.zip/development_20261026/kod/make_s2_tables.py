﻿"""Generate the result tables of S2 Appendix F (pandoc pipe tables) from the output files; nothing is typed in.
Writes ms/s2_appF_results.txt. Sources: out/p2_prevalence.csv, p2_mechanism.csv, p2_rank_corr.csv, p2_oat_flips.csv,
p5_summary_scenarios.csv, p5_summary.json, tsv/TSV_a/analysis/*.csv and results.json, p12_cost.csv."""
import csv
import json
import math
import os
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = Path(os.environ.get('G91_OUT', str(HERE.parent / 'out')))
A = OUT / 'tsv' / 'TSV_a' / 'analysis'
DST = HERE.parent / 'ms' / 's2_appF_results.txt'


def rd(p):
    return list(csv.DictReader(open(p, encoding='utf-8'))) if Path(p).exists() else []


def fm(x, nd=3):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return '--' if x in ('', None) else str(x)
    if not math.isfinite(v):
        return '--'
    if v != 0 and (abs(v) < 10 ** (-nd) or abs(v) >= 1e5):
        m, e = f'{v:.2e}'.split('e')
        return f'{m}×10^{int(e)}^'
    return f'{v:.{nd}f}'


def esc(s):
    return str(s).replace('|', '\\|')


def table(caption, head, rows, align=None):
    out = [caption, '', '| ' + ' | '.join(f'**{esc(h)}**' for h in head) + ' |',
           '|' + '|'.join(align or [':--'] + ['--:'] * (len(head) - 1)) + '|']
    for r in rows:
        out.append('| ' + ' | '.join(esc(c) for c in r) + ' |')
    return '\n'.join(out) + '\n'


parts = ['## F.9 Results: prevalence and mechanisms of the optimistic regime', '']
prev = rd(OUT / 'p2_prevalence.csv')
parts.append(table('**Table F.2.** Wide Sobol exploration (4096 points per family): Stage-1 gate outcomes and prevalence of $\\widehat{\\kappa}$ < 0 among the evaluable points.',
                   ['Family', 'G1', 'G2 voltage', 'G2 source', 'G3', 'G4', 'G5/G6', 'Evaluable', 'κ̂ < 0', 'κ̂ ≤ −0.05', '|κ̂| < 0.05', 'κ̂ 5–50–95%'],
                   [[r['family'], r.get('gate_G1') or 0, r.get('gate_G2-voltage') or 0, r.get('gate_G2-source') or 0, r.get('gate_G3') or 0,
                     r.get('gate_G4') or 0, int(r.get('gate_G6-newton') or 0) + int(r.get('gate_G5') or 0) + int(r.get('gate_G6') or 0),
                     r['n_evaluable'], r['n_kappa_neg'], r['n_kappa_lt_minus_tau'], r['n_abstain'],
                     f"{fm(r['kappa_q05'], 2)} / {fm(r['kappa_median'], 2)} / {fm(r['kappa_q95'], 2)}"] for r in prev]))
mech = rd(OUT / 'p2_mechanism.csv')
parts.append(table('**Table F.3.** Medians of the decomposition in the strata $\\widehat{\\kappa}$ \\< 0.05 and ≥ 0.05 (wide Sobol sets). $\\widehat{\\kappa}_{rest} = \\widehat{\\kappa} - {\\widehat{\\kappa}}_{L}$ contains the non-ideal CPL residual and the source term.',
                   ['Family', 'Stratum', 'n', 'κ̂_V', 'κ̂_θ', 'κ̂_rest', 'Re η̂', '−c Im η̂', 'c', 'ω* (rad/s)', 'Re π_d', '|π×|', 'anisotropy'],
                   [[r['family'], r['stratum'].replace('kappa', 'κ̂'), r['n'], fm(r.get('kappa_V_median')), fm(r.get('kappa_theta_median')),
                     fm(r.get('kappa_rest_median')), fm(r.get('eta_re_median')), fm(r.get('minus_c_Im_eta_median')), fm(r.get('c_median')),
                     fm(r.get('omega_median'), 0), fm(r.get('pi_d_re_median')), fm(r.get('pi_x_abs_median')), fm(r.get('aniso_median'))] for r in mech]))
rc = rd(OUT / 'p2_rank_corr.csv')
parts.append(table('**Table F.4.** Spearman rank correlation of each sampled parameter with $\\widehat{\\kappa}$ and its parts (wide Sobol sets, evaluable points).',
                   ['Family', 'Parameter', 'κ̂', 'κ̂_V', 'κ̂_θ', 'κ̂_rest', 'Re η̂', '−c Im η̂'],
                   [[r['family'], r['parameter'], fm(r['kappa'], 2), fm(r['kappa_V'], 2), fm(r['kappa_theta'], 2), fm(r['kappa_rest'], 2),
                     fm(r['Re_eta'], 2), fm(r['minus_c_Im_eta'], 2)] for r in rc]))
fl = [r for r in rd(OUT / 'p2_oat_flips.csv') if r['changes_sign'] == 'True' or r['crosses_minus_tau'] == 'True']
if fl:
    parts.append(table('**Table F.5.** One-at-a-time sweeps in which $\\widehat{\\kappa}$ changes sign (nine points over the sampling range; K1 limits and $\\Delta G_{f}^{*} \\leq G_{R}$ recorded as flags only).',
                       ['Family', 'Base point', 'Parameter', 'κ̂ min', 'at value', 'κ̂ max', 'at value', 'points with K1 flag'],
                       [[r['system'], r['base'].replace('min_kappa:', 'min κ̂: '), r['param'], fm(r['kappa_min']), fm(r['value_at_min']),
                         fm(r['kappa_max']), fm(r['value_at_max']), r['n_phys_flag']] for r in fl]))
sc = rd(OUT / 'p5_summary_scenarios.csv')
parts += ['## F.10 Results: current limiting', '']
parts.append(table('**Table F.6.** Current-limiting scenarios (six members of $\\mathcal{F}_{2}$; set-points of the unlimited dispatch). $u_{0}$: limiter utilisation at $x_{0}$; changes are maxima over the evaluated members relative to the unlimited model.',
                   ['Scenario', 'Evaluated', 'No equilibrium', 'Gate excl.', 'u₀ range', 'max Δ ΔG_f* (%)', 'max Δ κ̂ (%)', 'max Δ ΔG_t* (%)', 'κ̂ range', 'sign agreement', 'frozen optimistic'],
                   [[r['scenario'], r['evaluated'], r['no_equilibrium'], r['excluded'], f"{fm(r['u0_min'], 2)}–{fm(r['u0_max'], 2)}",
                     fm(100 * float(r['max_rel_change_dGf']), 2) if r['max_rel_change_dGf'] not in ('', 'nan') else '--',
                     fm(100 * float(r['max_rel_change_kappa']), 1) if r['max_rel_change_kappa'] not in ('', 'nan') else '--',
                     fm(100 * float(r['max_rel_change_dGt']), 2) if r['max_rel_change_dGt'] not in ('', 'nan') else '--',
                     f"{fm(r['kappa_min'])} to {fm(r['kappa_max'])}", f"{r['sign_agree']}/{r['evaluated']}", r['frozen_optimistic']] for r in sc]))
p5 = json.load(open(OUT / 'p5_summary.json', encoding='utf-8')) if (OUT / 'p5_summary.json').exists() else None
if p5:
    parts.append(table('**Table F.7.** Abrupt shedding of the member (0.65, 0.20) with and without current limiting (Radau, rtol $10^{-7}$, atol $10^{-9}$, maximum step 5 ms, 3 s; divergence: bus-voltage deviation above 1 pu).',
                       ['Scenario', 'Amount', 'ΔG (pu)', 'Outcome', 'peak GFM utilisation', 'peak CPL utilisation'],
                       [[r['scenario'], r['case'], fm(r['dG'], 4), r['outcome'], fm(r['u_gfm_peak'], 2), fm(r['u_cpl_peak'], 2)] for r in p5['large_signal']]))
res = json.load(open(A / 'results.json', encoding='utf-8')) if (A / 'results.json').exists() else None
if res:
    parts += ['## F.11 Results: two-sign validation (run TSV_a)', '']
    d = rd(A / 'directional.csv')
    parts.append(table('**Table F.8.** Directional results by scope (primary set: $|\\widehat{\\kappa}| \\geq 0.05$, no tie). Agreement = observed direction equal to the sign of $\\widehat{\\kappa}$.',
                       ['Scope', 'n', 'κ̂ < 0 (agree)', 'κ̂ > 0 (agree)', 'acc. R1', 'acc. majority', 'acc. R4', 'acc. R5', 'balanced acc.', 'MCC', 'p vs const.', 'p vs R4', 'verdict'],
                       [[r['scope'], r['n'], f"{r['n_kappa_minus']} ({r['agree_minus']})", f"{r['n_kappa_plus']} ({r['agree_plus']})",
                         fm(r['acc_R1']), fm(r['acc_const_plus']), fm(r['acc_R4']), fm(r['acc_R5']), fm(r['balanced_acc']), fm(r['mcc']),
                         fm(r['mcnemar_p_vs_const'], 4), fm(r['mcnemar_p_vs_R4'], 4), r['verdict'].split(' - ')[0].lower()] for r in d]))
    est = rd(A / 'estimators.csv')
    parts.append(table('**Table F.9.** Margin estimators by scope (uncensored, no fold). MAE interval: cluster-bootstrap BCa 95%.',
                       ['Scope', 'Estimator', 'extra eq.', 'n', 'MAE (pu)', 'MAE 95% CI', 'RMSE', 'median AE', 'IQR AE', 'max AE', 'mean |rel| (%)', 'p95 |rel| (%)', 'overshoots'],
                       [[r['set'], r['estimator'], r['extra_equilibria'], r['n'], fm(r['MAE'], 4), f"{fm(r['MAE_lo'], 4)}–{fm(r['MAE_hi'], 4)}",
                         fm(r['RMSE'], 4), fm(r['median_AE'], 4), fm(r['IQR_AE'], 4), fm(r['max_AE'], 4), fm(r['mean_rel_pct'], 2),
                         fm(r['p95_abs_rel_pct'], 1), f"{r['overshoot']}/{r['n']}"] for r in est]))
    env = rd(A / 'envelope.csv')
    parts.append(table('**Table F.10.** Spearman correlation of the absolute relative error with the validity indicators (pooled, with cluster-bootstrap BCa 95% interval, and within each family).',
                       ['Estimator', 'Indicator', 'n', 'ρ_S', '95% CI', 'A2', 'B2', 'C'],
                       [[r['estimator'], r['indicator'], r['n'], fm(r['spearman'], 2), f"{fm(r['ci_lo'], 2)} to {fm(r['ci_hi'], 2)}",
                         fm(r['spearman_A2'], 2), fm(r['spearman_B2'], 2), fm(r['spearman_C'], 2)] for r in env]))
    bands = rd(A / 'envelope_bands.csv')
    parts.append(table('**Table F.11.** Error quantiles (absolute relative error, %) in bands of the indicators.',
                       ['Indicator', 'band', 'n', 'frozen median', 'first median', 'first p90', 'first max', 'second median', 'second p90', 'second max', 'secant-1 median'],
                       [[r['indicator'], f"[{fm(r['lo'], 2)}, {fm(r['hi'], 2)})", r['n'], fm(r.get('frozen_median_pct'), 1), fm(r.get('first_order_median_pct'), 2),
                         fm(r.get('first_order_p90_pct'), 2), fm(r.get('first_order_max_pct'), 1), fm(r.get('second_order_median_pct'), 2),
                         fm(r.get('second_order_p90_pct'), 2), fm(r.get('second_order_max_pct'), 1), fm(r.get('secant_1_median_pct'), 2)] for r in bands]))
    fails = [r for r in rd(A / 'failures.csv') if r['tag'] != 'abstain_band' or
             (r['ref_sign'] not in ('0', '0.0') and (float(r['kappa']) > 0) != (float(r['ref_sign']) > 0))]
    for r in fails:
        if r['tag'] == 'abstain_band':
            r['tag'] = 'abstention band, sign wrong'
    parts.append(table('**Table F.12.** Failure cases (tags as the protocol, Section 6 S4).',
                       ['Tag', 'Point', 'κ̂', 'Re η̂', 'obs. sign', 'ΔG_f*', 'ΔG_t*', 'rel. err. 1st (%)', 'rel. err. 2nd (%)', 'ε₂', 'gap', 'log₁₀ cond', 'ΔG_f*/G_R', 'κ̂_rest', 'status'],
                       [[r['tag'], r['id'], fm(r['kappa']), fm(r['kappa_noc']), r['ref_sign'], fm(r['dGf'], 4), fm(r['dGref'], 4),
                         fm(100 * float(r['relerr_first']), 1) if r['relerr_first'] not in ('', 'nan') else '--',
                         fm(100 * float(r['relerr_second']), 1) if r['relerr_second'] not in ('', 'nan') else '--',
                         fm(r['eps2']), fm(r['gap_rel']), fm(r['log10_cond_J'], 1), fm(r['dGf_over_GR'], 2), fm(r['kappa_rest']),
                         r['status']] for r in fails]))
cost = rd(OUT / 'p12_cost.csv')
if cost:
    parts += ['## F.12 Results: computational cost', '']
    parts.append(table('**Table F.13.** Cost per point and estimator (from scratch, one warm-up, median of five repetitions; environment in p12_environment.json).',
                       ['Family', 'Point', 'states', 'Estimator', 'equilibria', 'Jacobians', 'full scans', 'state eig.', 'wall median (s)', 'wall min–max (s)'],
                       [[r['family'], r['id'], r['n_states_reduced'], r['estimator'], r['equilibrium_solves'], r['jacobians'], r['full_scans'], r['state_eig'],
                         fm(r['wall_median'], 3), f"{fm(r['wall_min'], 3)}–{fm(r['wall_max'], 3)}"] for r in cost]))
DST.write_text('\n'.join(parts), encoding='utf-8')
print('wrote', DST, len(parts))
