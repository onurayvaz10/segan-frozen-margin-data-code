"""Phase 2c: one-at-a-time sensitivity curves of kappa and its parts around fixed base points (predictor only).

For each base point every parameter of its family is swept over its sampling range on 9 points (log or linear, as
the family), the others held at the base value. Three sensitivity-only parameters are added: CPL reactive power
ratio q = Q/P in [-0.3, 0.3] (the theory assumes q = 0, condition C1), CPL DC-link capacitance scale cdc in
[0.25, 2] and GFM current-loop gain scale s_cc_gfm in [0.5, 2]. Base points are chosen by rule after the Sobol
exploration (out/p2_explore_*.jsonl): the family centre (author data where they exist) and the evaluable point with
the smallest kappa of each family. Writes out/p2_oat.csv.
"""
import csv
import json
import os
import math
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
OUT = Path(os.environ.get('G91_OUT', str(HERE.parent / 'out')))
sys.path.insert(0, str(HERE))
import ext_common as C  # noqa: E402
from p2_explore import SPACES  # noqa: E402

EXTRA = [('q', -0.3, 0.3, False), ('cdc', 0.25, 2.0, True), ('s_cc_gfm', 0.5, 2.0, True)]
CENTRE = {
    'A2': dict(Kiv=600.0, s_pll=1.0, s_cc=1.0, lv=0.2, rv=0.0, s_v=1.0, s_line=1.0, rx=0.1, kq=0.05, Rp=0.02,
               P_set=0.65, G_R=0.20),
    'B2': dict(P1=0.2, P2=0.35, G2=0.05, G_R=0.20, s_l1=1.0, s_l2=1.0, rx=0.1, Kiv1=600.0, Kiv2=600.0, s_pll1=1.0,
               s_pll2=1.0, lv=0.2),
    'C': dict(P1=0.15, P2=0.15, P3=0.35, G1=0.05, G3=0.05, G_R=0.20, z_trunk=0.04, rx_trunk=0.5, z_loop=0.05, rx=1.0,
              f23=1.0, f34=1.0, f14=1.0, Kiv1=600.0, Kiv2=600.0, Kiv3=600.0, s_pll1=1.0, s_pll2=1.0, s_pll3=1.0, lv=0.2),
}
KEYS = ['excl', 'phys_gate', 'g4_bound', 'kappa', 'kappa_V', 'kappa_theta', 'kappa_L', 'kappa_rest', 'eta_re', 'eta_im', 'c', 'omega', 'dGf',
        'xi_d', 'xi_q', 'pi_d_re', 'pi_x_abs', 'aniso', 'm_cpl_max', 'Vmin']


def grid(lo, hi, lg, n=9):
    return list(np.exp(np.linspace(math.log(lo), math.log(hi), n))) if lg else list(np.linspace(lo, hi, n))


def bases():
    out = []
    for s in ('A2', 'B2', 'C'):
        out.append((s, 'centre', dict(CENTRE[s])))
        p = OUT / f'p2_explore_{s}.jsonl'
        if p.exists():
            ev = [json.loads(l) for l in open(p, encoding='utf-8')]
            ev = [r for r in ev if r.get('excl') is None]
            if ev:
                r = min(ev, key=lambda r: r['kappa'])
                out.append((s, 'min_kappa:' + r['id'], {k: r[k] for k, *_ in SPACES[s]}))
    return out


def main():
    rows = []
    for s, label, base in bases():
        for nm, lo, hi, lg in SPACES[s] + EXTRA:
            for v in grid(lo, hi, lg):
                sp = dict(base)
                sp[nm] = float(v)
                lay, G, P = C.BUILDERS[s](sp)
                try:
                    r = C.stage1(lay, G, P, rec={}, strict=True, mapping=True)
                except Exception as exc:  # noqa: BLE001
                    r = dict(excl='error:' + type(exc).__name__)
                row = dict(system=s, base=label, param=nm, value=float(v), base_value=base.get(nm))
                row.update({k: r.get(k) for k in KEYS})
                rows.append(row)
            C.plog(f'oat {s} {label} {nm}', OUT / 'progress.txt')
    with open(OUT / 'p2_oat.csv', 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


if __name__ == '__main__':
    C.lower_priority()
    main()
