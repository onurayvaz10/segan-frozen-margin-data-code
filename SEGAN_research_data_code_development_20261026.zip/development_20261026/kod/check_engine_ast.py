"""Compare two versions of a Python module with docstrings removed (abstract syntax trees). Exit 0 if identical.
Usage: python -I check_engine_ast.py OLD.py NEW.py"""
import ast
import sys


def tree(path):
    t = ast.parse(open(path, encoding='utf-8').read())
    for node in ast.walk(t):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.ClassDef, ast.AsyncFunctionDef)) and node.body:
            first = node.body[0]
            if isinstance(first, ast.Expr) and isinstance(getattr(first, 'value', None), ast.Constant) \
                    and isinstance(first.value.value, str):
                node.body = node.body[1:]
    return ast.dump(t, include_attributes=False)


same = tree(sys.argv[1]) == tree(sys.argv[2])
print('executable code identical (docstrings excluded):', same)
sys.exit(0 if same else 1)
