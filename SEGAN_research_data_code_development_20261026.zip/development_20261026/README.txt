development_20261026 - addition to Supplementary Material S1 (development round of 26 October 2026)

Contents
  kod/       extended engine (ext_engine.py; bit-identical to bagimsiz/ind_engine.py with all extensions off,
             except the documented Newton acceptance at the round-off floor), common definitions (ext_common.py),
             all computation, analysis, figure and document scripts
  protokol/  TSV_PROTOKOL_v1.txt (two-sign validation protocol) and TSV_yetki_TSV_a.json (SHA-256 pins of
             protocol, engine, common module, run and analysis scripts and selection, written before the run)
  out/       predictor-stage records (p2_explore_*.jsonl wide Sobol, p2_focus_*.jsonl focused Sobol,
             p3_boundary_*.jsonl search, p3b_box_*.json boxes), tsv/selection.json, the sealed run
             tsv/TSV_a/ (stage2.jsonl, log, environment, SHA256SUMS) and its analysis, the current-limiting study
             (p5_*), F2 baselines (p7_*), cost benchmark (p12_*), PSV operating-limit audit (p1_*), regression tests
             (t0_regression.json); superseded files are kept with suffixes *.superseded_newton,
             *.discarded_incomplete_seeds, *.bak_* (see protocol section 6a)
  figures/   PNG figures (600 dpi)

Order of execution (python >= 3.12 with numpy, scipy, matplotlib; set G91_OUT to an output folder)
  python -I kod/t0_regression.py
  python -I kod/p1_audit.py
  python -I kod/p2_explore.py A2 B2 C
  python -I kod/p2_redo_newton.py          (only needed for records made before the Newton correction)
  python -I kod/p2_summary.py
  python -I kod/p3b_focused.py A2 B2 C
  python -I kod/p3_boundary.py A2 B2 C
  python -I kod/p4_stage2.py --select ; kod/p4_authorize.py ; python -I kod/p4_stage2.py --run TSV_a
  python -I kod/p4_analysis.py TSV_a ; python -I kod/tsv_numbers.py
  python -I kod/p5_current_limit.py ; python -I kod/p5_summary.py
  python -I kod/p7_f2_baselines.py ; python -I kod/p12_cost.py
  python -I kod/make_new_figures.py ; python -I kod/make_s2_tables.py
The single run TSV_a refuses to run again once finished; its outputs are sealed by SHA256SUMS.
All computations are deterministic (fixed seeds, one BLAS thread). Timings are machine dependent; on the
benchmark machine the processes were pinned to the efficiency cores.
