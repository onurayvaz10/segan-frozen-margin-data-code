# VH95-RA B5(b) sonuç raporu — son yeniden deneme (2026-11-07)

## 1. Mühür (VERIFIED)
- Çıktı: `C:\Users\onura\Documents\SEGAN_G94_work\vh94\out\VH95RA_20261107_b`; exit_code 0.
- SHA256SUMS sha256 `22a04e1a25ae35ebfe56dc181ea4d4d021689ebf4248ee3516bc0c0650b32d86`; 8 kalemin hepsi yeniden hesaplandı ve eşleşti.
- sonuc.json sha256 `002517567efea759187fd327220929c3f474ce5f2b4f8ecc010ac6a5cdaaf5c0`.
- Koşu kaydı: `rapor/VH95RA_B4b_kosu_kaydi.md`.
- SABİT v1.2 c6f7cbdb…22f0. Betik v2 615854e5…dfbb, koşu sonrasında değişmedi. Koşu bir kez yapıldı.
- Bütünlük: X-0, X-1 ve X-2 geçti. X-3 geçti: 10 dolgusuz koşu, VH95 çıktısını kanonik JSON'da tam eşit üretti. X-4 geçti: 14 dolgulu koşuda t_b ve kapılar eşit. `integrity_errors` boş.
- Kestirici çağrısı: dolgusuz 20, dolgulu 27.

## 2. Hüküm
`VH95-RA hüküm: KISMİ (satır 5) [keşif niteliğinde]`

### Ön-kayıt sapması (SABİT v1.2 başlığı, aynen tekrar)
Bu sonuç, v1.0'dan sapan tek yeniden denemeden gelmektedir.
- v1.0 §9, nedenin "ortam ya da uygulama" düzeyinde giderilmesini öngörüyordu. Buradaki neden SABİT'in kendi metniydi: X-0'daki tür şartı.
- v1.0 §1, kuralları değişmez kılıyordu. Bu denemede §5.1 madde 0 ve §7'nin bir cümlesi değiştirildi.
- Sapma bilerek, kullanıcı kararıyla (D-274) ve yalnız X-0 tür pini için yapıldı.

## 3. Karar tablosunun harfiyen uygulanması (VERIFIED, sonuc.json `cases`)

Vaka sonuçları:

| Vaka | Sınıf (s_pred) | D | u_D | Eşik | Etiket |
|---|---|---|---|---|---|
| A2-F00993 | iyimser (−1) | −23.13 | 6.01 | 18.02 | AGREE |
| A2-F01921 | iyimser (−1) | — | — | — | NE (F_m@0p05 `ne = q2`; pad 1, P-1 geçti) |
| A2-F00357 | iyimser (−1) | −10.61 | 2.13 | 6.39 | AGREE |
| A2-F00138 | tutucu (+1) | +2.195 | 5.38 | 16.15 | UNDETERMINED |
| F2-0.65-0.20 | tutucu (+1) | +4.545 | 0.407 | 1.22 | AGREE |
| F2-0.60-0.20 | tutucu (+1) | +10.49 | 5.70 | 17.10 | UNDETERMINED |

Satırlar sırayla:
- **Satır 1:** ABORT nedeni yok.
- **Satır 2:** değerlendirilebilir vaka 5 ≥ 4, iyimser 2 ≥ 2, tutucu 3 ≥ 2 → geçildi.
- **Satır 3:** DISAGREE yok → geçildi.
- **Satır 4:** AGREE sayısı 3 ≥ 3. AGREE vakaları arasında iyimser var (F00993, F00357) ve tutucu var (F2-0.65-0.20) → geçildi.
- **Satır 5:** iki UNDETERMINED var (A2-F00138, F2-0.60-0.20) → **KISMİ**.

Hüküm → statü (SABİT §2): "Düzeltilmiş, ön-kayıtlı, keşif amaçlı yeniden analizde tutarlı." Bu hüküm **kabul ettirici değildir**.

## 4. Körleme ağırlığı (SABİT §3 tablo B ile; INFERENCE)

AGREE veren üç vakanın körlük durumu:
- **A2-F00993:** etiketi önceden sabitti (X-3).
- **A2-F00357:** D önceden biliniyordu (≈ −10.61); DISAGREE olanaksızdı.
- **F2-0.65-0.20:** yalnız R_m@0p05 görülmüştü (+0.155). D'nin öteki üç bileşeni körlenmişti.

**Satır 4'ün geçilmesi, yani KISMİ ile BELİRSİZ arasındaki fark, yalnız F2-0.65-0.20'nin AGREE'sine dayanır.** Bu vaka AGREE vermeseydi, AGREE vakaları arasında tutucu kalmazdı ve hüküm BELİRSİZ olurdu. Gerçekten körlenmiş kanıt ağırlığı bu bir vakadadır.

Tam kör tek vaka A2-F00138'dir. Sonucu UNDETERMINED: D işareti öngörüyle aynı yönde (+), ama büyüklüğü eşiğin çok altında (2.2 < 16.1).

F2-0.60-0.20'de D önceden biliniyordu; belirleyici olan u_D oldu.

## 5. Ön-kayıtlı olmayan gözlemler (post-hoc; hüküm dışı)
- G-1: Raporlanan bütün σ̂_m25 değerlerinde işaret, d-tahminiyle aynıdır (`report.*.sign_agree`). Büyüklük oranı 0.06–1.44 aralığında değişir; tutucu R_m tarafındaki σ̂ değerleri sıfıra yakındır.
- G-2: A2-F01921, P-1 nedeniyle değil kestiricinin kalite koşulu (q2) nedeniyle NE oldu. Bu kayıt dolgusu ayıklanmış bir kayıttır (pad 1). P-1'in, bu kaydın NE olmasında doğrudan payı olup olmadığı bu analizden çıkarılamaz.
- G-3: VH95'te 5 vaka NE iken RA'da 4 vaka değerlendirilebilir hâle geldi. Dolgu düzeltmesi değerlendirilebilirlik sorununu büyük ölçüde gideriyor.

## 6. Kanıt düzeyi
- Tavan E4'tür (Typhoon Virtual HIL kayıtları üzerinde ofline yeniden analiz). Fiziksel HIL iddiası yoktur.
- Sonuç keşif niteliğindedir. Doğrulayıcı (onaylayıcı) kanıt değildir.

## 7. Sonuçlar
- **Argüman haritası:** H1 için "keşif amaçlı yeniden analizde KISMİ tutarlılık" eklenebilir. İddia dili "VH95 kayıtlarının ön-kayıtlı yeniden analizi H1 ile çelişmedi; körlenmiş kanıt tek vakaya dayanıyor" biçimini aşmamalıdır.
- **Risk kaydı:** veri biçimi varsayımlarından kaynaklanan iki ön-kayıt hatası oldu (D2 N-1, D-273). Gelecek ön-kayıtlarda tür ve biçim şartları önce yalnız başlık okunarak doğrulanmalıdır (`on-kayit` kontrol listesine aday madde).
- **VH96:** karar SABİT gereği bu sonuçtan bağımsızdır ve kullanıcınındır.

PROCEED: kullanıcı kararı. Seçenekler:
- **(a)** VH96 doğrulayıcı koşu ön-kaydı: yakalama hizası düzeltilir ve P-1 sabit kural olarak baştan pinlenir.
- **(b)** Mevcut kanıtla makale ve ek güncellemesi: RA, keşif amaçlı ek olarak raporlanır.
- **(c)** İkisi birden.
