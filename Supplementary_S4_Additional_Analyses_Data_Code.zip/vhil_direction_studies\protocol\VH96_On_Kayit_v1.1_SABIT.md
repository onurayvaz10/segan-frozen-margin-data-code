# VH96 — Taze ve kör A2 vakalarında eşleşik yön testi (H1) ve sınır parantezi (H2), Typhoon Virtual HIL · Ön-kayıt v1.1 SABİT

2026-11-07 · Yazar: Claude Code (Opus 5.5), ana oturum.

**Kaynak sürüm ve denetimler**

| Belge | sha256 | Hüküm |
|---|---|---|
| TASLAK v0.1 | e4b84d032b987b7c4f9356236d9cc3f010d15f02a55f373ab16258f789fdc848 | — |
| TASLAK v0.2 | 103b70bf5b4ce049fa40e0548550d790312904f46379027dbae5674c43066eb6 | — |
| TASLAK v0.3 (bu belgenin kaynağı) | 2ee46ba9c8eadd82d6e42ad8679f1d52f305b63052cf20f79a03189eba40d9f9 | — |
| D1 `denetim/VH96_On_Kayit_denetimi_D1.md` | 7dba5137c8b55607190fbebf18a67e2c99ebb8dcd3681b13c8c82cd0ef616819 | REVISE, R-1…R-13 |
| D2 `…_D2.md` | eda39ad745f59d2b7d4db9380a0b6a5200beea71baec859c37e14a01c7903e53 | ACCEPT_FOR_FIXATION, M-1…M-17 |
| D3 `…_D3.md` | 18f9bb38d7d7e8d181b4b9630afbf100ae96027e7b545511ed9d20596c74a00b | ACCEPT_FOR_FIXATION, M3-1…M3-17; revizyon turu 3/3 |

- **v1.1:** v1.0 (`VH96_On_Kayit_v1.0_SABIT.md`, sha256 068a5c2012196bc10331f5d3b5dba80fddf452581a3d1ac90678f83ca8815674; değiştirilmeden saklanır) fark denetiminden UYUMSUZ aldı (`denetim/VH96_SABIT_fark_denetimi.md`, sha256 b2c970dc9cc9e6ce85b564d33747132a8437dea73e3bb152d0bf4ebb0d81b3d0). v1.1, FD-1…FD-13'ü işler: v0.3'te olup taşınırken düşen kurallar geri kondu, yanlış atıflar düzeltildi. Yeni kural, eşik ya da sayı yoktur. Eşleme §11'in sonundadır.
- Bu belge v0.3'ten yalnız M-1…M-17 ve M3-1…M3-17 ile ayrılır. Bütün maddeler gövdeye işlendi; çelişen eski cümleler silindi (M3-16). Eşleme §11'dedir.
- Pilottan önce bu belge ile v0.3 arasında bağımsız bir fark denetimi yapılır (D3, "çözülmemiş engeller").

**Dayanak**
- Kullanıcı kararı "VH96 ön-kaydı" (2026-11-07; D-275 seçenek a).
- Kullanıcı kararı "Evet, önerilen yol" (2026-11-07; D-276). Bu karar D1 R-3 ve R-5 kullanıcıya bildirildikten sonra verildi.
- Kullanıcı talimatı (2026-11-07): "notlar.docx dosyasında karşılanmayan maddeler varsa onları da karşılamamız gerekmektedir". Danışman notları N-3 ve N-15 (`notlar_maddeleri_v1.md`) H2 ve modülasyon payının dayanağıdır.

## 1. Statü
**SABİT.** Belge yürütme yetkisi vermez.

**Sıra:**
1. Fark denetimi: SABİT ile v0.3 karşılaştırılır.
2. Tasarım betikleri yazılır ve denetlenir (§9.1).
3. Tasarım adımı **bir kez** koşar: seçim, pilot, H1 ve H2 güç kapıları, kalibrasyon (en az bir kapı geçerse), kapıların yeniden uygulanması, modülasyon payı, plan dosyası.
4. Kapısı geçen her hipotez için `tek-kosu-kapisi` B1–B5 uygulanır. B4 ayrı oturumda koşar ve kullanıcı onayı gerektirir.
5. İki kapı da geçmezse Typhoon koşusu yapılmaz. Hat KULLANICI_BEKLIYOR olur.

**D-275 (a) metninden sapmalar (D1 R-5; kullanıcıya bildirildi, onaylandı):**
- (i) Yakalama kodunun sıfır dolgu davranışı düzeltilmez. Sondaki sıfır dolgu P-1 analiz kuralıyla ayıklanır.
- (ii) Vakalar yenilenir.

**Kapsam değişikliği (N-15):** D-265 (2026-10-29), VH94'ün R_lo/R_hi koşularını "gelecek çalışma"ya bırakmıştı. Kullanıcının 2026-11-07 talimatı bu kararı H2 için yeniden açar.

## 2. Sorular, kapsam, kanıt tavanı

**H1 (birincil yön testi).** VH94 SABİT v1.3'ün H1 yön testi altı yeni A2 vakasında uygulanır. Bu vakalar VH94/VH95'te koşulmamıştır ve Typhoon çıktıları görülmemiştir. Kestirici, eşik ve karar tablosu VH94 v1.3'tekilerle aynıdır. Soru: H1 hangi hükmü verir?

**H2 (sınır parantezi; N-15).** Kurulum şöyledir: modülasyon payı artırılmıştır (§5.5) ve başlangıçta kararlıdır (§5.4). Bu kurulumda gerçek kesme (R), ΔG*_t,d'nin (1 − k) katında kararlı, (1 + k) katında kararsız mıdır? k vaka başına önceden yazılı kuralla seçilir (§5.6).

**Neden taze vakalar.**
- Birincil gerekçe körlemedir. VH95-RA'da altı vakanın üçünün etiketi önceden sabitti ya da DISAGREE'ye kapalıydı. Körlenmiş kanıt tek vakadaydı (`rapor/VH95RA_sonuc_raporu_B5b.md` §4).
- İkincil gerekçe (INFERENCE, VH94 SABİT v1.3 R3-5): VHIL belirlenimcidir. VH95-RA'nın X-3 sınaması aynı kayıtların yeniden analizidir; bu iddiayı doğrudan sınamaz.

| Sınama ögesi | Dayanak | VH96'da |
|---|---|---|
| H1: D, u_run, u_D, eşik = max(3·u_D, 0.2), H1 etiketleri | VH94 SABİT v1.3 §5–§7 ve §12–§15 değişiklikleri | Aynen |
| Kapılar, pencere, kestirici, q1–q3 (q3 bant içi n₀: VH94 v1.3 §14 madde 1, `analyze_vh94.noise_floor`) | VH94 v1.3 §5.5–§5.8, §14 | P-1'den sonra uygulanır |
| H1 karar tablosu | VH94 v1.3 §8 | Satır 1'e X-0 eklenir (§8.1) |
| P-1 ve X-0 tür pini | VH95-RA SABİT v1.2 §5.1, §14 V-1 | Baştan pinlenir |
| Vakalar | G94 plan §2a | Yeni seçim kuralı ve sapmaları (§5.1) |
| Kampanya yürütme (WHEA bekçisi, ledger, S-b sürdürme) | VH94 v1.3 §1 S-b, §8, §9, R3-9, R3-10 | `vh96_` kopyaları ve iki kampanya (§9.2) |
| Güç kapıları | — | Yeni (§7) |
| H2, modülasyon payı | — | Yeni (§5.4–§5.6, §8.2) |

**Göstermez.**
- B2 ve C sistemleri: bağımsız EMT modeli yalnız A2 ve F2'yi destekliyor (`calibrate_vh94.py`:30–31). F2 ailesi de yok.
- Anahtarlamalı modelin kararlılık bölgesinin tamamı. H2 yalnız seçilmiş vakalarda, vaka başına tek bir k parantezinde sınırın konumunu sınar.
- Vakalar arası istatistiksel genelleme. Tutucu vakalar güce göre zenginleştirilmiş bir seçimle alınmıştır. Sonuç tutucu A2 ailesine genellenmez (M-3).
- Fiziksel HIL ve gerçek zaman.
- Bağımsız ekip ya da model ailesi (iç tekrar).
- **N-3 yalnız kısmen karşılanır.** Bu çalışma değerlendirilebilir bir anahtarlamalı model doğrulamasıdır (E4, Typhoon Virtual HIL). Fiziksel CHIL/PHIL (E6) değildir (M3-17).

**Kanıt tavanı: E4.**

**H1 statüsü**

| Hüküm | Statü |
|---|---|
| TUTARLI | "Taze, kör, ön-kayıtlı altı Typhoon vakasının değerlendirilebilir olanlarının hepsinde H1 ile tutarlı." Kabul ettirici değildir. |
| KISMİ | "Taze, kör vakalarda H1 ile çelişki yok. En az üç AGREE var, iki sınıfı da kapsıyor. En az bir vaka ayrışmadı." |
| RET | "Satır 2 geçildikten sonra en az bir vakada DISAGREE çıktı. H1 bu kapsamda çürütüldü." |
| BELİRSİZ | "Değerlendirilebilirlik sağlandı, ayrım yetmedi." |
| NOT_EVALUABLE | "Yeni bilgi yoktur." Yerine vaka konmaz; karar kullanıcınındır. |
| GÜÇ_YETERSİZ / ABORT / ABORT_TASARIM | "Hüküm yoktur." Yerine vaka konmaz. |

H2 statüsü §8.2'dedir. **H1 ve H2 hükümleri birleştirilerek ortak bir iddia kurulmaz. H2, H1'in kanıt ağırlığını artırmaz** (M3-9).

## 3. Körleme (K-1; yazar beyanı, doğrulanabilirliği LOW CONFIDENCE)

| Öge | Durum |
|---|---|
| Aday vakaların TSV değerleri (`dGf`, `dGref`, `kappa`, `eps2`, `m_gfm`, `m_cpl_max`) ve P93 alanları (`primary.ids`, `sample.ids`, `report_only.b_yon_degisimi.ids`) | **Görüldü.** Seçimin kaynağıdır. |
| Aday vakaların pilot öngörüleri, kuru koşu, kalibrasyon | **Hesaplanmadı.** Tasarım adımında hesaplanır. Güç kapıları, tutucu seçimi ve k seçimi bunlara bakar. Bunlar Typhoon çıktısı değildir. |
| Aday vakaların Typhoon kayıtları | **Yok.** D2, dokuz kimlik ve "vh96" için 4261 dosya ve klasör adını taradı: 0 eşleşme. D3'te de 0 (VERIFIED). |
| VH95-RA aile örüntüleri: tutucu R_m σ̂ sıfıra yakın; iyimser σ̂/σ_pred 0.38–1.26; bütün işaretler öngörüyle aynı | **Kısmen sızmış.** Kaynak: VH95-RA_b `sonuc.json` (sha256 002517567efea759187fd327220929c3f474ce5f2b4f8ecc010ac6a5cdaaf5c0), `cases.*.report`. |
| VH95-RA belirsizlik ölçeği: A2'de u_D 2.13–6.01, eşik 6.39–18.02 s⁻¹; F2-0.65-0.20'de u_D 0.41. Tutucu R koşularında 25 ns ile 50 ns farkı 5.4–5.7 s⁻¹ | **Kısmen sızmış.** Aynı kaynak: `cases.*.u_D`, `threshold`, `runs.*.sigma`. G, G2 ve tutucu havuzu buna bakılarak seçildi. |
| VH94 pilotunun `pred_d.lo/hi.sigma_R` değerleri: k = 0.05'te iyimser A2 ≈ ∓6.4–6.9, tutucu A2-F00138 ≈ ∓1.5 s⁻¹ | **Görüldü** (M3-11). k kümesi ve G2 seçilirken. |
| VH94 v1.3 kuru koşusu: R_lo/R_hi dahil \|σ̂ − σ_pred\| ≤ 0.043 s⁻¹ (VH94 v1.3 §5.5, satır 168; v1.0–v1.3'te aynı metin) | **Görüldü** (M3-12). |

- Hükmün kanıt ağırlığı altı vakanın hepsindedir. Hiçbir vakanın etiketi önceden sabit değildir.
- Seçim, güç kapıları ve k seçimi Typhoon sonucuna bakmaz. Ancak görülmüş VH95-RA ölçeklerine ve pilot öngörülerine dayanır. |D_pred,d|'ye göre tutucu seçimi, VH95-RA'nın işaret örüntüsü ve u_D ölçeği görülmüşken verilmiş bir karardır (M-3).

## 4. Pinler (tam yol, bayt, SHA256)

### 4a. Dayanak belgeler ve veriler

| Dosya | Bayt | SHA256 |
|---|---|---|
| `C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme94_20261029\protokol\VH94_On_Kayit_v1.3_SABIT.md` | 40367 | ae8628bd9f05aeafb0a95f0b6d001fe64efe90c53cef2001facc26d1856b999d |
| `C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme94_20261029\protokol\VH95RA_On_Kayit_v1.2_SABIT.md` | 36906 | c6f7cbdb790fa5c89da01fdc8a2a9b80b8e893f38665b2964245b6e7c81e22f0 |
| `C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme94_20261029\rapor\VH95RA_sonuc_raporu_B5b.md` | 5196 | 5068a5c1da8f4257ca2fe72a710410974b96d98b7549607ee6495bd95edbbf6b |
| `C:\Users\onura\Documents\SEGAN_G94_work\vh94\out\VH95RA_20261107_b\sonuc.json` | 85136 | 002517567efea759187fd327220929c3f474ce5f2b4f8ecc010ac6a5cdaaf5c0 |
| `C:\Users\onura\Documents\SEGAN_G94_work\vh94\out\VH95_20261106_a\campaign_ledger.jsonl` | 10175 | a1040553d1ede402ffa041e162951bd968b97d44bb1e0f8d70a428d90d2760cf |
| `C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme94_20261029\G94_PLAN_v1.md` | 8873 | 832fc51325eea48168fc117c48e76107c5f8a9bc04ebbeeeb7cc753926836e77 |
| `C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme92_20261026\girdi\development_20261026\out\tsv\TSV_a\analysis\points.csv` | 2111107 | 6a099961188a4cdf51865fbc0e370c2c9ce5a8e961e55a8a7e23e01dcbb844e7 |
| `C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme92_20261026\girdi\development_20261026\out\tsv\selection.json` | 2635991 | 2d5a00d86497b174277d238293e08129f901627da99844552dcfcc397d981b53 |
| `C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme92_20261026\out\P93_20261026_a\sonuc.json` | 9622 | 4c9acafa7a0807b26280649dd6ad65f08c76da885bcfbf6f553f78fec3235325 |
| `C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme94_20261029\notlar_maddeleri_v1.md` (N-3, N-15 dayanağı) | 3452 | 3b678a10bbde2b9d6d4b38d5257452c18d3f5fba42ace3b87f269b1427d260bc |

### 4b. VH94 kaynak kodu (asıllar değişmez)
- `C:\Users\onura\Documents\SEGAN_G94_work\vh94\vh94_run.py`: 24801 bayt, sha256 ed11d0082c785cdca0db70a4dc992e45c8e007d974e5745a2878b30f725cfe0f.
- PINS tablosu satır 38–95, 56 kalem; pin_list_sha256 6aa30db8ffd3bc6326e53b9c685cc7ac91014ebdca9a2c03041982d7985b05dd. D1 ve D2 56 kalemin hepsini diskte doğruladı (D2: 56/56). D3 bu tablonun yalnız atıflarını denetledi.
- Typhoon ve analiz tarafındaki kalemler:

| Dosya | Bayt | SHA256 |
|---|---|---|
| `C:\Users\onura\Documents\SEGAN_G94_work\vh94\segan_typhoon_vh94\controller_code_vh94.py` | 12035 | 342efb717bc27a6dec25bb1886545f56c5dadfa87d436ee1c8a3377ddc6bd534 |
| `C:\Users\onura\Documents\SEGAN_G94_work\vh94\segan_typhoon_vh94\build_plant_vh94.py` | 10999 | ebe0d209adecefa978a4ca9694b997a26d5d1f1ed36581c28d73337af26f5f8c |
| `C:\Users\onura\Documents\SEGAN_G94_work\vh94\segan_typhoon_vh94\audit_model_vh94.py` | 4513 | c877288ede2e0df64c7bede7d50bb4807703c4a5554c2731a87b75360ec97d79 |
| `C:\Users\onura\Documents\SEGAN_G94_work\vh94\segan_typhoon_vh94\audit_compiled_timing_vh94.py` | 2655 | 4716bb31c193deb874e0d739f4edad084c62dd394fb203053aebaf08d5f51c0a |
| `C:\Users\onura\Documents\SEGAN_G94_work\vh94\segan_typhoon_vh94\run_vh94.py` | 7887 | 50e3bb41034224203f007d3957ccc48ce2f8b87b1444303eb451c3ed89c863a3 |
| `C:\Users\onura\Documents\SEGAN_G94_work\vh94\segan_typhoon_vh94\run_guarded_vh94.ps1` | 3910 | 77af37437a9ff0fb79959ddfdd43d98f1b82d16d1eb48a7356a7b083fd5041ef |
| `C:\Users\onura\Documents\SEGAN_G94_work\vh94\segan_typhoon_vh94\run_campaign_vh94.ps1` | 7113 | 499f7f05218de5d7b28a38922b6d73f066c7abac0d7fb42fb516b03bb301f351 |
| `C:\Users\onura\Documents\SEGAN_G94_work\vh94\segan_typhoon_vh94\controller_src\controller_math.c` | 3075 | 43c9eb5d4d357eba9c9d43171f839c6a36dc422f6e1850bb30035b2679f86732 |
| `C:\Users\onura\Documents\SEGAN_G94_work\vh94\segan_typhoon_vh94\controller_src\controller_math.h` | 647 | 9ea2fff2387661f0996472e88473bfbfee137f0df7f408eb5805abefd0f8120b |
| `C:\Users\onura\Documents\SEGAN_G94_work\vh94\independent_emt\calibrate_vh94.py` | 4545 | 958bde216aa612eeb17a67e99e9904d1403ad86310d3c4ad6056e1ae9d1ba579 |
| `C:\Users\onura\Documents\SEGAN_G94_work\vh94\independent_emt\model.py` | 6895 | 04678aba0b243bac49856dbfff3c8c4e993da9ba0d9780b8e1bfed85f72a0441 |
| `C:\Users\onura\Documents\SEGAN_G94_work\vh94\analyze_vh94.py` | 11408 | a8df777e5b83a03af2ac112dbeb809db019eaa28c1c0a56846c86251f1fd0d68 |
| `C:\Users\onura\Documents\SEGAN_G94_work\vh94\vh94_avg_dryrun.py` | 7482 | 8a1db891bd0ec5be91628fa78f86524ff177dcc7d555c0e80d01458a170c48b2 |
| `C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme94_20261029\kod\vh94_pilot.py` (v3) | 12128 | 68b80156bd7c9e3d26f559b6e4fe230d3082e2f129f6b48e051de7eb698dc3f6 |
| `C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme92_20261026\kod\ext_engine.py` | 28393 | 22feea1836b7e3b475e86efc0c3660eb742f83cd224444a2317ff001bd58489e |
| `C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme92_20261026\kod\ext_common.py` | 21468 | b11b55cd58665944e7371aece67dd2dea147bdae7156cc75190b8668544e811a |
| `C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme92_20261026\kod\ext_engine_d.py` | 30767 | 780c4d95a6748a137fd6ba0045603dda025c001b4d073bd3553fe62a76851cea |
| `C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme92_20261026\kod\ext_common_d.py` | 21470 | 98747eef15690f25b882850a04e77f53c22bbb21375fa7750b1a0c08242da727 |
| `C:\Users\onura\Documents\SEGAN_G94_work\vh94\vh95ra_run.py` (v2; P-1 ve X-0 uygulamasının kaynağı) | 32169 | 615854e508e98ab5e2fabd83fdb01c432fc6e18dfcb66cc569726baa5b45dfbb |

### 4c. VH96 PINS (M-15, M3-1, M3-6)
VH96 koşusunun yetkili listesi VH96 PINS tablosudur. B1'de yazılır, B3'te doğrulanır. İçeriği:
- §4a ve §4b'nin bütün kalemleri;
- dört tasarım betiği: `vh96_select.py`, `vh96_pilot.py`, `vh96_tasarim.py`, `vh96_headroom.py` (§9.1);
- `vh96_` önekli kopyalar (§9.2);
- tasarım adımının çıktıları: `vh96_tasarim.json`, `vh96_pilot.json`, `vh96_plan.json`, kuru koşu, `SHA256SUMS`;
- özgün ve değiştirilmiş kalibrasyonlar (`calibration_<vaka>.orig.json`, `calibration_<vaka>.json`).

Kopyalanan Typhoon betikleri ve değiştirilmiş kalibrasyonlar VH94 PINS'teki baytlarla aynı olamaz. Bu istisna yalnız §9.2 ve §5.5'teki izinli farklarla sınırlıdır. VH94 PINS bu tablonun kaynağıdır.

**Ortam.**
- Typhoon HIL Control Center 2026.3 (gömülü Python 3.11.4 / NumPy 2.2.3).
- Analiz Python 3.13.2 / NumPy 2.5.3.
- OMP, OPENBLAS, MKL ve NUMEXPR iş parçacığı değişkenleri tanımsız (VH95-RA B3 v2 N-4; `denetim/VH95RA_kod_denetimi_B3_v2.md` sha256 2ea5eb1a8556698fcdb877bc5ce4b5f05fc63bc81bfcff27c3398e4c1aff29cf).
- `SEGAN_SOURCE_CODE_DIR` tanımsız.

## 5. Tanımlar

### 5.1 Vaka seçimi
**Alanlar ve formül.**
- `points.csv`: `id`, `system`, `kappa`, `dGf`, `dGref`, `eps2`.
- P93 `sonuc.json`: `primary.ids`, `sample.ids`, `report_only.b_yon_degisimi.ids`.
- Göreli hata g = (`dGf` − `dGref`)/`dGref`. `rel_err` sütunu kullanılmaz.
- Sınıf: `kappa` < 0 iyimser, `kappa` > 0 tutucu.
- Eşitlik bozma: kimlik dizgesinin sözlük sırası, küçük olan önce.

**İyimser A2 (3; pilottan önce sabit).**
- Küme: `primary.ids` ∩ `system` = A2 ∩ `kappa` < 0. VH94 vakaları (A2-F00993, A2-F01921, A2-F00357) çıkarılır.
- Sıralama: g, büyükten küçüğe.
- Küme tam üç elemanlıdır ve tükenir: **A2-F01557** (κ −0.117; g 0.088), **A2-F00805** (κ −0.073; 0.067), **A2-F01169** (κ −0.067; 0.054).

**Tutucu A2 (3; havuzdan pilotla seçilir).**
- Havuz: `primary.ids` ∩ `system` = A2 ∩ `kappa` > 0 ∩ `eps2` < 0.5 ∩ `dGf` ≥ 0.03. A2-F00138 çıkarılır.
- Havuz altı noktadır:

| Vaka | g | ε₂ | ΔG*_f |
|---|---|---|---|
| A2-F00067 | −0.134 | 0.032 | 0.0409 |
| A2-F00555 | −0.147 | 0.061 | 0.0540 |
| A2-02149 | −0.073 | 0.037 | 0.0847 |
| A2-S01157 | −0.071 | 0.040 | 0.1023 |
| A2-F01579 | −0.173 | 0.058 | 0.0532 |
| A2-03094 | −0.367 | 0.486 | 0.0540 |

- **Seçim:** pilotta uygun olan havuz noktaları arasından |D_pred,d|'si en büyük üç nokta. "Uygun" şu demektir: `status = ok`, sonlu `D_pred_d`, sign κ_d = sign κ_TSV.
  - Eşitlikte önce |g|'nin 0.12'ye uzaklığı küçük olan, sonra sözlük sırası.
  - Uygun nokta üçten azsa uygun olanların hepsi alınır.

**Sapma beyanı (R-1, M-16).**
- (a) G94 plan §2a'nın iyimser kuralı harfiyen uygulansaydı A2-F00241'i seçerdi. `primary.ids` şartı onu dışarıda bırakır, çünkü nokta P93'te gecikmeyle yön değiştirir (`report_only.b_yon_degisimi.ids`). §2a'daki "P93'te gecikmeyle kararlı kalan" niteliği bu şartla mekanik olarak okunur. Bu bir yorumdur ve sapma olarak beyan edilir.
- (b) Tutucu kural v0.1'deki "0.12'ye en yakın" kuralından "havuzda |D_pred,d| en büyük" kuralına geçti. Neden: D1 R-3, güç.
- (c) Şu yapısal kararlar VH95-RA sonucundan sonra verildi: yalnız A2, 3+3, F2 yok, P93 `primary.ids` filtresi (iki tarafta), tutucu havuzu, güç kapıları, H2 ve modülasyon payı. Gerekçeleri:
  - "yalnız A2" ve "F2 yok": `calibrate_vh94.py`'nin destek sınırı;
  - "3+3": iyimser kümenin tükenmesi;
  - havuz, güç kapıları ve |D_pred,d|'ye göre tutucu seçimi: VH95-RA'nın görülmüş u_D ölçeği ve işaret örüntüsü (M-3);
  - H2 ve modülasyon payı: N-15.

**Pilot alanları (M-2).**
- Kullanılan alanlar: `cases[i].status`, `cases[i].kappa_d`, `cases[i].D_pred_d`, `cases[i].sigma0_d`, `cases[i].amounts.*`, `cases[i].pred_d.<anahtar>.*`.
- `rotate_alt` ve `nd_*` alanları seçimde ve kapıda kullanılmaz.
- Sonlu olmayan `D_pred_d` ya da `sigma_R` değeri vakayı NE yapar. sign κ_d ≠ sign κ_TSV de vakayı NE yapar.
- Kalibrasyon kabulü (`calibrate_vh94.py`'nin kendi ölçütü) başarısız olursa vaka NE olur; tolerans değişmez.
- Yerine vaka konmaz.

**Yeniden üretim (M-11).**
- `vh96_select.py` tasarım adımının ilk işidir. Ürettiği listeler bu bölümdeki iyimser listeyle ve tutucu havuzuyla birebir karşılaştırılır.
- B1, `vh96_select.py`'yi yeniden koşar ve sonucu `vh96_tasarim.json` ile karşılaştırır.
- Tasarım adımında ya da B1'de fark çıkarsa sonuç ABORT_TASARIM olur.

### 5.2 Analiz ön-işlemesi
- **X-0:** npz başlığından, değer okumadan: `time_s` float64, `values` float32. Başka tür ya da ortam sürümü uyuşmazlığı ABORT verir.
- **P-1:** VH95-RA SABİT v1.2 §5.1 madde 1–4 aynen (PAD_MAX 100, zaman toleransı 10⁻⁶ s). P-1'i geçmeyen koşu NE olur.
- **Eski kampanya karşılaştırması yok** (X-3/X-4 yok).
  - P-1 yükleyicisinin dolgusuz kayıtta pinli yükleyiciyle özdeşliği S-1'de sınanır.
  - VH96 analizcisinin VH95 kayıtlarını VH95-RA_b ile aynı işlediği S-8'de sınanır.
- Bunlar dışında VH94 v1.3 §5–§7 ve §12–§15 geçerlidir.

### 5.3 Varsayımlar (INFERENCE)
- A1: Yeni iyimser vakaların g değerleri VH94'tekilerden küçüktür (0.054–0.088'e karşı 0.093–0.144). |D_pred,d| değerlerinin de daha küçük olması beklenir.
- A2: Yeni A2 vakaları aynı kurucu ve denetleyiciyle kurulur. Değişen yalnız kalibrasyon girdisi ve `gfm_dc`'dir (§5.5).
- A3: VH95-RA'daki A2 u_D değerleri 2.1–6.0 s⁻¹ idi. Yeni A2 vakalarında da bu ölçek beklenir. Bu varsayım güç kapılarının dayanağıdır.

### 5.4 Başlangıçta kararlı (M3-10)
- (a) Pilotta `cases[i].sigma0_d` < 0 olmalıdır: x0'da gecikmeli modelin spektral apsisi negatiftir. Bu şart `status = ok` için zaten gereklidir (`vh94_pilot.py`:136–140) ve H1 ile H2 kapılarında açıkça sayılır. `pred_d.zero` yalnız rapor alanıdır.
- (b) Typhoon'da her koşu, VH94 koşu kapılarını [0, t_b] aralığında geçmelidir: sonlu değerler, kilit, geri alma yok, modülasyon, DC, enerji (`analyze_vh94.py`:181–202).
- Ayrı bir Typhoon ön-kesme kararlılık kapısı eklenmez; bu bir sınırlılıktır.

### 5.5 Modülasyon payı (bütün VH96 koşuları; N-15)
**Gözlem (VERIFIED).**
- TSV `m_gfm` = |V_c|/V_dc,GFM'dir; bu sinüs tanımıdır (`ext_common.py`:197). VH94/VH95 vakalarında ve aday havuzda değerler 0.917–0.962'dir. Yani TSV tanımında pay %4–8'dir.
- Typhoon kapısındaki `mg` ise min–maks sıfır-dizisi eklemesinden sonraki tepedir (`controller_code_vh94.py`:93–104; `analyze_vh94.py`:192–194). Kapı şartı tepe ≤ 1.0'dır.
- Dengeli kararlı durumda mg ≈ (√3/2)·m_gfm'dir. Buna göre 690 V'ta Typhoon kararlı-durum tepesi ≈ 0.79–0.83 beklenir (INFERENCE).
- VH94 kalibrasyonlarında `settings.gfm_dc` = 1.1119394 pu = 690 V / VDC_BASE'tir. VDC_BASE = √(8/3)·380 V = 620.537 V (`build_plant_vh94.py`:29). VERIFIED (sayısal).

**Değişiklik.**
- VH96 kalibrasyonlarında `settings.gfm_dc` = 800/VDC_BASE = 1.2892051 pu olur. Beklenen Typhoon kararlı-durum tepesi ≈ 0.68–0.72'dir (INFERENCE).
- Gerekçe kararlı-durum payı değildir. Gerekçe, kesme sonrası geçici durumdaki ve R_hi büyüme penceresindeki paydır.
- Her koşunun [0.20, 0.30) s aralığındaki tepe `mg` ve `mc` değeri yalnız rapor olarak verilir.

**Öngörü modelinin değişmediği.**
- VERIFIED (kod): `gfm_dc` ortalama-model motorlarında (`ext_engine*.py`, `ext_common*.py`) dinamiğe girmez. `ext_engine.py`:65 ve `ext_engine_d.py`:74'te `Vdc=690.0` parametresi tanımlıdır ama okunmaz. `ext_common*.py`:54, 197 ve 288'de yalnız `m_gfm` raporunda geçer.
- VERIFIED (kod): Typhoon tarafında `gfm_dc` yalnız şu yerlerde kullanılır:
  - ideal DC gerilim kaynağı (`build_plant_vh94.py`:98–99);
  - denetleyicinin modülasyon normalizasyonu (`controller_code_vh94.py`:93, `cfg[5]`);
  - kaynak değeri denetimi (`audit_model_vh94.py`:22);
  - güç çıktısı (`controller_math.c`:52) → `balance_pu_s` ve `supplied_energy_pu_s` → enerji koşu kapısı (`analyze_vh94.py`:196–201).
- VERIFIED (kod): Denetleyici dinamiği (`controller_math.c`:8–40) `SG_GFM_DC`'yi kullanmaz. `independent_emt/model.py`'de `gfm_dc` yalnız varsayılan değer olarak geçer (satır 34); `rhs` kullanmaz.
- INFERENCE: İdeal kaynak ve aynı normalizasyon altında ortalama çıkış gerilimi değişmez. Anahtarlama dalgalanması DC gerilimle büyür; bu, karar bandının (30–300 Hz) dışında bir etkidir. Doğrulanmamıştır; sınırlılık olarak yazılır.

**Uygulama (M3-6).**
- `vh96_headroom.py` kalibrasyondan ve kapıların yeniden uygulanmasından sonra koşar.
- Özgün `calibration_<vaka>.json`, `calibration_<vaka>.orig.json` adıyla bayt düzeyinde aynen saklanır. Değiştirilmiş dosya, `build_plant`'in okuduğu yoldadır (`build_plant_vh94.py`:30; kopyada aynı satır).
- Değişen tek alan `settings.gfm_dc`'dir. Değeri tam olarak 800/(√(8/3)·380)'dir. Betik her vaka için eski ve yeni değeri ve iki dosyanın hash'ini `vh96_headroom.json`'a kaydeder.
- Kalibrasyon kabulü `gfm_dc`'ye bağlı değildir (`calibrate_vh94.py`:65–89; `model.py` `rhs`). Bu yüzden değişiklik kabulü geçersiz kılmaz (VERIFIED, kod).
- İki dosya da VH96 PINS'tedir.

**CPL doğrultucu tarafı.** `m_cpl_max` 0.81–0.88'dir. Doğrultucunun DC gerilimi CPL dinamiğinin bir durumudur; değiştirilmez.

**Karşılaştırılabilirlik.** VH96 kurulumu VH94/VH95'ten bu yönüyle farklıdır. VH95-RA ile karşılaştırma yalnız aile düzeyinde yapılır.

### 5.6 H2 tasarımı
**Vakalar.** H2 vakaları, H1 için §5.1'de seçilen altı vakadır. Tutucu havuzun seçilmeyen noktaları H2'ye girmez. H2'nin güç kapısı ayrıdır (§7).

**Parantez seçimi (pilottan önce sabit).**
- k ∈ {0.05, 0.10, 0.20}, küçükten büyüğe denenir. ΔG_in = (1 − k)·ΔG*_t,d, ΔG_out = (1 + k)·ΔG*_t,d.
- Vaka başına seçilen k: σ_R,d(in) ≤ −G2 **ve** σ_R,d(out) ≥ +G2 koşulunu sağlayan en küçük k. G2 = 6.4 s⁻¹.
  - G2'nin dayanağı: M-4'e benzetme (INFERENCE). H1 eşiği D farkı içindir, H2 eşiği tek koşu içindir (M3-11).
- Hiçbir k sağlamazsa vaka H2 için GÜÇSÜZ olur ve H2'de NE sayılır.
- Pilot alanları:
  - k = 0.05: `amounts.lo/hi`, `pred_d.lo/hi`.
  - k = 0.10 ve 0.20: `vh96_pilot.py` aynı fonksiyonla `amounts.lo10/hi10/lo20/hi20` ve `pred_d.lo10/hi10/lo20/hi20` alanlarını ekler.

**Plan dosyası (M3-3).**
- Typhoon plan dosyası `vh96_plan.json`'dur. Onu `vh96_tasarim.py` üretir. `vh96_pilot.json` değiştirilmez.
- Plan yalnız seçilen vakaları taşır.
- H2'ye uygun vakada seçilen k için yeniden yazılan alanlar: `amounts.lo/hi` ve `pred_d.lo/hi`'nin **bütün** alt alanları (`sigma_R`, `f_R`, `sr_R`, `sa_R`, …; `analyze_vh94.py`:217–218 bunları okur).
- Özgün değerler `amounts.lo05/hi05` ve `pred_d.lo05/hi05` alanlarına taşınır. Seçilen k `h2_k` alanına yazılır.
- GÜÇSÜZ vakada lo/hi değişmez ve H2 koşusu planlanmaz.
- Kuru koşu bu dosyayla yapılır.

**Koşular.** Her H2 vakası için R_lo ve R_hi, 25 ns ve 50 ns: 4 koşu. En çok 24 koşu.

**Kestirim.** VH94 v1.3 §5.5–§5.8 aynen uygulanır, P-1 sonrası dizilerde.
- u_run = max(|σ̂₂₅ − σ̂₅₀|, |σ̂ − σ̂'|).
- thr = max(3·u_run, 0.2).
- Koşu etiketi: KARARLI ⟺ σ̂₂₅ < −thr; KARARSIZ ⟺ σ̂₂₅ > +thr; aksi BELİRSİZ_K.

**Vaka etiketi (sırayla, ilk eşleşen; M3-8).**
1. Vaka GÜÇSÜZ ise ya da dört koşudan biri NE ise → NE.
2. in KARARSIZ ya da out KARARLI → ÇELİŞKİ.
3. in KARARLI ve out KARARSIZ → PARANTEZ.
4. Aksi → BELİRSİZ_V.

**Mühendislik okuması (yalnız rapor; hükme girmez).** İyimser vakalarda H1'in R_m miktarı ΔG*_t,d ile ΔG*_f,d arasındadır. Bu miktarı donmuş kural kabul eder. R_m σ̂ değeri, "donmuş kuralın kabul ettiği miktar anahtarlamalı modelde kararsız mı" sorusunun yanıtı olarak raporlanır (N-15).

## 6. Sınamalar
- **H1:** VH94 v1.3 §6 aynen, P-1 sonrası.
- **H2:** §5.6, §8.2.
- **Yalnız rapor:**
  - R-1…R-7 (VH94 v1.3 §6);
  - P-1 dolgu dağılımı;
  - güç kapısı tabloları;
  - seçilmeyen havuz noktalarının pilot değerleri (M-3);
  - kuru koşu;
  - tepe `mg`/`mc`;
  - R_m mühendislik okuması;
  - VH95-RA ile aile düzeyi karşılaştırma.

## 7. Eşikler, güç kapıları, değerlendirilebilirlik
- H1 eşikleri VH94 v1.3 §7'den aynen alınır: 0.2 s⁻¹, 3·u_D, R² ≥ 0.5, 10·n₀. H2 eşikleri §5.6'dadır. Hiçbiri sonradan değişmez.

**G = 6.4 s⁻¹ (M-4).**
- VH95-RA_b `sonuc.json` alanı `cases.*.threshold`'a göre A2 vakalarının en küçük eşiği 6.391 s⁻¹'dir (A2-F00357, u_D 2.130).
- Bu değer etiketlere bakılmadan bulunmuş ve yukarı yuvarlanmıştır.
- G, G2, havuz, k kümesi ve kapı ölçütleri SABİT'ten sonra değişmez.

**H1 güç kapısı.**
- Şart: NE olmayan, `sigma0_d` < 0 olan seçilmiş vakalardan en az 2 iyimser **ve** en az 2 tutucu vakada |D_pred,d| ≥ G.
- Geçerse H1 kampanyası planlanır. Geçmezse **GÜÇ_YETERSİZ (H1)**.

**H2 güç kapısı.**
- Şart: seçilmiş altı vaka arasında GÜÇSÜZ ve NE olmayan, `sigma0_d` < 0 olan vaka sayısı ≥ 4; içinde en az 1 iyimser ve en az 1 tutucu.
- Geçerse H2 kampanyası planlanır. Geçmezse **GÜÇ_YETERSİZ (H2)**.

**Yeniden uygulama (M-5).** Kalibrasyon, H1 ya da H2 kapısından en az biri geçerse yapılır. Kalibrasyon NE'leri düşüldükten sonra iki kapı da yeniden uygulanır. Sonuç değişirse yeni sonuç geçerlidir.

**GÜÇ_YETERSİZ kuralları (M-6, M3-14).**
- GÜÇ_YETERSİZ, ilgili hipotez için VH96'nın son durumudur. Vaka eklenmez.
- Havuz, G, G2, k kümesi ve kapı ölçütleri değişmez.
- Ardıl çalışma, yeni D-ID'li ayrı bir ön-kayıttır. Bu ön-kayıt VH96 adını ve §2/§8.2 statü cümlelerini taşımaz. Pilot değerlerini "görüldü" diye beyan eder.
- Kapanış `dal-kapanisi` ile kaydedilir.
- "Yalnız iyimser" bir test ancak ayrı ve daha dar bir iddia olarak ön-kayda girer. TUTARLI ya da KISMİ veremez.
- İki kapı da geçmezse Typhoon koşusu yapılmaz ve karar kullanıcınındır.

**Çatallanma beyanı.**
- G, G2, k kümesi, 800 V ve tutucu havuzu şunlar görüldükten sonra seçildi: VH95-RA sonucu, TSV modülasyon değerleri ve VH94 pilotunun lo/hi öngörüleri (§3).
- Hepsi pilottan ve Typhoon'dan önce seçildi.
- Kapılar yalnız Typhoon koşusunun yapılıp yapılmayacağını belirler. Hüküm eşiklerine dokunmaz.

**Değerlendirilebilirlik ve risk.**
- H1: tutucu A2 havuzunda G'yi aşan nokta çıkmayabilir. VH94'ün tutucu A2 vakası A2-F00138'de D_pred +3.33 idi. Bu durumda GÜÇ_YETERSİZ (H1) verilir (INFERENCE).
- H2: VH94 pilotunda k = 0.05'te tutucu A2-F00138 ≈ ∓1.5 s⁻¹ idi. Bu ölçekle tutucu vakalar k = 0.20'de bile GÜÇSÜZ kalabilir ve H2 kapısı sınıf şartından düşebilir (INFERENCE).
- Tutucu R koşularında VH95-RA'da u_run büyüktü: 25 ns ile 50 ns farkı 5.4–5.7 s⁻¹. Sınıra yakın tutucu vakalarda BELİRSİZ_K olasılığı bu yüzden yüksektir.
- k büyüdükçe ayrım kolaylaşır, ama "sınıra yakın" iddiası zayıflar. Seçilen k vaka başına raporlanır.
- VH95-RA'da 6 vakadan 1'i NE çıktı (q2). Yedek aile yoktur. NOT_EVALUABLE durumunda karar kullanıcınındır. Kapıyı geçen bir tasarımda bile BELİRSİZ olası bir sonuçtur; bu, B4 onayı istenirken kullanıcıya yazılır.

## 8. Karar tabloları (ilk eşleşen satır hükmü verir)

### 8.1 H1

| # | Koşul | H1 hükmü |
|---|---|---|
| 1 | H1 kampanyasında bütünlük hatası. Hata türleri: pin ya da hash uyuşmazlığı; mühürsüz çıktı; protokol dışı senaryo; ledger'daki WHEA durdurmasından sonra yapılmış koşu; `_basarisiz_` kaydı; `vh96_run.py` CASES listesinin `vh96_tasarim.json`'dan farklı olması; X-0 (tür ya da ortam); betik istisnası | ABORT |
| 2 | Değerlendirilebilir vaka < 4; ya da değerlendirilebilir iyimser < 2; ya da tutucu < 2 | NOT_EVALUABLE |
| 3 | En az bir DISAGREE | RET |
| 4 | AGREE < 3; ya da AGREE vakaları arasında iyimser yok; ya da tutucu yok | BELİRSİZ |
| 5 | Satır 4 geçildi ve en az bir UNDETERMINED | KISMİ |
| 6 | Değerlendirilebilir vakaların hepsi AGREE | TUTARLI |

Satır 2–6 VH94 v1.3 §8 ile aynıdır. Hüküm metni: `VH96 H1 hüküm: … (satır n)`.

### 8.2 H2

| # | Koşul | H2 hükmü |
|---|---|---|
| 1 | H2 kampanyasında §8.1 satır 1'deki bütünlük nedenleri | ABORT |
| 2 | Değerlendirilebilir vaka < 4; ya da değerlendirilebilir iyimser < 1; ya da tutucu < 1 | NOT_EVALUABLE |
| 3 | En az bir ÇELİŞKİ | RET |
| 4 | PARANTEZ < 3 | BELİRSİZ |
| 5 | Satır 4 geçildi ve en az bir BELİRSİZ_V | KISMİ |
| 6 | Değerlendirilebilir vakaların hepsi PARANTEZ | TUTARLI |

Hüküm metni: `VH96 H2 hüküm: … (satır n)`.

**H2 statüsü (M3-9; "doğrulandı" sözcüğü kullanılmaz)**

| Hüküm | Statü |
|---|---|
| TUTARLI | "Seçilmiş taze vakaların değerlendirilebilir olanlarının hepsinde gerçek kesme sınırı, gecikmeli ortalama-model sınırının vaka başına seçilen k (≤ 0.20) parantezi içinde kaldı (E4, modülasyon payı artırılmış kurulum)." Kabul ettirici değildir. Sınıf başına PARANTEZ sayısı verilir. |
| KISMİ | "Sınır konumuyla çelişki yok; en az 3 PARANTEZ; en az bir vaka ayrışmadı." Sınıf başına sayılar verilir. |
| RET | "En az bir vakada sınırın konumu öngörüyle çelişti." |
| BELİRSİZ | "Değerlendirilebilirlik sağlandı, ayrım yetmedi." |
| NOT_EVALUABLE / GÜÇ_YETERSİZ / ABORT / ABORT_TASARIM | "Yeni bilgi yoktur ya da hüküm yoktur." |

### 8.3 Sonuç uzayı

| Öge | Olası sonuçlar | Etki |
|---|---|---|
| Seçim yeniden üretimi; tasarım betiği farkı | eşit, farklı | farklı → ABORT_TASARIM (Typhoon yok) |
| H1 ve H2 güç kapıları (yeniden uygulama dahil) | geçer, GÜÇ_YETERSİZ | GÜÇ_YETERSİZ → ilgili kampanya yok |
| Pilot ya da kalibrasyon (vaka başına) | ok, NE | NE → vaka NE |
| k seçimi (vaka başına) | 0.05, 0.10, 0.20, GÜÇSÜZ | GÜÇSÜZ → H2'de NE |
| X-0, bütünlük, HATA (kampanya başına) | geçer, başarısız | başarısız → o hipotezin satır 1'i |
| P-1 (koşu başına) | geçer, dolgu-yapı, dolgu-sınır, zaman-hiza | geçmeyen → koşu NE → vaka NE |
| WHEA durdurması | yok, var | var → kampanya biter, eksik koşular NE, tablo uygulanır. H1'de varsa H2 başlatılmaz (§9.2) |
| H1 etiketi | AGREE, DISAGREE, UNDETERMINED, NE | §8.1 satır 2–6 |
| H2 vaka etiketi | PARANTEZ, ÇELİŞKİ, BELİRSİZ_V, NE | §8.2 satır 2–6 |

Ön durumlar hüküm üretmez: ABORT_TASARIM, GÜÇ_YETERSİZ (hipotez başına), KAPI. Üçünde de ilgili Typhoon koşusu yapılmaz ya da analiz başlamaz.

## 9. Yürütme

### 9.1 Tasarım adımı (Typhoon yok; M3-13)
**Betikler** (`gelistirme94_20261029\kod\`): `vh96_select.py`, `vh96_pilot.py`, `vh96_tasarim.py`, `vh96_headroom.py`.

**Betik denetimi.**
- Betikler çalıştırılmadan önce, yazar olmayan ve B3'ü yapamayacak bir denetçi tarafından denetlenir.
- `vh96_pilot.py`, aşağıdaki izinli fark listesine göre `vh94_pilot.py` v3'e karşı denetlenir. Öteki üç betik §5.1, §5.5, §5.6 ve §7 kurallarına karşı kod denetiminden geçer.
- Dört betiğin sha256'sı `vh96_tasarim.json`'a yazılır. Bu dosya şunları da içerir: seçim, havuz pilotları (seçilmeyenler dahil), H1 ve H2 güç kapıları (iki uygulama), k seçimi, kalibrasyon sonuçları ve headroom kaydı.

**`vh96_pilot.py` izinli farkları (R-11, M-10):**
- (i) `CASES`: 3 iyimser + 6 tutucu havuz;
- (ii) çıktı adı `vh96_pilot.json`;
- (iii) belge dizesi ve `doc['script']` (`vh94_pilot.py`:246);
- (iv) k ∈ {0.10, 0.20} için `amounts` ve `pred_d` alanları; aynı fonksiyonla, yalnız çarpanları değişerek.

Başka bir fark ABORT_TASARIM verir. Pilot lo/hi alanlarını yeniden yazmaz.

**Sıra:**
1. `vh96_select.py` (§5.1).
2. `vh96_pilot.py` (9 nokta).
3. `vh96_tasarim.py`, birinci geçiş: tutucu seçimi, H1 ve H2 kapıları, k seçimi.
4. En az bir kapı geçtiyse seçilen altı vaka için `calibrate_vh94.py <vaka>` değiştirilmeden koşar.
5. `vh96_tasarim.py`, ikinci geçiş: kapılar yeniden uygulanır (M-5).
6. `vh96_headroom.py` (§5.5).
7. `vh96_tasarim.py`, üçüncü geçiş: `vh96_plan.json` üretilir (§5.6).
8. Kuru koşu (`vh94_avg_dryrun.py`, plan `vh96_plan.json`, gürültü kipi S6b; VH94 v1.3 §14 madde 2) yalnız rapor olarak yapılır.

**Kurallar.**
- Tasarım adımı bir kez koşar. Çıktıları `SHA256SUMS` ile mühürlenir.
- Pilot yalnız Python istisnası (`status='error'`) hâlinde, aynı kodla ve en çok bir kez yeniden koşulur. İki sürüm de saklanır.
- B3 izinsiz bir fark bulursa sonuç ABORT_TASARIM olur ve pilot yeniden koşulmaz.

### 9.2 Tek koşu (B1–B4; M3-1, M3-2)
**Kopyalar.** VH94 Typhoon ve analiz betikleri vaka listesini, plan hash'ini ve senaryoları sabit kodlar:
- `run_vh94.py`:19, 21;
- `build_plant_vh94.py`:15;
- `audit_model_vh94.py`:11;
- `audit_compiled_timing_vh94.py`:7;
- `run_guarded_vh94.ps1`:3;
- `run_campaign_vh94.ps1`:53–54;
- `analyze_vh94.py`:14–15;
- `vh94_run.py`:96–97.

VH96 bunların `vh96_` önekli kopyalarını kullanır; asıllar değiştirilmez.

**İzinli farklar:**
- (i) vaka listeleri (`CASES`, `ValidateSet`, `$cases`) = `vh96_tasarim.json` seçimi;
- (ii) `PLAN_SHA256` = `vh96_plan.json`'un sha256'sı;
- (iii) senaryo listeleri: H1 kampanyasında R_m, F_m; H2 kampanyasında R_lo, R_hi;
- (iv) belge dizeleri, dosya adı ve model adı önekleri;
- (v) P-1/X-0 aktarımı (`vh95ra_run.py` v2'den `p1_trim`, `load_capture_ra`, `preflight`); H2 etiket ve karar tablosu kodu; iki hükmün ayrı yazımı.

Her fark B3'te VH94 sürümüne karşı satır düzeyinde listelenir. İzinsiz fark B3'te REVISE verir ve koşu başlamaz. `vh96_run.py` CASES listesi `vh96_tasarim.json`'dan farklıysa §8.1 satır 1 uygulanır.

**İki kampanya.**
- H1: `C:\Users\onura\Documents\SEGAN_G94_work\vh94\out\VH96_<tarih>_a` (R_m, F_m; 24 koşu).
- H2: `C:\Users\onura\Documents\SEGAN_G94_work\vh94\out\VH96H2_<tarih>_a` (R_lo, R_hi; en çok 24 koşu).
- Her kampanyanın ledger'ı, `SHA256SUMS`'u ve analiz çıktısı ayrıdır.
- H2 kampanyası, H1 kampanyası mühürlendikten sonra başlar. H1 kapısı geçmediyse doğrudan başlar.
- §8.1 satır 1'in koşu ve kampanya düzeyindeki nedenleri her hipoteze yalnız kendi kampanyasının kayıtları üzerinden uygulanır.
- Ortak girdilerdeki pin ya da hash uyuşmazlığı (SABİT, VH96 PINS, kalibrasyonlar, `vh96_plan.json`) iki hipotezi de ABORT eder.
- H1 kampanyasında WHEA durdurması olursa H2 kampanyası başlatılmaz. Karar kullanıcınındır (yeni D-ID).
- Bir hipotezin ABORT'u, GÜÇ_YETERSİZ'i ya da hükmü ötekini değiştirmez.

**Diğer.**
- Typhoon yürütmesi VH94 v1.3 §9, R3-9 ve R3-10 ile aynıdır: tek ağır süreç, WHEA bekçisi.
- Çıktı klasörleri betiğe aittir. Çıktılar: `sonuc.json`, `hukum.txt`, `p1_dolgu.json`, `girdi_pinleri.json`, stdout, stderr, exit_code, `SHA256SUMS`.
- Süre: H1 24 koşu; VH95'te 24 koşu yaklaşık 3 saat 14 dakika sürdü (ledger 16:50:11–20:04:30, §4a). H2 de en çok 24 koşudur.

### 9.3 Yeniden deneme
- **WHEA ya da donanım:** VH94 v1.3 §1 S-b ve §8 aynen. Kampanya biter, eksik koşular NE olur, tablo uygulanır. Yeniden kampanya yoktur.
- **Çökme (M-8):** S-b uygulanır. Aynı run_id ve yetkiyle, aynı klasörde kalan koşulardan devam edilir.
  - `run_start` sayacı sıfırlanmaz; ledger'daki `run_start` satırlarından sayılır.
  - Koşu başına en çok 2 deneme yapılır. Başarısız deneme `_basarisiz_` klasörüne gider.
  - Derleme hatası vakayı NE yapar; kampanya diğer vakalarla sürer (VH94 v1.3 R3-9).
- **Analiz ABORT'u (M-7):** kaynak VH95-RA SABİT v1.2 §9'dur. En çok bir yeniden deneme yapılır. Şartların hepsi gerekir:
  - (i) hiçbir koşuda kestirici çağrılmamış olmalı. Bunu, kestiriciden önce stdout'a yazılan koşu kimlikli `kestirici-başlıyor <run_id>` işaret satırının yokluğu gösterir;
  - (ii) neden ortam ya da uygulama düzeyinde giderilmiş olmalı. Neden SABİT metniyse yeniden deneme yapılmaz;
  - (iii) yeni D-ID;
  - (iv) B3 ek denetimi;
  - (v) kullanıcı onayı;
  - (vi) Typhoon yeniden koşulmaz.

  Yeniden deneme hiçbir ön-kayıtlı kuralı değiştiremez. `_b` klasörüne yazılır; ilk çıktı mühürlü saklanır.

**Zorunlu sentetik durumlar**

| No | Durum | Beklenen |
|---|---|---|
| S-1 | Dolgusuz kayıt: P-1 yükleyicisi ile pinli yükleyici | Kanonik JSON tam eşit |
| S-2 | Dolgu 1, 14, 100 | P-1 geçer; kestirici çıktısı dolgusuz eşdeğerine eşit |
| S-3 | Dolgu 101; yapı dışı T[0]; NaN ya da sıfır olmayan kuyruk; saat kayması; düzensiz dt | İlgili P-1 NE'si |
| S-4 | float32 `time_s`; float64 `values`; ortam sürümü uyuşmazlığı | ABORT (X-0) |
| S-5 | H1 tablosunun satır 1–6'sının her biri; WHEA durdurmalı yarım kampanya | Doğru satır |
| S-6 | Vaka listesi §5.1'den farklı; `rel_err` ile yanlış seçim; H1 GÜÇ_YETERSİZ; H2 GÜÇ_YETERSİZ; kalibrasyon NE'sinden sonra kapının düşmesi | ABORT_TASARIM; ABORT_TASARIM; H1 koşusu yok; H2 koşusu yok; GÜÇ_YETERSİZ |
| S-7 | Yetki eksik ya da yanlış; iki kip birlikte; çıktı klasörü var | KAPI |
| S-8 | VH96 analizcisi VH95 kayıtlarında (vaka listesi VH95'e ayarlı; yalnız sentetik test kipinde) | `cases` ve `labels` VH95-RA_b ile kanonik JSON'da eşit |
| S-9 | H2: in KARARLI + out KARARSIZ; in KARARSIZ; out KARARLI; ikisi BELİRSİZ_K; biri NE; in KARARSIZ + out NE | PARANTEZ; ÇELİŞKİ; ÇELİŞKİ; BELİRSİZ_V; NE; NE |
| S-10 | H2 tablosunun satır 1–6'sı | Doğru satır |
| S-11 | k seçimi: yalnız k = 0.20 sağlıyor; hiçbiri sağlamıyor | k = 0.20; GÜÇSÜZ |
| S-12 | `vh96_headroom.py` `gfm_dc` dışında bir alanı değiştiriyor; yeni değer 800/VDC_BASE'ten farklı | ABORT_TASARIM |
| S-13 | H1 kapısı geçmiyor, H2 kapısı geçiyor | Yalnız H2 kampanyası; ayrı klasör ve ledger |

## 10. Yetki ve kapı
Her kampanyanın ayrı bir yetki dosyası vardır: `protokol/VH96_yetki_<run_id>.json`. İçeriği:
- action: `ALLOW_VH96_RUN` ya da `ALLOW_VH96H2_RUN`;
- run_id;
- SABİT sha256;
- betik sha256'ları;
- VH96 pin_list_sha256;
- `vh96_tasarim.json` sha256; içinde H1 ve H2 kapı sonuçları; yetkilendirilen kampanyanın kapısı "geçer" olmalıdır;
- `vh96_plan.json` sha256;
- headroom kaydı, özgün ve değiştirilmiş kalibrasyon pinleri;
- B3 raporu (yol + sha256);
- kampanya ve çıktı klasörü;
- ortam;
- dayanak D-ID'ler.

B4 kullanıcı onayı gerektirir. Ayrı oturumda koşar. Koşucu ne B1 yazarı ne de B3 denetçisi olabilir.

## 11. Düzeltme eşlemesi

| Kaynak | İşlendiği yer |
|---|---|
| D1 R-1 | §5.1 sapma (a)–(c), §3 |
| D1 R-2 | §5.1 alanlar, formül, eşitlik bozma; pilot sonrası kurallar |
| D1 R-3 | §7 kapılar; tutucu havuzu |
| D1 R-4 | §9.3 |
| D1 R-5 | §1 sapmalar |
| D1 R-6 | §2 gerekçe |
| D1 R-7 | §4b |
| D1 R-8 | §8.1 satır 1, §8.3 ön durumlar |
| D1 R-9 | §2 tablo |
| D1 R-10 | §5.1, §4 ortam |
| D1 R-11 | §9.1 izinli farklar |
| D1 R-12 | S-8 |
| D1 R-13 | §2, §8, §4a pinler |
| D2 M-1 | §9.1 |
| D2 M-2 | §5.1 pilot alanları |
| D2 M-3 | §2 Göstermez, §3, §6 |
| D2 M-4 | §7 G |
| D2 M-5 | §7 yeniden uygulama, S-6 |
| D2 M-6 | §7 GÜÇ_YETERSİZ kuralları |
| D2 M-7 | §9.3 |
| D2 M-8 | §9.3 |
| D2 M-9 | §2 tablo (q3) |
| D2 M-10 | §9.1 (iii) |
| D2 M-11 | §5.1 yeniden üretim, §9.2, S-6 |
| D2 M-12 | §9.1 madde 8 |
| D2 M-13 | §3 |
| D2 M-14 | §4a ledger |
| D2 M-15 | §4c |
| D2 M-16 | §5.1 (c) |
| D2 M-17 | D-276; `G94_DURUM.md` |
| D3 M3-1 | §9.2 kopyalar, §4c |
| D3 M3-2 | §9.2 iki kampanya, §8.1, §8.2, S-13 |
| D3 M3-3 | §5.6 plan dosyası |
| D3 M3-4 | §5.5 gözlem ve değişiklik |
| D3 M3-5 | §5.5 öngörü modeli listesi |
| D3 M3-6 | §5.5 uygulama, S-12 |
| D3 M3-7 | §8.2 satır 2, statü |
| D3 M3-8 | §5.6 vaka etiketi, §8.2 satır 5, S-9 |
| D3 M3-9 | §2 son cümle, §8.2 statü |
| D3 M3-10 | §5.4 |
| D3 M3-11 | §3, §5.6 G2, §7 risk |
| D3 M3-12 | §5.5 CPL aralığı, §3 atıf |
| D3 M3-13 | §9.1 |
| D3 M3-14 | §7 GÜÇ_YETERSİZ kuralları |
| D3 M3-15 | §5.1, §3, §7, §9.3, §9.1 |
| D3 M3-16 | belge geneli: §1 sıra, §9.1, §9.2, §10, S-6, S-13 |
| D3 M3-17 | §2 Göstermez |

## 12. Kontrol listesi (`on-kayit` §2)

| Madde | Yer |
|---|---|
| K-1 | §3 |
| K-2 | §4, §5.1 |
| K-3 | VH94 v1.3 §5.1 mod kimliği; sign κ_d; §5.4 |
| K-4 | §5.1 |
| K-5 | §8 |
| K-6 | VH94 v1.3; eşitlik bozma |
| K-7 | §7 |
| K-8 | §7 |
| K-9 | §5.3 |
| K-10 | §2 |
| K-11 | §9 |
| K-12 | Belge geneli |

### FD eşlemesi (v1.1)

| FD | İşlendiği yer |
|---|---|
| FD-1 | §5.6 Vakalar; §7 H2 kapısı "seçilmiş altı vaka" |
| FD-2 | §2 H1 statüsü NOT_EVALUABLE satırı; §7 |
| FD-3 | §9.1 `vh96_tasarim.json` içeriği; §5.5 headroom kaydı |
| FD-4 | §8.3 P-1 zinciri ve ön durumların etkisi |
| FD-5 | §2 Göstermez: gerçek zaman |
| FD-6 | §7 k raporu ve ödünleşim |
| FD-7 | §4b doğrulama atfı |
| FD-8 | §4a `notlar_maddeleri_v1.md` pini |
| FD-9 | §3, §5.1 (c) |
| FD-10 | §8.1 satır 1 |
| FD-11 | §4c |
| FD-12 | §5.1 (a), (c) |
| FD-13 | §5.6 mühendislik okuması |
