# E2P ön-kayıt: port geçişi ile durum-uzayı referansı, port dal izleme ve κ_rest ayrıştırması (N-2, N-12, N-13)

**Sürüm:** **SABİT v1.1** (2026-11-08). Önceki SABİT v1.0 (7ae32a5acabf6d8f92cea05ffa12eac552194308f84521cec7650cb5e6542d5d) saklanır; v1.1 yalnız fark denetimi `denetim/E2P_SABIT_fark_denetimi.md` (bda3d9f78b942e10f8fe8c8cd7ce84840d246bd4eb25dafd1a2fc023b0462596; REVISE, F-1…F-7) metin düzeltmelerini işler, eşik değişmez (§14). Taban: TASLAK v0.3 (4094fa9da5fcf22501cfee89fd677593840e6f3eadcd29e9cd389f80dfe3b67f).
- D3 `denetim/E2P_On_Kayit_denetimi_D3.md` (23e9a507b64b6797b4cc47e42d00a1621fadc9fbe09657b647b10265deb96db9): ACCEPT_FOR_FIXATION. R3-1…R3-11 bu sürümde **yalnız metin düzeltmesi** olarak işlendi; eşikler değişmedi (§13).
- Önceki sürümler (saklanıyor): v0.2 (677f473ed5f153ebbcd5862859d2ae6c722501a0b616b211bb7febdc306dd4d6) ve v0.1 (7a98e8bed9f77dacab977ead5a1a88ee2051b1b96b0e9ff36c04f9b6fa1d3954).
- İşlenen denetimler:
  - D1 `denetim/E2P_On_Kayit_denetimi_D1.md` (0561df87c8da1ca495a061af1d5497ebd2d0a5db57493867451066b4dc5856b7), R-1…R-19 (§11);
  - D2 `denetim/E2P_On_Kayit_denetimi_D2.md` (3d24d03fe80d093dbbea55034452e1082c07486848be2a10f8621bad51ba81c5), REVISE, R2-1…R2-10. Hepsi işlendi (§12).
- Revizyon turları: 3/3 tamamlandı (D3 kabul).

**Yazar:** ana oturum (Claude). Denetçi yazardan farklıdır.

## 1. Statü
Bu belge SABİT'tir: tanımlar, eşikler ve karar tabloları değişmez; yalnız gerekçe metni düzeltilebilir (K-7). Tek başına yürütme yetkisi vermez; koşu için yetki dosyası ve kullanıcı onayı gerekir.

Yürütme sırası:
1. Bağımsız denetimler D1–D3 tamamlandı; SABİT farkı ayrı bir fark denetimiyle doğrulanır.
2. SABİT.
3. `tek-kosu-kapisi` B1–B3.
4. Yetki dosyası.
5. **Kullanıcı onayı.**
6. B4 tek koşu, kendi oturumunda.

Dayanaklar:
- Kullanıcı talimatı (2026-11-07): notlar.docx'te karşılanmamış maddeler de karşılanacak.
- Notlar planı (D-277): `notlar_is_plani_v1.md`.
- Kullanıcı (2026-11-07): "devam et" (D-286).

Danışman maddeleri (`notlar_maddeleri_v1.md`):
- **N-2:** Kuramsal port geçişi ile sayısal referans sınırı arasındaki ilişki.
- **N-12:** İyimser ve uyuşmazlık noktalarında port dallarının yol boyunca izlenmesi; rakip geçişler.
- **N-13:** κ_rest'in kaynak ve dinamik CPL katkılarına ayrılması; işareti hangi katkının çevirdiği.

## 2. Soru, kapsam, kanıt tavanı

| Sınama | Not | Soru | Dayanak |
|---|---|---|---|
| A (port–referans kimliği) | N-2 | Kesin (eşiksiz) referansta durum matrisinin sanal eksen özdeğeri bir port geçişiyle eşleşiyor mu (I1)? Bu geçiş, port ölçütünün seçtiği en küçük geçiş mi (I2)? Port kökü kesin referansla örtüşüyor mu? Makalenin kullandığı göreli eşikli referans (dGref) kesin referanstan ne kadar sapıyor (δ_tab)? | Makale §4: F(ΔG) = min_z ρ_z(x(ΔG)) − ΔG. Referans: S2 F.2; `ext_engine.reference_margin` |
| B (dal izleme) | N-12 | 0 → ΔG_son yolunda donmuş kritik geçiş en küçük geçiş olarak kalıyor mu? Rakip geçiş var mı? | Makale v6.3 §6.9; S2 v6'daki eşdeğer iki cümle (§4) |
| C (κ ayrıştırması) | N-13 | κ'nın satır bölüşümü (κ_G, κ_N, κ_Co, κ_Cb) nedir? İyimser noktalarda işareti hangi katkı çeviriyor? | Makale Denk. 12–15 (κ_L); `ext_common.decompose` |

### Kuramsal dayanak (VERIFIED; D1 Madde 1 ve D2 bağımsız olarak doğruladı)
- **G'nin girişi:** G yalnız bara gerilim satırlarında, doğrusal olarak −G[k]·V terimiyle girer (`ext_engine.py:244–245`). Bu yüzden J_{G−ΔG}(x) = J_G(x) + ΔG·E_port olur.
- **Schur tümleyeni:** K(s) = sM − J ve M köşegendir. Buradan Y_{ΔG}(s) = Y(s) − ΔG·I çıkar. Bu her karmaşık s için geçerlidir.
- **Determinant özdeşliği:** det K(s) = det K_rr(s)·det(Y(s) − ΔG·I).
- **Sonuç:** K_rr(s) tekil değilse, s'nin x(ΔG)'de bir durum özdeğeri olması ile Y_G(s; x(ΔG))'nin ΔG'ye eşit bir özdeğerinin olması denktir. s = jω'da bu, Im μ = 0 ve ρ = ΔG olan bir geçiş demektir.

Port kökü ile ilk eksen geçişinin ayrışabileceği durumlar:
- (a) ω = 0;
- (b) ω, tarama bandının (10⁻²–10^3.5 Hz) dışındadır;
- (c) K_rr(jω) tekildir;
- (d) tarama ya da dal izleme bir geçişi kaçırmış ya da sahte bir geçiş üretmiştir (`ext_engine.py:479–512`);
- (e) eksene geçen geçiş en küçük geçiş değildir (rakip geçiş; F geçiş doğumunda süreksiz olabilir);
- (f) dGref'in göreli eşiği (−1e-10‖A‖₂) referansı kesin geçişten önceye çeker.

(a)–(e) dışlanırsa port kökü kesin referansla kuram gereği aynıdır (INFERENCE).

### Göstermez
- **A yeni bir kuramsal kanıt değildir.** Schur determinant özdeşliğinin yazılımdaki karşılığını sınayan bir **doğrulama** sınamasıdır ve sürprizi düşüktür. Kanıt ağırlığı I2'de (RAKİP), sınıf dağılımında, δ_tab/δ_tab,pred'de ve ref_sign_ex'tedir.
- TSV aileleri (A2, B2, C) dışına genelleme yapmaz. Anahtarlamalı ya da EMT modeli hakkında bir şey söylemez.
- B'nin 21 noktalı ızgarası, ızgara noktaları arasındaki kısa ömürlü değişimleri kaçırabilir.
- C bir satır bölüşümüdür, alt sistem ya da cihaz bölüşümü değildir:
  - GFM frekansı z, CPL filtre (`ext_engine.py:220–225`), hat (234–235) ve bara (244–245) satırlarına girer. GFM'in frekans etkisi bu yüzden κ_N, κ_Co ve κ_Cb'ye dağılır.
  - R_N, shed baranın kendi port düğüm satırlarını içerir. Port satırlarındaki CPL enjeksiyonu (kL·Irf) doğrusaldır ve dJ'ye katkısı 0'dır (`ext_engine.py:227`; INFERENCE, D2). Bu yüzden R_N'e CPL cihaz terimi sızmaz.
  - κ_Cb bir cihaz admitansı türevi değildir.
  - κ_L ile κ_Cb'nin "ideal parçası"nın aynı olduğu sınanmamış bir varsayımdır (INFERENCE).
- C, x0'da birinci derecedendir; nedensel bir fizik iddiası değildir.

**Kanıt tavanı:** E2.

### Hüküm → statü
- **A = RET-İHLAL:** yalnız karmaşık s'deki doğrudan özdeşlik denetimi (§5.3 adım 9b) de başarısız olursa verilir. Anlamı yazılım tutarsızlığıdır. O durumda makaledeki port–referans ilişkisi cümlesi yazılmaz.
- **A = KISMİ ya da TUTARLI:** makaleye δ_tab ilişkisi ve sınıf sayıları girer.
- **B:** Makale v6.3'te §6.9'daki "Port-branch switching was not separately tracked throughout these paths." cümlesi ile S2 v6'daki iki eşdeğer cümle (paragraf 4762 ve 4821; D2 R2-10) birlikte değiştirilir:
  - KISMİ → rakip geçişli nokta sayısı ve ilk SWITCH'in ΔG/ΔG_son konumu;
  - TUTARLI → "değerlendirilebilen n/18 iyimser noktada kritik dal 21 noktalı ızgara boyunca en küçük geçiş olarak kaldı" (n gerçek sayıdır; S_O'da EŞİK_GENİŞ sayısı > 0 ise bu sayı da cümlede belirtilir; R3-9, F-4);
  - BELİRSİZ ya da NOT_EVALUABLE → cümle korunur, takibin sınırı eklenir.
- **C betimseldir.** Önceden yazılmış sonuç kuralı: S_O'da X-3'ü geçen noktalar arasında TEK(κ_dış) sayısı mutlak olarak ≥ 10 ise makalenin κ_rest için kullandığı "non-ideal CPL residual" adlandırması düzeltilir; 9 ve altında değişmez. C = NOT_EVALUABLE ise adlandırma değişmez (R3-10).

## 3. Körleme (K-1; yazarın kendi beyanı, LOW CONFIDENCE doğrulanabilirlik)

| Nicelik | Durum |
|---|---|
| points.csv'nin kayıtlı alanları (κ, ΔG*_f, dGref, ref_sign, κ_L/κ_V/κ_θ/κ_rest, F_single, eps2, ω, c, …) | Körleme dışı (görüldü, yayımlı) |
| Y2 N2 − dGref farkı (0.5×10⁻⁵ … 1.6×10⁻⁴ pu, hepsi pozitif, medyan 3.5×10⁻⁵; `ms\s2_v3.txt` H.11) | Kısmen sızmış. δ_tab'ın işaretini ve büyüklüğünü öngörür. **A'nın KİMLİK yönünü de büyük ölçüde öngörür** |
| Y2 `newton.jsonl` alanları omega1, omega2, F1, F2, kappa1, kappa2 (774 nokta) | Kısmen sızmış (yol üzerindeki iki noktada dal değişimi). **Yazar değerlere bakmadı.** K-2 (D-285) yalnız 8 noktada N1 ve N2 göreli farkını (0) gördü |
| PSV `stage2.jsonl` `dGref_exact` (95 satır, kardeş aile) | Kısmen sızmış. Yazar değerleri açmadı |
| İyimser noktalarda κ_rest değeri | Kısmen sızmış: toplam bilinir, bölüşüm bilinmez |
| C-F00779'un göreli referans farkı (−1.79×10⁻⁵ pu, K1 notu) | Görüldü (δ_tab aralığında; D1 R-5) |
| ΔG*_ex, ω_ss, I1, I2, δ_port, ref_sign_ex, e_id | Körlenmiş |
| B'nin 19 ara ızgara noktasındaki geçiş kümeleri; S_D ve S_X yolları | Körlenmiş |
| κ_G, κ_N, κ_Co, κ_Cb | Körlenmiş |

**Kanıt ağırlığı:**
- A: I2/RAKİP, δ_tab/δ_tab,pred, ref_sign_ex.
- B: 19 ara ızgara noktası, S_D ve S_X.
- C: satır bölüşümü.

## 4. Pinler

`…` = `C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence`.

| Dosya | Bayt | SHA256 |
|---|---|---|
| `…\gelistirme92_20261026\girdi\development_20261026\out\tsv\TSV_a\analysis\points.csv` | 2111107 | 6a099961188a4cdf51865fbc0e370c2c9ce5a8e961e55a8a7e23e01dcbb844e7 |
| `…\gelistirme92_20261026\girdi\development_20261026\out\tsv\selection.json` | 2635991 | 2d5a00d86497b174277d238293e08129f901627da99844552dcfcc397d981b53 |
| `…\gelistirme92_20261026\kod\ext_engine.py` | 28393 | 22feea1836b7e3b475e86efc0c3660eb742f83cd224444a2317ff001bd58489e |
| `…\gelistirme92_20261026\kod\ext_common.py` | 21468 | b11b55cd58665944e7371aece67dd2dea147bdae7156cc75190b8668544e811a |
| `…\gelistirme92_20261026\kod\y2_newton.py` | 7408 | 93428a8a031e21024ca338cb3d7381f209bc49b4a504d0e7914e96239b006e65 |
| `…\gelistirme92_20261026\kod\y_common.py` | 3644 | 7b16ffbf27dce28fb1932a38705eadbadde2ad1f22c9349c485f6feb523a2970 |
| `…\gelistirme92_20261026\kod\y16_analysis.py` | 7963 | ac90702669de465013a383ebd7789b16be99b609afdf59f9611f162d33b9fccc |
| `…\gelistirme92_20261026\ms\s2_v3.txt` | 208824 | d039946c8122ec6056a6d5385b5d4c80483e09f37bf0ff3adea32b202956f4c7 |
| `…\gelistirme92_20261026\ms\ms_v4.txt` | 139194 | 94df67aaf411d987d872919d1065de56a6c642ac02652f11655589a1a65d238c |
| `…\gelistirme94_20261029\notlar_maddeleri_v1.md` | 3452 | 3b678a10bbde2b9d6d4b38d5257452c18d3f5fba42ace3b87f269b1427d260bc |
| `…\gelistirme94_20261029\K1_kayit_analizleri_N4_N5_N16.md` | 4839 | 10f25de3b00c7d05d9f5aebd17d3273423a1f26b5f1936b0444e600fa6af39d2 |
| `…\gelistirme94_20261029\protokol\P94_On_Kayit_v1.0_SABIT.md` (S-b emsali) | 32226 | 88b37f583111255d334449fea16c38c82815b3a8a07531bfc7b1a99f906551c2 |
| `…\gelistirme94_20261029\makale_v6\Manuscript_v6_3.docx` | 4074230 | 68885a86aa7a6401ac71765ef1fb003c7fc32b76084630d4581155b14014d47e |
| `…\gelistirme94_20261029\makale_v6\Supplementary_Methods_S2_v6.docx` | 679676 | df3cf76e6ce20503bfde634dc0476f6f97cb880d87daa54ee252c7ac78f12442 |

**Okuma ve kapı kuralları:**
- Motor modülleri yalnız okunur ve içe aktarılır; yama ya da setattr yapılmaz.
- `y2_newton.kappa_at` bir üçlü döndürür: (κ, c, η).
- **Ortam kapısı (P94 emsali, D2 R2-6):** G92_S1 ya da G92_OUT ortam değişkeni tanımlıysa `--check-only` ve gerçek kip "KAPI" ile çıkar. Ayrıca `y_common.TSV / 'TSV_a/analysis/points.csv'` ve `y_common.TSV / 'selection.json'` mutlak yolları pin tablosuyla karşılaştırılır. Hash, motorun gerçekten okuduğu yol üzerinden alınır.
- **Tek okuyucu:** Noktalar `y_common.load_points()` ile okunur; sayısal alanlar float'tır (ref_sign ∈ {1.0, −1.0, 0.0}). Seçim kaydı `y_common.selection()[id]` ile alınır.

## 5. Tanımlar

### 5.1 Nokta kümeleri
- **Tüm küme:** 1249 satır. Durum metinleri önek eşleşmesiyle okunur: 'alpha', 'censored', 'newton failure'.
- **S_P:** `y_common.y2_set(load_points())`. Beklenen 774; değilse ABORT. |κ| = 0.05 kümeye girer (≥).
- **S_O:** S_P içinde κ < 0 ve ref_sign = −1.0. Beklenen 18; değilse ABORT.
- **S_D:** Tüm kümede ref_sign ∈ {1.0, −1.0} olup şunlardan birini sağlayan noktalar:
  - sign(κ) ≠ ref_sign; ya da
  - ref_sign = −1.0 ve [κ ≥ 0.05 ya da (κ < 0.05 ve F_single tanımlı ve F_single > 0)].
  F_single boş (None) ise ikinci koşul yanlış sayılır (`y16_analysis.py:43–52`). Beklenen 4 nokta (A2-F00893, B2-F01989, C-F00428, C-F00779); değilse ABORT.
- **S_X:** S_P içinde A'da ω0, ωHI, EKSEN, TARAMA, GİZLİ, İHLAL, RAKİP, GENİŞ ya da KÖK_SAPMA sınıfı alan noktalar. id metninin sözlük sırasıyla ilk 20'si alınır; 20'den azsa hepsi. A tamamlanmadan kurulamaz.
- **S_T (B):** S_O ∪ S_D ∪ S_X.
- **S_K (C):** Tüm küme.
- **S_A (A):** S_P ∪ S_D. Hükme yalnız S_P girer.

### 5.2 Hazırlık ve giriş denetimleri
- **Kurulum:** `ext_common.BUILDERS[system](selection()[id])`, ardından `E.dispatch(lay, P, G, tol=1e-12)`. Kabul: ok ya da artık ≤ 1e-8. Değilse NE-dağıtım.
- θ_b = atan2(V_I, V_R), shed bara.
- **X-1 (K-3):** crit = `E.rho_at(lay, x0, refs, G, θ_b, dict(omega=ω_rec, lam=complex(dGf_rec, 0)))`. Koşul: |crit.ω − ω_rec| ≤ 1e-6·ω_rec ve |crit.ρ − dGf_rec| ≤ max(1e-9·dGf_rec, 5e-12) pu. Değilse NE-kimlik.
- **X-2:** k = `E.kappa_hat(lay, x0, refs, G, θ_b, crit)`. Koşul: |k.κ − κ_rec| ≤ 1e-6·max(|κ_rec|, 0.05). Değilse NE-kimlik.
- Sonraki her yerde κ := X-2'nin κ'sıdır.
- X-1 ve X-2 sonuçları C aşamasında hesaplanır; A ve B bunları C.jsonl'dan okur. Hesap deterministiktir; bu yalnız süre ve devam davranışını etkiler (D2 R2-8.11).

### 5.3 Sınama A (S_A)
**Matris biçimi (her yerde):** A(x, G') = J[np.ix_(keep, keep)] / M[keep][:, None], yani satır bölmesi (`spectral_abscissa` ile aynı, `ext_engine.py:442`).

1. **Kesin referans:**
   - `E.reference_margin(lay, x0, refs, G, dG_max, 0.01·dGf_rec, tol=1e-9, alpha_tab=0.0)`, dG_max = min(G_R, 2·dGf_rec).
   - Durum 'alpha' ile başlamıyorsa: 'censored' ise REF-SANSÜR (A sınıfı NE-ref; ref_sign_ex = +1; B'de ΔG_son = dG_max); öteki durumlarda NE-ref.
   - ΔG*_ex = dGt.
2. **x_ex:**
   - `E.path_point(lay, x0, refs, G, ΔG*_ex, steps=n)`, n = ⌈ΔG*_ex/(0.01·dGf_rec)⌉. Başarısızsa bir kez 2n adımla yeniden denenir; yine olmazsa NE-denge.
   - G_ex = G − ΔG*_ex·e_sb.
   - J_ex = `jac(lay, x_ex, refs, G_ex)`; J_exG = `jac(lay, x_ex, refs, G)`.
3. **Durum özdeğeri:**
   - A_ex = A(x_ex, G_ex); λ_ss en büyük gerçel kısımlı özdeğerdir.
   - ω_ss = |Im λ_ss|, σ_ss = Re λ_ss.
   - λ_ss eşlenik bir çiftin üyesiyse Im λ_ss ≥ 0 olan üye alınır (R3-10).
   - v: `eig(A_ex)`'in λ_ss'e ait sağ özvektörü. y: `eig(A_exᵀ)`'in λ_ss'e en yakın özdeğerine ait özvektör (eşleniksiz).
   - κ_eig = ‖y‖₂‖v‖₂/|yᵀv|. Hesap `y @ v` ile yapılır, `np.vdot` ile değil (`kappa_hat:550` ve `eig2:472` ile aynı).
   - Koruma: |yᵀv| ≤ 1e-14·‖y‖‖v‖ ise κ_eig tanımsızdır ve bayrak EŞİK_VARSAYILAN konur.
   - ‖A_ex‖₂ kaydedilir.

   **Erken sınıf:** ω_ss < 2π·0.01 ise ω0, ω_ss > 2π·10^3.5 ise ωHI. Eşitlik bu sınıflara girmez. Bu durumda adım 6–12 atlanır; adım 4, 5, 13 ve 14 hesaplanır.
4. **dσ/dΔG:**
   - ΔG⁻ = ΔG*_ex − 1e-3·dGf_rec'de `E.newton_fixed_refs(lay, x_ex, refs, G − ΔG⁻·e_sb)` çözülür.
   - A(x⁻, G − ΔG⁻e_sb)'nin λ_ss'e en yakın özdeğeri alınır; dσ/dΔG = (σ_ss − σ⁻)/(1e-3·dGf_rec).
   - Başarısızlık, istisna ya da 0 sonuç → "tanımsız".
5. **Nokta eşiği:**
   - thr_ρ,i = max(1e-7, 10·u·κ_eig·‖A_ex‖₂/|dσ/dΔG|) pu, u = 2.22e-16.
   - dσ/dΔG ya da κ_eig tanımsızsa thr_ρ,i = 1e-7 ve bayrak EŞİK_VARSAYILAN.
   - κ_eig tanımsızsa (|yᵀv| koruması) ayrıca EŞİK_GENİŞ bayrağı konur ve 9b "değerlendirilemedi" sayılır (R3-4).
   - **Üst sınır:** thr_ρ,i > 1e-3·ΔG*_ex ise bayrak EŞİK_GENİŞ konur. Sınıf GENİŞ olur (aşağıdaki sıra).
6. **Port geçişleri:**
   - C_ex = `E.crossings(lay, J_exG, θ_b)`.
   - **Geçerli aday:** |Im z.lam| ≤ 1e-9·max(1, |z.lam|) olan geçiştir. Geçerli olmayanlar SAHTE_ADAY olarak kaydedilir ve m, F, I1, I2'ye girmez.
7. **I1 toleransları.** |ω_z − ω_ss| ≤ 0.05·ω_ss olan her geçerli aday z için:
   - λ_z = `eig_branch(lay, J_exG, θ_b, ω_z, z.lam)[0]`.
   - dμ/dω = [eig_branch(…, ω_z(1+1e-6), λ_z)[0] − eig_branch(…, ω_z(1−1e-6), λ_z)[0]]/(2e-6·ω_z).
   - c_z = Re(dμ/dω)/Im(dμ/dω).
   - tol_ρ,z = thr_ρ,i + |σ_ss|·|dμ/dω|²/|Im dμ/dω|.
   - tol_ω,z = 1e-4·ω_ss + 2(1 + |c_z|)·|σ_ss|.
   - Im dμ/dω = 0 ya da istisna olursa aday elenir ve kaydedilir.

   Dayanak: s = σ + jω'da μ'nün birinci derece açılımı ve Cauchy–Riemann (dμ/ds = −j·dμ/dω). D2 bunu doğruladı.
8. **I1:** |ω_z − ω_ss| ≤ tol_ω,z ve |ρ_z − ΔG*_ex| ≤ tol_ρ,z sağlayan bir geçerli z vardır. Birden çoksa |ρ_z − ΔG*_ex| en küçük olan z* seçilir.
9. **I1 başarısızsa, sırayla:**
   - **9a. TARAMA:**
     - z_d = `E.rho_at(lay, x_ex, refs, G, θ_b, dict(omega=ω_ss, lam=complex(ΔG*_ex, 0)))`.
     - λ_d = `eig_branch(lay, J_exG, θ_b, z_d.omega, z_d.lam)[0]`.
     - Yakınsama: |Im λ_d| ≤ 1e-9·max(1, |λ_d|).
     - tol_ρ ve tol_ω, z_d.ω'da adım 7'deki yolla hesaplanır.
     - z_d yakınsamış ve I1'i sağlıyorsa TARAMA. İstisna olursa TARAMA bulunamamış sayılır.
   - **9b. Karmaşık s'de özdeşlik (D2 R2-3):**
     - e_id = min_i |μ_i(to_F0(port_admittance(lay, J_exG, λ_ss), θ_b)) − ΔG*_ex|.
     - Koşul: e_id ≤ thr_ρ,i + 10·|dμ/dω|_ss·u·κ_eig·‖A_ex‖₂. |dμ/dω|_ss'nin kaynağı sırayla şöyledir (R3-5): (1) adım 7'de hesaplanmış, ω_ss'ye en yakın aday; yoksa (2) 9a'daki z_d için hesaplanan değer; o da yoksa (3) terim atlanır ve yalnız thr_ρ,i kullanılır.
     - 9b'de istisna olursa 9B_HATA bayrağı konur; EKSEN sınıfı iki alt sayıyla raporlanır: e_id koşulu sağlandı / değerlendirilemedi (R3-6).
   - **9c. GİZLİ:**
     - eig(A_rr), A_rr = J_exG[np.ix_(r, r)]/M[r][:, None], r = keep ∖ port.
     - min_i |λ_i − λ_ss| ≤ 1e-4·max(ω_ss, |λ_ss|) ise GİZLİ.
     - İstisnada GİZLİ değil; bayrak GİZLİ_HATA.
10. **Rapor (her noktada):**
    - cond(K_rr(jω_z*)) ya da I1 başarısızsa cond(K_rr(jω_ss));
    - ω_ss'de Y'nin iki özdeğerinin gap_rel'i (stage1'deki G5 ölçüsü);
    - Özdeşliğin ikinci sayısal sınaması: adım 4'teki FD dσ/dΔG ile (1 − κ_ex)·Im(dμ/dω)/|dμ/dω|² oranı (D2 R2-7).
11. **I2 (işlevsel; yalnız I1 sağlanmışsa değerlendirilir):** z* için ρ < ρ_z* − tol_ρ,z* sağlayan başka bir **geçerli** pozitif geçiş yoktur.
12. **Port kökü (yalnız I1 ve I2 sağlanmışsa hesaplanır; R3-1).** I1 ya da I2 sağlanmazsa F_ex, κ_ex ve δ_port "tanımsız" kaydedilir; bu bir NE değildir. Sağlanmışsa:
    - Karar niceliği: F_ex = ρ_z* − ΔG*_ex (F-1). Yalnız rapor: F_ex,min = min_{geçerli, ρ>0} ρ_z − ΔG*_ex ve MIN_FARKLI bayrağı (en küçük geçerli pozitif geçiş z* değilse).
    - κ_ex = `y2_newton.kappa_at(lay, x_ex, refs, G, G_ex, θ_b, z*)[0]` (R3-1). F_ex ve κ_ex aynı dalda (z*) alınır.
    - κ_ex < 1 ise δ_port = −F_ex/(κ_ex − 1); değilse δ_port tanımsızdır (transversallik C12 yok).
    - İstisna → NE-hata.
13. **ref_sign_ex** = `ext_common.ref_sign_of('alpha', ΔG*_ex − dGf_rec, dGf_rec)`. REF-SANSÜR'de +1.
14. **δ_tab** = dGref_rec − ΔG*_ex.
    - δ_tab,pred = −1e-10‖A_ex‖₂/(dσ/dΔG); dσ/dΔG tanımsızsa δ_tab,pred tanımsızdır.
    - AYIRT bayrağı: |δ_tab| ≥ 10·thr_ρ,i.

**İstisna yerelliği:**

| Adım | İstisnada sonuç |
|---|---|
| 1 | NE-ref |
| 2 | NE-denge |
| 3 | NE-hata |
| 4 | dσ/dΔG tanımsız (EŞİK_VARSAYILAN) |
| 6 | NE-hata |
| 7 (aday başına) | aday elenir |
| 9a | TARAMA bulunamadı |
| 9b | özdeşlik değerlendirilemedi; e_id koşulu sağlanmamış sayılmaz, sınıf EKSEN olur (İHLAL verilmez) |
| 9c | GİZLİ değil (GİZLİ_HATA) |
| 10 | yalnız rapor alanı boş |
| 11 | yalnız I1 sağlanmışken değerlendirilir; istisna → NE-hata |
| 12 | yalnız I1 ve I2 sağlanmışken hesaplanır; istisna → NE-hata |
| listelenmeyen herhangi bir adım | NE-hata (R3-6) |

**Nokta sınıfı (ilk eşleşen):**
1. NE-dağıtım / NE-kimlik / NE-ref / NE-denge / NE-hata;
2. ω0;
3. ωHI;
4. I1 başarısızsa:
   - TARAMA (9a buldu);
   - GİZLİ (9c);
   - EKSEN (9b koşulu sağlanıyor ya da değerlendirilemedi);
   - İHLAL (9a, 9b ve 9c'nin hiçbiri);
5. GENİŞ: EŞİK_GENİŞ;
6. RAKİP: I1 sağlanır, I2 sağlanmaz;
7. KÖK_SAPMA: I1 ve I2 sağlanır ve şunlardan biri doğrudur (transversallik ihlali; tek uzayda yazılış R3-8):
   - δ_port tanımsız (κ_ex ≥ 1);
   - |F_ex| > tol_ρ,z* (δ_port tanımlıyken |δ_port| > tol_ρ,z*/|1 − κ_ex| ile cebirsel olarak aynıdır; tek koşul olarak bu kullanılır, F-2).
8. KİMLİK.

Toplam 15 sınıf: 5 NE + ω0, ωHI, TARAMA, GİZLİ, EKSEN, İHLAL, GENİŞ, RAKİP, KÖK_SAPMA, KİMLİK. REF-SANSÜR, NE-ref'in bir alt etiketidir.

### 5.4 Sınama B (S_T)
- **ΔG_son:**
  - A sınıfı NE-dağıtım ya da NE-kimlik → B'de aynı NE.
  - NE-ref (REF-SANSÜR değil) → B'de NE-ref.
  - REF-SANSÜR → ΔG_son = dG_max.
  - Öteki her durumda (NE-denge ve NE-hata dahil) → ΔG_son = ΔG*_ex.
- **Izgara:** ΔG_k = k·ΔG_son/20, k = 0…20. x_k, x_{k−1}'den `E.newton_fixed_refs` ile bulunur. Başarısızsa 2 ve 4 alt adımla yeniden denenir; yine olmazsa NE-denge(k).
- **Her k'de:**
  - C_k = `E.crossings(lay, jac(lay, x_k, refs, G), θ_b)`;
  - geçerli adaylar (§5.3 adım 6 ölçütü); SAHTE_ADAY'lar kaydedilir;
  - m_k = en küçük geçerli pozitif geçiş; yoksa YOK(k);
  - F_k = ρ(m_k) − ΔG_k.
- **İzlenen geçiş:**
  - t_0 = crit;
  - t_k = `E.rho_at(lay, x_k, refs, G, θ_b, t_{k−1})`;
  - κ_{k−1} = `kappa_at(lay, x_{k−1}, refs, G, G_{k−1}, θ_b, t_{k−1})[0]`; k−1 = 0'da κ.
- **Takip geçerliliği** (thr_ρ = noktanın A'daki thr_ρ,i'si; yoksa 1e-7). Beşi de sağlanmalıdır:
  - (i) **yakınsama:** |Im λ(t_k)| ≤ 1e-9·max(1, |λ|); λ, `eig_branch` ile t_k.ω'da t_k.lam hedefiyle alınır;
  - (ii) **ω sürekliliği:** |ω(t_k) − ω(t_{k−1})| ≤ 0.05·ω(t_{k−1});
  - (iii) **ρ sürekliliği:** |ρ(t_k) − (ρ(t_{k−1}) + κ_{k−1}·ΔG_son/20)| ≤ max(10·thr_ρ, 0.05·|ρ(t_{k−1})|);
  - (iv) **eşleşme:** C_k'de |Δω| ≤ 1e-4·ω ve |Δρ| ≤ 10·thr_ρ olan geçerli bir geçiş vardır. Bu ölçütü sağlayan **bütün** girdiler t_k ile özdeş sayılır; (v) ve SWITCH'te t_k'dan ayrı bir geçiş sayılmaz (R3-3);
  - (v) **tek anlamlılık:** C_k'de t_k ile eşleşenin dışında (ii) ve (iii) pencerelerini sağlayan başka bir geçerli pozitif geçiş yoktur. Varsa kopuş nedeni BELİRSİZ_EŞLEŞME'dir.

  Her k'de önce (i)–(v) değerlendirilir, sonra SWITCH (R3-3). Biri tutmazsa TAKİP_KOPUK(k) olur ve takip durur. Geçiş kümeleri k = 20'ye kadar kaydedilmeye devam eder.
  - Kopuş alt nedeni (i…v) ve "olası rakip" bayrağı yalnız rapor amaçlıdır. Olası rakip: kopuş anında ρ(m_k) < ρ(t_{k−1}) + κ_{k−1}·ΔG_son/20 − thr_ρ.
  - **B istisna ayrımı (R3-2, F-7):** `newton_fixed_refs` başarısızlığı ya da istisnası önce 2 ve 4 alt adımla yeniden denenir; hepsi başarısızsa NE-denge(k)'dır. `crossings`, `rho_at`, `kappa_at`, `eig_branch` ya da k'inci adımdaki başka herhangi bir hesap istisnası TAKİP_KOPUK(k)'dır (takip zaten kopmuşsa yalnız kaydedilir). Kurulum (dağıtım, X-1) istisnası NE-hata'dır.
- **SWITCH(k):** Takip geçerliyken şu üç koşul birlikte sağlanır:
  - m_k ≠ t_k: |ω(m_k) − ω(t_k)| > 1e-4·ω(t_k);
  - ρ(m_k) < ρ(t_k) − thr_ρ (katı);
  - m_k'dan başlatılan `rho_at` m_k'ya yeniden yakınsar (|Δω| ≤ 1e-4·ω, |Δρ| ≤ 10·thr_ρ).
- ρ(t_k) ≤ 0 olan k'ler kaydedilir.
- **Nokta sınıfı (ilk eşleşen):**
  1. NE-*. İki istisna var (R3-2):
     - NE-denge(k)'dan önce SWITCH gözlenmişse sınıf RAKİP_GEÇİŞ olur;
     - NE-denge(k)'dan önce takip kopmuşsa (SWITCH olmadan) sınıf TAKİP_KOPUK olur.
  2. RAKİP_GEÇİŞ (geçerli takip sırasında en az bir SWITCH);
  3. TAKİP_KOPUK;
  4. TEK_DAL.
- **Temsilci şekil seçimi (N-12):** S_O'da max_k |F_tr,k − F_k| (F_tr,k = ρ(t_k) − ΔG_k; yalnız takibin geçerli olduğu ve YOK olmayan k'ler) en büyük 3 nokta seçilir; eşitlikte id sırası.

### 5.5 Sınama C (S_K)
- ξ = k.xi (X-2). dJ = [J(x0+εξ) − J(x0−εξ)]/(2ε), ε = 1e-5, refs ve G sabit.
- **Satır kümeleri** (keep'in tam bölüşümü):
  - R_Cb: shed baradaki CPL'lerin satırları;
  - R_Co: öteki CPL'lerin satırları;
  - R_G: 'G:*' satırları (θ hariç);
  - R_N: 'V*' ve 'L*' satırları.
- **Formül:**
  - K = jω0·M − J0 (ω0 = crit.ω), dK^S = −P_S·dJ.
  - X = K_rr⁻¹K_rb, X' = K_br K_rr⁻¹.
  - dY^S = dK^S_bb − dK^S_br X − X' dK^S_rb + X' dK^S_rr X.
  - η_S = w_lᵀ·to_F0(dY^S)·v/(w_lᵀv) (eşleniksiz), `eig_branch(lay, J0, θ_b, ω0, crit.lam)` ile.
  - κ_S = Re[(1 + j·k.c)·η_S].
  - w_lᵀv = 0 ise NE-ayrışım.
- **Gürültü ve çapraz denetim:**
  - ν = |κ − `kappa_hat(…, eps=2e-5)`.κ|.
  - X-3: |Σκ_S − κ| ≤ max(1e-4·max(|κ|, 0.05), 10ν). Değilse NE-ayrışım.
- **Birincil bölüşüm:**
  - κ_Cb;
  - κ_dış = κ_G + κ_N + κ_Co: shed-bara CPL satırları dışındaki satırlar (ağ + port düğümü + GFM + öteki CPL'ler).
- **Birincil çevirici kuralı** (S_O, κ < 0; T₁ = {κ_Cb, κ_dış}): t < 0 ve κ − t ≥ 0 ise t çeviricidir. Sınıflar: TEK(κ_Cb), TEK(κ_dış), ÇOKLU, ORTAK.
- **İkincil (INFERENCE):** κ_res = κ_Cb − κ_L,rec. Aynı kural T = {κ_L, κ_dış, κ_res} üzerinde uygulanır. Sınıflar: TEK ×3, ÇOKLU, ORTAK.
- **Rapor:** S_O, S_P ∖ S_O ve tüm küme için κ_G, κ_N, κ_Co, κ_Cb (medyan, aralık, işaret sayıları) ve iki sınıflandırma.

### 5.6 Önceden tanımlı özetler
- **δ_tab** (S_P, aile bazında):
  - medyan, en küçük ve en büyük değer;
  - δ_tab < 0 oranı;
  - δ_tab/δ_tab,pred ∈ [0.5, 2] oranı (δ_tab,pred tanımsız noktalar paydadan çıkar, sayıları raporlanır);
  - AYIRT oranı;
  - EŞİK_VARSAYILAN, EŞİK_GENİŞ ve thr_ρ,i > 1e-6 sayıları;
  - SAHTE_ADAY sayısı.
- **Etiket değişim tablosu** (ref_sign → ref_sign_ex): S_O, S_P ∖ S_O, S_D.
- **S_D yorum tablosu** (ilk eşleşen):
  1. ref_sign_ex ∈ {0, +1} → "göreli eşik artefaktı";
  2. ref_sign_ex = −1 ve B = RAKİP_GEÇİŞ → "rakip dal";
  3. ref_sign_ex = −1 ve B = TEK_DAL → "açıklanmadı (çözünürlük ya da eğrilik)";
  4. öteki → "belirsiz".
- Mühürlü hükümler (TSVP, Y-serisi) değişmez. ref_sign_ex yalnız duyarlılık olarak raporlanır.

## 6. Eşik gerekçesi (K-7; INFERENCE)
**thr_ρ,i = max(1e-7 pu, 10·u·κ_eig·‖A_ex‖₂/|dσ/dΔG|).** Kalemler:
- **Özdeğer hatası:** σ'da ≈ u·κ_eig·‖A‖. κ_eig doğru biçimde, eşleniksiz yᵀv ile ölçülür (D2 R2-1).
  - ΔG uzayına 1/|dσ/dΔG| ile taşınır; bu δ_tab ve AYIRT için doğrudur.
  - I1'in ρ eşleşmesinde doğru çarpan |1 − κ|/|dσ/dΔG|'dir (D2 R2-7). Formül, max(|1 − κ|, 1/|1 − κ|) çarpanına kadar gevşek ya da sıkıdır (R3-7). Kayıtlı x0 κ aralığında bu çarpan ≤ 4.6'dır ve 10× güvenlik payının içinde kalır; κ_ex için aynı sınır bir varsayımdır (INFERENCE; R3-7, F-5). Eşik değişmez; yalnız gerekçe düzeltildi (K-7).
  - Port tarafı yuvarlama (≈ u·cond(K_rr)·‖Y‖) ayrı bir kalem olarak bütçeye girmez; cond(K_rr) her noktada raporlanır.
- **Üst sınır:** EŞİK_GENİŞ (thr_ρ,i > 1e-3·ΔG*_ex) sınıfı ayrıdır. Böylece aşırı geniş bir eşik I2/RAKİP'i sessizce maskeleyemez.
- **Newton tabanı:** `NEWTON_FLOOR` = 1e-9 (`ext_engine.py:42, 418–420, 434`). I1 aynı x_ex'te karşılaştırma yapar; Newton etkisi yalnız σ_ss üzerinden girer ve σ terimli toleranslarla karşılanır.
- **Bisection tol 1e-9:** σ terimine girer.
- **Geçiş inceltmesi:** göreli 1e-13. X-1'in 5e-12 pu tabanı bunu karşılar.
- **Geçerli aday ölçütü** |Im λ| ≤ 1e-9·max(1, |λ|): sekantın durma ölçütü 1e-13 (`ext_engine.py:506`). Bunun 1e4 katı, süreksizlik kaynaklı sahte geçişleri ayırır (D2 R2-5).

**ω eşikleri:**
- 1e-4·ω_ss + 2(1+|c|)|σ_ss| (I1);
- 0.05·ω (B sürekliliği ve tek anlamlılık);
- 1e-4·ω (eşleşme, SWITCH, GİZLİ).

**Çatallanma beyanı:**
- Eşikler v0.1'de Y2 farkı ve K1 notu görüldükten sonra yazıldı. v0.2 ve v0.3'te denetim bulgularıyla yeniden yazıldı.
- D1 ve D2 raporlarındaki kayıtlı özet aralıklarını (dGf ≤ 0.332; log10 cond J 5.3–6.8; t_ref ve t_single toplamları; κ aralığı) yazar raporlardan okudu.
- Körlenmiş niceliklerin hiçbiri görülmedi.
- Eşikler SABİT'ten sonra değiştirilmez.

## 7. Değerlendirilebilirlik (K-8)
- **A:** S_P'nin en az 697/774'ü NE-* dışında sınıf almalı.
- **B:** S_O'nun en az 12/18'i NE-* dışında sınıf almalı.
- **C:** S_O'nun en az 15/18'i X-3'ü geçmeli ve tüm kümenin en az 1125/1249'u X-1, X-2 ve X-3'ü geçmeli.
- Eşitlik değerlendirilebilir sayılır. Şart sağlanmazsa NOT_EVALUABLE olur ve kullanıcı kararı gerekir.

## 8. Sıralı karar tabloları (ilk eşleşen; sınamalar ayrı hüküm alır)

**A (yalnız S_P):**
1. ABORT: pin ya da hash uyuşmazlığı; ortam kapısı; S_P ≠ 774, S_O ≠ 18 ya da S_D ≠ 4.
2. NOT_EVALUABLE: < 697.
3. RET-İHLAL: en az bir İHLAL.
4. KISMİ: İHLAL yok, en az bir {ω0, ωHI, TARAMA, GİZLİ, EKSEN, GENİŞ, RAKİP, KÖK_SAPMA}.
5. TUTARLI: değerlendirilebilen her nokta KİMLİK.

**B (yalnız S_O):**
1. ABORT (ortak).
2. NOT_EVALUABLE: < 12.
3. KISMİ: en az bir RAKİP_GEÇİŞ.
4. BELİRSİZ: RAKİP_GEÇİŞ yok, en az bir TAKİP_KOPUK.
5. TUTARLI: değerlendirilebilen her nokta TEK_DAL.

**K-5 sırasından beyan edilmiş sapma (varoluşsal hüküm):** RAKİP_GEÇİŞ, geçerli takip sırasında doğrulanmış (geçerli aday ve rho_at yeniden yakınsaması) bir olaydır. Kopuk takip gözlenmiş bir olayı geçersiz kılmaz; bu yüzden KISMİ, BELİRSİZ'den önce gelir. Sahte pozitife karşı korumalar: §5.3 adım 6 ve §5.4 SWITCH koşulları. S_D ve S_X yalnız rapor amaçlıdır.

**C:**
1. ABORT (ortak).
2. NOT_EVALUABLE.
3. BETİMSEL.

**Korumalar:**
- κ_ex ≥ 1 → KÖK_SAPMA.
- w_lᵀv = 0 → NE-ayrışım.
- dσ/dΔG ya da κ_eig tanımsız → EŞİK_VARSAYILAN.
- Im dμ/dω = 0 → aday elenir.

Bütün sonuç uzayları tam ve ayrıktır (D2 3a).

**Ek raporlar (R3-9, R3-10):**
- S_O'daki EŞİK_GENİŞ sayısı ayrıca raporlanır.
- S_X, §5.1'deki dokuz sınıftan (ω0, ωHI, EKSEN, TARAMA, GİZLİ, İHLAL, RAKİP, GENİŞ, KÖK_SAPMA; NE-* hariç) birini alan noktaların id sırasıyla ilk 20'sidir (F-6). Aile dağılımı yanlı olabilir; S_X'in aile sayıları raporlanır ve bir genelleme kümesi olarak yorumlanmaz.

## 9. Yürütme biçimi (K-11)
**Betikler:** `gelistirme94_20261029/kod/e2p_run.py`, `e2p_static_check.py`, `e2p_synth_test.py`.
- İzinli içe aktarmalar: stdlib, numpy, pinli motor modülleri. scipy ve subprocess yok; eval, exec ve setattr yok.
- Kipler: `--check-only`; `--run-id ID --yetki P`; `--devam --run-id ID --yetki P`.
- Ortam kapısı ve yetki doğrulaması motor içe aktarımından önce yapılır.
- Süreç: tek süreç, düşük öncelik, verimlilik çekirdekleri, OPENBLAS ve MKL iş parçacığı sayısı 1.
- **Aşama sırası C → A → B.** Her aşamadan sonra `asama_<X>_tamam.txt` yazılır. S_X, A tamamlanmadan kurulmaz.
- **Çıktı klasörü betiğe aittir:** `C:\Users\onura\Documents\SEGAN_G94_work\e2p\<run_id>\`. Nokta satırları `C.jsonl`, `A.jsonl`, `B.jsonl` dosyalarına anında eklenir.

**Kesinti kuralı (P94 SABİT S-b emsali, pinli).** `tek-kosu-kapisi` §4'ten beyan edilmiş sapmadır ve yalnız dışsal kesinti içindir. Betik dışsal kesintiyi ayırt edemediği için uygulanabilir kural şudur:
- `--devam`, exit_code.txt yoksa izinlidir. Aynı run_id ve aynı yetki kullanılır; devam eden oturum B4 rolüne uygundur.
- Kesinti nedeni (oturumun beyanı) `devam_log.txt`'ye yazılır. Devam sayacı bu dosyanın satır sayısından okunur; üçüncü girişim reddedilir ve DURUM KULLANICI_BEKLIYOR olur.
- Her JSONL'nin yarım son satırı atılır ve kaydedilir. **O noktanın sonucu yeniden hesaplanır** (P94 S-b ile aynı). Tamamlanmış noktalar yeniden hesaplanmaz.
- Tamamlanmamış aşamadan sürdürülür.
- A'da istisnalar §5.3 istisna tablosuna, B'de §5.4 istisna ayrımına göre sınıflanır; tablo dışı istisna NE-hata'dır. Hiçbir nokta yeniden koşulmaz (F-7).

**Bitişte yazılanlar:** sonuc.json (hükümler ve §5.6 özetleri), hukum.txt, girdi_pinleri.json, stdout.txt, stderr.txt, exit_code.txt, SHA256SUMS. WHEA olay sayısı başta ve sonda kaydedilir; hükme girmez.

**Tahmini süre (INFERENCE):** A ≈ 70–90 dk, B ≈ 20–30 dk, C ≈ 10–15 dk; toplam ≈ 2–2.5 sa (×2 bant). Dayanak: kayıtlı t_ref ve t_single toplamları.

**Zorunlu sentetik test durumları** (el yapımı girdi; motor çağrılmaz; yalnız numpy yardımcıları sınanabilir):
1. **A sınıflandırıcısı:** 15 sınıfın her biri adıyla (NE-dağıtım, NE-kimlik, NE-ref, NE-denge, NE-hata, ω0, ωHI, TARAMA, GİZLİ, EKSEN, İHLAL, GENİŞ, RAKİP, KÖK_SAPMA, KİMLİK) ve REF-SANSÜR alt etiketi. Sınırlar:
   - ω_ss = 2π·0.01 ve 2π·10^3.5 (erken sınıf değil);
   - ω_ss = 0 istisnasız ω0 verir;
   - tol_ω ve tol_ρ eşitlikleri (eşleşir);
   - I2'de ρ = ρ_z* − tol (rakip değil);
   - GİZLİ eşitliği;
   - EKSEN ile İHLAL ayrımı;
   - Im dμ/dω = 0;
   - EŞİK_GENİŞ eşitliği (thr = 1e-3·ΔG: GENİŞ değil, katı >);
   - SAHTE_ADAY dışlanması;
   - istisna tablosunun her satırı;
   - I1 başarısızken adım 11–12 koşmaz ve İHLAL korunur (R3-1);
   - I1 ve I2 sağlanmışken adım 12 istisnası → NE-hata;
   - KÖK_SAPMA'nın iki yolu: κ_ex ≥ 1 ve |F_ex| > tol (R3-8, F-2, F-3);
   - MIN_FARKLI: [ρ_z* − tol, ρ_z*) aralığında daha küçük bir geçerli geçiş varken F_ex'in z*'dan alınması (F-1).
   - dσ/dΔG = 0 → EŞİK_VARSAYILAN ve δ_tab,pred tanımsız;
   - κ_eig tanımsız → EŞİK_GENİŞ ve 9b değerlendirilemedi (R3-4);
   - 9b kaynak sırası (R3-5) ve 9B_HATA;
   - eşlenik çiftte Im ≥ 0 üyesinin seçimi.
2. **κ_eig yardımcısı:**
   - normal 2×2 dönme matrisinde κ_eig = 1;
   - bilinen normal olmayan 2×2 matriste analitik κ_eig;
   - eşlenikli (vdot) yanlış kullanımı yakalayan test;
   - |yᵀv| koruması.
3. **B sınıflandırıcısı:**
   - 4 sınıf;
   - SWITCH eşitliği ve rho_at yeniden yakınsama koşulu;
   - beş kopuş ölçütü ayrı ayrı ve sınırları;
   - BELİRSİZ_EŞLEŞME;
   - SWITCH sonra kopuk → RAKİP_GEÇİŞ;
   - kopuk sonra SWITCH → TAKİP_KOPUK;
   - SWITCH sonra NE-denge(k) → RAKİP_GEÇİŞ;
   - NE-denge(k) ve 2/4 alt adımla kurtarma;
   - YOK(k); ρ(t_k) ≤ 0;
   - temsilci seçimi (YOK ve geçersiz k'ler dışlanır) ve eşitlik;
   - ΔG_son'un her dalı (REF-SANSÜR → dG_max);
   - kopuştan sonra NE-denge(k) → TAKİP_KOPUK (R3-2);
   - B istisna ayrımı: Newton → NE-denge(k), öteki istisnalar → TAKİP_KOPUK(k);
   - (iv)'ü sağlayan birden çok girdinin t_k ile özdeş sayılması (R3-3);
   - olası rakip bayrağı.
4. **C:**
   - birincil 4 ve ikincil 5 sınıf;
   - κ − t = 0;
   - X-3 eşitliği ve başarısızlığı (NE-ayrışım);
   - ν baskın tolerans;
   - w_lᵀv = 0;
   - §2 sonuç kuralı: mutlak 10 ve 9 (X-3'ü geçenler arasında); C = NOT_EVALUABLE iken adlandırma değişmez.
5. **Giriş denetimleri:** X-1 ve X-2 eşitlikleri; 5e-12 tabanı.
6. **Karar tabloları A, B, C:** her satır ve değerlendirilebilirlik eşitlikleri (697, 12, 15, 1125).
7. **Küme kuralları:** float ref_sign; F_single None; κ = 0.05; durum önekleri; S_X'te < 20 ve > 20 aday, sözlük sırası.
8. **Özetler:** δ_tab oranları (tanımsız pred paydadan çıkar); AYIRT; bayrak sayıları; etiket değişim tablosu; S_D yorum tablosunun 4 satırı.
9. **Kapılar ve devam:**
   - yetki yok; yanlış SABİT hash'i; iki kip birlikte;
   - G92_S1 ya da G92_OUT tanımlı → KAPI;
   - exit_code varken `--devam`;
   - yarım satırın atılması ve noktanın yeniden hesaplanması;
   - aşama ortası devam;
   - üçüncü devam reddi.

## 10. Yetki ve kapı
- Yetki dosyası: `protokol/E2P_yetki_<run_id>.json` (`tek-kosu-kapisi` §4 alanları).
- B4 ayrı oturumda, **kullanıcı onayından sonra** koşulur.
- Rol ayrımı: B1 yazarı ≠ B3 denetçisi ≠ B4 koşucusu.
- Donanım: tek ağır süreç; Typhoon kullanılmaz.

## 11. D1 düzeltme eşlemesi (v0.2'de işlendi; v0.3'te korunuyor)
R-1…R-19: ayrıntı v0.2 §11'dedir. D2 bunların 16'sını KARŞILANDI, 3'ünü (R-6, R-10, R-16) KISMEN buldu. Kalan kısımlar §12'de R2-1/R2-7 (R-6), R2-9 (R-10) ve R2-10 (R-16) ile kapatıldı.

## 12. D2 düzeltme eşlemesi (D2 → v0.3)

| D2 | Ciddiyet | Nerede karşılandı |
|---|---|---|
| R2-1 | yüksek | §5.3 adım 3 (eşleniksiz yᵀv, `y @ v`, koruma); adım 5 (EŞİK_GENİŞ üst sınırı ve GENİŞ sınıfı); §5.6 sayılar; §9 test 2 (κ_eig yardımcısı) |
| R2-2 | orta | §5.3 matris biçimi (satır bölmesi); adım 4 ve 9c aynı biçimle |
| R2-3 | orta | §5.3 adım 9b (karmaşık s'de e_id), EKSEN sınıfı; İHLAL yalnız 9a, 9b ve 9c'nin hiçbiri sağlanmazsa; §2 statü cümlesi |
| R2-4 | orta | §5.3 erken sınıf (ω0/ωHI adım 3'ten sonra); istisna yerelliği tablosu; §5.4 NE-denge(k) sonrası RAKİP_GEÇİŞ kuralı; testler |
| R2-5 | orta | §5.3 adım 6 geçerli aday ve SAHTE_ADAY; §5.4 SWITCH'te rho_at yeniden yakınsaması ve (v) tek anlamlılık; §8 sapma beyanı |
| R2-6 | orta | §4 ortam kapısı ve okunan yolun hash'i; §8 ABORT; §9 test |
| R2-7 | düşük | §6 gerekçe düzeltmesi (|1 − κ| çarpanı; eşik değişmedi); §5.3 adım 10 ikinci sayısal sınama ve her noktada cond(K_rr) |
| R2-8 | düşük | 1: adım 7 (hedef ve Jacobian); 2: adım 9a; 3: adım 2 (2n ile yeniden deneme); 4: §5.4 ΔG_son dalları; 5: temsilci seçimi; 6: §5.6 payda; 7: §4 tek okuyucu (float); 8: κ_dış etiketi ve göstermez notu; 9: 15 sınıf adlarıyla; 10: §9 uygulanabilir devam kuralı; 11: §5.2 C → A/B yeniden kullanım |
| R2-9 | düşük | §9 testler 1–9 (dσ/dΔG tanımsız, REF-SANSÜR yolu, X-3 başarısızlığı, 10/18–9/18, NE-denge(k) kurtarma, yeni sınıflar ve kapılar) |
| R2-10 | düşük | §4 P94 SABİT ve S2 v6 pinleri; §2 B sonuç kuralı S2'deki iki cümleyi de bağlar |

## 13. D3 düzeltme eşlemesi (v0.3 → SABİT v1.0; yalnız metin düzeltmesi, eşik değişmedi)

| D3 | Ciddiyet | Nerede karşılandı |
|---|---|---|
| R3-1 | orta | §5.3 adım 11–12 yalnız I1 (ve I2) sağlanmışken; z* kullanımı; istisna tablosunda 11 ve 12 satırları; test |
| R3-2 | orta | §5.4 B istisna ayrımı; kopuştan sonra NE-denge(k) → TAKİP_KOPUK; test |
| R3-3 | düşük | §5.4 (iv) özdeşlik kuralı; önce (i)–(v), sonra SWITCH; kopuş alt nedeni ve olası rakip bayrağı (rapor) |
| R3-4 | düşük | §5.3 adım 5: κ_eig tanımsız → EŞİK_GENİŞ ve 9b değerlendirilemedi |
| R3-5 | düşük | §5.3 9b: |dμ/dω|_ss kaynak sırası |
| R3-6 | düşük | istisna tablosu "listelenmeyen adım → NE-hata"; 9B_HATA ve EKSEN'in iki alt sayısı |
| R3-7 | düşük | §6 çarpan max(|1−κ|, 1/|1−κ|); κ_ex INFERENCE notu |
| R3-8 | düşük | §5.3 sınıf 7 (KÖK_SAPMA üç yol, tek uzay) |
| R3-9 | düşük | §2 B TUTARLI cümlesi "n/18"; §8 S_O EŞİK_GENİŞ sayısı |
| R3-10 | düşük | §2 C sonuç kuralı (mutlak 10; C = NE'de değişmez); adım 3'te Im ≥ 0 üyesi; §8 S_X aile notu; dσ/dΔG = 0 testi |
| R3-11 | düşük | §4 v6.3 docx baytı 4074230; başlıkta v0.1 ve D1 hash'leri tam; D3 hash'i eklendi |

## 14. Fark denetimi düzeltme eşlemesi (v1.0 → v1.1; yalnız metin, eşik değişmedi)

| Fark | Ciddiyet | Nerede karşılandı |
|---|---|---|
| F-1 | orta | §5.3 adım 12: karar niceliği F_ex = ρ_z* − ΔG*_ex; F_ex,min ve MIN_FARKLI yalnız rapor; yanlış cümle silindi; test |
| F-2 | düşük | §5.3 sınıf 7: KÖK_SAPMA iki koşul (κ_ex ≥ 1; \|F_ex\| > tol) |
| F-3 | düşük | §9 test listesinde tek "iki yol" maddesi |
| F-4 | düşük | §2 B TUTARLI cümlesi: EŞİK_GENİŞ sayısı |
| F-5 | düşük | §6 κ_ex için INFERENCE notu; adım 12'deki D3'te olmayan cümle silindi |
| F-6 | düşük | §8 ek raporlar: S_X dokuz sınıfla, §5.1 ile aynı |
| F-7 | düşük | §5.4 B istisna ayrımı (alt adım denemesi, tablo dışı istisnalar, kurulum); §9 istisna cümlesi |
