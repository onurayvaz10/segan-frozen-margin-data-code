"""VH96 H2 single-run gate script (tek-koşu kapısı B1). SABİT: VH96_On_Kayit_v1.1_SABIT.md (SABIT_PATH / SABIT_SHA256,
981f5faa...8c88e). Derived from vh94_run.py (24801 B, ed11d008...) with the P-1 / X-0 code of vh95ra_run.py v2
(32169 B, 615854e5...) and the H2 label / decision code (SABİT §9.2 (v)). The pinned VH94 code (vh94_run.py,
analyze_vh94.py) is imported, never edited and never patched.

State (D-279): design step tasarim_20261107_a is sealed. H1 = GÜÇ_YETERSİZ, so there is NO H1 campaign and no H1
verdict. Only the H2 campaign runs: vh96_tasarim.json H2_cases (4 cases) x R_lo, R_hi x 25 ns, 50 ns = 16 runs, in
C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\out\\VH96H2_<tarih>_a with its own ledger (SABİT §9.2, S-13).

v-history
  v1 (2026-11-07): first version.

SABİT § -> function
  §4c VH96 PINS (+ §4a, §4b) ......... PINS, check_pins; §4b VH94 PINS (56 items) ... check_vh94_pins (vh94_run.check_pins,
                                       pin list 6aa30db8...); imported module files = pins ... module_check
  §5.1, §5.5, §5.6, §7, §9.1, §9.2 ... design_checks: CASES == H2_cases (§9.2 / §8.1 row 1), scripts == scripts_pass1
     design record                     (design audit v2 N-2), gate H2 'geçer' (§10), k re-check (choose_k, §5.6),
                                       plan lo/hi rewrite (§5.6 M3-3), headroom re-check (headroom_check, §5.5 M3-6)
  §5.2 X-0 ........................... EXPECTED_DTYPE, npy_dtype, preflight, ENV, environment, pass0
  §5.2 P-1 (VH95-RA v1.2 §5.1) ....... P1Error, p1_trim, load_capture_p1 (DT, T_LAST, PAD_MAX, TOL_T)
  §5.4 (b) run gates, VH94 §5.6 G-3 .. analyze_vh94.run_gates + input_hash_ok, in process_run
  §5.6 estimator (VH94 v1.3 §5.5-8) .. analyze_vh94.window_end / estimate_run / pred_of (R_lo -> pred_d.lo, R_hi ->
                                       pred_d.hi of vh96_plan.json, i.e. the selected k), called through _estimate
  §5.6 run label, case label (M3-8) .. h2_run_label (u_run, thr = max(3 u_run, 0.2)), h2_case_label
  §8.2 decision table ................ h2_verdict (first matching row); row 1 = Abort / exception in run_analysis
  §8.1 row 1 reasons for H2 (§9.2) ... pass0 (pins, design record, ledger, WHEA, protocol, _basarisiz_, capture hash,
                                       run_status plan hash; H2 campaign records only), Abort('X-0'), HATA
  §5.5 peak mg/mc [0.20, 0.30) s ..... peak_mg_mc (report only)
  §6 report items, R_m reading ....... report_h2 (R-2 via vh94_run.report_items, R-4 = vdc_report; R-1, R-3, R-5, R-6,
                                       R-7 and the R_m engineering reading: 'uygulanamaz')
  §9.2 output, §9.3 marker ........... write_outputs; _estimate prints 'kestirici-başlıyor <run_id> <koşu>'
  §10 authorization .................. verify_authorization, campaign_ok, out_dir_ok, env_ok
  S-8 (synthetic mode only) .......... cfg['hyp'] == 'H1' branch of analyze (VH95 records; VH95-RA_b structure)

Author choices (VH96-B1-a ...):
  VH96-B1-a  No VHIL process is started here. run_campaign_vh96.ps1 calls this script with --verify (line 35, only the
             file-name prefix changed) and refuses to start otherwise; --analyze verifies again and reads the records.
  VH96-B1-b  analyze_vh94.py is imported unchanged (pinned), not copied. SABİT §9.2 lists its lines 14-15 (PLAN_SHA256,
             CASES) as hard-coded; the functions called here (window_end, estimate_run, noise_floor, fit_mode,
             run_gates, pred_of; case_verdict / campaign_verdict only in the S-8 branch) never read PLAN_SHA256, CASES
             or RUNS. This script never reads A.CASES, A.PLAN_SHA256 or A.RUNS (static check S12). The vh96_ copy of
             vh94_run.py (lines 96-97) is this file. B3 decides whether this reading of §9.2 is accepted.
  VH96-B1-c  CASES (campaign) = vh96_tasarim.json H2_cases in that order. The H2 label table covers the six selected
             cases (SELECTED): a case with h2_k = null is GÜÇSÜZ and labelled NE (§5.6 case label 1, §8.3); this does
             not change any row of §8.2 (row 2 counts evaluable cases only).
  VH96-B1-d  Class (iyimser / tutucu) is read from vh96_tasarim.json cases.<id>.cls; the plan's vh96_class must equal
             it (design_checks).
  VH96-B1-e  u_run = max(|s25 - s50|, |s25 - s25'|): sigma_hat and sigma_hat' of §5.6 are the 25 ns run's sigma and
             sigma_variant (same reading as analyze_vh94.case_verdict for one scenario).
  VH96-B1-f  Marker: before the first estimator call of a VHIL run the line 'kestirici-başlıyor <run_id> <run name>'
             is printed (flush) and kept in stdout.txt. The line starts with the literal 'kestirici-başlıyor
             <run_id>' of §9.3; the run name is added because §9.3 (i) asks about every run.
  VH96-B1-g  Design-record checks: in --verify they give KAPI (the campaign does not start); in --analyze they are
             integrity reasons of pass0 and give ABORT (row 1), as §8.1 row 1 says for a CASES difference.
  VH96-B1-h  A run_status.json whose plan_sha256 differs from the pinned vh96_plan.json is an integrity error
             ("pin ya da hash uyuşmazlığı"). A run directory whose name is not <case>_<R_lo|R_hi>_<0p025|0p05>us
             of CASES is an integrity error ("protokol dışı senaryo").
  VH96-B1-i  X-0 = Python / NumPy versions (ENV) and the dtype pins. OMP/OPENBLAS/MKL/NUMEXPR thread variables and
             SEGAN_SOURCE_CODE_DIR (§4c "tanımsız") are checked before the analysis starts and give KAPI, not ABORT.
  VH96-B1-j  --out is required only with --analyze; it must equal the authorization's out_dir, must not exist and
             must not lie inside <campaign>\\runs. A retry (§9.3) uses a new authorization, run id and *_b folder.
  VH96-B1-k  The campaign folder must be ...\\vh94\\out\\VH96H2_<8 digits>_<a-z> and equal campaign_dir of the
             authorization (SABİT §9.2 two campaigns; S-13).
  VH96-B1-l  Any script exception after the gate is recorded as ABORT, row 1, abort 'HATA', with traceback
             (§8.1 row 1 "betik istisnası"; as VH95RA-B1-g).
  VH96-B1-m  R-7 is 'uygulanamaz': VH94 v1.3 §15 item 2 computes it from the R_m 25 ns run, and there is no R_m run.
             The R_m engineering reading of §5.6 is 'uygulanamaz' for the same reason (no H1 campaign).
  VH96-B1-n  vdc_report (R-4) is kept as in vh94_run.analyze (report only).
  VH96-B1-o  The S-8 branch (hyp 'H1') exists only for the synthetic test; main() always builds real_cfg (hyp 'H2').
             R-7 in that branch uses latch_settling_p1, a copy of vh94_run.latch_settling with the P-1 loader, so no
             module attribute is assigned (VH95-RA patched vh94_run.load_capture instead).
  VH96-B1-p  Design audit v2 N-1 (TB-2 strict reading), declared: vh96_tasarim.py eligible() makes a case NE when
             sigma_R is missing or not finite in any of m, lo, hi, lo10, hi10, lo20, hi20, also for H1. This is the
             literal reading of SABİT v1.1 line 204, fixed in code before any value was seen; it may lower H1 power.
             In tasarim_20261107_a no case is NE for this reason (cases.*.ne = false). This script uses the design
             record as it is and does not re-judge eligibility.
  VH96-B1-q  sys.stdout is reconfigured to UTF-8 (python -I ignores PYTHONIOENCODING; design runner crash note
             2026-11-07, tasarim_20261107_a\\_log\\NOT_kosucu_cokmesi.txt).
  VH96-B1-r  A run without run_status.json or capture.npz is 'kayıt yok' (NE), as in vh94_run.analyze.
  VH96-B1-s  Ledger rules are those of vh94_run.analyze 170-186 (WHEA stop, run / run_start after it, case and
             scenario outside the protocol, a *_basarisiz_* directory holding capture.npz); a missing ledger is an
             integrity error.
Modes: --check-only | --verify --run-id ID --yetki P --campaign DIR | --analyze --run-id ID --yetki P --campaign DIR --out DIR
"""
import argparse
import hashlib
import io
import json
import math
import os
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
G94 = r'C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme94_20261029'
SABIT_PATH = os.path.join(G94, 'protokol', 'VH96_On_Kayit_v1.1_SABIT.md')
SABIT_SHA256 = '981f5faac8807d07597b9ad2b5fa8ee8219dd1b8189a97f0ed92acc1e9b8c88e'
OUT_ROOT = r'C:\Users\onura\Documents\SEGAN_G94_work\vh94\out'
TD = r'C:\Users\onura\Documents\SEGAN_G94_work\vh96\tasarim_20261107_a'
TASARIM = os.path.join(TD, 't3', 'vh96_tasarim.json')
PLAN = os.path.join(TD, 't3', 'vh96_plan.json')
PILOT = os.path.join(TD, 'pilot', 'vh96_pilot.json')
HEADROOM = os.path.join(TD, 'headroom', 'vh96_headroom.json')
CAL_DIR = r'C:\Users\onura\Documents\SEGAN_G94_work\vh94\independent_emt'
PINS = [   # SABİT §4c: §4a, §4b, design scripts, vh96_ copies, design outputs, original and changed calibrations
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme94_20261029\\protokol\\VH94_On_Kayit_v1.3_SABIT.md', 40367, 'ae8628bd9f05aeafb0a95f0b6d001fe64efe90c53cef2001facc26d1856b999d'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme94_20261029\\protokol\\VH95RA_On_Kayit_v1.2_SABIT.md', 36906, 'c6f7cbdb790fa5c89da01fdc8a2a9b80b8e893f38665b2964245b6e7c81e22f0'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme94_20261029\\rapor\\VH95RA_sonuc_raporu_B5b.md', 5196, '5068a5c1da8f4257ca2fe72a710410974b96d98b7549607ee6495bd95edbbf6b'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\out\\VH95RA_20261107_b\\sonuc.json', 85136, '002517567efea759187fd327220929c3f474ce5f2b4f8ecc010ac6a5cdaaf5c0'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\out\\VH95_20261106_a\\campaign_ledger.jsonl', 10175, 'a1040553d1ede402ffa041e162951bd968b97d44bb1e0f8d70a428d90d2760cf'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme94_20261029\\G94_PLAN_v1.md', 8873, '832fc51325eea48168fc117c48e76107c5f8a9bc04ebbeeeb7cc753926836e77'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme92_20261026\\girdi\\development_20261026\\out\\tsv\\TSV_a\\analysis\\points.csv', 2111107, '6a099961188a4cdf51865fbc0e370c2c9ce5a8e961e55a8a7e23e01dcbb844e7'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme92_20261026\\girdi\\development_20261026\\out\\tsv\\selection.json', 2635991, '2d5a00d86497b174277d238293e08129f901627da99844552dcfcc397d981b53'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme92_20261026\\out\\P93_20261026_a\\sonuc.json', 9622, '4c9acafa7a0807b26280649dd6ad65f08c76da885bcfbf6f553f78fec3235325'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme94_20261029\\notlar_maddeleri_v1.md', 3452, '3b678a10bbde2b9d6d4b38d5257452c18d3f5fba42ace3b87f269b1427d260bc'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\vh94_run.py', 24801, 'ed11d0082c785cdca0db70a4dc992e45c8e007d974e5745a2878b30f725cfe0f'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\segan_typhoon_vh94\\controller_code_vh94.py', 12035, '342efb717bc27a6dec25bb1886545f56c5dadfa87d436ee1c8a3377ddc6bd534'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\segan_typhoon_vh94\\build_plant_vh94.py', 10999, 'ebe0d209adecefa978a4ca9694b997a26d5d1f1ed36581c28d73337af26f5f8c'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\segan_typhoon_vh94\\audit_model_vh94.py', 4513, 'c877288ede2e0df64c7bede7d50bb4807703c4a5554c2731a87b75360ec97d79'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\segan_typhoon_vh94\\audit_compiled_timing_vh94.py', 2655, '4716bb31c193deb874e0d739f4edad084c62dd394fb203053aebaf08d5f51c0a'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\segan_typhoon_vh94\\run_vh94.py', 7887, '50e3bb41034224203f007d3957ccc48ce2f8b87b1444303eb451c3ed89c863a3'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\segan_typhoon_vh94\\run_guarded_vh94.ps1', 3910, '77af37437a9ff0fb79959ddfdd43d98f1b82d16d1eb48a7356a7b083fd5041ef'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\segan_typhoon_vh94\\run_campaign_vh94.ps1', 7113, '499f7f05218de5d7b28a38922b6d73f066c7abac0d7fb42fb516b03bb301f351'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\segan_typhoon_vh94\\controller_src\\controller_math.c', 3075, '43c9eb5d4d357eba9c9d43171f839c6a36dc422f6e1850bb30035b2679f86732'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\segan_typhoon_vh94\\controller_src\\controller_math.h', 647, '9ea2fff2387661f0996472e88473bfbfee137f0df7f408eb5805abefd0f8120b'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\independent_emt\\calibrate_vh94.py', 4545, '958bde216aa612eeb17a67e99e9904d1403ad86310d3c4ad6056e1ae9d1ba579'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\independent_emt\\model.py', 6895, '04678aba0b243bac49856dbfff3c8c4e993da9ba0d9780b8e1bfed85f72a0441'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\analyze_vh94.py', 11408, 'a8df777e5b83a03af2ac112dbeb809db019eaa28c1c0a56846c86251f1fd0d68'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\vh94_avg_dryrun.py', 7482, '8a1db891bd0ec5be91628fa78f86524ff177dcc7d555c0e80d01458a170c48b2'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme94_20261029\\kod\\vh94_pilot.py', 12128, '68b80156bd7c9e3d26f559b6e4fe230d3082e2f129f6b48e051de7eb698dc3f6'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme92_20261026\\kod\\ext_engine.py', 28393, '22feea1836b7e3b475e86efc0c3660eb742f83cd224444a2317ff001bd58489e'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme92_20261026\\kod\\ext_common.py', 21468, 'b11b55cd58665944e7371aece67dd2dea147bdae7156cc75190b8668544e811a'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme92_20261026\\kod\\ext_engine_d.py', 30767, '780c4d95a6748a137fd6ba0045603dda025c001b4d073bd3553fe62a76851cea'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme92_20261026\\kod\\ext_common_d.py', 21470, '98747eef15690f25b882850a04e77f53c22bbb21375fa7750b1a0c08242da727'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\vh95ra_run.py', 32169, '615854e508e98ab5e2fabd83fdb01c432fc6e18dfcb66cc569726baa5b45dfbb'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme94_20261029\\kod\\vh96_select.py', 3759, '0ff0e74b445a33976832c55bc0431c6b057b62e99dcd95ddc6487604f621cde6'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme94_20261029\\kod\\vh96_pilot.py', 12613, 'bfb29becc8736f506943709e9e839814ff2f8aff0bb40e4fe35aa3a5a1dad9e6'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme94_20261029\\kod\\vh96_tasarim.py', 12682, '61e093465eed3482e9ddfbc75d320206bab4806724d5ea4dc5db492c222f5579'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme94_20261029\\kod\\vh96_headroom.py', 5189, '90b559947aaf19aa1fa92cce2d0f2b0d089416b44246bf2afb94ff006b009c4a'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\segan_typhoon_vh94\\run_vh96.py', 7793, 'c11a54e974f15fcd3ad13dc44ceedc43bfc5e4e1fcbeb6e6afca3136253192cc'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\segan_typhoon_vh94\\build_plant_vh96.py', 11006, 'b03de70f2d2d79bb44c70f84439bc3252cecbb7cf7ba882298c73bde42bccbf9'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\segan_typhoon_vh94\\audit_model_vh96.py', 4500, 'a9090fc943705fff190c7706eec7b430ca97504aca9def28ad276cd23e9e8325'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\segan_typhoon_vh94\\audit_compiled_timing_vh96.py', 2638, '7d8c39011fcd65be16fc2c4c5554ad314042a941862290c8642b795ba0d99e43'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\segan_typhoon_vh94\\run_guarded_vh96.ps1', 3935, 'f595a66e04eaa45aac7d971438395746ee52032036101cf7b363f266b1407bdf'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\segan_typhoon_vh94\\run_campaign_vh96.ps1', 7162, '3084fe91615e186d9bd8b7e090b4a6003af4125770622283bf1d572415b32edc'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh96\\tasarim_20261107_a\\select\\vh96_select.json', 2084, '4c9d73c3936b06ebf257b2bbfe47ccf54a55b186ac02cff00562a5e9af6bc1d6'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh96\\tasarim_20261107_a\\select\\SHA256SUMS', 83, 'ffa86855010c5eaa334bb3342ce8970f0e7136ddff7f3c779431c139d6171984'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh96\\tasarim_20261107_a\\pilot\\vh96_pilot.json', 72779, '30bfcdc7e54349eae0188fa4793a22f77d71f11bfcae087ec7482b11a98ecb6f'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh96\\tasarim_20261107_a\\pilot\\SHA256SUMS', 82, '4d782d56894baded8148b806a24f0e838ba5fd4074300d4739f021c219db40b8'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh96\\tasarim_20261107_a\\t1\\vh96_tasarim1.json', 6221, '5b0dfbfc9bb21891975d58d2ffbfbf8672e5a298827ee4f56293f39d27234c7f'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh96\\tasarim_20261107_a\\t1\\SHA256SUMS', 85, '16557047861ae4025ed9d301abe96a65af4c07e2640f5059ebc376c464e232c0'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh96\\tasarim_20261107_a\\t2\\vh96_tasarim2.json', 8570, '1575f63af6fd45aa4d73707484e42a282cc526e0372670acee4c08bc437ff58e'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh96\\tasarim_20261107_a\\t2\\SHA256SUMS', 85, '57aea21b7768d4518f56f61863fce047ae6eb972acbbb774601a7a9cc51fcd9a'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh96\\tasarim_20261107_a\\t3\\vh96_plan.json', 51281, '0a55b64690df1a01477642dcf35466a8555ec82c695ecd6ce6ae0a1ce74b03ba'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh96\\tasarim_20261107_a\\t3\\vh96_tasarim.json', 12888, 'a15cf5711827667306dad305a1fc6a269bb9317b934fd440ede9af46b2b2b760'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh96\\tasarim_20261107_a\\t3\\SHA256SUMS', 165, '94561b95191169d6238e9f1e8c383c691d54f6248a052ba662917ea35c341160'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh96\\tasarim_20261107_a\\headroom\\vh96_headroom.json', 3625, '491175fd0a6c152c9ef2359b69ff63153cd0130409aaf22846d19a77e16629ae'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh96\\tasarim_20261107_a\\headroom\\SHA256SUMS', 85, '00a61f2e22b7978d259f844399728133b8ff831e2409ad847abd5675cf5b13b6'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh96\\tasarim_20261107_a\\dryrun_S6b\\dryrun.json', 17024, '9d5c9d3078b5670bbe83aa793a0b62f03d4ec30e59777c9d6b755ab45c8883ba'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\independent_emt\\calibration_A2-F01557.orig.json', 3880, 'b83687913ea676c394763dbe259a13f7525afa8ce5866108f3d968329b906f70'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\independent_emt\\calibration_A2-F01557.json', 3878, '6ff5a491debb666ec6713acf574c1945e0662ab09a7ec2ddd4d585e139f6b3c1'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\independent_emt\\calibration_A2-F00805.orig.json', 3875, 'b722e3111c0e5fa9debe0f33037979e2276233a83bc56d0edf05ead35a26b94d'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\independent_emt\\calibration_A2-F00805.json', 3873, 'f53fcf89a0e3c6f9cb329afdd173337bc85f25d71a66981e45fb6f28274b5656'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\independent_emt\\calibration_A2-F01169.orig.json', 3881, '9d7d7a4b48e1743f2d4c37b04dcd393c7911347350215fa6ed9393db31766154'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\independent_emt\\calibration_A2-F01169.json', 3879, '76b21c11de5a547ef3c1473ca26e11b6b81ed7fa2462ad299b21e7d1c6aac9c8'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\independent_emt\\calibration_A2-03094.orig.json', 3871, '33d6d11ed36a6a64b591faa323d8cd0e21b23575a9f25fe3d5ebc4a1815ea497'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\independent_emt\\calibration_A2-03094.json', 3869, 'cd12464151481c1ebcdd7f2bf353b264bc6ae56f45adff262a3602fff713a4c2'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\independent_emt\\calibration_A2-F00555.orig.json', 3885, '1e0541ebbf838415f53c0863d51106691ff3b6a6c28b2d8b7a17e70b6fad84ab'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\independent_emt\\calibration_A2-F00555.json', 3883, '1d05aeeb548c99601b1c703c43cdb50c2f7205d524e6bb692939a53de9724516'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\independent_emt\\calibration_A2-F01579.orig.json', 3888, '12081b184b06f79104664fd020c6f8ef9572d7a6b27e554538c60948ee9874ea'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\independent_emt\\calibration_A2-F01579.json', 3886, 'c39722263c3ef460f255fd2f445f856d8a25cee63e90af65661fd634c8ae93db'),
]
VH94_PIN_LIST_SHA256 = '6aa30db8ffd3bc6326e53b9c685cc7ac91014ebdca9a2c03041982d7985b05dd'   # SABİT §4b
CASES = ('A2-F00555', 'A2-F00805', 'A2-F01169', 'A2-F01557')          # = vh96_tasarim.json H2_cases (§9.2 (i))
SELECTED = ('A2-F01557', 'A2-F00805', 'A2-F01169', 'A2-03094', 'A2-F00555', 'A2-F01579')   # §5.1 / §5.6 H2 cases
SCENARIOS = ('R_lo', 'R_hi')                                          # §9.2 (iii), H2 campaign
RUNS_H2 = (('R_lo', '0p025'), ('R_hi', '0p025'), ('R_lo', '0p05'), ('R_hi', '0p05'))
STEPS = ('0p025', '0p05')
ACTION = 'ALLOW_VH96H2_RUN'                                           # §10
# P-1 and X-0 (SABİT §5.2 = VH95-RA v1.2 §5.1, §14 V-1)
DT = 1e-4
T_LAST = 1.8
PAD_MAX = 100
TOL_T = 1e-6
EXPECTED_DTYPE = (('time_s', 'float64'), ('values', 'float32'))
ENV = ('3.13.2', '2.5.3')                                             # §4c analysis Python / NumPy
ENV_UNSET = ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS', 'SEGAN_SOURCE_CODE_DIR')
# H2 (SABİT §5.6, §7) and modulation headroom (§5.5)
G2 = 6.4
K_KEYS = ((0.05, 'lo', 'hi'), (0.1, 'lo10', 'hi10'), (0.2, 'lo20', 'hi20'))   # pilot keys per k, smallest k first
THR_K = 3.0
THR_MIN = 0.2
VDC_BASE = math.sqrt(8 / 3) * 380.0
GFM_DC_OLD = 690.0 / VDC_BASE
GFM_DC_NEW = 800.0 / VDC_BASE
T_PEAK = (0.20, 0.30)
H2_VERDICTS = {1: 'ABORT', 2: 'NOT_EVALUABLE', 3: 'RET', 4: 'BELİRSİZ', 5: 'KISMİ', 6: 'TUTARLI'}
NA = 'uygulanamaz'
NA_RM = 'uygulanamaz: H1 GÜÇ_YETERSİZ, H1 kampanyası ve R_m koşusu yok (SABİT §5.6 mühendislik okuması)'
NA_R7 = 'uygulanamaz: R-7 R_m 25 ns koşusundan hesaplanır (VH94 v1.3 §15 madde 2); R_m koşusu yok'
R6_TEXT = ('Codex v3 F2-0.65-0.20 rampası (0.0691 pu) sönmemişti; bu kalem yalnız VH94 R_m/R_lo ile '
           'karşılaştırma notudur.')   # S-8 branch only (same text as vh94_run.py 230-231)


def _read_bytes(p):
    with open(p, 'rb') as fh:
        return fh.read()


def _write_text(p, s):
    with open(p, 'w', encoding='utf-8', newline='\n') as fh:
        fh.write(s)


def sha(p):
    return hashlib.sha256(_read_bytes(p)).hexdigest()


def sha_text(s):
    return hashlib.sha256(s.encode('utf-8')).hexdigest()


def load_json(p):
    return json.loads(_read_bytes(p).decode('utf-8'))


def canon(obj):
    return json.dumps(json.loads(json.dumps(obj, default=float)), sort_keys=True, ensure_ascii=False, default=float)


def norm(p):
    return os.path.normcase(os.path.abspath(p)) if p else ''


def pinned(path):
    want = norm(path)
    for p, _, d in PINS:
        if norm(p) == want:
            return d
    return None


class P1Error(Exception):
    """P-1 rejected a capture; args[0] is the reason (dolgu-yapı / dolgu-sınır / zaman-hiza)."""


class Abort(Exception):
    """§8.2 row 1 found in pass 0; args[0] = 'X-0' or 'BÜTÜNLÜK', args[1] = detail list."""


class Ctx:
    def __init__(self, run_id):
        self.run_id = run_id
        self.log = []
        self.est_calls = 0
        self.marked = set()


# ---------------------------------------------------------------- pins (§4)
def check_pins():
    bad = []
    for path, size, digest in PINS:
        if not os.path.isfile(path):
            bad.append((path, 'yok'))
            continue
        b = _read_bytes(path)
        if len(b) != size or hashlib.sha256(b).hexdigest() != digest:
            bad.append((path, 'uyuşmaz'))
    if not os.path.isfile(SABIT_PATH) or sha(SABIT_PATH) != SABIT_SHA256:
        bad.append((SABIT_PATH, 'SABİT uyuşmaz'))
    return bad, sha_text(json.dumps(PINS, ensure_ascii=False))


def check_vh94_pins():
    """§4b: the 56 VH94 PINS items on disk and their list hash."""
    import vh94_run as R
    bad, pin_list = R.check_pins()
    bad = [tuple(b) for b in bad]
    if pin_list != VH94_PIN_LIST_SHA256:
        bad.append(('vh94_run.PINS', 'pin listesi hash'))
    return bad


def all_pin_failures():
    return check_pins()[0] + check_vh94_pins()


def module_check(R, A):
    """The imported modules must be the pinned files."""
    bad = []
    for m, name in ((R, 'vh94_run.py'), (A, 'analyze_vh94.py')):
        p = os.path.join(HERE, name)
        if norm(m.__file__) != norm(p) or sha(p) != pinned(p):
            bad.append('içe aktarılan modül pinli dosya değil: %s' % name)
    return bad


# ---------------------------------------------------------------- design record (§5.1, §5.5, §5.6, §7, §9.2, N-2)
def _finite(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


def choose_k(pred_d):
    """§5.6: smallest k with sigma_R(in) <= -G2 and sigma_R(out) >= +G2 (pilot keys); None = GÜÇSÜZ."""
    for k, lo, hi in K_KEYS:
        a = (pred_d.get(lo) or {}).get('sigma_R')
        b = (pred_d.get(hi) or {}).get('sigma_R')
        if _finite(a) and _finite(b) and a <= -G2 and b >= G2:
            return k
    return None


def headroom_check(cid, orig_bytes, new_bytes):
    """§5.5 M3-6: the changed calibration differs from the original only in settings.gfm_dc, 690 V -> 800 V."""
    p = []
    o = json.loads(orig_bytes.decode('utf-8'))
    n = json.loads(new_bytes.decode('utf-8'))
    if o.get('case') != cid or n.get('case') != cid:
        p.append('kalibrasyon case alanı: %s' % cid)
    if (o.get('settings') or {}).get('gfm_dc') != GFM_DC_OLD:
        p.append('özgün gfm_dc 690/VDC_BASE değil: %s' % cid)
    if (n.get('settings') or {}).get('gfm_dc') != GFM_DC_NEW:
        p.append('yeni gfm_dc 800/VDC_BASE değil: %s' % cid)
    o2 = json.loads(json.dumps(o))
    n2 = json.loads(json.dumps(n))
    (o2.get('settings') or {}).pop('gfm_dc', None)
    (n2.get('settings') or {}).pop('gfm_dc', None)
    if canon(o2) != canon(n2):
        p.append('gfm_dc dışında alan farkı: %s' % cid)
    return p


def design_checks(cfg):
    """Problems of the sealed design record; empty list = consistent."""
    p = []
    t = load_json(cfg['tasarim'])
    plan = load_json(cfg['plan'])
    pilot = load_json(cfg['pilot'])
    hd = load_json(cfg['headroom'])
    scripts = t.get('scripts') or {}
    if not scripts or scripts != t.get('scripts_pass1'):
        p.append('scripts != scripts_pass1 (denetim v2 N-2)')
    for name, h in scripts.items():
        if h != pinned(os.path.join(G94, 'kod', name)):
            p.append('tasarım betiği pinle aynı değil: %s' % name)
    gates = t.get('gates') or {}
    if (gates.get('H2') or {}).get('result') != 'geçer':
        p.append('H2 kapısı geçer değil')
    if list(t.get('H2_cases') or []) != list(cfg['cases']):
        p.append('CASES != vh96_tasarim.json H2_cases')
    if list((gates.get('H2') or {}).get('campaign_cases') or []) != list(cfg['cases']):
        p.append('CASES != gates.H2.campaign_cases')
    if list(t.get('cases') or {}) != list(cfg['selected']):
        p.append('seçilmiş vakalar vh96_tasarim.json ile aynı değil')
    pc = {c['id']: c for c in plan.get('cases') or []}
    qc = {c['id']: c for c in pilot.get('cases') or []}
    if list(pc) != list(cfg['selected']):
        p.append('plan vakaları seçilmiş vakalar değil')
    if plan.get('source_pilot') != sha(cfg['pilot']):
        p.append('plan source_pilot pilot hash değil')
    for cid in cfg['selected']:
        tc = (t.get('cases') or {}).get(cid) or {}
        c, q = pc.get(cid), qc.get(cid)
        if c is None or q is None:
            p.append('plan/pilot vakası yok: %s' % cid)
            continue
        if c.get('vh96_class') != tc.get('cls') or tc.get('cls') not in ('iyimser', 'tutucu'):
            p.append('sınıf: %s' % cid)
        k = None if tc.get('ne') else choose_k(q.get('pred_d') or {})
        if k != tc.get('h2_k') or c.get('h2_k') != tc.get('h2_k'):
            p.append('k seçimi yeniden üretilemedi: %s' % cid)
        guclu = tc.get('h2_k') is not None and not tc.get('ne')
        if guclu != (cid in cfg['cases']):
            p.append('H2 vaka kümesi ile k uyuşmaz: %s' % cid)
        if guclu:
            lo, hi = {kk: (a, b) for kk, a, b in K_KEYS}[tc['h2_k']]
            pairs = (('lo', lo), ('hi', hi), ('lo05', 'lo'), ('hi05', 'hi'))
        else:
            pairs = (('lo', 'lo'), ('hi', 'hi'))
        for dst, src in pairs:
            if (c.get('amounts') or {}).get(dst) != (q.get('amounts') or {}).get(src) or \
                    canon((c.get('pred_d') or {}).get(dst)) != canon((q.get('pred_d') or {}).get(src)):
                p.append('plan %s alanı pilot %s değil: %s' % (dst, src, cid))
        po = os.path.join(cfg['cal_dir'], 'calibration_%s.orig.json' % cid)
        pn = os.path.join(cfg['cal_dir'], 'calibration_%s.json' % cid)
        hc = (hd.get('cases') or {}).get(cid) or {}
        if (hc.get('orig') or {}).get('sha256') != sha(po) or (hc.get('new') or {}).get('sha256') != sha(pn):
            p.append('headroom kaydı kalibrasyon hash: %s' % cid)
        p += headroom_check(cid, _read_bytes(po), _read_bytes(pn))
    return p


# ---------------------------------------------------------------- environment and X-0 (§4c, §5.2)
def environment():
    import numpy as np
    try:
        cfg = np.show_config(mode='dicts')
        blas = (cfg.get('Build Dependencies') or {}).get('blas')
    except Exception as exc:  # noqa: BLE001
        blas = 'show_config: %s' % exc
    return dict(python=sys.version.split()[0], numpy=np.__version__, blas=blas,
                unset_vars={v: os.environ.get(v) for v in ENV_UNSET})


def env_ok():
    bad = [v for v in ENV_UNSET if os.environ.get(v) is not None]
    return ('KAPI: tanımsız olması gereken ortam değişkenleri tanımlı: %s' % ','.join(bad)) if bad else None


def run_dirs(campaign):
    rd = os.path.join(campaign, 'runs')
    if not os.path.isdir(rd):
        return rd, []
    names = [n for n in os.listdir(rd) if os.path.isdir(os.path.join(rd, n)) and '_basarisiz_' not in n]
    return rd, sorted(names)


def npy_dtype(npz_bytes, member):
    """dtype of one array of an npz from its .npy header only (no values read)."""
    import numpy as np
    with zipfile.ZipFile(io.BytesIO(npz_bytes)) as zf:
        with zf.open(member + '.npy') as fh:
            ver = np.lib.format.read_magic(fh)
            hdr = (np.lib.format.read_array_header_1_0(fh) if ver == (1, 0)
                   else np.lib.format.read_array_header_2_0(fh))
    return str(hdr[2])


def preflight(campaign):
    rd, names = run_dirs(campaign)
    bad = []
    for n in names:
        p = os.path.join(rd, n, 'capture.npz')
        if not os.path.isfile(p):
            continue
        b = _read_bytes(p)
        for m, want in EXPECTED_DTYPE:
            try:
                dt = npy_dtype(b, m)
            except Exception as exc:  # noqa: BLE001
                dt = 'okunamadı: %s' % exc
            if dt != want:
                bad.append('%s %s %s' % (n, m, dt))
    return bad


# ---------------------------------------------------------------- P-1 (§5.2)
def p1_trim(T, V, names, capture_rows):
    """Return (k, pad) or raise P1Error. T: time_s, V: values (channel x row). Same as vh95ra_run.p1_trim."""
    import numpy as np
    pos = np.nonzero(T > 0)[0]
    if len(pos) == 0:
        raise P1Error('dolgu-yapı')
    k = int(pos[-1]) + 1
    if not (np.all(T[k:] == 0) and np.all(V[:, k:] == 0)):          # NaN != 0 -> rejected
        raise P1Error('dolgu-yapı')
    pad = len(T) - k
    if (pad > PAD_MAX or capture_rows is None or len(T) != int(capture_rows)
            or not abs(float(T[0]) - (1 + pad) * DT) <= TOL_T):
        raise P1Error('dolgu-sınır')
    C = V[names.index('simulation_clock_s')][:k]
    Tk = T[:k]
    ok = (bool(np.all(np.abs(Tk - C) <= TOL_T)) and bool(np.all(np.abs(np.diff(Tk) - DT) <= TOL_T))
          and abs(float(Tk[-1]) - T_LAST) <= TOL_T)
    if not ok:
        raise P1Error('zaman-hiza')
    return k, pad


def load_capture_p1(d):
    """vh94_run.load_capture with P-1 (= vh95ra_run.load_capture_ra): arrays cut to the valid prefix; '_pad' added."""
    import numpy as np
    z = np.load(io.BytesIO(_read_bytes(os.path.join(d, 'capture.npz'))))
    names = [str(n) for n in z['signal_names']]
    T, V = z['time_s'], z['values']
    st = load_json(os.path.join(d, 'run_status.json'))
    k, pad = p1_trim(T, V, names, st.get('capture_rows'))
    vals = V[:, :k]
    cap = {n: vals[i] for i, n in enumerate(names)}
    cap['t'] = T[:k]
    cap['values'] = vals
    cap['y'] = np.hypot(cap['v2d_pm'], cap['v2q_pm'])
    cap['_pad'] = pad
    return cap


# ---------------------------------------------------------------- authorization and gates (§10)
def campaign_ok(campaign):
    c = os.path.abspath(campaign or '')
    parent, name = os.path.split(c)
    if norm(parent) != norm(OUT_ROOT):
        return 'KAPI: kampanya klasörü %s altında değil' % OUT_ROOT
    if not (len(name) == 17 and name.startswith('VH96H2_') and name[7:15].isdigit() and name[15] == '_'
            and name[16] in 'abcdefghijklmnopqrstuvwxyz'):
        return 'KAPI: kampanya klasörü adı VH96H2_<tarih>_<harf> değil'
    return None


def out_dir_ok(out, campaign):
    o = norm(out)
    if not o:
        return 'KAPI: --out gerekli'
    if os.path.exists(o):
        return 'KAPI: çıktı klasörü zaten var'
    r = norm(os.path.join(campaign, 'runs'))
    try:
        inside = os.path.commonpath([o, r]) == r
    except ValueError:
        inside = False
    if inside:
        return 'KAPI: çıktı klasörü kampanyanın runs klasörünün içinde'
    return None


def verify_authorization(run_id, yetki, campaign, out, mode, cfg):
    bad = all_pin_failures()
    if bad:
        return 'KAPI: pin ' + json.dumps(bad, ensure_ascii=False)
    pin_list = check_pins()[1]
    try:
        y = load_json(yetki)
    except Exception as exc:  # noqa: BLE001
        return 'KAPI: yetki okunamadı: %s' % exc
    want = dict(action=ACTION, run_id=run_id, sabit_sha256=SABIT_SHA256, pin_list_sha256=pin_list)
    for k, v in want.items():
        if y.get(k) != v:
            return 'KAPI: yetki alanı %s' % k
    ss = y.get('script_sha256') or {}
    for name in ('vh96_run.py', 'vh96_static_check.py', 'vh96_synth_test.py'):
        p = os.path.join(HERE, name)
        if not os.path.isfile(p) or ss.get(name) != sha(p):
            return 'KAPI: yetki betik hash %s' % name
    for key, path in (('tasarim', cfg['tasarim']), ('plan', cfg['plan']), ('headroom', cfg['headroom'])):
        e = y.get(key) or {}
        if norm(e.get('path')) != norm(path) or e.get('sha256') != pinned(path) or sha(path) != pinned(path):
            return 'KAPI: yetki %s' % key
    if ((load_json(cfg['tasarim']).get('gates') or {}).get('H2') or {}).get('result') != 'geçer':
        return 'KAPI: yetkilendirilen kampanyanın (H2) kapısı geçer değil'
    cal = y.get('kalibrasyon') or {}
    for cid in cfg['selected']:
        e = cal.get(cid) or {}
        if (e.get('orig') != pinned(os.path.join(cfg['cal_dir'], 'calibration_%s.orig.json' % cid))
                or e.get('new') != pinned(os.path.join(cfg['cal_dir'], 'calibration_%s.json' % cid))
                or e.get('orig') is None):
            return 'KAPI: yetki kalibrasyon pini %s' % cid
    if not campaign or norm(campaign) != norm(y.get('campaign_dir')):
        return 'KAPI: campaign_dir yetkideki değer değil'
    if not y.get('out_dir') or (mode == 'analyze' and norm(out) != norm(y.get('out_dir'))):
        return 'KAPI: out_dir yetkideki değer değil'
    if list(y.get('ortam') or []) != list(ENV):
        return 'KAPI: yetki ortam'
    dy = y.get('dayanak')
    if not isinstance(dy, list) or not dy or not all(isinstance(d, str) and d.startswith('D-') for d in dy):
        return 'KAPI: yetki dayanak'
    rep = y.get('code_audit_report') or {}
    if not rep.get('path') or not os.path.isfile(rep['path']) or sha(rep['path']) != rep.get('sha256'):
        return 'KAPI: kod denetimi raporu'
    if mode == 'verify':
        dp = design_checks(cfg)
        if dp:
            return 'KAPI: tasarım kaydı ' + json.dumps(dp, ensure_ascii=False)
    return None


# ---------------------------------------------------------------- pass 0 (X-0 and integrity, §8.1 row 1 for H2)
def input_hash_ok(st, cid, cfg):
    """VH94 §5.6 G-3: run_status input hashes must equal the pinned files (by file name)."""
    pins = {os.path.basename(p): d for p, _, d in cfg['input_pins']}
    want = dict(controller_c='controller_math.c', controller_h='controller_math.h',
                controller_code_vh94='controller_code_vh94.py', calibration='calibration_%s.json' % cid)
    if cfg['hyp'] == 'H2':
        want['run_vh96'] = 'run_vh96.py'
    else:
        want['run_vh94'] = 'run_vh94.py'
    got = st.get('input_sha256') or {}
    return all(got.get(k) == pins.get(v) for k, v in want.items())


def pass0(cfg, R, A):
    campaign = cfg['campaign']
    env = environment()
    if (env['python'], env['numpy']) != tuple(cfg['env']):
        raise Abort('X-0', ['ortam %s/%s' % (env['python'], env['numpy'])])
    pf = preflight(campaign)
    if pf:
        raise Abort('X-0', ['kayıt biçimi: ' + s for s in pf])
    integ = []
    bad = all_pin_failures()
    if bad:
        integ.append('pin uyuşmazlığı: %s' % json.dumps(bad, ensure_ascii=False))
    integ += module_check(R, A)
    if cfg['hyp'] == 'H2':
        integ += ['tasarım: ' + s for s in design_checks(cfg)]
    lp = os.path.join(campaign, 'campaign_ledger.jsonl')
    ledger = []
    if not os.path.isfile(lp):
        integ.append('ledger yok')
    else:
        if cfg.get('ledger_sha256') and sha(lp) != cfg['ledger_sha256']:
            integ.append('ledger hash')
        txt = _read_bytes(lp).decode('utf-8-sig')
        ledger = [json.loads(l.lstrip('\ufeff')) for l in txt.splitlines() if l.strip()]
    guard, whea_stop = {}, False
    for e in ledger:                                   # vh94_run.analyze 170-178
        if e.get('op') == 'stop' and e.get('reason') == 'new_whea':
            whea_stop = True
        if e.get('op') in ('run', 'run_start'):
            if whea_stop:
                integ.append('WHEA durdurmasından sonra koşu: %s %s' % (e.get('case'), e.get('scenario')))
            if e.get('scenario') not in cfg['scenarios'] or e.get('case') not in cfg['cases']:
                integ.append('protokol dışı senaryo: %s %s' % (e.get('case'), e.get('scenario')))
            guard[(e['case'], e['scenario'], e['step'])] = e.get('guard_ok') is True
    rd = os.path.join(campaign, 'runs')
    failed_dirs = sorted(n for n in os.listdir(rd) if '_basarisiz_' in n) if os.path.isdir(rd) else []
    for n in failed_dirs:
        if os.path.isfile(os.path.join(rd, n, 'capture.npz')):
            integ.append('kayıtlı koşu yinelenmiş: %s' % n)
    expected = {'%s_%s_%sus' % (c, s, st) for c in cfg['cases'] for s, st in cfg['runs']}
    plan_sha = sha(cfg['plan'])
    _, names = run_dirs(campaign)
    for n in names:
        if n not in expected:
            integ.append('protokol dışı kayıt klasörü: %s' % n)
        sp, cp = os.path.join(rd, n, 'run_status.json'), os.path.join(rd, n, 'capture.npz')
        if os.path.isfile(sp) and os.path.isfile(cp):
            st = load_json(sp)
            if st.get('capture_npz_sha256') != sha(cp):
                integ.append('kayıt hash uyuşmazlığı: %s' % n)
            if st.get('plan_sha256') != plan_sha:
                integ.append('run_status plan hash uyuşmazlığı: %s' % n)
    if integ:
        raise Abort('BÜTÜNLÜK', integ)
    return guard, failed_dirs, env


# ---------------------------------------------------------------- per run (§5.4 (b), §5.6)
def _estimate(ctx, A, name, *args, **kw):
    if name not in ctx.marked:
        line = 'kestirici-başlıyor %s %s' % (ctx.run_id, name)
        print(line, flush=True)
        ctx.log.append(line)
        ctx.marked.add(name)
    ctx.est_calls += 1
    return A.estimate_run(*args, **kw)


def peak_mg_mc(cap):
    """§5.5 report: peak mg and mc over [0.20, 0.30) s."""
    import numpy as np
    t = cap['t']
    m = (t >= T_PEAK[0]) & (t < T_PEAK[1])
    if not m.any():
        return None
    return dict(mg=float(np.max(cap['mg'][m])), mc=float(np.max(cap['mc'][m])))


def process_run(ctx, cfg, A, case, cid, scen, step, rd, guard, dolgu, peaks):
    name = '%s_%s_%sus' % (cid, scen, step)
    d = os.path.join(rd, name)
    if not (os.path.isfile(os.path.join(d, 'run_status.json')) and os.path.isfile(os.path.join(d, 'capture.npz'))):
        return dict(ne='kayıt yok', pad=None, p1=None)
    st = load_json(os.path.join(d, 'run_status.json'))
    try:
        cap = load_capture_p1(d)
    except P1Error as exc:
        dolgu[name] = dict(pad=None, p1=exc.args[0])
        return dict(ne='p1:%s' % exc.args[0], pad=None, p1=exc.args[0])
    pad = cap['_pad']
    dolgu[name] = dict(pad=pad, t0=float(cap['t'][0]), p1='geçer')
    if peaks is not None:
        peaks[name] = peak_mg_mc(cap)
    sig_p, f_p, sig_r = A.pred_of(case, scen)
    win = A.window_end(cap['t'], cap['y'], sig_p)
    ok, gates, phys = A.run_gates(st, cap, guard.get((cid, scen, step), False), win[0])
    ih = input_hash_ok(st, cid, cfg)
    gates['input_hash'] = ih
    ok = ok and ih
    r = dict(gates=gates, physics=phys, capture_npz_sha256=st.get('capture_npz_sha256'))
    if not ok:
        r['ne'] = 'kapı:' + ','.join(k for k, v in gates.items() if not v)
    else:
        r.update(_estimate(ctx, A, name, cap['t'], cap['y'], sig_p, f_p, sig_r, window=win))
        if r.get('ne') is None:
            r['vdc_report'] = _estimate(ctx, A, name, cap['t'], cap['vdc_pm'], sig_p, f_p, sig_r)
    r.update(pad=pad, p1='geçer')
    return r


# ---------------------------------------------------------------- H2 labels and decision table (§5.6, §8.2)
def h2_run_label(r25, r50):
    """§5.6 run label from the 25 ns and 50 ns runs of one scenario."""
    for r in (r25, r50):
        if r is None or r.get('ne') is not None:
            return dict(label='NE')
    s = r25['sigma']
    u_run = max(abs(s - r50['sigma']), abs(s - r25['sigma_variant']))
    thr = max(THR_K * u_run, THR_MIN)
    lab = 'KARARLI' if s < -thr else 'KARARSIZ' if s > thr else 'BELİRSİZ_K'
    return dict(label=lab, sigma25=s, sigma50=r50['sigma'], sigma_variant25=r25['sigma_variant'], u_run=u_run, thr=thr)


def h2_case_label(guclu, runs4, lab_in, lab_out):
    """§5.6 case label, first matching rule (M3-8)."""
    if not guclu or any(r is None or r.get('ne') is not None for r in runs4):
        return 'NE'
    if lab_in == 'KARARSIZ' or lab_out == 'KARARLI':
        return 'ÇELİŞKİ'
    if lab_in == 'KARARLI' and lab_out == 'KARARSIZ':
        return 'PARANTEZ'
    return 'BELİRSİZ_V'


def h2_verdict(labels, classes, integrity_ok):
    """§8.2, first matching row. labels: case -> label; classes: case -> iyimser / tutucu."""
    if not integrity_ok:
        return 1, H2_VERDICTS[1]
    ev = [c for c, l in labels.items() if l != 'NE']
    n_opt = sum(1 for c in ev if classes[c] == 'iyimser')
    n_con = sum(1 for c in ev if classes[c] == 'tutucu')
    if len(ev) < 4 or n_opt < 1 or n_con < 1:
        return 2, H2_VERDICTS[2]
    if any(labels[c] == 'ÇELİŞKİ' for c in ev):
        return 3, H2_VERDICTS[3]
    if sum(1 for c in ev if labels[c] == 'PARANTEZ') < 3:
        return 4, H2_VERDICTS[4]
    if any(labels[c] == 'BELİRSİZ_V' for c in ev):
        return 5, H2_VERDICTS[5]
    return 6, H2_VERDICTS[6]


def report_h2(R, A, case, est, peaks, cid):
    rep = R.report_items(A, case, est)           # R-2: R_lo@0p025, R_hi@0p025 (sigma_hat vs sigma_pred, f)
    rep.update(R1=NA, R3=NA, R4='runs.*.vdc_report', R5=NA, R6=NA, R7=NA_R7)
    rep['tepe_mg_mc_020_030'] = {'%s@%s' % (s, st): peaks.get('%s_%s_%sus' % (cid, s, st)) for s, st in RUNS_H2}
    return rep


def latch_settling_p1(rd, cid, cal_dir):
    """S-8 branch only: vh94_run.latch_settling with the P-1 loader (R-7)."""
    import numpy as np
    d = os.path.join(rd, '%s_R_m_0p025us' % cid)
    if not os.path.isfile(os.path.join(d, 'capture.npz')):
        return None
    cap = load_capture_p1(d)
    t, y = cap['t'], cap['y']
    m = (t >= 0.20) & (t < 0.30)
    slope = float(np.polyfit(t[m], y[m], 1)[0]) if m.sum() > 2 else None
    cal = load_json(os.path.join(cal_dir, 'calibration_%s.json' % cid))
    x0 = cal['initial_state_independent_order']
    k = int(np.nonzero(t >= 0.30)[0][0])
    dv = float(np.hypot(cap['v0d_latched'][k] - x0[2], cap['v0q_latched'][k] - x0[3]))
    return dict(slope_pu_per_s=slope, v0_minus_x0_pu=dv)


# ---------------------------------------------------------------- analysis
def analyze(cfg, ctx):
    import vh94_run as R
    import analyze_vh94 as A
    guard, failed_dirs, env = pass0(cfg, R, A)
    ctx.log.append('X-0 ve bütünlük geçti')
    plan = load_json(cfg['plan'])
    pc = {c['id']: c for c in plan['cases']}
    rd = os.path.join(cfg['campaign'], 'runs')
    runs, dolgu, peaks = {}, {}, {}
    for cid in cfg['cases']:
        case = pc[cid]
        if cfg['hyp'] == 'H1' and case.get('status') != 'ok':
            continue
        for scen, step in cfg['runs']:
            runs[(cid, '%s@%s' % (scen, step))] = process_run(ctx, cfg, A, case, cid, scen, step, rd, guard, dolgu,
                                                              peaks)
    res = dict(run_id=ctx.run_id, plan_sha256=sha(cfg['plan']), cases={}, failed_attempt_dirs=failed_dirs)
    labels = {}
    if cfg['hyp'] == 'H1':                                                 # S-8 only (VH95-RA_b structure)
        signs = {}
        for cid in cfg['cases']:
            case = pc[cid]
            rec = dict(s_pred=case.get('sign_pred_D'), pilot_status=case.get('status'), runs={})
            signs[cid] = case.get('sign_pred_D') or 0
            if case.get('status') != 'ok':
                labels[cid] = 'NE'
                rec.update(label='NE', ne_reason='pilot')
                res['cases'][cid] = rec
                continue
            est = {}
            for scen, step in cfg['runs']:
                key = '%s@%s' % (scen, step)
                rec['runs'][key] = runs[(cid, key)]
                est[key] = runs[(cid, key)]
            lab, D, uD, thr = A.case_verdict(case['sign_pred_D'], est.get('F_m@0p025'), est.get('R_m@0p025'),
                                             est.get('F_m@0p05'), est.get('R_m@0p05'))
            rep = R.report_items(A, case, est)
            rep['R5'] = dict(D_pred_rotate_true=(case.get('rotate_alt') or {}).get('D_pred_at_m'),
                             pred_no_delay_m=(case.get('pred_nd') or {}).get('m'))
            rep['R6'] = R6_TEXT if cid == 'F2-0.65-0.20' else None
            try:
                rep['R7'] = latch_settling_p1(rd, cid, cfg['cal_dir'])
            except Exception as exc:  # noqa: BLE001
                rep['R7'] = dict(error='%s: %s' % (type(exc).__name__, exc))
            rec.update(label=lab, D=D, u_D=uD, threshold=thr, D_pred_d=case.get('D_pred_d'), report=rep)
            labels[cid] = lab
            res['cases'][cid] = rec
        row, verdict = A.campaign_verdict(labels, signs, True)
        res.update(labels=labels, decision_row=row, verdict=verdict, integrity_errors=[])
        return res, dolgu, env
    t = load_json(cfg['tasarim'])
    classes = {}
    for cid in cfg['selected']:
        tc = t['cases'][cid]
        classes[cid] = tc['cls']
        guclu = tc.get('h2_k') is not None and not tc.get('ne') and cid in cfg['cases']
        rec = dict(cls=tc['cls'], h2_k=tc.get('h2_k'), guc='GÜÇLÜ' if guclu else 'GÜÇSÜZ', runs={}, run_labels={})
        if not guclu:
            rec.update(label='NE', ne_reason='GÜÇSÜZ' if tc.get('h2_k') is None else 'tasarım NE')
            labels[cid] = 'NE'
            res['cases'][cid] = rec
            continue
        est = {}
        for scen, step in cfg['runs']:
            key = '%s@%s' % (scen, step)
            rec['runs'][key] = runs[(cid, key)]
            est[key] = runs[(cid, key)]
        rl = {s: h2_run_label(est['%s@0p025' % s], est['%s@0p05' % s]) for s in SCENARIOS}
        lab = h2_case_label(True, [est['%s@%s' % rs] for rs in RUNS_H2], rl['R_lo']['label'], rl['R_hi']['label'])
        rec.update(run_labels=rl, label=lab, report=report_h2(R, A, pc[cid], est, peaks, cid))
        labels[cid] = lab
        res['cases'][cid] = rec
    row, verdict = h2_verdict(labels, classes, True)
    par = {k: sum(1 for c, l in labels.items() if l == 'PARANTEZ' and classes[c] == k) for k in ('iyimser', 'tutucu')}
    res.update(hipotez='H2', labels=labels, classes=classes, decision_row=row, verdict=verdict, integrity_errors=[],
               parantez_sinif=par, h1_durum='%s: H1 kampanyası ve H1 hükmü yok (vh96_tasarim.json gates.H1)' % (
                   (t.get('gates') or {}).get('H1') or {}).get('result'),
               R_m_muhendislik_okumasi=NA_RM, kestirici_cagri=ctx.est_calls)
    return res, dolgu, env


# ---------------------------------------------------------------- output (§9.2)
def write_outputs(out, res, dolgu, env, log, code, hyp):
    os.makedirs(out)
    _write_text(os.path.join(out, 'sonuc.json'), json.dumps(res, indent=1, ensure_ascii=False, default=float))
    v = res.get('verdict', 'ABORT')
    if hyp == 'H2':
        lines = ['VH96 H2 hüküm: %s (satır %s)' % (v, res.get('decision_row'))]
    else:
        lines = ['VH96 S-8 sentetik H1 yolu (hüküm değildir): %s (satır %s)' % (v, res.get('decision_row'))]
    lines += ['%s: %s' % (c, l) for c, l in (res.get('labels') or {}).items()]
    _write_text(os.path.join(out, 'hukum.txt'), '\n'.join(lines) + '\n')
    _write_text(os.path.join(out, 'p1_dolgu.json'), json.dumps(dolgu, indent=1, ensure_ascii=False, default=float))
    try:
        import vh94_run as R
        vh94_pins = R.PINS
    except Exception as exc:  # noqa: BLE001
        vh94_pins = 'okunamadı: %s' % exc
    _write_text(os.path.join(out, 'girdi_pinleri.json'), json.dumps(
        dict(vh96_pins=PINS, vh96_pin_list_sha256=check_pins()[1], vh94_pins=vh94_pins,
             sabit=[SABIT_PATH, SABIT_SHA256], ortam=env), indent=1, ensure_ascii=False, default=str))
    _write_text(os.path.join(out, 'stdout.txt'), '\n'.join(log) + '\n')
    _write_text(os.path.join(out, 'stderr.txt'), res.get('hata', ''))
    _write_text(os.path.join(out, 'exit_code.txt'), str(code))
    sums = []
    for n in sorted(os.listdir(out)):
        p = os.path.join(out, n)
        if os.path.isfile(p) and n != 'SHA256SUMS':
            sums.append('%s  %s' % (sha(p), n))
    _write_text(os.path.join(out, 'SHA256SUMS'), '\n'.join(sums) + '\n')


def run_analysis(cfg, run_id, out):
    """Full --analyze body without the authorization gate (used by main and by the synthetic test)."""
    ctx = Ctx(run_id)
    env = {}
    try:
        res, dolgu, env = analyze(cfg, ctx)
        code = 0
    except Abort as ab:
        res = dict(run_id=run_id, hipotez=cfg['hyp'], verdict='ABORT', decision_row=1, abort=ab.args[0],
                   abort_detay=ab.args[1], kestirici_cagri=ctx.est_calls)
        dolgu = {}
        code = 4
    except Exception as exc:  # noqa: BLE001                        # VH96-B1-l
        import traceback
        res = dict(run_id=run_id, hipotez=cfg['hyp'], verdict='ABORT', decision_row=1, abort='HATA',
                   hata=traceback.format_exc(), kestirici_cagri=ctx.est_calls)
        dolgu = {}
        ctx.log.append('HATA %s' % exc)
        code = 1
    ctx.log.append('kestirici çağrısı: %d' % ctx.est_calls)
    ctx.log.append('verdict %s row %s' % (res['verdict'], res['decision_row']))
    if not env:
        try:
            env = environment()
        except Exception as exc:  # noqa: BLE001
            env = dict(hata=str(exc))
    write_outputs(out, res, dolgu, env, ctx.log, code, cfg['hyp'])
    return res, ctx, code


def real_cfg(campaign):
    return dict(hyp='H2', campaign=campaign, cases=CASES, selected=SELECTED, scenarios=SCENARIOS, runs=RUNS_H2,
                tasarim=TASARIM, plan=PLAN, pilot=PILOT, headroom=HEADROOM, cal_dir=CAL_DIR, env=ENV,
                input_pins=PINS, ledger_sha256=None)


def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding='utf-8')                    # VH96-B1-q
    except Exception:  # noqa: BLE001
        pass
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument('--check-only', action='store_true')
    g.add_argument('--verify', action='store_true')
    g.add_argument('--analyze', action='store_true')
    ap.add_argument('--run-id')
    ap.add_argument('--yetki')
    ap.add_argument('--campaign')
    ap.add_argument('--out')
    a = ap.parse_args(argv)
    if HERE not in sys.path:
        sys.path.insert(0, HERE)
    if a.check_only:
        bad = all_pin_failures()
        _, pin_list = check_pins()
        try:
            dp = design_checks(real_cfg(None))
        except Exception as exc:  # noqa: BLE001
            dp = ['okunamadı: %s' % exc]
        print(json.dumps(dict(pin_failures=bad, pin_list_sha256=pin_list, tasarim_denetimi=dp, ortam=environment()),
                         ensure_ascii=False, default=str))
        return 0 if not (bad or dp) else 1
    if not a.run_id or not a.yetki or not a.campaign:
        print('KAPI: --run-id, --yetki ve --campaign gerekli')
        return 2
    why = campaign_ok(a.campaign)
    if a.analyze:
        why = why or env_ok() or out_dir_ok(a.out, a.campaign)
    mode = 'analyze' if a.analyze else 'verify'
    why = why or verify_authorization(a.run_id, a.yetki, a.campaign, a.out, mode, real_cfg(a.campaign))
    if why:
        print(why)
        return 2
    if a.verify:
        print('yetki doğrulandı: %s' % a.run_id)
        return 0
    res, ctx, code = run_analysis(real_cfg(a.campaign), a.run_id, a.out)
    print('VH96 H2 hüküm: %s (satır %s); kestirici çağrısı %d' % (res['verdict'], res['decision_row'], ctx.est_calls))
    return code


if __name__ == '__main__':
    sys.exit(main())
