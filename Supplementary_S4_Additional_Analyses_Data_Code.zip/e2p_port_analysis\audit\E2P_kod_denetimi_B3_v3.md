# E2P kod denetimi (B3, v3 — revizyon turu 3/3, son tur) — e2p_run.py / e2p_static_check.py / e2p_synth_test.py
**"Claude cross-audit (same model family; not Codex, not human review)"**

- Tarih: 2026-11-08.
- Denetçi: taze bağlamlı B3 denetçi alt-ajanı (revizyon turu 3). B1 yazarı (ana oturum), B2 koşucusu, B3 v1 ve B3 v2 denetçisi değilim; önceki iki raporu yalnız girdi olarak okudum.
- Dayanak: D-286 (E2P), D-287 (SABİT v1.1 + B1); `tek-kosu-kapisi` §3 (revizyon: vN → vN+1 farkı, her değişiklik bir bulguya karşılık, gerileme yok), `bagimsiz-denetim` §2–§4.
- **Bu rapor hiçbir şeye yetki vermez.**

## §0 Kapsam, hash, körleme

**Doğrulanan hash'ler (Get-FileHash, VERIFIED; denetim sonunda yeniden hesaplandı, değişmedi):**

| Dosya | SHA256 | Pinle |
|---|---|---|
| `protokol\E2P_On_Kayit_v1.1_SABIT.md` | 134b47c123c59c3977e20e5869f86aa0188014326c250771683f3f0d3bbbbc80 | aynı |
| `denetim\E2P_kod_denetimi_B3_v2.md` | 6a32e856dce207e5c6cc8bfa2a94893ab989d9fbab6f7bb602280765e2294f07 | aynı |
| `kod\e2p_run.py` (v3) | 898cedd540ca4faade1c350d45ac7fc36dc5c36bed3e41c3107e84471d3a5c9b | aynı |
| `kod\e2p_static_check.py` (v3) | ee42a0fdf90d4b18da1c1fda17c080088d60f215758d9e28e207f78ea6234c72 | aynı |
| `kod\e2p_synth_test.py` (v3) | 210e752cc2b205efe647ed7c9f488a4e9f89cf2d74ad95cd2669be5b9a98d4ed | aynı |
| `kod\archive\e2p_run_v2_20261108.py` | ebef7e445da0c119793b1f71ddba2b5ce4e94b5047596dd83476cf9a4114ec67 | B3 v2'deki v2 hash'iyle aynı |
| `kod\archive\e2p_static_check_v2_20261108.py` | c2b694f8967b73e0c88bfa593aebef79c3be77b116bd954d8abd03242b8898f2 | aynı |
| `kod\archive\e2p_synth_test_v2_20261108.py` | e541e3dfc9aaaceb1c7b686cb5cc8469e7f741a396aedc8754de128802104586 | aynı |

**B2 v3 çıktıları** (`C:\Users\onura\Documents\SEGAN_G94_work\e2p\`): üç klasörde SHA256SUMS satırları dosyalardan yeniden hesaplandı ve **birebir tuttu**. Eski `_a` ve `_b` klasörleri yerinde.

| Klasör | exit | stdout | stderr.txt |
|---|---|---|---|
| E2PCHECK_20261108_c | 0 | CHECK-ONLY OK; pin_list_sha256 = 2b2f0286…1bfb (v2 ile aynı); script = 898cedd5…5c9b | 0 bayt |
| E2PSTATIC_20261108_c | 0 | S1–S12 GEÇTİ; SONUÇ: GEÇTİ; script hash 898cedd5…5c9b | 0 bayt |
| E2PSYNTH_20261108_c | 0 | SENTETİK: 237/237 geçti (v2: 221) | 0 bayt |

**Denetçinin yeniden koşuları** (`python -I -B`, akışlar ayrı): `--check-only` aynı pin_list_sha256 ve script hash'ini verdi, stderr 0 bayt, exit 0. Argümansız → "KAPI: kip yok", exit 2.

**Okunanlar:**
- Tam: B3 v2 raporu; üç v2 → v3 farkı (difflib); e2p_static_check.py v3; e2p_synth_test.py v3'ün 1–40, 351–761 satırları.
- Kısmi: SABİT v1.1 §5.1–§5.6, §6–§9 (126–465); e2p_run.py v3 1–140, 440–1252; y_common.py (tamamı, 125 satır; yalnız kod); yazarın `e2p_duman.py`'si (F2 kurulum kalıbı); B3 v2 denetçisinin `b3v2_f2.py`, `b3v2_static_mut.py`, `diff.py` ve `f2_v2.json` dosyaları.

**Açılmayanlar:** points.csv, selection.json, newton.jsonl, stage2.jsonl ve hiçbir TSV satırı (başlık dahil). Pin dosyaları yalnız `check_pins` tarafından hash için bayt olarak okundu. F2 denemesinde `Eng(..., sel={})` kullanıldı; selection.json bu denetimde ayrıştırılmadı. Hiçbir TSV noktasında motor çalıştırılmadı. **Kayıtlı ya da körlenmiş değer görülmedi.** Gerçek kip (`--run-id … --yetki`) koşulmadı. Hiçbir proje dosyası değiştirilmedi.

**Denetçi denemeleri** (kanıt düzeyi: denetçi sınaması; hükme girmez). Betikler ve çıktılar `C:\Users\onura\AppData\Local\Temp\claude\7036c16949a3edc6\cf9883b2-ca9a-425f-8c99-f0a89ce3065b\scratchpad\b3v3\` altında:
- (a) `diff.py` → `diff_e2p_run.txt`, `diff_e2p_static_check.txt`, `diff_e2p_synth_test.txt`.
- (b) `cov.py` → `cov\miss.txt`: sentetik testin `trace` ile satır kapsaması. Sonuç 237/237, FAIL yok.
- (c) `delta_cmp.py` → `delta_cmp_out.txt`: delta_son v2 ↔ v3, 5 C sınıfı × 9 A kaydı = 45 dal.
- (d) `static_mut.py` → `mut_out.txt`: S10/S11/S12 için 9 mutasyon. Değiştirilmiş kopya yalnız bu klasörde oluşturuldu, sonra silindi.
- (e) `b3v3_f2.py` → `f2_v3.json`: TSV dışı tek F2 üyesi (P = 0.65, G_R = 0.34). v3 ve arşivdeki v2 aynı süreçte koşuldu; çıktı f2_v2.json ile de karşılaştırıldı. Yaklaşık 45 s.

## §1 Özet tablo

| Madde | Konu | Hüküm |
|---|---|---|
| M1 | v2 → v3 farkı: her değişiklik bir B3v2-n'ye eşlenir, gerileme yok | PASS |
| M2 | B3v2-1…B3v2-7 karşılanma | PASS (yedisi de karşılandı; B3v2-3 ve B3v2-5'te birer küçük kalıntı) |
| M3 | Değişen bölgelerde SABİT §5.2/§5.4 uyumu (C_INHERIT, delta_son); A/B tutarlılığı | PASS |
| M4 | Sentetik testlerin SABİT §9 kapsamı; κ_eig yamasının kabul edilebilirliği | PASS (küçük: B3v3-2, B3v3-3, B3v3-4) |
| M5 | Statik S10–S12 (mutasyon) | PASS (9/9 mutasyon doğru sınıflandı) |
| M6 | F2 motor denemesi: v3 ile v2 arasında gerileme | PASS (C, A, B tam JSON'da v2 ile bit düzeyinde aynı) |
| M7 | B1 seçimleri (yalnız değişenler: b, h, i) | i kabul; b ve h metni eskimiş (B3v3-1, küçük) |

**Genel hüküm: ACCEPT.** Esaslı, yüksek ya da orta bulgu yok. B3 v2'nin iki orta bulgusu (B3v2-1, B3v2-2) tam karşılandı. Kalan altı bulgunun hepsi küçük ya da bilgi düzeyindedir ve "B4 öncesi bilinen sınırlar" olarak listelendi.

## M1 — v2 → v3 farkı (difflib; e2p_run +14/−11, static +27/−6, synth +116/−3)

| Değişiklik (v3 satırı) | Bulgu | Durum |
|---|---|---|
| e2p_run.py 1–8: v3 değişiklik listesi | B3v2-1, -4, -6, -7 | ✓ |
| e2p_run.py 59–60: B1-i yeni metni | B3v2-1 | ✓ |
| e2p_run.py 131: `C_INHERIT = ('NE-dağıtım', 'NE-kimlik', 'NE-hata')` | B3v2-1 | ✓ |
| e2p_run.py 608: delta_son, `crec.cls in C_INHERIT` | B3v2-1 (B tarafı) | ✓ |
| e2p_run.py 612–613: `dG_ex is None → arec.ne or 'NE-ref'`; v2'deki `ne in (NE-ref, NE-dağıtım, NE-kimlik)` satırı kaldırıldı | B3v2-4 | ✓ davranış eşdeğeri; aşağıda (c) |
| e2p_run.py 760: `_compute_A`, `crec.cls in C_INHERIT` | B3v2-1 | ✓ |
| e2p_run.py 1040–1043: erişilemez switch_k geri alma silindi | B3v2-6 | ✓ |
| static 1, 163–181: S10 geniş handler; compute_C'de try dışında setup_point, entry_checks ya da _decompose çağrısı yok | B3v2-5 | ✓ |
| static 184–186: S11 `ImportFrom numpy` ve `ast.walk` | B3v2-5 | ✓ |
| static 192–200: S12 check_engine_paths < prepare_dir | B3v2-5 | ✓ |
| synth 1: docstring | — | ✓ |
| synth 346: ΔG_son NE-hata beklentisi NE-ref'ten NE-hata'ya | B3v2-4 | ✓ |
| synth 561–562: C NE-hata beklentisi KİMLİK'ten NE-hata'ya | B3v2-1 | ✓ |
| synth 644–733: MA3, BadM, runA3; istisna tablosu, κ_eig ve B NE-hata testleri | B3v2-2, B3v2-1 | ✓ |
| synth 735–755: summaries testi | B3v2-3 | ✓ |

**Bulguya eşlenmeyen değişiklik yok.** Motor yolu kodunda (compute_C, _decompose, _compute_A ve _compute_B'nin hesap gövdeleri, main, write_outputs) değişiklik yok; fark yalnız yukarıdaki satırlardadır.

**Gerileme yok:**
- (a) **F2 denemesi (M6).** v3 ile v2 aynı girdide aynı C/A/B kaydını üretti; tam JSON eşitliği sağlandı (B'nin 21 adımı ve 231 alanı dahil). Kayıt, B3 v2 denetçisinin f2_v2.json'daki 31 alanıyla da aynı.
- (b) **Sentetik test.** v2'nin 221 testinin ikisi bilinçli olarak değişti (346, 562). Geri kalan 219 test v3'te de geçiyor (237/237).
- (c) **delta_son dal karşılaştırması** (`delta_cmp_out.txt`). 45 dalın 11'inde fark var ve hepsi amaçlanan farktır:
  - 9'unda C = NE-hata → v3'te NE-hata (B3v2-1). Bu dallardaki A kayıtlarının çoğu v3'te zaten oluşamaz, çünkü A da NE-hata alır.
  - 2'sinde A = NE-hata ve ΔG*_ex yok → v3'te NE-hata, v2'de NE-ref (B3v2-4).
  - NE-ref, REF-SANSÜR, NE-dağıtım, NE-denge, A'nın ΔG*_ex'li NE-hata'sı ve normal dal değişmedi. Kaldırılan v2 satırı yalnız `dG_ex` tanımsızken etkiliydi. Kodda NE-ref her zaman dG_ex atanmadan önce döner (e2p_run.py 774–786, dG_ex 788'de atanır); yani bu sadeleştirme davranışı değiştirmez.

## M2 — B3v2-1…B3v2-7 karşılanma tablosu

| B3 v2 | Durum | Yer ve kanıt |
|---|---|---|
| B3v2-1 (orta) A, C'nin NE-hata'sını devralmıyordu | **KARŞILANDI** | e2p_run.py 131, 760 (A), 608 (B; delta_son). B1-i 59–60. Test 561–562 (A → NE-hata), 731–732 (B → NE-hata). Trace: satır 761 iki kez çalıştı (C NE-dağıtım ve C NE-hata) |
| B3v2-2 (orta) §9.1 istisna tablosu ve κ_eig tanımsız yolu | **KARŞILANDI** | synth 704–730. Satır 1 → NE-ref (704; trace 776). Satır 3 → NE-hata (705; dış yakalayıcı 747). Satır 4 → dσ tanımsız (706–708; 819–820). Satır 6 → NE-hata (709). Satır 7, istisna → elenir ve kaydedilir (710–712; 850). Im dμ/dω = 0 → elenir ve kaydedilir (713–714; 854). Satır 9c → GİZLİ_HATA (716–717; 893–894). Satır 10 → rapor boş (718–719; 902). A kurulum istisnası → NE-hata (720). κ_eig tanımsız → EŞİK_GENİŞ, 9b değerlendirilemedi, EKSEN (721–730; 876–877). Ayrıntı: M4 |
| B3v2-3 (küçük) summaries testi | **KARŞILANDI** (küçük kalıntı: B3v3-4) | synth 735–755: dört test (sınıf sayıları, etiket ve S_D yorumu, EKSEN_alt, SX_aile, n_elenen_aday, C istatistikleri). jdump ile JSON'a çevirme yapılmıyor |
| B3v2-4 (küçük) A NE-hata (ΔG*_ex yok) → B'de NE-ref | **KARŞILANDI** | e2p_run.py 612–613; test 346 ve 733 |
| B3v2-5 (küçük) statik boşluklar | **KARŞILANDI** (B1-h metni güncellenmedi: B3v3-1) | static 163–200; mutasyon sınaması M5 |
| B3v2-6 (küçük) erişilemez geri alma kodu | **KARŞILANDI** | Silindi (fark 1040–1043). İstisna dalı korundu; trace 1041–1043 iki kez çalıştı (B3-2 testleri) |
| B3v2-7 (bilgi) k = 0'da (iv) ve SWITCH | **KARŞILANDI** (beyan) | e2p_run.py 8. B1 seçimi olarak değil, v3 değişiklik listesinde beyan edildi; yeterli |

## M3 — Değişen bölgelerde SABİT uyumu ve A/B tutarlılığı

### §5.2 (giriş denetimleri)

| SABİT §5.2 | Kod | Durum |
|---|---|---|
| "X-1 ve X-2 sonuçları C aşamasında hesaplanır; A ve B bunları C.jsonl'dan okur." | A: `_compute_A` 760 C sınıfını okur ve NE-dağıtım, NE-kimlik, NE-hata'yı devralır. B: delta_son 608 aynı kümeyi devralır | ✓ Giriş denetimi yapılmamış (C'de kurulum ya da X-1/X-2 istisnası) bir nokta artık A'da sınıf almaz |
| Geçmeyen nokta NE-kimlik; dağıtım reddi NE-dağıtım | compute_C 663–673 (değişmedi) | ✓ |
| C NE-ayrışım: giriş denetimi geçmiştir | C_INHERIT'te yok; A ve B hesaplanır | ✓ doğru: ayrışım hatası A ve B'nin girdisi değildir |

### §5.4 (ΔG_son ve kurulum istisnası)

| SABİT §5.4 | delta_son (606–614) | Durum |
|---|---|---|
| A sınıfı NE-dağıtım ya da NE-kimlik → B'de aynı NE | C kaynaklıysa 608–609; A'nın kendi dağıtım reddiyse (dG_ex yok) 612–613 | ✓ |
| NE-ref (REF-SANSÜR değil) → NE-ref | 612–613 (NE-ref her zaman dG_ex'siz) | ✓ |
| REF-SANSÜR → dG_max | 610–611 (dG_ex kontrolünden önce) | ✓ |
| NE-denge ve NE-hata dahil öteki durumlar → ΔG*_ex | 614 (dG_ex tanımlıysa) | ✓ |
| "Kurulum (dağıtım, X-1) istisnası NE-hata'dır" | C'de NE-hata → B NE-hata (608). A'da ΔG*_ex yoksa NE-hata → B NE-hata (613). B'nin kendi kurulum istisnası → dış yakalayıcıda NE-hata (943–949) | ✓ ΔG*_ex tanımsızken "→ ΔG*_ex" dalı uygulanamaz; NE-hata tek tutarlı etikettir |

### A/B tutarlılığı (C sınıfı → A → B)

| C | A | B |
|---|---|---|
| OK / NE-ayrışım | hesaplanır | delta_son'a göre; B ayrıca kendi entry_checks'ini yapar (964) |
| NE-dağıtım | NE-dağıtım | NE-dağıtım |
| NE-kimlik | NE-kimlik | NE-kimlik |
| NE-hata | **NE-hata** (v2: A hesaplanıyordu) | NE-hata |

v2'deki A–B tutarsızlığı (A KİMLİK alabilir, B NE-hata) giderildi. B'nin kendi kurulum ve X-1 denetimi korunuyor (958–968); deterministik hesapta C ile aynı sonucu verir.

**§5.6 / §7 etkisi:** NE-hata A'da NE-* sayılır (decide_A, değerlendirilebilirlik 697); eşik ve karar sırası değişmedi.

## M4 — Sentetik test kapsamı (SABİT §9) ve κ_eig yaması

**Trace sonucu** (`cov\miss.txt`; e2p_run.py'nin değişen ve A/B motor bölgeleri 606–614, 742–921, 941–1047). Çalışmayan satırlar yalnız şunlar:
- 766–768: A'nın kendi dağıtım reddi → NE-dağıtım;
- 918–919: ratio_dsig istisnası;
- 960–962 ve 966–968: B'nin kendi dağıtım reddi ve kendi X-1/X-2 başarısızlığı.

Bu dallar SABİT §9'da adıyla geçmez. C aynı deterministik çağrıları önce yaptığı için pratikte erişilmezler (B3v3-3).

**§9.1 "istisna tablosunun her satırı":**

| Satır | Test | Durum |
|---|---|---|
| 1 → NE-ref | 704 | ✓ |
| 2 → NE-denge | 549 (v2) | ✓ |
| 3 → NE-hata | 705 | ✓ (istisna J_ex kurulumunda tetikleniyor; B3v3-2) |
| 4 → dσ tanımsız | 706–708 | ✓ |
| 6 → NE-hata | 709 | ✓ |
| 7 → aday elenir (ve kaydedilir) | 710–712; Im dμ/dω = 0: 713–714 | ✓ |
| 9a → TARAMA bulunamadı | MA'nın rho_at istisnası (v2 testlerinin çoğu) | ✓ |
| 9b → 9B_HATA, EKSEN | 541 (v2) | ✓ |
| 9c → GİZLİ_HATA | 716–717 | ✓ |
| 10 → rapor boş | 718–719 | ✓ |
| 11 → NE-hata | yok | i2_ok saf karşılaştırmadır; istisna pratikte oluşamaz (B3v3-3) |
| 12 → NE-hata | 555–556 (v2) | ✓ |
| listelenmeyen adım (kurulum) → NE-hata | 720 | ✓ |

**§9.1 "κ_eig tanımsız → EŞİK_GENİŞ ve 9b değerlendirilemedi (R3-4)":** saf parçalar (threshold 71; kappa_eig koruması 96–97) ve compute_A kablolaması (721–730) birlikte sınanıyor. ✓

**κ_eig yamasının kabul edilebilirliği — KABUL.** Gerekçe:
1. **Yamalanan hedef.** Yamalanan sınanan modülün (e2p_run) kendi yardımcısıdır, pinli motor modülü değildir. `tek-kosu-kapisi` §1'deki "pinli modüllere yama yok" yasağı ve statik S7 koşu betiğini kapsar; sentetik testin yerel değiştirmesi bu yasağın konusu değildir.
2. **Geri alma.** Değişim `try/finally` ile geri alınıyor (722–727). Sonraki testler özgün işlevi kullanıyor.
3. **İki halkanın ayrı sınanması.** Zincirin iki halkası ayrı sınanıyor:
   - Koruma işlevi: el yapımı kusurlu matris `[[0, 1], [0, 0]]` → `κ_eig None` (96–97). Matris gerçel Jordan bloğudur.
   - Kablolama: `kappa_eig` None verdiğinde _compute_A'nın 9b'yi "değerlendirilemedi" sayması, EŞİK_GENİŞ koyması ve sınıfı EKSEN vermesi (721–730; trace 876–877).
   Birleşik yolu doğal girdiyle tetiklemek gerçekten güvenilir değil. Gerçel Jordan bloğu ω_ss = 0 verir ve erken ω0'a düşer. Karmaşık Jordan bloğunda yuvarlama |yᵀv|'yi 1e-14 korumasının üstünde tutar (B3 v2 R-2'de öngörüldü; testin 721. satırındaki yorum aynı).
4. **Elle kurulan beklenti.** Beklenen değerler elle kurulmuş; test özdeğer hesabıyla beklenti üretmiyor.

Sınır: test, _compute_A'nın `kappa_eig`'i çağrı anında modül adından çözmesine dayanır (802). Bu Python'un standart davranışıdır; kod `from … import` ile bağlamıyor.

**Yeni sahte motor testlerinin ilgili dalı gerçekten çalıştırdığı** trace ile doğrulandı: 747 (dört dış yakalama: J_ex, crossings, kurulum, adım 12), 776, 819–820, 850, 854, 876–877, 893–894.

## M5 — Statik S10–S12 (mutasyon sınaması, `mut_out.txt`)

| Mutasyon | Beklenen | Sonuç |
|---|---|---|
| özgün | GEÇTİ | GEÇTİ ✓ |
| compute_A `except ValueError` | S10 KALDI | KALDI ✓ (v2'de GEÇTİ idi) |
| compute_B `except KeyError` | S10 KALDI | KALDI ✓ |
| compute_C ikinci try dar | S10 KALDI | KALDI ✓ |
| compute_C setup_point try dışında, iki try kalır | S10 KALDI | KALDI ✓ (v2'de GEÇTİ idi) |
| compute_C entry_checks try dışında | S10 KALDI | KALDI ✓ |
| `from numpy import` ortam atamasından önce | S11 KALDI | KALDI ✓ (v2'de GEÇTİ idi) |
| OPENBLAS/MKL ataması numpy importundan sonra | S11 KALDI | KALDI ✓ |
| check_engine_paths prepare_dir'den sonra | S12 KALDI | KALDI ✓ (v2'de denetlenmiyordu) |
| check_engine_paths silindi | S12 KALDI | KALDI ✓ |

**Yanlış pozitif yok:** S1–S12 özgün v3'te GEÇTİ (B2 ile aynı).

**Bilinen ince sınırlar (bulgu değil):**
- S10'un `broad`'u handler'lardan birinin geniş olmasını yeterli sayar.
- `except (Exception,)` demet biçimi yanlış KALDI verir; güvenli yöndedir.
- S12 kontrol akışına değil, satır sırasına bakar.
Mevcut kod bu biçimlerin hiçbirini kullanmıyor.

## M6 — F2 motor denemesi (TSV dışı, P = 0.65, G_R = 0.34; `f2_v3.json`)

| Sınama | Sonuç |
|---|---|
| v3 C/A/B ile v2 C/A/B, aynı süreçte, tam JSON | C, A, B üçü de **eşit**; farklı anahtar yok |
| v3 ile B3 v2 denetçi çıktısı (f2_v2.json) | 31 alanın hepsi aynı: satır, C (sınıf, κ, κ_Cb, κ_Co, κ_dış, Σκ, ν, flip1), A (sınıf, ΔG*_ex, κ_eig, thr, bayraklar, I1, I2, F_ex, tol*, κ_ex, δ_tab, δ_tab,pred, elenen, n_sahte, ratio_dsig), B (sınıf, switch_k, kopuk_k, ne_denge_k, ΔG_son), n_steps = 21, n_tv = 21 |
| Sınıflar | C OK, A KİMLİK, B TEK_DAL |
| Süre (v3) | C 0.03 s, A 3.1 s, B 18.9 s |

v1 → v2 → v3 boyunca bu üye için motor yolu çıktısı bit düzeyinde aynı kaldı. **Gerileme yok.**

## M7 — B1 seçimleri (yalnız v3'te etkilenenler)

| Seçim | Karar | Gerekçe |
|---|---|---|
| b X-1/X-2 C'de; A ve B yeniden kullanır | Kabul (metin eskimiş: B3v3-1) | Kod artık NE-hata'yı da devralıyor; 46–48'deki parantez yalnız NE-dağıtım ve NE-kimlik diyor |
| h compute_A/B/C en dışta try | Kabul (metin eskimiş: B3v3-1) | compute_C iki geniş try içeriyor; S10 bunu doğru denetliyor |
| i C'nin NE-dağıtım/NE-kimlik/NE-hata sınıfları A ve B'ye devralınır | **Kabul** (v2'de A için red) | §5.2 "A ve B C.jsonl'dan okur" ile uyumlu; A/B tutarlı (M3) |
| a, c–g | Kabul (değişmedi) | B3 v2'deki gerekçeler geçerli |

## Bulgular (hepsi küçük ya da bilgi; B4 öncesi bilinen sınırlar)

### B3v3-1 (küçük) — B1-b ve B1-h metinleri v3 davranışını yansıtmıyor
- **Sorun.** B1-b'nin parantezi (e2p_run.py:46–48) "NE-dağıtım ve NE-kimlik C'den devralınır" diyor. Oysa kod (131, 608, 760) ve B1-i (59–60) NE-hata'yı da devralıyor. B1-h (57–58) hâlâ "compute_A/B/C'nin her biri en dışta try" diyor; B3 v2 R-5'in son maddesi ("compute_C: kurulum ve ayrışım iki try") uygulanmamış.
- **Neden önemli.** Yalnız belgeleme tutarlılığı. Davranış doğru ve test ediliyor.
- **R-1 (sonraki sürüme; B4'ü engellemez).** B1-b parantezini "NE-dağıtım, NE-kimlik ve NE-hata C'den devralınır" yapın. B1-h'yi "compute_A/B tek dış try; compute_C kurulum ve ayrışım için iki try" diye düzeltin. Betik hash'i değişeceği için bu düzeltme ancak yeni bir tur açılırsa yapılmalıdır. Bu turda **yapılmamalıdır** (tur sınırı 3/3).

### B3v3-2 (küçük) — "A istisna 3" testi J_ex kurulumunda tetikleniyor; SABİT metni J_ex'i adım 2'de sayıyor
- **Sorun.** Test synth:705, `jac(…, G_ex)` istisnasını kullanıyor (e2p_run.py:799). SABİT §5.3 ise J_ex ve J_exG'yi adım 2'nin metninde sayar; istisna tablosunda adım 2'nin sonucu NE-denge'dir. Kod bu istisnayı dış yakalayıcıda NE-hata yapar (746–750). Adım 3'ün kendisi (kappa_eig ve ‖A‖₂, 802–803) ayrı bir istisnayla sınanmıyor; aynı dış yakalayıcıya gider.
- **Neden önemli.** Yalnız etiket. NE-denge ile NE-hata ikisi de NE-*'dır. decide_A ve değerlendirilebilirlik bunları birlikte sayar. B tarafında ikisinde de ΔG*_ex tanımlıdır, dolayısıyla delta_son (612–614) aynı ΔG_son'u verir. Hüküm değişmez. Adım 2'nin NE-denge'si doğal okumayla `path_point` (denge) başarısızlığına aittir; Jacobian istisnasının NE-hata sayılması savunulabilir. Bu bir yorum seçimidir ve v1/v2'den devralınmıştır.
- **Bilinen sınır (B4/B5).** x_ex bulunduktan sonraki Jacobian istisnaları A raporunda NE-hata etiketiyle görünür. B5 bunu NE-denge'den ayrı sayar.

### B3v3-3 (küçük) — Pratikte erişilmeyen birkaç dal sentetik testte çalışmıyor
- **Sorun.** Trace'te çalışmayan dallar: A'nın kendi dağıtım reddi (e2p_run.py:766–768), B'nin kendi dağıtım reddi (960–962) ve kendi X-1/X-2 başarısızlığı (966–968), ratio_dsig istisnası (918–919). §5.3 tablo satırı 11 (I2 istisnası → NE-hata) için de test yok.
- **Neden önemli değil.** Bu dalların hiçbiri SABİT §9'da adıyla zorunlu değildir. Hepsi, C'nin önce yaptığı aynı deterministik çağrının farklı sonuç vermesini gerektirir. Satır 11 saf bir karşılaştırmadır (i2_ok 551–553) ve dış yakalayıcıya düşer. Kodları okundu; etiketleri SABİT'e uygun.
- **Bilinen sınır.**

### B3v3-4 (küçük) — summaries testi JSON'a çevirmeyi ve S_P'deki NE kayıtlarını içermiyor
- **Sorun.** synth:735–755, B3 v2 R-3'ün önerdiği jdump ile JSON'a çevirmeyi yapmıyor. Test kümesinde S_P'nin iki kaydı da (P1 KİMLİK, P2 EKSEN) NE değil. tab_summary'nin S_P'deki NE-* kayıtlarıyla (delta_tab yok) davranışı burada sınanmıyor.
- **Neden düşük risk.**
  - tab_summary (484–501) ve summaries (1068–1101) yalnız `.get` ya da her kayıtta bulunan anahtarları (`cls`, `flags`) kullanır.
  - `int(rows_by_id[i]['ref_sign'])` güvenlidir, çünkü S_P ve S_D tanım gereği ref_sign ∈ {±1} ister (y_common.py:52; e2p_run build_sets).
  - Çıktı `clean` ile yazılır (1119).
  - B3 v2 denetçisi summaries'i NE kayıtlı sentetik verilerle çağırdı ve çökmedi.
- **Bilinen sınır.** Bu yoldaki bir istisna 2–2.5 saatlik koşunun sonunda CRASH (exit 1) olur. `--devam` aşamaları atlar, yalnız özetleri yeniden dener. B4 operatörü bunu bilmelidir.

### B3v3-5 (küçük) — Test hijyeni
- MA3'ün `jordan` parametresi ve 660–663'teki dalı hiç kullanılmıyor (ölü test kodu).
- synth:733, synth:346 ile aynı iddiayı ikinci kez sınıyor.
- Zararsız.

### B3v3-6 (bilgi) — B3v2-7 v3 değişiklik listesinde beyan edildi
k = 0'da (iv) ve SWITCH'in değerlendirilmemesi e2p_run.py:8'de beyan edilmiş. "Yazar seçimleri" bölümüne ayrı bir B1 maddesi olarak eklenmesi daha düzenli olurdu. Davranış B3 v2'de incelendi ve etkisi pratikte sıfır.

## Düzeltme listesi

| ID | Öncelik | Yer | Düzeltme |
|---|---|---|---|
| R-1 | küçük, sonraki sürüm | e2p_run.py 46–48, 57–58 | B1-b ve B1-h metinleri (yeni tur açılmadıkça yapılmaz) |
| R-2 | bilgi | B5 raporu | Adım 2 sonrası Jacobian istisnası NE-hata etiketiyle raporlanır |
| R-3 | bilgi | — | Pratikte erişilmeyen dallar (B3v3-3) |
| R-4 | bilgi | B4 talimatı | summaries çöküşü olursa `--devam` yalnız özeti yeniden dener |
| R-5 | küçük, sonraki sürüm | synth 647, 660–663, 733 | Ölü parametre ve yinelenen test |

## B4 öncesi bilinen sınırlar (koşuyu engellemez)
1. B1-b ve B1-h docstring metinleri v3 davranışının gerisinde (B3v3-1).
2. Adım 2 sonrası Jacobian istisnası NE-hata etiketi alır; hükme etkisi yok (B3v3-2).
3. A/B'nin kendi dağıtım ve X-1 dalları, ratio_dsig istisnası ve tablo satırı 11 sentetik testte çalışmıyor; pratikte erişilmez (B3v3-3).
4. summaries uçtan uca JSON'a çevirme ve S_P'de NE kaydı ile sınanmadı; düşük risk (B3v3-4).
5. B3 v2'den taşınanlar:
   - WHEA olay sayımı operatöre aittir (B1-a). Sayım başta ve sonda konsol klasörüne yazılmalıdır.
   - Konsol yakalaması `<run_id>_konsol/` altına, stdout ve stderr ayrı yönlendirilerek alınmalıdır.

## Çözülmemiş engeller (koşuyu engelleyenler)
Yok.

## Genel hüküm: **ACCEPT**

En esaslı bulgu küçük düzeydedir (B3v3-1…B3v3-5). B3 v2'nin iki orta bulgusu tam karşılandı:
- **B3v2-1.** A ve B, C'deki kurulum ve X-1/X-2 istisnasını tutarlı biçimde NE-hata olarak devralıyor. Bu SABİT §5.2 ("A ve B C.jsonl'dan okur") ve §5.4 ile uyumludur.
- **B3v2-2.** §9.1'in istisna tablosu satırları ve κ_eig tanımsız yolu compute_A üzerinden sınanıyor. Trace bu dalların gerçekten çalıştığını gösteriyor.

κ_eig'in test içinde geçici olarak değiştirilmesi kabul edilebilir. Değiştirilen pinli bir motor modülü değil, sınanan modülün kendi yardımcısıdır; değişim finally ile geri alınıyor ve koruma işlevi ayrıca doğrudan sınanıyor.

Statik S10–S12 dokuz mutasyonun dokuzunu da doğru sınıfladı; yanlış pozitif yok. v2 → v3 farkındaki her değişiklik bir B3v2 bulgusuna eşleniyor; motor yolu kodu değişmedi. F2 üyesinde v3 ve v2 C/A/B çıktıları tam JSON'da bit düzeyinde aynı. Gerileme yok.

B2 v3 çıktıları (CHECK, STATIC S1–S12, SYNTH 237/237) ve SHA256SUMS dosyaları doğrulandı.

Toplam 6 bulgu: 0 esaslı, 0 yüksek, 0 orta, 5 küçük, 1 bilgi.

**"Claude cross-audit (same model family; not Codex, not human review)"**
