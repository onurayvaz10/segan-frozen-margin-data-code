# VH94 — Sonuç raporu (B5)

2026-10-29 · Claude Code (Opus 5.5), ana oturum (B1 yazarı; B4'ü ayrı oturum `vh94-b4` yürüttü) · SABİT v1.3 (ae8628bd…999d) · yetki `protokol/VH94_yetki_VH94_20261029_a.json` (07dd0d94…dcec)

## Mühür ve kayıt
- Kampanya `SEGAN_G94_work\vh94\out\VH94_20261029_a`; analiz `analysis_VH94_20261029_a\` SHA256SUMS sha256 1db3483710cfe74a9b4c08f9594ebfa65cd01c6390ae3c58fa6b64402eeb328e; bütünlük hatası yok.
- Kampanya çıkış kodu 2. Ledger: A2-F00993'ün dört koşusu (R_m, F_m × 50/25 ns) kaydedildi; ardından A2-F01921 50 ns modelinin denetim adımında (20:33:22) yeni bir WHEA olayı (System, WHEA-Logger, Id 19 = düzeltilmiş donanım hatası, 20:33:21) görüldü → `stop/new_whea`. SABİT §1 S-b gereği kampanya kesin olarak bitti; yeniden başlatılmadı. 24 koşunun 4'ü yapıldı.

## Önceden kayıtlı hüküm (§8, satır sırasıyla)
`hukum.txt`: **NOT_EVALUABLE (satır 2)** — değerlendirilebilir vaka 1 < 4. A2-F00993: AGREE; diğer beş vaka NE (koşu yok).

H1 hakkında bir hüküm verilemez. Tek vaka sonucu yalnız rapor değeridir.

## Yalnız rapor (hükmü değiştirmez)
| Koşu | σ̂ (s⁻¹) | σ_pred | f̂ (Hz) | R² | Not |
|---|---|---|---|---|---|
| R_m 25 ns | +12.22 | +10.97 | 87.7 | 0.999 | 0.05 pu'da kesildi (pencere 0.149 s) |
| R_m 50 ns | +12.19 | +10.97 | 87.7 | 0.998 | |
| F_m 25 ns | −10.92 | −9.72 | 77.4 | 0.60 | |
| F_m 50 ns | −4.91 | −9.72 | 76.0 | 0.69 | 25 ns ile 6.0 s⁻¹ fark |

- A2-F00993 (iyimser): D = −23.13 s⁻¹ (öngörü −20.69); u_D = 6.01; eşik max(3·u_D, 0.2) = 18.02 → AGREE. Yön, anahtarlamalı modelde ortalama modelin öngördüğü yöndedir (R_m kararsız, F_m kararlı).
- **Sayısal duyarlılık bulgusu:** F_m'de 25 ns ile 50 ns arasında σ̂ 6.0 s⁻¹ farklı (R_m'de 0.03). Belirsizliği bu fark belirliyor; eşiği 18 s⁻¹'ye çıkarıyor. Donmuş öykünmenin daha kaba adımda farklı sönüm vermesi açıklanmamış bir sayısal etkidir (INFERENCE: enjeksiyon referansı v2eq'in θ ile adım başına güncellenmesi ya da 50 ns'de anahtarlama çözünürlüğü). Kuru koşu bu etkiyi içermez.
- Kuru koşu S6b'de bildirilen yanlılıkla tutarlı olarak F_m 25 ns σ̂ öngörüden 1.2 s⁻¹ daha negatif; R_m σ̂ öngörüden 1.2 s⁻¹ daha pozitif (gecikme modeli ile Typhoon arasındaki fark; INFERENCE).
- R-7 kilit oturması ve öteki rapor kalemleri `sonuc.json` içindedir.

## Kanıt düzeyi ve iddia
E4 tavanı korunur. Makaleye yazılabilecek en güçlü ifade: "Önceden kayıtlı Typhoon VHIL kampanyası bir donanım (WHEA) olayıyla bir vaka sonra durdu ve değerlendirilemez kaldı; tamamlanan tek iyimser vakada eşleşik sönüm farkı öngörülen yöndeydi (rapor değeri)." Genel bir anahtarlamalı-model doğrulaması iddia edilemez.

## Kullanıcıya sunulan seçenekler (protokol bu turda gevşetilmez)
1. **Olduğu gibi raporla:** NOT_EVALUABLE + tek vaka rapor değeri + sayısal duyarlılık bulgusu, sınırlılık olarak makale §7.5'e.
2. **Yeni ön-kayıtlı kampanya (VH95, yeni run_id):** aynı 24 koşu; WHEA kuralı yeniden tanımlanır (ör. Id 19 düzeltilmiş hatalar kaydedilir ama durdurmaz; durdurma yalnız düzeltilemez hatalarda) ve bir koşunun bit-düzeyi tekrarıyla veri bütünlüğü sınanır. Bu değişiklik bu sonuç görüldükten sonra yapılacağı için çatallanma olarak beyan edilir ve yeni denetimden geçer. Ayrıca F_m adım duyarlılığı açıklanmalı (gerekirse 12.5 ns ek düzeyi), aksi halde u_D büyük kalır.
3. **Donanım kontrolünden sonra aynı kurallarla yeniden koşu** (yeni run_id): makine WHEA üretmeye devam ederse yine durur.
