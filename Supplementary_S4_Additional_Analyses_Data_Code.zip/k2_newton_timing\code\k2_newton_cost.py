"""K-2 (danışman notu N-16): Newton-κ kestiricilerinin baştan (from scratch) süresi, Tablo 9'un öteki satırlarıyla aynı temelde.

Betimsel, hüküm dışı bir süre ölçümüdür; hipotez sınamaz. Süreler makineye bağlıdır.

Aynı temel (Tablo 9 başlığı ve p12_cost.py, gelistirme91/kod):
  - Noktalar: p12'nin N2/N3/N5 (A2, B2, C) kıyas noktaları. Her ailede kimlik sırasıyla κ ≥ τ olan ilk iki Sobol noktası
    ve κ ≤ −τ olan ilk nokta, toplam 9. Kimlikler p12 kaydıyla eşleşmezse betik durur.
  - Her kestirici dağıtım dahil baştan hesaplanır: bir ısınma, ardından 5 tekrar; duvar saati medyanı.
  - Süreç verimlilik çekirdeklerine bağlanır, düşük öncelik, tek BLAS iş parçacığı (ext_common.lower_priority).
Kestiriciler:
  - p12'deki altı kestirici (frozen, first_order, second_order, secant_1, secant_2, reference) yeniden ölçülür. Amaç,
    makine durumunun kayması için denetim (2026-10-26 kaydına karşı).
  - newton_1: first_order + 1 denge (dG1 = dGf/(1−κ0)) + tarama + κ(dG1) → N1. κ-başlatmalı sekant N1s aynı
    niceliklerden çıkar, maliyeti aynıdır.
  - newton_2: newton_1 + 1 denge (N1) + tarama + κ(N1) → N2.
  Newton adımları gelistirme92/kod/y2_newton.py içindeki `evaluate` işleviyle aynen yapılır. Tek fark: κ0 ve dGf
  mühürlü kayıttan okunmaz, baştan hesaplanır.
Önceden yazılmış raporlama kuralı (sonuçtan önce):
  - Tablo 9 süre sütunu = 9 noktanın medyanlarının en küçüğü–en büyüğü, bir ondalık.
  - Newton-κ bir adım ve κ-başlatmalı sekant satırları newton_1 aralığını, iki adım satırı newton_2 aralığını alır.
  - Kayma denetimi: yeniden ölçülen her p12 kestiricisi için yeni/eski medyan oranlarının medyanı yazılır. Oranlardan
    biri [0.85, 1.15] dışındaysa, dipnotta Newton satırlarının ayrı bir oturumda ölçüldüğü ve öteki satırların aynı
    oturumdaki aralığı (S2) belirtilir. Tablo 9'un mevcut değerleri değiştirilmez.
  - Değer denetimi: N1 ve N2, Y2 mühürlü kaydıyla (newton.jsonl), p12 değerleri p12_cost.csv ile karşılaştırılır.
    Bağıl fark > 1e-6 ise kayıt düşülür; süre ölçümü yine raporlanır.
Kullanım: python -I -B k2_newton_cost.py <çıktı_klasörü>  (klasör var olmamalı)
"""
import csv
import json
import os
import platform
import sys
import time

os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['MKL_NUM_THREADS'] = '1'

G92_KOD = r'C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme92_20261026\kod'
G92_S1 = r'C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme92_20261026\girdi\development_20261026'
P12_CSV = r'C:\Users\onura\Documents\Codex\2026-10-27\ma\work\review92\supplement\development_20261026\out\p12_cost.csv'
Y2_JSONL = r'C:\Users\onura\Documents\Codex\2026-10-27\ma\work\review92\supplement\p92_20261026\out\y2\newton.jsonl'
os.environ['G92_S1'] = G92_S1
sys.path.insert(0, G92_KOD)

import numpy as np  # noqa: E402
import ext_common as C  # noqa: E402
import ext_engine as X  # noqa: E402
import y2_newton as Y  # noqa: E402

REPS = 5
P12_IDS = ['A2-00042', 'A2-00054', 'A2-03486', 'B2-00018', 'B2-00030', 'B2-F00433', 'C-00020', 'C-00033', 'C-01685']


def frozen(lay, G, P):
    d = X.dispatch(lay, P, G, tol=1e-12)
    x0, refs = d['x'], d['refs']
    sb = lay.sysd['shed_bus']
    Jm = X.jac(lay, x0, refs, G)
    th = float(np.arctan2(x0[lay.ix[f'V{sb}:I']], x0[lay.ix[f'V{sb}:R']]))
    fm = X.frozen_margin(lay, Jm, th, G[sb])
    return dict(x0=x0, refs=refs, th=th, fm=fm, value=fm['rho'])


def first(lay, G, P):
    f = frozen(lay, G, P)
    k = X.kappa_hat(lay, f['x0'], f['refs'], G, f['th'], f['fm'])
    f.update(k=k, value=f['fm']['rho'] / (1 - k['kappa']))
    return f


def second(lay, G, P):
    f = first(lay, G, P)
    sb = lay.sysd['shed_bus']
    h = 1e-3 * f['fm']['rho']
    rr = {}
    for sg in (1, -1):
        Gk = G.copy()
        Gk[sb] -= sg * h
        xs = X.newton_fixed_refs(lay, f['x0'], f['refs'], Gk)[0]
        rr[sg] = X.rho_at(lay, xs, f['refs'], G, f['th'], f['fm'])['rho']
    kfd = (rr[1] - rr[-1]) / (2 * h)
    curv = (rr[1] - 2 * f['fm']['rho'] + rr[-1]) / h ** 2
    f['value'] = C.quad_root(f['fm']['rho'], kfd, curv)
    return f


def secant(lay, G, P, n):
    f = frozen(lay, G, P)
    dGf = f['value']
    F1, _ = C.F_min_at(lay, f['x0'], f['refs'], G, dGf, f['th'])
    s = dGf * dGf / (dGf - F1)
    if n == 2:
        F2, _ = C.F_min_at(lay, f['x0'], f['refs'], G, s, f['th'])
        s = s - F2 * (s - dGf) / (F2 - F1)
    f['value'] = s
    return f


def reference(lay, G, P):
    f = frozen(lay, G, P)
    sb = lay.sysd['shed_bus']
    dGf = f['value']
    R = X.reference_margin(lay, f['x0'], f['refs'], G, min(G[sb], 2 * dGf), 0.01 * dGf, tol=1e-9, alpha_tab='rel')
    f['value'] = R['dGt']
    return f


def newton(lay, G, P, n):
    """From scratch: dispatch, frozen margin, κ0, then n Newton-κ steps with y2_newton.evaluate."""
    f = first(lay, G, P)
    dGf, k0 = f['fm']['rho'], f['k']['kappa']
    f['value'] = None
    if not k0 < 1:
        f['status'] = 'kappa0 >= 1'
        return f
    dG1 = dGf / (1.0 - k0)
    e1 = Y.evaluate(lay, f['x0'], f['refs'], G, dG1, f['th'])
    if e1['status'] != 'ok' or not e1['kappa'] < 1:
        f['status'] = 'step1 ' + e1['status']
        return f
    N1 = dG1 + e1['F'] / (1.0 - e1['kappa'])
    f['N1'] = N1
    f['N1s'] = dG1 - e1['F'] * dG1 / (e1['F'] - dGf)
    f['value'] = N1
    f['status'] = 'ok'
    if n == 2:
        e2 = Y.evaluate(lay, e1['x'], f['refs'], G, N1, f['th'])
        if e2['status'] != 'ok' or not e2['kappa'] < 1:
            f['status'] = 'step2 ' + e2['status']
            f['value'] = None
            return f
        f['value'] = N1 + e2['F'] / (1.0 - e2['kappa'])
    return f


ESTS = [('frozen', frozen), ('first_order', first), ('second_order', second),
        ('secant_1', lambda l, g, p: secant(l, g, p, 1)), ('secant_2', lambda l, g, p: secant(l, g, p, 2)),
        ('reference', reference), ('newton_1', lambda l, g, p: newton(l, g, p, 1)),
        ('newton_2', lambda l, g, p: newton(l, g, p, 2))]


class Counter:
    names = ('newton_fixed_refs', 'jac', 'crossings', 'spectral_abscissa')

    def __enter__(self):
        self.n = {k: 0 for k in self.names}
        self.orig = {k: getattr(X, k) for k in self.names}
        for k in self.names:
            def wrap(*a, _k=k, **kw):
                self.n[_k] += 1
                return self.orig[_k](*a, **kw)
            setattr(X, k, wrap)
        return self

    def __exit__(self, *a):
        for k in self.names:
            setattr(X, k, self.orig[k])


def points():
    sel = json.loads(open(os.path.join(G92_S1, 'out', 'tsv', 'selection.json'), encoding='utf-8').read())['points']
    pts = []
    for s in ('A2', 'B2', 'C'):
        sob = sorted([r for r in sel if r['system'] == s and r['source'] == 'sobol'], key=lambda r: r['id'])
        pos = [r for r in sob if r['kappa'] >= C.TAU_K][:2]
        neg = [r for r in sorted([r for r in sel if r['system'] == s], key=lambda r: r['id']) if r['kappa'] <= -C.TAU_K][:1]
        for r in pos + neg:
            pts.append((s, r['id'], C.BUILDERS[s](r)))
    ids = [p[1] for p in pts]
    if ids != P12_IDS:
        raise SystemExit('DUR: nokta kimlikleri p12 ile eşleşmiyor: %s' % ids)
    return pts


def main():
    out = sys.argv[1]
    os.makedirs(out, exist_ok=False)
    C.lower_priority()
    p12 = {(r['id'], r['estimator']): r for r in csv.DictReader(open(P12_CSV, encoding='utf-8'))}
    y2 = {}
    for line in open(Y2_JSONL, encoding='utf-8'):
        o = json.loads(line)
        y2[o['id']] = o
    rows = []
    logp = os.path.join(out, 'log.txt')
    t_start = time.time()
    for fam, pid, (lay, G, P) in points():
        for name, fn in ESTS:
            fn(lay, G, P)
            wall, cpu = [], []
            for _ in range(REPS):
                with Counter() as cn:
                    t0, c0 = time.perf_counter(), time.process_time()
                    res = fn(lay, G, P)
                    wall.append(time.perf_counter() - t0)
                    cpu.append(time.process_time() - c0)
            v = res['value']
            ref_v = None
            if name in ('newton_1', 'newton_2'):
                o = y2.get(pid)
                ref_v = None if o is None else o.get('N1' if name == 'newton_1' else 'N2')
            elif (pid, name) in p12:
                ref_v = float(p12[(pid, name)]['value'])
            old_wall = float(p12[(pid, name)]['wall_median']) if (pid, name) in p12 else None
            rel = None if (v is None or ref_v is None) else abs(v - ref_v) / max(abs(ref_v), 1e-300)
            rows.append(dict(family=fam, id=pid, estimator=name, value=v, value_record=ref_v, value_rel_diff=rel,
                             status=res.get('status', 'ok'), N1s=res.get('N1s'),
                             equilibrium_solves=cn.n['newton_fixed_refs'], jacobians=cn.n['jac'],
                             full_scans=cn.n['crossings'], state_eig=cn.n['spectral_abscissa'],
                             wall_median=float(np.median(wall)), wall_min=float(np.min(wall)),
                             wall_max=float(np.max(wall)), cpu_median=float(np.median(cpu)),
                             wall_median_p12=old_wall, reps=REPS))
            with open(logp, 'a', encoding='utf-8') as lg:
                lg.write('%s %s %s %.3fs t=%.0fs\n' % (fam, pid, name, rows[-1]['wall_median'], time.time() - t_start))
    with open(os.path.join(out, 'k2_cost.csv'), 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    summ = {}
    for name, _ in ESTS:
        r = [x for x in rows if x['estimator'] == name]
        med = [x['wall_median'] for x in r]
        d = dict(n=len(r), wall_min=min(med), wall_max=max(med), range_1dp='%.1f–%.1f' % (min(med), max(med)))
        ratios = [x['wall_median'] / x['wall_median_p12'] for x in r if x['wall_median_p12']]
        if ratios:
            d.update(ratio_median=float(np.median(ratios)), ratio_min=min(ratios), ratio_max=max(ratios))
        rel = [x['value_rel_diff'] for x in r if x['value_rel_diff'] is not None]
        d.update(value_checked=len(rel), value_rel_diff_max=max(rel) if rel else None)
        summ[name] = d
    env = dict(python=sys.version.split()[0], numpy=np.__version__, platform=platform.platform(),
               processor=platform.processor(), cpu_count=os.cpu_count(), blas_threads=os.environ.get('OPENBLAS_NUM_THREADS'),
               affinity='0xFFFF0000 (verimlilik çekirdekleri, ext_common.lower_priority)', reps=REPS, warmup=1,
               timer='time.perf_counter / time.process_time', date=time.strftime('%Y-%m-%d %H:%M'),
               power_profile='dengeli (kullanıcı, 2026-11-07)', engine_dir=G92_KOD, p12_csv=P12_CSV, y2_jsonl=Y2_JSONL,
               note='betimsel süre ölçümü; hüküm dışı')
    with open(os.path.join(out, 'k2_summary.json'), 'w', encoding='utf-8') as f:
        json.dump(dict(summary=summ, environment=env), f, indent=1, ensure_ascii=False)
    import hashlib
    with open(os.path.join(out, 'SHA256SUMS'), 'w', encoding='utf-8', newline='\n') as f:
        for n in sorted(os.listdir(out)):
            if n != 'SHA256SUMS':
                f.write('%s  %s\n' % (hashlib.sha256(open(os.path.join(out, n), 'rb').read()).hexdigest(), n))
    sys.stdout.buffer.write(json.dumps(summ, ensure_ascii=False, indent=1).encode('utf-8'))


if __name__ == '__main__':
    main()
