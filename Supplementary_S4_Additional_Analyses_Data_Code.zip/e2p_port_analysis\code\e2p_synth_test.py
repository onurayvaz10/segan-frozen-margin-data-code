"""E2P sentetik testleri (SABİT v1.1 §9), v3 (B3v2-1…4 ekleri); v2: B3-1 için saf işlev ve sahte motor (SimpleNamespace) testleri. Yalnız el yapımı girdi; motor içe aktarılmaz, gerçek kayıt okunmaz
(yalnız check_pins pin dosyalarının hash'ini okur). Çıkış 0 = hepsi geçti. Kullanım: python -I -B e2p_synth_test.py
"""
import json
import math
import os
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import e2p_run as R  # noqa: E402
import numpy as np  # noqa: E402

PASS, FAIL = [], []


def t(name, cond):
    (PASS if cond else FAIL).append(name)


def raises(fn, exc=R.Kapi):
    try:
        fn()
    except exc:
        return True
    except Exception:  # noqa: BLE001
        return False
    return False


def A(**kw):
    base = dict(ne=None, omega_ss=100.0, I1=True, tarama=False, gizli=False, e_id_ok=False, genis=False, I2=True,
                kappa_ex=0.5, F_ex=0.0, delta_port=0.0, tol_star=1e-7)
    base.update(kw)
    return R.classify_A(base)


# ------------------------------------------------------------------ 1. A sınıflandırıcısı (15 sınıf)
for ne in R.NE_CLASSES:
    t('A ' + ne, A(ne=ne) == ne)
t('A ω0', A(omega_ss=R.W_LO * 0.999) == 'ω0')
t('A ω0 sınırı (eşitlik ω0 değil)', A(omega_ss=R.W_LO) == 'KİMLİK')
t('A ω_ss=0 → ω0', A(omega_ss=0.0) == 'ω0')
t('A ωHI', A(omega_ss=R.W_HI * 1.001) == 'ωHI')
t('A ωHI sınırı (eşitlik ωHI değil)', A(omega_ss=R.W_HI) == 'KİMLİK')
t('A TARAMA', A(I1=False, tarama=True, gizli=True) == 'TARAMA')
t('A GİZLİ', A(I1=False, gizli=True) == 'GİZLİ')
t('A EKSEN (e_id sağlandı)', A(I1=False, e_id_ok=True) == 'EKSEN')
t('A EKSEN (değerlendirilemedi)', A(I1=False, e_id_ok=None) == 'EKSEN')
t('A İHLAL', A(I1=False, e_id_ok=False) == 'İHLAL')
t('A GENİŞ', A(genis=True, I2=False) == 'GENİŞ')
t('A RAKİP', A(I2=False) == 'RAKİP')
t('A KÖK_SAPMA κ_ex ≥ 1', A(kappa_ex=1.0) == 'KÖK_SAPMA')
t('A KÖK_SAPMA κ_ex None', A(kappa_ex=None) == 'KÖK_SAPMA')
t('A KÖK_SAPMA |F_ex| > tol', A(F_ex=2e-7) == 'KÖK_SAPMA')
t('A KİMLİK |F_ex| = tol', A(F_ex=1e-7) == 'KİMLİK')
t('A KİMLİK', A() == 'KİMLİK')
t('A I1 başarısızken I2/κ_ex bakılmaz (İHLAL korunur)', A(I1=False, I2=None, kappa_ex=None, e_id_ok=False) == 'İHLAL')

# tolerans ve eşleşme eşitlikleri (compute_A'daki karşılaştırmalar ≤)
tr, tw = R.tolerances(1e-7, 0.0, complex(0.2, 0.5), 100.0)
t('tol σ=0: tol_ρ = thr', abs(tr - 1e-7) < 1e-20 and abs(tw - 1e-2) < 1e-15)
tr2, tw2 = R.tolerances(1e-7, 1e-3, complex(0.3, 0.4), 100.0)
t('tol σ terimi', abs(tr2 - (1e-7 + 1e-3 * 0.25 / 0.4)) < 1e-15 and abs(tw2 - (1e-2 + 2 * (1 + 0.75) * 1e-3)) < 1e-15)
t('tol Im dμ/dω = 0 → None', R.tolerances(1e-7, 1e-3, complex(0.3, 0.0), 100.0) is None)
t('tol dμ None → None', R.tolerances(1e-7, 1e-3, None, 100.0) is None)

# eşik ve bayraklar
thr, fl = R.threshold(None, 1e6, 2.0, 0.1)
t('κ_eig tanımsız → EŞİK_VARSAYILAN ve EŞİK_GENİŞ', thr == 1e-7 and 'EŞİK_VARSAYILAN' in fl and 'EŞİK_GENİŞ' in fl)
thr, fl = R.threshold(10.0, 1e6, None, 0.1)
t('dσ tanımsız → EŞİK_VARSAYILAN', thr == 1e-7 and fl == ['EŞİK_VARSAYILAN'])
thr, fl = R.threshold(1.0, 1.0, 1.0, 0.1)
t('eşik tabanı 1e-7', thr == 1e-7 and fl == [])
thr, fl = R.threshold(1e3, 1e8, 1e-3, 1.0)
t('eşik formülü', abs(thr - 10 * 2.22e-16 * 1e3 * 1e8 / 1e-3) < 1e-12)
thr_g = 1e-3 * 0.5
k_e = thr_g * 1.0 / (10 * 2.22e-16 * 1.0)
thr, fl = R.threshold(k_e, 1.0, 1.0, 0.5)
t('EŞİK_GENİŞ eşitliği (katı >)', abs(thr - thr_g) < 1e-15 and 'EŞİK_GENİŞ' not in fl)
thr, fl = R.threshold(k_e * 1.01, 1.0, 1.0, 0.5)
t('EŞİK_GENİŞ', 'EŞİK_GENİŞ' in fl)

# geçerli aday
t('geçerli aday', R.is_valid(complex(0.1, 1e-12)))
t('geçerli aday sınırı', R.is_valid(complex(0.1, 1e-9)))
t('SAHTE_ADAY', not R.is_valid(complex(0.1, 1.1e-9)))
t('geçerli büyük |λ|', R.is_valid(complex(100.0, 9e-8)) and not R.is_valid(complex(100.0, 1.1e-7)))

# ------------------------------------------------------------------ 2. κ_eig yardımcısı
lam, ke = R.kappa_eig(np.array([[0.0, -1.0], [1.0, 0.0]]))
t('κ_eig dönme = 1 (eşleniksiz yᵀv; vdot tuzağı)', ke is not None and abs(ke - 1) < 1e-12 and lam.imag > 0)
lam, ke = R.kappa_eig(np.array([[1.0, 3.0], [0.0, 2.0]]))
t('κ_eig analitik √10', abs(lam - 2) < 1e-12 and abs(ke - math.sqrt(10)) < 1e-10)
lam, ke = R.kappa_eig(np.array([[0.0, 1.0], [0.0, 0.0]]))
t('κ_eig koruması (kusurlu)', ke is None)
ev = np.array([complex(-1, -2), complex(-1, 2), complex(-5, 0)])
t('eşlenik çiftte Im ≥ 0 üyesi', ev[R.pick_lambda(ev)].imag > 0)

# ------------------------------------------------------------------ 3. B sınıflandırıcısı
B = lambda **kw: R.classify_B(kw)  # noqa: E731
t('B TEK_DAL', B() == 'TEK_DAL')
t('B RAKİP_GEÇİŞ', B(switch_k=5) == 'RAKİP_GEÇİŞ')
t('B TAKİP_KOPUK', B(kopuk_k=7) == 'TAKİP_KOPUK')
t('B SWITCH sonra kopuk → RAKİP', B(switch_k=3, kopuk_k=7) == 'RAKİP_GEÇİŞ')
t('B kopuk sonra SWITCH → KOPUK', B(switch_k=9, kopuk_k=4) == 'TAKİP_KOPUK')
t('B NE-denge', B(ne_denge_k=6) == 'NE-denge')
t('B SWITCH sonra NE-denge → RAKİP', B(switch_k=2, ne_denge_k=6) == 'RAKİP_GEÇİŞ')
t('B kopuk sonra NE-denge → KOPUK', B(kopuk_k=2, ne_denge_k=6) == 'TAKİP_KOPUK')
t('B ön NE', B(ne='NE-ref') == 'NE-ref')
steps = lambda vals: [dict(k=i, F=f, F_tr=ft, tracked_valid=v) for i, (f, ft, v) in enumerate(vals)]  # noqa: E731
br = {'a': dict(steps=steps([(0.1, 0.1, True), (0.05, 0.08, True)])),
      'b': dict(steps=steps([(0.1, 0.1, True), (None, 0.5, True), (0.0, 0.9, False)])),
      'c': dict(steps=steps([(0.1, 0.13, True)])), 'd': dict(steps=steps([(0.1, 0.13, True)]))}
t('temsilci seçimi (YOK ve geçersiz dışlanır; eşitlikte id)', R.representatives(br, ['a', 'b', 'c', 'd'], 3) == ['a', 'c', 'd'])

# ------------------------------------------------------------------ 4. C
t('C TEK(κ_Cb)', R.flip_class(-0.1, {'κ_Cb': -0.3, 'κ_dış': 0.2}) == 'TEK(κ_Cb)')
t('C TEK(κ_dış)', R.flip_class(-0.1, {'κ_Cb': 0.2, 'κ_dış': -0.3}) == 'TEK(κ_dış)')
t('C ÇOKLU', R.flip_class(-0.1, {'κ_Cb': -0.2, 'κ_dış': -0.15}) == 'ÇOKLU')
t('C ORTAK', R.flip_class(-0.3, {'κ_Cb': -0.15, 'κ_dış': -0.15}) == 'ORTAK')
t('C κ − t = 0 çevirici', R.flip_class(-0.1, {'κ_Cb': -0.1, 'κ_dış': 0.0}) == 'TEK(κ_Cb)')
t('C ikincil TEK(κ_res)', R.flip_class(-0.1, {'κ_L': 0.1, 'κ_dış': 0.1, 'κ_res': -0.3}) == 'TEK(κ_res)')
t('C ikincil TEK(κ_L)', R.flip_class(-0.1, {'κ_L': -0.3, 'κ_dış': 0.1, 'κ_res': 0.1}) == 'TEK(κ_L)')
t('C κ ≥ 0 → None', R.flip_class(0.2, {'κ_Cb': -0.1}) is None)
t('C X-3 eşitliği geçer', R.x3_ok(0.2 + 1e-4 * 0.2, 0.2, 0.0))
t('C X-3 başarısız', not R.x3_ok(0.2 + 2e-4 * 0.2, 0.2, 0.0))
t('C X-3 ν baskın', R.x3_ok(0.2 + 1e-3, 0.2, 2e-4) and not R.x3_ok(0.2 + 1e-3, 0.2, 5e-5))
t('C adlandırma 10 → değişir', R.naming_rule('BETİMSEL', 10) == 'DEĞİŞİR')
t('C adlandırma 9 → değişmez', R.naming_rule('BETİMSEL', 9) == 'DEĞİŞMEZ')
t('C NE → değişmez', R.naming_rule('NOT_EVALUABLE', 18) == 'DEĞİŞMEZ')

# ------------------------------------------------------------------ 6. karar tabloları
def cls(n_ev, extra=(), ne=0):
    d = {('p%d' % i): 'KİMLİK' for i in range(n_ev)}
    for j, c in enumerate(extra):
        d['x%d' % j] = c
    for j in range(ne):
        d['n%d' % j] = 'NE-ref'
    return d


t('A ABORT', R.decide_A(cls(774), abort='x') == 'ABORT')
t('A NE 696', R.decide_A(cls(696, ne=78)) == 'NOT_EVALUABLE')
t('A 697 eşitlik değerlendirilir', R.decide_A(cls(697, ne=77)) == 'TUTARLI')
t('A RET-İHLAL', R.decide_A(cls(700, extra=('İHLAL', 'RAKİP'))) == 'RET-İHLAL')
for c in R.A_KISMI:
    t('A KISMİ ' + c, R.decide_A(cls(700, extra=(c,))) == 'KISMİ')
t('A TUTARLI', R.decide_A(cls(774)) == 'TUTARLI')
t('B NE 11', R.decide_B({('s%d' % i): 'TEK_DAL' for i in range(11)}) == 'NOT_EVALUABLE')
t('B 12 eşitlik', R.decide_B({('s%d' % i): 'TEK_DAL' for i in range(12)}) == 'TUTARLI')
t('B KISMİ', R.decide_B(dict({('s%d' % i): 'TEK_DAL' for i in range(12)}, a='RAKİP_GEÇİŞ', b='TAKİP_KOPUK')) == 'KISMİ')
t('B BELİRSİZ', R.decide_B(dict({('s%d' % i): 'TEK_DAL' for i in range(12)}, b='TAKİP_KOPUK')) == 'BELİRSİZ')
t('B ABORT', R.decide_B({}, abort='x') == 'ABORT')
t('C 15/1125 eşitlik', R.decide_C(15, 1125) == 'BETİMSEL')
t('C 14', R.decide_C(14, 1249) == 'NOT_EVALUABLE')
t('C 1124', R.decide_C(18, 1124) == 'NOT_EVALUABLE')
t('C ABORT', R.decide_C(18, 1249, abort='x') == 'ABORT')

# ------------------------------------------------------------------ 7. küme kuralları
def row(i, k, rs, fs=None, cen=False, st='alpha', pin=True):
    return dict(id=i, kappa=k, abs_kappa=abs(k), ref_sign=rs, F_single=fs, censored=cen, ref_status=st,
                stage1_pin_ok=pin)


rows = [row('P1', 0.05, 1.0), row('P2', -0.2, -1.0), row('P3', 0.3, 1.0, cen=True, st='censored (stable…)'),
        row('Q1', 0.0005, -1.0), row('Q2', -0.0077, 1.0), row('Q3', 0.027, -1.0, fs=1.7e-5),
        row('Q4', 0.02, -1.0, fs=None), row('Q5', 0.02, 0.0), row('Q6', 0.049, 1.0)]
s = R.build_sets(rows)
t('S_P κ = 0.05 girer, sansürlü girmez', s['SP'] == ['P1', 'P2'])
t('S_O', s['SO'] == ['P2'])
t('S_D (işaret hatası, güvensiz kabul, F_single None yanlış, ref_sign 0 dışarıda)', s['SD'] == ['Q1', 'Q2', 'Q3', 'Q4'])
rows2 = [row('R1', 0.02, -1.0, fs=None), row('R2', 0.02, -1.0, fs=-1e-3)]
t('S_D F_single None → koşul yanlış (işaret hatası yine sayılır)', R.build_sets(rows2)['SD'] == ['R1', 'R2'])
rows3 = [row('R3', -0.02, -1.0, fs=None)]
t('S_D F_single None ve işaret uyumlu → girmez', R.build_sets(rows3)['SD'] == [])
t('küme ABORT', R.set_abort(s) is not None)
t('küme ABORT yok', R.set_abort(dict(SP=['x'] * 774, SO=['x'] * 18, SD=['x'] * 4)) is None)
ac = {('A2-%05d' % i): ('RAKİP' if i % 2 else 'KİMLİK') for i in range(60)}
ac['A2-99999'] = 'NE-hata'
sx = R.select_sx(ac)
t('S_X > 20 aday: ilk 20, sözlük sırası, NE hariç', len(sx) == 20 and sx == sorted(sx) and 'A2-99999' not in sx)
t('S_X < 20 aday', R.select_sx({'b': 'RAKİP', 'a': 'GENİŞ', 'c': 'KİMLİK'}) == ['a', 'b'])

# ------------------------------------------------------------------ 8. özetler
ar = [dict(delta_tab=-2e-5, delta_tab_pred=-2e-5, ayirt=True, flags=['EŞİK_GENİŞ'], thr=2e-6, n_sahte=1),
      dict(delta_tab=-1e-5, delta_tab_pred=None, ayirt=False, flags=[], thr=1e-7, n_sahte=0),
      dict(delta_tab=3e-5, delta_tab_pred=1e-6, ayirt=True, flags=['EŞİK_VARSAYILAN'], thr=1e-7, n_sahte=2)]
sm = R.tab_summary(ar)
t('özet payda (tanımsız pred çıkar)', sm['n_pred_tanimsiz'] == 1 and abs(sm['frac_ratio_0p5_2'] - 0.5) < 1e-12)
t('özet frac_neg ve AYIRT', abs(sm['frac_neg'] - 2 / 3) < 1e-12 and abs(sm['frac_ayirt'] - 2 / 3) < 1e-12)
t('özet bayrak sayıları', sm['n_EŞİK_GENİŞ'] == 1 and sm['n_EŞİK_VARSAYILAN'] == 1 and sm['n_thr_gt_1e-6'] == 1
  and sm['n_sahte_aday'] == 3)
t('S_D yorum 1 (0)', R.sd_interpretation(0, 'TEK_DAL') == 'göreli eşik artefaktı')
t('S_D yorum 1 (+1)', R.sd_interpretation(1, None) == 'göreli eşik artefaktı')
t('S_D yorum 2', R.sd_interpretation(-1, 'RAKİP_GEÇİŞ') == 'rakip dal')
t('S_D yorum 3', R.sd_interpretation(-1, 'TEK_DAL').startswith('açıklanmadı'))
t('S_D yorum 4', R.sd_interpretation(-1, 'TAKİP_KOPUK') == 'belirsiz' and R.sd_interpretation(None, None) == 'belirsiz')
t('etiket tablosu', R.label_table([(-1, -1), (-1, 0), (-1, -1)]) == {'-1->-1': 2, '-1->0': 1})

# ------------------------------------------------------------------ 9. kapılar ve devam
t('ortam kapısı G92_S1', raises(lambda: R.env_gate({'G92_S1': 'x'})))
t('ortam kapısı G92_OUT', raises(lambda: R.env_gate({'G92_OUT': 'x'})))
t('ortam kapısı boş', not raises(lambda: R.env_gate({})))
t('kip yok', raises(lambda: R.parse([])))
t('iki kip birlikte', raises(lambda: R.parse(['--check-only', '--run-id', 'X', '--yetki', 'C:\\y.json'])))
t('devam nedensiz', raises(lambda: R.parse(['--devam', '--run-id', 'X', '--yetki', 'C:\\y.json'])))
t('check-only kip', R.parse(['--check-only']).check_only)
pin_sha, _ = R.check_pins()
t('pinler geçer', len(pin_sha) == 64)
tmp = tempfile.mkdtemp(prefix='e2p_synth_')
car = os.path.join(tmp, 'denetim.md')
R._write_text(car, 'denetim')
good = dict(action='ALLOW_E2P_RUN', run_id='E2P_T_a', sabit_sha256=R.SABIT_SHA,
            script_sha256={'e2p_run.py': R.script_sha()}, pin_list_sha256=pin_sha,
            code_audit_report=dict(path=car, sha256=R.sha256_bytes(b'denetim')), dayanak=['D-x'], yazan='test')


def yetki(**chg):
    d = dict(good)
    d.update(chg)
    p = os.path.join(tmp, 'y_%d.json' % len(os.listdir(tmp)))
    R._write_text(p, json.dumps(d))
    return p


t('yetki geçerli', not raises(lambda: R.verify_authorization(yetki(), 'E2P_T_a', pin_sha)))
t('yetki yok', raises(lambda: R.verify_authorization(os.path.join(tmp, 'yok.json'), 'E2P_T_a', pin_sha)))
t('yetki göreli yol', raises(lambda: R.verify_authorization('y.json', 'E2P_T_a', pin_sha)))
t('yanlış SABİT hash', raises(lambda: R.verify_authorization(yetki(sabit_sha256='0' * 64), 'E2P_T_a', pin_sha)))
t('yanlış run_id', raises(lambda: R.verify_authorization(yetki(), 'E2P_T_b', pin_sha)))
t('yanlış betik hash', raises(lambda: R.verify_authorization(yetki(script_sha256={'e2p_run.py': '0'}), 'E2P_T_a', pin_sha)))
t('yanlış action', raises(lambda: R.verify_authorization(yetki(action='X'), 'E2P_T_a', pin_sha)))
def _missing():
    d = dict(good)
    del d['yazan']
    p = os.path.join(tmp, 'y_eksik.json')
    R._write_text(p, json.dumps(d))
    return p


t('eksik alan', raises(lambda: R.verify_authorization(_missing(), 'E2P_T_a', pin_sha)))
# devam
R.OUT_ROOT = tmp
t('yeni klasör', os.path.isdir(R.prepare_dir(R.parse(['--run-id', 'RUN1', '--yetki', 'C:\\y.json']))))
t('klasör varken yeni koşu reddi', raises(lambda: R.prepare_dir(R.parse(['--run-id', 'RUN1', '--yetki', 'C:\\y.json']))))
dv = lambda: R.prepare_dir(R.parse(['--devam', '--neden', 'güç kesintisi', '--run-id', 'RUN1', '--yetki', 'C:\\y.json']))  # noqa: E731
t('devam 1', not raises(dv))
t('devam 2', not raises(dv))
t('üçüncü devam reddi', raises(dv))
run2 = os.path.join(tmp, 'RUN2')
os.makedirs(run2)
R._write_text(os.path.join(run2, 'exit_code.txt'), '0')
t('exit_code varken devam reddi',
  raises(lambda: R.prepare_dir(R.parse(['--devam', '--neden', 'x', '--run-id', 'RUN2', '--yetki', 'C:\\y.json']))))
jl = os.path.join(tmp, 'A.jsonl')
R._write_text(jl, '{"id": "a", "cls": "KİMLİK"}\n{"id": "b", "cl')
R.discard_partial(jl, os.path.join(tmp, 'devam_log.txt'))
t('yarım satır atılır, nokta yeniden hesaplanacak', set(R.load_jsonl(jl)) == {'a'})
# aşama ortası devam: tamamlanmış nokta yeniden hesaplanmaz, eksik olan hesaplanır
calls = []
done = R.stage_loop('A', ['a', 'b'], {'a': {'id': 'a'}, 'b': {'id': 'b'}},
                    lambda r: calls.append(r['id']) or dict(id=r['id'], cls='KİMLİK'), tmp, [])
t('aşama ortası devam', calls == ['b'] and set(done) == {'a', 'b'}
  and os.path.exists(os.path.join(tmp, 'asama_A_tamam.txt')))

# ================================================================== v2 ekleri (B3-1): saf işlevler ve sahte motor
from types import SimpleNamespace as NS  # noqa: E402

# --- §9.5 X-1 / X-2 eşitlikleri ve 5e-12 tabanı
t('X-1 ω sınırı', R.x1_ok(1.0 + 1e-6, 0.5, 1.0, 0.5) and not R.x1_ok(1.0 + 1.1e-6, 0.5, 1.0, 0.5))
t('X-1 ρ göreli', R.x1_ok(1.0, 0.5 * (1 + 0.9e-9), 1.0, 0.5) and not R.x1_ok(1.0, 0.5 * (1 + 1.1e-9), 1.0, 0.5))
t('X-1 5e-12 tabanı', R.x1_ok(1.0, 1e-4 + 4e-12, 1.0, 1e-4) and not R.x1_ok(1.0, 1e-4 + 6e-12, 1.0, 1e-4))
t('X-2 sınırı', R.x2_ok(0.2 + 1.9e-7, 0.2) and not R.x2_ok(0.2 + 2.1e-7, 0.2) and R.x2_ok(0.01 + 4.9e-8, 0.01) and not R.x2_ok(0.01 + 5.1e-8, 0.01))

# --- §5.3 saf: I1 eşleşme eşitliği, I2, GİZLİ, 9b kaynak sırası
TR = 2.0 ** -20
z1 = dict(omega=100.0, rho=0.25, lam=complex(0.25, 0))
cands = [(z1, complex(0, 0.01), (TR, 2.0 ** -10))]
m, best = R.match_I1(cands, 100.0 + 2.0 ** -10, 0.25 + TR)
t('I1 eşitlik (ω ve ρ tam toleransta eşleşir)', best is not None and best[0] is z1)
m, best = R.match_I1(cands, 100.0, 0.25 + 2 * TR)
t('I1 eşleşmez', best is None and m == [])
z2 = dict(omega=100.002, rho=0.25 + TR / 2, lam=0)
m, best = R.match_I1(cands + [(z2, 0.01j, (TR, 1.0))], 100.0, 0.25 + TR / 2)
t('I1 çoklu: |ρ − ΔG| en küçük z*', best[0] is z2)
zo = dict(omega=300.0, rho=0.25 - TR)
t('I2 eşitlik: ρ = ρ_z* − tol rakip değil', R.i2_ok([z1, zo], z1, TR))
zo2 = dict(omega=300.0, rho=0.25 - 2 * TR)
t('I2 rakip', not R.i2_ok([z1, zo2], z1, TR))
t('I2 negatif ρ sayılmaz', R.i2_ok([z1, dict(omega=5.0, rho=-1.0)], z1, TR))
t('GİZLİ eşitliği', R.gizli_ok([complex(0, 100.0) + 1e-2], complex(0, 100.0), 100.0))
t('GİZLİ değil', not R.gizli_ok([complex(0, 100.0) + 2e-2], complex(0, 100.0), 100.0))
ca = [(dict(omega=101.0), 0.1j, None), (dict(omega=99.5), 0.2j, None)]
t('9b kaynak 1: en yakın aday', R.eid_source(ca, 0.9j, 100.0) == 0.2j)
t('9b kaynak 2: z_d', R.eid_source([], 0.9j, 100.0) == 0.9j)
t('9b kaynak 3: yok', R.eid_source([], None, 100.0) is None)
t('9b sınır kaynaksız = thr', R.eid_bound(1e-7, None, 5.0, 1e3) == 1e-7)
t('9b sınır kaynaklı', abs(R.eid_bound(1e-7, 2j, 5.0, 1e3) - (1e-7 + 10 * 2 * 2.22e-16 * 5e3)) < 1e-20)

# --- §5.4 saf: track_check beş ölçüt ve sınırları, R3-3, SWITCH, olası rakip, ΔG_son
tp = dict(omega=100.0, rho=0.5)
h, kp, thr = 0.01, 0.25, 2.0 ** -20


def cr(w, r, im=0.0):
    return dict(omega=w, rho=r, lam=complex(r, im))


tk = dict(omega=100.0, rho=0.5 + kp * h)
v_ok = [cr(100.0, 0.5 + kp * h)]
why, same = R.track_check(tk, complex(0.5, 0), tp, kp, h, thr, v_ok, v_ok)
t('takip geçerli', why is None and len(same) == 1)
t('(i) yakınsama sınırı', R.track_check(tk, complex(0.5, 1e-9), tp, kp, h, thr, v_ok, v_ok)[0] is None
  and R.track_check(tk, complex(0.5, 1.1e-9), tp, kp, h, thr, v_ok, v_ok)[0] == 'i')
tk2 = dict(omega=105.0, rho=tk['rho'])
t('(ii) ω sürekliliği sınırı', R.track_check(tk2, 0.5, tp, kp, h, thr, [cr(105.0, tk['rho'])], [])[0] is None)
tk3 = dict(omega=105.01, rho=tk['rho'])
t('(ii) kopuş', R.track_check(tk3, 0.5, tp, kp, h, thr, [cr(105.01, tk['rho'])], [])[0] == 'ii')
win = 0.05 * 0.5
tk4 = dict(omega=100.0, rho=0.5 + kp * h + win * 0.999)
t('(iii) sınır içi', R.track_check(tk4, 0.5, tp, kp, h, thr, [cr(100.0, tk4['rho'])], [])[0] is None)
tk5 = dict(omega=100.0, rho=0.5 + kp * h + win * 1.001)
t('(iii) kopuş', R.track_check(tk5, 0.5, tp, kp, h, thr, [cr(100.0, tk5['rho'])], [])[0] == 'iii')
t('(iv) eşleşme yok', R.track_check(tk, 0.5, tp, kp, h, thr, [cr(100.0, tk['rho'] + 1e-3)], [])[0] == 'iv')
oth = cr(101.0, tk['rho'] - 1e-4)
t('(v) BELİRSİZ_EŞLEŞME', R.track_check(tk, 0.5, tp, kp, h, thr, v_ok + [oth], v_ok + [oth])[0] == 'v')
dup = cr(100.0 + 0.005, tk['rho'] - 5 * thr)
why, same = R.track_check(tk, 0.5, tp, kp, h, thr, v_ok + [dup], v_ok + [dup])
t('R3-3: (iv)\'ü sağlayan bütün girdiler özdeş (v) değil, SWITCH değil',
  why is None and len(same) == 2 and not R.switch_pre(dup, tk, same, thr))
mm = cr(300.0, tk['rho'] - 2 * thr)
t('SWITCH ön koşulu', R.switch_pre(mm, tk, same, thr))
t('SWITCH eşitliği (katı)', not R.switch_pre(cr(300.0, tk['rho'] - thr), tk, same, thr))
t('SWITCH ω aynı değil', not R.switch_pre(cr(100.0 + 0.005, tk['rho'] - 1.0), tk, [], thr))
t('SWITCH m yok', not R.switch_pre(None, tk, same, thr))
t('yeniden yakınsama sınırı', R.reconv_ok(dict(omega=300.03, rho=mm['rho'] + 10 * thr), mm, thr)
  and not R.reconv_ok(dict(omega=300.031, rho=mm['rho']), mm, thr))
t('olası rakip', R.olasi_rakip(cr(300.0, 0.5 + kp * h - 2 * thr), tp, kp, h, thr)
  and not R.olasi_rakip(cr(300.0, 0.5 + kp * h - thr), tp, kp, h, thr) and not R.olasi_rakip(None, tp, kp, h, thr))
t('ΔG_son C NE', R.delta_son(dict(cls='NE-kimlik'), {}) == (None, 'NE-kimlik'))
t('ΔG_son REF-SANSÜR', R.delta_son(dict(cls='OK'), dict(ref_sansur=True, ne='NE-ref', dG_max=0.4)) == (0.4, None))
t('ΔG_son NE-ref', R.delta_son(dict(cls='OK'), dict(ne='NE-ref')) == (None, 'NE-ref'))
t('ΔG_son NE-denge → ΔG*_ex', R.delta_son(dict(cls='OK'), dict(ne='NE-denge', dG_ex=0.3)) == (0.3, None))
t('ΔG_son NE-hata dG_ex yok', R.delta_son(dict(cls='OK'), dict(ne='NE-hata')) == (None, 'NE-hata'))
t('ΔG_son normal', R.delta_son(dict(cls='OK'), dict(dG_ex=0.2)) == (0.2, None))


# --- sahte motor: compute_B
class MB:
    """Izgara h = 0.01 (ΔG_son = 0.2). x = [ΔG]; jac x'i geçirir; senaryo k'ye göre geçiş listesi verir."""
    def __init__(self, extra=None, cross_raise=(), kap_raise=(), sw_raise=False, newton_fail=None, rho_neg=False,
                 sahte=None):
        self.extra, self.cross_raise, self.kap_raise = extra or {}, set(cross_raise), set(kap_raise)
        self.sw_raise, self.newton_fail, self.rho_neg, self.sahte = sw_raise, newton_fail, rho_neg, sahte or {}

    def rho(self, k):
        return (0.002 - 0.02 * k * 0.01) if self.rho_neg else (0.1 + 0.2 * k * 0.01)

    def kk(self, x):
        return int(round(float(x[0]) / 0.01))

    def newton_fixed_refs(self, lay, x, refs, Gk):
        tgt = 1.0 - Gk[0]
        if self.newton_fail is not None and abs(tgt - self.newton_fail[1]) < 1e-12 and abs(x[0] - self.newton_fail[0]) < 1e-12:
            return x, False, 0, 0
        if self.newton_fail is not None and self.newton_fail[0] is None and abs(tgt - self.newton_fail[1]) < 1e-12:
            return x, False, 0, 0
        return np.array([tgt]), True, 0, 0

    def jac(self, lay, x, refs, G):
        return np.array(x, dtype=float)

    def crossings(self, lay, J, th):
        k = self.kk(J)
        if k in self.cross_raise:
            raise RuntimeError('crossings')
        out = [cr(100.0, self.rho(k))] + [cr(w, r) for w, r in self.extra.get(k, [])]
        out += [cr(w, r, 1e-6) for w, r in self.sahte.get(k, [])]
        return out

    def rho_at(self, lay, x, refs, G, th, prev):
        k = self.kk(x)
        if abs(prev['omega'] - 100.0) > 1e-9:
            if self.sw_raise:
                raise RuntimeError('rho_at switch')
            for w, r in self.extra.get(k, []):
                if abs(w - prev['omega']) < 1e-9:
                    return dict(omega=w, rho=r, lam=complex(r, 0))
        return dict(omega=100.0, rho=self.rho(k), lam=complex(self.rho(k), 0))

    def eig_branch(self, lay, J, th, w, lam):
        return complex(lam).real + 0j, None, None, None


class MY:
    def __init__(self, mb):
        self.mb = mb

    def kappa_at(self, lay, x, refs, G, Gk, th, t):
        if self.mb.kk(x) in self.mb.kap_raise:
            raise RuntimeError('kappa_at')
        return (-0.02 if self.mb.rho_neg else 0.2), 0.0, 0j


def runB(mb, crec=None, arec=None):
    eng = R.Eng(None, mb, None, MY(mb), sel={})
    eng.setup_point = lambda r: dict(lay=None, G=np.array([1.0]), P=None, x0=np.array([0.0]), refs=None, sb=0, th=0.0)
    crit = dict(omega=100.0, rho=mb.rho(0), lam=complex(mb.rho(0), 0))
    eng.entry_checks = lambda s, r: (crit, dict(kappa=(-0.02 if mb.rho_neg else 0.2), c=0.0), {})
    return eng.compute_B(dict(id='T', system='A2'), crec or dict(cls='OK'), arec or dict(dG_ex=0.2, thr=2.0 ** -20))


b = runB(MB())
t('B sahte: TEK_DAL, 21 adım', b['cls'] == 'TEK_DAL' and len(b['steps']) == 21)
b = runB(MB(extra={5: [(300.0, 0.1 + 0.2 * 0.05 - 0.05)]}))
t('B sahte: SWITCH → RAKİP_GEÇİŞ', b['cls'] == 'RAKİP_GEÇİŞ' and b['switch_k'] == 5)
b = runB(MB(extra={5: [(300.0, 0.1 + 0.2 * 0.05 - 0.05)]}, kap_raise={5}))
t('B3-2(1): SWITCH(5) sonra κ istisnası → kopuş(6), RAKİP_GEÇİŞ',
  b['cls'] == 'RAKİP_GEÇİŞ' and b['switch_k'] == 5 and b['kopuk_k'] == 6)
b = runB(MB(extra={5: [(300.0, 0.1 + 0.2 * 0.05 - 0.05)]}, sw_raise=True))
t('B3-2(2): SWITCH doğrulamasında rho_at istisnası → TAKİP_KOPUK(5)',
  b['cls'] == 'TAKİP_KOPUK' and b['kopuk_k'] == 5 and b.get('switch_k') is None)
b = runB(MB(cross_raise={0}, extra={5: [(300.0, 0.0)]}))
t('B3-2(3): k = 0 crossings istisnası → TAKİP_KOPUK(0)', b['cls'] == 'TAKİP_KOPUK' and b['kopuk_k'] == 0)
b = runB(MB(extra={4: [(101.0, 0.1 + 0.2 * 0.04 - 1e-4)]}))
t('B sahte: BELİRSİZ_EŞLEŞME → TAKİP_KOPUK', b['cls'] == 'TAKİP_KOPUK' and b['steps'][4].get('kopus') == 'v')
b = runB(MB(extra={6: [(100.005, 0.1 + 0.2 * 0.06 - 2.0 ** -21)]}))
t('B sahte: R3-3 özdeş girdi SWITCH değil', b['cls'] == 'TEK_DAL')
b = runB(MB(sahte={7: [(300.0, 0.0)]}))
t('B sahte: SAHTE_ADAY m/SWITCH dışında', b['cls'] == 'TEK_DAL' and b['steps'][7]['n_sahte'] == 1)
b = runB(MB(newton_fail=(None, 0.1)))
t('B sahte: NE-denge(10)', b['cls'] == 'NE-denge' and b['ne_denge_k'] == 10)
b = runB(MB(newton_fail=(None, 0.1), extra={5: [(300.0, 0.1 + 0.2 * 0.05 - 0.05)]}))
t('B sahte: SWITCH sonra NE-denge → RAKİP_GEÇİŞ', b['cls'] == 'RAKİP_GEÇİŞ')
b = runB(MB(newton_fail=(None, 0.1), cross_raise={3}))
t('B sahte: kopuş sonra NE-denge → TAKİP_KOPUK', b['cls'] == 'TAKİP_KOPUK')
b = runB(MB(newton_fail=(0.09, 0.1)))
t('B sahte: 2/4 alt adım kurtarma', b['cls'] == 'TEK_DAL' and len(b['steps']) == 21)
b = runB(MB(rho_neg=True))
t('B sahte: ρ(t_k) ≤ 0 ve YOK(k)', any(s.get('rho_t_nonpos') for s in b['steps'])
  and any(s.get('m') is None for s in b['steps']))
b = runB(MB(cross_raise={8}, extra={8: []}))
t('B sahte: kopuş adımında olası rakip alanı (istisnada yok)', b['steps'][8].get('kopus') == 'istisna')
b = runB(MB(extra={4: [(101.0, 0.1 + 0.2 * 0.04 - 1e-4)]}))
t('B sahte: olası rakip bayrağı', b['steps'][4].get('olasi_rakip') is True)
b = runB(MB(), crec=dict(cls='NE-kimlik'))
t('B sahte: C NE-kimlik devralınır', b['cls'] == 'NE-kimlik')
b = runB(MB(), arec=dict(ref_sansur=True, ne='NE-ref', dG_max=0.2, thr=None))
t('B sahte: REF-SANSÜR → ΔG_son = dG_max', b['cls'] == 'TEK_DAL' and b['dG_son'] == 0.2)
eng = R.Eng(None, MB(), None, MY(MB()), sel={})
eng.setup_point = lambda r: (_ for _ in ()).throw(RuntimeError('kurulum'))
t('B sahte: kurulum istisnası → NE-hata', eng.compute_B(dict(id='T', system='A2'), dict(cls='OK'),
                                                      dict(dG_ex=0.2))['cls'] == 'NE-hata')


# --- sahte motor: compute_A
class MA:
    def __init__(self, cross, ref_status='alpha', path_raise=False, rho_at=None, port_eig=None, flat=False,
                 lam_real=False, kap_raise=False):
        self.cross, self.ref_status, self.path_raise = cross, ref_status, path_raise
        self.rho_at_v, self.port_eig, self.flat, self.lam_real, self.kap_raise = rho_at, port_eig, flat, lam_real, kap_raise

    def reference_margin(self, lay, x0, refs, G, dmax, step, tol, alpha_tab):
        return dict(dGt=0.1, status=self.ref_status)

    def path_point(self, lay, x0, refs, G, dG, steps):
        if self.path_raise:
            raise RuntimeError('path')
        return np.array([0.0]), 0, 0

    def jac(self, lay, x, refs, G):
        s = 0.0 if self.flat else 10 * ((1.0 - G[0]) - 0.1)
        if self.lam_real:
            return np.array([[s, 0.0], [0.0, -1.0]])
        return np.array([[s, -100.0], [100.0, s]])

    def newton_fixed_refs(self, lay, x, refs, G):
        return x, True, 0, 0

    def crossings(self, lay, J, th):
        return [cr(w, r, im) for w, r, im in self.cross]

    def eig_branch(self, lay, J, th, w, lam):
        return complex(complex(lam).real, 0.01 * (w - 100.0)), None, None, None

    def rho_at(self, lay, x, refs, G, th, prev):
        if self.rho_at_v is None:
            raise RuntimeError('rho_at')
        return dict(omega=self.rho_at_v[0], rho=self.rho_at_v[1], lam=complex(self.rho_at_v[1], 0))

    def to_F0(self, Y, th):
        return Y

    def port_admittance(self, lay, J, s):
        if self.port_eig is None:
            raise RuntimeError('port')
        return np.diag(self.port_eig)


class MYA:
    def __init__(self, raise_=False):
        self.raise_ = raise_

    def kappa_at(self, *a):
        if self.raise_:
            raise RuntimeError('kappa_at')
        return 0.3, 0.0, 0j


def ref_sign_of(status, e, dGf):
    tie = 2e-3 * dGf
    return 1 if e > tie else (-1 if e < -tie else 0)


LAY = NS(keep=[0, 1], port=[0], M=np.ones(2))


def runA(ma, crec=None, kap_raise=False):
    eng = R.Eng(NS(ref_sign_of=ref_sign_of), ma, None, MYA(kap_raise), sel={})
    eng.setup_point = lambda r: dict(lay=LAY, G=np.array([1.0]), P=None, x0=np.array([0.0]), refs=None, sb=0, th=0.0)
    return eng.compute_A(dict(id='T', system='A2', dGf=0.09, dGref=0.0999), crec or dict(cls='OK'))


a = runA(MA([(100.0, 0.1, 0.0)]))
t('A sahte: KİMLİK', a['cls'] == 'KİMLİK' and a['I1'] and a['I2'] and abs(a['dsig_ddG'] - 10.0) < 1e-6
  and abs(a['thr'] - 1e-7) < 1e-20 and a['kappa_eig'] is not None and abs(a['kappa_eig'] - 1) < 1e-9)
a = runA(MA([(100.0, 0.1, 0.0), (300.0, 0.1 - 0.5e-7, 0.0)]))
t('A sahte: MIN_FARKLI (F-1; F_ex z*\'dan)', a['cls'] == 'KİMLİK' and 'MIN_FARKLI' in a['flags']
  and a['F_ex'] == 0.0 and a['F_ex_min'] < 0)
a = runA(MA([(100.0, 0.1, 0.0), (300.0, 0.05, 0.0)]))
t('A sahte: RAKİP', a['cls'] == 'RAKİP')
a = runA(MA([(100.0, 0.1, 0.0), (300.0, 0.05, 1e-6)]))
t('A sahte: SAHTE_ADAY I2 dışında', a['cls'] == 'KİMLİK' and a['n_sahte'] == 1)
a = runA(MA([(150.0, 0.1, 0.0)], rho_at=(100.0, 0.1)))
t('A sahte: TARAMA', a['cls'] == 'TARAMA')
a = runA(MA([(150.0, 0.1, 0.0)], port_eig=[0.1, 5.0]))
t('A sahte: EKSEN (e_id sağlandı)', a['cls'] == 'EKSEN' and a['e_id_ok'] is True)
a = runA(MA([(150.0, 0.1, 0.0)]))
t('A sahte: EKSEN (9B_HATA)', a['cls'] == 'EKSEN' and '9B_HATA' in a['flags'])
a = runA(MA([(150.0, 0.1, 0.0)], port_eig=[0.3, 5.0]))
t('A sahte: İHLAL', a['cls'] == 'İHLAL')
a = runA(MA([(100.0, 0.1, 0.0)], ref_status='censored (stable up to dG_max)'))
t('A sahte: REF-SANSÜR', a['cls'] == 'NE-ref' and a['ref_sansur'] and a['ref_sign_ex'] == 1)
a = runA(MA([(100.0, 0.1, 0.0)], ref_status='newton failure (fold?)'))
t('A sahte: NE-ref', a['cls'] == 'NE-ref' and not a.get('ref_sansur'))
a = runA(MA([(100.0, 0.1, 0.0)], path_raise=True))
t('B3-4: adım 2 istisnası → NE-denge', a['cls'] == 'NE-denge')
a = runA(MA([(100.0, 0.1, 0.0)], flat=True))
t('A sahte: dσ/dΔG = 0 → EŞİK_VARSAYILAN, δ_tab,pred tanımsız',
  'EŞİK_VARSAYILAN' in a['flags'] and a['delta_tab_pred'] is None)
a = runA(MA([(100.0, 0.1, 0.0)], lam_real=True))
t('A sahte: ω_ss = 0 istisnasız ω0', a['cls'] == 'ω0' and 'err' not in a)
a = runA(MA([(100.0, 0.1, 0.0)]), kap_raise=True)
t('A sahte: I1 ∧ I2 iken adım 12 istisnası → NE-hata', a['cls'] == 'NE-hata')
a = runA(MA([(150.0, 0.1, 0.0)], port_eig=[0.3, 5.0]), kap_raise=True)
t('A sahte: I1 başarısızken adım 12 koşmaz (İHLAL korunur)', a['cls'] == 'İHLAL')
a = runA(MA([(100.0, 0.1, 0.0)]), crec=dict(cls='NE-dağıtım'))
t('A sahte: C NE-dağıtım devralınır', a['cls'] == 'NE-dağıtım')
a = runA(MA([(100.0, 0.1, 0.0)]), crec=dict(cls='NE-hata'))
t('A sahte: C NE-hata devralınır (B3v2-1)', a['cls'] == 'NE-hata')
a = runA(MA([(100.0, 0.2, 0.0)]))
t('A sahte: ref_sign_ex −1 değil (ΔG*_ex > dGf)', a['ref_sign_ex'] == 1)


# --- sahte motor: compute_C
class MC:
    def __init__(self, den_zero=False, jac_raise=False):
        self.den_zero, self.jac_raise = den_zero, jac_raise
        rng = np.random.default_rng(7)
        self.J0 = rng.standard_normal((5, 5))
        self.D = rng.standard_normal((5, 5))

    def jac(self, lay, x, refs, G):
        if self.jac_raise:
            raise RuntimeError('jac')
        return self.J0 + float(np.sum(x)) * self.D

    def eig_branch(self, lay, J, th, w, lam):
        v = np.array([1.0, 0.0])
        wl = np.array([0.0, 1.0]) if self.den_zero else np.array([1.0, 0.5])
        return lam, v, wl, None

    def to_F0(self, Y, th):
        return Y

    def kappa_hat(self, lay, x0, refs, G, th, crit, eps=1e-5):
        return dict(kappa=self.kref)


LC = NS(keep=[0, 1, 3, 4], port=[0, 1], M=np.ones(5), names=['V0:R', 'V0:I', 'G:th', 'G:pm', 'C0:vdc'],
        sysd=dict(cpls=[dict(bus=0)], shed_bus=0))


def runC(mc, kref, setup_raise=False, x1_fail=False):
    mc.kref = kref
    eng = R.Eng(None, mc, None, None, sel={})
    if setup_raise:
        eng.setup_point = lambda r: (_ for _ in ()).throw(RuntimeError('kurulum'))
    else:
        eng.setup_point = lambda r: dict(lay=LC, G=np.array([1.0]), P=None, x0=np.zeros(5), refs=None, sb=0, th=0.0)
    crit = dict(omega=50.0, rho=0.1, lam=complex(0.1, 0))
    eng.entry_checks = lambda s, r: ((None, None, dict(x1_omega=1.0)) if x1_fail
                                     else (crit, dict(kappa=kref, c=0.0, xi=np.ones(5)), {}))
    return eng.compute_C(dict(id='T', system='A2', kappa=kref, kappa_L=0.05))


c = runC(MC(), 100.0)
t('C sahte: X-3 başarısız → NE-ayrışım', c['cls'] == 'NE-ayrışım' and 'k_sum' in c)
ks = c['k_sum']
c = runC(MC(), ks)
t('C sahte: X-3 geçer, dört terim toplamı κ', c['cls'] == 'OK'
  and abs(c['k_Cb'] + c['k_dis'] - ks) < 1e-12 and abs(c['k_res'] - (c['k_Cb'] - 0.05)) < 1e-15)
t('C sahte: R_Co boş (tek CPL) → κ_Co = 0', c['k_Co'] == 0.0)
t('C sahte: w_lᵀv = 0 → NE-ayrışım', runC(MC(den_zero=True), 0.2)['cls'] == 'NE-ayrışım')
t('C sahte: ayrışım istisnası → NE-ayrışım', runC(MC(jac_raise=True), 0.2)['cls'] == 'NE-ayrışım')
t('C sahte: kurulum istisnası → NE-hata (B3-3)', runC(MC(), 0.2, setup_raise=True)['cls'] == 'NE-hata')
t('C sahte: X-1 başarısız → NE-kimlik', runC(MC(), 0.2, x1_fail=True)['cls'] == 'NE-kimlik')

# --- §9.9 ek kapılar ve özet ekleri
t('yanlış pin_list_sha256', raises(lambda: R.verify_authorization(yetki(), 'E2P_T_a', '0' * 64)))
t('kod denetim raporu hash uyuşmazlığı',
  raises(lambda: R.verify_authorization(yetki(code_audit_report=dict(path=car, sha256='0' * 64)), 'E2P_T_a', pin_sha)))
t('yetki: script_sha256 sözlük değil → Kapi (B3-6)',
  raises(lambda: R.verify_authorization(yetki(script_sha256='x'), 'E2P_T_a', pin_sha)))
t('yetki: rapor yolu yok → Kapi (B3-6)',
  raises(lambda: R.verify_authorization(yetki(code_audit_report=dict(path=os.path.join(tmp, 'yok.md'), sha256='0')),
                                        'E2P_T_a', pin_sha)))
t('ortam kapısı boş değer (B3-9)', raises(lambda: R.env_gate({'G92_S1': ''})))
R.OUT_ROOT = tmp
R.prepare_dir(R.parse(['--run-id', 'RUN3', '--yetki', 'C:\\y.json']), 'aaa')
t('devam: yetki aynı', not raises(lambda: R.prepare_dir(R.parse(['--devam', '--neden', 'x', '--run-id', 'RUN3',
                                                                 '--yetki', 'C:\\y.json']), 'aaa')))
t('devam: yetki farklı → KAPI (B3-6)', raises(lambda: R.prepare_dir(R.parse(['--devam', '--neden', 'x', '--run-id',
                                                                            'RUN3', '--yetki', 'C:\\y.json']), 'bbb')))
t('EKSEN alt sayıları', R.eksen_alt([dict(cls='EKSEN', e_id_ok=True), dict(cls='EKSEN', e_id_ok=None),
                                     dict(cls='İHLAL', e_id_ok=False)]) == dict(saglandi=1, degerlendirilemedi=1))
t('S_X aile sayıları', R.sx_aile(['a', 'b', 'c'], {'a': dict(system='C'), 'b': dict(system='A2'),
                                                   'c': dict(system='C')}) == {'A2': 1, 'C': 2})
t('MIN_FARKLI sayısı özette', R.tab_summary([dict(flags=['MIN_FARKLI'])])['n_MIN_FARKLI'] == 1)
t('S_D κ = 0 işaret kenarı', R.build_sets([row('Z0', 0.0, -1.0)])['SD'] == ['Z0'])

# ================================================================== v3 ekleri (B3v2-1…4): A istisna tablosu, κ_eig, özet
class MA3(MA):
    def __init__(self, cross, ref_raise=False, jac_ex_raise=False, newton_raise=False, cross_raise=False,
                 dmu_raise=False, dmu_flat=False, jordan=False, **kw):
        MA.__init__(self, cross, **kw)
        self.ref_raise, self.jac_ex_raise, self.newton_raise = ref_raise, jac_ex_raise, newton_raise
        self.cross_raise, self.dmu_raise, self.dmu_flat, self.jordan = cross_raise, dmu_raise, dmu_flat, jordan

    def reference_margin(self, *a, **kw):
        if self.ref_raise:
            raise RuntimeError('ref')
        return MA.reference_margin(self, *a, **kw)

    def jac(self, lay, x, refs, G):
        if self.jac_ex_raise and abs(G[0] - 0.9) < 1e-12:
            raise RuntimeError('jac G_ex')
        if self.jordan:
            w = 100.0
            return np.array([[0, -w, 1, 0], [w, 0, 0, 1], [0, 0, 0, -w], [0, 0, w, 0]], dtype=float)
        return MA.jac(self, lay, x, refs, G)

    def newton_fixed_refs(self, *a):
        if self.newton_raise:
            raise RuntimeError('newton')
        return MA.newton_fixed_refs(self, *a)

    def crossings(self, *a):
        if self.cross_raise:
            raise RuntimeError('crossings')
        return MA.crossings(self, *a)

    def eig_branch(self, lay, J, th, w, lam):
        if self.dmu_raise and abs(w - 100.0) > 0:
            raise RuntimeError('eig_branch')
        if self.dmu_flat:
            return complex(complex(lam).real, 0.0), None, None, None
        return MA.eig_branch(self, lay, J, th, w, lam)


class BadM:
    """A_of'ta (iki indeks) çalışır; 9c ve adım 10'da (tek indeks / np.diag) istisna verir."""
    def __getitem__(self, idx):
        if isinstance(idx, list) and len(idx) == 2:
            return np.ones(2)
        raise RuntimeError('M')

    def __array__(self, *a, **kw):
        raise RuntimeError('M array')


def runA3(ma, lay=None, kap_raise=False, setup_raise=False):
    eng = R.Eng(NS(ref_sign_of=ref_sign_of), ma, None, MYA(kap_raise), sel={})
    if setup_raise:
        eng.setup_point = lambda r: (_ for _ in ()).throw(RuntimeError('kurulum'))
    else:
        eng.setup_point = lambda r: dict(lay=lay or LAY, G=np.array([1.0]), P=None, x0=np.array([0.0]), refs=None,
                                         sb=0, th=0.0)
    return eng.compute_A(dict(id='T', system='A2', dGf=0.09, dGref=0.0999), dict(cls='OK'))


t('A istisna 1 → NE-ref', runA3(MA3([(100.0, 0.1, 0.0)], ref_raise=True))['cls'] == 'NE-ref')
t('A istisna 3 → NE-hata', runA3(MA3([(100.0, 0.1, 0.0)], jac_ex_raise=True))['cls'] == 'NE-hata')
a = runA3(MA3([(100.0, 0.1, 0.0)], newton_raise=True))
t('A istisna 4 → dσ tanımsız, EŞİK_VARSAYILAN', a['dsig_ddG'] is None and 'EŞİK_VARSAYILAN' in a['flags']
  and a['cls'] == 'KİMLİK')
t('A istisna 6 → NE-hata', runA3(MA3([(100.0, 0.1, 0.0)], cross_raise=True))['cls'] == 'NE-hata')
a = runA3(MA3([(100.0, 0.1, 0.0)], dmu_raise=True, port_eig=[0.3, 5.0]))
t('A istisna 7 → aday elenir ve kaydedilir', a['I1'] is False and len(a['elenen']) == 1
  and a['elenen'][0][1].startswith('istisna'))
a = runA3(MA3([(100.0, 0.1, 0.0)], dmu_flat=True, port_eig=[0.3, 5.0]))
t('A Im dμ/dω = 0 → aday elenir ve kaydedilir', a['I1'] is False and a['elenen'] == [(100.0, 'Im dμ/dω = 0')])
LAYB = NS(keep=[0, 1], port=[0], M=BadM())
a = runA3(MA3([(150.0, 0.1, 0.0)], port_eig=[0.3, 5.0]), lay=LAYB)
t('A istisna 9c → GİZLİ değil, GİZLİ_HATA', 'GİZLİ_HATA' in a['flags'] and a['gizli'] is False and a['cls'] == 'İHLAL')
a = runA3(MA3([(100.0, 0.1, 0.0)]), lay=LAYB)
t('A istisna 10 → yalnız rapor alanı boş', a['cls'] == 'KİMLİK' and 'cond_Krr' not in a)
t('A kurulum istisnası → NE-hata', runA3(MA3([(100.0, 0.1, 0.0)]), setup_raise=True)['cls'] == 'NE-hata')
# sayısal Jordan bloğu κ_eig'i sonlu (~1e7) verir; |yᵀv| koruması tam dikliktedir. Kablolama için kappa_eig yamalanır
_ke = R.kappa_eig
R.kappa_eig = lambda A: (complex(0.0, 100.0), None)
try:
    a = runA3(MA3([(150.0, 0.1, 0.0)], port_eig=[0.3, 5.0]))
finally:
    R.kappa_eig = _ke
t('A κ_eig tanımsız → EŞİK_GENİŞ ve 9b değerlendirilemedi (EKSEN)', a['kappa_eig'] is None
  and 'EŞİK_GENİŞ' in a['flags'] and a['e_id_ok'] is None and a.get('e_id_neden') == 'κ_eig tanımsız'
  and a['cls'] == 'EKSEN')
b = runB(MB(), crec=dict(cls='NE-hata'))
t('B: C NE-hata devralınır (B3v2-1)', b['cls'] == 'NE-hata')
t('ΔG_son: A NE-hata ve ΔG*_ex yok → NE-hata (B3v2-4)', R.delta_son(dict(cls='OK'), dict(ne='NE-hata')) == (None, 'NE-hata'))

# --- summaries (B3v2-3): sentetik kayıtlarla çökmeden ve doğru sayımlarla
rows_s = {i: dict(id=i, system=f, ref_sign=rs) for i, f, rs in
          (('P1', 'A2', -1.0), ('P2', 'B2', 1.0), ('D1', 'C', -1.0))}
sets_s = dict(SP=['P1', 'P2'], SO=['P1'], SD=['D1'], ALL=['P1', 'P2', 'D1'], SX=['P2'])
cre = {'P1': dict(id='P1', cls='OK', k_Cb=-0.3, k_dis=0.1, k_G=0.1, k_N=0.0, k_Co=0.0, k_res=-0.2,
                  flip1='TEK(κ_Cb)', flip2='TEK(κ_res)'),
       'P2': dict(id='P2', cls='OK', k_Cb=0.2, k_dis=0.1, k_G=0.1, k_N=0.0, k_Co=0.0, k_res=0.1, flip1=None, flip2=None),
       'D1': dict(id='D1', cls='NE-ayrışım')}
are = {'P1': dict(cls='KİMLİK', ref_sign_ex=-1, delta_tab=-2e-5, delta_tab_pred=-2e-5, ayirt=True, flags=[], thr=1e-7),
       'P2': dict(cls='EKSEN', e_id_ok=None, ref_sign_ex=1, delta_tab=-1e-5, delta_tab_pred=None, ayirt=False,
                  flags=['9B_HATA'], thr=1e-7, elenen=[(1.0, 'x')]),
       'D1': dict(cls='NE-ref', ref_sign_ex=1, flags=[])}
bre = {'P1': dict(cls='TEK_DAL'), 'P2': dict(cls='RAKİP_GEÇİŞ'), 'D1': dict(cls='TEK_DAL')}
sm = R.summaries(sets_s, cre, are, bre, rows_s)
t('summaries: sınıf sayıları', sm['A_class_counts_SP'] == {'EKSEN': 1, 'KİMLİK': 1})
t('summaries: etiket ve S_D yorumu', sm['label_change']['SD'] == {'-1->1': 1}
  and sm['SD_yorum']['D1']['yorum'] == 'göreli eşik artefaktı')
t('summaries: EKSEN alt, S_X aile, elenen', sm['EKSEN_alt'] == dict(saglandi=0, degerlendirilemedi=1)
  and sm['SX_aile'] == {'B2': 1} and sm['n_elenen_aday'] == 1)
t('summaries: C istatistikleri', sm['C']['SO']['flip1'] == {'TEK(κ_Cb)': 1} and sm['n_C_ok'] == 2
  and sm['C']['ALL']['k_Cb']['n_neg'] == 1)

# ------------------------------------------------------------------ sonuç
for n in FAIL:
    sys.stdout.buffer.write(('KALDI: %s\n' % n).encode('utf-8'))
sys.stdout.buffer.write(('SENTETİK: %d/%d geçti\n' % (len(PASS), len(PASS) + len(FAIL))).encode('utf-8'))
sys.exit(0 if not FAIL else 1)
