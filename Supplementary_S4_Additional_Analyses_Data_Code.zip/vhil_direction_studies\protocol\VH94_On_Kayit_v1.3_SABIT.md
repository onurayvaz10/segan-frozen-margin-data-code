# VH94 — Anahtarlamalı devre modelinde yanlılık yönünün eşleşik sınaması · Ön-kayıt v1.3 SABİT

2026-10-29 · yazar: Claude Code (Opus 5.5), ana oturum · G94 madde 1
Önceki sürümler: v0.1 (sha256 24e27d5da7fa631319000a18a9c2512a17e745d884208b6f6b336e5b712b5dca), v0.2 (ff4124ef8aab4e884125ba891c5a8b5247359451c11aff074497c695df32b18d). Denetimler: D1 (`denetim/VH94_On_Kayit_denetimi_D1.md`, b48b947ff8c574cde4bb67a884c4435b418d2ea4daf3b56be564eb6528431f85, REVISE), D2 (`denetim/VH94_On_Kayit_denetimi_D2.md`, 20db16f0796c06e20746b061c0d7340a37e54aed172f609e3666b567350ced60, REVISE). Bu belge kendi kendine yeter; önceki sürümlere atıf yalnız tarihçe içindir. D2 düzeltme eşlemesi §11. Revizyon turu 3/3 (D3 son denetim).

## 1. Statü

**SABİT** (2026-10-29). Kaynak: TASLAK v0.3 (sha256 32a8b6b63911d1a3aad3b097e46fd6a8ad2903bafea53b726c9c6799da078182) + D3'ün mekanik düzeltmeleri (§12). D3: `denetim/VH94_On_Kayit_denetimi_D3.md` (sha256 355de20e430cf10410422fc400ad3d01579a50eb7176d0411c93c1fbf4d6b454), ACCEPT_FOR_FIXATION. Bu belge yürütme yetkisi vermez; sıra: tek-koşu kapısı (B1, B2, B3, yetki, B4 ayrı oturumda, B5). §12, önceki bölümlerle çelişen yerlerde geçerlidir. Yetki dayanağı: kullanıcı talimatı 2026-10-29 (G94 planı; karar kayıtları D-262, D-263; sapmalar SABİT ile birlikte D-264'e yazılır).

**Tek-koşu kapısından beyan edilen sapmalar (D-264'te kayda geçer):**
- (S-a) B2'ye bir Typhoon teknik duman koşusu eklenir (§9). Yetki dayanağı SABİT ve D-262'dir; B2 adımı olduğu için yetki dosyası gerektirmez, kampanya betiği duman kipinde `--verify` adımını atlar. Körleme: duman yalnız 0.01 pu'da koşar (iki marjın %20'sinin altında); duman betiği mod uydurmaz, büyüme hızı hesaplamaz. SMOKE_B0 hiçbir rapor kalemine (R-3 dahil) girmez.
- (S-b) "Kayıt" = koşunun kanonik klasöründe `capture.npz` bulunması. Kaydı olan bir koşu asla yinelenmez. Kaydı olmayan bir koşu (Typhoon/Python çökmesi, duvar saati sınırı) toplam en çok iki kez denenir; deneme sayısı ledger'daki `run` satırlarından sayılır, kampanya yeniden başlatılsa da sıfırlanmaz. Kaydı olmayan klasör `_basarisiz_<saat>` adıyla saklanır; böyle bir klasörde `capture.npz` bulunursa bütünlük hatasıdır (§8 satır 1). Yeni bir WHEA olayı kampanyayı kesin olarak bitirir; ledger'da WHEA durdurması varsa kampanya betiği yeniden çalışmaz.

## 2. Soru, kapsam, dayanak

**Tanımlar.** ΔG*_f: x₀'da donmuş küçük-sinyal marjı; ΔG*_t: yeniden dengelenmiş referans marjı. **İyimser** vaka: ΔG*_f > ΔG*_t (κ < 0 öngörür). **Tutucu** vaka: ΔG*_f < ΔG*_t (κ > 0 öngörür). Alt simge d, 1.5·Ts gecikmeli ortalama modeli (§5.1) gösterir.

**Soru.** Aynı kesme miktarı ΔG_m'de, (i) donmuş marjın zaman uzayı karşılığı olan dengeye sabitlenmiş artımsal iletkenlik kaldırma (F) ile (ii) gerçek kesme (R) arasındaki kritik mod sönüm farkı D = σ̂_F − σ̂_R, Typhoon Virtual HIL anahtarlamalı devre modelinde sign κ_d ile aynı işareti taşıyor mu?

**Neden bu fark yönü sınar.** Kritik modun büyüme hızı her sistemde kendi sınırı yakınında doğrusaldır: σ_F(ΔG) ≈ s_F·(ΔG − ΔG*_f), σ_R(ΔG) ≈ s_R·(ΔG − ΔG*_t), s_F, s_R > 0. ΔG_m = (ΔG*_f + ΔG*_t)/2'de D = (s_F + s_R)·Δ/2, Δ = ΔG*_t − ΔG*_f, yani sign D = sign Δ = yanlılığın yönü. Makalenin birinci derece kuralı sign Δ = sign κ der. ΔG = 0'da D = 0; fark yalnız iki sınırın arasındaki miktarda yön taşır. **Ön kabuller** (pilot alanı `precond`; tutmazsa vaka NE): 1.05·ΔG*_t,d'de R'nin ve 1.05·ΔG*_f,d'de F'nin spektral apsis modu kritik salınım modudur ve pozitiftir; sign κ_d = sign Δ_d = sign D_pred. Pilot v3'te altı vakada tutuyor.

| Sınama | Dayanak |
|---|---|
| H1 (birincil): sign D = sign κ_d, vaka başına | makale §4 Lemma 1 ve §5.1; P93 (D-261): 1.5·Ts gecikmeli ortalama modelde 50/50 (`P93_sonuc_raporu_B5.md`, §4) |
| R-1…R-7 (yalnız rapor) | ortalama-model öngörüleri (`vh94_pilot.json` v3) |

**Göstermez.** Fiziksel donanım, gerçek zaman, CHIL/PHIL, koruma, saha; anahtarlamalı modelin kararlılık bölgesi; bağımsız fiziksel geçerlilik (Typhoon ve ortalama model denklemleri, parametreleri, kalibrasyonu paylaşır); büyük-sinyal güvenliği. Typhoon modelinde ölü zaman 0, anahtar kaybı yok, ölçüm ideal, GFM DC kaynağı ideal (sabit gerilim). Donmuş öykünme bir analiz yapısıdır, fiziksel cihaz değildir. Koruyucu geri alma (C-11) bir ölçüm güvenlik önlemidir, koruma tasarımı değildir. Vakalar büyük göreli donmuş-marj hatasına göre seçildi; ayrımı kolaylaştırır, tipik vakaları temsil etmez.

**Kanıt tavanı: E4** (çevrimdışı, platformlar arası sanal). E5/E6 iddiası yoktur.

**Hüküm → hipotez.** §8 satır 2 geçildikten sonra tek bir DISAGREE RET verir. TUTARLI yalnız "seçilen vakalarda anahtarlamalı modelde yön kuralıyla çelişki bulunmadı" demektir.

## 3. Körleme ve görülenler (K-1; yazar beyanı, LOW CONFIDENCE doğrulanabilirlik)

| Nicelik | Durum |
|---|---|
| VH94 Typhoon koşularının çıktıları | **körlenmiş** (yok) |
| Codex v3 Typhoon kayıtları (3 vaka, yalnız rampa, 1/60 s ortalama; 0.0691, 0.2512, 0.05 pu) | görüldü; F2-0.65-0.20 tepkisi sönmedi. Kısmen sızmış: F2 R koşularının öngörülenden az sönümlü olabileceği biliniyor |
| Ortalama model: pilot v1 (spektral apsis), v2 (`rotate=True`), v3 (`rotate=False`, birincil) | görüldü (öngörü). v1→v2 çatallanması: v1 spektral apsis −11.3 s⁻¹ gerçel modunu seçiyordu → salınım modu seçimine geçildi; darbe hedefi 2·10⁻³'ten 3·10⁻³ pu'ya, kırpma alt sınırı 0.002'den 0.001'e indi (v1'de bütün darbeler alt sınıra takılmıştı) |
| Ortalama-model kuru koşuları v1 ve v2 (§9 S6; pinli) | görüldü: tam zaman çizgisinde kestiricinin öngörüyü bulup bulmadığı (öngörünün kendisine karşı kestirici sınaması; Typhoon değil) |
| B2 duman koşusunun teknik nicelikleri | SABİT'ten sonra; mod/σ hesaplanmaz |
| TSV, P93 mühürlü değerleri | görüldü; vaka seçimi bunlarla, pilottan önce (G94 plan §2a) |

## 4. Pinler (tam yol, bayt, SHA256)

Önekler: `G92 = C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme92_20261026`; `G94 = C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme94_20261029`; `CX = C:\Users\onura\Documents\Codex\2026-10-28\segan-frozen-formatted-zip-dosyas-na\work`; `WK = C:\Users\onura\Documents\SEGAN_G94_work`; `S3A = WK\audit_v3\s3`.

| Dosya | Bayt | SHA256 |
|---|---|---|
| `G94\G94_PLAN_v1.md` | 8873 | 832fc51325eea48168fc117c48e76107c5f8a9bc04ebbeeeb7cc753926836e77 |
| `G94\kod\vh94_pilot.py` (v3) | 12128 | 68b80156bd7c9e3d26f559b6e4fe230d3082e2f129f6b48e051de7eb698dc3f6 |
| `G94\kod\archive\vh94_pilot_v2_66c267c1.py` | 9455 | 66c267c14e5e5c037c40ad20d8dda83faad5170152d9ac83712ddaae0a86c4f3 |
| `WK\vh94_pilot\vh94_pilot.json` (v3, öngörü kaynağı) | 37235 | 21e56aa6d6a8687603e8b8c26715341d1bcbef8c899fd488c7604fb2dc6099d0 |
| `WK\vh94_pilot\vh94_pilot_v2_rotateTrue.json` (kayıt) | 22354 | 05765b63fbaba0388df136497ed5c9e93d792af426d5dd2e170e1a485df7cff5 |
| `WK\vh94_pilot\vh94_pilot_v1_spektral_apsis.json` (kayıt) | 12808 | e54b29016eaccf588439f6894037345d925849e906bbfd63407734b5db99bcc0 |
| `WK\vh94\dryrun_v1\dryrun.json` (kuru koşu v1, kayıt) | 15608 | c33d06c02c82dead83ea0813f6d782ad8f53571afb79bff30ef9c7a3938ad565 |
| `WK\vh94\dryrun_v2\dryrun.json` (kuru koşu v2) | 17122 | 60dc8b4134ae5196cc13e9fd52c0f21b586953cdb1dac11e105afc00fe178a1e |
| `G92\kod\ext_engine.py` | 28393 | 22feea1836b7e3b475e86efc0c3660eb742f83cd224444a2317ff001bd58489e |
| `G92\kod\ext_common.py` | 21468 | b11b55cd58665944e7371aece67dd2dea147bdae7156cc75190b8668544e811a |
| `G92\kod\ext_engine_d.py` | 30767 | 780c4d95a6748a137fd6ba0045603dda025c001b4d073bd3553fe62a76851cea |
| `G92\kod\ext_common_d.py` | 21470 | 98747eef15690f25b882850a04e77f53c22bbb21375fa7750b1a0c08242da727 |
| `G92\girdi\development_20261026\out\tsv\selection.json` | 2635991 | 2d5a00d86497b174277d238293e08129f901627da99844552dcfcc397d981b53 |
| `G92\girdi\development_20261026\out\tsv\TSV_a\analysis\points.csv` | 2111107 | 6a099961188a4cdf51865fbc0e370c2c9ce5a8e961e55a8a7e23e01dcbb844e7 |
| `G92\out\P93_20261026_a\sonuc.json` | 9622 | 4c9acafa7a0807b26280649dd6ad65f08c76da885bcfbf6f553f78fec3235325 |
| `G92\protokol\P93_sonuc_raporu_B5.md` | 4810 | 57bb997c8e59a77466b5a882f0a791d231aff62a3a52ec80ad14da2d50ba6541 |
| `S3A\analysis\virtual_hil_raw_audit.json` | 8697 | a20791b22dc30dfd3e3233aa352b4375919eae9e51904f43d97461a84b8ebcb5 |
| `CX\virtual_hil_protocol.json` | 6212 | 238275dc4d3124d19c5bc4690c927ed58e16986875ff3efea8424c5443a2f178 |
| `CX\independent_emt\ramp_plan.json` | 1136 | 5d5524e5954f4fcb6c2b20f280af22b8b242ba5f56d4758e1540e4d4b2a48e6b |
| `CX\segan_typhoon\build_plant.py` | 14731 | 65e6a2bfa30d04448f48733ddb84e55e0022af1fa6cf5da7b4e111c67a5180b5 |
| `CX\segan_typhoon\controller_code.py` | 8006 | 1386ae79c560899ee82885b6452e1fa884493a4e5fc6801c774f2ed7690f258c |
| `CX\segan_typhoon\controller_src\controller_math.c` | 3075 | 43c9eb5d4d357eba9c9d43171f839c6a36dc422f6e1850bb30035b2679f86732 |
| `CX\segan_typhoon\controller_src\controller_math.h` | 647 | 9ea2fff2387661f0996472e88473bfbfee137f0df7f408eb5805abefd0f8120b |
| `CX\segan_typhoon\audit_model.py` | 4223 | a1c2072068d2fb0baa7b1af9e8f3cfe6754ba2d387f864e1a756cdadaa32005d |
| `CX\segan_typhoon\audit_compiled_timing.py` | 2766 | e1fcdaf74b68a3ab85d05cb4b7765d0f0424d3743c2cc9aaaddeb4b88aca028e |
| `CX\segan_typhoon\run_validation.py` | 7175 | ad38b71808202d3684b37eb9b181fa7fdf1df67926f1b9116d759bf27d4a24e7 |
| `CX\segan_typhoon\hardware_reliability\run_guarded_native.ps1` | 3559 | 59279134cadbd0a1d9900dce39e89bf5ff51915111eefac3c9d883cb2ef8a029 |
| `CX\independent_emt\calibrate.py` | 4250 | a525facb8090b46d10b3f8e6ba32d6f44d193614318ed5f786af4c228d6235e9 |
| `CX\independent_emt\model.py` | 6895 | 04678aba0b243bac49856dbfff3c8c4e993da9ba0d9780b8e1bfed85f72a0441 |
| `CX\independent_emt\calibration_A2-F00993.json` | 3872 | 077aad9d7bd39c084a44ebca790ab248e4dbfcf51ab000573cb545f8f9b8eb2b |
| `CX\independent_emt\calibration_F2-0.65-0.20.json` | 3705 | 9c408b4714de473fce8d1fc10b04589494bf6d1e786dcf496ed194bc65f2d1cb |
| `CX\independent_emt\calibration_F2-0.60-0.20.json` | 3702 | e849b6db120a3b5b690a00183edf4b2339424889b10e12b6148144a57d55bde8 |

B1 dosyaları (`WK\vh94\` altındaki VH94 betikleri, `calibrate_vh94.py` ve üç yeni kalibrasyon) SABİT'ten sonra `vh94_run.py` PINS tablosuna bayt + sha256 ile yazılır; B3 denetçisi bu tabloyu SABİT ile karşılaştırır. Sürümler: Typhoon HIL Control Center 2026.3 (gömülü Python 3.11.4 / NumPy 2.2.3); analiz Python 3.13.2 / NumPy 2.5.3.

## 5. Tanımlar

### 5.1 Vakalar, miktarlar, öngörü modeli

Altı vaka (G94 plan §2a, pilottan önce sabit): iyimser A2-F00993, A2-F01921, A2-F00357; tutucu A2-F00138, F2-0.65-0.20, F2-0.60-0.20.

**Öngörü modeli:** P93 motoru (`ext_engine_d.py`), 1.5·Ts = 75 µs ikinci derece Padé gecikmesi, `rotate=False`. Gerekçe (INFERENCE): Typhoon denetleyicisi dq komutunu bir PWM periyodu tutar ve PWM'de güncel çerçeve açısıyla ters dönüştürür (`CX\segan_typhoon\controller_code.py` satır 56–58, 88, 93). GFM için bu, gecikme sırasında çerçeve dönüşü uygulanmamasına tam denk gelir. CPL için yaklaşıktır: Typhoon CPL komutunu ortak çerçevede tutar, model gecikmeyi CPL'nin PLL çerçevesinde uygular; dengede ikisi aynı hızla döner, küçük-sinyalde fark PLL frekans sapmasıyla orantılıdır. Duyarlılık (pilot `rotate_alt`): `rotate=True` ile altı vakanın altısında D_pred'in işareti aynı, |ΔD_pred| ≤ 1.26 s⁻¹.

| Nicelik | Alan (`vh94_pilot.json` v3 → `cases[i]`) | Kural |
|---|---|---|
| s_pred | `sign_pred_D` | sign(`kappa_d`) |
| ΔG_m; ΔG_lo, ΔG_hi | `amounts.m`; `amounts.lo`, `amounts.hi` | (ΔG*_f,d + ΔG*_t,d)/2; 0.95/1.05·ΔG*_t,d |
| δg_p | `pulse.dg_p` | R_m ve F_m noktalarındaki birim darbe yanıtlarının geometrik ortalaması için 30 ms'de kritik mod genliği 3·10⁻³ pu; [0.001, 0.05] pu'ya kırpılır |
| σ_p, f_p, σ_r (koşu başına) | R_x: `pred_d.x.sigma_R/f_R/sr_R`; F_m: `pred_d.m.sigma_F/f_F/sr_F`; B0: `pred_d.zero.sigma_R/f_R/sr_R` | kritik salınım modu: 30–300 Hz bandında gerçel kısmı en büyük öz değer; σ_r: |Im|/2π < 1 Hz olan en yavaş gerçel mod |
| ön kabuller | `precond`, `status` | §2 |

Pilot v3 (bilgi; bağlayıcı olan JSON):

| Vaka | κ_d | ΔG*_f,d | ΔG*_t,d | D_pred (s⁻¹) |
|---|---|---|---|---|
| A2-F00993 | −0.240 | 0.30818 | 0.26602 | −20.69 |
| A2-F01921 | −0.186 | 0.27198 | 0.23747 | −17.11 |
| A2-F00357 | −0.130 | 0.26266 | 0.23848 | −12.69 |
| A2-F00138 | +0.121 | 0.07787 | 0.08701 | +3.33 |
| F2-0.65-0.20 | +0.239 | 0.05880 | 0.07471 | +7.51 |
| F2-0.60-0.20 | +0.179 | 0.08560 | 0.10128 | +8.46 |

Kritik mod frekansları: R/F koşularında 70–105 Hz; B0'da 62–97 Hz. B0'da σ_p −28…−131 s⁻¹.

### 5.2 Typhoon modeli (Codex kurucusundan; C-1…C-11 dışında değişiklik yok)

- **C-1** Altı vaka kimliği. Üç yeni A2 kalibrasyonu (A2-F01921, A2-F00357, A2-F00138) `WK\vh94\independent_emt\calibrate_vh94.py` ile üretilir ve betiğin klasörüne yazılır. Bu betik `calibrate.py`'den yalnız şu noktalarda ayrılır: dağıtım `tol=1e-12`, kabul `ok` ya da kalıntı ≤ 1e-10 (gömülü 1e-13 toleransı A2-F00138'i 1.12·10⁻¹³ kalıntıyla reddetmişti); altı karşılaştırma denemesinde `max_abs ≤ 1e-9` kabulü betikte uygulanır, aşılırsa hata verir. Ön-uçuş: kalıntı ≤ 1.84·10⁻¹³, `max_abs` ≤ 2.09·10⁻¹². Codex'in üç kalibrasyonu (§4) değişmez.
- **C-2** SCADA girişleri `Shed_dG`, `Frozen_dG`, `Pulse_dG`.
- **C-3** Zaman çizgisi, tamsayı devre adımlarıyla: kilit [0.20, 0.30) s; rampa r(t) = min(1, max(0, (t − 0.30)/0.25)); darbe p(t) = 1, [0.560, 0.565) s; süre 1.80 s.
- **C-4** Kilit: [0.20, 0.30) boyunca `sx[2]`, `sx[3]` toplanır; son pencere adımının güncellemesinde v₀ = ortalama ve `latched = 1` olur (t = 0.30'da rampa hâlâ 0).
- **C-5** g_real = shed_dg·r + pulse_dg·p; g_frz = frozen_dg·r.
- **C-6** Faz başına enjeksiyon `i_k = (g_real·v2_k + g_frz·(v2_k − v2eq_k))/14.44` A; `v2eq_k = 0.81649658092772603273·380·(v₀d cos θ_k − v₀q sin θ_k)`, θ_k = θ − 2πk/3, θ denetleyicinin ortak çerçeve açısı.
- **C-7** PWM periyodu ortalamaları `v2d_pm`, `v2q_pm`, `vdc_pm`.
- **C-8** `conductance_pu = g0 − g_real − g_frz`.
- **C-9** Kayıt aralığı 100 µs; kanallar: `v2d_pm, v2q_pm, vdc_pm, latched, v0d_latched, v0q_latched, conductance_pu, simulation_clock_s, feedback_ready, peak_gfm_mod, peak_rectifier_mod, minimum_dc_pu, stored_energy_pu_s, balance_pu_s, supplied_energy_pu_s, p_gfm_mean_pu, p_load_mean_pu, p_losses_mean_pu, frequency_pu, ia, mg, mc, dc_pu, tripped, v2_ref`.
- **C-10** `run_vh94.py`, Codex `run_validation.py`'den yalnız şu noktalarda ayrılır: senaryo değerleri pilot JSON'dan (sha denetimi); üç SCADA girişi; çıktı klasörü `--outroot` altında ve önceden var olamaz; süre 1.80 s, kayıt 100 µs, C-9 kanalları; girdi hash'lerine `controller_code_vh94.py` ve `run_vh94.py` eklenir, Codex protokol dosyası hash'i çıkarılır (VH94 kendi protokolüne bağlıdır); CSV çıktısı yazılmaz (yalnız `capture.npz` ve satıcının ham CSV'si); F2-0.60-0.20 için Codex'in bağımsız-referans ön koşulu yoktur; `run_status.json`'a `plan_sha256`, `shed_dg/frozen_dg/pulse_dg`, `expected_rows`, `capture_npz_sha256`, `wall_s`, `first_nonfinite_time_s` eklenir; kayıt sonluluk denetiminden **önce** yazılır.
- **C-11 (yeni, D2 F-1)** Koruyucu geri alma: [0.530, 0.555) s'de |v2_pm| ortalaması `v2_ref` olarak kurulur. t ≥ 0.595 s'de ||v2_pm| − v2_ref| > 0.08 pu olursa kaldırma geri alınır (g_real = g_frz = 0) ve koşu sonuna kadar öyle kalır; `tripped = 1`. Analiz 0.05 pu'da keser; bu yüzden uydurma penceresi olağan durumda geri almadan önce biter; aksi hâlde `tripped = 0` kapısı koşuyu NE yapar. Başvuru farkı beyanı: denetleyici başvurusu adım başına periyot ortalamalarının ortalamasıdır, analiz başvurusu 100 µs örneklerinin medyanıdır; fark gürültü düzeyindedir ve 0.03 pu payın çok altındadır (INFERENCE). Geri alma, kararsız koşuların pencereden sonra ıraksamasını ve bunun kaydı ya da satıcı bayraklarını bozmasını önler. Ortalama modelde benzetimi kuru koşu v2'dedir.

Değişmeyenler: SI devre, LCL, DC bağlantıları, 20 kHz min-max PWM, 50 µs komut güncelleme ve bir periyot tutma, `controller_math.c/.h` (bayt bayt aynı), VHIL+ yapılandırması, çift hassasiyet, `enb_pole_shift = False`.

### 5.3 Senaryolar

| Kod | shed_dg | frozen_dg | pulse_dg | Adım |
|---|---|---|---|---|
| B0 | 0 | 0 | δg_p | 25 ns |
| R_m | ΔG_m | 0 | δg_p | 25 ve 50 ns |
| F_m | 0 | ΔG_m | δg_p | 25 ve 50 ns |
| R_lo | ΔG_lo | 0 | δg_p | 25 ns |
| R_hi | ΔG_hi | 0 | δg_p | 25 ns |

42 koşu, 12 derleme. Sıra: vaka sırası (§5.1); vaka içinde 50 ns derleme → R_m, F_m → 25 ns derleme → B0, R_m, F_m, R_lo, R_hi. Aynı anda tek Typhoon süreci; Codex bekçisinin kopyası yeni WHEA olayında durur. Duvar saati: Codex'te 2.75 s'lik koşu 25 ns'de 152 s sürdü (`CX\segan_typhoon\guarded_native_runs\F2-0.65-0.20_ramp_0p025us_20261029_002453_guard.json`, başlangıç 00:24:53.9, bitiş 00:27:26.0); 1.80 s'lik koşu için ≈ 100 s beklenir (INFERENCE); bekçinin 1040 s ve koşu betiğinin 900 s sınırı bunun çok üstündedir.

### 5.4 Gözlenen

y(t) = √(v2d_pm² + v2q_pm²) (pu), 100 µs aralıkla. PWM periyodu ortalamasının 70–105 Hz'deki kazancı > 0.999. Kritik mod liman kesişiminden geldiği için liman (bara-2) geriliminde gözlenebilir. İkincil (rapor) kanal vdc_pm.

### 5.5 Kestirici

1. t_a = 0.595 s (darbe sonu + 30 ms).
2. σ_p, f_p, σ_r §5.1'den.
3. T_w = min(1.2, max(0.25, 4/|σ_p|)) s; σ_p = 0 ise T_w = 1.2 s. t_b = min(t_a + T_w, 1.795 s).
4. y_ref = medyan y, [0.530, 0.555] s. İlk t > t_a için |y − y_ref| > **0.05 pu** ise t_b o an olur. t_b − t_a < **0.06 s** ise koşu NE ("pencere"). 0.06 s, 70 Hz'de 4.2, 87 Hz'de 5.2 çevrimdir.
5. Model: y(τ) ≈ c₀ + c₁τ + c₂·e^{σ_r τ} + e^{στ}(a cos ωτ + b sin ωτ), τ = t − t_a. σ_r pilotun sabit değeridir (yoksa sütun yok). Verilen (σ, ω) için doğrusal katsayılar en küçük karelerle bulunur; eğilim sütunları QR ile izdüşürülür.
6. Arama: kaba ızgara σ ∈ [−150, +60] s⁻¹ adım 0.5; ω/2π ∈ [0.6, 1.4]·f_p'de 81 eşit nokta. İki yakınlaştırma düzeyi: σ ±1.0 adım 0.05 ve σ ±0.1 adım 0.005; ω her düzeyde önceki düzeyin ±1 adımında 41 nokta. En iyi nokta kutu kenarındaysa kutu oraya kaydırılır (en çok 10 kez); yine kenardaysa `zoom_edge`. Eşitlikte ilk en küçük alınır (dış döngü ω, iç döngü σ, artan sıra).
7. Kalite (sağlanmazsa koşu NE): (q1) kaba ω indeksi uçta değil, σ̂ ∈ (−149.5, 59.5), `zoom_edge` yok; (q2) R²_osc = 1 − RSS/TSS₁ ≥ 0.5, TSS₁ yalnız eğilim sütunlarıyla kalan kareler toplamı; (q3) A₀ ≥ 10·n₀, n₀ = [0.20, 0.30) s'de y'nin doğrusal eğilimden arındırılmış standart sapması.
8. Pencere değişkeni: t_b' = t_a + 0.6·(t_b − t_a) ile σ̂'.

**Kuru koşu v2 pencere tablosu** (ortalama model, aynı eşikler; birincil koşular; bilgi):

| Vaka | R_m pencere (s) / geri alma (s) | F_m pencere (s) / geri alma (s) | σ̂ − σ_pred (R_m; F_m) | D (kuru) / D_pred |
|---|---|---|---|---|
| A2-F00993 | 0.160 / 0.800 | 0.411 / — | −0.015; +0.038 | −20.64 / −20.69 |
| A2-F01921 | 0.194 / 0.838 | 0.514 / — | −0.043; −0.026 | −17.09 / −17.11 |
| A2-F00357 | 0.347 / 1.014 | 0.658 / — | −0.015; +0.002 | −12.67 / −12.69 |
| A2-F00138 | 1.200 / — | 1.200 / — | 0.000; +0.005 | +3.34 / +3.33 |
| F2-0.65-0.20 | 1.163 / — | 0.665 / 1.364 | −0.006; +0.035 | +7.55 / +7.51 |
| F2-0.60-0.20 | 0.994 / — | 0.602 / 1.296 | +0.003; +0.033 | +8.49 / +8.46 |

30 koşunun hepsi 1.80 s'ye ıraksamadan ulaştı (C-11); R_lo/R_hi dahil bütün R/F koşularında |σ̂ − σ_pred| ≤ 0.043 s⁻¹ (B0 hariç); altı vaka AGREE. En kısa pencere 0.160 s, 0.06 s sınırının 2.7 katı.

### 5.6 Koşu kapıları ([0, t_b] üzerinde)

Önce §5.5 adım 3–4 ile t_b bulunur. Kapılar:
- model denetimi (`*.audit.json` `all_passed`), derleme zamanlaması (`compiled_timing_valid`, düzeltilmiş yürütme hızı 0), girdi hash'leri;
- satıcı bayrakları temiz (bütün koşu; geri alma ıraksamayı önlediği için koşu sonu davranışı bayrakları bozmamalıdır; bozarsa koşu NE);
- satır sayısı beklenen ±1;
- **t ≤ t_b'de:** bütün kanallar sonlu; t ≥ 0.30'da `latched = 1`; `tripped = 0`; max(mg, mc) ≤ 1.0; min dc_pu > 0;
- göreli enerji kalıntısı |ΔE_stored − ∫(p_gfm − p_load − p_kayıp)dt| / max(|∫p_gfm dt|, |E(0)|, 10⁻⁹) ≤ 0.01, [0, t_b] üzerinde (Codex `audit_virtual_hil.py` satır 39'daki tanım);
- bekçi sonucu `completed` (son deneme).

### 5.7 Mod kimliği (K-3)

(q1) ve §2 ön kabulleri.

### 5.8 Belirsizlik

u_run = max(|σ̂_25 − σ̂_50|, |σ̂ − σ̂'|); u_D = √(u_F² + u_R²); D = σ̂_F,25 − σ̂_R,25.

## 6. Sınamalar

**H1 (birincil).** Vaka değerlendirilebilir: pilot `status = ok` ve F_m ile R_m'nin 25 ns ve 50 ns koşuları §5.5–5.7'yi geçer.
- AGREE: sign D = s_pred ve |D| ≥ max(3·u_D, 0.2 s⁻¹).
- DISAGREE: sign D = −s_pred ve aynı eşik.
- UNDETERMINED: diğer durumlar (D = 0 dahil).

**Yalnız rapor:**
- R-1: σ̂_R(m) ve σ̂_F(m)'nin işaretleri ve öngörüye oranları.
- R-2: σ̂_R(lo) ve σ̂_R(hi) parantezi.
- R-3: B0 (A2'de σ_p −100.2…−130.9 s⁻¹; mod 30 ms'de gürültüye iner, büyük olasılıkla NE; tasarım gereği yalnız rapor; SMOKE_B0 dahil değildir).
- R-4: vdc_pm kanalı.
- R-5: gecikmesiz ve `rotate=True` öngörüleriyle karşılaştırma.
- R-6: Codex v3 F2-0.65-0.20 gözlemiyle tutarlılık notu.
- R-7 (D2 F-10): kilit penceresinde oturma, yani [0.20, 0.30) s'de y'nin doğrusal eğim katsayısı ve |v₀ − kalibrasyon x₀ liman gerilimi|.

## 7. Eşik gerekçesi ve çatallanma beyanı

- **0.2 s⁻¹:** ince ızgara adımı 0.005 s⁻¹'in 40 katı; 0.25 s'lik pencerede 0.2 s⁻¹ fark genlikte e^0.05 ≈ %5'tir (INFERENCE).
- **3·u_D:** sayısal adım (25/50 ns) ve pencere seçimine karşı en az üç kat ayrım. Codex v3'te adım iyileştirmesinin bara RMSE'si 2.8·10⁻⁵–3.2·10⁻⁴ pu idi (`virtual_hil_raw_audit.json`); bu, 3·10⁻³ pu modal genlikte σ̂'yi birkaç yüzde etkileyebilir (INFERENCE).
- **R²_osc ≥ 0.5, A₀ ≥ 10·n₀:** tek modlu uydurmanın gürültüye değil moda oturduğunu güvenceye alır (INFERENCE).
- **0.05 pu kesme, 0.06 s en kısa pencere (D2 F-2):** kuru koşu v1'de iyimser R_m pencereleri 0.114 ve 0.134 s idi (0.03 pu kesmeyle). t_a'daki genlik rampa uyarımı nedeniyle ≈ 8·10⁻³ pu'dur. 0.05 pu kesme pencereyi ≈ ln(0.05/0.008)/σ kadar uzatır; 0.06 s sınırıyla σ, öngörünün ≈ 2.7 katına kadar değerlendirilebilir kalır. Kuru koşu v1'de kestirici 0.114 ve 0.134 s'lik pencerelerde öngörüden ≤ 0.048 s⁻¹ saptı.
- **0.08 pu geri alma:** 0.05 pu kesmenin üstünde, 0.03 pu pay bırakır (C-11).
- Kuru koşularda (§9 S6) kestiricinin öngörüden sapması R/F koşularında ≤ 0.05 s⁻¹'dir (B0 hariç); eşikler bunun en az dört katıdır.
- **Çatallanma:** eşikler pilot öngörüleri (|D_pred| 3.3–20.7 s⁻¹) ve kuru koşu v1 görüldükten sonra yazıldı; 0.05/0.06 değişikliği kuru koşu v1 pencere uzunluklarından sonradır. Typhoon sonuçları görülmedi. Eşikler sonradan değiştirilmez.

## 8. Sıralı karar tablosu (ilk eşleşen satır hükmü verir)

| # | Koşul | Hüküm |
|---|---|---|
| 1 | Bütünlük hatası: pin/hash uyuşmazlığı, mühürsüz çıktı, protokol dışı senaryo, ledger'daki WHEA durdurmasından sonra yapılmış koşu, `_basarisiz_` klasöründe kayıt (S-b) | ABORT |
| 2 | Değerlendirilebilir vaka < 4, ya da değerlendirilebilir iyimser < 2, ya da tutucu < 2 | NOT_EVALUABLE |
| 3 | En az bir DISAGREE | RET |
| 4 | AGREE < 3, ya da AGREE vakaları arasında iyimser yok, ya da tutucu yok | BELİRSİZ |
| 5 | Satır 4 geçildi ve en az bir UNDETERMINED | KISMİ |
| 6 | Değerlendirilebilir vakaların hepsi AGREE | TUTARLI |

Tamlık: satır 2'yi geçen her bileşimde ya DISAGREE vardır (satır 3) ya yoktur. Yoksa satır 4'ün koşulu ya sağlanır ya sağlanmaz. Sağlanmıyorsa ya UNDETERMINED vardır (satır 5) ya yoktur (satır 6). Satır 6'daki her işaretten ≥ 2 şartı satır 2'den gelir.

**Değerlendirilebilirlik (K-8).** En az 4 vaka gerekir (≥ 2 iyimser, ≥ 2 tutucu). WHEA durdurması kampanyayı bitirir, eksik koşular NE sayılır ve tablo yine uygulanır. Bu durum kampanyanın yarıda kalmasıdır (sentetik S4'te adıyla sınanır). NOT_EVALUABLE'da B5 nedenleri listeler ve seçenekleri kullanıcıya sunar; protokol aynı turda gevşetilmez.

## 9. Yürütme biçimi

**Betikler** (`WK\vh94\`):
- `vh94_run.py`: `--check-only`; `--verify --run-id --yetki`; `--analyze --run-id --yetki --campaign`. stdlib + numpy; okuma/yazma `_read_bytes`/`_write_text` ile; süreç başlatmaz.
- `analyze_vh94.py`: saf fonksiyonlar.
- `vh94_static_check.py`: AST denetimi S1–S8.
- `vh94_synth.py`: S0–S5, S7.
- `vh94_avg_dryrun.py`: S6.
- `vh94_smoke_check.py`: duman denetimi.
- `segan_typhoon_vh94\`: `controller_code_vh94.py`, `build_plant_vh94.py`, `audit_model_vh94.py`, `audit_compiled_timing_vh94.py`, `run_vh94.py`, `run_guarded_vh94.ps1` ve `run_campaign_vh94.ps1` (kampanya kipinde önce `vh94_run.py --verify`; ledger'da WHEA durdurması varsa çalışmaz; deneme sayacı ledger'dan).
- `independent_emt\calibrate_vh94.py`.

**Çıktı** `WK\vh94\out\VH94_<tarih>_a\` (runs, guard_logs, campaign_ledger.jsonl, analysis_<run_id>\ mühürlü). Proje klasörüne sonuc.json, hukum.txt ve SHA256SUMS kopyalanır.

**Zorunlu sentetik testler (B2):**
- S0: vektörleştirilmiş RSS = doğrudan en küçük kareler (σ_r'li ve σ_r'siz), göreli 1e-8.
- S1: bilinen σ ∈ {−20, −5, −1.5, −0.3, +0.3, +1.5, +5, +11}, f ∈ {75, 100} Hz, f_p/f ∈ {0.85, 1, 1.15}; yavaş gerçel mod 2·10⁻³·e^{−11.3τ} ve hızlı ikinci bant modu 2·10⁻³·e^{−240(t−0.565)}cos(2π·45(t−0.565)), t ≥ 0.565 s (darbe sonu; v1.1) eklenir; gürültü 10⁻⁵ ve 10⁻⁴ pu. Kabul: |σ̂ − σ| ≤ 0.1 ve ≤ 0.5 s⁻¹.
- S2: ters Park gidiş-dönüş, 1e-12.
- S3: q1 (uçta ω), q2/q3 (yalnız gürültü, küçük genlik), 0.05 pu kesme, 0.06 s pencere sınırı.
- S4: §8'in her satırı ve kenarlar: u_D = 0, D = 0, tam eşikte |D|, tek yönlü AGREE → BELİRSİZ, yarıda kalan kampanya (NE'li vakalar) → NOT_EVALUABLE.
- S5: ortalama modelde donmuş öykünme, `rotate=False`: x₀'da kalıntı ≤ 1e-8; Jacobian `jac(x0, G−ΔG)` ile göreli 1e-6 içinde.
- **S6** ortalama-model kuru koşusu, kuru koşu v2 ile aynı kod: altı vaka, 30 senaryo, tam zaman çizgisi (kilit yerine v₀ = x₀; rampa, darbe, C-11 geri alma), gürültü 5·10⁻⁵ pu, aynı kestirici. Kabul: R_m ve F_m'de |σ̂ − σ_pred| ≤ max(0.3, 0.1·|σ_pred|) ve altı vakanın altısı AGREE. **Sıralama (D2 F-4):** kuru koşu v1/v2 SABİT öncesi geliştirme kayıtlarıdır (pinli). B2'deki S6 aynı kodla yinelenir. B2-S6 bir kod hatası nedeniyle kalırsa B1'e dönülür; kestirici tasarımı değişmek zorunda kalırsa protokol v1.1 yazılır ve yeni bir denetimden geçer.
- S7: koşu kapıları; [0, t_b] sonrasındaki modülasyon, sonsuzluk ve geri alma yok sayılır; t_b'den önceki ihlaller koşuyu düşürür; kilit eksikliği ve bekçi hatası da düşürür.

**Teknik duman koşusu (B2, S-a):** F2-0.65-0.20, 50 ns üzerinde üç koşu: SMOKE_B0 (yalnız darbe), SMOKE_F01 (frozen_dg 0.01), SMOKE_R01 (shed_dg 0.01). `vh94_smoke_check.py` şunları denetler:
- kayıt ve bayraklar;
- kilit: |v₀ − kaydedilen periyot ortalamalarının pencere ortalaması| ≤ max(10⁻⁵, 0.25·n₀) pu. Bütçe: kayıt 2000 periyot ortalamasının 1000'ini tutar; fark ≈ 0.03·n₀ (1σ), dolayısıyla 0.25·n₀ > 5σ;
- [0.70, 1.80] s'de F01'in komut enjeksiyon RMS'si R01'inkinin ≤ %5'i. Anlamı: donmuş öykünme aynı miktarda gerçek kaldırmanın çektiği akımın en çok %5'ini çeker, yani denge korunur;
- n₀ ve tepe modülasyon (rapor).

Duman mod uydurmaz. Duman başarısız olursa B1'e dönülür (revizyon turu +1), B4 yapılmaz.

## 10. Yetki ve kapı

SABİT (D-264) → B1 (PINS doldurulur) → B2 (S0–S7 + duman) → B3 ayrı kod denetimi ACCEPT → `VH94_yetki_<run_id>.json` → B4 ayrı oturumda tek kampanya → `vh94_run.py --analyze` → B5. Yeniden kampanya yoktur.

## 11. Düzeltme eşlemesi (D2 → v0.3)

| Bulgu | Yapılan |
|---|---|
| F-1 t_b sonrası ıraksama kaydı/bayrakları bozar | C-11 koruyucu geri alma; kayıt sonluluk denetiminden önce yazılır (C-10); sonluluk, kilit ve geri alma [0, t_b] üzerinde (§5.6); bayraklar bütün koşu (beyan) |
| F-2 dar pencere | kesme 0.05 pu, en kısa pencere 0.06 s; kuru koşu v2 pencere tablosu (§5.5); duvar saati notu (§5.3) |
| F-3 "kayıt üretmemiş" tanımı | S-b işlevsel tanım: kanonik klasörde `capture.npz`; ledger'dan deneme sayacı; `_basarisiz_` klasöründe kayıt → ABORT (§1, §8) |
| F-4 S6 sıralaması, kuru koşu pinleri | §9 S6 sıralama; kuru koşu v1/v2 pinli (§4) |
| F-5 belge kendine yetmiyor | tam pin tablosu ve tam hash'ler; §7 gerekçesi tam; iyimser/tutucu tanımı (§2, §4, §7) |
| F-6 D-ID, duman yetkisi, SMOKE_B0 | D-264; duman B2'dir, yetki dosyası gerekmez; SMOKE_B0 R-3'e girmez (§1, §6) |
| F-7 C-10 eksik, C-1 kökeni, kabul uygulanmıyor | C-10 tam liste; üç kalibrasyon `calibrate_vh94.py` ile yeniden üretildi ve kabul betikte uygulanıyor (§5.2) |
| F-8 CPL için rotate yaklaşık | gerekçe ve duyarlılık (6/6 aynı işaret, \|ΔD_pred\| ≤ 1.26) (§5.1) |
| F-9 küçük maddeler | %5 anlamı; ideal GFM DC kaynağı; S1'e ikinci bant modu; v1→v2 çatallanması §3'te; −100.2; B0 62–97 Hz |
| F-10 kilit oturması | R-7 rapor kalemi |
| B1-1…B1-10 | B1-1 (C-10), B1-2/B1-6 (§5.6), B1-3/B1-4 (S-b), B1-5 (S1, S4, S7), B1-7 (kilit bütçesi), B1-8 (C-1), B1-9 (kuru koşu v2'de C-11; kilit yerine v₀ = x₀ beyan, modülasyon ortalama modelde yok), B1-10 (κ = 0 hiçbir vakada yok; pilot betiği değişmedi) |

## 12. SABİT mekanik düzeltmeleri (D3, R3-1…R3-10)

- **R3-1 Kuru koşu üreteçleri (§4'e ek pinler).** Kuru koşu v1: `WK\vh94\archive\vh94_avg_dryrun_v1.py` (5764 B, fee88e847d242f720ae48b0bbbe82f174a66e8331d17d122b0e7d348e01f1826) ve `WK\vh94\archive\analyze_vh94_v02.py` (10478 B, f587b66d244ab81f495c51dc74f0ddd0d2f6c1e83bbd804642cde199ec582ddf). Kuru koşu v2: `WK\vh94\vh94_avg_dryrun.py` (6642 B, 6abc94dfb63ef6e32bbf1aba6c7274ac933f268dd4a65be5a90e407efdfcc573) ve `WK\vh94\analyze_vh94.py` (10800 B, 92a57530df547e28b7e06b22c89e6cd3c31aca69d19a6e1b9513ecb15cd297c2). §9 S6'daki "aynı kod": B2-S6, B1'in son sürümleriyle koşar (`vh94_run.py` PINS). Bu sürümler kuru koşu v2 sürümlerinden yalnız D3 kod notlarının (G-1…G-6) gerektirdiği değişikliklerle ayrılabilir; kestirici mantığı, eşikler ve karar fonksiyonları değişmez. B3 bu farkı satır satır doğrular.
- **R3-2, R3-3, R3-4, R3-7** metne işlendi (§5.5, §7, §5.2 C-11, §5.3).
- **R3-5 Kayıt tanımı ve okuma kuralları.** Satıcının ham CSV'si "kayıt" sayılmaz. Gerekçe (INFERENCE): VHIL belirlenimcidir; aynı derlenmiş model ve girdilerle yinelenen koşu aynı çıktıyı verir, dolayısıyla kaydı olmayan koşunun yinelenmesi sonuca göre seçim yapamaz. `_basarisiz_` klasörlerindeki CSV'ler açılmaz. Duman kayıtları yalnız `vh94_smoke_check.py` ile okunur, çizilmez.
- **R3-6 Dumanın kapsamı ve C-11 riski.** Duman 0.01 pu'da koşar ve C-11'i tetiklemez; C-11'i Typhoon'da sınamaz. Geri alma koşu sonunda satıcı bayraklarını bozarsa, o koşu NE olur (LOW CONFIDENCE risk; K-8'e eklenir). C-10'a ek: `run_vh94.py` SMOKE_* senaryolarını yalnız F2-0.65-0.20 ve 50 ns için kabul eder ve pilot `status = ok` denetimi yapar.
- **R3-8 Bilinçli olarak düşürülenler.** D1 R-5(iii) ortak-kayma rapor kalemi ayrı tutulmadı; R-1 (öngörüye oranlar) ve R-5 (öngörü modeli karşılaştırması) bu bilgiyi verir. S1'de σ_r uyuşmazlık varyantı yok; kestiricinin σ_r yanlışlığına duyarlılığı S6'da gerçek yavaş modlarla sınanır.
- **R3-9 Deneme sayımı ve WHEA.** Kampanya betiği her koşu denemesinden **önce** ledger'a `run_start` satırı yazar; deneme sayısı `run_start` satırlarından sayılır (sert çökmede de sayılır). WHEA denetimi kampanya başında ve her bekçi işleminden sonra (build, timing, audit, run) yapılır; yeni olayda ledger'a `stop/new_whea` yazılır ve kampanya biter. Derleme hatası o vakayı NE yapar, kampanya diğer vakalarla sürer.
- **R3-10 Klasörler.** Yetki JSON'u kampanya klasörünü (`campaign_dir`) adlandırır; `vh94_run.py --verify/--analyze` başka bir klasörü reddeder. Duman ayrı bir klasöre (`WK\vh94\out\VH94SMOKE_<tarih>_<harf>\`) yazılır. Aynı kampanya klasöründe yeniden başlatma S-b kapsamında devam sayılır.
- **D3 kod notları G-1…G-6** B1'de kapatılır ve B3'te doğrulanır: G-1 (`run_start` satırı), G-2 (bekçi işlemleri sonrası WHEA), G-3 (§5.6 girdi hash kapısı analizde: `run_status.json` `input_sha256` değerleri PINS ile karşılaştırılır, uyuşmazlık koşuyu NE yapar), G-4 (kampanya klasörü yetkiyle bağlı; duman ayrı ledger), G-5 (R-5, R-6, R-7 rapor kalemleri), G-6 (belge dizeleri).

## 13. Değişiklik v1.0 → v1.1 (B2 sonrası; 2026-10-29)

**Neden.** B2 sentetik koşusu (`SEGAN_G94_work\vh94\out\VH94SYNTH_20261029_a`, exit 2) S1'de yalnız σ = −20 s⁻¹ satırlarında kaldı (|σ̂ − σ| 0.23–1.48 s⁻¹; diğer bütün S1 satırları ve S0, S2–S5, S7 geçti). v1.0 metni hızlı ikinci bant modunu tam 2·10⁻³ genlikle pencere başına (t_a) koyuyordu. Oysa §5.5 adım 1 t_a'yı darbe sonundan 30 ms sonraya, tam da hızlı modlar sönsün diye koyar. −240 s⁻¹'lik bir mod t_a'da e⁻⁷·² ≈ 7·10⁻⁴ katına inmiş olur. v1.0 S1'i, kestiricinin karşılaşmayacağı bir durumu sınıyordu.

**Değişiklik.** S1'de ikinci bant modu darbe sonunda (t = 0.565 s) 2·10⁻³ genlikle başlar. Eski sert değişken (t_a'da tam genlik) **yalnız rapor** kalemi olarak koşulur ve kabul sayımına girmez.

**Değişmeyenler.** Kestirici, eşikler, kapılar ve karar tablosu aynıdır. Kod değişikliği yalnız `vh94_synth.py`'dedir.

**Çatallanma beyanı.** Bu değişiklik B2 sentetik sonucundan sonra yapıldı. Typhoon sonuçları görülmedi. σ = −20 s⁻¹, birincil koşuların öngörülen σ aralığının (−9.7…+11 s⁻¹) dışındadır (§5.1). Değişiklik yeni bir bağımsız denetimden geçer.

**B2 süreç notları (protokol değişikliği değil).** (i) Typhoon derlemesi kalıcı bir HAPI sunucu süreci bırakıyor; `Start-Process -Wait` alt süreçleri de beklediği için duman kampanyası derlemeden sonra takıldı. `run_campaign_vh94.ps1` artık yalnız bekçi sürecini bekliyor (`WaitForExit`); `run_guarded_vh94.ps1` çıkış kodunu tutuyor. (ii) Statik denetim S5/S8 metin taramaları PINS içindeki dosya yollarını da tarıyordu; PINS ifadesi taramadan çıkarıldı. Bu üç dosya yeniden pinlendi. Duman kampanyası hiçbir koşu yapmadan durdu: derleme bitti, koşu kaydı yok.

## 14. Değişiklik v1.1 → v1.2 (B2 duman sonrası; 2026-10-29)

**Neden.** B2 duman koşusu (`SEGAN_G94_work\vh94\out\VH94SMOKECHECK_20261029_b\smoke_check.json`, sha256 502c4ba9b9afe6003173166fe5920df9c680ac7802f9afd03bf747fdd2c62333; teknik denetimler geçti) Typhoon'da |v2_pm| geniş bant gürültüsünü 3.5·10⁻⁴ pu ölçtü. Başat bileşen 180 Hz'dedir, yani uydurma bandının (0.6–1.4·f_p ≈ 42–147 Hz) dışında. Bant içi gürültü ≈ 1·10⁻⁴ pu'dur. §5.5 q3 (A₀ ≥ 10·n₀) geniş bant n₀ ile, bant dışı dalgalanma yüzünden, F_m koşularını (kuru koşuda A₀ ≈ 2·10⁻³) değerlendirilemez yapardı. q3'ün amacı, uydurmanın gürültüye değil moda oturduğunu güvenceye almaktır; ilgili karşılaştırma bant içi gürültüdür.

**Değişiklikler.**
1. §5.5 adım 7 (q3): n₀ = [0.20, 0.30) s'de doğrusal eğilimden arındırılmış y'nin yalnız [0.6, 1.4]·f_p bandındaki bileşeninin standart sapması (FFT maskesi). Geniş bant n₀ rapor edilir. Kod: `analyze_vh94.noise_floor(t, y, f_p)`.
2. §9'a **S6b** eklenir: S6 ile aynı kuru koşu, beyaz gürültü yerine SMOKE_B0 kaydının zamanla hizalı, eğilimden arındırılmış |v2_pm| kalıntısı eklenerek (`vh94_avg_dryrun.py` üçüncü argüman). Kabul: altı vakanın altısı AGREE ve her vakada |D̂ − D_pred| ≤ 0.25·|D_pred|.
3. S3'teki q3 tetikleme testi bant içi tanıma göre küçük genlikle (5·10⁻⁵) yapılır.

**Değişmeyenler.** Kestirici modeli ve ızgarası, öteki kapılar, eşikler (0.2 s⁻¹, 3·u_D, R² ≥ 0.5, 10·n₀ çarpanı) ve karar tablosu aynıdır.

**Geliştirme kayıtları ve çatallanma beyanı.** Değişiklik duman sonucundan sonra yazıldı. S6b'nin kabul ölçütü iki geliştirme koşusu görüldükten sonra konuldu:
- `out\VH94S6b_dev_roll_hatali`: gürültü kaydırılıp başa sarılmıştı; bu, kayıtta yapay bir sıçrama yaptı ve sonuç geçersizdir; saklandı.
- `out\VH94S6b_dev2\dryrun.json` (sha256 fcd35fbe8eb005fd4a339b6387a4979a21684dc9e692b626a6085119e5ac5216): 6/6 AGREE; |D̂ − D_pred| en çok 1.18 s⁻¹ (%9).

Typhoon VH94 kampanya sonuçları görülmedi. **Bilinen yanlılık (rapor kalemi R-8):** gerçek gürültüyle sönümlü A2 F_m koşularında σ̂ öngörüden 0.45–1.22 s⁻¹ daha negatif çıktı. Bu D'nin işaretini etkilemez (|D_pred| ≥ 12.7 s⁻¹), ama B5'te σ̂/σ_pred oranları (R-1) yorumlanırken belirtilir. Değişiklik yeni bir dar bağımsız denetimden geçer.

## 15. Değişiklik v1.2 → v1.3 (kapsam daraltma; D-265; 2026-10-29)

**Dayanak.** Kullanıcı talimatı ("doğrulama kapsamını daraltma ve yayına odaklanma"): yalnız makalenin merkezî iddiasını doğrudan sınayan koşular yapılır. Değişiklik hiçbir Typhoon VH94 kampanya sonucu görülmeden yapıldı.

**Değişiklikler.**
1. §5.3 senaryoları yalnız birincil koşulardır: her vaka için R_m ve F_m, 25 ns ve 50 ns. Toplam 24 koşu, 12 derleme. **B0, R_lo, R_hi koşulmaz.** Bunlar yalnız rapor kalemleriydi (R-2 parantez, R-3 B0); H1'e ve §8'e girmezler. A2'deki B0'ların kalite kapısında değerlendirilemez çıkacağı zaten öngörülmüştü (R-3). Altı vakanın hepsi ve iki işaret korunur; hükmün tanımı, eşikleri ve değerlendirilebilirlik koşulu (§8) değişmez.
2. R-2 ve R-3 rapor kalemleri düşer. R-7 (kilit oturması) R_m 25 ns koşusunun [0.20, 0.30) s aralığından hesaplanır; bu aralık kesmeden öncedir ve B0 ile özdeştir.
3. S3 testleri: v1.2 §14 madde 3'teki 5·10⁻⁵ genlikli test q3'ü tetiklemiyordu, çünkü önce q2 düşüyordu (B2-c `VH94SYNTH_20261029_c`, 138 testin tek başarısızı). Bu test "değerlendirilemez (q2 ya da q3)" beklentisiyle kalır. q3'ü gerçekten sınayan ek test: 1·10⁻³ genlikli 70 Hz bant içi girişim; R² ≥ 0.5 ama A₀ < 10·n₀. Kestirici ve kapılar değişmez.

**Kod.** `analyze_vh94.RUNS`, `vh94_run.SCENARIOS` ve R-7 kaynağı; `vh94_synth.py` S3; `run_campaign_vh94.ps1` senaryo listesi. Eski sürümler `vh94\archive\*_v12.*`.

**B2-c özeti (v1.2 kodu).** check 0; static 0; S6 0 (6/6 AGREE); S6b 0 (6/6 AGREE, |D̂ − D_pred|/|D_pred| ≤ 0.093); synth 2 (yalnız madde 3'teki test).
