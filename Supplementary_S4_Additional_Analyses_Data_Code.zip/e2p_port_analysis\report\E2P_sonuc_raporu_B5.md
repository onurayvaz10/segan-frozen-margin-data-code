# E2P B5 sonuç raporu (2026-11-08)

Koşu: `E2P_20261108_a`. SABİT: `protokol/E2P_On_Kayit_v1.1_SABIT.md` (134b47c1…bbbc80). Danışman maddeleri: N-2, N-12, N-13; ek olarak N-5 (C-F00779).
Rapor yazarı: B4 koşucusu oturumu (ana oturumun talebiyle; §8 Sapmalar S-1).

## 1. Mühür (VERIFIED)
- Çıktı klasörü: `C:\Users\onura\Documents\SEGAN_G94_work\e2p\E2P_20261108_a\` (betiğe ait; bu adımda yazılmadı).
- `SHA256SUMS` 13 satır yeniden hesaplandı, 13/13 eşleşti (B4'te ve B5 başında iki kez). SHA256SUMS dosyasının sha256'sı: 6df3cb050c351be505c328ebe4b54664ed5e56ccdb722fafec3737ff5890c013.
- `sonuc.json` sha256: 38b635965df818544d49433f875883b482aa44a0357d5a8ef2a5f803b494e8b7. Ana oturum da bağımsız doğruladı.
- Yetki ↔ çıktı eşlemesi (sonuc.json `sabit_sha256`, `script_sha256`, `pin_list_sha256`, `yetki`):

  | Kalem | Yetki dosyası | Koşu kaydı / yeniden hesap |
  |---|---|---|
  | SABİT v1.1 | 134b47c1…bbbc80 | aynı |
  | e2p_run.py | 898cedd5…3a5c9b | aynı |
  | pin_list | 2b2f0286…1bfb | aynı (`--check-only` da aynı) |
  | B3 v3 kod denetimi | 25f5fd75…ce5a | yeniden hesap aynı |
  | points.csv (pin) | 6a099961…44e7 | yeniden hesap aynı |
- `exit_code.txt` = 0; `stderr.txt` boş; `devam_sayisi` = 0 (tek kesintisiz koşu).
- Koşu: 2026-11-08 01:36:17 → 03:08:49 (+03:00), 92.5 dk; düşük öncelik (BelowNormal); WHEA koşu boyunca 0 (başta son 24 sa: 1, son 1 sa: 0).
- B4 konsol kayıtları: `C:\Users\onura\Documents\SEGAN_G94_work\e2p\E2P_20261108_a_konsol\` (kendi SHA256SUMS'u var).

## 2. Hüküm (SABİT §8, harfiyen)
`hukum.txt`:
```
A: KISMİ
B: TUTARLI
C: BETİMSEL
C_adlandirma: DEĞİŞMEZ
```

### 2.1 Değerlendirilebilirlik (§7, satır 362–365)
| Sınama | Ölçüt | Değer | Sonuç |
|---|---|---|---|
| A | S_P'de NE-* dışı ≥ 697/774 | 768/774 | değerlendirilebilir |
| B | S_O'da NE-* dışı ≥ 12/18 | 18/18 | değerlendirilebilir |
| C | S_O'da X-3 geçen ≥ 15/18 | 18/18 (`n_SO_x3`) | değerlendirilebilir |
| C | tüm kümede X-1, X-2, X-3 geçen ≥ 1125/1249 | 1224/1249 (`n_ALL_C_ok`) | değerlendirilebilir |

Küme boyları beklenenle aynı (ABORT yok): S_P = 774, S_O = 18, S_D = 4 (A2-F00893, B2-F01989, C-F00428, C-F00779), tüm küme = 1249 (`sets`).

### 2.2 A — KISMİ (§8 A satır 4; SABİT satır 373)
> "4. KISMİ: İHLAL yok, en az bir {ω0, ωHI, TARAMA, GİZLİ, EKSEN, GENİŞ, RAKİP, KÖK_SAPMA}."

Satır satır (ilk eşleşen):
| Satır | Koşul | Durum |
|---|---|---|
| 1 ABORT | pin/hash, ortam kapısı, küme boyları | eşleşmedi |
| 2 NOT_EVALUABLE | < 697 | eşleşmedi (768) |
| 3 RET-İHLAL | ≥ 1 İHLAL | eşleşmedi (İHLAL 0) |
| **4 KISMİ** | İHLAL yok, ≥ 1 listedeki sınıf | **eşleşti: GENİŞ = 134** |

S_P sınıf sayıları (`summaries.A_class_counts_SP`):
| Sınıf | Sayı |
|---|---|
| KİMLİK | 634 |
| GENİŞ | 134 |
| NE-kimlik | 6 |
| ω0, ωHI, TARAMA, GİZLİ, EKSEN, İHLAL, RAKİP, KÖK_SAPMA, NE-dağıtım, NE-ref, NE-denge, NE-hata | 0 |

KISMİ'yi doğuran sınıf **yalnız GENİŞ**'tir (EŞİK_GENİŞ: thr_ρ,i > 10⁻³·ΔG*_ex). Aile dağılımı (`delta_tab.<aile>.n_EŞİK_GENİŞ`): A2 17, B2 41, C 76.
Aile bazında S_P: A2 258 (KİMLİK 241, GENİŞ 17), B2 265 (KİMLİK 221, GENİŞ 41, NE-kimlik 3), C 251 (KİMLİK 172, GENİŞ 76, NE-kimlik 3).
"Hüküm → statü" (satır 73): **A = KISMİ → makaleye δ_tab ilişkisi ve sınıf sayıları girer.** RET-İHLAL olmadığı için port–referans cümlesi yazılabilir.

### 2.3 B — TUTARLI (§8 B satır 5; SABİT satır 381)
> "5. TUTARLI: değerlendirilebilen her nokta TEK_DAL."

| Satır | Koşul | Durum |
|---|---|---|
| 1 ABORT | ortak | eşleşmedi |
| 2 NOT_EVALUABLE | < 12 | eşleşmedi (18) |
| 3 KISMİ | ≥ 1 RAKİP_GEÇİŞ | eşleşmedi (0) |
| 4 BELİRSİZ | ≥ 1 TAKİP_KOPUK | eşleşmedi (0) |
| **5 TUTARLI** | hepsi TEK_DAL | **eşleşti: 18/18 TEK_DAL** |

S_O sınıfları (`B_classes`; 18 nokta, hepsi TEK_DAL): A2-03486, A2-F00241, A2-F00357, A2-F00805, A2-F00841, A2-F00993, A2-F01077, A2-F01169, A2-F01557, A2-F01921, A2-S01753, A2-S02873, B2-F00433, B2-F00506, B2-F01189, B2-S01727, C-01685, C-S01685.
S_O'da EŞİK_GENİŞ sayısı (`SO_esik_genis`, R3-9 ek raporu): **0**. Bu yüzden §2 kuralı (satır 76) gereği cümleye ek sayı girmez.
Rapor amaçlı (hükme girmez): S_D'nin 4 ve S_X'in 20 noktası da TEK_DAL (toplam 42/42).
"Hüküm → statü" (satır 76): **B = TUTARLI → v6.3 §6.9 ve S2 v6 (paragraf 4762 ve 4821) cümleleri "n/18" cümlesiyle değiştirilir; n = 18.**

### 2.4 C — BETİMSEL; adlandırma DEĞİŞMEZ (§8 C satır 3; §2 satır 78)
> "3. BETİMSEL." · Sonuç kuralı (satır 78): "S_O'da X-3'ü geçen noktalar arasında TEK(κ_dış) sayısı mutlak olarak ≥ 10 ise … adlandırması düzeltilir; 9 ve altında değişmez."

- S_O'da X-3'ü geçen: 18. Bunlar arasında TEK(κ_dış) = **0** (`n_tek_dis`). 0 ≤ 9 → **"non-ideal CPL residual" adlandırması değişmez.**
- Birincil çevirici sınıfları, S_O (`summaries.C.SO.flip1`): **TEK(κ_Cb) 17, ORTAK 1** (C-S01685), TEK(κ_dış) 0, ÇOKLU 0.
- İkincil (INFERENCE; `flip2`): **TEK(κ_res) 17, ORTAK 1** (C-S01685), TEK(κ_L) 0, TEK(κ_dış) 0, ÇOKLU 0.

### 2.5 Sınırda ya da belirsiz hücreler
- Karar tablolarının hiçbirinde eşitlik ya da sınır durumu yok (768 ≫ 697; 18 > 12; 0 ≪ 10).
- A'da EKSEN alt sayıları: e_id koşulu sağlandı 0 / değerlendirilemedi 0 (EKSEN sınıfı oluşmadı).
- Sınırda tek hücre türü, X-2 giriş denetimindeki NE-kimlik'tir (§6 G-5, post-hoc): sapmalar toleransın 1.0–5.4 katı.

## 3. Önceden tanımlı özetler (§5.6; ön-kayıtlı)

### 3.1 δ_tab = dGref_rec − ΔG*_ex (S_P, aile bazında; `summaries.delta_tab`)
| Aile | n | medyan (pu) | en küçük (pu) | en büyük (pu) | δ_tab<0 oranı | δ_tab/δ_tab,pred ∈ [0.5, 2] oranı | pred tanımsız | AYIRT oranı | EŞİK_VARSAYILAN | EŞİK_GENİŞ | thr>1e-6 | SAHTE_ADAY |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| A2 | 258 | −2.07e-5 | −7.12e-5 | −4.81e-6 | 1.00 | 1.00 | 0 | 0.00 | 0 | 17 | 258 | 1 |
| B2 | 262 | −3.54e-5 | −9.91e-5 | −1.05e-5 | 1.00 | 1.00 | 0 | 0.00 | 0 | 41 | 262 | 0 |
| C | 248 | −5.46e-5 | −1.62e-4 | −2.21e-5 | 1.00 | 1.00 | 0 | 0.00 | 0 | 76 | 248 | 0 |
| Tümü | 768 | −3.49e-5 | −1.62e-4 | −4.81e-6 | 1.00 | 1.00 | 0 | 0.00 | 0 | 134 | 768 | 1 |

Diğer bayraklar (tümü 0): 9B_HATA, GİZLİ_HATA, MIN_FARKLI.
Not (işaret kuralı): SABİT §3'teki "Y2 N2 − dGref" farkı pozitif tanımlıdır; δ_tab = dGref − ΔG*_ex ters yönde tanımlıdır. Negatif δ_tab, tablo referansının kesin referanstan önce (küçük ΔG'de) geldiği anlamına gelir. §3'teki öngörüyle aynı yöndedir.

### 3.2 Etiket değişim tablosu (ref_sign → ref_sign_ex; `summaries.label_change`)
| Küme | Geçiş | Sayı |
|---|---|---|
| S_O | −1 → −1 | 18 |
| S_P ∖ S_O | +1 → +1 | 750 |
| S_P ∖ S_O | +1 → tanımsız (NE-kimlik) | 6 |
| S_D | −1 → −1 (B2-F01989) | 1 |
| S_D | −1 → 0 (A2-F00893) | 1 |
| S_D | −1 → +1 (C-F00779) | 1 |
| S_D | +1 → +1 (C-F00428) | 1 |

Kayıtlı ref_sign değerleri pinli points.csv'den okundu. Eşitlik bandı TIE_K = 2·10⁻³·dGf'dir (`ext_common.ref_sign_of`).

### 3.3 S_D yorum tablosu (§5.6 ilk eşleşen; `summaries.SD_yorum`)
| Nokta | ref_sign (kayıt) | ref_sign_ex | A sınıfı | B sınıfı | Eşleşen satır | Yorum |
|---|---|---|---|---|---|---|
| A2-F00893 | −1 | 0 | KİMLİK | TEK_DAL | 1 | göreli eşik artefaktı |
| B2-F01989 | −1 | −1 | KİMLİK | TEK_DAL | 3 | açıklanmadı (çözünürlük ya da eğrilik) |
| C-F00428 | +1 | +1 | KİMLİK | TEK_DAL | 1 | göreli eşik artefaktı |
| **C-F00779** | −1 | **+1** | **GENİŞ** | TEK_DAL | 1 | **göreli eşik artefaktı** |

**C-F00779 ayrıntısı** (A.jsonl, C.jsonl ve points.csv; VERIFIED okuma):
| Alan | Değer |
|---|---|
| dGf_rec (crit ρ) | 6.316e-4 pu |
| dGref_rec | 6.137e-4 pu → dGref − dGf = −1.79e-5 pu (kayıtlı ref_sign −1; K1 notundaki değer) |
| ΔG*_ex | 6.491e-4 pu → ΔG*_ex − dGf = +1.75e-5 pu (ref_sign_ex +1) |
| δ_tab / δ_tab,pred | −3.539e-5 / −3.539e-5 pu |
| thr_ρ,i | 2.26e-5 pu; thr/ΔG*_ex = 0.0348 > 10⁻³ → EŞİK_GENİŞ → sınıf GENİŞ |
| I1, I2 | sağlandı; F_ex = 3.6e-11 pu, tol_ρ,z* = 2.26e-5 pu; κ_ex = 0.027 |
| ω_ss | 356.9 rad/s |
| κ (X-2), F_single | 0.0270, +1.71e-5 pu |
| B | TEK_DAL (21/21 adımda geçerli takip) |

Ön-kayıtlı yorum: **"göreli eşik artefaktı"**. Satır 1 (ref_sign_ex ∈ {0, +1}) eşleşti. Ek uyarı post-hoc'tur (§6 G-4).

### 3.4 S_X ve aile sayıları
- S_X (20 nokta; `SX`): A2-00194, A2-00490, A2-00597, A2-00837, A2-01034, A2-01218, A2-01286, A2-01466, A2-02037, A2-03674, A2-03890, A2-03990, A2-F00403, A2-F01132, A2-F01332, A2-F01627, A2-F01975, B2-00030, B2-00146, B2-00453.
- Aile sayıları (`SX_aile`): A2 17, B2 3, C 0. A sınıflarının 20'si de GENİŞ. Seçim id sözlük sırasıyla yapıldığından A2 ağırlıklıdır. Genelleme kümesi değildir (§8 satır 400).
- B: 20/20 TEK_DAL.

### 3.5 B temsilci noktaları (§5.4 seçim kuralı; `B_representatives`)
| Sıra | Nokta | max_k \|F_tr,k − F_k\| (pu) | Geçerli takip | YOK(k) | ρ(t_k) ≤ 0 |
|---|---|---|---|---|---|
| 1 | B2-F00506 | 2.15e-13 | 21/21 | 0 | 0 |
| 2 | B2-F00433 | 2.04e-13 | 21/21 | 0 | 0 |
| 3 | B2-S01727 | 1.76e-13 | 21/21 | 0 | 0 |

S_O'nun 18 noktasının hepsinde takip 21/21 adımda geçerlidir. YOK(k), ρ(t_k) ≤ 0, SWITCH ve SAHTE_ADAY sayılarının hepsi 0'dır. max|F_tr − F| 1.7e-14 ile 2.2e-13 pu arasındadır.

### 3.6 C bölüşüm özetleri (§5.5 Rapor; `summaries.C`)
| Küme (n_ok) | κ_Cb medyan [min, max] (neg) | κ_dış medyan [min, max] (neg) | κ_G medyan (neg) | κ_N medyan (neg) | κ_Co medyan [min, max] (neg) |
|---|---|---|---|---|---|
| S_O (18) | −0.125 [−0.283, −0.069] (18) | +0.011 [−0.037, +0.184] (1) | +0.0088 (0) | +0.00026 (5) | 0 [−0.050, +0.172] (1) |
| S_P ∖ S_O (750) | +0.137 [−0.289, +0.908] (138) | +0.012 [−0.231, +0.598] (134) | +0.0047 (4) | −0.00002 (404) | 0 [−0.247, +0.575] (132) |
| Tümü (1224) | +0.097 [−0.289, +1.411] (358) | +0.012 [−0.348, +0.598] (227) | +0.0046 (7) | −0.00006 (729) | 0 [−0.369, +0.575] (224) |

κ_res = κ_Cb − κ_L,rec (ikincil, INFERENCE): S_O medyan −0.332 [−0.687, −0.143] (18 negatif); tümü medyan −0.062 (820 negatif).
Tüm kümede çevirici sınıfları (κ < 0 olan 79 X-3 geçen nokta; rapor amaçlı): birincil TEK(κ_Cb) 69, TEK(κ_dış) 6, ORTAK 4; ikincil TEK(κ_res) 72, ÇOKLU 4, TEK(κ_dış) 2, ORTAK 1. TEK(κ_dış) alan 6 noktanın hiçbiri S_O'da değildir (B2-F00110, B2-S03345, C-F00243, C-F00441, C-F00451, C-F00861; hepsinde |κ| ≤ 0.022). Adlandırma kuralı yalnız S_O'ya bakar.

S_O nokta tablosu (C.jsonl):
| Nokta | κ | κ_Cb | κ_dış | κ_G | κ_N | κ_Co | κ_res | birincil | ikincil |
|---|---|---|---|---|---|---|---|---|---|
| A2-03486 | −0.108 | −0.114 | +0.006 | +0.007 | −0.0009 | 0 | −0.181 | TEK(κ_Cb) | TEK(κ_res) |
| A2-F00241 | −0.115 | −0.122 | +0.007 | +0.007 | −0.0002 | 0 | −0.288 | TEK(κ_Cb) | TEK(κ_res) |
| A2-F00357 | −0.122 | −0.128 | +0.006 | +0.006 | +0.0002 | 0 | −0.311 | TEK(κ_Cb) | TEK(κ_res) |
| A2-F00805 | −0.073 | −0.086 | +0.012 | +0.012 | −0.0001 | 0 | −0.316 | TEK(κ_Cb) | TEK(κ_res) |
| A2-F00841 | −0.090 | −0.095 | +0.005 | +0.005 | +0.0005 | 0 | −0.349 | TEK(κ_Cb) | TEK(κ_res) |
| A2-F00993 | −0.224 | −0.238 | +0.014 | +0.014 | +0.0002 | 0 | −0.474 | TEK(κ_Cb) | TEK(κ_res) |
| A2-F01077 | −0.064 | −0.070 | +0.006 | +0.005 | +0.0004 | 0 | −0.489 | TEK(κ_Cb) | TEK(κ_res) |
| A2-F01169 | −0.067 | −0.071 | +0.004 | +0.004 | −0.0002 | 0 | −0.199 | TEK(κ_Cb) | TEK(κ_res) |
| A2-F01557 | −0.117 | −0.127 | +0.010 | +0.010 | +0.0003 | 0 | −0.372 | TEK(κ_Cb) | TEK(κ_res) |
| A2-F01921 | −0.164 | −0.176 | +0.013 | +0.011 | +0.0013 | 0 | −0.627 | TEK(κ_Cb) | TEK(κ_res) |
| A2-S01753 | −0.144 | −0.154 | +0.010 | +0.008 | +0.0015 | 0 | −0.687 | TEK(κ_Cb) | TEK(κ_res) |
| A2-S02873 | −0.115 | −0.132 | +0.017 | +0.015 | +0.0019 | 0 | −0.372 | TEK(κ_Cb) | TEK(κ_res) |
| B2-F00433 | −0.056 | −0.175 | +0.120 | +0.004 | +0.0001 | +0.115 | −0.309 | TEK(κ_Cb) | TEK(κ_res) |
| B2-F00506 | −0.067 | −0.099 | +0.031 | +0.004 | −0.0001 | +0.028 | −0.180 | TEK(κ_Cb) | TEK(κ_res) |
| B2-F01189 | −0.223 | −0.283 | +0.060 | +0.012 | +0.0008 | +0.047 | −0.461 | TEK(κ_Cb) | TEK(κ_res) |
| B2-S01727 | −0.077 | −0.262 | +0.185 | +0.012 | +0.0004 | +0.172 | −0.354 | TEK(κ_Cb) | TEK(κ_res) |
| C-01685 | −0.066 | −0.116 | +0.050 | +0.014 | +0.0003 | +0.037 | −0.147 | TEK(κ_Cb) | TEK(κ_res) |
| C-S01685 | −0.156 | −0.118 | −0.037 | +0.013 | +0.0002 | −0.050 | −0.143 | ORTAK | ORTAK |

### 3.7 EKSEN, SAHTE_ADAY, elenen adaylar ve §5.3 adım 10 rapor alanları
- EKSEN alt sayıları (`EKSEN_alt`): sağlandı 0, değerlendirilemedi 0.
- SAHTE_ADAY: A'da 1 nokta (A2-00490, S_P/S_X; 1 aday). B'de aynı nokta 21 adımın hepsinde 1'er SAHTE_ADAY kaydetti. Başka nokta yok.
- Elenen adaylar (Im dμ/dω = 0 ya da istisna; `n_elenen_aday`): 0.
- Adım 10 rapor alanları (S_P, 768 nokta): cond(K_rr) 6.4e5–2.3e7; gap_rel en küçük 0.758. İkinci özdeşlik oranı (FD dσ/dΔG ile (1 − κ_ex)·Im(dμ/dω)/|dμ/dω|²) 0.99957–1.00010 aralığında.
- REF-SANSÜR: 0 (768 noktanın hepsi 'alpha').

## 4. Ön-kayıtlı sonuçların özeti (yalnız SABİT ölçütleri)
- **A KISMİ:** 768 değerlendirilebilir noktanın 634'ü KİMLİK, 134'ü GENİŞ. İHLAL, RAKİP, KÖK_SAPMA, TARAMA, GİZLİ, EKSEN, ω0 ve ωHI yok.
- **δ_tab:** 768/768 negatif; medyan −3.49e-5 pu, aralık [−1.62e-4, −4.81e-6] pu. δ_tab/δ_tab,pred oranı 768/768 noktada [0.5, 2] içinde. AYIRT 0/768.
- **B TUTARLI:** S_O 18/18 TEK_DAL; S_O'da EŞİK_GENİŞ 0.
- **C BETİMSEL:** S_O'da birincil TEK(κ_Cb) 17, ORTAK 1; TEK(κ_dış) 0 → adlandırma DEĞİŞMEZ.
- **S_D:** 3 "göreli eşik artefaktı" (A2-F00893, C-F00428, C-F00779), 1 "açıklanmadı" (B2-F01989).

## 5. Körleme durumu ve kanıt düzeyi
- §3'teki körlenmiş nicelikler (ΔG*_ex, ω_ss, I1, I2, δ_port, ref_sign_ex, e_id; B ara ızgara kümeleri; κ_G/κ_N/κ_Co/κ_Cb) koşudan önce görülmedi. Kimse bu niceliklere bakarak eşik ya da tablo değiştirmedi. SABİT ve betik hash'leri yetki dosyasıyla aynı.
- Kısmen sızmış nicelikler §3'te beyan edildiği gibi kaldı: Y2 N2 − dGref farkı δ_tab'ın işaretini ve büyüklüğünü öngörüyordu; sonuç bu öngörüyle aynı yöndedir. **δ_tab bulgusunun sürpriz değeri bu yüzden düşüktür.** Kanıt ağırlığı I2 (RAKİP 0), sınıf dağılımı ve δ_tab/δ_tab,pred'dedir (§2 "Göstermez").
- B4 koşucusu hüküm satırlarını B4'te gördü. Bu rapor da aynı oturumda yazıldı (S-1). Sonuç görüldükten sonra yeniden koşu yapılmadı, eşik ya da tablo değişmedi.
- **Kanıt düzeyi: E2** (model içi, çevrimdışı ortalama-değer hesabı; TSV aileleri A2, B2, C). Fiziksel, EMT ya da anahtarlamalı model doğrulaması yoktur. A, yazılımdaki Schur determinant özdeşliğinin bir **doğrulama** sınamasıdır; yeni bir kuramsal kanıt değildir.

## 6. Ön-kayıt dışı gözlemler (post-hoc / INFERENCE; hükmü değiştirmez)
- **G-1. GENİŞ noktaların iç durumu.** GENİŞ sınıfı sıralamada I1 başarısızlık dallarından sonra gelir. Bu yüzden 134 GENİŞ noktanın hepsinde I1 ve I2 sağlanmıştır (A.jsonl). Ayrıca 134'ünün hepsinde |F_ex| ≤ tol_ρ,z* ve κ_ex < 1'dir; yani GENİŞ olmasalar KİMLİK koşulunu karşılarlardı. |F_ex| en çok 4.0e-10 pu'dur. GENİŞ'i doğuran thr/ΔG*_ex oranı 0.00102–0.0668 aralığındadır (KİMLİK'te 1.0e-5–9.98e-4). KISMİ hükmü değişmez; bu gözlem yalnız KISMİ'nin içeriğinin "eşik bütçesi geniş" olduğunu betimler.
- **G-2. AYIRT = 0 cebirseldir (INFERENCE).** §5.3 ve §6 tanımlarından |δ_tab,pred|/thr_ρ,i = 10⁻¹⁰/(10·u·κ_eig) ≈ 4.5·10⁴/κ_eig çıkar (thr tabanı 1e-7 hiçbir noktada bağlayıcı değildir). S_P'de κ_eig 1.7e4–1.2e5 olduğundan oran 0.38–2.67 aralığındadır (gözlenen |δ_tab|/thr: en küçük 0.383, medyan 1.33, en büyük 2.67). AYIRT için κ_eig ≲ 4.5·10³ gerekirdi. Sonuç: δ_tab, noktanın sayısal hata bütçesiyle aynı mertebededir. Öte yandan δ_tab/δ_tab,pred oranı 0.99956–1.00023'tür; ofset göreli eşik formülüyle dört basamak uyumludur.
- **G-3. Temsilci seçimi pratikte gürültüyle belirlendi.** S_O'da max|F_tr − F| değerleri 1.7e-14 ile 2.2e-13 pu arasındadır; m_k ile t_k her adımda aynı geçiştir. Kural harfiyen uygulandı. Ancak üç temsilcinin (hepsi B2) seçimi yuvarlama düzeyindeki farklara dayanır; bu noktaların "en farklı" olduğu fiziksel bir anlam taşımaz.
- **G-4. C-F00779'un işaret ayrımı noktasal eşiğin altındadır.** |ΔG*_ex − dGf_rec| = 1.75e-5 pu < thr_ρ,i = 2.26e-5 pu, ve nokta GENİŞ'tir. Ön-kayıtlı yorum ("göreli eşik artefaktı") geçerlidir: kayıtlı −1 etiketinin kaynağı δ_tab = −3.54e-5 pu'luk göreli eşik ofsetidir ve bu ofset öngörülen değerle aynıdır. Ancak kesin referanstaki +1 etiketi de sayısal çözünürlük sınırındadır. Makale cümlesi bunu söylemelidir (§7 N-5).
- **G-5. NE-kimlik'in nedeni X-2'dir.** C'deki 25 NE-kimlik noktasının hepsi X-2 (κ eşleşmesi) denetiminde düştü; X-1'i geçtiler (C.jsonl'da yalnız `x2_kappa` alanı var). Göreli sapma |κ_X2 − κ_rec|/max(|κ_rec|, 0.05) 1.0e-6 ile 5.4e-6 arasındadır; eşik 1e-6'dır, yani sınırın hemen üstü. Bu 25 noktanın 6'sı S_P'dedir (B2-F00126, B2-F01230, B2-F01892, C-00414, C-03249, C-F00721); hepsi A'da NE-kimlik. Kayıtlı κ'nın 6 anlamlı basamak düzeyinde yeniden üretildiğini gösterir; hükme etkisi yok (768 ≫ 697).
- **G-6. C-F00428 için satır 1 bilgi taşımaz.** C-F00428, S_D'ye sign(κ) ≠ ref_sign yoluyla girdi (κ = −0.0077, ref_sign +1). Etiket +1 → +1 değişmedi. Tablo harfiyen "göreli eşik artefaktı" verir, ama bu noktada etiket değişimi yoktur. Uyuşmazlığın kaynağı küçük |κ|'dır (eşitlik bandı yakını).
- **G-7. A'nın KİMLİK dışı noktaları:** liste aşağıda **Ek A**'dadır. 134 S_P GENİŞ ve 6 S_P NE-kimlik noktası, ayrıca S_D'den C-F00779 (GENİŞ) yer alır; toplam 141 satır.

## 7. Makale ve S2 için cümle önerileri (SABİT §2 sonuç kuralları; İngilizce)
Uygulama bu adımda yapılmaz; ana oturum/makale hattında yapılacaktır.

**N-2 (port–referans ilişkisi; A = KISMİ → δ_tab ilişkisi ve sınıf sayıları girer):**
> "To relate the port-admittance margin to the numerical reference, we recomputed the state-space reference without the relative eigenvalue threshold (ΔG*_ex) at the 774 primary-set points (768 evaluable). At every evaluable point the imaginary-axis eigenvalue of the state matrix at ΔG*_ex coincided with a port-admittance crossing at the same frequency, and that crossing was the smallest positive crossing: 634 points met all identity tolerances and the remaining 134 were classified only as wide-threshold cases (point-wise numerical threshold above 10⁻³ ΔG*_ex); no identity violation, competing crossing or root deviation occurred. The tabulated reference, which uses a relative threshold of 10⁻¹⁰‖A‖₂, lies below the exact one at all 768 points (median offset −3.5 × 10⁻⁵ pu, range −1.6 × 10⁻⁴ to −4.8 × 10⁻⁶ pu), and the offset agrees with its first-order prediction −10⁻¹⁰‖A‖₂/(dσ/dΔG) within a factor of two at every point; the offset is of the same order as the point-wise numerical threshold."

Kaynak alanları: 774/768 → `sets.SP`, `A_class_counts_SP` (774 − NE-kimlik 6); 634/134 → `A_class_counts_SP`; "no violation…" → `A_class_counts_SP`'de İHLAL/RAKİP/KÖK_SAPMA yok; medyan/aralık → `delta_tab.ALL.median/min/max`; "all 768 below" → `delta_tab.ALL.frac_neg` = 1.0; "factor of two" → `delta_tab.ALL.frac_ratio_0p5_2` = 1.0, `n_pred_tanimsiz` = 0; "same order" → `delta_tab.ALL.frac_ayirt` = 0 (yorumu G-2, INFERENCE).

**N-12 (B = TUTARLI; §6.9 cümlesi "Port-branch switching was not separately tracked throughout these paths." ve S2 v6 paragraf 4762 ve 4821'deki eşdeğerleri değiştirilir):**
> "Port branches were tracked along each path from 0 to the exact reference on a 21-point grid: at all 18 of 18 evaluable optimistic points the critical crossing remained the smallest positive crossing throughout, with no competing-crossing switch and no tracking break; short-lived switches between grid points cannot be excluded."

Kaynak alanları: 18/18 → `B_classes` (S_O id'leri) ve `hukum.B`; S_O'da EŞİK_GENİŞ = `SO_esik_genis` = 0 (cümleye ek sayı gerekmez). Izgara sınırı → SABİT §2 "Göstermez". İsteğe bağlı S2 eki (rapor amaçlı): "The same held at the four discordant and twenty control points." (`B_classes`, 42/42).

**N-13 (C = BETİMSEL; satır bölüşümü ve çevirici):**
> "A first-order row partition of κ at the pre-shed operating point (by equation rows, not by device) shows that, at all 18 optimistic points, the rows of the constant-power loads at the shed bus contribute a negative term (median −0.125, range −0.283 to −0.069), whereas all remaining rows (network, port node, grid-forming source and other constant-power loads) contribute a small term that is positive at 17 of 18 points (median 0.011). By the pre-registered flipper rule, the shed-bus load rows alone turn κ negative at 17 of 18 points; at the remaining point neither part does so alone. No point is turned negative by the remaining rows alone, so we retain the term 'non-ideal CPL residual' for κ_rest."

Kaynak alanları: `summaries.C.SO.k_Cb` (median/min/max, n_neg 18); `summaries.C.SO.k_dis` (median 0.011, n_neg 1 → 17/18 pozitif); `flip1` {TEK(κ_Cb) 17, ORTAK 1}; `n_tek_dis` = 0 ve `hukum.C_ad` = DEĞİŞMEZ. İkincil bölüşüm (κ_res; TEK 17/18) INFERENCE etiketlidir; makaleye girerse "the residual beyond the ideal CPL term (κ_Cb − κ_L)" olarak ve INFERENCE niteliğiyle girmelidir (§2: κ_L ile κ_Cb'nin ideal parçasının aynı olduğu sınanmamış bir varsayımdır). Satır bölüşümü uyarısı (GFM frekans etkisi κ_N, κ_Co ve κ_Cb'ye dağılır) S2'de korunmalıdır.

**N-5 (tek hatalı kabul: C-F00779):**
> "The single optimistic acceptance occurs at C-F00779, where the frozen margin (6.32 × 10⁻⁴ pu) exceeds the tabulated reference (6.14 × 10⁻⁴ pu) by 1.8 × 10⁻⁵ pu. This label is attributable to the relative eigenvalue threshold of the tabulated reference, which shifts it by −3.5 × 10⁻⁵ pu at this point (equal to its first-order prediction); against the threshold-free reference (6.49 × 10⁻⁴ pu) the frozen margin is 1.8 × 10⁻⁵ pu conservative. Both separations are, however, below the point's numerical threshold (2.3 × 10⁻⁵ pu), so the case is unresolved at numerical precision rather than a resolved optimistic error."

Kaynak alanları: dGf ve dGref → points.csv (pinli) `dGf`, `dGref`; −3.5e-5 → A.jsonl `delta_tab`, `delta_tab_pred`; 6.49e-4 → A.jsonl `dG_ex`; 2.3e-5 → A.jsonl `thr`; yorum → `SD_yorum.C-F00779` ("göreli eşik artefaktı") + G-4 (post-hoc). Son cümle post-hoc G-4'e dayanır; ana oturum bu cümleyi koymayı seçerse S2'de "post-hoc" diye işaretlenmelidir. C-F00779'un N-5'teki "tek hatalı kabul" noktası olduğu bilgisi ana oturumun talebinden ve K1 notundan alındı; bu raporda politika sayımı yeniden doğrulanmadı (UNVERIFIED bu adımda).

## 8. Sapmalar (usul)
- **S-1.** `sonuc-raporu` §0 "rapor yazarı koşucuyla tercihen aynı değil" koşuluna uyulmadı: bu raporu B4 koşucusu oturumu, ana oturumun açık talebiyle yazdı. Kesin yasak olan "kod denetçisiyle aynı" koşulu ihlal edilmedi. Etkisi: hüküm satırları mekanik olarak `hukum.txt`'den ve §8 tablolarından alındı. Yorum payı §6 ve §7'dedir; bağımsız bir okuma önerilir.
- **S-2.** B4'te konsol yakalaması (`konsol_stdout.txt`) boş kaldı. Betik akışını kendi `stdout.txt` dosyasına yazıyor. Kayıp yok.
- **S-3.** Bash fork hatası nedeniyle tablo çıkarımı PowerShell + `python -I -B` ile yapıldı (`tek-kosu-kapisi` §6 kuralı). Salt okuma betikleri oturum geçici klasöründe; çıktılar `rapor/E2P_rapor_ek/`'te. Mühürlü klasöre yazılmadı.
- **S-4.** Süre tahmini 2–2.5 sa idi; gerçek süre 92.5 dk. A ≈ 74 dk, B ≈ 16 dk, C ≈ 2.7 dk (stdout.txt zaman damgaları).

## 9. Yansımalar ve sonraki adım
Bu adımda değişiklik yapılmaz; aşağıdakiler ilgili hatta adım olarak önerilir.
- **Makale v6.3 / S2 v6:** §7'deki dört cümle grubu (N-2, N-12, N-13, N-5). §6.9 cümlesi ve S2 paragraf 4762 ile 4821 birlikte değiştirilir. N-13 için S_O nokta tablosu (§3.6) S2 tablosu ya da şekil kaynağı olabilir.
- **Argüman haritası** (`makale/arguman_haritasi_v0.6.md`, en son 2026-10-23): "Tez" satırının port-admitans payı ↔ sayısal referans dayanağı E2 düzeyinde güçlenir. A KISMİ olduğu için GENİŞ sınıfı açıkça yazılmalıdır. "κ_rest = non-ideal CPL residual" adlandırması için C desteği eklenir. Satır eşlemesini ana oturum yapmalıdır; bu oturum haritanın güncel sürümünü doğrulamadı.
- **Hakem risk kaydı** (`makale/hakem_risk_kaydi_v0.8.md`):
  - "referans sınırı = port geçişi mi?" tehdidi E2 kanıtıyla karşılanır (A, 0 İHLAL/RAKİP);
  - "dal değişimi izlenmedi" tehdidi B TUTARLI ile kapanır (ızgara sınırı kalır);
  - "κ_rest adlandırması" tehdidi C ile karşılanır;
  - yeni küçük risk: "C-F00779 sayısal çözünürlük sınırında" (G-4).
  
  Risk ID eşlemesi (ör. H10, N-2 kapsamı) INFERENCE'tır; ana oturum doğrulamalıdır.
- **Kayıt:** D-ID (`pf1-faz-kapanisi` → `records.py next` + `decision`), DURUM/GUNLUK güncellemesi ana oturumda yapılır.
- **Yön kararı gerekmiyor:** dal kapanışı yok, kapsam daraltma yok. Yeni koşu önerilmiyor. GENİŞ sınıfını daraltmak için bir eşik değişikliği yeni bir ön-kayıt gerektirir ve bu rapor onu önermez.
- **Durum: PROCEED** (makale/S2 cümle uygulaması ve kayıt kapanışı). Açık engel yok.

## Ek A — A'nın KİMLİK dışı noktaları (post-hoc liste; A.jsonl)
Kaynak dosyalar (bu raporla üretildi, salt okuma):
- `rapor/E2P_rapor_ek/A_kimlik_disi_noktalar.csv` (sha256 f17b4d2c5ba66d02cbd941102fa11dfc326b7df8de690445523566c2bbaeb504; tam duyarlık; tol_star ve κ_eig sütunları da var).
- `rapor/E2P_rapor_ek/A_kimlik_disi_tablo.md` (sha256 46fa3ba8f481c4261675852c0803642e089ade8b83be97c852257bc06ceeeb91).

Sıralama: sınıf, sonra id. NE-kimlik satırlarında A hesapları yapılmadığı için alanlar "—"dir. Birimler: ω_ss rad/s, thr ve F_ex pu.

| # | id | küme | sınıf | ω_ss (rad/s) | thr_ρ,i (pu) | thr/ΔG*_ex | F_ex (pu) | κ_ex | bayraklar |
|---|---|---|---|---|---|---|---|---|---|
| 1 | A2-00194 | S_P | GENİŞ | 909.8 | 8.203e-05 | 0.001043 | 1.64e-10 | 0.4288 | EŞİK_GENİŞ |
| 2 | A2-00490 | S_P | GENİŞ | 837.1 | 2.763e-05 | 0.001995 | 7.973e-11 | 0.2388 | EŞİK_GENİŞ |
| 3 | A2-00597 | S_P | GENİŞ | 740.5 | 2.678e-05 | 0.002993 | 1.018e-10 | 0.3378 | EŞİK_GENİŞ |
| 4 | A2-00837 | S_P | GENİŞ | 800.7 | 3.243e-05 | 0.001066 | 7.784e-11 | 0.1146 | EŞİK_GENİŞ |
| 5 | A2-01034 | S_P | GENİŞ | 882.3 | 5.499e-05 | 0.008167 | -2.255e-10 | 0.1861 | EŞİK_GENİŞ |
| 6 | A2-01218 | S_P | GENİŞ | 981.6 | 0.0001195 | 0.004446 | -7.101e-11 | 0.4687 | EŞİK_GENİŞ |
| 7 | A2-01286 | S_P | GENİŞ | 421.3 | 1.696e-05 | 0.002993 | 2.595e-11 | 0.4038 | EŞİK_GENİŞ |
| 8 | A2-01466 | S_P | GENİŞ | 760.5 | 2.467e-05 | 0.01076 | 1.383e-10 | 0.1713 | EŞİK_GENİŞ |
| 9 | A2-02037 | S_P | GENİŞ | 750.3 | 2.517e-05 | 0.001514 | 1.998e-10 | 0.1434 | EŞİK_GENİŞ |
| 10 | A2-03674 | S_P | GENİŞ | 696.4 | 1.762e-05 | 0.002311 | -1.357e-10 | 0.1666 | EŞİK_GENİŞ |
| 11 | A2-03890 | S_P | GENİŞ | 1039 | 5.993e-05 | 0.001408 | 4.506e-11 | 0.1609 | EŞİK_GENİŞ |
| 12 | A2-03990 | S_P | GENİŞ | 496.3 | 8.372e-06 | 0.003687 | 2.287e-11 | 0.176 | EŞİK_GENİŞ |
| 13 | A2-F00403 | S_P | GENİŞ | 894.5 | 2.963e-05 | 0.002668 | 2.29e-10 | 0.168 | EŞİK_GENİŞ |
| 14 | A2-F01132 | S_P | GENİŞ | 879.6 | 4.393e-05 | 0.02656 | -8.005e-11 | 0.2102 | EŞİK_GENİŞ |
| 15 | A2-F01332 | S_P | GENİŞ | 665.5 | 2.942e-05 | 0.001749 | -1.923e-10 | 0.3777 | EŞİK_GENİŞ |
| 16 | A2-F01627 | S_P | GENİŞ | 719.2 | 2.636e-05 | 0.003005 | 2.72e-10 | 0.2503 | EŞİK_GENİŞ |
| 17 | A2-F01975 | S_P | GENİŞ | 555.8 | 1.45e-05 | 0.003108 | 7.517e-11 | 0.2898 | EŞİK_GENİŞ |
| 18 | B2-00030 | S_P | GENİŞ | 735 | 6.47e-05 | 0.002348 | 3.967e-10 | 0.1113 | EŞİK_GENİŞ |
| 19 | B2-00146 | S_P | GENİŞ | 628.7 | 8.101e-05 | 0.001233 | -3.654e-11 | 0.4372 | EŞİK_GENİŞ |
| 20 | B2-00453 | S_P | GENİŞ | 709.8 | 9.985e-05 | 0.001154 | -6.01e-11 | 0.2169 | EŞİK_GENİŞ |
| 21 | B2-00516 | S_P | GENİŞ | 796.2 | 0.0001828 | 0.00269 | -2.072e-10 | 0.3786 | EŞİK_GENİŞ |
| 22 | B2-01009 | S_P | GENİŞ | 568.8 | 8.248e-05 | 0.003857 | 1.419e-10 | 0.3113 | EŞİK_GENİŞ |
| 23 | B2-01460 | S_P | GENİŞ | 562.8 | 8.353e-05 | 0.001789 | -2.096e-10 | 0.1795 | EŞİK_GENİŞ |
| 24 | B2-01476 | S_P | GENİŞ | 598.6 | 5.853e-05 | 0.001402 | 3.072e-11 | 0.2356 | EŞİK_GENİŞ |
| 25 | B2-01788 | S_P | GENİŞ | 498.1 | 6.228e-05 | 0.002434 | 1.381e-10 | 0.1351 | EŞİK_GENİŞ |
| 26 | B2-01835 | S_P | GENİŞ | 382.6 | 2.371e-05 | 0.001152 | 6.145e-11 | 0.1321 | EŞİK_GENİŞ |
| 27 | B2-01838 | S_P | GENİŞ | 536.8 | 2.855e-05 | 0.001099 | 3.556e-10 | 0.09036 | EŞİK_GENİŞ |
| 28 | B2-01930 | S_P | GENİŞ | 592.5 | 5.145e-05 | 0.001897 | 7.709e-11 | 0.1934 | EŞİK_GENİŞ |
| 29 | B2-02004 | S_P | GENİŞ | 693.2 | 0.0001423 | 0.002481 | 1.13e-10 | 0.4404 | EŞİK_GENİŞ |
| 30 | B2-02288 | S_P | GENİŞ | 598.9 | 8.765e-05 | 0.004713 | -1.5e-10 | 0.2266 | EŞİK_GENİŞ |
| 31 | B2-02310 | S_P | GENİŞ | 720.3 | 8.131e-05 | 0.00145 | -2.828e-10 | 0.09731 | EŞİK_GENİŞ |
| 32 | B2-02844 | S_P | GENİŞ | 798.8 | 0.0001061 | 0.0015 | 1.039e-10 | 0.2101 | EŞİK_GENİŞ |
| 33 | B2-03022 | S_P | GENİŞ | 847.6 | 0.0001885 | 0.001214 | -8.285e-11 | 0.328 | EŞİK_GENİŞ |
| 34 | B2-03107 | S_P | GENİŞ | 456.8 | 5.166e-05 | 0.002161 | -3.541e-10 | 0.05671 | EŞİK_GENİŞ |
| 35 | B2-03110 | S_P | GENİŞ | 522.8 | 5.017e-05 | 0.005941 | 1.765e-11 | 0.3327 | EŞİK_GENİŞ |
| 36 | B2-03158 | S_P | GENİŞ | 670.7 | 0.0001024 | 0.001376 | 1.28e-10 | 0.2457 | EŞİK_GENİŞ |
| 37 | B2-03316 | S_P | GENİŞ | 503.7 | 5.907e-05 | 0.00809 | 1.333e-10 | 0.4713 | EŞİK_GENİŞ |
| 38 | B2-03326 | S_P | GENİŞ | 537.7 | 4.297e-05 | 0.001022 | -2.126e-10 | 0.1522 | EŞİK_GENİŞ |
| 39 | B2-03602 | S_P | GENİŞ | 607 | 5.547e-05 | 0.002012 | 7.187e-11 | 0.2623 | EŞİK_GENİŞ |
| 40 | B2-F00123 | S_P | GENİŞ | 506.2 | 5.486e-05 | 0.001052 | -1.626e-10 | 0.1539 | EŞİK_GENİŞ |
| 41 | B2-F00142 | S_P | GENİŞ | 553.3 | 6.37e-05 | 0.001733 | 2.308e-10 | 0.1305 | EŞİK_GENİŞ |
| 42 | B2-F00144 | S_P | GENİŞ | 438.1 | 5.091e-05 | 0.001971 | 2.082e-10 | 0.1737 | EŞİK_GENİŞ |
| 43 | B2-F00388 | S_P | GENİŞ | 565.9 | 3.932e-05 | 0.006584 | 3.175e-10 | 0.113 | EŞİK_GENİŞ |
| 44 | B2-F00529 | S_P | GENİŞ | 444.6 | 3.042e-05 | 0.00146 | 2.004e-10 | 0.101 | EŞİK_GENİŞ |
| 45 | B2-F00586 | S_P | GENİŞ | 555 | 7.201e-05 | 0.004486 | 1.616e-10 | 0.251 | EŞİK_GENİŞ |
| 46 | B2-F00648 | S_P | GENİŞ | 432.1 | 1.932e-05 | 0.001291 | 3.321e-10 | 0.2082 | EŞİK_GENİŞ |
| 47 | B2-F00654 | S_P | GENİŞ | 464.8 | 1.706e-05 | 0.005494 | -7.832e-11 | 0.1143 | EŞİK_GENİŞ |
| 48 | B2-F00720 | S_P | GENİŞ | 476.1 | 2.379e-05 | 0.002302 | -2.663e-10 | 0.1679 | EŞİK_GENİŞ |
| 49 | B2-F00750 | S_P | GENİŞ | 557.6 | 3.534e-05 | 0.004368 | -1.734e-10 | 0.1696 | EŞİK_GENİŞ |
| 50 | B2-F00843 | S_P | GENİŞ | 376.2 | 2.169e-05 | 0.01207 | 1.719e-10 | 0.1932 | EŞİK_GENİŞ |
| 51 | B2-F00996 | S_P | GENİŞ | 488.6 | 5.915e-05 | 0.001127 | 9.796e-11 | 0.2496 | EŞİK_GENİŞ |
| 52 | B2-F01060 | S_P | GENİŞ | 513.8 | 5.882e-05 | 0.001215 | -1.744e-10 | 0.2634 | EŞİK_GENİŞ |
| 53 | B2-F01352 | S_P | GENİŞ | 446.1 | 1.908e-05 | 0.001483 | 2.587e-10 | 0.1653 | EŞİK_GENİŞ |
| 54 | B2-F01607 | S_P | GENİŞ | 504.6 | 8.134e-05 | 0.001978 | 8.16e-11 | 0.3199 | EŞİK_GENİŞ |
| 55 | B2-F01671 | S_P | GENİŞ | 518.9 | 5.568e-05 | 0.0011 | 2.668e-10 | 0.05011 | EŞİK_GENİŞ |
| 56 | B2-F01748 | S_P | GENİŞ | 441.3 | 2.796e-05 | 0.001778 | 1.176e-10 | 0.2513 | EŞİK_GENİŞ |
| 57 | B2-F01867 | S_P | GENİŞ | 476.8 | 2.555e-05 | 0.005669 | -1.53e-10 | 0.09543 | EŞİK_GENİŞ |
| 58 | B2-F01973 | S_P | GENİŞ | 365.9 | 2.291e-05 | 0.005909 | 1.209e-10 | 0.313 | EŞİK_GENİŞ |
| 59 | C-00246 | S_P | GENİŞ | 369.5 | 3.421e-05 | 0.001525 | 9.606e-11 | 0.05702 | EŞİK_GENİŞ |
| 60 | C-00260 | S_P | GENİŞ | 428 | 7.708e-05 | 0.007023 | -9.419e-11 | 0.3114 | EŞİK_GENİŞ |
| 61 | C-00539 | S_P | GENİŞ | 508 | 5.759e-05 | 0.001285 | 1.492e-10 | 0.1436 | EŞİK_GENİŞ |
| 62 | C-00754 | S_P | GENİŞ | 566.3 | 0.0001371 | 0.001118 | -1.892e-11 | 0.1079 | EŞİK_GENİŞ |
| 63 | C-00828 | S_P | GENİŞ | 493.2 | 8.063e-05 | 0.002468 | 8.189e-11 | 0.1654 | EŞİK_GENİŞ |
| 64 | C-00854 | S_P | GENİŞ | 502 | 0.0001198 | 0.001332 | -2.317e-11 | 0.1796 | EŞİK_GENİŞ |
| 65 | C-00950 | S_P | GENİŞ | 331.6 | 3.386e-05 | 0.001775 | -1.884e-10 | 0.2092 | EŞİK_GENİŞ |
| 66 | C-00952 | S_P | GENİŞ | 461.5 | 0.0002325 | 0.01375 | 1.529e-10 | 0.4749 | EŞİK_GENİŞ |
| 67 | C-00965 | S_P | GENİŞ | 421.1 | 0.0001244 | 0.001789 | -5.116e-11 | 0.1331 | EŞİK_GENİŞ |
| 68 | C-01006 | S_P | GENİŞ | 447.6 | 5.137e-05 | 0.009074 | -1.71e-10 | 0.2726 | EŞİK_GENİŞ |
| 69 | C-01055 | S_P | GENİŞ | 443.4 | 5.356e-05 | 0.001414 | -1.195e-10 | 0.2107 | EŞİK_GENİŞ |
| 70 | C-01111 | S_P | GENİŞ | 420.6 | 6.505e-05 | 0.02225 | 1.037e-11 | 0.3442 | EŞİK_GENİŞ |
| 71 | C-01418 | S_P | GENİŞ | 413.1 | 0.000122 | 0.001566 | 1.449e-10 | 0.215 | EŞİK_GENİŞ |
| 72 | C-01438 | S_P | GENİŞ | 332.7 | 4.26e-05 | 0.003086 | 3.05e-10 | 0.06647 | EŞİK_GENİŞ |
| 73 | C-01464 | S_P | GENİŞ | 408.3 | 0.0001157 | 0.01692 | 3.803e-10 | 0.06771 | EŞİK_GENİŞ |
| 74 | C-01576 | S_P | GENİŞ | 512.5 | 7.931e-05 | 0.001061 | 4.011e-11 | 0.2368 | EŞİK_GENİŞ |
| 75 | C-01644 | S_P | GENİŞ | 446 | 0.0001399 | 0.005257 | -5.142e-11 | 0.3571 | EŞİK_GENİŞ |
| 76 | C-01680 | S_P | GENİŞ | 390.5 | 6.357e-05 | 0.001753 | 1.965e-10 | 0.08285 | EŞİK_GENİŞ |
| 77 | C-01741 | S_P | GENİŞ | 510.1 | 0.0001245 | 0.00146 | 7.64e-11 | 0.2714 | EŞİK_GENİŞ |
| 78 | C-01748 | S_P | GENİŞ | 379.3 | 5.736e-05 | 0.001423 | 8.003e-11 | 0.199 | EŞİK_GENİŞ |
| 79 | C-02050 | S_P | GENİŞ | 458.9 | 6.665e-05 | 0.001075 | 1.848e-10 | 0.1063 | EŞİK_GENİŞ |
| 80 | C-02098 | S_P | GENİŞ | 441.5 | 5.779e-05 | 0.00525 | 4.666e-11 | 0.1565 | EŞİK_GENİŞ |
| 81 | C-02110 | S_P | GENİŞ | 387.4 | 9.581e-05 | 0.003188 | 6.008e-11 | 0.4278 | EŞİK_GENİŞ |
| 82 | C-02179 | S_P | GENİŞ | 505.2 | 0.0001351 | 0.001639 | -2.207e-10 | 0.2017 | EŞİK_GENİŞ |
| 83 | C-02374 | S_P | GENİŞ | 322.8 | 8.629e-05 | 0.002004 | 2.068e-10 | 0.3763 | EŞİK_GENİŞ |
| 84 | C-02384 | S_P | GENİŞ | 370 | 5.792e-05 | 0.001062 | -1.274e-10 | 0.2513 | EŞİK_GENİŞ |
| 85 | C-02642 | S_P | GENİŞ | 431.9 | 0.0001088 | 0.001496 | -2.582e-10 | 0.08695 | EŞİK_GENİŞ |
| 86 | C-02758 | S_P | GENİŞ | 422.7 | 4.139e-05 | 0.001136 | -1.415e-10 | 0.1511 | EŞİK_GENİŞ |
| 87 | C-02851 | S_P | GENİŞ | 434.1 | 7.65e-05 | 0.00149 | 6.409e-11 | 0.2225 | EŞİK_GENİŞ |
| 88 | C-02858 | S_P | GENİŞ | 385.8 | 7.804e-05 | 0.001862 | 5.424e-11 | 0.1881 | EŞİK_GENİŞ |
| 89 | C-02923 | S_P | GENİŞ | 473.7 | 0.0001031 | 0.002524 | -8.075e-11 | 0.3593 | EŞİK_GENİŞ |
| 90 | C-02990 | S_P | GENİŞ | 400.8 | 0.0001091 | 0.001484 | -1.161e-10 | 0.1866 | EŞİK_GENİŞ |
| 91 | C-03112 | S_P | GENİŞ | 470.9 | 0.0001816 | 0.002099 | -1.217e-10 | 0.4455 | EŞİK_GENİŞ |
| 92 | C-03300 | S_P | GENİŞ | 320.3 | 4.612e-05 | 0.005384 | -9.381e-11 | 0.2955 | EŞİK_GENİŞ |
| 93 | C-03399 | S_P | GENİŞ | 401.3 | 0.0001079 | 0.001598 | 3.05e-10 | 0.2636 | EŞİK_GENİŞ |
| 94 | C-03518 | S_P | GENİŞ | 371.3 | 3.906e-05 | 0.00204 | -2.78e-10 | 0.07773 | EŞİK_GENİŞ |
| 95 | C-03569 | S_P | GENİŞ | 534.5 | 0.0001167 | 0.003982 | 3.459e-10 | 0.2081 | EŞİK_GENİŞ |
| 96 | C-03720 | S_P | GENİŞ | 425.9 | 4.152e-05 | 0.001345 | -2.855e-11 | 0.2799 | EŞİK_GENİŞ |
| 97 | C-03868 | S_P | GENİŞ | 401.7 | 4.503e-05 | 0.001019 | 1.944e-10 | 0.1548 | EŞİK_GENİŞ |
| 98 | C-03914 | S_P | GENİŞ | 466.6 | 0.0001402 | 0.008024 | -4.923e-11 | 0.2474 | EŞİK_GENİŞ |
| 99 | C-04024 | S_P | GENİŞ | 461 | 9.516e-05 | 0.001765 | 1.271e-12 | 0.2717 | EŞİK_GENİŞ |
| 100 | C-04066 | S_P | GENİŞ | 401.7 | 4.386e-05 | 0.0668 | -2.544e-10 | 0.1945 | EŞİK_GENİŞ |
| 101 | C-04080 | S_P | GENİŞ | 366.6 | 4.614e-05 | 0.001584 | -3.981e-11 | 0.317 | EŞİK_GENİŞ |
| 102 | C-F00024 | S_P | GENİŞ | 411.4 | 5.113e-05 | 0.007642 | 1.952e-10 | 0.2416 | EŞİK_GENİŞ |
| 103 | C-F00032 | S_P | GENİŞ | 404.1 | 4.188e-05 | 0.00148 | 1.443e-10 | 0.1833 | EŞİK_GENİŞ |
| 104 | C-F00042 | S_P | GENİŞ | 418.8 | 5.684e-05 | 0.001169 | 3.706e-11 | 0.1594 | EŞİK_GENİŞ |
| 105 | C-F00065 | S_P | GENİŞ | 350.1 | 3.809e-05 | 0.001821 | 2.086e-10 | 0.09843 | EŞİK_GENİŞ |
| 106 | C-F00079 | S_P | GENİŞ | 383.6 | 3.169e-05 | 0.004663 | -2.664e-10 | 0.1986 | EŞİK_GENİŞ |
| 107 | C-F00104 | S_P | GENİŞ | 327.6 | 2.674e-05 | 0.003656 | 4.707e-11 | 0.261 | EŞİK_GENİŞ |
| 108 | C-F00177 | S_P | GENİŞ | 393.9 | 2.805e-05 | 0.001418 | -4.97e-11 | 0.06779 | EŞİK_GENİŞ |
| 109 | C-F00186 | S_P | GENİŞ | 367 | 3.887e-05 | 0.005368 | -1.947e-10 | 0.257 | EŞİK_GENİŞ |
| 110 | C-F00213 | S_P | GENİŞ | 347.3 | 3.27e-05 | 0.001675 | 1.175e-10 | 0.1022 | EŞİK_GENİŞ |
| 111 | C-F00218 | S_P | GENİŞ | 421.2 | 7.246e-05 | 0.02716 | 2.363e-10 | 0.193 | EŞİK_GENİŞ |
| 112 | C-F00245 | S_P | GENİŞ | 418.5 | 5.609e-05 | 0.001123 | 2.325e-10 | 0.2894 | EŞİK_GENİŞ |
| 113 | C-F00247 | S_P | GENİŞ | 388.9 | 3.723e-05 | 0.001638 | -7.508e-11 | 0.1195 | EŞİK_GENİŞ |
| 114 | C-F00254 | S_P | GENİŞ | 446.9 | 5.269e-05 | 0.004368 | -8.497e-11 | 0.133 | EŞİK_GENİŞ |
| 115 | C-F00292 | S_P | GENİŞ | 346.7 | 2.097e-05 | 0.001322 | 7.495e-11 | 0.09052 | EŞİK_GENİŞ |
| 116 | C-F00310 | S_P | GENİŞ | 371.8 | 4.057e-05 | 0.001156 | -3.671e-11 | 0.07461 | EŞİK_GENİŞ |
| 117 | C-F00330 | S_P | GENİŞ | 428.5 | 6.792e-05 | 0.003267 | 1.117e-10 | 0.203 | EŞİK_GENİŞ |
| 118 | C-F00369 | S_P | GENİŞ | 382.6 | 2.931e-05 | 0.00468 | -8.383e-11 | 0.07288 | EŞİK_GENİŞ |
| 119 | C-F00376 | S_P | GENİŞ | 415.6 | 7.406e-05 | 0.001043 | -6.054e-12 | 0.1676 | EŞİK_GENİŞ |
| 120 | C-F00422 | S_P | GENİŞ | 375 | 2.716e-05 | 0.006234 | 1.515e-10 | 0.2179 | EŞİK_GENİŞ |
| 121 | C-F00481 | S_P | GENİŞ | 341 | 4.005e-05 | 0.001274 | -2.398e-10 | 0.07523 | EŞİK_GENİŞ |
| 122 | C-F00521 | S_P | GENİŞ | 373 | 3.399e-05 | 0.001633 | -2.039e-10 | 0.136 | EŞİK_GENİŞ |
| 123 | C-F00526 | S_P | GENİŞ | 337.3 | 5.991e-05 | 0.004994 | 2.787e-10 | 0.1833 | EŞİK_GENİŞ |
| 124 | C-F00527 | S_P | GENİŞ | 419.6 | 4.435e-05 | 0.001868 | -3.082e-10 | 0.1091 | EŞİK_GENİŞ |
| 125 | C-F00531 | S_P | GENİŞ | 368.2 | 4.054e-05 | 0.01137 | 2.235e-10 | 0.2223 | EŞİK_GENİŞ |
| 126 | C-F00532 | S_P | GENİŞ | 396.2 | 4.793e-05 | 0.00122 | 1.93e-11 | 0.2183 | EŞİK_GENİŞ |
| 127 | C-F00587 | S_P | GENİŞ | 327.1 | 2.008e-05 | 0.001682 | 2.855e-10 | 0.1584 | EŞİK_GENİŞ |
| 128 | C-F00616 | S_P | GENİŞ | 374.5 | 4.142e-05 | 0.001455 | -9.475e-11 | 0.1958 | EŞİK_GENİŞ |
| 129 | C-F00654 | S_P | GENİŞ | 348 | 2.258e-05 | 0.01486 | -3.991e-11 | 0.1312 | EŞİK_GENİŞ |
| 130 | C-F00765 | S_P | GENİŞ | 376.2 | 3.169e-05 | 0.001169 | -3.126e-10 | 0.1307 | EŞİK_GENİŞ |
| 131 | C-F00770 | S_P | GENİŞ | 382.6 | 5.65e-05 | 0.001183 | -1.03e-10 | 0.1898 | EŞİK_GENİŞ |
| 132 | C-F00779 | S_D | GENİŞ | 356.9 | 2.259e-05 | 0.03481 | 3.621e-11 | 0.02698 | EŞİK_GENİŞ |
| 133 | C-F00830 | S_P | GENİŞ | 394.9 | 5.381e-05 | 0.002391 | 6.27e-11 | 0.1224 | EŞİK_GENİŞ |
| 134 | C-F01016 | S_P | GENİŞ | 334.8 | 3.202e-05 | 0.001039 | -3.096e-10 | 0.1672 | EŞİK_GENİŞ |
| 135 | C-F01021 | S_P | GENİŞ | 391.7 | 3.532e-05 | 0.001172 | 9.349e-11 | 0.1734 | EŞİK_GENİŞ |
| 136 | B2-F00126 | S_P | NE-kimlik | — | — | — | — | — | NE-kimlik |
| 137 | B2-F01230 | S_P | NE-kimlik | — | — | — | — | — | NE-kimlik |
| 138 | B2-F01892 | S_P | NE-kimlik | — | — | — | — | — | NE-kimlik |
| 139 | C-00414 | S_P | NE-kimlik | — | — | — | — | — | NE-kimlik |
| 140 | C-03249 | S_P | NE-kimlik | — | — | — | — | — | NE-kimlik |
| 141 | C-F00721 | S_P | NE-kimlik | — | — | — | — | — | NE-kimlik |
