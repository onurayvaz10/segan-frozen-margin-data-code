"""VH94 analysis functions (protocol VH94 v0.2 §5.4-§8): run gates, modal growth-rate estimator, per-case paired
difference and campaign verdict. Pure functions (NumPy, no file input/output); vh94_run.py does all reading/writing.

v0.2 (audit D1): gates on [0, t_b] with instantaneous modulation/DC channels (R-1); zoom search with interior
conditions, sigma grid [-150, 60] (R-2, R-14); fixed slow real-mode column from the pilot (R-3); sigma_p = 0 guard
and first-minimum tie rule (R-9); KISMİ needs one AGREE of each sign (R-7).
v1.2 (SABİT §14): q3 uses the in-band noise floor (fit band [0.6, 1.4] f_p); broadband n0 is reported.
v0.3 (audit D2): truncation 0.05 pu and minimum window 0.06 s (F-2); finiteness, latch (t >= 0.30) and the protective
restore flag are judged on [0, t_b] (F-1, B1-2, B1-6); vendor flags stay whole-run."""
import math

import numpy as np

PLAN_SHA256 = '21e56aa6d6a8687603e8b8c26715341d1bcbef8c899fd488c7604fb2dc6099d0'
CASES = ('A2-F00993', 'A2-F01921', 'A2-F00357', 'A2-F00138', 'F2-0.65-0.20', 'F2-0.60-0.20')
RUNS = (('R_m', '0p025'), ('F_m', '0p025'), ('R_m', '0p05'), ('F_m', '0p05'))   # v1.3 (D-265): primary runs only
T_A = 0.595            # fit window start (pulse end + 30 ms)
T_END = 1.795
T_NOISE = (0.20, 0.30)
T_REF = (0.530, 0.555)
DEV_MAX = 0.05         # truncation threshold [pu] (v0.3)
WIN_MIN = 0.06         # minimum fit window [s] (v0.3)
SIG_LO, SIG_HI = -150.0, 60.0
SIG_COARSE = np.round(np.arange(SIG_LO, SIG_HI + 1e-9, 0.5), 10)
N_OMEGA = 81           # coarse omega grid on [0.6, 1.4] f_p
ZOOM = ((1.0, 0.05), (0.1, 0.005))   # (half width, step) of sigma per zoom level; omega: +-1 step of previous level
N_ZOOM_OMEGA = 41
MAX_RECENTER = 10
R2_MIN = 0.5
SNR_MIN = 10.0
D_MIN = 0.2
K_U = 3.0
VERDICTS = {1: 'ABORT', 2: 'NOT_EVALUABLE', 3: 'RET', 4: 'BELİRSİZ', 5: 'KISMİ', 6: 'TUTARLI'}


# ---------------------------------------------------------------- estimator (§5.5)
def _trend(tau, sig_r):
    cols = [np.ones_like(tau), tau]
    if sig_r is not None:
        cols.append(np.exp(sig_r * tau))
    return np.column_stack(cols)


def _design(tau, sig, om, sig_r):
    ref = tau[-1] if sig > 0 else 0.0                     # column scaling only (fit unchanged)
    e = np.exp(sig * (tau - ref))
    return np.column_stack((_trend(tau, sig_r), e * np.cos(om * tau), e * np.sin(om * tau))), ref


def _rss(tau, y, sig, om, sig_r):
    X, ref = _design(tau, sig, om, sig_r)
    coef = np.linalg.lstsq(X, y, rcond=None)[0]
    r = y - X @ coef
    return float(r @ r), coef, ref


def _rss_grid(tau, y, sigmas, om, Q):
    """RSS for every sigma at one omega (variable projection): the trend columns (QR factor Q) are projected out and
    the two oscillatory columns are solved in closed form (2x2 normal equations per sigma)."""
    py = y - Q @ (Q.T @ y)
    ref = np.where(sigmas > 0, tau[-1], 0.0)
    E = np.exp(sigmas[None, :] * (tau[:, None] - ref[None, :]))
    Zc = E * np.cos(om * tau)[:, None]
    Zs = E * np.sin(om * tau)[:, None]
    Zc -= Q @ (Q.T @ Zc)
    Zs -= Q @ (Q.T @ Zs)
    a11 = (Zc * Zc).sum(0)
    a22 = (Zs * Zs).sum(0)
    a12 = (Zc * Zs).sum(0)
    b1 = Zc.T @ py
    b2 = Zs.T @ py
    det = a11 * a22 - a12 * a12
    with np.errstate(divide='ignore', invalid='ignore'):
        expl = (a22 * b1 * b1 - 2 * a12 * b1 * b2 + a11 * b2 * b2) / det
    expl = np.where(np.isfinite(expl) & (det > 0), expl, 0.0)
    return float(py @ py) - expl


def _grid_min(tau, y, Q, sigmas, omegas):
    """(rss, i_sigma, j_omega) of the first minimum (numpy argmin order: omega outer, sigma inner)."""
    best = (math.inf, None, None)
    for j, om in enumerate(omegas):
        r = _rss_grid(tau, y, sigmas, om, Q)
        i = int(np.argmin(r))
        if r[i] < best[0]:
            best = (float(r[i]), i, j)
    return best


def fit_mode(t, y, t_a, t_b, f_p, sig_r):
    """Variable-projection fit of y = c0 + c1 tau [+ c2 exp(sig_r tau)] + exp(s tau)(a cos w tau + b sin w tau).
    Coarse grid, then two zoom levels; a zoom optimum on its box edge is re-centred (at most MAX_RECENTER times)."""
    m = (t >= t_a - 1e-9) & (t <= t_b + 1e-9)
    tau, yy = t[m] - t_a, y[m]
    if len(tau) < 20:
        return dict(ok=False, why='few samples')
    Q, _ = np.linalg.qr(_trend(tau, sig_r))
    om_c = 2 * math.pi * np.linspace(0.6 * f_p, 1.4 * f_p, N_OMEGA)
    _, i_c, j_c = _grid_min(tau, yy, Q, SIG_COARSE, om_c)
    s_cur, om_cur, d_om = float(SIG_COARSE[i_c]), float(om_c[j_c]), float(om_c[1] - om_c[0])
    zoom_edge = False
    for half, step in ZOOM:
        n_s = int(round(2 * half / step)) + 1
        for _ in range(MAX_RECENTER + 1):
            sigs = np.round(s_cur - half + step * np.arange(n_s), 10)
            oms = np.linspace(om_cur - d_om, om_cur + d_om, N_ZOOM_OMEGA)
            _, i, j = _grid_min(tau, yy, Q, sigs, oms)
            s_cur, om_cur = float(sigs[i]), float(oms[j])
            if 0 < i < n_s - 1 and 0 < j < N_ZOOM_OMEGA - 1:
                break
        else:
            zoom_edge = True
        d_om = float(oms[1] - oms[0])
    rss, coef, ref = _rss(tau, yy, s_cur, om_cur, sig_r)
    T = _trend(tau, sig_r)
    ct = np.linalg.lstsq(T, yy, rcond=None)[0]
    tss1 = float(((yy - T @ ct) ** 2).sum())
    k = T.shape[1]
    a0 = float(math.hypot(coef[k], coef[k + 1]) * math.exp(-s_cur * ref))
    return dict(ok=True, sigma=s_cur, f_hz=om_cur / (2 * math.pi), rss=rss, tss1=tss1,
                r2=(1 - rss / tss1) if tss1 > 0 else None, a0=a0, coarse_j=int(j_c),
                coarse_sigma=float(SIG_COARSE[i_c]), zoom_edge=zoom_edge, n=int(len(tau)), t_a=t_a, t_b=t_b,
                sig_r=sig_r)


def window_end(t, y, sig_p):
    """§5.5 steps 3-4: (t_b, y_ref, truncated, T_w)."""
    t_w = min(1.2, max(0.25, 4.0 / abs(sig_p))) if sig_p else 1.2
    t_b = min(T_A + t_w, T_END)
    ref = float(np.median(y[(t >= T_REF[0]) & (t <= T_REF[1])]))
    over = np.nonzero((t > T_A) & (t <= t_b) & (np.abs(y - ref) > DEV_MAX))[0]
    trunc = bool(len(over))
    if trunc:
        t_b = float(t[over[0]])
    return t_b, ref, trunc, t_w


def noise_floor(t, y, f_p=None):
    """n0 over [0.20, 0.30) s after a linear detrend. v1.2: in-band, i.e. only the spectral content in
    [0.6, 1.4] f_p (the fit band) is kept (FFT mask); the broadband value is returned when f_p is None."""
    m = (t >= T_NOISE[0]) & (t < T_NOISE[1])
    tt, yy = t[m], y[m]
    X = np.column_stack((np.ones_like(tt), tt))
    r = yy - X @ np.linalg.lstsq(X, yy, rcond=None)[0]
    if f_p is None:
        return float(np.std(r))
    R = np.fft.rfft(r)
    f = np.fft.rfftfreq(len(r), float(np.median(np.diff(tt))))
    band = (f >= 0.6 * f_p) & (f <= 1.4 * f_p)
    return float(np.std(np.fft.irfft(np.where(band, R, 0), n=len(r))))


def estimate_run(t, y, sig_p, f_p, sig_r, window=None):
    """§5.5 steps 1-8 for one run. window: precomputed window_end tuple (gates use the same t_b)."""
    t_b, yref, trunc, t_w = window if window is not None else window_end(t, y, sig_p)
    o = dict(t_b=t_b, y_ref=yref, truncated=trunc, t_w=t_w, sig_p=sig_p, f_p=f_p, sig_r=sig_r)
    n0 = noise_floor(t, y, f_p)          # v1.2: in-band n0 for q3
    o['n0'] = n0
    o['n0_broadband'] = noise_floor(t, y)
    if t_b - T_A < WIN_MIN:
        o['ne'] = 'pencere'
        return o
    f = fit_mode(t, y, T_A, t_b, f_p, sig_r)
    o['fit'] = f
    if not f['ok']:
        o['ne'] = 'fit'
        return o
    fv = fit_mode(t, y, T_A, T_A + 0.6 * (t_b - T_A), f_p, sig_r)
    o['fit_variant'] = fv
    o['sigma'] = f['sigma']
    o['sigma_variant'] = fv.get('sigma')
    q1 = (1 <= f['coarse_j'] <= N_OMEGA - 2 and SIG_LO + 0.5 < f['sigma'] < SIG_HI - 0.5 and not f['zoom_edge'])
    q2 = f['r2'] is not None and f['r2'] >= R2_MIN
    q3 = f['a0'] >= SNR_MIN * n0
    o.update(q1=q1, q2=q2, q3=q3)
    o['ne'] = None if (q1 and q2 and q3) else ('q1' if not q1 else 'q2' if not q2 else 'q3')
    return o


# ---------------------------------------------------------------- run gates (§5.6, on [0, t_b])
def run_gates(status, cap, guard_ok, t_b):
    g = {}
    g['status'] = status.get('status') == 'actual_virtual_hil_capture_saved'
    g['flags'] = all(v is False for v in (status.get('flags') or {'x': True}).values())
    g['rows'] = abs(int(status.get('capture_rows', -9)) - int(status.get('expected_rows', -99))) <= 1
    t = cap['t']
    w = t <= t_b + 1e-9
    g['finite'] = bool(np.isfinite(cap['values'][:, w]).all())
    g['latched'] = bool(np.all(cap['latched'][(t >= 0.30 - 1e-9) & w] == 1.0))
    g['no_restore'] = bool(np.all(cap['tripped'][w] == 0.0))
    kb = int(np.nonzero(w)[0][-1])
    peak = float(max(np.max(cap['mg'][w]), np.max(cap['mc'][w])))
    dcmin = float(np.min(cap['dc_pu'][w]))
    g['modulation'] = peak <= 1.0
    g['dc'] = dcmin > 0
    E, B, S = cap['stored_energy_pu_s'], cap['balance_pu_s'], cap['supplied_energy_pu_s']
    delta = float(E[kb] - E[0])
    net = float(B[kb] - B[0])
    supply = float(S[kb] - S[0])
    rel = abs(delta - net) / max(abs(supply), abs(float(E[0])), 1e-9)
    g['energy'] = rel <= 0.01
    g['guard'] = bool(guard_ok)
    return all(g.values()), g, dict(peak_modulation_to_tb=peak, minimum_dc_to_tb=dcmin, energy_relative_to_tb=rel,
                                    peak_modulation_run=float(max(cap['peak_gfm_mod'][-1], cap['peak_rectifier_mod'][-1])),
                                    t_b=t_b)


def pred_of(case, scen):
    """(sigma_p, f_p, sigma_r) of the pilot for the operating point of the scenario."""
    p = case['pred_d']
    if scen == 'B0':
        q = p['zero']
        return q['sigma_R'], q['f_R'], q.get('sr_R')
    if scen == 'F_m':
        q = p['m']
        return q['sigma_F'], q['f_F'], q.get('sr_F')
    q = p[{'R_m': 'm', 'R_lo': 'lo', 'R_hi': 'hi'}[scen]]
    return q['sigma_R'], q['f_R'], q.get('sr_R')


# ---------------------------------------------------------------- per case and campaign (§6, §8)
def case_verdict(s_pred, rF25, rR25, rF50, rR50):
    """Return (label, D, u_D, thr). Inputs are run estimates (dict with sigma, sigma_variant, ne)."""
    for r in (rF25, rR25, rF50, rR50):
        if r is None or r.get('ne') is not None:
            return 'NE', None, None, None
    uF = max(abs(rF25['sigma'] - rF50['sigma']), abs(rF25['sigma'] - rF25['sigma_variant']))
    uR = max(abs(rR25['sigma'] - rR50['sigma']), abs(rR25['sigma'] - rR25['sigma_variant']))
    D = rF25['sigma'] - rR25['sigma']
    uD = math.hypot(uF, uR)
    thr = max(K_U * uD, D_MIN)
    if D == 0 or abs(D) < thr:
        return 'UNDETERMINED', D, uD, thr
    return ('AGREE' if (1 if D > 0 else -1) == s_pred else 'DISAGREE'), D, uD, thr


def campaign_verdict(labels, signs, integrity_ok):
    """labels: case -> label; signs: case -> s_pred. Returns (row, verdict)."""
    if not integrity_ok:
        return 1, VERDICTS[1]
    ev = [c for c, l in labels.items() if l != 'NE']
    n_opt = sum(1 for c in ev if signs[c] < 0)
    n_con = sum(1 for c in ev if signs[c] > 0)
    if len(ev) < 4 or n_opt < 2 or n_con < 2:
        return 2, VERDICTS[2]
    if any(labels[c] == 'DISAGREE' for c in ev):
        return 3, VERDICTS[3]
    ag = [c for c in ev if labels[c] == 'AGREE']
    if len(ag) < 3 or not any(signs[c] < 0 for c in ag) or not any(signs[c] > 0 for c in ag):
        return 4, VERDICTS[4]
    if any(labels[c] == 'UNDETERMINED' for c in ev):
        return 5, VERDICTS[5]
    return 6, VERDICTS[6]
