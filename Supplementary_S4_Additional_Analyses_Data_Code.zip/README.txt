Supplementary S4 - Additional analyses, data and code (2026-11-08)

Accompanies: "Decision-induced bias of frozen small-signal margins in resistive load shedding:
a port-admittance sign rule for grid-forming microgrids" (manuscript v6.4, Supplementary Methods S2 v7).
S1 and S3 are unchanged. Everything here was computed offline (evidence level E2/E4; no physical hardware).

k2_newton_timing/        From-scratch timing of the Newton-kappa estimators on the nine benchmark points of
                         N2, N3, N5 (Table 9, S2 Section F.12). Descriptive, machine dependent.
e2p_port_analysis/       Pre-specified analysis (protocol E2P v1.1, frozen before computation): A) identity of
                         the exact state-space reference with a port-admittance crossing and the offset of the
                         relative-threshold reference; B) tracking of the critical port branch along the path at
                         the optimistic and disagreement points; C) row decomposition of kappa. Single sealed run
                         E2P_20261108_a (SHA256SUMS inside). See S2 and the result report.
vhil_direction_studies/  Pre-specified Typhoon Virtual HIL direction studies VH94, VH95 (with the re-analysis
                         VH95-RA) and VH96 (S2 Appendix I.7). Protocols, run/analysis code, result reports and
                         sealed run folders. Raw captures larger than 2 MB are omitted and listed with their
                         SHA-256 in OMITTED_LARGE_FILES.csv (available from the authors).

Protocols, audit and result reports are the original working records and are written in Turkish; the English
description of each study is in Supplementary Methods S2.

Verification: from this folder run   python -I verify_s4.py
It checks the SHA-256 of every file listed in FILE_INVENTORY.csv (standard library only, read-only).
