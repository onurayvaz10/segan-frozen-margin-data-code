# VH95 — Sonuç raporu (B5)

**Başlık bilgileri**
- Tarih: 2026-11-06
- Yazar: Claude Code (Opus 5.5), ana oturum. Yetki dosyasını bu oturum yazdı. B4'ü ayrı oturum `vh95-b4` yürüttü. Kod denetçisi (B3/B3b) bu oturum değil.
- Ön-kayıt: VH94 SABİT v1.3 (ae8628bd…999d), değiştirilmeden.
- Yetki: `protokol/VH95_yetki_VH95_20261106_a.json` (3646b50f…3e68).
- Dayanak: D-266, D-267, D-269.

## 1. Mühür ve pinler

**Kampanya:** `C:\Users\onura\Documents\SEGAN_G94_work\vh94\out\VH95_20261106_a`

**Analiz klasörü:** `analysis_VH95_20261106_a\`
- `SHA256SUMS` yeniden hesaplandı; uyuşmazlık ve eksik dosya yok.
- `SHA256SUMS` dosyasının kendi hash'i: f6db2fe9c197f8ed39cb134243f0fd98cfebb34f51d97ede607f9303779d59a6

**Pinler yetki dosyasıyla eşleşiyor:**

| Dosya | SHA-256 |
|---|---|
| SABİT | ae8628bd…999d |
| `vh94_run.py` | ed11d008…fe0f |
| B3b denetim raporu | 515bef36…addf |

`sonuc.json` durumu: `integrity_errors` boş, `failed_attempt_dirs` boş.

**Ledger** (74 kayıt):
- Başlangıç 16:50:11; o anda son 24 saatte WHEA sayısı 0.
- 24 `run` kaydı var. Hepsinde `saved=true`, `exit=0`, `guard_ok=true`, `new_whea=0` ve `attempt=1`.
- Bitiş 20:04:30.
- Koşu yeniden başlatılmadı; hiçbir parametre değiştirilmedi.
- 20:27 denetimi: son 24 saatte WHEA-Logger olayı 0.

## 2. Önceden kayıtlı hüküm

`hukum.txt`, aynen:

```
VH94 hüküm: NOT_EVALUABLE (satır 2)
A2-F00993: AGREE
A2-F01921: NE
A2-F00357: NE
A2-F00138: NE
F2-0.65-0.20: NE
F2-0.60-0.20: NE
```

SABİT §8 satır 2: "Değerlendirilebilir vaka < 4, ya da değerlendirilebilir iyimser < 2, ya da tutucu < 2 → NOT_EVALUABLE."

Satır 1 (ABORT) eşleşmedi, çünkü bütünlük hatası yok. Satır 2 eşleşti:
- değerlendirilebilir vaka sayısı 1 < 4;
- değerlendirilebilir tutucu (s_pred = +1) sayısı 0 < 2.

**H1 hakkında hüküm verilemez.**

| Vaka | Sınıf | NE nedeni (koşu: kapı) |
|---|---|---|
| A2-F00993 | iyimser | — **AGREE**: D = −23.13 s⁻¹; u_D = 6.01; eşik 18.02; D_pred −20.69 |
| A2-F01921 | iyimser | R_m 25 ns, R_m 50 ns ve F_m 50 ns: dc + enerji kapısı |
| A2-F00357 | iyimser | R_m 50 ns ve F_m 50 ns: dc + enerji |
| A2-F00138 | tutucu | dört koşunun dördü: dc + enerji |
| F2-0.65-0.20 | tutucu | R_m 25 ns, F_m 25 ns ve F_m 50 ns: dc + enerji |
| F2-0.60-0.20 | tutucu | R_m 50 ns ve F_m 50 ns: dc + enerji |

- 24 koşunun 14'ü, §5.6'daki dc (`min dc_pu > 0`) ve enerji kalıntısı (≤ 0.01) kapılarından geçmedi.
- Bu 14 koşunun hepsinde değerler aynı: `minimum_dc_to_tb = 0.0` ve `energy_relative_to_tb ≈ 1.000`.
- Öteki kapıların (status, flags, rows, finite, latched, no_restore, modulation, guard, input_hash) hepsi geçti.
- Kalite (q1–q3) ya da pencere nedeniyle NE olan koşu yok.
- Sınırda (SINIRDA) hücre yok.

## 3. Ön-kayıt dışı gözlemler (post-hoc; hükmü değiştirmez)

**G-1. Kapı başarısızlığının nedeni: yakalama hizalama artefaktı.** (INFERENCE, yüksek güven)

Sonda salt okur çalıştı; mühürlü klasöre yazılmadı. Betik ve çıktısı ayrı klasörde:
- `rapor/VH95_rapor_ek/sifir_sonda.py` (0fa2131b…857e)
- `rapor/VH95_rapor_ek/sifir_sonda_cikti.txt` (a782d700…a9a0)

Başarısız 14 koşunun her birinde iki şey birlikte görülüyor:
- `capture.npz` 1–14 örnek (0.1–1.4 ms) geç başlıyor. İlk zaman damgası 0.00010 yerine 0.00020–0.00150 s.
- Dizinin sonunda aynı sayıda **satır var ve tüm kanalları sıfır** (`time_s = 0` dahil).

Geçen 10 koşuda ise başlangıç 0.00010 s ve sıfır satır yok.

Sıfırlı satırların zamanı 0 olduğu için analizcinin `t ≤ t_b` maskesi bu satırları pencerenin içinde sayıyor (`analyze_vh94.py` satır 186–200). Sonuç olarak:
- `min dc_pu` sıfır çıkıyor;
- `kb` sıfırlı son satırı gösteriyor, bu yüzden E[kb] = 0 oluyor ve kalıntı ≈ 1 hesaplanıyor;
- `peak_modulation_run` (son satır) 0 çıkıyor.

Bu satırlar fiziksel bir dc çöküşü değildir. Aynı koşuların gerçek pencere içi değerleri normal görünüyor: tepe modülasyon 0.81–0.91. Bu gözlem kapıyı geriye dönük olarak geçersiz kılmaz. Hüküm, kurala göre NOT_EVALUABLE olarak kalır.

**G-2. Neden VH94'te görülmedi?**
- VH94'teki 4 koşunun (A2-F00993) hepsi hizalıydı.
- Kuru koşular ve B3/B3b sentetik sınamaları sıfır dolgulu kayma durumunu içermiyordu.

Bu nedenle bu, analizcide denetimden kaçmış bir kusurdur; çalışma zamanı ya da donanım hatası değildir. Bu da INFERENCE. Kaymanın kaynağı (Typhoon tetikleme ve yakalama başlangıcı) belirlenmedi.

**G-3. A2-F00993 bu kez de AGREE.** (rapor değeri)

| Koşu | σ̂ (s⁻¹) | σ_pred | R² |
|---|---|---|---|
| R_m 25 ns | +12.215 | +10.97 | 0.999 |
| R_m 50 ns | +12.19 | +10.97 | 0.998 |
| F_m 25 ns | −10.915 | −9.72 | 0.60 |
| F_m 50 ns | −4.91 | −9.72 | 0.69 |

- Değerler VH94 ile basamağına kadar aynı. Bu yakalama ve yeniden üretilebilirlik açısından olumlu bir rapor değeridir.
- F_m'nin 25 ns ile 50 ns arasındaki 6.0 s⁻¹'lik adım duyarlılığı yinelendi. Bu, VH94 B5'teki bulgunun aynısı; açıklanmış değil.

**G-4. Değerlendirilemeyen vakalarda geçen koşuların σ̂'leri** (yalnız rapor)

Bu değerler yalnızca kapıyı geçen koşulardan geliyor, o yüzden vaka hükmü yok:

| Koşu | σ̂ (s⁻¹) | σ_pred |
|---|---|---|
| A2-F00357 R_m 25 ns | +8.33 | +6.61 |
| A2-F00357 F_m 25 ns | −2.29 | −6.08 |
| F2-0.60-0.20 R_m 25 ns | −5.79 | −4.02 |
| F2-0.60-0.20 F_m 25 ns | +4.71 | +4.44 |
| A2-F01921 F_m 25 ns | −5.78 | −7.79 |
| F2-0.65-0.20 R_m 50 ns | +0.155 | −3.44 |

- F2-0.65-0.20 R_m 50 ns değeri işaret uyuşmuyor ve tek bir koşudur.
- Bunlar H1 için kanıt değildir.

**Körleme notu.** Kapıdan geçmeyen 14 koşu için σ̂ uydurması hesaplanmadı. Yazar bu oturumda o koşuların kestirici sonuçlarını görmedi. Bu, olası bir ön-kayıtlı yeniden analiz için kısmi körlüğü korur.

Sınırlılık: G-4'teki kısmi değerler ve VH94 sonucu görülmüştür. Bu yüzden yeniden analiz çatallanma olarak beyan edilmelidir.

## 4. Kanıt düzeyi

SABİT §2 tavanı **E4** (çevrimdışı, platformlar arası sanal; Typhoon HIL Control Center 2026.3 sanal HIL) korunur. E5/E6 iddiası yoktur; fiziksel HIL değildir. (Düzeltme 2026-11-06: ilk sürümde yanlışlıkla "E5" yazılmıştı.)

Makaleye yazılabilecek en güçlü ifade:

> "Ön-kayıtlı Typhoon VHIL kampanyası donanım olayı olmadan 24 koşuyu tamamladı. Ancak yakalama hizalamasından kaynaklanan bir analiz kapısı artefaktı nedeniyle 6 vakadan yalnız 1'i değerlendirilebilir kaldı (NOT_EVALUABLE). O vakada eşleşik sönüm farkı öngörülen yöndeydi (rapor değeri)."

Anahtarlamalı model düzeyinde genel bir doğrulama iddia edilemez.

## 5. Sapmalar

- **VH95 planı §4'ten sapma:** BIOS ya da mikrokod güncellemesi sonrası 24 saat ölçütü yerine, bakım sonrası 24 saat ve 7 gün boyunca WHEA = 0 kullanıldı. D-269'da beyan edildi.
- **Ön-kayıt dışı sonda:** mühürlü klasörün dışında ve salt okur çalıştı (G-1).
- Başka usul olayı yok.

## 6. Yansımalar ve seçenekler

Kararı kullanıcı verir. Protokol bu turda gevşetilmez.

**a. Olduğu gibi raporla.**
- İçerik: VH94 ve VH95 ikisi de NOT_EVALUABLE; tek vaka rapor değeri; G-1 sınırlılık olarak makale §7.5'e girer.
- Maliyet: sıfır.
- İddiaya etkisi: anahtarlamalı model kanıtı "değerlendirilemedi" olarak kalır.

**b. Mühürlü VH95 kayıtları üzerinde ön-kayıtlı yeniden analiz (VH95-RA).** (önerilen)
- Yeni hesap yok, yeni koşu yok.
- Tek değişiklik: sıfır dolgulu satırları dışlayan maske düzeltmesi. Örneğin ilk satırdan sonra zaman damgası 0 olan ve tüm kanalları sıfır olan satırlar atılır, `kb` son gerçek satır olur ve ≥ 0.999 kapsama ya da satır kapısı eklenir.
- Kalan her şey (eşikler, kestirici, karar tablosu) v1.3 ile aynı kalır.
- Bunun için gerekenler:
  - yeni bir SABİT ek (v1.4-RA) ve çatallanma beyanı (VH94 ve G-4 görüldü);
  - kaymayı içeren sentetik sınama;
  - bağımsız kod denetimi;
  - ayrı yetki.
- Maliyet: düşük; birkaç saat ve Typhoon gerekmez.
- İddiaya etkisi: en fazla "ön-kayıtlı, düzeltilmiş analiz" düzeyinde, açık çatallanma beyanıyla.

**c. Yakalamayı düzelterek yeni koşu (VH96).**
- Tetikleme hizalaması ya da analizci düzeltmesi yapılır ve aynı 24 koşu yinelenir.
- Maliyet: yaklaşık 3,5 saatlik makine süresi; WHEA riski sürüyor.
- İddiaya etkisi: (b)'den daha temiz, çünkü kör bir yeni örneklem olur.

**Argüman haritası ve risk kaydı** (bu adımda değiştirilmedi; öneri):
- VHIL anahtarlamalı model satırı "VH94 NOT_EVALUABLE" yerine "VH94 + VH95 NOT_EVALUABLE; analiz artefaktı bulundu" olarak güncellenmeli.
- Hakem riski "anahtarlamalı modelde yön sınaması yok" açık kalır.

Durum: **KULLANICI_BEKLIYOR** (a/b/c seçimi).
