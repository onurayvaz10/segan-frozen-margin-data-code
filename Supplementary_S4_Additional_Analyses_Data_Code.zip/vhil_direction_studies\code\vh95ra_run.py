"""VH95-RA single-run gate script (tek-koşu kapısı B1). SABİT: VH95RA_On_Kayit_v1.2_SABIT.md (SABIT_PATH / SABIT_SHA256).
v2 changes (2026-11-07, SABİT v1.2 §14 V-1; text-only v1.1->v1.2): X-0 dtype pin per array - time_s float64, values float32 (EXPECTED_DTYPE);
v1 = archive/vh95ra_run_v1_20261107.py (3bb24517...757c95), whose B4 run VH95RA_20261107_a was ABORT X-0.
Exploratory re-analysis of the sealed VH95_20261106_a records: SABİT v1.3 §5-§8 unchanged, plus P-1 (trailing zero
padding removal). The pinned VH94 code (vh94_run.py, analyze_vh94.py) is imported, never edited.

SABİT § -> function
  §4 pins, list pins, environment .... RA_PINS, check_ra_pins, list_sha, X-0..X-2 in pass0
  §5.1 P-1 (+ dtype pre-flight) ...... npy_dtype, preflight, p1_trim, load_capture_ra
  §5.2 X-0..X-4, order ............... pass0, x3_check, x4_check, analyze_ra (pass 0 / 1 / 2)
  §5.3 unchanged parts ............... analyze_vh94.window_end / run_gates / estimate_run / case_verdict /
                                       campaign_verdict, vh94_run.input_hash_ok / report_items / latch_settling
  §8 decision table .................. analyze_vh94.campaign_verdict (rows 2-6); row 1 = abort() in analyze_ra / main
  §9 execution, output, retry ........ main, verify_authorization_ra, write_outputs_ra, Counter
  §10 authorization .................. verify_authorization_ra (before any capture is read)
B3 difference list vs vh94_run.analyze (SABİT §9, M-2): F-1 loader load_capture_ra; F-2 P-1 NE -> dict(ne='p1:<why>',
pad, p1) and est[key] = None; F-3 integrity in pass 0 with early stop; F-4 loop split into pass 1 / pass 2 with X-3 and
X-4 in between; F-5 'pad' and 'p1' fields in every run dict.
Author choices (VH95RA-B1-a ...):
  VH95RA-B1-a  The only module attribute assignment is vh94_run.load_capture = load_capture_ra (inside analyze_ra);
               vh94_run.latch_settling resolves load_capture through the module, so R-7 uses P-1 too (SABİT §9).
  VH95RA-B1-b  P-1 failures raise P1Error from load_capture_ra; pass 1 turns it into the run NE, latch_settling's own
               try/except (vh94_run.py 232-235) turns it into R7 'error'.
  VH95RA-B1-c  The dtype pre-flight parses the .npy headers inside the npz (zipfile + numpy.lib.format); no array
               value is read (SABİT §5.1 item 0).
  VH95RA-B1-d  All paths and expected list hashes of one analysis are collected in a cfg dict. main() builds it only
               from the literals below (REAL_CFG); the synthetic test builds its own cfg for synthetic campaigns.
  VH95RA-B1-e  Estimator calls go through _estimate, which counts calls on padded runs (Counter.padded); the count is
               written to ra_karsilastirma.json and stdout so the retry rule (SABİT §9) can be checked.
  VH95RA-B1-f  On an ABORT before pass 2, sonuc.json carries no run dicts and ra_karsilastirma.json only equal / not
               equal flags (M-7); blinded dc / energy values of padded runs are never written.
  VH95RA-B1-g  A script exception is recorded as verdict ABORT, decision_row 1, with the traceback (SABİT §8 row 1).
Modes: --check-only | --verify --run-id ID --yetki P | --analyze --run-id ID --yetki P --campaign DIR --out DIR
"""
import argparse
import hashlib
import io
import json
import math
import os
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
G94 = r'C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme94_20261029'
SABIT_PATH = os.path.join(G94, 'protokol', 'VH95RA_On_Kayit_v1.2_SABIT.md')
SABIT_SHA256 = 'c6f7cbdb790fa5c89da01fdc8a2a9b80b8e893f38665b2964245b6e7c81e22f0'
RA_PINS = [   # SABİT §4, row for row
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme94_20261029\\protokol\\VH94_On_Kayit_v1.3_SABIT.md', 40367, 'ae8628bd9f05aeafb0a95f0b6d001fe64efe90c53cef2001facc26d1856b999d'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\vh94_run.py', 24801, 'ed11d0082c785cdca0db70a4dc992e45c8e007d974e5745a2878b30f725cfe0f'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\analyze_vh94.py', 11408, 'a8df777e5b83a03af2ac112dbeb809db019eaa28c1c0a56846c86251f1fd0d68'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\vh94_synth.py', 12573, '8ddea8eec617c8d63263d8504390fc2954a573fd15e6d60649fa46dd9d960432'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94_pilot\\vh94_pilot.json', 37235, '21e56aa6d6a8687603e8b8c26715341d1bcbef8c899fd488c7604fb2dc6099d0'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme94_20261029\\denetim\\VH94_kod_denetimi_B3b.md', 5792, '515bef3674af79927b14ff66c1088e9956c3e43414b276820c8f2733e5dfaddf'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme94_20261029\\protokol\\VH95_yetki_VH95_20261106_a.json', 1580, '3646b50fe21eb0a0816f3cfcb15f36ad3d4f98b2591afa0d0053fa0e36363e68'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\out\\VH95_20261106_a\\campaign_ledger.jsonl', 10175, 'a1040553d1ede402ffa041e162951bd968b97d44bb1e0f8d70a428d90d2760cf'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\out\\VH95_20261106_a\\analysis_VH95_20261106_a\\SHA256SUMS', 472, 'f6db2fe9c197f8ed39cb134243f0fd98cfebb34f51d97ede607f9303779d59a6'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\out\\VH95_20261106_a\\analysis_VH95_20261106_a\\sonuc.json', 48572, '084cec660fd6ea913308a9a5e73481985c690356ba94af0423b84527f5f81679'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme94_20261029\\rapor\\VH95_sonuc_raporu_B5.md', 8971, 'b1a148210dc9728a2e65f9632d8937fcf7622e3efbae418b0418b44785fac716'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme94_20261029\\rapor\\VH95_rapor_ek\\zaman_sonda.py', 1204, '0ce3429664c03c88d4ef5eebe1578d15d5c0da11e1c66d5a72f75774625e8f75'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme94_20261029\\rapor\\VH95_rapor_ek\\zaman_sonda_cikti.txt', 5115, '6f8b2b895feabeb95b5df488c8a81a49f3255f40869acd008d4b7c5341a94c74'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme94_20261029\\rapor\\VH95_rapor_ek\\sifir_sonda.py', 917, '0fa2131baffa2b8b293a2eda39608c21238b4005f0cc5da0f15021d741c5857e'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme94_20261029\\rapor\\VH95_rapor_ek\\sifir_sonda_cikti.txt', 2902, 'a782d7008fee30ad7e3deabc2bfa31d71e04eb614d96074bc77e456ba6cab9a0'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme94_20261029\\rapor\\VH95_rapor_ek\\zaman_hassasiyet_sonda.py', 1079, 'a8d61e2c78decbe89ed8fa96ce099b311e16cab58edea908dfe67fe42c9047fc'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme94_20261029\\rapor\\VH95_rapor_ek\\zaman_hassasiyet_sonda_cikti.txt', 3524, '16fbf87c00bc8ab10fa6329c3faaf93d0fbf962481d2f1488b118ef1dc790f60'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme94_20261029\\denetim\\VH95RA_On_Kayit_denetimi_D1.md', 28176, '8e0997e6c6bbc5cdcf74755d62e4ae1be4ec9b12052c9c3aa2500f92f03464cf'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme94_20261029\\denetim\\VH95RA_On_Kayit_denetimi_D2.md', 22470, '791af35e1d2e595f652314db3cb9a39b7af5daa3d2b445978e7907ce1136031a'),
]
VH94_RUN_SHA256 = 'ed11d0082c785cdca0db70a4dc992e45c8e007d974e5745a2878b30f725cfe0f'
ANALYZE_SHA256 = 'a8df777e5b83a03af2ac112dbeb809db019eaa28c1c0a56846c86251f1fd0d68'
VH95_CAMPAIGN = r'C:\Users\onura\Documents\SEGAN_G94_work\vh94\out\VH95_20261106_a'
REAL_CFG = dict(
    campaign=VH95_CAMPAIGN,
    ref_dir=os.path.join(VH95_CAMPAIGN, 'analysis_VH95_20261106_a'),
    ref_sonuc_sha256='084cec660fd6ea913308a9a5e73481985c690356ba94af0423b84527f5f81679',
    ref_sums_sha256='f6db2fe9c197f8ed39cb134243f0fd98cfebb34f51d97ede607f9303779d59a6',
    ledger_sha256='a1040553d1ede402ffa041e162951bd968b97d44bb1e0f8d70a428d90d2760cf',
    capture_list_sha256='d0e0586ef9216a51fae7f6520ff74075768a77f58c615af6c4598c2ea7f63a97',
    run_status_list_sha256='85d6eda45e36a61067fb5d0d35bcbee5ad17909e083e6c06e216f0fe99505c00',
    env=('3.13.2', '2.5.3'),
)
# P-1 constants (SABİT §5.1, §7, M-1)
DT = 1e-4
T_LAST = 1.8
PAD_MAX = 100
TOL_T = 1e-6
THREAD_VARS = ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS')
CASES = ('A2-F00993', 'A2-F01921', 'A2-F00357', 'A2-F00138', 'F2-0.65-0.20', 'F2-0.60-0.20')
SCENARIOS = ('R_m', 'F_m')


def _read_bytes(p):
    with open(p, 'rb') as fh:
        return fh.read()


def _write_text(p, s):
    with open(p, 'w', encoding='utf-8', newline='\n') as fh:
        fh.write(s)


def sha(p):
    return hashlib.sha256(_read_bytes(p)).hexdigest()


def sha_text(s):
    return hashlib.sha256(s.encode('utf-8')).hexdigest()


def canon(obj):
    """Canonical text used by every equality test (SABİT §5.2 X-3 item 3)."""
    return json.dumps(json.loads(json.dumps(obj, default=float)), sort_keys=True, ensure_ascii=False, default=float)


class P1Error(Exception):
    """P-1 rejected a capture; args[0] is the reason (dolgu-yapı / dolgu-sınır / zaman-hiza)."""


class Abort(Exception):
    """SABİT §8 row 1 before pass 2; args[0] = check id (X-0 ... X-4), args[1] = detail list."""


class Counter:
    def __init__(self):
        self.padded = 0     # estimate_run calls on runs with pad > 0
        self.unpadded = 0


# ---------------------------------------------------------------- pins, lists, environment (§4, X-0..X-2)
def check_ra_pins():
    bad = []
    for path, size, digest in RA_PINS:
        if not os.path.isfile(path):
            bad.append((path, 'yok'))
            continue
        b = _read_bytes(path)
        if len(b) != size or hashlib.sha256(b).hexdigest() != digest:
            bad.append((path, 'uyuşmaz'))
    if not os.path.isfile(SABIT_PATH) or sha(SABIT_PATH) != SABIT_SHA256:
        bad.append((SABIT_PATH, 'SABİT uyuşmaz'))
    pin_list = sha_text(json.dumps(RA_PINS, ensure_ascii=False))
    return bad, pin_list


def run_dirs(campaign):
    rd = os.path.join(campaign, 'runs')
    names = [n for n in os.listdir(rd) if os.path.isdir(os.path.join(rd, n)) and '_basarisiz_' not in n]
    return rd, sorted(names)          # Python sorted = ordinal (SABİT §4, R-19)


def list_sha(campaign, fname):
    rd, names = run_dirs(campaign)
    lines = ['%s  %s' % (sha(os.path.join(rd, n, fname)), n) for n in names if os.path.isfile(os.path.join(rd, n, fname))]
    return sha_text('\n'.join(lines) + '\n'), len(lines)


def environment():
    import numpy as np
    try:
        cfg = np.show_config(mode='dicts')
        blas = (cfg.get('Build Dependencies') or {}).get('blas')
    except Exception as exc:  # noqa: BLE001
        blas = 'show_config: %s' % exc
    return dict(python=sys.version.split()[0], numpy=np.__version__, blas=blas,
                threads={v: os.environ.get(v) for v in THREAD_VARS})


def npy_dtype(npz_bytes, member):
    """dtype of one array of an npz from its .npy header only (no values read; SABİT §5.1 item 0)."""
    import numpy as np
    with zipfile.ZipFile(io.BytesIO(npz_bytes)) as zf:
        with zf.open(member + '.npy') as fh:
            ver = np.lib.format.read_magic(fh)
            hdr = (np.lib.format.read_array_header_1_0(fh) if ver == (1, 0)
                   else np.lib.format.read_array_header_2_0(fh))
    return str(hdr[2])


EXPECTED_DTYPE = (('time_s', 'float64'), ('values', 'float32'))  # SABİT v1.2 §5.1 item 0 (V-1)


def preflight(campaign):
    rd, names = run_dirs(campaign)
    bad = []
    for n in names:
        p = os.path.join(rd, n, 'capture.npz')
        if not os.path.isfile(p):
            continue
        b = _read_bytes(p)
        for m, want in EXPECTED_DTYPE:
            try:
                dt = npy_dtype(b, m)
            except Exception as exc:  # noqa: BLE001
                dt = 'okunamadı: %s' % exc
            if dt != want:
                bad.append('%s %s %s' % (n, m, dt))
    return bad


# ---------------------------------------------------------------- P-1 (§5.1)
def p1_trim(T, V, names, capture_rows):
    """Return (k, pad) or raise P1Error. T: time_s, V: values (channel x row)."""
    import numpy as np
    pos = np.nonzero(T > 0)[0]
    if len(pos) == 0:
        raise P1Error('dolgu-yapı')
    k = int(pos[-1]) + 1
    if not (np.all(T[k:] == 0) and np.all(V[:, k:] == 0)):          # NaN != 0 -> rejected
        raise P1Error('dolgu-yapı')
    pad = len(T) - k
    if (pad > PAD_MAX or capture_rows is None or len(T) != int(capture_rows)
            or not abs(float(T[0]) - (1 + pad) * DT) <= TOL_T):
        raise P1Error('dolgu-sınır')
    C = V[names.index('simulation_clock_s')][:k]
    Tk = T[:k]
    ok = (bool(np.all(np.abs(Tk - C) <= TOL_T)) and bool(np.all(np.abs(np.diff(Tk) - DT) <= TOL_T))
          and abs(float(Tk[-1]) - T_LAST) <= TOL_T)
    if not ok:
        raise P1Error('zaman-hiza')
    return k, pad


def load_capture_ra(d):
    """vh94_run.load_capture with P-1: same dict, every array cut to the valid prefix; '_pad' added."""
    import numpy as np
    z = np.load(io.BytesIO(_read_bytes(os.path.join(d, 'capture.npz'))))
    names = [str(n) for n in z['signal_names']]
    T, V = z['time_s'], z['values']
    st = json.loads(_read_bytes(os.path.join(d, 'run_status.json')).decode('utf-8'))
    k, pad = p1_trim(T, V, names, st.get('capture_rows'))
    vals = V[:, :k]
    cap = {n: vals[i] for i, n in enumerate(names)}
    cap['t'] = T[:k]
    cap['values'] = vals
    cap['y'] = np.hypot(cap['v2d_pm'], cap['v2q_pm'])
    cap['_pad'] = pad
    return cap


# ---------------------------------------------------------------- authorization (§10)
def verify_authorization_ra(run_id, yetki, campaign, out):
    import vh94_run as R
    bad, _ = R.check_pins()
    bad2, pin_list = check_ra_pins()
    if bad or bad2:
        return 'KAPI: pin ' + json.dumps(bad + bad2, ensure_ascii=False)
    try:
        y = json.loads(_read_bytes(yetki).decode('utf-8'))
    except Exception as exc:  # noqa: BLE001
        return 'KAPI: yetki okunamadı: %s' % exc
    want = dict(action='ALLOW_VH95RA_ANALYSIS', run_id=run_id, sabit_sha256=SABIT_SHA256, pin_list_sha256=pin_list)
    for k, v in want.items():
        if y.get(k) != v:
            return 'KAPI: yetki alanı %s' % k
    if (y.get('script_sha256') or {}).get('vh95ra_run.py') != sha(os.path.abspath(__file__)):
        return 'KAPI: yetki betik hash'
    for key, val in (('campaign_dir', campaign), ('out_dir', out)):
        if not val or os.path.normcase(os.path.abspath(val)) != os.path.normcase(os.path.abspath(y.get(key) or '')):
            return 'KAPI: %s yetkideki değer değil' % key
    if list(y.get('ortam') or []) != list(REAL_CFG['env']):
        return 'KAPI: yetki ortam'
    rep = y.get('code_audit_report') or {}
    if not rep.get('path') or not os.path.isfile(rep['path']) or sha(rep['path']) != rep.get('sha256'):
        return 'KAPI: kod denetimi raporu'
    return None


def out_dir_ok(out, campaign):
    """SABİT §9: the output directory must not exist and must not lie inside the campaign directory."""
    o = os.path.normcase(os.path.abspath(out))
    c = os.path.normcase(os.path.abspath(campaign))
    if os.path.exists(o):
        return 'KAPI: çıktı klasörü zaten var'
    try:
        inside = os.path.commonpath([o, c]) == c
    except ValueError:
        inside = False
    if inside:
        return 'KAPI: çıktı klasörü kampanya klasörünün içinde'
    return None


# ---------------------------------------------------------------- pass 0 (X-0, X-1, X-2)
def pass0(cfg, R, env):
    campaign = cfg['campaign']
    if (env['python'], env['numpy']) != tuple(cfg['env']):
        raise Abort('X-0', ['ortam %s/%s' % (env['python'], env['numpy'])])
    pf = preflight(campaign)
    if pf:
        raise Abort('X-0', ['kayıt biçimi: ' + s for s in pf])
    integrity = []
    if sha(R.__file__) != VH94_RUN_SHA256 or sha(os.path.join(os.path.dirname(R.__file__), 'analyze_vh94.py')) != ANALYZE_SHA256:
        integrity.append('pinli kod hash')
    bad, _ = R.check_pins()
    bad2, _ = check_ra_pins()
    if bad or bad2:
        integrity.append('pin uyuşmazlığı: %s' % json.dumps(bad + bad2, ensure_ascii=False))
    lp = os.path.join(campaign, 'campaign_ledger.jsonl')
    if sha(lp) != cfg['ledger_sha256']:
        integrity.append('ledger hash')
    ledger_txt = _read_bytes(lp).decode('utf-8-sig')
    ledger = [json.loads(l.lstrip('\ufeff')) for l in ledger_txt.splitlines() if l.strip()]
    guard, whea_stop = {}, False
    for e in ledger:                                   # same rules as vh94_run.analyze 170-178
        if e.get('op') == 'stop' and e.get('reason') == 'new_whea':
            whea_stop = True
        if e.get('op') in ('run', 'run_start'):
            if whea_stop:
                integrity.append('WHEA durdurmasından sonra koşu: %s %s' % (e.get('case'), e.get('scenario')))
            if e.get('scenario') not in SCENARIOS or e.get('case') not in CASES:
                integrity.append('protokol dışı senaryo: %s %s' % (e.get('case'), e.get('scenario')))
            guard[(e['case'], e['scenario'], e['step'])] = e.get('guard_ok') is True
    rd = os.path.join(campaign, 'runs')
    failed_dirs = sorted(n for n in os.listdir(rd) if '_basarisiz_' in n) if os.path.isdir(rd) else []
    for n in failed_dirs:
        if os.path.isfile(os.path.join(rd, n, 'capture.npz')):
            integrity.append('kayıtlı koşu yinelenmiş: %s' % n)
    _, names = run_dirs(campaign)
    for n in names:
        sp, cp = os.path.join(rd, n, 'run_status.json'), os.path.join(rd, n, 'capture.npz')
        if os.path.isfile(sp) and os.path.isfile(cp):
            st = json.loads(_read_bytes(sp).decode('utf-8'))
            if st.get('capture_npz_sha256') != sha(cp):
                integrity.append('kayıt hash uyuşmazlığı: %s' % n)
    if integrity:
        raise Abort('X-1', integrity)
    x2 = []
    if list_sha(campaign, 'capture.npz')[0] != cfg['capture_list_sha256']:
        x2.append('capture.npz liste hash')
    if list_sha(campaign, 'run_status.json')[0] != cfg['run_status_list_sha256']:
        x2.append('run_status.json liste hash')
    ref = cfg['ref_dir']
    if sha(os.path.join(ref, 'SHA256SUMS')) != cfg['ref_sums_sha256']:
        x2.append('VH95 SHA256SUMS hash')
    else:
        for line in _read_bytes(os.path.join(ref, 'SHA256SUMS')).decode('utf-8').splitlines():
            if not line.strip():
                continue
            h, n = line.split('  ', 1)
            if not os.path.isfile(os.path.join(ref, n)) or sha(os.path.join(ref, n)) != h:
                x2.append('VH95 SHA256SUMS satırı: %s' % n)
    if sha(os.path.join(ref, 'sonuc.json')) != cfg['ref_sonuc_sha256']:
        x2.append('VH95 sonuc.json hash')
    if x2:
        raise Abort('X-2', x2)
    return guard, failed_dirs


# ---------------------------------------------------------------- X-3, X-4 (§5.2)
def _passed_in_ref(rref):
    ne = rref.get('ne')
    return not (isinstance(ne, str) and ne.startswith('kapı:'))      # M-3


def x3_check(ref, runs, pads, case_est, A):
    """Reproduction on pad = 0 runs; returns list of mismatches (empty = pass). No values are returned."""
    bad = []
    ref_passed = {(c, k) for c, rc in ref['cases'].items() for k, rr in (rc.get('runs') or {}).items()
                  if _passed_in_ref(rr)}
    pad0 = {ck for ck, p in pads.items() if p == 0}
    if pad0 != ref_passed:
        bad.append('pad=0 kümesi VH95 geçen kümesine eşit değil')
    for ck in sorted(pad0 & ref_passed):
        mine = {k: v for k, v in runs[ck].items() if k not in ('pad', 'p1')}
        if canon(mine) != canon(ref['cases'][ck[0]]['runs'][ck[1]]):
            bad.append('run sözlüğü: %s %s' % ck)
    for cid, (lab, D, uD, thr) in case_est.items():
        rc = ref['cases'][cid]
        if canon(dict(label=lab, D=D, u_D=uD, threshold=thr)) != canon(
                dict(label=rc.get('label'), D=rc.get('D'), u_D=rc.get('u_D'), threshold=rc.get('threshold'))):
            bad.append('vaka: %s' % cid)
    return bad


def _x4_view(r):
    g = {k: v for k, v in (r.get('gates') or {}).items() if k not in ('dc', 'energy')}
    ph = r.get('physics') or {}
    return dict(gates=g, t_b=ph.get('t_b'), peak_modulation_to_tb=ph.get('peak_modulation_to_tb'))


def x4_check(ref, runs, pads):
    bad = []
    for ck, p in sorted(pads.items()):
        if p is None or p == 0:
            continue
        rr = ref['cases'][ck[0]]['runs'].get(ck[1]) or {}
        if canon(_x4_view(runs[ck])) != canon(_x4_view(rr)):
            bad.append('dolgulu yol: %s %s' % ck)
    return bad


# ---------------------------------------------------------------- analysis (§5, §8; passes 0 / 1 / 2)
def _estimate(A, counter, pad, *args, **kw):
    if pad:
        counter.padded += 1
    else:
        counter.unpadded += 1
    return A.estimate_run(*args, **kw)


def analyze_ra(cfg, counter, log):
    import vh94_run as R
    import analyze_vh94 as A
    R.load_capture = load_capture_ra                      # VH95RA-B1-a: the only attribute assignment
    env = environment()
    guard, failed_dirs = pass0(cfg, R, env)
    log.append('X-0 X-1 X-2 geçti')
    campaign = cfg['campaign']
    ref = json.loads(_read_bytes(os.path.join(cfg['ref_dir'], 'sonuc.json')).decode('utf-8'))
    plan = json.loads(_read_bytes(R.PILOT).decode('utf-8'))
    pc = {c['id']: c for c in plan['cases']}
    rd = os.path.join(campaign, 'runs')
    runs, pads, wins, caps_ok, dolgu = {}, {}, {}, {}, {}
    # pass 1: P-1, window, gates; estimator only on pad = 0 runs
    for cid in CASES:
        case = pc[cid]
        if case.get('status') != 'ok':
            continue
        for scen, step in A.RUNS:
            key = '%s@%s' % (scen, step)
            ck = (cid, key)
            d = os.path.join(rd, '%s_%s_%sus' % (cid, scen, step))
            if not (os.path.isfile(os.path.join(d, 'run_status.json')) and os.path.isfile(os.path.join(d, 'capture.npz'))):
                runs[ck] = dict(ne='kayıt yok', pad=None, p1=None)
                pads[ck] = None
                continue
            st = json.loads(_read_bytes(os.path.join(d, 'run_status.json')).decode('utf-8'))
            try:
                cap = load_capture_ra(d)
            except P1Error as exc:
                runs[ck] = dict(ne='p1:%s' % exc.args[0], pad=None, p1=exc.args[0])      # F-2
                pads[ck] = None
                dolgu['%s %s' % ck] = dict(pad=None, p1=exc.args[0])
                continue
            pad = cap['_pad']
            pads[ck] = pad
            dolgu['%s %s' % ck] = dict(pad=pad, t0=float(cap['t'][0]), p1='geçer')
            sig_p, f_p, sig_r = A.pred_of(case, scen)
            win = A.window_end(cap['t'], cap['y'], sig_p)
            ok, gates, phys = A.run_gates(st, cap, guard.get((cid, scen, step), False), win[0])
            ih = R.input_hash_ok(st, cid)
            gates['input_hash'] = ih
            ok = ok and ih
            r = dict(gates=gates, physics=phys, capture_npz_sha256=st.get('capture_npz_sha256'))
            if not ok:
                r['ne'] = 'kapı:' + ','.join(k for k, v in gates.items() if not v)
            elif pad == 0:
                r.update(_estimate(A, counter, 0, cap['t'], cap['y'], sig_p, f_p, sig_r, window=win))
                if r.get('ne') is None:
                    r['vdc_report'] = _estimate(A, counter, 0, cap['t'], cap['vdc_pm'], sig_p, f_p, sig_r)
            r.update(pad=pad, p1='geçer')                                                   # F-5
            runs[ck] = r
            wins[ck] = (win, sig_p, f_p, sig_r)
            caps_ok[ck] = ok
    # X-3: cases whose four runs are all pad = 0 (A2-F00993 in VH95) are judged now
    case_est = {}
    for cid in CASES:
        keys = [(cid, '%s@%s' % rs) for rs in A.RUNS]
        if all(pads.get(k) == 0 for k in keys):
            e = {k[1]: runs[k] for k in keys}
            case_est[cid] = A.case_verdict(pc[cid]['sign_pred_D'], e.get('F_m@0p025'), e.get('R_m@0p025'),
                                           e.get('F_m@0p05'), e.get('R_m@0p05'))
    x3 = x3_check(ref, runs, pads, case_est, A)
    if x3:
        raise Abort('X-3', x3)
    log.append('X-3 geçti (%d dolgusuz koşu)' % sum(1 for p in pads.values() if p == 0))
    x4 = x4_check(ref, runs, pads)
    if x4:
        raise Abort('X-4', x4)
    log.append('X-4 geçti (%d dolgulu koşu)' % sum(1 for p in pads.values() if p))
    # pass 2: estimator on padded runs, then cases and campaign
    for ck in sorted(k for k, p in pads.items() if p):
        if not caps_ok[ck]:
            continue
        cid, key = ck
        scen, step = key.split('@')
        cap = load_capture_ra(os.path.join(rd, '%s_%s_%sus' % (cid, scen, step)))
        win, sig_p, f_p, sig_r = wins[ck]
        r = runs[ck]
        r.update(_estimate(A, counter, cap['_pad'], cap['t'], cap['y'], sig_p, f_p, sig_r, window=win))
        if r.get('ne') is None:
            r['vdc_report'] = _estimate(A, counter, cap['_pad'], cap['t'], cap['vdc_pm'], sig_p, f_p, sig_r)
    res = dict(run_id=None, plan_sha256=sha(R.PILOT), cases={}, failed_attempt_dirs=failed_dirs)
    labels, signs = {}, {}
    for cid in CASES:
        case = pc[cid]
        rec = dict(s_pred=case.get('sign_pred_D'), pilot_status=case.get('status'), runs={})
        signs[cid] = case.get('sign_pred_D') or 0
        if case.get('status') != 'ok':
            labels[cid] = 'NE'
            rec.update(label='NE', ne_reason='pilot')
            res['cases'][cid] = rec
            continue
        est = {}
        for scen, step in A.RUNS:
            key = '%s@%s' % (scen, step)
            rec['runs'][key] = runs[(cid, key)]
            est[key] = None if pads.get((cid, key)) is None else runs[(cid, key)]
        lab, D, uD, thr = A.case_verdict(case['sign_pred_D'], est.get('F_m@0p025'), est.get('R_m@0p025'),
                                         est.get('F_m@0p05'), est.get('R_m@0p05'))
        rep = R.report_items(A, case, est)
        rep['R5'] = dict(D_pred_rotate_true=(case.get('rotate_alt') or {}).get('D_pred_at_m'),
                         pred_no_delay_m=(case.get('pred_nd') or {}).get('m'))
        rep['R6'] = ('Codex v3 F2-0.65-0.20 rampası (0.0691 pu) sönmemişti; bu kalem yalnız VH94 R_m/R_lo ile '
                     'karşılaştırma notudur.') if cid == 'F2-0.65-0.20' else None
        try:
            rep['R7'] = R.latch_settling(rd, cid)
        except Exception as exc:  # noqa: BLE001
            rep['R7'] = dict(error='%s: %s' % (type(exc).__name__, exc))
        rec.update(label=lab, D=D, u_D=uD, threshold=thr, D_pred_d=case.get('D_pred_d'), report=rep)
        labels[cid] = lab
        res['cases'][cid] = rec
    row, verdict = A.campaign_verdict(labels, signs, True)
    res.update(labels=labels, decision_row=row, verdict=verdict, integrity_errors=[])
    karsi = dict(X3='geçti', X4='geçti', kestirici_dolgulu_cagri=counter.padded,
                 kestirici_dolgusuz_cagri=counter.unpadded,
                 RA2={cid: dict(VH95=ref['labels'].get(cid), VH95RA=labels[cid]) for cid in CASES})
    return res, dolgu, karsi, env


# ---------------------------------------------------------------- output (§9)
def write_outputs_ra(out, res, dolgu, karsi, env, log, code):
    os.makedirs(out, exist_ok=True)
    _write_text(os.path.join(out, 'sonuc.json'), json.dumps(res, indent=1, ensure_ascii=False, default=float))
    v = res.get('verdict', 'ABORT')
    lines = ['VH95-RA hüküm: %s (satır %s) [keşif niteliğinde]' % (v, res.get('decision_row'))]
    lines += ['%s: %s' % (c, l) for c, l in (res.get('labels') or {}).items()]
    _write_text(os.path.join(out, 'hukum.txt'), '\n'.join(lines) + '\n')
    _write_text(os.path.join(out, 'ra_dolgu.json'), json.dumps(dolgu, indent=1, ensure_ascii=False, default=float))
    _write_text(os.path.join(out, 'ra_karsilastirma.json'), json.dumps(karsi, indent=1, ensure_ascii=False, default=float))
    import vh94_run as R
    _write_text(os.path.join(out, 'girdi_pinleri.json'), json.dumps(
        dict(ra_pins=RA_PINS, vh94_pins=R.PINS, sabit=[SABIT_PATH, SABIT_SHA256], ortam=env),
        indent=1, ensure_ascii=False, default=str))
    _write_text(os.path.join(out, 'stdout.txt'), '\n'.join(log) + '\n')
    _write_text(os.path.join(out, 'stderr.txt'), res.get('hata', ''))
    _write_text(os.path.join(out, 'exit_code.txt'), str(code))
    sums = []
    for n in sorted(os.listdir(out)):
        p = os.path.join(out, n)
        if os.path.isfile(p) and n != 'SHA256SUMS':
            sums.append('%s  %s' % (sha(p), n))
    _write_text(os.path.join(out, 'SHA256SUMS'), '\n'.join(sums) + '\n')


def run_analysis(cfg, run_id, out):
    """Full --analyze body without the authorization gate (used by main and by the synthetic test)."""
    counter, log, env = Counter(), [], {}
    try:
        res, dolgu, karsi, env = analyze_ra(cfg, counter, log)
        res['run_id'] = run_id
        code = 0
    except Abort as ab:
        res = dict(run_id=run_id, verdict='ABORT', decision_row=1, abort=ab.args[0], abort_detay=ab.args[1])
        dolgu = {}
        karsi = dict(abort=ab.args[0], kestirici_dolgulu_cagri=counter.padded,
                     kestirici_dolgusuz_cagri=counter.unpadded)        # M-7: flags only, no blinded values
        code = 4
    except Exception as exc:  # noqa: BLE001                         # VH95RA-B1-g
        import traceback
        res = dict(run_id=run_id, verdict='ABORT', decision_row=1, abort='HATA', hata=traceback.format_exc())
        dolgu = {}
        karsi = dict(abort='HATA', kestirici_dolgulu_cagri=counter.padded,
                     kestirici_dolgusuz_cagri=counter.unpadded)
        log.append('HATA %s' % exc)
        code = 1
    log.append('kestirici çağrısı: dolgusuz %d, dolgulu %d' % (counter.unpadded, counter.padded))
    log.append('verdict %s row %s' % (res['verdict'], res['decision_row']))
    if not env:
        try:
            env = environment()
        except Exception as exc:  # noqa: BLE001
            env = dict(hata=str(exc))
    write_outputs_ra(out, res, dolgu, karsi, env, log, code)
    return res, counter, code


def main():
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument('--check-only', action='store_true')
    g.add_argument('--verify', action='store_true')
    g.add_argument('--analyze', action='store_true')
    ap.add_argument('--run-id')
    ap.add_argument('--yetki')
    ap.add_argument('--campaign')
    ap.add_argument('--out')
    a = ap.parse_args()
    sys.path.insert(0, HERE)
    if a.check_only:
        import vh94_run as R
        bad, _ = R.check_pins()
        bad2, pin_list = check_ra_pins()
        print(json.dumps(dict(pin_failures=bad + bad2, pin_list_sha256=pin_list, ortam=environment()),
                         ensure_ascii=False, default=str))
        return 0 if not (bad or bad2) else 1
    if not a.run_id or not a.yetki or not a.campaign or not a.out:
        print('KAPI: --run-id, --yetki, --campaign ve --out gerekli')
        return 2
    if os.path.normcase(os.path.abspath(a.campaign)) != os.path.normcase(os.path.abspath(REAL_CFG['campaign'])):
        print('KAPI: kampanya klasörü SABİT §4 değil')
        return 2
    why = verify_authorization_ra(a.run_id, a.yetki, a.campaign, a.out) or out_dir_ok(a.out, a.campaign)
    if why:
        print(why)
        return 2
    if a.verify:
        print('yetki doğrulandı: %s' % a.run_id)
        return 0
    res, counter, code = run_analysis(REAL_CFG, a.run_id, a.out)
    print('verdict %s row %s; kestirici dolgulu %d' % (res['verdict'], res['decision_row'], counter.padded))
    return code


if __name__ == '__main__':
    sys.exit(main())
