"""E2P statik denetim (AST), v3 (B3v2-5: S10 geniş except ve compute_C kurulumu, S11 from-import, S12 eklendi). Çıkış 0 = GEÇTİ, 1 = KALDI.
Kullanım: python -I -B e2p_static_check.py"""
import ast
import hashlib
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
RUN = os.path.join(HERE, 'e2p_run.py')
SABIT = os.path.join(os.path.dirname(HERE), 'protokol', 'E2P_On_Kayit_v1.1_SABIT.md')
ROOT = r'C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence'

TOP_OK = {'argparse', 'hashlib', 'json', 'math', 'os', 'sys', 'time', 'numpy'}
ENGINE = {'ext_common', 'ext_engine', 'y_common', 'y2_newton'}
LOCAL_OK = {'traceback'}
FORBID_MOD = {'subprocess', 'scipy', 'pathlib', 'ctypes', 'importlib', 'pickle', 'shutil', 'socket'}
FORBID_CALL = {'eval', 'exec', 'compile', '__import__', 'setattr', 'delattr'}
IO_HELPERS = {'_read_bytes', '_write_text', '_write_bytes'}
FORBID_STR = ('newton.jsonl', 'stage2.jsonl', 'dGref_exact', 'scipy')


def sha(p):
    with open(p, 'rb') as f:
        return hashlib.sha256(f.read()).hexdigest()


def main():
    src = open(RUN, encoding='utf-8').read()
    tree = ast.parse(src)
    res = []
    parents = {}
    for node in ast.walk(tree):
        for ch in ast.iter_child_nodes(node):
            parents[ch] = node

    def enclosing_fn(n):
        while n in parents:
            n = parents[n]
            if isinstance(n, ast.FunctionDef):
                return n.name
        return None

    # S1 importlar
    bad = []
    for n in ast.walk(tree):
        if isinstance(n, (ast.Import, ast.ImportFrom)):
            names = [a.name.split('.')[0] for a in n.names] if isinstance(n, ast.Import) else [n.module.split('.')[0]]
            fn = enclosing_fn(n)
            for m in names:
                if m in FORBID_MOD:
                    bad.append('yasak modül %s (satır %d)' % (m, n.lineno))
                elif fn is None and m not in TOP_OK:
                    bad.append('üst düzey izinsiz import %s (satır %d)' % (m, n.lineno))
                elif fn is not None and m in ENGINE and fn != '_load_engine':
                    bad.append('motor importu _load_engine dışında %s (satır %d)' % (m, n.lineno))
                elif fn is not None and m not in ENGINE and m not in LOCAL_OK:
                    bad.append('yerel izinsiz import %s (satır %d)' % (m, n.lineno))
    res.append(('S1 import izin listesi', not bad, bad))

    # S2 yasak çağrılar
    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in FORBID_CALL:
            bad.append('%s (satır %d)' % (n.func.id, n.lineno))
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and (
                n.func.attr in ('system', 'popen', 'Popen', 'startfile') or n.func.attr.startswith(('exec', 'spawn'))):
            bad.append('%s (satır %d)' % (n.func.attr, n.lineno))
    res.append(('S2 yasak çağrılar', not bad, bad))

    # S3 open yalnız G/Ç yardımcılarında
    bad = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'open':
            if enclosing_fn(n) not in IO_HELPERS:
                bad.append('open %s içinde (satır %d)' % (enclosing_fn(n), n.lineno))
    res.append(('S3 open yalnız yardımcılarda', not bad, bad))

    # S4 PINS ile SABİT §4 tablosu ve disk hash'leri
    bad = []
    ns = {}
    for n in tree.body:
        if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name):
            if n.targets[0].id in ('ROOT', 'POINTS_PIN', 'SELECTION_PIN', 'PINS', 'SABIT_PATH', 'SABIT_SHA'):
                ns[n.targets[0].id] = n
    code_ns = {}
    for k in ('ROOT', 'POINTS_PIN', 'SELECTION_PIN', 'PINS', 'SABIT_PATH', 'SABIT_SHA'):
        code_ns[k] = _literal(ns[k].value, code_ns)   # yalnız sabit, isim ve + birleştirme
    pins = code_ns['PINS']
    sab = open(SABIT, encoding='utf-8').read()
    tab = re.findall(r'^\| `…(\\[^`]+)`[^|]*\| ([0-9—]+) \| ([0-9a-f]{64}) \|', sab, re.M)
    tab_set = {(ROOT + p, h) for p, _, h in tab}
    pin_set = {(p, h) for p, _, h in pins}
    if tab_set != pin_set:
        bad.append('PINS ≠ SABİT §4: fazla=%s eksik=%s' % (pin_set - tab_set, tab_set - pin_set))
    for p, nb, h in pins:
        if not os.path.exists(p):
            bad.append('dosya yok ' + p)
            continue
        if os.path.getsize(p) != nb or sha(p) != h:
            bad.append('disk uyuşmazlığı ' + p)
    res.append(('S4 PINS = SABİT §4 ve disk', not bad, bad))

    # S5 yasak dosya adları ya da dizgiler
    bad = [s for s in FORBID_STR if s in src]
    res.append(('S5 yasak dizgiler', not bad, bad))

    # S6 yetki doğrulaması motor yüklemesinden önce; _load_engine yalnız main'de
    bad = []
    calls = {}
    for n in ast.walk(tree):
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in ('verify_authorization',
                                                                                   '_load_engine', 'env_gate',
                                                                                   'check_pins'):
            calls.setdefault(n.func.id, []).append((n.lineno, enclosing_fn(n)))
    le = calls.get('_load_engine', [])
    va = calls.get('verify_authorization', [])
    if not le or any(f != 'main' for _, f in le):
        bad.append('_load_engine main dışında ya da yok')
    if not va or not le or min(l for l, _ in va) > min(l for l, _ in le):
        bad.append('verify_authorization _load_engine sonrasında')
    eg = calls.get('env_gate', [])
    if not eg or min(l for l, _ in eg) > min(l for l, _ in le):
        bad.append('env_gate _load_engine sonrasında')
    res.append(('S6 yetki ve kapı sırası', not bad, bad))

    # S7 motor modüllerine atama (yama) yok
    bad = []
    for n in ast.walk(tree):
        tg = []
        if isinstance(n, ast.Assign):
            tg = n.targets
        elif isinstance(n, (ast.AugAssign, ast.AnnAssign)):
            tg = [n.target]
        for t in tg:
            if isinstance(t, ast.Attribute) and isinstance(t.value, ast.Name) and t.value.id in ('C', 'E', 'U', 'Y'):
                bad.append('modül ataması %s.%s (satır %d)' % (t.value.id, t.attr, n.lineno))
            if (isinstance(t, ast.Attribute) and isinstance(t.value, ast.Attribute) and isinstance(t.value.value, ast.Name)
                    and t.value.value.id == 'self' and t.value.attr in ('C', 'E', 'U', 'Y')):
                bad.append('modül ataması self.%s.%s (satır %d)' % (t.value.attr, t.attr, n.lineno))
            if isinstance(t, ast.Subscript):
                base = t.value
                while isinstance(base, (ast.Attribute, ast.Subscript)):
                    if isinstance(base, ast.Attribute) and base.attr in ('__dict__', 'modules'):
                        bad.append('alt simge ataması %s (satır %d)' % (base.attr, n.lineno))
                    base = base.value
    res.append(('S7 motor modülü yaması yok', not bad, bad))

    # S8 SABİT hash sabiti
    ok8 = code_ns['SABIT_PATH'].endswith('E2P_On_Kayit_v1.1_SABIT.md') and sha(code_ns['SABIT_PATH']) == code_ns['SABIT_SHA']
    res.append(('S8 SABİT yolu ve hash', ok8, [] if ok8 else ['SABİT hash/yol']))

    # S9 kip kapıları: parse içinde iki kip birlikte ve kipsiz reddi
    pf = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'parse']
    seg = ast.get_source_segment(src, pf[0]) if pf else ''
    ok9 = 'check_only and (a.run_id or a.yetki or a.devam)' in seg and 'not (a.run_id and a.yetki)' in seg
    res.append(('S9 kip kapıları', ok9, [] if ok9 else ['parse kapıları']))

    # S10 Eng.compute_* gövdeleri en dışta try içerir (compute_C: kurulum ve ayrışım iki try)
    bad = []
    eng = [n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'Eng']
    meths = {m.name: m for m in eng[0].body if isinstance(m, ast.FunctionDef)} if eng else {}
    def broad(tr):
        return any(h.type is None or (isinstance(h.type, ast.Name) and h.type.id in ('Exception', 'BaseException'))
                   for h in tr.handlers)
    for nm in ('compute_A', 'compute_B'):
        body = meths.get(nm).body if nm in meths else []
        body = [s for s in body if not isinstance(s, ast.Expr)]
        if not (len(body) == 2 and isinstance(body[1], ast.Try) and broad(body[1])):
            bad.append(nm + ' en dışta geniş try değil')
    cbody = meths['compute_C'].body if 'compute_C' in meths else []
    tries = [s for s in cbody if isinstance(s, ast.Try)]
    if len(tries) < 2 or not all(broad(x) for x in tries):
        bad.append('compute_C iki geniş try içermiyor')
    for s in cbody:     # try dışında motor/kurulum çağrısı yok
        if not isinstance(s, ast.Try):
            for n2 in ast.walk(s):
                if (isinstance(n2, ast.Call) and isinstance(n2.func, ast.Attribute) and isinstance(n2.func.value, ast.Name)
                        and n2.func.value.id == 'self' and n2.func.attr in ('setup_point', 'entry_checks', '_decompose')):
                    bad.append('compute_C: %s try dışında (satır %d)' % (n2.func.attr, n2.lineno))
    res.append(('S10 compute_* istisna yerelliği', not bad, bad))

    # S11 OPENBLAS/MKL ataması numpy importundan önce
    ln_np = min([n.lineno for n in ast.walk(tree) if isinstance(n, ast.Import) and any(a.name == 'numpy' for a in n.names)]
                + [n.lineno for n in ast.walk(tree) if isinstance(n, ast.ImportFrom) and n.module == 'numpy'],
                default=10 ** 9)
    ln_env = [n.lineno for n in tree.body if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Subscript)
              and 'NUM_THREADS' in ast.get_source_segment(src, n.targets[0])]
    ok11 = len(ln_env) == 2 and max(ln_env) < ln_np
    res.append(('S11 iş parçacığı ortamı numpy öncesinde', ok11, [] if ok11 else ['OPENBLAS/MKL sırası']))

    # S12 main'de check_engine_paths, prepare_dir'den önce (Kapi klasör açılmadan)
    mf = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main']
    lc = {}
    for n2 in ast.walk(mf[0]) if mf else []:
        if isinstance(n2, ast.Call) and isinstance(n2.func, ast.Name) and n2.func.id in ('check_engine_paths', 'prepare_dir'):
            lc.setdefault(n2.func.id, []).append(n2.lineno)
    ok12 = bool(lc.get('check_engine_paths')) and bool(lc.get('prepare_dir')) and \
        max(lc['check_engine_paths']) < min(lc['prepare_dir'])
    res.append(('S12 motor yolu kapısı klasörden önce', ok12, [] if ok12 else ['sıra']))

    allok = True
    for name, ok, det in res:
        allok &= ok
        sys.stdout.buffer.write(('%s: %s %s\n' % (name, 'GEÇTİ' if ok else 'KALDI', '' if ok else det)).encode('utf-8'))
    sys.stdout.buffer.write(('e2p_run.py sha256 %s\nSONUÇ: %s\n' % (sha(RUN), 'GEÇTİ' if allok else 'KALDI')).encode('utf-8'))
    return 0 if allok else 1


def _literal(node, env):
    """Yalnız sabitler, isimler (env'den), + birleştirme, liste/demet ve ** üstü."""
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.Name):
        return env[node.id]
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        return _literal(node.left, env) + _literal(node.right, env)
    if isinstance(node, (ast.List, ast.Tuple)):
        v = [_literal(e, env) for e in node.elts]
        return v if isinstance(node, ast.List) else tuple(v)
    raise ValueError('literal değil: %s' % ast.dump(node)[:80])


if __name__ == '__main__':
    sys.exit(main())
