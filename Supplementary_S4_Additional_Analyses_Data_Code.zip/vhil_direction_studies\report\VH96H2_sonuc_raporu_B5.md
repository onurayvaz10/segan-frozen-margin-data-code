# VH96 H2 B5 sonuç raporu (2026-11-07)

## 1. Mühür (VERIFIED)
- Kampanya: `C:\Users\onura\Documents\SEGAN_G94_work\vh94\out\VH96H2_20261107_a`.
- Analiz klasörü: `…\analysis_VH96H2_20261107_a`.
  - SHA256SUMS sha256: e32242c02a595c5defa816019e2364f04bed408fa3cb3119cea3f393eef42527. Yedi kalem yeniden hesaplandı, hepsi eşleşti.
  - sonuc.json sha256: 2e3efacf07f0adeb64be3d7770f9573909041c911520bc3dc68a0705882123ff.
  - `integrity_errors` boş. Kestirici çağrısı 18.
- B4 koşu kaydı: `rapor/VH96H2_B4_kosu_kaydi.md`. Kampanya bir kez koşuldu, analiz bir kez yapıldı. Yetki: bdc1bad3…66eb.

## 2. Hüküm (SABİT v1.1 §8.2, harfiyen)
`VH96 H2 hüküm: NOT_EVALUABLE (satır 2)`. Hiçbir vaka değerlendirilebilir değildi (0 < 4).

**Statü:** "Yeni bilgi yoktur." H2 hakkında ön-kayıtlı bir hüküm yoktur.

**H1:** GÜÇ_YETERSİZ (D-279; `rapor/VH96_H1_dal_kapanisi.md`).

## 3. Vaka başına neden (VERIFIED: ledger, guard_logs, sonuc.json)

| Vaka | Sınıf, k | Kayıtlı koşular | NE nedeni |
|---|---|---|---|
| A2-F01557 | iyimser, 0.10 | R_lo, R_hi @ 50 ns | 25 ns koşuları yok. Kampanya 19:49:20'de yeni bir **WHEA** olayıyla durdu (System, WHEA-Logger, Id 2, "düzeltilen donanım hatası"); 25 ns derlemesi WHEA bekçisince kesildi. |
| A2-F00805 | iyimser, 0.20 | R_lo, R_hi @ 25 ns | 50 ns derlemesi "compile=True" yazdı, ama `.cpd` dosyası oluşmadı. Zamanlama denetimi FileNotFoundError ile düştü (`case_build_failed`). VH94 R3-9 gereği adım NE. |
| A2-F01169 | iyimser, 0.10 | R_lo, R_hi @ 25 ns | Aynı: 50 ns `.cpd` yok. |
| A2-F00555 | tutucu, 0.20 | 4/4 | R_hi: KARARSIZ (σ̂₂₅ 8.215; thr 1.53). R_lo: iki adımda da q3 (A₀ < 10·n₀). M3-8 kuralı 1 gereği vaka NE. |
| A2-03094, A2-F01579 | tutucu | — | GÜÇSÜZ (tasarım adımı). |

**Modülasyon payı (rapor kalemi, VERIFIED):** Kaydedilen 10 koşunun tepe modülasyonu 0.76–0.87'dir. Modülasyon kapısı hiçbir koşuyu düşürmedi. Dolgu yoktu (pad 0). §5.5'teki değişiklik amacına ulaştı.

## 4. Ön-kayıtlı olmayan gözlemler (post-hoc; hüküm dışı, yalnız rapor)
- **G-1.** Kaydedilen 10 koşunun hepsinde σ̂'nin işareti öngörüyle aynıdır. Bunlara q3'ten düşen F00555 R_lo da dahildir.

  | Taraf | σ̂ (s⁻¹) |
  |---|---|
  | R_lo (sınırın içi) | −2.8 (F01557, 50 ns), −9.9, −12.6, −1.7, −7.6 |
  | R_hi (sınırın dışı) | +12.1, +9.8, +12.4, +8.2, +8.7 |

  R_hi koşularında σ̂/σ_pred oranı 0.99–1.16 aralığındadır.
- **G-1 neden hüküm değildir.** u_run iki adım gerektirir. Üç iyimser vakada yalnız bir adım vardır; F00555'te ise R_lo koşuları q3'ü geçmedi. Bu gözlem keşif niteliğindedir ve H2 için kanıt sayılmaz.
- **G-2.** Sınırın içindeki koşularda (σ < 0) kip hızla söndüğü için uydurma kalitesi düşük kalıyor. R² 0.59–0.76'dır; R_hi'de ise 0.998–0.999'dur. F00555 R_lo'da genlik gürültü tabanının 10 katına ulaşmadı (q3).
  - INFERENCE: Darbe genliği H1'in R_m çalışma noktasına göre seçilmişti (VH94 v1.3 §5.1). Kararlı taraftaki ölçüm bu yüzden yapısal olarak zayıf kalıyor.
  - Bu, ardıl bir tasarımın ele alması gereken bir yöntem bulgusudur.
- **G-3.** 50 ns `.cpd` eksikliği iki vakada, her vakanın ilk 50 ns derlemesinde görüldü. Aynı adım F00555 ve F01557'de çalıştı. Neden bilinmiyor (UNVERIFIED): geçici bir derleyici ya da dosya sistemi sorunu olabilir.
- **G-4. Donanım.** Bakım ve BIOS onayından sonra (2026-11-06) WHEA düzeltilmiş hata olayı yeniden görüldü (19:49:20). VH95'te 24 koşu WHEA'sız geçmişti; bu olay donanım sorununun tamamen giderilmediğini gösteriyor (INFERENCE). Ayrıntılı tanı için bkz. VH95 planı §3.

## 5. Kanıt düzeyi
H2 için E4 düzeyinde ön-kayıtlı kanıt yoktur. Post-hoc G-1 keşif niteliğindedir ve makalede yalnız böyle anılabilir.

## 6. Yeniden deneme
SABİT §9.3'e göre WHEA durdurmasından sonra yeniden kampanya yoktur. Analiz ABORT olmadığı için analiz yeniden denemesi de söz konusu değildir.

## 7. N-3 ve N-15 için sonuç ve seçenekler (kullanıcı kararı)
N-15'in istediği temiz doğrulama ön-kayıtlı olarak elde edilemedi. Seçenekler:
- **(a)** Makalede dürüst raporlama: VH96 H2 NOT_EVALUABLE. Nedenleri: WHEA, derleme, kararlı tarafta q3. Post-hoc G-1 keşif bulgusu olarak verilir (10/10 işaret uyumu, sayılarıyla). Modülasyon payının çalıştığı yazılır. N-15 kısmen karşılanmış olur.
- **(b)** Ardıl ön-kayıt (VH97 H2), VH96 adını taşımadan. Önerilen değişiklikler: kararlı taraf için ayrı darbe genliği kuralı (G-2), derleme sonrası `.cpd` denetimi ve bir kez yeniden derleme kuralı (G-3), yalnız H2 vakaları. **Önkoşul:** donanımın WHEA'sız olduğunun yeniden gösterilmesi (G-4), ya da başka bir makine.
- **(c)** (a) şimdi, (b) donanım düzeldikten sonra.

PROCEED: kullanıcı kararı.
