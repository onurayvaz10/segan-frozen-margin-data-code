"""VH94 single-run gate script (tek-koşu kapısı B1). SABİT: VH94_On_Kayit_v1.0_SABIT.md (SABIT_PATH / SABIT_SHA256).
v1.0 changes (D3 code notes): campaign directory bound to the authorization (G-4, §12 R3-10); input-hash gate per run
(G-3, §5.6); report items R-5, R-6, R-7 (G-5).

SABİT § -> function
  §4 pins ........................ PINS, check_pins
  §10 authorization .............. verify_authorization (before any analysis import or capture read)
  §5.6 run gates ................. analyze_vh94.run_gates
  §5.4-§5.8 estimator ............ analyze_vh94.estimate_run / fit_mode / window_end / noise_floor
  §6 H1 per case ................. analyze_vh94.case_verdict
  §8 decision table .............. analyze_vh94.campaign_verdict
  §6 R-1...R-5 report only ....... report_items
Author choices (VH94-B1-a ...):
  VH94-B1-a  Typhoon runs are executed by run_campaign_vh94.ps1 (Typhoon bundled Python); this script never starts
             a process. The campaign script first calls this script with --verify (authorization) and refuses
             otherwise. --analyze verifies the authorization again, then reads the campaign records.
  VH94-B1-b  All file reading/writing goes through _read_bytes / _write_text; captures are loaded with
             numpy.load(io.BytesIO(_read_bytes(path))).
  VH94-B1-c  A run directory that the campaign renamed to *_basarisiz_* (no capture after a guard stop or crash) is
             listed in sonuc.json and never analysed; only the canonical directory name counts.
  VH94-B1-d  Integrity errors (§8 row 1): pin mismatch at analysis time, a capture whose sha256 differs from its
             run_status.json, a scenario outside §5.3, or a run attempted after a 'new_whea' stop in the ledger.
Modes: --check-only | --verify --run-id ID --yetki P | --analyze --run-id ID --yetki P --campaign DIR
"""
import argparse
import hashlib
import io
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
WK = os.path.dirname(HERE)
G94 = r'C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme94_20261029'
SABIT_PATH = os.path.join(G94, 'protokol', 'VH94_On_Kayit_v1.3_SABIT.md')
SABIT_SHA256 = 'ae8628bd9f05aeafb0a95f0b6d001fe64efe90c53cef2001facc26d1856b999d'
PILOT = os.path.join(WK, 'vh94_pilot', 'vh94_pilot.json')
PINS = [
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme94_20261029\\G94_PLAN_v1.md', 8873, '832fc51325eea48168fc117c48e76107c5f8a9bc04ebbeeeb7cc753926836e77'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme94_20261029\\kod\\vh94_pilot.py', 12128, '68b80156bd7c9e3d26f559b6e4fe230d3082e2f129f6b48e051de7eb698dc3f6'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme94_20261029\\kod\\archive\\vh94_pilot_v2_66c267c1.py', 9455, '66c267c14e5e5c037c40ad20d8dda83faad5170152d9ac83712ddaae0a86c4f3'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94_pilot\\vh94_pilot.json', 37235, '21e56aa6d6a8687603e8b8c26715341d1bcbef8c899fd488c7604fb2dc6099d0'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94_pilot\\vh94_pilot_v2_rotateTrue.json', 22354, '05765b63fbaba0388df136497ed5c9e93d792af426d5dd2e170e1a485df7cff5'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94_pilot\\vh94_pilot_v1_spektral_apsis.json', 12808, 'e54b29016eaccf588439f6894037345d925849e906bbfd63407734b5db99bcc0'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\dryrun_v1\\dryrun.json', 15608, 'c33d06c02c82dead83ea0813f6d782ad8f53571afb79bff30ef9c7a3938ad565'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\dryrun_v2\\dryrun.json', 17122, '60dc8b4134ae5196cc13e9fd52c0f21b586953cdb1dac11e105afc00fe178a1e'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme92_20261026\\kod\\ext_engine.py', 28393, '22feea1836b7e3b475e86efc0c3660eb742f83cd224444a2317ff001bd58489e'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme92_20261026\\kod\\ext_common.py', 21468, 'b11b55cd58665944e7371aece67dd2dea147bdae7156cc75190b8668544e811a'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme92_20261026\\kod\\ext_engine_d.py', 30767, '780c4d95a6748a137fd6ba0045603dda025c001b4d073bd3553fe62a76851cea'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme92_20261026\\kod\\ext_common_d.py', 21470, '98747eef15690f25b882850a04e77f53c22bbb21375fa7750b1a0c08242da727'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme92_20261026\\girdi\\development_20261026\\out\\tsv\\selection.json', 2635991, '2d5a00d86497b174277d238293e08129f901627da99844552dcfcc397d981b53'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme92_20261026\\girdi\\development_20261026\\out\\tsv\\TSV_a\\analysis\\points.csv', 2111107, '6a099961188a4cdf51865fbc0e370c2c9ce5a8e961e55a8a7e23e01dcbb844e7'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme92_20261026\\out\\P93_20261026_a\\sonuc.json', 9622, '4c9acafa7a0807b26280649dd6ad65f08c76da885bcfbf6f553f78fec3235325'),
    ('C:\\Users\\onura\\OneDrive\\Desktop\\EN YENİ MAKALEM\\research_intelligence\\gelistirme92_20261026\\protokol\\P93_sonuc_raporu_B5.md', 4810, '57bb997c8e59a77466b5a882f0a791d231aff62a3a52ec80ad14da2d50ba6541'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\audit_v3\\s3\\analysis\\virtual_hil_raw_audit.json', 8697, 'a20791b22dc30dfd3e3233aa352b4375919eae9e51904f43d97461a84b8ebcb5'),
    ('C:\\Users\\onura\\Documents\\Codex\\2026-10-28\\segan-frozen-formatted-zip-dosyas-na\\work\\virtual_hil_protocol.json', 6212, '238275dc4d3124d19c5bc4690c927ed58e16986875ff3efea8424c5443a2f178'),
    ('C:\\Users\\onura\\Documents\\Codex\\2026-10-28\\segan-frozen-formatted-zip-dosyas-na\\work\\independent_emt\\ramp_plan.json', 1136, '5d5524e5954f4fcb6c2b20f280af22b8b242ba5f56d4758e1540e4d4b2a48e6b'),
    ('C:\\Users\\onura\\Documents\\Codex\\2026-10-28\\segan-frozen-formatted-zip-dosyas-na\\work\\segan_typhoon\\build_plant.py', 14731, '65e6a2bfa30d04448f48733ddb84e55e0022af1fa6cf5da7b4e111c67a5180b5'),
    ('C:\\Users\\onura\\Documents\\Codex\\2026-10-28\\segan-frozen-formatted-zip-dosyas-na\\work\\segan_typhoon\\controller_code.py', 8006, '1386ae79c560899ee82885b6452e1fa884493a4e5fc6801c774f2ed7690f258c'),
    ('C:\\Users\\onura\\Documents\\Codex\\2026-10-28\\segan-frozen-formatted-zip-dosyas-na\\work\\segan_typhoon\\controller_src\\controller_math.c', 3075, '43c9eb5d4d357eba9c9d43171f839c6a36dc422f6e1850bb30035b2679f86732'),
    ('C:\\Users\\onura\\Documents\\Codex\\2026-10-28\\segan-frozen-formatted-zip-dosyas-na\\work\\segan_typhoon\\controller_src\\controller_math.h', 647, '9ea2fff2387661f0996472e88473bfbfee137f0df7f408eb5805abefd0f8120b'),
    ('C:\\Users\\onura\\Documents\\Codex\\2026-10-28\\segan-frozen-formatted-zip-dosyas-na\\work\\segan_typhoon\\audit_model.py', 4223, 'a1c2072068d2fb0baa7b1af9e8f3cfe6754ba2d387f864e1a756cdadaa32005d'),
    ('C:\\Users\\onura\\Documents\\Codex\\2026-10-28\\segan-frozen-formatted-zip-dosyas-na\\work\\segan_typhoon\\audit_compiled_timing.py', 2766, 'e1fcdaf74b68a3ab85d05cb4b7765d0f0424d3743c2cc9aaaddeb4b88aca028e'),
    ('C:\\Users\\onura\\Documents\\Codex\\2026-10-28\\segan-frozen-formatted-zip-dosyas-na\\work\\segan_typhoon\\run_validation.py', 7175, 'ad38b71808202d3684b37eb9b181fa7fdf1df67926f1b9116d759bf27d4a24e7'),
    ('C:\\Users\\onura\\Documents\\Codex\\2026-10-28\\segan-frozen-formatted-zip-dosyas-na\\work\\segan_typhoon\\hardware_reliability\\run_guarded_native.ps1', 3559, '59279134cadbd0a1d9900dce39e89bf5ff51915111eefac3c9d883cb2ef8a029'),
    ('C:\\Users\\onura\\Documents\\Codex\\2026-10-28\\segan-frozen-formatted-zip-dosyas-na\\work\\independent_emt\\calibrate.py', 4250, 'a525facb8090b46d10b3f8e6ba32d6f44d193614318ed5f786af4c228d6235e9'),
    ('C:\\Users\\onura\\Documents\\Codex\\2026-10-28\\segan-frozen-formatted-zip-dosyas-na\\work\\independent_emt\\model.py', 6895, '04678aba0b243bac49856dbfff3c8c4e993da9ba0d9780b8e1bfed85f72a0441'),
    ('C:\\Users\\onura\\Documents\\Codex\\2026-10-28\\segan-frozen-formatted-zip-dosyas-na\\work\\independent_emt\\calibration_A2-F00993.json', 3872, '077aad9d7bd39c084a44ebca790ab248e4dbfcf51ab000573cb545f8f9b8eb2b'),
    ('C:\\Users\\onura\\Documents\\Codex\\2026-10-28\\segan-frozen-formatted-zip-dosyas-na\\work\\independent_emt\\calibration_F2-0.65-0.20.json', 3705, '9c408b4714de473fce8d1fc10b04589494bf6d1e786dcf496ed194bc65f2d1cb'),
    ('C:\\Users\\onura\\Documents\\Codex\\2026-10-28\\segan-frozen-formatted-zip-dosyas-na\\work\\independent_emt\\calibration_F2-0.60-0.20.json', 3702, 'e849b6db120a3b5b690a00183edf4b2339424889b10e12b6148144a57d55bde8'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\archive\\vh94_avg_dryrun_v1.py', 5764, 'fee88e847d242f720ae48b0bbbe82f174a66e8331d17d122b0e7d348e01f1826'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\archive\\analyze_vh94_v02.py', 10478, 'f587b66d244ab81f495c51dc74f0ddd0d2f6c1e83bbd804642cde199ec582ddf'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\vh94_avg_dryrun.py', 7482, '8a1db891bd0ec5be91628fa78f86524ff177dcc7d555c0e80d01458a170c48b2'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\analyze_vh94.py', 11408, 'a8df777e5b83a03af2ac112dbeb809db019eaa28c1c0a56846c86251f1fd0d68'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\vh94_synth.py', 12573, '8ddea8eec617c8d63263d8504390fc2954a573fd15e6d60649fa46dd9d960432'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\vh94_smoke_check.py', 3925, 'e7010d27900f6d3f6b862b14a942dc7cb2a2783963d59e0cb27f480f88ecea6b'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\vh94_static_check.py', 5580, 'daa2a4a0b8ad3826314c9b122d9bee1f206dfa310056eeb2fe308e9c0fdc99b0'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\independent_emt\\calibrate_vh94.py', 4545, '958bde216aa612eeb17a67e99e9904d1403ad86310d3c4ad6056e1ae9d1ba579'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\independent_emt\\model.py', 6895, '04678aba0b243bac49856dbfff3c8c4e993da9ba0d9780b8e1bfed85f72a0441'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\independent_emt\\calibration_A2-F00993.json', 3872, '077aad9d7bd39c084a44ebca790ab248e4dbfcf51ab000573cb545f8f9b8eb2b'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\independent_emt\\calibration_A2-F01921.json', 3874, '1e74fc5fb46c549a112ee63aba1fdf980b982acd806ba6a538b44e72e6e77fb5'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\independent_emt\\calibration_A2-F00357.json', 3874, '3a48ff25522e74a470efcd645b920e313f3c63aa46097545dc3f5dd537ab4a55'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\independent_emt\\calibration_A2-F00138.json', 3878, '74a19a6e3569f58a6f25e91de388b7038b873715275948e9d3e6650e6fb3812d'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\independent_emt\\calibration_F2-0.65-0.20.json', 3705, '9c408b4714de473fce8d1fc10b04589494bf6d1e786dcf496ed194bc65f2d1cb'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\independent_emt\\calibration_F2-0.60-0.20.json', 3702, 'e849b6db120a3b5b690a00183edf4b2339424889b10e12b6148144a57d55bde8'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\segan_typhoon_vh94\\controller_code_vh94.py', 12035, '342efb717bc27a6dec25bb1886545f56c5dadfa87d436ee1c8a3377ddc6bd534'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\segan_typhoon_vh94\\build_plant_vh94.py', 10999, 'ebe0d209adecefa978a4ca9694b997a26d5d1f1ed36581c28d73337af26f5f8c'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\segan_typhoon_vh94\\audit_model_vh94.py', 4513, 'c877288ede2e0df64c7bede7d50bb4807703c4a5554c2731a87b75360ec97d79'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\segan_typhoon_vh94\\audit_compiled_timing_vh94.py', 2655, '4716bb31c193deb874e0d739f4edad084c62dd394fb203053aebaf08d5f51c0a'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\segan_typhoon_vh94\\run_vh94.py', 7887, '50e3bb41034224203f007d3957ccc48ce2f8b87b1444303eb451c3ed89c863a3'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\segan_typhoon_vh94\\run_guarded_vh94.ps1', 3910, '77af37437a9ff0fb79959ddfdd43d98f1b82d16d1eb48a7356a7b083fd5041ef'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\segan_typhoon_vh94\\run_campaign_vh94.ps1', 7113, '499f7f05218de5d7b28a38922b6d73f066c7abac0d7fb42fb516b03bb301f351'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\segan_typhoon_vh94\\controller_src\\controller_math.c', 3075, '43c9eb5d4d357eba9c9d43171f839c6a36dc422f6e1850bb30035b2679f86732'),
    ('C:\\Users\\onura\\Documents\\SEGAN_G94_work\\vh94\\segan_typhoon_vh94\\controller_src\\controller_math.h', 647, '9ea2fff2387661f0996472e88473bfbfee137f0df7f408eb5805abefd0f8120b'),
]
CASES = ('A2-F00993', 'A2-F01921', 'A2-F00357', 'A2-F00138', 'F2-0.65-0.20', 'F2-0.60-0.20')
SCENARIOS = ('R_m', 'F_m')   # v1.3 (D-265)


def _read_bytes(p):
    with open(p, 'rb') as fh:
        return fh.read()


def _write_text(p, s):
    with open(p, 'w', encoding='utf-8', newline='\n') as fh:
        fh.write(s)


def sha(p):
    return hashlib.sha256(_read_bytes(p)).hexdigest()


def check_pins():
    bad = []
    for path, size, digest in PINS:
        if not os.path.isfile(path):
            bad.append((path, 'yok'))
            continue
        b = _read_bytes(path)
        if len(b) != size or hashlib.sha256(b).hexdigest() != digest:
            bad.append((path, 'uyuşmaz'))
    if not os.path.isfile(SABIT_PATH) or sha(SABIT_PATH) != SABIT_SHA256:
        bad.append((SABIT_PATH, 'SABİT uyuşmaz'))
    pin_list = hashlib.sha256(json.dumps(PINS, ensure_ascii=False).encode('utf-8')).hexdigest()
    return bad, pin_list


def verify_authorization(run_id, yetki, campaign):
    bad, pin_list = check_pins()
    if bad:
        return 'KAPI: pin ' + json.dumps(bad, ensure_ascii=False)
    try:
        y = json.loads(_read_bytes(yetki).decode('utf-8'))
    except Exception as exc:  # noqa: BLE001
        return 'KAPI: yetki okunamadı: %s' % exc
    want = dict(action='ALLOW_VH94_RUN', run_id=run_id, sabit_sha256=SABIT_SHA256, pin_list_sha256=pin_list)
    for k, v in want.items():
        if y.get(k) != v:
            return 'KAPI: yetki alanı %s' % k
    if (y.get('script_sha256') or {}).get('vh94_run.py') != sha(os.path.abspath(__file__)):
        return 'KAPI: yetki betik hash'
    if not campaign or os.path.normcase(os.path.abspath(campaign)) != os.path.normcase(os.path.abspath(y.get('campaign_dir') or '')):
        return 'KAPI: kampanya klasörü yetkideki campaign_dir değil'
    rep = y.get('code_audit_report') or {}
    if not rep.get('path') or not os.path.isfile(rep['path']) or sha(rep['path']) != rep.get('sha256'):
        return 'KAPI: kod denetimi raporu'
    return None


def load_capture(d):
    import numpy as np
    z = np.load(io.BytesIO(_read_bytes(os.path.join(d, 'capture.npz'))))
    names = [str(n) for n in z['signal_names']]
    vals = z['values']
    cap = {n: vals[i] for i, n in enumerate(names)}
    cap['t'] = z['time_s']
    cap['values'] = vals
    cap['y'] = np.hypot(cap['v2d_pm'], cap['v2q_pm'])
    return cap


def analyze(campaign, out):
    import analyze_vh94 as A
    plan = json.loads(_read_bytes(PILOT).decode('utf-8'))
    pc = {c['id']: c for c in plan['cases']}
    ledger_txt = _read_bytes(os.path.join(campaign, 'campaign_ledger.jsonl')).decode('utf-8-sig')
    ledger = [json.loads(l.lstrip('\ufeff')) for l in ledger_txt.splitlines() if l.strip()]
    integrity, guard, whea_stop = [], {}, False
    for e in ledger:
        if e.get('op') == 'stop' and e.get('reason') == 'new_whea':
            whea_stop = True
        if e.get('op') in ('run', 'run_start'):           # B3-5: run_start lines count too
            if whea_stop:
                integrity.append('WHEA durdurmasından sonra koşu: %s %s' % (e.get('case'), e.get('scenario')))
            if e.get('scenario') not in SCENARIOS or e.get('case') not in CASES:
                integrity.append('protokol dışı senaryo: %s %s' % (e.get('case'), e.get('scenario')))
            guard[(e['case'], e['scenario'], e['step'])] = e.get('guard_ok') is True
    bad, _ = check_pins()
    if bad:
        integrity.append('analiz anında pin uyuşmazlığı')
    rd = os.path.join(campaign, 'runs')
    failed_dirs = sorted(n for n in os.listdir(rd) if '_basarisiz_' in n) if os.path.isdir(rd) else []
    for n in failed_dirs:   # v0.3 (audit D2 F-3, B1-4): a renamed directory must not hold a record
        if os.path.isfile(os.path.join(rd, n, 'capture.npz')):
            integrity.append('kayıtlı koşu yinelenmiş: %s' % n)
    res = dict(run_id=None, plan_sha256=sha(PILOT), cases={}, failed_attempt_dirs=failed_dirs)
    labels, signs = {}, {}
    for cid in CASES:
        case = pc[cid]
        rec = dict(s_pred=case.get('sign_pred_D'), pilot_status=case.get('status'), runs={})
        signs[cid] = case.get('sign_pred_D') or 0
        if case.get('status') != 'ok':
            labels[cid] = 'NE'
            rec.update(label='NE', ne_reason='pilot')
            res['cases'][cid] = rec
            continue
        est = {}
        for scen, step in A.RUNS:
            d = os.path.join(rd, '%s_%s_%sus' % (cid, scen, step))
            key = '%s@%s' % (scen, step)
            if not (os.path.isfile(os.path.join(d, 'run_status.json')) and os.path.isfile(os.path.join(d, 'capture.npz'))):
                rec['runs'][key] = dict(ne='kayıt yok')
                est[key] = None
                continue
            st = json.loads(_read_bytes(os.path.join(d, 'run_status.json')).decode('utf-8'))
            if st.get('capture_npz_sha256') != sha(os.path.join(d, 'capture.npz')):
                integrity.append('kayıt hash uyuşmazlığı: %s' % key)
            cap = load_capture(d)
            sig_p, f_p, sig_r = A.pred_of(case, scen)
            win = A.window_end(cap['t'], cap['y'], sig_p)
            ok, gates, phys = A.run_gates(st, cap, guard.get((cid, scen, step), False), win[0])
            ih = input_hash_ok(st, cid)                      # §5.6 input hashes (G-3)
            gates['input_hash'] = ih
            ok = ok and ih
            r = dict(gates=gates, physics=phys, capture_npz_sha256=st.get('capture_npz_sha256'))
            if not ok:
                r['ne'] = 'kapı:' + ','.join(k for k, v in gates.items() if not v)
            else:
                r.update(A.estimate_run(cap['t'], cap['y'], sig_p, f_p, sig_r, window=win))
                if r.get('ne') is None:
                    r['vdc_report'] = A.estimate_run(cap['t'], cap['vdc_pm'], sig_p, f_p, sig_r)
            rec['runs'][key] = r
            est[key] = r
        lab, D, uD, thr = A.case_verdict(case['sign_pred_D'], est.get('F_m@0p025'), est.get('R_m@0p025'),
                                         est.get('F_m@0p05'), est.get('R_m@0p05'))
        rep = report_items(A, case, est)
        rep['R5'] = dict(D_pred_rotate_true=(case.get('rotate_alt') or {}).get('D_pred_at_m'),
                         pred_no_delay_m=(case.get('pred_nd') or {}).get('m'))
        rep['R6'] = ('Codex v3 F2-0.65-0.20 rampası (0.0691 pu) sönmemişti; bu kalem yalnız VH94 R_m/R_lo ile '
                     'karşılaştırma notudur.') if cid == 'F2-0.65-0.20' else None
        try:                                               # B3-2: report item must not abort the analysis
            rep['R7'] = latch_settling(rd, cid)
        except Exception as exc:  # noqa: BLE001
            rep['R7'] = dict(error='%s: %s' % (type(exc).__name__, exc))
        rec.update(label=lab, D=D, u_D=uD, threshold=thr, D_pred_d=case.get('D_pred_d'), report=rep)
        labels[cid] = lab
        res['cases'][cid] = rec
    row, verdict = A.campaign_verdict(labels, signs, not integrity)
    res.update(labels=labels, decision_row=row, verdict=verdict, integrity_errors=integrity)
    return res


def input_hash_ok(st, cid):
    """§5.6: run_status input hashes must equal the pinned files (by file name)."""
    pinned = {os.path.basename(p): d for p, _, d in PINS}
    want = dict(controller_c='controller_math.c', controller_h='controller_math.h',
                controller_code_vh94='controller_code_vh94.py', run_vh94='run_vh94.py',
                calibration='calibration_%s.json' % cid)
    got = st.get('input_sha256') or {}
    return all(got.get(k) == pinned.get(v) for k, v in want.items())


def latch_settling(rd, cid):
    """R-7 (report): slope of y over [0.20, 0.30) s in R_m at 25 ns (before any removal), |v0 - calibration|."""
    import numpy as np
    d = os.path.join(rd, '%s_R_m_0p025us' % cid)
    if not os.path.isfile(os.path.join(d, 'capture.npz')):
        return None
    cap = load_capture(d)
    t, y = cap['t'], cap['y']
    m = (t >= 0.20) & (t < 0.30)
    slope = float(np.polyfit(t[m], y[m], 1)[0]) if m.sum() > 2 else None
    cal = json.loads(_read_bytes(os.path.join(HERE, 'independent_emt', 'calibration_%s.json' % cid)).decode('utf-8'))
    x0 = cal['initial_state_independent_order']
    k = int(np.nonzero(t >= 0.30)[0][0])
    dv = float(np.hypot(cap['v0d_latched'][k] - x0[2], cap['v0q_latched'][k] - x0[3]))
    return dict(slope_pu_per_s=slope, v0_minus_x0_pu=dv)


def report_items(A, case, est):
    rep = {}
    for key, scen in (('R_m@0p025', 'R_m'), ('F_m@0p025', 'F_m'), ('R_lo@0p025', 'R_lo'), ('R_hi@0p025', 'R_hi'),
                      ('B0@0p025', 'B0')):
        r = est.get(key)
        sp, fp, _ = A.pred_of(case, scen)
        if r is not None and r.get('ne') is None:
            rep[key] = dict(sigma_hat=r['sigma'], sigma_pred_d=sp, sign_agree=(r['sigma'] > 0) == (sp > 0),
                            ratio=(r['sigma'] / sp) if sp else None, f_hat=r['fit']['f_hz'], f_pred=fp)
    return rep


def write_outputs(out, res, log, code):
    os.makedirs(out, exist_ok=True)
    _write_text(os.path.join(out, 'sonuc.json'), json.dumps(res, indent=1, ensure_ascii=False, default=float))
    v = res.get('verdict', 'HATA')
    lines = ['VH94 hüküm: %s (satır %s)' % (v, res.get('decision_row'))]
    lines += ['%s: %s' % (c, l) for c, l in (res.get('labels') or {}).items()]
    _write_text(os.path.join(out, 'hukum.txt'), '\n'.join(lines) + '\n')
    _write_text(os.path.join(out, 'girdi_pinleri.json'), json.dumps(PINS, indent=1, ensure_ascii=False))
    _write_text(os.path.join(out, 'stdout.txt'), '\n'.join(log) + '\n')
    _write_text(os.path.join(out, 'stderr.txt'), res.get('error', ''))
    _write_text(os.path.join(out, 'exit_code.txt'), str(code))
    sums = []
    for n in sorted(os.listdir(out)):
        p = os.path.join(out, n)
        if os.path.isfile(p) and n != 'SHA256SUMS':
            sums.append('%s  %s' % (sha(p), n))
    _write_text(os.path.join(out, 'SHA256SUMS'), '\n'.join(sums) + '\n')


def main():
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument('--check-only', action='store_true')
    g.add_argument('--verify', action='store_true')
    g.add_argument('--analyze', action='store_true')
    ap.add_argument('--run-id')
    ap.add_argument('--yetki')
    ap.add_argument('--campaign')
    a = ap.parse_args()
    if a.check_only:
        bad, pin_list = check_pins()
        print(json.dumps(dict(pin_failures=bad, pin_list_sha256=pin_list), ensure_ascii=False))
        return 0 if not bad else 1
    if not a.run_id or not a.yetki:
        print('KAPI: --run-id ve --yetki gerekli')
        return 2
    why = verify_authorization(a.run_id, a.yetki, a.campaign)
    if why:
        print(why)
        return 2
    if a.verify:
        print('yetki doğrulandı: %s' % a.run_id)
        return 0
    if not a.campaign:
        print('KAPI: --campaign gerekli')
        return 2
    out = os.path.join(a.campaign, 'analysis_' + a.run_id)
    if os.path.isfile(os.path.join(out, 'exit_code.txt')):
        print('KAPI: bu run_id için mühürlü analiz var')
        return 3
    log = []
    try:
        sys.path.insert(0, HERE)
        res = analyze(a.campaign, out)
        res['run_id'] = a.run_id
        log.append('verdict %s row %s' % (res['verdict'], res['decision_row']))
        write_outputs(out, res, log, 0)
        print('\n'.join(log))
        return 0
    except Exception as exc:  # noqa: BLE001
        import traceback
        res = dict(run_id=a.run_id, verdict='HATA', error=traceback.format_exc())
        write_outputs(out, res, log + ['HATA %s' % exc], 1)
        print('HATA', exc)
        return 1


if __name__ == '__main__':
    sys.exit(main())
