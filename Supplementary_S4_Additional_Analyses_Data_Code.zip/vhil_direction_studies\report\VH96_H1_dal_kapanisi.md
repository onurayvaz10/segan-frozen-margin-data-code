# VH96 H1 — dal kapanışı: GÜÇ_YETERSİZ (2026-11-07)

## Ne kapandı
VH96'nın H1 hipotezi (taze, kör A2 vakalarında eşleşik yön testi) Typhoon'a hiç gitmeden kapandı.

**Dayanak (SABİT v1.1):**
- §7 H1 güç kapısı: en az 2 iyimser ve en az 2 tutucu vakada |D_pred,d| ≥ 6.4 s⁻¹ gerekir.
- M-6 / M3-14: GÜÇ_YETERSİZ son durumdur.

**Tasarım kaydı:** `SEGAN_G94_work/vh96/tasarim_20261107_a/t3/vh96_tasarim.json` (sha256 a15cf571…b760). Kapı sonucu iki uygulamada da aynı çıktı:

| Sınıf | Vaka: \|D_pred,d\| (s⁻¹) | Eşiği geçen |
|---|---|---|
| İyimser | F01557 10.17, F01169 6.56, F00805 3.19 | 2 |
| Tutucu (seçilen) | 03094 9.40, F00555 6.08, F01579 5.56 | 1 |
| Tutucu (seçilmeyen havuz) | S01157 4.06, 02149 3.61, F00067 2.59 | — |

## Neden (INFERENCE)
- Tutucu A2 noktalarında gecikmeli ortalama modelin öngördüğü sönüm farkı küçüktür. Havuzun en büyüğü 9.40'tır, ikincisi 6.08. Bu farklar, VH95-RA'da A2 vakalarında görülen ölçüm belirsizliği ölçeğine (eşik 6.4–18 s⁻¹) ulaşmaz.
- Bu, D1 R-3'te öngörülen risktir. Kapı, yaklaşık 3,3 saatlik bir Typhoon koşusunun büyük olasılıkla BELİRSİZ vereceğini koşudan önce gösterdi.

## Ne kalır
- H2 (sınır parantezi) kapısı geçti. Dört vaka (3 iyimser, 1 tutucu) ayrı kampanyada koşulacak.
- H1 hakkında VH96'dan hüküm yoktur.
- H1 için mevcut kanıt değişmedi:
  - VH95-RA, keşif niteliğinde KISMİ verdi; kısmen kör.
  - VH94, NOT_EVALUABLE verdi.

## Sabit kalanlar
- Havuz, G, G2, k kümesi ve kapı ölçütleri değişmez (M3-14).
- Vaka eklenmez.
- H1 için ardıl bir çalışma, yeni D-ID'li ve VH96 adını taşımayan ayrı bir ön-kayıt olur. Bu ön-kayıt şunları "görüldü" diye beyan eder:
  - bu pilot değerleri;
  - VH96 H2 sonuçları (o sırada varsa).
- "Yalnız iyimser" bir test ancak ayrı ve daha dar bir iddia olarak ön-kayda girer. TUTARLI ya da KISMİ veremez.

## Seçenekler (kullanıcı; şimdi karar gerekmiyor)
- (a) H1'i makalede yalnız VH95-RA keşif sonucu ve VH96 güç kapısı bulgusuyla raporlamak. Bulgu şu: "taze tutucu A2 noktalarında öngörülen etki ölçüm belirsizliği ölçeğinin altında".
- (b) Ardıl ön-kayıt: belirsizliği düşürecek yöntem değişikliği. Örnek: daha ince adım çifti ile u_run'ı küçültmek, ya da F2 tutucu ailesi. Bu yeni bir yöntem kararıdır.

## Kayıtlar
- Karar günlüğü: D-279.
- Reddedilen bir aday yoktur; bu bir güç kapanışıdır. Bu yüzden ret defterine satır yazılmadı.
