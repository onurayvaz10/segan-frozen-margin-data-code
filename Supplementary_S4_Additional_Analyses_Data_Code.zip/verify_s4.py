"""Read-only check of FILE_INVENTORY.csv (standard library only)."""
import csv, hashlib, os, sys
here = os.path.dirname(os.path.abspath(__file__))
bad = 0
n = 0
with open(os.path.join(here, 'FILE_INVENTORY.csv'), encoding='utf-8') as f:
    for row in csv.DictReader(f):
        n += 1
        p = os.path.join(here, *row['path'].split('/'))
        h = hashlib.sha256(open(p, 'rb').read()).hexdigest() if os.path.exists(p) else None
        if h != row['sha256']:
            bad += 1
            print('MISMATCH', row['path'])
print('files checked: %d, mismatches: %d' % (n, bad))
sys.exit(1 if bad else 0)
