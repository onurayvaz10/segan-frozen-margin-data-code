"""E2P tek koşu betiği (B1, sürüm v3; v1/v2 kod/archive/e2p_run_v{1,2}_20261108.py).

v3 değişiklikleri (B3 v2 denetimi `denetim/E2P_kod_denetimi_B3_v2.md`, 6a32e856…4f07):
  B3v2-1 A, C'nin NE-hata sınıfını da devralır (C'de NE-hata yalnız kurulum ya da X-1/X-2 istisnasından doğar);
         B de delta_son üzerinden aynı biçimde devralır. B1-i buna göre değişti.
  B3v2-4 delta_son: ΔG*_ex'i olmayan A NE sınıfı B'ye aynı etiketle geçer (NE-hata → NE-hata).
  B3v2-6 B istisna dalındaki erişilemez switch_k geri alma kodu kaldırıldı.
  B3v2-7 (bilgi) k = 0'da (iv) ve SWITCH değerlendirilmez: t_0 = crit tanım gereği eşleşir; değişiklik yok.

v2 değişiklikleri (B3 v1 denetimi `denetim/E2P_kod_denetimi_B3_v1.md`, 7f5c046d…5dfb):
  B3-1  Satır içi kararlar saf işlevlere ayrıldı (x1_ok, x2_ok, match_I1, i2_ok, gizli_ok, eid_source,
        eid_bound, track_check, switch_pre, reconv_ok, delta_son); sentetik testler bunları ve sahte motorla
        compute_A/B/C yollarını sınar.
  B3-2  B: κ_{k−1} adım k'nin başında hesaplanır (istisna → TAKİP_KOPUK(k)); SWITCH doğrulamasındaki rho_at
        istisnası → TAKİP_KOPUK(k); k = 0'daki crossings istisnası → TAKİP_KOPUK(0).
  B3-3  compute_C try ile sarıldı: kurulum/X-1/X-2 istisnası → NE-hata, ayrışım istisnası → NE-ayrışım.
  B3-4  A adım 2 istisnası → başarısız sayılır, 2n ile yeniden denenir, yine olmazsa NE-denge.
  B3-5  Motor yolu kapısı klasör açılmadan önce (Kapi → exit 2); çöküş izi crash_<n>.txt ve stderr.txt'ye
        eklenir; çöküşte geçici SHA256SUMS; stdout.txt'ye ekleme kipiyle yazılır.
  B3-6  İlk koşuda yetki_sha256.txt yazılır, devamda karşılaştırılır; verify_authorization'daki her istisna Kapi.
  B3-7  Raporlar: EKSEN alt sayıları, S_X aile sayıları, adım 7'de elenen adaylar (elenen).
  B3-8  S_P, y_common.y2_set ile de kurulur ve yerel kuralla eşitliği denetlenir (eşit değilse ABORT);
        S_D'de sign(κ) ≠ ref_sign, np.sign ile.
  B3-9  Ortam kapısı: değişken tanımlıysa (boş dahil) KAPI.
  B3-11 kok_sapma'ya N-1 notu.

SABİT: research_intelligence/gelistirme94_20261029/protokol/E2P_On_Kayit_v1.1_SABIT.md
       sha256 134b47c123c59c3977e20e5869f86aa0188014326c250771683f3f0d3bbbbc80

SABİT § -> işlev eşlemesi
  §4  pinler, ortam kapısı, tek okuyucu ...... PINS, check_pins, env_gate, check_engine_paths
  §5.1 nokta kümeleri ......................... build_sets, select_sx
  §5.2 kurulum, X-1, X-2 ...................... setup_point, entry_checks
  §5.3 sınama A ............................... compute_A, kappa_eig, threshold, tolerances, is_valid,
                                                 classify_A, kok_sapma (v1.1: F-1, F-2)
  §5.4 sınama B ............................... compute_B, classify_B, representatives
  §5.5 sınama C ............................... compute_C, flip_class
  §5.6 özetler ................................ summaries, sd_interpretation, label_table
  §7–§8 değerlendirilebilirlik ve kararlar .... decide_A, decide_B, decide_C, naming_rule
  §9  kipler, aşamalar, devam, çıktı ........... main, stage_loop, discard_partial, write_outputs
  §10 yetki .................................... verify_authorization

Yazar seçimleri (B1; denetimde kabul ya da red edilir)
  E2P-B1-a  WHEA sayımı betikte yapılmaz (subprocess yasak). B4 operatörü koşudan önce ve sonra
            konsol klasörüne yazar. SABİT §9 bunu betiğe yüklemiyor.
  E2P-B1-b  X-1/X-2 C aşamasında hesaplanır ve C.jsonl'a yazılır. A ve B dağıtımı ve X-1'i aynı
            deterministik çağrılarla yeniden yapar ve C kaydının sınıfını kullanır (NE-dağıtım ve
            NE-kimlik C'den devralınır).
  E2P-B1-c  gap_rel (yalnız rapor) = |μ1 − μ2| / max(1, max|μ|), Y_F0(jω_ss)'nin iki özdeğeri.
  E2P-B1-d  "en büyük gerçel kısım" eşitliğinde (eşlenik çift) Im ≥ 0 olan üye seçilir: argmax Re'den
            sonra Im < 0 ise eşleniği aranır (en yakın conj).
  E2P-B1-e  B'de alt adım kurtarma: x_{k−1}'den ΔG_k'ye 2 eşit alt adım, olmazsa 4. Her alt adım
            newton_fixed_refs'tir.
  E2P-B1-f  Devam için --neden metni zorunludur; devam_log.txt'ye zaman damgasıyla yazılır.
  E2P-B1-g  ABORT bir hükümdür. Çıktılar yazılır ve exit_code 0 olur. Kapı ihlalleri (KAPI) klasör
            açmadan exit 2 verir. Beklenmeyen çöküş exit 1 verir ve stderr.txt yazılır.
  E2P-B1-h  Nokta istisnaları (SABİT istisna tabloları) yerel yakalanır. compute_A/B/C'nin her biri en
            dışta try içerir (statik S10); hiçbir nokta istisnası aşamayı durdurmaz.
  E2P-B1-i  C'nin NE-dağıtım, NE-kimlik ve NE-hata sınıfları (kurulum ve X-1/X-2 giriş denetimleri) A ve B'ye
            devralınır (v3, B3v2-1); A ve B giriş denetimi yapılmamış noktayı sınıflamaz.

Kullanım:
  python -I -B e2p_run.py --check-only
  python -I -B e2p_run.py --run-id E2P_YYYYMMDD_a --yetki <mutlak yol>
  python -I -B e2p_run.py --devam --neden "<metin>" --run-id E2P_YYYYMMDD_a --yetki <mutlak yol>
"""
import argparse
import hashlib
import json
import math
import os
import sys
import time

os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['MKL_NUM_THREADS'] = '1'
import numpy as np  # noqa: E402

ROOT = r'C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence'
SABIT_PATH = ROOT + r'\gelistirme94_20261029\protokol\E2P_On_Kayit_v1.1_SABIT.md'
SABIT_SHA = '134b47c123c59c3977e20e5869f86aa0188014326c250771683f3f0d3bbbbc80'
G92_KOD = ROOT + r'\gelistirme92_20261026\kod'
OUT_ROOT = r'C:\Users\onura\Documents\SEGAN_G94_work\e2p'
POINTS_PIN = ROOT + r'\gelistirme92_20261026\girdi\development_20261026\out\tsv\TSV_a\analysis\points.csv'
SELECTION_PIN = ROOT + r'\gelistirme92_20261026\girdi\development_20261026\out\tsv\selection.json'

PINS = [
    (POINTS_PIN, 2111107, '6a099961188a4cdf51865fbc0e370c2c9ce5a8e961e55a8a7e23e01dcbb844e7'),
    (SELECTION_PIN, 2635991, '2d5a00d86497b174277d238293e08129f901627da99844552dcfcc397d981b53'),
    (ROOT + r'\gelistirme92_20261026\kod\ext_engine.py', 28393,
     '22feea1836b7e3b475e86efc0c3660eb742f83cd224444a2317ff001bd58489e'),
    (ROOT + r'\gelistirme92_20261026\kod\ext_common.py', 21468,
     'b11b55cd58665944e7371aece67dd2dea147bdae7156cc75190b8668544e811a'),
    (ROOT + r'\gelistirme92_20261026\kod\y2_newton.py', 7408,
     '93428a8a031e21024ca338cb3d7381f209bc49b4a504d0e7914e96239b006e65'),
    (ROOT + r'\gelistirme92_20261026\kod\y_common.py', 3644,
     '7b16ffbf27dce28fb1932a38705eadbadde2ad1f22c9349c485f6feb523a2970'),
    (ROOT + r'\gelistirme92_20261026\kod\y16_analysis.py', 7963,
     'ac90702669de465013a383ebd7789b16be99b609afdf59f9611f162d33b9fccc'),
    (ROOT + r'\gelistirme92_20261026\ms\s2_v3.txt', 208824,
     'd039946c8122ec6056a6d5385b5d4c80483e09f37bf0ff3adea32b202956f4c7'),
    (ROOT + r'\gelistirme92_20261026\ms\ms_v4.txt', 139194,
     '94df67aaf411d987d872919d1065de56a6c642ac02652f11655589a1a65d238c'),
    (ROOT + r'\gelistirme94_20261029\notlar_maddeleri_v1.md', 3452,
     '3b678a10bbde2b9d6d4b38d5257452c18d3f5fba42ace3b87f269b1427d260bc'),
    (ROOT + r'\gelistirme94_20261029\K1_kayit_analizleri_N4_N5_N16.md', 4839,
     '10f25de3b00c7d05d9f5aebd17d3273423a1f26b5f1936b0444e600fa6af39d2'),
    (ROOT + r'\gelistirme94_20261029\protokol\P94_On_Kayit_v1.0_SABIT.md', 32226,
     '88b37f583111255d334449fea16c38c82815b3a8a07531bfc7b1a99f906551c2'),
    (ROOT + r'\gelistirme94_20261029\makale_v6\Manuscript_v6_3.docx', 4074230,
     '68885a86aa7a6401ac71765ef1fb003c7fc32b76084630d4581155b14014d47e'),
    (ROOT + r'\gelistirme94_20261029\makale_v6\Supplementary_Methods_S2_v6.docx', 679676,
     'df3cf76e6ce20503bfde634dc0476f6f97cb880d87daa54ee252c7ac78f12442'),
]

# ---------------------------------------------------------------------------------------- sabitler (SABİT)
TAU = 0.05
N_SP, N_SO, N_SD = 774, 18, 4
EVAL_A, EVAL_B, EVAL_C_SO, EVAL_C_ALL = 697, 12, 15, 1125
U_ROUND = 2.22e-16
THR_FLOOR = 1e-7
GENIS_REL = 1e-3
W_LO = 2 * math.pi * 0.01
W_HI = 2 * math.pi * 10 ** 3.5
VALID_IM = 1e-9
X1_W, X1_R, X1_R_ABS, X2_K = 1e-6, 1e-9, 5e-12, 1e-6
NGRID = 20
SX_MAX = 20
NE_CLASSES = ('NE-dağıtım', 'NE-kimlik', 'NE-ref', 'NE-denge', 'NE-hata')
A_KISMI = ('ω0', 'ωHI', 'TARAMA', 'GİZLİ', 'EKSEN', 'GENİŞ', 'RAKİP', 'KÖK_SAPMA')
C_INHERIT = ('NE-dağıtım', 'NE-kimlik', 'NE-hata')


class Kapi(Exception):
    pass


# ---------------------------------------------------------------------------------------- G/Ç yardımcıları
def _read_bytes(p):
    with open(p, 'rb') as f:
        return f.read()


def _write_text(p, s, mode='w'):
    with open(p, mode, encoding='utf-8', newline='\n') as f:
        f.write(s)
        f.flush()


def _write_bytes(p, b):
    with open(p, 'wb') as f:
        f.write(b)
        f.flush()


def sha256_bytes(b):
    return hashlib.sha256(b).hexdigest()


def clean(o):
    if isinstance(o, dict):
        return {str(k): clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [clean(v) for v in o]
    if isinstance(o, (complex, np.complexfloating)):
        return [clean(float(o.real)), clean(float(o.imag))]
    if isinstance(o, (np.floating, float)):
        v = float(o)
        return v if math.isfinite(v) else None
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.bool_,)):
        return bool(o)
    return o


def jdump(o):
    return json.dumps(clean(o), ensure_ascii=False)


# ---------------------------------------------------------------------------------------- kapılar (§4, §10)
def env_gate(environ=None):
    environ = os.environ if environ is None else environ
    for k in ('G92_S1', 'G92_OUT'):
        if k in environ:
            raise Kapi('KAPI: ortam değişkeni tanımlı: ' + k)


def check_pins():
    if sha256_bytes(_read_bytes(SABIT_PATH)) != SABIT_SHA:
        raise Kapi('KAPI: SABİT hash uyuşmazlığı')
    lines = []
    for p, n, h in PINS:
        b = _read_bytes(p)
        if len(b) != n or sha256_bytes(b) != h:
            raise Kapi('KAPI: pin uyuşmazlığı: ' + p)
        lines.append('%s  %d  %s' % (h, n, p))
    return sha256_bytes('\n'.join(lines).encode('utf-8')), lines


def script_sha():
    return sha256_bytes(_read_bytes(os.path.abspath(__file__)))


def verify_authorization(path, run_id, pin_sha):
    try:
        return _verify_authorization(path, run_id, pin_sha)
    except Kapi:
        raise
    except Exception as exc:  # noqa: BLE001
        raise Kapi('KAPI: yetki doğrulanamadı: %s: %s' % (type(exc).__name__, exc))


def _verify_authorization(path, run_id, pin_sha):
    if not path or not os.path.isabs(path):
        raise Kapi('KAPI: yetki dosyası mutlak yol olmalı')
    try:
        a = json.loads(_read_bytes(path).decode('utf-8'))
    except Exception as exc:  # noqa: BLE001
        raise Kapi('KAPI: yetki okunamadı: %s' % exc)
    need = ('action', 'run_id', 'sabit_sha256', 'script_sha256', 'pin_list_sha256', 'code_audit_report',
            'dayanak', 'yazan')
    for k in need:
        if k not in a:
            raise Kapi('KAPI: yetki alanı eksik: ' + k)
    if a['action'] != 'ALLOW_E2P_RUN':
        raise Kapi('KAPI: action')
    if a['run_id'] != run_id:
        raise Kapi('KAPI: run_id')
    if a['sabit_sha256'] != SABIT_SHA:
        raise Kapi('KAPI: sabit_sha256')
    if a['script_sha256'].get('e2p_run.py') != script_sha():
        raise Kapi('KAPI: script_sha256')
    if a['pin_list_sha256'] != pin_sha:
        raise Kapi('KAPI: pin_list_sha256')
    car = a['code_audit_report']
    if sha256_bytes(_read_bytes(car['path'])) != car['sha256']:
        raise Kapi('KAPI: kod denetim raporu hash')
    return a


def check_engine_paths(U):
    pts = os.path.normcase(os.path.abspath(str(U.TSV / 'TSV_a' / 'analysis' / 'points.csv')))
    sel = os.path.normcase(os.path.abspath(str(U.TSV / 'selection.json')))
    if pts != os.path.normcase(POINTS_PIN) or sel != os.path.normcase(SELECTION_PIN):
        raise Kapi('KAPI: motorun okuduğu yol pinle aynı değil')
    for p, n, h in PINS[:2]:
        if sha256_bytes(_read_bytes(p)) != h:
            raise Kapi('KAPI: okunan dosya hash')


# ---------------------------------------------------------------------------------------- kümeler (§5.1)
def is_primary(r):
    return (r['abs_kappa'] is not None and r['abs_kappa'] >= TAU and r['ref_sign'] in (1.0, -1.0)
            and r['stage1_pin_ok'] is True)


def is_uncensored(r):
    return r['censored'] is False and r['ref_status'] == 'alpha'


def build_sets(rows):
    sp = [r for r in rows if is_primary(r) and is_uncensored(r)]
    so = [r for r in sp if r['kappa'] < 0 and r['ref_sign'] == -1.0]
    sd = []
    for r in rows:
        if r['ref_sign'] not in (1.0, -1.0):
            continue
        mis = float(np.sign(r['kappa'])) != r['ref_sign']
        fs = r.get('F_single')
        unsafe = r['ref_sign'] == -1.0 and (r['kappa'] >= TAU or (r['kappa'] < TAU and fs is not None and fs > 0))
        if mis or unsafe:
            sd.append(r)
    ids = lambda L: sorted(x['id'] for x in L)  # noqa: E731
    return dict(SP=ids(sp), SO=ids(so), SD=ids(sd), ALL=ids(rows))


def set_abort(sets):
    if len(sets['SP']) != N_SP or len(sets['SO']) != N_SO or len(sets['SD']) != N_SD:
        return 'ABORT: küme sayısı S_P=%d S_O=%d S_D=%d' % (len(sets['SP']), len(sets['SO']), len(sets['SD']))
    return None


def select_sx(a_classes):
    """a_classes: {id: class} over S_P. Non-NE, non-KİMLİK; lexical id order; first 20."""
    c = sorted(i for i, k in a_classes.items() if k not in NE_CLASSES and k != 'KİMLİK')
    return c[:SX_MAX]


# ---------------------------------------------------------------------------------------- A yardımcıları
def pick_lambda(ev):
    i = int(np.argmax(ev.real))
    if ev[i].imag < 0:
        j = int(np.argmin(np.abs(ev - np.conj(ev[i]))))
        if j != i and abs(ev[j].real - ev[i].real) <= 1e-12 * max(1.0, abs(ev[i].real)):
            i = j
    return i


def kappa_eig(A):
    """λ (largest real part, Im >= 0 member), condition number with unconjugated y^T v (None if guarded)."""
    ev, V = np.linalg.eig(A)
    i = pick_lambda(ev)
    lam, v = ev[i], V[:, i]
    evl, W = np.linalg.eig(A.T)
    y = W[:, int(np.argmin(np.abs(evl - lam)))]
    yv = y @ v
    ny, nv = float(np.linalg.norm(y)), float(np.linalg.norm(v))
    if abs(yv) <= 1e-14 * ny * nv:
        return lam, None
    return lam, ny * nv / abs(yv)


def threshold(keig, normA, dsig, dG):
    """thr_ρ,i, flags. SABİT §5.3 adım 5 ve R3-4."""
    flags = []
    if keig is None or dsig is None:
        thr = THR_FLOOR
        flags.append('EŞİK_VARSAYILAN')
    else:
        thr = max(THR_FLOOR, 10 * U_ROUND * keig * normA / abs(dsig))
    if keig is None or thr > GENIS_REL * dG:
        flags.append('EŞİK_GENİŞ')
    return thr, flags


def tolerances(thr, sigma, dmu, omega_ss):
    """tol_ρ,z ve tol_ω,z (adım 7). dmu: dμ/dω. None if Im dmu == 0."""
    if dmu is None or dmu.imag == 0:
        return None
    c = dmu.real / dmu.imag
    tr = thr + abs(sigma) * abs(dmu) ** 2 / abs(dmu.imag)
    tw = 1e-4 * omega_ss + 2 * (1 + abs(c)) * abs(sigma)
    return tr, tw


def is_valid(lam):
    return abs(complex(lam).imag) <= VALID_IM * max(1.0, abs(complex(lam)))


def kok_sapma(kappa_ex, F_ex, tol):
    """SABİT v1.1 sınıf 7 (F-2): κ_ex ≥ 1 (ya da tanımsız) veya |F_ex| > tol; F_ex = ρ_z* − ΔG*_ex (F-1).
    N-1 (R3-8, B3-11): I1 ∧ I2 altında |F_ex| ≤ tol_star özdeştir; ikinci yol tanım gereği tutulur ve yalnız
    el yapımı girdiyle sınanır."""
    if kappa_ex is None or not kappa_ex < 1:
        return True
    return abs(F_ex) > tol


def classify_A(rec):
    """SABİT §5.3 sınıf sırası. rec: ne, omega_ss, I1, tarama, gizli, e_id_ok (True/False/None), genis,
    I2, kappa_ex, F_ex, delta_port, tol_star."""
    if rec.get('ne'):
        return rec['ne']
    w = rec['omega_ss']
    if w < W_LO:
        return 'ω0'
    if w > W_HI:
        return 'ωHI'
    if not rec['I1']:
        if rec.get('tarama'):
            return 'TARAMA'
        if rec.get('gizli'):
            return 'GİZLİ'
        if rec.get('e_id_ok') is None or rec.get('e_id_ok'):
            return 'EKSEN'
        return 'İHLAL'
    if rec.get('genis'):
        return 'GENİŞ'
    if not rec['I2']:
        return 'RAKİP'
    if kok_sapma(rec.get('kappa_ex'), rec.get('F_ex'), rec['tol_star']):
        return 'KÖK_SAPMA'
    return 'KİMLİK'


# ---------------------------------------------------------------------------------------- B yardımcıları
def classify_B(rec):
    """rec: ne, switch_k, kopuk_k, ne_denge_k (None ya da int)."""
    if rec.get('ne'):
        return rec['ne']
    sk, kk, nk = rec.get('switch_k'), rec.get('kopuk_k'), rec.get('ne_denge_k')
    if nk is not None:
        if sk is not None and sk < nk:
            return 'RAKİP_GEÇİŞ'
        if kk is not None and kk < nk:
            return 'TAKİP_KOPUK'
        return 'NE-denge'
    if sk is not None and (kk is None or sk < kk):
        return 'RAKİP_GEÇİŞ'
    if kk is not None:
        return 'TAKİP_KOPUK'
    return 'TEK_DAL'


def representatives(brecs, so_ids, n=3):
    sc = []
    for i in so_ids:
        b = brecs.get(i)
        if not b:
            continue
        d = [abs(s['F_tr'] - s['F']) for s in b.get('steps', [])
             if s.get('tracked_valid') and s.get('F') is not None and s.get('F_tr') is not None]
        if d:
            sc.append((-max(d), i))
    sc.sort()
    return [i for _, i in sc[:n]]


# ---------------------------------------------------------------------------------------- C yardımcıları
def flip_class(kappa, terms):
    """terms: ordered dict name -> value. Çevirici: t < 0 ve κ − t ≥ 0. Yalnız κ < 0 için."""
    if not kappa < 0:
        return None
    fl = [n for n, t in terms.items() if t < 0 and kappa - t >= 0]
    if len(fl) == 1:
        return 'TEK(%s)' % fl[0]
    return 'ÇOKLU' if len(fl) > 1 else 'ORTAK'


def x3_ok(sum_k, kappa, nu):
    return abs(sum_k - kappa) <= max(1e-4 * max(abs(kappa), TAU), 10 * nu)


# ---------------------------------------------------------------------------------------- kararlar (§7–§8)
def decide_A(sp_classes, abort=None):
    if abort:
        return 'ABORT'
    ev = [c for c in sp_classes.values() if c not in NE_CLASSES]
    if len(ev) < EVAL_A:
        return 'NOT_EVALUABLE'
    if 'İHLAL' in ev:
        return 'RET-İHLAL'
    if any(c in A_KISMI for c in ev):
        return 'KISMİ'
    return 'TUTARLI'


def decide_B(so_classes, abort=None):
    if abort:
        return 'ABORT'
    ev = [c for c in so_classes.values() if c not in NE_CLASSES]
    if len(ev) < EVAL_B:
        return 'NOT_EVALUABLE'
    if 'RAKİP_GEÇİŞ' in ev:
        return 'KISMİ'
    if 'TAKİP_KOPUK' in ev:
        return 'BELİRSİZ'
    return 'TUTARLI'


def decide_C(n_so_x3, n_all_ok, abort=None):
    if abort:
        return 'ABORT'
    if n_so_x3 < EVAL_C_SO or n_all_ok < EVAL_C_ALL:
        return 'NOT_EVALUABLE'
    return 'BETİMSEL'


def naming_rule(c_verdict, n_tek_dis):
    if c_verdict != 'BETİMSEL':
        return 'DEĞİŞMEZ'
    return 'DEĞİŞİR' if n_tek_dis >= 10 else 'DEĞİŞMEZ'


def sd_interpretation(ref_sign_ex, b_class):
    if ref_sign_ex in (0, 1):
        return 'göreli eşik artefaktı'
    if ref_sign_ex == -1 and b_class == 'RAKİP_GEÇİŞ':
        return 'rakip dal'
    if ref_sign_ex == -1 and b_class == 'TEK_DAL':
        return 'açıklanmadı (çözünürlük ya da eğrilik)'
    return 'belirsiz'


def label_table(pairs):
    t = {}
    for a, b in pairs:
        k = '%s->%s' % (a, b)
        t[k] = t.get(k, 0) + 1
    return dict(sorted(t.items()))


def tab_summary(arecs):
    d = [a['delta_tab'] for a in arecs if a.get('delta_tab') is not None]
    rat = [a['delta_tab'] / a['delta_tab_pred'] for a in arecs
           if a.get('delta_tab') is not None and a.get('delta_tab_pred') not in (None, 0)]
    out = dict(n=len(d), n_pred_tanimsiz=sum(1 for a in arecs if a.get('delta_tab') is not None
                                             and a.get('delta_tab_pred') in (None, 0)))
    if d:
        out.update(median=float(np.median(d)), min=min(d), max=max(d), frac_neg=sum(x < 0 for x in d) / len(d))
    if rat:
        out['frac_ratio_0p5_2'] = sum(0.5 <= r <= 2 for r in rat) / len(rat)
    ay = [a.get('ayirt') for a in arecs if a.get('ayirt') is not None]
    if ay:
        out['frac_ayirt'] = sum(ay) / len(ay)
    for f in ('EŞİK_VARSAYILAN', 'EŞİK_GENİŞ', '9B_HATA', 'GİZLİ_HATA', 'MIN_FARKLI'):
        out['n_' + f] = sum(1 for a in arecs if f in a.get('flags', []))
    out['n_thr_gt_1e-6'] = sum(1 for a in arecs if a.get('thr') is not None and a['thr'] > 1e-6)
    out['n_sahte_aday'] = sum(a.get('n_sahte', 0) for a in arecs)
    return out


# ---------------------------------------------------------------------------------------- devam (§9)
def discard_partial(path, log):
    if not os.path.exists(path):
        return
    b = _read_bytes(path)
    if b and not b.endswith(b'\n'):
        cut = b.rfind(b'\n') + 1
        _write_text(log, '%s yarım satır atıldı %s: %r\n' % (time.strftime('%Y-%m-%dT%H:%M:%S'),
                                                             os.path.basename(path), b[cut:][:200]), 'a')
        _write_bytes(path, b[:cut])


def devam_count(log):
    if not os.path.exists(log):
        return 0
    return sum(1 for ln in _read_bytes(log).decode('utf-8').splitlines() if ln.startswith('DEVAM '))


def load_jsonl(path):
    if not os.path.exists(path):
        return {}
    out = {}
    for ln in _read_bytes(path).decode('utf-8').splitlines():
        if ln.strip():
            o = json.loads(ln)
            out[o['id']] = o
    return out


# ---------------------------------------------------------------------------------------- saf karar işlevleri (B3-1)
def x1_ok(crit_omega, crit_rho, w_rec, dGf_rec):
    return (abs(crit_omega - w_rec) <= X1_W * w_rec
            and abs(crit_rho - dGf_rec) <= max(X1_R * dGf_rec, X1_R_ABS))


def x2_ok(kappa, kappa_rec):
    return abs(kappa - kappa_rec) <= X2_K * max(abs(kappa_rec), TAU)


def match_I1(cands, w_ss, dG):
    """cands: [(z, dmu, (tol_ρ, tol_ω))]. Eşleşenler ve z* (|ρ − ΔG| en küçük)."""
    m = [c for c in cands if abs(c[0]['omega'] - w_ss) <= c[2][1] and abs(c[0]['rho'] - dG) <= c[2][0]]
    if not m:
        return m, None
    return m, min(m, key=lambda c: abs(c[0]['rho'] - dG))


def i2_ok(valid, zstar, tol):
    """I2: z* dışında ρ > 0 ve ρ < ρ_z* − tol olan geçerli geçiş yok (katı)."""
    return not [z for z in valid if z is not zstar and z['rho'] > 0 and z['rho'] < zstar['rho'] - tol]


def gizli_ok(evr, lam_ss, w_ss):
    return bool(np.min(np.abs(np.asarray(evr) - lam_ss)) <= 1e-4 * max(w_ss, abs(lam_ss)))


def eid_source(cands, dmu_d, w_ss):
    """R3-5: (1) ω_ss'ye en yakın aday, (2) z_d, (3) None."""
    if cands:
        return min(cands, key=lambda c: abs(c[0]['omega'] - w_ss))[1]
    return dmu_d


def eid_bound(thr, src, keig, normA):
    return thr + (10 * abs(src) * U_ROUND * keig * normA if src is not None else 0.0)


def track_check(tk, lamc, t_prev, kap_prev, h, thr, valid, pos):
    """§5.4 (i)–(v). Dönüş (neden ya da None, same). same: (iv)'ü sağlayan bütün girdiler (R3-3)."""
    pred = t_prev['rho'] + kap_prev * h
    win_r = max(10 * thr, 0.05 * abs(t_prev['rho']))
    same = [z for z in valid if abs(z['omega'] - tk['omega']) <= 1e-4 * tk['omega']
            and abs(z['rho'] - tk['rho']) <= 10 * thr]
    if not is_valid(lamc):
        return 'i', same
    if abs(tk['omega'] - t_prev['omega']) > 0.05 * t_prev['omega']:
        return 'ii', same
    if abs(tk['rho'] - pred) > win_r:
        return 'iii', same
    if not same:
        return 'iv', same
    others = [z for z in pos if not any(z is q for q in same)
              and abs(z['omega'] - t_prev['omega']) <= 0.05 * t_prev['omega'] and abs(z['rho'] - pred) <= win_r]
    if others:
        return 'v', same
    return None, same


def switch_pre(m, tk, same, thr):
    """SWITCH'in ilk iki koşulu: m_k (iv) kümesinde değil, ω farklı, ρ(m) < ρ(t) − thr (katı)."""
    return (m is not None and not any(m is q for q in same)
            and abs(m['omega'] - tk['omega']) > 1e-4 * tk['omega'] and m['rho'] < tk['rho'] - thr)


def reconv_ok(zz, m, thr):
    return abs(zz['omega'] - m['omega']) <= 1e-4 * m['omega'] and abs(zz['rho'] - m['rho']) <= 10 * thr


def olasi_rakip(m, t_prev, kap_prev, h, thr):
    return bool(m is not None and m['rho'] < t_prev['rho'] + kap_prev * h - thr)


def delta_son(crec, arec):
    """§5.4 ΔG_son dalları. Dönüş (ΔG_son ya da None, NE sınıfı ya da None)."""
    if crec.get('cls') in C_INHERIT:
        return None, crec['cls']
    if arec.get('ref_sansur'):
        return arec['dG_max'], None
    if arec.get('dG_ex') is None:
        return None, arec.get('ne') or 'NE-ref'
    return arec['dG_ex'], None


# ---------------------------------------------------------------------------------------- motor (yetkiden sonra)
def _load_engine():
    sys.path.insert(0, G92_KOD)
    import ext_common as C  # noqa: E402
    import ext_engine as E  # noqa: E402
    import y_common as U  # noqa: E402
    import y2_newton as Y  # noqa: E402
    return C, E, U, Y


class Eng:
    def __init__(self, C, E, U, Y, sel=None):
        self.C, self.E, self.U, self.Y = C, E, U, Y
        self.sel = U.selection() if sel is None else sel

    def A_of(self, lay, J):
        k = lay.keep
        return J[np.ix_(k, k)] / lay.M[k][:, None]

    def setup_point(self, r):
        C, E = self.C, self.E
        lay, G, P = C.BUILDERS[r['system']](self.sel[r['id']])
        d = E.dispatch(lay, P, G, tol=1e-12)
        if not (d['ok'] or d['hist'][-1] <= 1e-8):
            return None
        x0, refs = d['x'], d['refs']
        sb = lay.sysd['shed_bus']
        th = float(np.arctan2(x0[lay.ix['V%d:I' % sb]], x0[lay.ix['V%d:R' % sb]]))
        return dict(lay=lay, G=G, P=P, x0=x0, refs=refs, sb=sb, th=th)

    def entry_checks(self, s, r):
        E = self.E
        crit = E.rho_at(s['lay'], s['x0'], s['refs'], s['G'], s['th'],
                        dict(omega=r['omega'], lam=complex(r['dGf'], 0.0)))
        if not x1_ok(crit['omega'], crit['rho'], r['omega'], r['dGf']):
            return None, None, dict(x1_omega=crit['omega'], x1_rho=crit['rho'])
        k = E.kappa_hat(s['lay'], s['x0'], s['refs'], s['G'], s['th'], crit)
        if not x2_ok(k['kappa'], r['kappa']):
            return crit, None, dict(x2_kappa=k['kappa'])
        return crit, k, {}

    # ------------------------------------------------------------------------------------ C (§5.5)
    def compute_C(self, r):
        out = dict(id=r['id'], system=r['system'], kappa_rec=r['kappa'], kappa_L_rec=r['kappa_L'])
        try:
            s = self.setup_point(r)
            if s is None:
                out['cls'] = 'NE-dağıtım'
                return out
            crit, k, info = self.entry_checks(s, r)
        except Exception as exc:  # noqa: BLE001
            out.update(cls='NE-hata', err='kurulum: %s: %s' % (type(exc).__name__, exc))
            return out
        out.update(info)
        if k is None:
            out['cls'] = 'NE-kimlik'
            return out
        out.update(crit_omega=crit['omega'], crit_rho=crit['rho'], crit_lam=crit['lam'], kappa=k['kappa'], c=k['c'])
        try:
            return self._decompose(r, s, crit, k, out)
        except Exception as exc:  # noqa: BLE001
            out.update(cls='NE-ayrışım', err='ayrışım: %s: %s' % (type(exc).__name__, exc))
            return out

    def _decompose(self, r, s, crit, k, out):
        E = self.E
        lay, x0, refs, G, th, sb = s['lay'], s['x0'], s['refs'], s['G'], s['th'], s['sb']
        eps = 1e-5
        xi = k['xi']
        J0 = E.jac(lay, x0, refs, G)
        dJ = (E.jac(lay, x0 + eps * xi, refs, G) - E.jac(lay, x0 - eps * xi, refs, G)) / (2 * eps)
        keep, b = lay.keep, lay.port
        rr = [i for i in keep if i not in b]
        w0 = crit['omega']
        K = 1j * w0 * np.diag(lay.M) - J0
        Krr, Krb, Kbr = K[np.ix_(rr, rr)], K[np.ix_(rr, b)], K[np.ix_(b, rr)]
        X = np.linalg.solve(Krr, Krb)
        Xp = np.linalg.solve(Krr.T, Kbr.T).T
        lam0, v, wl, _ = E.eig_branch(lay, J0, th, w0, crit['lam'])
        den = wl @ v
        if den == 0:
            out['cls'] = 'NE-ayrışım'
            return out
        groups = dict(Cb=[], Co=[], G=[], N=[])
        cpl_bus = [cd['bus'] for cd in lay.sysd['cpls']]
        for i in keep:
            nm = lay.names[i]
            if nm.startswith('C'):
                ci = int(nm[1:nm.index(':')])
                groups['Cb' if cpl_bus[ci] == sb else 'Co'].append(i)
            elif nm.startswith('G:'):
                groups['G'].append(i)
            else:
                groups['N'].append(i)
        ks = {}
        for gname, rows in groups.items():
            dK = np.zeros_like(K)
            if rows:
                dK[rows, :] = -dJ[rows, :]
            dY = (dK[np.ix_(b, b)] - dK[np.ix_(b, rr)] @ X - Xp @ dK[np.ix_(rr, b)]
                  + Xp @ dK[np.ix_(rr, rr)] @ X)
            eta = complex(wl @ E.to_F0(dY, th) @ v / den)
            ks[gname] = (eta * complex(1.0, k['c'])).real
        nu = abs(k['kappa'] - E.kappa_hat(lay, x0, refs, G, th, crit, eps=2e-5)['kappa'])
        ssum = sum(ks.values())
        out.update(k_Cb=ks['Cb'], k_Co=ks['Co'], k_G=ks['G'], k_N=ks['N'], k_sum=ssum, nu=nu)
        if not x3_ok(ssum, k['kappa'], nu):
            out['cls'] = 'NE-ayrışım'
            return out
        kd = ks['G'] + ks['N'] + ks['Co']
        out['k_dis'] = kd
        out['k_res'] = ks['Cb'] - r['kappa_L']
        out['flip1'] = flip_class(k['kappa'], dict([('κ_Cb', ks['Cb']), ('κ_dış', kd)]))
        out['flip2'] = flip_class(k['kappa'], dict([('κ_L', r['kappa_L']), ('κ_dış', kd), ('κ_res', out['k_res'])]))
        out['cls'] = 'OK'
        return out

    # ------------------------------------------------------------------------------------ A (§5.3)
    def dmu_at(self, lay, J, th, w, lam_target):
        E = self.E
        lz = E.eig_branch(lay, J, th, w, lam_target)[0]
        lp = E.eig_branch(lay, J, th, w * (1 + 1e-6), lz)[0]
        lm = E.eig_branch(lay, J, th, w * (1 - 1e-6), lz)[0]
        return complex((lp - lm) / (2e-6 * w))

    def compute_A(self, r, crec):
        out = dict(id=r['id'], system=r['system'], flags=[], n_sahte=0, elenen=[])
        try:
            return self._compute_A(r, crec, out)
        except Exception as exc:  # noqa: BLE001
            out['ne'] = 'NE-hata'
            out['err'] = '%s: %s' % (type(exc).__name__, exc)
            out['cls'] = classify_A(out)
            return out

    def _path(self, lay, x0, refs, G, dG, n):
        try:
            return self.E.path_point(lay, x0, refs, G, dG, steps=n)[0]
        except Exception:  # noqa: BLE001
            return None

    def _compute_A(self, r, crec, out):
        C, E, Y = self.C, self.E, self.Y
        if crec.get('cls') in C_INHERIT:
            out['ne'] = crec['cls']
            out['cls'] = classify_A(out)
            return out
        s = self.setup_point(r)
        if s is None:
            out['ne'] = 'NE-dağıtım'
            out['cls'] = classify_A(out)
            return out
        lay, x0, refs, G, th, sb = s['lay'], s['x0'], s['refs'], s['G'], s['th'], s['sb']
        dGf = r['dGf']
        dmax = min(G[sb], 2 * dGf)
        out['dG_max'] = dmax
        try:
            R = E.reference_margin(lay, x0, refs, G, dmax, 0.01 * dGf, tol=1e-9, alpha_tab=0.0)
        except Exception as exc:  # noqa: BLE001
            out.update(ne='NE-ref', err='ref: %s' % exc)
            out['cls'] = classify_A(out)
            return out
        out['ref_status_ex'] = R['status']
        if not R['status'].startswith('alpha'):
            out['ne'] = 'NE-ref'
            if R['status'].startswith('censored'):
                out['ref_sansur'] = True
                out['ref_sign_ex'] = 1
            out['cls'] = classify_A(out)
            return out
        dG = R['dGt']
        out['dG_ex'] = dG
        n = int(math.ceil(dG / (0.01 * dGf)))
        x_ex = self._path(lay, x0, refs, G, dG, n)
        if x_ex is None:
            x_ex = self._path(lay, x0, refs, G, dG, 2 * n)
        if x_ex is None:
            out['ne'] = 'NE-denge'
            out['cls'] = classify_A(out)
            return out
        Gex = G.copy()
        Gex[sb] -= dG
        J_ex = E.jac(lay, x_ex, refs, Gex)
        J_exG = E.jac(lay, x_ex, refs, G)
        A_ex = self.A_of(lay, J_ex)
        lam_ss, keig = kappa_eig(A_ex)
        normA = float(np.linalg.norm(A_ex, 2))
        w_ss, sig = abs(lam_ss.imag), lam_ss.real
        out.update(lam_ss=lam_ss, omega_ss=w_ss, sigma_ss=sig, kappa_eig=keig, normA=normA)
        # adım 4
        dsig = None
        try:
            dGm = dG - 1e-3 * dGf
            Gm = G.copy()
            Gm[sb] -= dGm
            xm, okm = E.newton_fixed_refs(lay, x_ex, refs, Gm)[:2]
            if okm:
                evm = np.linalg.eigvals(self.A_of(lay, E.jac(lay, xm, refs, Gm)))
                sm = evm[int(np.argmin(np.abs(evm - lam_ss)))].real
                dsig = (sig - sm) / (1e-3 * dGf)
                if dsig == 0:
                    dsig = None
        except Exception:  # noqa: BLE001
            dsig = None
        out['dsig_ddG'] = dsig
        thr, fl = threshold(keig, normA, dsig, dG)
        out['thr'] = thr
        out['flags'] += fl
        out['genis'] = 'EŞİK_GENİŞ' in fl
        # adım 13–14
        out['ref_sign_ex'] = C.ref_sign_of('alpha', dG - dGf, dGf)
        out['delta_tab'] = r['dGref'] - dG
        out['delta_tab_pred'] = (-1e-10 * normA / dsig) if dsig else None
        out['ayirt'] = abs(out['delta_tab']) >= 10 * thr
        if w_ss < W_LO or w_ss > W_HI:
            out['cls'] = classify_A(out)
            return out
        # adım 6 (istisna → NE-hata, dış yakalayıcı)
        cr = E.crossings(lay, J_exG, th)
        valid = []
        for z in cr:
            if is_valid(z['lam']):
                valid.append(z)
            else:
                out['n_sahte'] += 1
        out['crossings'] = [dict(omega=z['omega'], rho=z['rho'], valid=is_valid(z['lam'])) for z in cr]
        # adım 7–8
        cands = []
        for z in valid:
            if abs(z['omega'] - w_ss) <= 0.05 * w_ss:
                try:
                    dmu = self.dmu_at(lay, J_exG, th, z['omega'], z['lam'])
                except Exception as exc:  # noqa: BLE001
                    out['elenen'].append((z['omega'], 'istisna: %s' % type(exc).__name__))
                    continue
                t = tolerances(thr, sig, dmu, w_ss)
                if t is None:
                    out['elenen'].append((z['omega'], 'Im dμ/dω = 0'))
                    continue
                cands.append((z, dmu, t))
        match, best = match_I1(cands, w_ss, dG)
        out['I1'] = bool(match)
        zstar = dmu_s = None
        if best is not None:
            zstar, dmu_s, tstar = best
            out.update(zstar_omega=zstar['omega'], zstar_rho=zstar['rho'], tol_star=tstar[0])
        else:
            out['tol_star'] = None
            dmu_d = None
            try:   # 9a
                zd = E.rho_at(lay, x_ex, refs, G, th, dict(omega=w_ss, lam=complex(dG, 0.0)))
                ld = E.eig_branch(lay, J_exG, th, zd['omega'], zd['lam'])[0]
                dmu_d = self.dmu_at(lay, J_exG, th, zd['omega'], zd['lam'])
                t = tolerances(thr, sig, dmu_d, w_ss)
                out['tarama'] = bool(is_valid(ld) and t is not None and abs(zd['omega'] - w_ss) <= t[1]
                                     and abs(zd['rho'] - dG) <= t[0])
            except Exception:  # noqa: BLE001
                out['tarama'] = False
            if keig is None:   # 9b
                out['e_id_ok'] = None
                out['e_id_neden'] = 'κ_eig tanımsız'
            else:
                try:
                    mu = np.linalg.eigvals(E.to_F0(E.port_admittance(lay, J_exG, lam_ss), th))
                    e_id = float(np.min(np.abs(mu - dG)))
                    bound = eid_bound(thr, eid_source(cands, dmu_d, w_ss), keig, normA)
                    out.update(e_id=e_id, e_id_bound=bound, e_id_ok=e_id <= bound)
                except Exception:  # noqa: BLE001
                    out['flags'].append('9B_HATA')
                    out['e_id_ok'] = None
                    out['e_id_neden'] = '9B_HATA'
            try:   # 9c
                rr = [i for i in lay.keep if i not in lay.port]
                evr = np.linalg.eigvals(J_exG[np.ix_(rr, rr)] / lay.M[rr][:, None])
                out['gizli'] = gizli_ok(evr, lam_ss, w_ss)
            except Exception:  # noqa: BLE001
                out['flags'].append('GİZLİ_HATA')
                out['gizli'] = False
        try:   # adım 10 (rapor)
            w_r = zstar['omega'] if zstar is not None else w_ss
            rr = [i for i in lay.keep if i not in lay.port]
            Kq = 1j * w_r * np.diag(lay.M) - J_exG
            out['cond_Krr'] = float(np.linalg.cond(Kq[np.ix_(rr, rr)]))
            mu2 = np.linalg.eigvals(E.to_F0(E.port_admittance(lay, J_exG, 1j * w_ss), th))
            out['gap_rel'] = float(abs(mu2[0] - mu2[1]) / max(1.0, float(np.max(np.abs(mu2)))))
        except Exception:  # noqa: BLE001
            pass
        out['I2'] = i2_ok(valid, zstar, out['tol_star']) if out['I1'] else None   # adım 11
        if out['I1'] and out['I2']:   # adım 12 (istisna → NE-hata, dış yakalayıcı)
            pos = [z for z in valid if z['rho'] > 0]
            zmin = min(pos, key=lambda z: z['rho'])
            F_ex = zstar['rho'] - dG
            out.update(F_ex_min=zmin['rho'] - dG, min_farkli=zmin is not zstar)
            if zmin is not zstar:
                out['flags'].append('MIN_FARKLI')
            kex = Y.kappa_at(lay, x_ex, refs, G, Gex, th, zstar)[0]
            out.update(F_ex=F_ex, kappa_ex=kex)
            out['delta_port'] = (-F_ex / (kex - 1)) if kex < 1 else None
            if dsig is not None:
                try:
                    out['ratio_dsig'] = dsig / ((1 - kex) * dmu_s.imag / abs(dmu_s) ** 2)
                except Exception:  # noqa: BLE001
                    pass
        out['cls'] = classify_A(out)
        return out

    # ------------------------------------------------------------------------------------ B (§5.4)
    def solve_step(self, lay, x_prev, refs, G, sb, dg_prev, dg):
        E = self.E
        for sub in (1, 2, 4):
            x, ok = x_prev, True
            for j in range(1, sub + 1):
                Gk = G.copy()
                Gk[sb] -= dg_prev + (dg - dg_prev) * j / sub
                try:
                    x, ok = E.newton_fixed_refs(lay, x, refs, Gk)[:2]
                except Exception:  # noqa: BLE001
                    ok = False
                if not ok:
                    break
            if ok:
                return x
        return None

    def compute_B(self, r, crec, arec):
        out = dict(id=r['id'], system=r['system'], steps=[])
        try:
            return self._compute_B(r, crec, arec, out)
        except Exception as exc:  # noqa: BLE001
            out['ne'] = 'NE-hata'
            out['err'] = '%s: %s' % (type(exc).__name__, exc)
            out['cls'] = classify_B(out)
            return out

    def _compute_B(self, r, crec, arec, out):
        E, Y = self.E, self.Y
        dend, ne = delta_son(crec, arec)
        if ne:
            out['ne'] = ne
            out['cls'] = classify_B(out)
            return out
        s = self.setup_point(r)                    # kurulum istisnası → NE-hata (dış yakalayıcı)
        if s is None:
            out['ne'] = 'NE-dağıtım'
            out['cls'] = classify_B(out)
            return out
        lay, x0, refs, G, th, sb = s['lay'], s['x0'], s['refs'], s['G'], s['th'], s['sb']
        crit, k, _ = self.entry_checks(s, r)
        if k is None:
            out['ne'] = 'NE-kimlik'
            out['cls'] = classify_B(out)
            return out
        thr = arec.get('thr') or THR_FLOOR
        h = dend / NGRID
        out.update(dG_son=dend, thr=thr)
        x_prev, t_prev = x0, crit
        tracking = True

        def kopus(kk, st, why, m=None, kap=None):
            out['kopuk_k'], st['kopus'] = kk, why
            if m is not None and kap is not None:
                st['olasi_rakip'] = olasi_rakip(m, t_prev, kap, h, thr)

        for kk in range(0, NGRID + 1):
            dg = kk * h
            st = dict(k=kk, dG=dg)
            if kk == 0:
                xk = x0
            else:
                xk = self.solve_step(lay, x_prev, refs, G, sb, dg - h, dg)
                if xk is None:
                    out['ne_denge_k'] = kk
                    out['steps'].append(st)
                    break
            try:
                cr = E.crossings(lay, E.jac(lay, xk, refs, G), th)
            except Exception:  # noqa: BLE001
                cr = None
            if cr is None:
                st['crossings_err'] = True
                if tracking:
                    kopus(kk, st, 'istisna')
                    tracking = False
                out['steps'].append(st)
                x_prev = xk
                continue
            valid = [z for z in cr if is_valid(z['lam'])]
            st['n_cross'], st['n_valid'], st['n_sahte'] = len(cr), len(valid), len(cr) - len(valid)
            pos = [z for z in valid if z['rho'] > 0]
            m = min(pos, key=lambda z: z['rho']) if pos else None
            st['m'] = None if m is None else dict(omega=m['omega'], rho=m['rho'])
            st['F'] = None if m is None else m['rho'] - dg
            st['crossings'] = [dict(omega=z['omega'], rho=z['rho'], valid=is_valid(z['lam'])) for z in cr]
            if kk == 0:
                if tracking:
                    st.update(t=dict(omega=crit['omega'], rho=crit['rho']), F_tr=crit['rho'], tracked_valid=True)
            elif tracking:
                try:
                    if kk == 1:
                        kap_prev = k['kappa']
                    else:
                        Gp = G.copy()
                        Gp[sb] -= dg - h
                        kap_prev = Y.kappa_at(lay, x_prev, refs, G, Gp, th, t_prev)[0]
                    tk = E.rho_at(lay, xk, refs, G, th, t_prev)
                    lamc = E.eig_branch(lay, E.jac(lay, xk, refs, G), th, tk['omega'], tk['lam'])[0]
                    why, same = track_check(tk, lamc, t_prev, kap_prev, h, thr, valid, pos)
                    st['t'] = dict(omega=tk['omega'], rho=tk['rho'])
                    st['F_tr'] = tk['rho'] - dg
                    if why is not None:
                        kopus(kk, st, why, m, kap_prev)
                        tracking = False
                    else:
                        if switch_pre(m, tk, same, thr):
                            zz = E.rho_at(lay, xk, refs, G, th, dict(omega=m['omega'], lam=m['lam']))
                            if reconv_ok(zz, m, thr):
                                st['switch'] = True
                                if out.get('switch_k') is None:
                                    out['switch_k'] = kk
                        st['tracked_valid'] = True
                        if tk['rho'] <= 0:
                            st['rho_t_nonpos'] = True
                        t_prev = tk
                except Exception as exc:  # noqa: BLE001
                    kopus(kk, st, 'istisna: %s' % type(exc).__name__)
                    st.pop('tracked_valid', None)
                    tracking = False
            out['steps'].append(st)
            x_prev = xk
        out['cls'] = classify_B(out)
        return out


# ---------------------------------------------------------------------------------------- aşama döngüsü
def stage_loop(name, ids, rows_by_id, fn, out_dir, log):
    path = os.path.join(out_dir, name + '.jsonl')
    discard_partial(path, os.path.join(out_dir, 'devam_log.txt'))
    done = load_jsonl(path)
    t0 = time.time()
    for n, i in enumerate(ids):
        if i in done:
            continue
        rec = fn(rows_by_id[i])
        _write_text(path, jdump(rec) + '\n', 'a')
        done[i] = json.loads(jdump(rec))
        if (n + 1) % 25 == 0:
            log.append('%s %d/%d t=%.0fs' % (name, n + 1, len(ids), time.time() - t0))
    _write_text(os.path.join(out_dir, 'asama_%s_tamam.txt' % name), time.strftime('%Y-%m-%dT%H:%M:%S'))
    return done


def summaries(sets, crecs, arecs, brecs, rows_by_id):
    sp, so, sd = sets['SP'], set(sets['SO']), sets['SD']
    a_sp = {i: arecs[i]['cls'] for i in sp}
    cnt = lambda d: {k: list(d.values()).count(k) for k in sorted(set(d.values()))}  # noqa: E731
    fam = {}
    for f in ('A2', 'B2', 'C'):
        fam[f] = tab_summary([arecs[i] for i in sp if rows_by_id[i]['system'] == f])
    fam['ALL'] = tab_summary([arecs[i] for i in sp])
    lab = dict(
        SO=label_table([(int(rows_by_id[i]['ref_sign']), arecs[i].get('ref_sign_ex')) for i in sets['SO']]),
        SP_minus_SO=label_table([(int(rows_by_id[i]['ref_sign']), arecs[i].get('ref_sign_ex')) for i in sp
                                 if i not in so]),
        SD=label_table([(int(rows_by_id[i]['ref_sign']), arecs[i].get('ref_sign_ex')) for i in sd]))
    sd_tab = {i: dict(A=arecs[i]['cls'], B=brecs.get(i, {}).get('cls'), ref_sign_ex=arecs[i].get('ref_sign_ex'),
                      yorum=sd_interpretation(arecs[i].get('ref_sign_ex'), brecs.get(i, {}).get('cls')))
              for i in sd}
    c_ok = [i for i in sets['ALL'] if crecs[i].get('cls') == 'OK']
    c_stat = {}
    for gname, ids in (('SO', sets['SO']), ('SP_minus_SO', [i for i in sp if i not in so]), ('ALL', sets['ALL'])):
        ok = [crecs[i] for i in ids if crecs[i].get('cls') == 'OK']
        st = dict(n_ok=len(ok))
        for key in ('k_Cb', 'k_dis', 'k_G', 'k_N', 'k_Co', 'k_res'):
            v = [c[key] for c in ok]
            if v:
                st[key] = dict(median=float(np.median(v)), min=min(v), max=max(v), n_neg=sum(x < 0 for x in v))
        st['flip1'] = cnt({c['id']: c['flip1'] for c in ok if c.get('flip1')})
        st['flip2'] = cnt({c['id']: c['flip2'] for c in ok if c.get('flip2')})
        c_stat[gname] = st
    return dict(A_class_counts_SP=cnt(a_sp), A_class_counts_SD={i: arecs[i]['cls'] for i in sd},
                delta_tab=fam, label_change=lab, SD_yorum=sd_tab, C=c_stat, n_C_ok=len(c_ok),
                SO_esik_genis=sum(1 for i in sets['SO'] if 'EŞİK_GENİŞ' in arecs[i].get('flags', [])),
                EKSEN_alt=eksen_alt([arecs[i] for i in sp]),
                SX_aile=sx_aile(sets.get('SX', []), rows_by_id),
                n_elenen_aday=sum(len(arecs[i].get('elenen', [])) for i in sp))


def eksen_alt(arecs):
    e = [a for a in arecs if a.get('cls') == 'EKSEN']
    return dict(saglandi=sum(1 for a in e if a.get('e_id_ok') is True),
                degerlendirilemedi=sum(1 for a in e if a.get('e_id_ok') is None))


def sx_aile(sx, rows_by_id):
    d = {}
    for i in sx:
        f = rows_by_id[i]['system']
        d[f] = d.get(f, 0) + 1
    return dict(sorted(d.items()))


def write_outputs(out_dir, result, log, pin_lines, code):
    _write_text(os.path.join(out_dir, 'sonuc.json'), json.dumps(clean(result), ensure_ascii=False, indent=1))
    h = result.get('hukum', {})
    _write_text(os.path.join(out_dir, 'hukum.txt'),
                'A: %s\nB: %s\nC: %s\nC_adlandirma: %s\n' % (h.get('A'), h.get('B'), h.get('C'), h.get('C_ad')))
    _write_text(os.path.join(out_dir, 'girdi_pinleri.json'), json.dumps(pin_lines, ensure_ascii=False, indent=1))
    _write_text(os.path.join(out_dir, 'stdout.txt'), '\n'.join(log) + '\n', 'a')
    if not os.path.exists(os.path.join(out_dir, 'stderr.txt')):
        _write_text(os.path.join(out_dir, 'stderr.txt'), '')
    if code is not None:
        _write_text(os.path.join(out_dir, 'exit_code.txt'), str(code))
    write_sums(out_dir)


def write_sums(out_dir):
    lines = []
    for n in sorted(os.listdir(out_dir)):
        p = os.path.join(out_dir, n)
        if n != 'SHA256SUMS' and os.path.isfile(p):
            lines.append('%s  %s' % (sha256_bytes(_read_bytes(p)), n))
    _write_text(os.path.join(out_dir, 'SHA256SUMS'), '\n'.join(lines) + '\n')


# ---------------------------------------------------------------------------------------- ana akış
def parse(argv):
    ap = argparse.ArgumentParser()
    ap.add_argument('--check-only', action='store_true')
    ap.add_argument('--run-id')
    ap.add_argument('--yetki')
    ap.add_argument('--devam', action='store_true')
    ap.add_argument('--neden')
    a = ap.parse_args(argv)
    if a.check_only and (a.run_id or a.yetki or a.devam):
        raise Kapi('KAPI: --check-only başka kiple birlikte verilemez')
    if not a.check_only and not (a.run_id and a.yetki):
        raise Kapi('KAPI: kip yok (--check-only ya da --run-id ve --yetki)')
    if a.devam and not a.neden:
        raise Kapi('KAPI: --devam için --neden zorunlu')
    return a


def prepare_dir(a, yetki_sha=None):
    out_dir = os.path.join(OUT_ROOT, a.run_id)
    log = os.path.join(out_dir, 'devam_log.txt')
    ys = os.path.join(out_dir, 'yetki_sha256.txt')
    if a.devam:
        if not os.path.isdir(out_dir):
            raise Kapi('KAPI: devam edilecek klasör yok')
        if os.path.exists(os.path.join(out_dir, 'exit_code.txt')):
            raise Kapi('KAPI: koşu tamamlanmış (exit_code.txt var)')
        if devam_count(log) >= 2:
            raise Kapi('KAPI: üçüncü devam girişimi; KULLANICI_BEKLIYOR')
        if yetki_sha is not None and (not os.path.exists(ys) or _read_bytes(ys).decode('utf-8').strip() != yetki_sha):
            raise Kapi('KAPI: devamda yetki dosyası ilk koşudakiyle aynı değil')
        _write_text(log, 'DEVAM %s %s\n' % (time.strftime('%Y-%m-%dT%H:%M:%S'), a.neden), 'a')
    else:
        if os.path.exists(out_dir):
            raise Kapi('KAPI: çıktı klasörü zaten var')
        os.makedirs(out_dir)
        if yetki_sha is not None:
            _write_text(ys, yetki_sha + '\n')
    return out_dir


def main(argv=None):
    a = parse(sys.argv[1:] if argv is None else argv)
    env_gate()
    pin_sha, pin_lines = check_pins()
    if a.check_only:
        sys.stdout.buffer.write(('CHECK-ONLY OK sabit=%s pin_list_sha256=%s script=%s\n'
                                 % (SABIT_SHA, pin_sha, script_sha())).encode('utf-8'))
        return 0
    auth = verify_authorization(a.yetki, a.run_id, pin_sha)
    C, E, U, Y = _load_engine()
    check_engine_paths(U)                       # Kapi → exit 2, klasör açılmadan (B3-5)
    out_dir = prepare_dir(a, sha256_bytes(_read_bytes(a.yetki)))
    log = ['start %s run_id=%s devam=%s' % (time.strftime('%Y-%m-%dT%H:%M:%S'), a.run_id, a.devam)]
    try:
        C.lower_priority()
        eng = Eng(C, E, U, Y)
        rows = U.load_points()
        rows_by_id = {r['id']: r for r in rows}
        sets = build_sets(rows)
        abort = set_abort(sets)
        if sorted(r['id'] for r in U.y2_set(rows)) != sets['SP']:
            abort = 'ABORT: S_P yerel kural ≠ y_common.y2_set'
        result = dict(run_id=a.run_id, sabit_sha256=SABIT_SHA, script_sha256=script_sha(), pin_list_sha256=pin_sha,
                      yetki=auth, sets={k: len(v) for k, v in sets.items()}, SD_ids=sets['SD'])
        if abort:
            result['abort'] = abort
            result['hukum'] = dict(A='ABORT', B='ABORT', C='ABORT', C_ad='DEĞİŞMEZ')
            write_outputs(out_dir, result, log, pin_lines, 0)
            return 0
        crecs = stage_loop('C', sets['ALL'], rows_by_id, eng.compute_C, out_dir, log)
        sa = sorted(set(sets['SP']) | set(sets['SD']))
        arecs = stage_loop('A', sa, rows_by_id, lambda r: eng.compute_A(r, crecs[r['id']]), out_dir, log)
        sx = select_sx({i: arecs[i]['cls'] for i in sets['SP']})
        sets['SX'] = sx
        st = sorted(set(sets['SO']) | set(sets['SD']) | set(sx))
        brecs = stage_loop('B', st, rows_by_id, lambda r: eng.compute_B(r, crecs[r['id']], arecs[r['id']]),
                           out_dir, log)
        a_sp = {i: arecs[i]['cls'] for i in sets['SP']}
        b_so = {i: brecs[i]['cls'] for i in sets['SO']}
        n_so_x3 = sum(1 for i in sets['SO'] if crecs[i].get('cls') == 'OK')
        n_all = sum(1 for i in sets['ALL'] if crecs[i].get('cls') == 'OK')
        hA, hB, hC = decide_A(a_sp), decide_B(b_so), decide_C(n_so_x3, n_all)
        n_tek_dis = sum(1 for i in sets['SO'] if crecs[i].get('cls') == 'OK' and crecs[i].get('flip1') == 'TEK(κ_dış)')
        result.update(SX=sx, B_classes={i: brecs[i]['cls'] for i in st},
                      B_representatives=representatives(brecs, sets['SO']),
                      summaries=summaries(sets, crecs, arecs, brecs, rows_by_id),
                      n_SO_x3=n_so_x3, n_ALL_C_ok=n_all, n_tek_dis=n_tek_dis,
                      hukum=dict(A=hA, B=hB, C=hC, C_ad=naming_rule(hC, n_tek_dis)),
                      devam_sayisi=devam_count(os.path.join(out_dir, 'devam_log.txt')))
        log.append('end %s A=%s B=%s C=%s' % (time.strftime('%Y-%m-%dT%H:%M:%S'), hA, hB, hC))
        write_outputs(out_dir, result, log, pin_lines, 0)
        return 0
    except Exception as exc:  # noqa: BLE001
        import traceback
        tb = traceback.format_exc()
        n = sum(1 for f in os.listdir(out_dir) if f.startswith('crash_')) + 1
        _write_text(os.path.join(out_dir, 'crash_%d.txt' % n), tb)
        _write_text(os.path.join(out_dir, 'stderr.txt'), tb, 'a')
        log.append('CRASH %s: %s' % (type(exc).__name__, exc))
        _write_text(os.path.join(out_dir, 'stdout.txt'), '\n'.join(log) + '\n', 'a')
        write_sums(out_dir)                     # geçici; exit_code.txt yazılmaz (devam mümkün)
        return 1


if __name__ == '__main__':
    try:
        code = main()
    except Kapi as exc:
        sys.stdout.buffer.write((str(exc) + '\n').encode('utf-8'))
        code = 2
    sys.exit(code)
