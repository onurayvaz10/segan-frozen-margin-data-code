# VH95-RA — Mühürlü VH95 kayıtları üzerinde dolgu düzeltmeli yeniden analiz · Ön-kayıt v1.2 SABİT

**v1.1 (2026-11-07):** Bu sürüm v1.0'ı (`VH95RA_On_Kayit_v1.0_SABIT.md`, sha256 4742cf79a9bef1d81a71af04c08818bfea1e4549ab2d4f2459c5fdb7feea051e, değiştirilmeden saklanır) yalnız §14'te sayılan noktalarda değiştirir. Neden: v1.0 B4 koşusu `VH95RA_20261107_a` ABORT verdi (X-0, "kayıt biçimi"; D-273). Kestirici çağrısı 0/0'dı. Kullanıcı kararı (2026-11-07): "Evet, v1.1 ile dene". Bu, §9'daki **tek** yeniden denemedir.

**v1.2 (2026-11-07):** v1.1 (VH95RA_On_Kayit_v1.1_SABIT.md, sha256 f1599114caf9d3f9b569b4b48f5c139073f8c78fd27ca78bbe63a17389a94123, değiştirilmeden saklanır) D3 denetiminin (denetim/VH95RA_On_Kayit_v1.1_denetimi_D3.md, sha256 fc55cbd59f053d3ad779bcb7854a3bbdec5d6439b897e1353bc3f7e1d90f61c0, hüküm REVISE, esaslı bulgu yok) R-1…R-5 metin düzeltmeleriyle v1.2 olarak sabitlendi. Emsal: v1.0 §13 (D2). Kural, eşik ya da karar satırı değişmedi; farklar §14 V-5…V-8'dedir.

**Ön-kayıt sapması (R-1; açık beyan).** Bu yeniden deneme v1.0'ı harfiyen izlemez: (i) §9 nedenin 'ortam ya da uygulama' düzeyinde giderilmesini öngörür; buradaki neden SABİT'in kendi metnidir (X-0 tür şartı). (ii) §1 kuralların SABİT'ten sonra değiştirilmeyeceğini söyler; V-1 §5.1 madde 0'ı ve §7'nin bir cümlesini değiştirir. Sapma bilerek, kullanıcı kararıyla (D-274) ve yalnız X-0 tür pini için yapılmıştır. Hükmü belirleyen niceliklere dokunmaz. Bu sapma hüküm raporunda aynen tekrarlanır.

2026-11-06 · Yazar: Claude Code (Opus 5.5), ana oturum. Bu oturum VH95 yetkisini ve VH95 B5 raporunu yazdı. Kod denetçisi (B3) ve taslak denetçileri (D1, D2) bu oturum değildir.

- Önceki sürümler:
  - `VH95RA_On_Kayit_TASLAK_v0.1.md` (sha256 62f49c7d…86df);
  - `VH95RA_On_Kayit_TASLAK_v0.2.md` (sha256 c7727c8f702dbadb59bab45766c8f1adcb098d74b77f28187852330c44fb9015).
- D1: `denetim/VH95RA_On_Kayit_denetimi_D1.md` (sha256 8e0997e6…64cf), hüküm REVISE. R-1…R-20'nin işlenişi §11'dedir.
- D2: `denetim/VH95RA_On_Kayit_denetimi_D2.md` (sha256 791af35e1d2e595f652314db3cb9a39b7af5daa3d2b445978e7907ce1136031a), hüküm REVISE. Esaslı bulgu yoktur. M-1…M-7 bu belgeye mekanik düzeltme olarak işlendi (§13). Üçüncü tur yapılmadı. Emsal: SABİT v1.3 §12.
- Dayanak: D-266, D-267, D-269, D-270, D-271. Kullanıcı kararı 2026-11-06: seçenek (b).

## 1. Statü

**SABİT.** Bu belge kendi başına yürütme yetkisi vermez. Yürütme ancak B1–B3 ve yetki dosyası tamamlandıktan sonra kullanıcı onayıyla yapılır. Eşikler, kurallar ve karar tablosu bundan sonra değiştirilmez.

Yürütme sırası:
1. ayrı oturumda bağımsız denetim (D2);
2. SABİT;
3. `tek-kosu-kapisi`:
   - B1: betik;
   - B2: statik ve sentetik sınama, sentetik kampanyada uçtan uca;
   - B3: bağımsız kod denetimi;
   - yetki (kullanıcı onayıyla);
   - B4: ayrı oturumda tek analiz;
   - B5.

**Sapma ve statü beyanı.** Bu analiz sonuç görüldükten **sonra** yazılmıştır. Görülenler: VH95 hükmü (NOT_EVALUABLE), 10 koşunun σ̂ değerleri ve dolgulu koşuların `physics` alanları. Yeni bir örneklem değildir.

VH95-RA hükmü, sonucu ne olursa olsun **keşif niteliğindedir (exploratory).** VH95 hükmünü (D-270) değiştirmez, onun yerine geçmez; ikisi yan yana raporlanır. Anahtarlamalı model için doğrulayıcı (confirmatory) bir iddia yalnız kör bir örneklemden gelebilir: VH96 ya da sonrası. **VH96'nın açılıp açılmayacağı VH95-RA sonucundan bağımsız olarak kullanıcıya bırakılır** (R-14).

## 2. Soru, kapsam, dayanak

**Soru.** SABİT v1.3 §5–§8 değiştirilmeden ve yalnız P-1 ön-işlemesi (§5.1) eklenerek uygulandığında, mühürlü VH95_20261106_a kayıtlarında H1'in hükmü nedir?

| Sınama ya da ögesi | Dayanak | Değişiklik |
|---|---|---|
| H1 (AGREE / DISAGREE / UNDETERMINED) | SABİT v1.3 §6 | Yok |
| Kapılar | SABİT v1.3 §5.6 | P-1 sonrası dizilerde değerlendirilir. Enerji kapısının başlangıcı §5.1(b)'de beyan edilen sapmaya tabidir. |
| Kestirici, eşikler, belirsizlik | SABİT v1.3 §5.5, §5.8, §7 | Yok |
| Karar tablosu | SABİT v1.3 §8 | Satır 1'e ABORT nedenleri eklenir (X-0…X-4, HATA). Satır 2–6 aynıdır. |

**Göstermez:**
- yeni bir kör örneklem ya da doğrulayıcı bir sonuç;
- yakalama kaymasının kaynağı;
- F_m adım duyarlılığının açıklaması;
- fiziksel ya da HIL doğrulaması;
- VH95 hükmünün iptali.

**Kanıt tavanı: E4** (SABİT v1.3 §2). E5 ya da E6 iddiası yoktur.

**Hüküm → hipotez statüsü (R-13).** Her satır "keşif niteliğinde" etiketiyle yazılır.

| Hüküm | Statü |
|---|---|
| RET | Keşif amaçlı yeniden analizde H1 ile çelişen bir vaka bulundu. RET yalnız A2-F00138, F2-0.65-0.20 ya da A2-F01921'den gelebilir (§3 tablo B); A2-F01921'de D'nin bir bileşeni görülmüştür. |
| TUTARLI / KISMİ | "Düzeltilmiş, ön-kayıtlı, keşif amaçlı yeniden analizde tutarlı." Kabul ettirici değildir. Altı vakanın üçünde etiket ya sabittir ya da DISAGREE'ye kapalıdır (§3 tablo B). |
| BELİRSİZ | Değerlendirilebilirlik sağlandı, ama ayrım ya da kapsam yetmedi. VH95'ten farklı bir hükümdür. |
| NOT_EVALUABLE | VH95 ile aynı sınıftaki hüküm; yeni bilgi yoktur. |
| ABORT | Hüküm verilmez. §9'daki yeniden deneme kuralına tabidir. |

## 3. Körleme (K-1; yazar beyanı, doğrulanabilirliği LOW CONFIDENCE)

**Tablo A — nicelikler**

| Nicelik | Durum | Kaynak |
|---|---|---|
| VH94 hükmü ve A2-F00993 değerleri | Körleme dışı | VH94 B5 |
| VH95 hükmü, 6 etiket, A2-F00993'ün D ve u_D değerleri; A2-F00993'ün dört koşusunun σ̂, σ̂' ve R² değerleri (R-10) | Körleme dışı | `hukum.txt`, `sonuc.json`, VH95 B5 G-3 |
| Kapıyı geçen 10 koşunun σ̂, σ̂', R², t_b değerleri | Körleme dışı | `sonuc.json` (VH95 B5 G-3/G-4) |
| Dolgu sayısı, t0, dt, saat hizası (24 koşu) | Körleme dışı | `zaman_sonda_cikti.txt` |
| **Dolgulu 14 koşu:** t_b, kesme bayrağı, pencere NE durumu, tepe modülasyonu ve dc/enerji dışındaki bütün kapı sonuçları | **Kısmen öngörülebilir (R-9).** Bunlar P-1'den bağımsızdır ve VH95'te görülmüştür. Pencere NE'si yoktur; dc/enerji dışındaki kapıların hepsi geçti. | `sonuc.json` `physics`/`gates` |
| Dolgulu 14 koşunun P-1 sonrası dc ve enerji kapısı, σ̂, σ̂', q1–q3 değerleri | Körlenmiş | Hesaplanmadı |
| y (v2d_pm, v2q_pm) zaman serileri | Görülmedi | Sondalar y'ye dokunmadı |

**Değerlendirilebilirlik öngörüsü (R-9).** Dolgulu koşularda belirsiz kalan yalnız iki şey vardır:
- P-1 sonrası dc ve enerji kapıları;
- q1–q3.

Yazar, satır 2'nin (NOT_EVALUABLE) muhtemelen geçileceğini RA kararından önce öngörebiliyordu (INFERENCE).

**Tablo B — vaka başına körlük (R-8).** Tanımlar: D = σ̂_F,25 − σ̂_R,25 (`analyze_vh94.py` 229). u_run = max(|σ̂_25 − σ̂_50|, |σ̂ − σ̂'|).

| Vaka | Sınıf (s_pred) | Görülen koşular | D | u_D | Olası etiketler |
|---|---|---|---|---|---|
| A2-F00993 | iyimser (−1) | 4/4 | Bilinen (−23.13) | Bilinen (6.01) | **AGREE** (X-3 ile sabit) |
| A2-F00357 | iyimser (−1) | R_m 25, F_m 25 | Bilinen (≈ −10.61; öngörü yönünde) | Kısmen: 50 ns σ̂'ler kör | AGREE / UNDETERMINED / NE. **DISAGREE olanaksız.** |
| A2-F01921 | iyimser (−1) | F_m 25 (−5.775) | Yarı: σ̂_R,25 kör | Kısmen | AGREE / DISAGREE / UNDETERMINED / NE |
| A2-F00138 | tutucu (+1) | Yok | Kör | Kör | AGREE / DISAGREE / UNDETERMINED / NE |
| F2-0.65-0.20 | tutucu (+1) | R_m 50 (+0.155) | Kör (iki 25 ns koşusu kör) | Kısmen | AGREE / DISAGREE / UNDETERMINED / NE |
| F2-0.60-0.20 | tutucu (+1) | R_m 25, F_m 25 | Bilinen (≈ +10.49; öngörü yönünde) | Kısmen: 50 ns σ̂'ler kör | AGREE / UNDETERMINED / NE. **DISAGREE olanaksız.** |

**Kanıt ağırlığı.**
- Hükmün gerçekten kör kısmı şunlardır:
  - A2-F00138 tamamen;
  - F2-0.65-0.20'nin D'si;
  - A2-F01921'in σ̂_R,25'i;
  - A2-F00357 ile F2-0.60-0.20'nin u_D'si, yani eşik geçişi.
- Satır 2 için en az 2 tutucu gerekir: A2-F00138, F2-0.65-0.20, F2-0.60-0.20.
- Olumlu bir sonucun bir kısmı görülmüş verilerden öngörülebilirdi. Bu nedenle §1'deki "keşif niteliğinde" statüsü bağlayıcıdır.

## 4. Pinler (tam yol, bayt, SHA256)

| Dosya | Bayt | SHA256 |
|---|---|---|
| `C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme94_20261029\protokol\VH94_On_Kayit_v1.3_SABIT.md` | 40367 | ae8628bd9f05aeafb0a95f0b6d001fe64efe90c53cef2001facc26d1856b999d |
| `C:\Users\onura\Documents\SEGAN_G94_work\vh94\vh94_run.py` | 24801 | ed11d0082c785cdca0db70a4dc992e45c8e007d974e5745a2878b30f725cfe0f |
| `C:\Users\onura\Documents\SEGAN_G94_work\vh94\analyze_vh94.py` | 11408 | a8df777e5b83a03af2ac112dbeb809db019eaa28c1c0a56846c86251f1fd0d68 |
| `C:\Users\onura\Documents\SEGAN_G94_work\vh94\vh94_synth.py` | 12573 | 8ddea8eec617c8d63263d8504390fc2954a573fd15e6d60649fa46dd9d960432 |
| `C:\Users\onura\Documents\SEGAN_G94_work\vh94_pilot\vh94_pilot.json` | 37235 | 21e56aa6d6a8687603e8b8c26715341d1bcbef8c899fd488c7604fb2dc6099d0 |
| `C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme94_20261029\denetim\VH94_kod_denetimi_B3b.md` | 5792 | 515bef3674af79927b14ff66c1088e9956c3e43414b276820c8f2733e5dfaddf |
| `C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme94_20261029\protokol\VH95_yetki_VH95_20261106_a.json` | 1580 | 3646b50fe21eb0a0816f3cfcb15f36ad3d4f98b2591afa0d0053fa0e36363e68 |
| `C:\Users\onura\Documents\SEGAN_G94_work\vh94\out\VH95_20261106_a\campaign_ledger.jsonl` | 10175 | a1040553d1ede402ffa041e162951bd968b97d44bb1e0f8d70a428d90d2760cf |
| `C:\Users\onura\Documents\SEGAN_G94_work\vh94\out\VH95_20261106_a\analysis_VH95_20261106_a\SHA256SUMS` | 472 | f6db2fe9c197f8ed39cb134243f0fd98cfebb34f51d97ede607f9303779d59a6 |
| `C:\Users\onura\Documents\SEGAN_G94_work\vh94\out\VH95_20261106_a\analysis_VH95_20261106_a\sonuc.json` | 48572 | 084cec660fd6ea913308a9a5e73481985c690356ba94af0423b84527f5f81679 |
| `C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme94_20261029\rapor\VH95_sonuc_raporu_B5.md` | 8971 | b1a148210dc9728a2e65f9632d8937fcf7622e3efbae418b0418b44785fac716 |
| `C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme94_20261029\rapor\VH95_rapor_ek\zaman_sonda.py` | 1204 | 0ce3429664c03c88d4ef5eebe1578d15d5c0da11e1c66d5a72f75774625e8f75 |
| `C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme94_20261029\rapor\VH95_rapor_ek\zaman_sonda_cikti.txt` | 5115 | 6f8b2b895feabeb95b5df488c8a81a49f3255f40869acd008d4b7c5341a94c74 |
| `C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme94_20261029\rapor\VH95_rapor_ek\sifir_sonda.py` | 917 | 0fa2131baffa2b8b293a2eda39608c21238b4005f0cc5da0f15021d741c5857e |
| `C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme94_20261029\rapor\VH95_rapor_ek\sifir_sonda_cikti.txt` | 2902 | a782d7008fee30ad7e3deabc2bfa31d71e04eb614d96074bc77e456ba6cab9a0 |
| `C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme94_20261029\rapor\VH95_rapor_ek\zaman_hassasiyet_sonda.py` | 1079 | a8d61e2c78decbe89ed8fa96ce099b311e16cab58edea908dfe67fe42c9047fc |
| `C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme94_20261029\rapor\VH95_rapor_ek\zaman_hassasiyet_sonda_cikti.txt` | 3524 | 16fbf87c00bc8ab10fa6329c3faaf93d0fbf962481d2f1488b118ef1dc790f60 |
| `C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme94_20261029\denetim\VH95RA_On_Kayit_denetimi_D1.md` | 28176 | 8e0997e6c6bbc5cdcf74755d62e4ae1be4ec9b12052c9c3aa2500f92f03464cf |
| `C:\Users\onura\OneDrive\Desktop\EN YENİ MAKALEM\research_intelligence\gelistirme94_20261029\denetim\VH95RA_On_Kayit_denetimi_D2.md` | 22470 | 791af35e1d2e595f652314db3cb9a39b7af5daa3d2b445978e7907ce1136031a |

**Liste pinleri (R-19, R-20).** Her listede satır biçimi `sha256  klasör_adı`dır. Satırlar klasör adına göre **ordinal** sıralanır (Python `sorted` sırası), LF ile ayrılır ve liste sonda bir LF ile biter. Liste metninin SHA256'sı:

| Liste | SHA256 |
|---|---|
| 24 `capture.npz` | d0e0586ef9216a51fae7f6520ff74075768a77f58c615af6c4598c2ea7f63a97 |
| 24 `run_status.json` | 85d6eda45e36a61067fb5d0d35bcbee5ad17909e083e6c06e216f0fe99505c00 |

**Ortam (R-5).** Python 3.13.2 / NumPy 2.5.3, SABİT v1.3 §4 satır 83'teki analiz sürümü (2026-11-06'da `python -I` ile okundu).

`girdi_pinleri.json` şunları kaydeder:
- sürümler;
- `numpy.show_config()` özeti;
- iş parçacığı değişkenleri: `OMP_NUM_THREADS`, `OPENBLAS_NUM_THREADS`, `MKL_NUM_THREADS`, `NUMEXPR_NUM_THREADS`.

Betik bu değişkenleri değiştirmez. Süreç önceliği değiştirilebilir, çünkü öncelik iş parçacığı sayısını değiştirmez. Sürüm uyuşmazlığı X-0'dır.

Pinli kod (`vh94_run.py`, `analyze_vh94.py`) **değiştirilmez.**

## 5. Tanımlar

### 5.1 P-1: sondaki sıfır dolgunun ayıklanması

Her `capture.npz` için şu alanlar kullanılır:
- `time_s` (T);
- `values` (V: kanal × satır);
- `signal_names`;
- `simulation_clock_s` kanalı (C).

0. **Biçim ön-uçuşu (R-4).** Değer okunmadan, yalnız npz başlığından `time_s` türü tam olarak float64, `values` türü tam olarak float32 olmalıdır (v1.1, §14 V-1). Değilse koşu ABORT olur (X-0, "kayıt biçimi"). Ön-uçuş bütün kayıtlarda kestiriciden önce yapılır.
1. **Geçerli önek.** k = 1 + (T > 0 olan son indeks). T > 0 olan satır yoksa koşu NE ("dolgu-yapı").
2. **Kuyruk.** İndeksi ≥ k olan bütün satırlarda T = 0 ve V'nin bütün kanalları tam olarak 0 olmalıdır. NaN sıfır sayılmaz. Sağlanmazsa koşu NE ("dolgu-yapı").
3. **Sınır ve yapı (R-3).** Şunların hepsi sağlanmalıdır, değilse koşu NE ("dolgu-sınır"):
   - pad = len(T) − k ≤ PAD_MAX = 100;
   - len(T) = `run_status.capture_rows`;
   - |T[0] − (1 + pad)·10⁻⁴| ≤ 10⁻⁶ s (M-1).
   
   Bu koşul, "baştaki kayma = sondaki dolgu" gözlemini kurala bağlar. pad ≤ 100 olduğu için T[0] ≤ 0.0101 + 10⁻⁶ s olur.
4. **Zaman hizası.** Önekte şunlar sağlanmalıdır, değilse koşu NE ("zaman-hiza"):
   - max |T − C| ≤ 10⁻⁶ s. `time_s` saat kanalının kendisi olarak yakalandığından (`run_vh94.py` 112) bu denetim önekte kendiliğinden sağlanır. Yalnız yapısal bir tutarlılık denetimidir, bağımsız bir zaman kanıtı değildir (M-6);
   - ardışık farklar 10⁻⁴ ± 10⁻⁶ s;
   - |T[k−1] − 1.8| ≤ 10⁻⁶ s.
5. **Dilimleme.** Sonraki bütün işlemler önek dizileri üzerinde yapılır: T[:k], V[:, :k] ve bunlardan türeyen bütün kanallar (`y` dahil). Bu işlemler `window_end`, `run_gates`, `estimate_run`, `vdc` raporu ve `latch_settling`'dir.

**(a) P-1'in değiştirdiği nicelikler (R-2).** `run_gates` içinde şu üç nicelik değişir (`analyze_vh94.py` 191, 193, 204):
- `kb`: son gerçek satırın indeksi;
- `dcmin`: dolgu sıfırları artık dahil değildir;
- `peak_modulation_run`: `[-1]` artık son gerçek satırdır.

`window_end`, kesme ve öteki kapılar P-1'den etkilenmez (INFERENCE). Çünkü dolgu satırlarının zamanı T = 0'dır ve bu satırlar t > t_a pencerelerine girmez. `noise_floor` ve T_REF aralıkları da dolgu satırlarını içermez.

**(b) Kayıttan gelen baş eksikliği (beyan edilen sapma).** Dolgulu kayıtlarda ilk satır T[0] = (1+pad)·10⁻⁴ s'dir. Enerji kapısı E[0] ve B[0] yerine bu satırı kullanır, yani [T[0], t_b] üzerinde değerlendirilir. Bu, SABİT v1.3 §5.6'daki "[0, t_b]" tanımından küçük bir sapmadır. Dolgusuz kayıtlarda da T[0] = 10⁻⁴ s'dir. Kayma ≤ 1.01·10⁻² s'dir ve 0.30 s'deki bozulmadan çok öncedir (INFERENCE).

**Satır kapısı.** `capture_rows` ile `expected_rows` karşılaştırması `run_status.json` üzerinden aynen kalır.

### 5.2 Çapraz denetimler ve yürütme sırası (R-5, R-6, R-7, R-11)

Betik denetimleri **bu sırayla** yapar. Bir adım başarısız olursa ABORT yazar ve durur.

| # | Denetim | Ne zaman | Başarısızlıkta |
|---|---|---|---|
| X-0 | Ortam sürümü (§4); bütün kayıtların biçim ön-uçuşu (P-1 madde 0) | İlk | ABORT |
| X-1 | SABİT v1.3 §8 satır 1'in bütünlük maddeleri: pinler (§4 dahil), ledger WHEA, protokol dışı senaryo, `_basarisiz_` klasörü, kayıt hash'i ile `run_status.capture_npz_sha256` eşitliği | X-0'dan sonra | ABORT |
| X-2 | §4'teki iki liste pini; VH95 `SHA256SUMS`'ün yeniden doğrulanması | X-1'den sonra | ABORT |
| X-3 | **Yeniden üretim (pad = 0).** Aşağıda. | X-2'den sonra, **dolgulu hiçbir kayıtta kestirici çağrılmadan önce** | ABORT |
| X-4 | **Dolgulu yol denetimi (pad > 0).** Aşağıda. | X-3'ten sonra, dolgulu kayıtlarda kestiriciden önce | ABORT |

**X-3 ayrıntısı.**
1. P-1 ile hesaplanan pad = 0 kümesi, VH95'te kapıyı geçen koşu kümesine eşit olmalıdır. "Kapıyı geçen" şu demektir: VH95 `sonuc.json`'da `cases.<cid>.runs.<senaryo>@<adım>.ne` alanı yoktur, ya da `"kapı:"` ile başlamayan bir değerdir; buna `null` da dahildir (M-3). Gözlenen: 10 koşu, iki küme aynı.
2. Bu kümedeki her koşu için RA'nın ürettiği run sözlüğünün tamamı karşılaştırılır (`gates`, `physics`, `t_b`, `fit`, `fit_variant`, `sigma`, `sigma_variant`, `q1`–`q3`, `ne`, `vdc_report` …). RA'nın eklediği `pad` ve `p1` alanları çıkarılır. Karşılaştırılan nesne VH95 `sonuc.json`'daki `cases.<cid>.runs.<senaryo>@<adım>` nesnesidir.
3. Eşitlik ölçütü: iki taraf aynı biçimde serileştirilir, `json.dumps(obj, sort_keys=True, ensure_ascii=False, default=float)`, ve **metinler** eşit olmalıdır. Bu ölçüt NaN ve None durumlarını da belirler.
4. A2-F00993 vaka nesnesinde `label`, `D`, `u_D` ve `threshold` aynı ölçütle eşit olmalıdır.
5. pad = 0 olan bir koşuda P-1 NE'si çıkarsa bu X-3 uyuşmazlığıdır ve sonuç ABORT olur. Gerekçe: bu koşuların zaman hizası VH95'te görülmüştür, böyle bir NE uygulama hatasıdır.

**X-4 ayrıntısı.** pad > 0 olan her koşu için RA, P-1 sonrası dizilerden VH95 `sonuc.json` ile **metin olarak eşit** şu alanları üretir:
- `physics.t_b`;
- `physics.peak_modulation_to_tb`;
- `gates` nesnesinden `dc` ve `energy` çıkarıldıktan sonra kalan bütün alanlar.

Bu denetim, dolgulu yoldaki dilimleme hatalarını kör değer görmeden yakalar. Bir koşu P-1 NE'si alırsa (madde 1–4) X-4'e girmez ve vakası NE olur.

**Sıra güvencesi.** X-0…X-4'ün hepsi geçmeden dolgulu kayıtlarda `estimate_run` çağrılmaz. B2 bunu sınar (S-RA12).

**Kestirici öncesi ABORT'ta çıktı (M-7).** X-4 için `run_gates` dolgulu koşularda çalışır ve bu sırada körlenmiş `dc`/`energy` kapı sonuçlarını ve `physics.minimum_dc_to_tb`/`energy_relative_to_tb` değerlerini hesaplar. Kestiriciden önce ABORT olursa bu değerler hiçbir çıktıya yazılmaz; `ra_karsilastirma.json` yalnız X-4 alanlarının eşit ya da eşit değil sonucunu yazar. Normal tamamlanmada ise bu değerler `sonuc.json`'a VH95 ile aynı biçimde yazılır.

### 5.3 Değişmeyenler

SABİT v1.3 §5–§6 ile aynı kalanlar:
- vakalar ve öngörüler;
- kestirici, eşikler ve kalite ölçütleri;
- belirsizlik;
- H1 ve R-1…R-7.

## 6. Sınamalar

**H1 (birincil).** SABİT v1.3 §6 ile aynı. Koşular P-1 sonrası dizilerle değerlendirilir.

**Yalnız rapor:**
- R-1…R-7 (v1.3);
- RA-1: koşu başına pad, T[0] ve P-1 sonucu;
- RA-2: VH95 ve VH95-RA etiketleri yan yana;
- RA-3: X-3 ve X-4 karşılaştırma özeti.

## 7. Eşik gerekçesi ve çatallanma beyanı

- SABİT v1.3 §7'deki bütün eşikler aynen kalır.
- **PAD_MAX = 100 satır (0.01 s).** Dolgu yapısı görüldükten sonra yazıldı; gözlenen en büyük dolgu 14 satırdır.
  - 0.01 s, ilk analiz aralığı T_NOISE'ın (0.20 s) 1/20'sidir.
  - Daha sıkı bir sınır gözlenen değere ayarlanmış olurdu. Daha gevşek bir sınırın gerekçesi yoktur.
  - Gözlenen değerler sınırın çok altında olduğundan PAD_MAX sonucu yönlendiremez.
- **Zaman toleransı 10⁻⁶ s (M-1; D2 N-1).** `time_s` float64 dizisidir, ama değerleri float32 ızgarasındadır (`controller_code_vh94.py` 89: `(real)elapsed_tick*dt`). Ölçülen en kötü sapmalar (`rapor/VH95_rapor_ek/zaman_hassasiyet_sonda_cikti.txt`; yalnız zaman dizisi okundu):
  - adım farkı: 1.03·10⁻⁷ s;
  - son satır: 4.8·10⁻⁸ s;
  - başlangıç: 5.0·10⁻⁸ s.

  10⁻⁶ s bunun yaklaşık 10 katıdır ve örnek aralığının (10⁻⁴ s) %1'idir. Bu yüzden tek satırlık kayma hâlâ yakalanır. v0.2'deki 10⁻⁹ s ve "float64 gösterimi" gerekçesi olgusal olarak yanlıştı. Çatallanma: 10⁻⁶ s, ölçülen sapmalar görüldükten sonra seçildi; ölçülen değerler yalnız zaman dizisidir ve hükmü belirleyen niceliklere dokunmaz. Biçim ön-uçuşu (madde 0) yalnız depolama türünü (`time_s` float64, `values` float32) denetler, hassasiyeti denetlemez.
- **P-1'in seçilmemiş eşdeğerleri (R-15).** Şu kurallar gözlenen kayıtlarda aynı diziyi verir (INFERENCE):
  - "T > 0 maskesi";
  - VH95 B5'teki "≥ 0.999 kapsama" önerisi;
  - "son pad satırı at".
  
  Daha sıkı yapı denetimleri içerdiği için P-1 seçildi.
- **Çatallanma.** Yeniden analiz kararı şunlar görüldükten sonra verildi:
  - VH95 hükmü;
  - 10 koşunun σ̂ değerleri;
  - iki vakanın 25 ns D değeri;
  - dolgulu koşuların t_b ve kapı durumları.
  
  Olumlu bir sonuç kısmen öngörülebilirdi (§3). Bu riski şu kurallar sınırlar:
  - hükmün keşif statüsü (§1, §2);
  - VH96 kararının sonuçtan bağımsızlığı (§1).
  
  Seçilmeyen alternatifler: (a) olduğu gibi raporlamak, (c) VH96. Eşikler sonradan değiştirilmez.

## 8. Sıralı karar tablosu (ilk eşleşen satır hükmü verir)

| # | Koşul | Hüküm |
|---|---|---|
| 1 | X-0, X-1, X-2, X-3 ya da X-4 başarısız; ya da betik istisnası (HATA) | ABORT |
| 2 | Değerlendirilebilir vaka < 4, ya da değerlendirilebilir iyimser < 2, ya da tutucu < 2 | NOT_EVALUABLE |
| 3 | En az bir DISAGREE | RET |
| 4 | AGREE < 3, ya da AGREE vakaları arasında iyimser yok, ya da tutucu yok | BELİRSİZ |
| 5 | Satır 4 geçildi ve en az bir UNDETERMINED | KISMİ |
| 6 | Değerlendirilebilir vakaların hepsi AGREE | TUTARLI |

**Sonuç uzayı (R-12).**

| Öge | Olası sonuçlar | Etki |
|---|---|---|
| P-1 (koşu başına) | geçer, dolgu-yapı, dolgu-sınır, zaman-hiza | Geçmeyen her koşu NE'dir ve vakayı NE yapar (`case_verdict`, `analyze_vh94.py` 224–226). pad = 0 koşusunda NE çıkarsa X-3'e göre ABORT. Biçim ön-uçuşu başarısızsa X-0'a göre ABORT. |
| X-0…X-4 | geçer, başarısız | Başarısız → satır 1 |
| HATA | var, yok | Var → satır 1 |
| H1 (vaka başına) | AGREE, DISAGREE, UNDETERMINED, NE | Satır 2–6 |

**Tamlık.** Satır 2–6 SABİT v1.3 §8 ile aynıdır ve tamlık gerekçesi oradadır. Satır 1 yalnız ABORT nedenlerini genişletir.

**Hüküm metni:** `VH95-RA hüküm: … (satır n) [keşif niteliğinde]`.

## 9. Yürütme biçimi

**Betik.** `C:\Users\onura\Documents\SEGAN_G94_work\vh94\vh95ra_run.py`.
- Bağımlılık: stdlib + numpy.
- Typhoon çağrısı, alt süreç ya da ağ erişimi yoktur.
- Modlar: `--check-only`, `--verify --run-id --yetki`, `--analyze --run-id --yetki --campaign --out`.

**Pinli kodun kullanımı (R-1).**
- `vh94_run` ve `analyze_vh94` modülleri içe aktarılır, hash'leri §4 ile karşılaştırılır. Bu karşılaştırma X-1'in parçasıdır.
- Sarmalama tek bir atamayla yapılır: `vh94_run.load_capture = load_capture_ra`. `latch_settling` modül adı üzerinden çağırdığı için (`vh94_run.py` 260) bu atama onu da kapsar.
- `vh94_run.analyze` P-1 NE'sini taşıyamaz. Ayrıca kestiriciyi vaka vaka çağırır ve bütünlük hatalarını sona kadar biriktirir (`vh94_run.py` 199–239). Bu yüzden RA, **iki geçişli** bir kopya kullanır: `analyze_ra` (M-2; D2 N-2).

  **Geçiş 0 — bütünlük.**
  - X-0 ve X-1 bütünüyle yapılır: ortam, biçim ön-uçuşu, pinler, ledger, `_basarisiz_` klasörü, kayıt hash'leri.
  - Ardından X-2 yapılır.
  - Herhangi biri başarısızsa ABORT yazılır ve betik durur. v1.3'teki gibi biriktirip sona bırakmaz.

  **Geçiş 1 — kestirici öncesi (24 koşu, vaka ve koşu sırasıyla).**
  - Her kayıt `load_capture_ra` ile yüklenir; P-1 burada uygulanır.
  - P-1 NE'si olan koşu için: `ne='p1:<neden>'` yazılır.
  - Öteki koşular için `window_end`, `run_gates` ve `input_hash_ok` çağrılır.
  - pad = 0 koşularında yalnız bu geçişte `estimate_run` (ve `vdc` raporu) çağrılır. Böylece X-3'ün run sözlükleri tamamlanır.
  - Geçiş sonunda önce X-3, sonra X-4 değerlendirilir. Biri başarısızsa M-7 kuralıyla ABORT yazılır ve betik durur.

  **Geçiş 2 — dolgulu kestirici.**
  - pad > 0 olan ve kapıyı geçen koşularda `estimate_run` ve `vdc` raporu çağrılır.
  - Ardından vaka sırasıyla şunlar çağrılır: `case_verdict`, `report_items`, R5/R6 alanları, `latch_settling` (sarmalanmış yükleyiciyle) ve en sonda `campaign_verdict`.

  **B3'ün satır satır doğrulayacağı fark listesi** (`analyze_ra` ile `vh94_run.analyze` arasında; başka fark yoktur):
  - (F-1) yükleyici `load_capture_ra`'dır;
  - (F-2) P-1 NE'si `dict(ne='p1:<neden>', pad=…, p1=…)` olarak yazılır ve `est[key] = None` olur; bu, v1.3'teki "kayıt yok" yolunun eşdeğeridir;
  - (F-3) bütünlük denetimleri Geçiş 0'da yapılır ve başarısızlıkta erken durulur;
  - (F-4) döngü Geçiş 1 ve Geçiş 2 olarak bölünür; X-3 ve X-4 ikisinin arasında yapılır;
  - (F-5) her run sözlüğüne `pad` ve `p1` alanları eklenir.

  Run ve vaka sözlüklerinin içeriği, v1.3'teki tek geçişli sıra ile aynıdır; çağrıların sırası sonuçları etkilemez, çünkü işlevler saftır (`analyze_vh94.py` 1–2). X-3 tam eşitliği bunu dolgusuz koşularda sınar.
- Kalan bütün çağrılar (`window_end`, `run_gates`, `input_hash_ok`, `estimate_run`, `case_verdict`, `report_items`, `latch_settling`, `campaign_verdict`) pinli koddan değiştirilmeden yapılır.
- `verify_authorization` ve `write_outputs` RA'ya uyarlanmış kendi sürümleridir; v1.3 yetki ve çıktı biçimleri kullanılmaz.

**Çıktı.**
- Klasör: `C:\Users\onura\Documents\SEGAN_G94_work\vh94\out\VH95RA_<tarih>_a\` (v1.2: tek yeniden deneme için `_b`; §14 V-3).
- **Klasör önceden varsa betik durur** (R-18).
- Çıktı yolu kampanya klasörünün içindeyse betik durur. Bu, `os.path.normcase` + `os.path.commonpath` ile denetlenir.
- İçerik:
  - `sonuc.json`, `hukum.txt`;
  - `ra_dolgu.json` (RA-1), `ra_karsilastirma.json` (X-3, X-4, RA-2);
  - `girdi_pinleri.json` (ortam dahil), `stdout.txt`, `stderr.txt`, `exit_code.txt`, `SHA256SUMS`.
- VH95 kampanya klasörüne yazılmaz.

**Yeniden deneme kuralı (R-5, R-11).**
- B4 bir kez çalışır.
- X-0…X-4 ya da HATA nedeniyle ABORT olursa ve dolgulu hiçbir kayıtta kestirici çağrılmamışsa (`stdout` ve `ra_karsilastirma.json` bunu kaydeder), en çok **bir** yeniden deneme yapılabilir. Koşulları:
  - neden giderilmiş olmalı (ortam ya da uygulama);
  - yeni D-ID;
  - B3 ek denetimi;
  - kullanıcı onayı.
- Dolgulu bir kayıtta kestirici çağrıldıktan sonraki ABORT ya da HATA için yeniden deneme yoktur.

**Statik denetim (AST).** Şunlar sınanır:
- kampanya klasörüne yazma çağrısı olmaması;
- `subprocess`, `socket`, `typhoon` içe aktarımı olmaması;
- modül özniteliği atamasının yalnız `vh94_run.load_capture` için yapılması;
- iş parçacığı ortam değişkenlerine yazılmaması.

**Zorunlu sentetik sınamalar (B2).** Mühürlü kayıtlara dokunulmaz. Bütün sınamalar sentetik npz dosyaları ya da sentetik bir kampanya klasörü üzerinde yapılır.

| # | Durum | Beklenen |
|---|---|---|
| S-RA1 | Dolgusuz kayıt | P-1 özdeşlik: diziler bayt düzeyinde aynı |
| S-RA2 | Dolgu 1, 14 ve 100 satır | Orijinal `load_capture` ile dc ve enerji kapıları düşer (regresyon kanıtı). `load_capture_ra` ile geçer. t_b dolgusuz eşdeğerine tam eşit. Dolgulu kayıt, dolgusuz kayıttan "baştan pad satır at, sona pad sıfır satır ekle" ile üretilir. Bu durumda `estimate_run` çıktısı kanonik JSON metni olarak **tam eşittir** (M-4). Sentetik kayıtta E[0] ≠ B[0] olmalıdır, ki orijinal yükleyicideki enerji düşüşü gerçekten sınansın (M-5). Sentetik zaman dizileri float32 ızgarasında üretilir (M-1). pad = 100'de sınır geçer. |
| S-RA3 | Dolgu 101 satır; ayrıca pad ≤ 100 iken T[0] yapı koşuluna uymuyor | NE "dolgu-sınır" |
| S-RA4 | Kuyrukta sıfır olmayan tek değer; kuyrukta NaN; T > 0 satırı olmayan kayıt | NE "dolgu-yapı" |
| S-RA5 | T ile C arasında 1 örneklik kayma | NE "zaman-hiza" |
| S-RA6 | Önekte düzensiz dt; T[k−1] ≠ 1.8 | NE "zaman-hiza" |
| S-RA7 | float32 `time_s`; float64 `values` (v1.1); ortam sürümü uyuşmazlığı (sahte sürüm enjeksiyonu) | ABORT (X-0) |
| S-RA8 | Sentetik kampanyada `--analyze` uçtan uca. 24 npz + `run_status` + ledger + başvuru `sonuc.json` ve `SHA256SUMS`. | Satır 1'e X-1, X-2, X-3 ve X-4'ün **her biriyle ayrı ayrı** ulaşılır; satır 2'ye P-1 NE'leri yoluyla; satır 3, 4, 5 ve 6'ya; HATA → ABORT yoluna |
| S-RA9 | Çıktı yolu kampanya klasörünün içinde; çıktı klasörü önceden var | Betik durur |
| S-RA10 | X-3'te pad = 0 kümesi VH95 geçen kümeden farklı; pad = 0 koşusunda P-1 NE'si | ABORT |
| S-RA11 | P-1 NE'li R_m 25 ns kaydında `latch_settling` | Sarmalanmış yükleyici kullanılır; R-7 `error` yazılır; analiz sürer |
| S-RA12 | X-3 ya da X-4 başarısız | Dolgulu kayıtlarda `estimate_run` **hiç çağrılmaz** (sayaçla sınanır) |

## 10. Yetki ve kapı

- Yetki dosyası: `protokol/VH95RA_yetki_<run_id>.json`. Alanlar:
  - `action = ALLOW_VH95RA_ANALYSIS`;
  - `run_id`;
  - VH95-RA SABİT'inin hash'i;
  - `vh95ra_run.py` hash'i;
  - pin listesi hash'i;
  - B3 raporu yolu ve hash'i;
  - `campaign_dir`, `out_dir`;
  - ortam sürümleri.
- Yetki, D2 ve B3 ACCEPT verdikten sonra **kullanıcı onayıyla** yazılır.
- B4 ayrı oturumda bir kez çalışır. Yeniden deneme yalnız §9'daki kuralla yapılabilir.

## 11. D1 düzeltme eşlemesi

| D1 | Öncelik | İşlendiği yer |
|---|---|---|
| R-1 | yüksek | §9 "Pinli kodun kullanımı" (`analyze_ra`, modül ataması, AST) |
| R-2 | orta | §5.1 (a)/(b) |
| R-3 | küçük | §5.1 madde 3 (yapı koşulu, `capture_rows`) |
| R-4 | küçük | §5.1 madde 0, X-0, S-RA7 |
| R-5 | yüksek | §5.2 sıra, §9 yeniden deneme, §4 ortam |
| R-6 | orta | §5.2 X-3 (kanonik JSON, tam yol, tüm run sözlüğü) |
| R-7 | orta | §5.2 X-4 |
| R-8 | yüksek | §3 Tablo B, §2 RET satırı |
| R-9 | orta | §3 Tablo A "kısmen öngörülebilir", değerlendirilebilirlik öngörüsü |
| R-10 | küçük | §3 Tablo A satır 2 |
| R-11 | orta | §8 satır 1, sonuç uzayı, X-3 madde 5 |
| R-12 | küçük | §8 sonuç uzayı |
| R-13 | küçük | §2 hüküm → statü tablosu |
| R-14 | orta-yüksek | §1 statü beyanı, §2, §7 |
| R-15 | küçük | §7 |
| R-16 | yüksek | S-RA8 uçtan uca |
| R-17 | orta | S-RA2 kabul ölçütü; S-RA3…S-RA6, S-RA10…S-RA12 |
| R-18 | küçük | §9 çıktı, S-RA9 |
| R-19 | küçük | §4 ordinal sıralama |
| R-20 | küçük | §4 `vh94_synth.py`, `sifir_sonda*`, `run_status` listesi |

## 12. Kontrol listesi eşlemesi

| Madde | Karşılandığı yer |
|---|---|
| K-1 | §3 (Tablo A, Tablo B) |
| K-2 | §4, §5.1, §5.2 (tam alan yolları) |
| K-3 | Mod kimliği v1.3 q1'den değişmez. Zaman kimliği §5.1 madde 3–4'tedir; T − C denetimi yapısal olarak kendiliğinden sağlanır (M-6), ayırt edici olanlar adım, uç ve başlangıç yapısıdır. |
| K-4 | v1.3 ile aynı |
| K-5 | §8 ve sonuç uzayı |
| K-6 | v1.3 ızgarası değişmez |
| K-7 | §7 |
| K-8 | §3 değerlendirilebilirlik öngörüsü. Risk dc/enerji (P-1 sonrası) ve q1–q3'tedir. Yedek aile yoktur; NOT_EVALUABLE'da karar kullanıcınındır. |
| K-9 | §5.1 (a)/(b) |
| K-10 | §2 |
| K-11 | §9 |
| K-12 | Türkçe; etiketler kullanıldı |

## 13. SABİT mekanik düzeltmeleri (D2 → v1.0; 2026-11-06)

| D2 | İşlendiği yer | Düzeltme |
|---|---|---|
| N-1 / M-1 | §5.1 madde 3–4, §7, S-RA2 | Zaman toleransları 10⁻⁹ s'den 10⁻⁶ s'ye çıkarıldı. Gerekçe float32 ızgarası; ölçüm `zaman_hassasiyet_sonda_cikti.txt` (en kötü 1.03·10⁻⁷ s). Sentetik zaman dizileri float32 ızgarasında. |
| N-2 / M-2 | §9 "Pinli kodun kullanımı" | `analyze_ra` iki geçişli (Geçiş 0/1/2). B3'ün fark listesi F-1…F-5. |
| N-3 / M-3 | §5.2 X-3 madde 1 | "Kapıyı geçen koşu" alan tanımı: `ne` yok, ya da `"kapı:"` ile başlamıyor. |
| N-4 / M-4 | S-RA2 | Belirsiz "S1 toleransı" kaldırıldı. Kural: "baştan at + sona sıfır ekle" yapısıyla `estimate_run` çıktısı kanonik JSON'da tam eşit. |
| N-5 / M-5 | S-RA2 | Sentetik kayıtta E[0] ≠ B[0]. |
| N-6 / M-6 | §5.1 madde 4, §12 K-3 | T − C denetiminin yapısal olarak kendiliğinden sağlandığı beyan edildi. |
| N-7 / M-7 | §5.2 | Kestirici öncesi ABORT'ta körlenmiş dc/enerji değerleri çıktıya yazılmaz. |

Bu düzeltmeler eşiklerin hükmü belirleyen kısmına (SABİT v1.3 §5–§8) dokunmaz. Yalnız P-1'in zaman toleransı ve yürütme biçimi değişir. B3, M-1…M-7'nin betikte uygulandığını doğrular.

## 14. v1.1 değişiklikleri (v1.0 B4 ABORT → tek yeniden deneme; 2026-11-07)

| No | Yer | Değişiklik | Gerekçe |
|---|---|---|---|
| V-1 | §5.1 madde 0, §7 (zaman toleransı paragrafının son cümlesi) | X-0 tür pini: `time_s` float64 (değişmedi), `values` float64 → **float32**. Tür tam pinlidir; başka tür ABORT olur. Pinli kod VH95'te float32 girdiyle çalıştı (R-6). | v1.0 B4 ön-uçuşu 24 kaydın hepsinde `values` float32 buldu (`vh94/out/VH95RA_20261107_a/sonuc.json` sha256 1f72e3b50ea71dea5177e194a7addabe581728cf52d6dd0dbf1dcbdffd09dca4, `abort_detay`). Pinli `vh94_run.load_capture` (satır 151–160) `values`'u dönüştürmeden kullanır; dolayısıyla VH95 analizi de float32 ile yapıldı. v1.0'daki float64 şartı olgusal bir varsayım hatasıydı. VERIFIED (kod okuması + ABORT kaydı). |
| V-2 | S-RA7 | Sentetik ABORT durumuna "float64 `values`" eklendi; sentetik kayıtların `values` dizisi float32 olur. | V-1'in sınanması. |
| V-3 | §9 yeniden deneme | Bu sürümle yapılan koşu §9'daki tek yeniden denemedir. run_id `VH95RA_20261107_b`, çıktı `C:\Users\onura\Documents\SEGAN_G94_work\vh94\out\VH95RA_20261107_b`. Bu koşu da ABORT ya da HATA verirse **yeniden deneme yoktur**; hüküm ABORT olarak kalır. Ön koşullar, bu sırayla (R-3): yeni D-ID (D-274: kullanıcı kararı ve v1.1/v1.2); SABİT'e bağlı betik revizyonu (B1 turu 2); B2'nin yeni harfli klasörlerde yeniden yapılması; B3 ek denetimi (v1→v2 farkı ve v1.0→v1.2 farkı); yetki `VH95RA_yetki_VH95RA_20261107_b.json`; kullanıcı onayı (2026-11-07, 'Evet, v1.1 ile dene'; v1.2 metin düzeltmesi bu onayın kapsamındadır); B4 ayrı oturumda tek koşu. | SABİT §9 (R-5, R-11). |
| V-4 | §10 | Yetki ve betik bu belgenin son sabit sürümünün (v1.2) hash'ine bağlanır. v1.0 yetkisi (`VH95RA_yetki_VH95RA_20261107_a.json`) kullanılmaz. | Kapı tutarlılığı. |

Değişmeyenler: §5.1 madde 0 ve §7'nin son cümlesi (V-1) dışında §2–§8'deki bütün kurallar; eşikler, P-1, X-1…X-4, karar tablosu ve körleme tablosu (R-2). §4 pin tablosu aynıdır. V-1, hükmü belirleyen hiçbir niceliğe dokunmaz. Değeri, X-0'ın ölçüm değeri okumadan reddettiği tür bilgisidir. Çatallanma beyanı: tür, v1.0 ABORT kaydında görüldükten sonra pinlendi; bu kayıt yalnız npz başlık türlerini içerir, y, σ̂ ya da kapı değeri içermez.

| No | Yer | Değişiklik (v1.2, D3) | Gerekçe |
|---|---|---|---|
| V-5 | Başlık | Ön-kayıt sapması açıkça beyan edildi (§9 neden koşulu ve §1 değişmezlik). | D3 R-1 |
| V-6 | §14 'Değişmeyenler' | Cümle V-1'i istisna olarak sayacak biçimde düzeltildi. | D3 R-2 |
| V-7 | V-3, §9 klasör satırı | Ön koşullar sırasıyla sayıldı; `_a` şablonu ile `_b` çelişkisi giderildi. | D3 R-3, R-4 |
| V-8 | §14 | values dizisi gerçek kayıtlarda Fortran düzenli (25 × satır, başlıktan; D3). RA yolu tür dönüşümü ya da kopya yapmaz, görünüm kullanır; B3 bunu doğrular. Sentetik kayıtlar float32 ve Fortran düzenli yazılır. Düzen hükmü belirleyen bir kural değildir; X-3 eşitliğini korumak için kayıt altına alınır. | D3 R-5 |
