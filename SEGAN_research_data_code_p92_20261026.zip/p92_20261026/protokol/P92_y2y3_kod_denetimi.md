# P92 Y2/Y3 kod denetimi (y2_newton, y3_limiter, y_common, y_chain, y_summary, y_extra)

Tarih: 2026-10-26. Dayanak: P92_PROTOKOL_v1. Kapsam: Y2/Y3 hesap ve özet betiklerinin kod denetimi.

## §0 Bağımsızlık ve kapsam
- Bu denetim koşu sonrası bir yeniden hesaptır, körleme konusu değildir (protokol §0: girdiler körlenmiş değil).
- Hiçbir benzetim, özdeğer taraması ya da model değerlendirmesi koşulmadı. Yalnız mühürlü jsonl/csv kayıtlarından özet yeniden hesaplandı (`audit_tools/audit_y2y3.py`, `audit_extra.py`, `audit_y3b.py`).
- Tamamen okunanlar: y2_newton.py, y3_limiter.py, y_common.py, y_chain.py, y_summary.py, y_extra.py, P92_PROTOKOL_v1.txt, P92_yetki.json, chain.txt, selftest_y2/y3.
- Kısmen okunanlar: ext_engine.py (rhs, jac, dfdG, dispatch, newton_fixed_refs, port_admittance, crossings, frozen_margin, eig_branch, kappa_hat, reference_margin), ext_common.py (operating_quantities…stage2), ms_v3.txt §6.7–6.10, s2_v2.txt satır 1165 ve 1286.
- Açılmayanlar: körlenmiş S_* dosyaları; S1 eki zip'i (1fe0d2ab… doğrulanamadı, yalnız açılmış dosyalar doğrulandı).

### Hash'ler (SHA-256, yeniden hesaplandı: VERIFIED)
| Dosya | SHA-256 | Pin |
|---|---|---|
| kod/y2_newton.py | 93428a8a031e21024ca338cb3d7381f209bc49b4a504d0e7914e96239b006e65 | OK |
| kod/y3_limiter.py | f1b5c1751be14d64a6aa93a5953242e841317abca84e349008acd51a1d3ac19a | OK |
| kod/y_common.py | 7b16ffbf27dce28fb1932a38705eadbadde2ad1f22c9349c485f6feb523a2970 | OK |
| kod/y_chain.py | 9fcd789584398b1723daeaf7c22c7cc3f40522d801fa497d97f6fdfbfd815696 | OK |
| kod/ext_engine.py | 35d6bd7773b51cce12ca5d5506ab2860f45dcf2f2f217f398ccc76e1a53dbb7f | OK |
| kod/ext_common.py | 63982bfd61cf3a38da8e39ebc470952c8db44b02a11811f712fcc6d38c444c1b | OK |
| kod/y_summary.py | b82865e0e280495fd05bd9fbcb07cb454b41b7802e54965fb8816aa4a98dcaf7 | **pin yok** |
| kod/y_extra.py | 99445c1458dcf6f5e10f5700dff0ffb91ef16b5d7d99990c536eb511a6b49e19 | **pin yok** |
| protokol/P92_PROTOKOL_v1.txt | db8d3110dbebf0cf0b16d25bcf71eaa20c57d27d793bfcfaef3b4fe3fd68d85c | OK |
| protokol/P92_yetki.json | f6fa7fb34aca558c3369cbf3391dbf475ce443564bde6baf7d9fabe4b8fabc3b | — |
| girdi selection.json / points.csv / stage2.jsonl | 2d5a00d8… / 6a099961… / 5edd8475… | protokol §1 ile OK |
| g92out/y2/newton.jsonl | 1ef875bb93672b1403acbd04410413e51f90ccafd834e295f4ec69074324046b | SHA256SUMS OK |
| g92out/y3/limiter.jsonl | edee610def0a7b0639567b89d8bc89ee4867d6531e59e48b649fcb4c35a86630 | SHA256SUMS OK |
| g92out/y3/sample.json | a8bc033b3daffb07be357fd5c4ab984e71446160c984c435310827384ac1531a | SHA256SUMS OK |
| g92out/summary/p92_summary.json · y2_estimators.csv · y3_levels.csv · y_extra.json | cd46d7f5… · 48462921… · 751225fe… · 079456b8… | out_ozet kopyalarıyla bayt-eş |
| g92out/chain.txt | 015a8ad6446f456191e1c65ed3661a61835a1874d821fb6f18fad6e9a5cba9d0 | — |

y2 ve y3 SHA256SUMS'taki her satır tutuyor; listelenen dosyalar klasördekilerle aynı. chain.txt: 8 pinin hepsi 08:48:25'te OK (yetki 08:48:08'de yazılmış). y2, y3 ve y4 birer denemede çıkış kodu 0 verdi, yeniden deneme yok.

## §1 Protokol → kod eşleme
| Protokol | Kod |
|---|---|
| §0/§1 pin, yetki | y_chain.py:25-39 (yalnız kod pinleri; girdi verisi pinlenmemiş, bkz. B-8) |
| §0 tek koşu, devam, SHA256SUMS | y2_newton.py:149-170; y3_limiter.py:109-133; y_common.py:119-124 |
| §2 nokta kümesi, n≠774 ise durma | y_common.py:51-61; y2_newton.py:132-135 |
| ΔG1 = ΔG_f/(1−κ0), κ0≥1 eksik | y2_newton.py:87-92 |
| x1 = x0'dan newton_fixed_refs; F1 tam tarama, ρ>0, min | y2_newton.py:52-63 |
| κ1: J(x1,G−ΔG1)ξ=∂f/∂G; G_R sabit Y; min-ρ kesişmesinde | y2_newton.py:28-49, 64 |
| N1, κ1≥1 eksik | y2_newton.py:103-107 |
| N1s (κ0 ile başlatılmış sekant) | y2_newton.py:102 |
| x2 = x1'den; F2, κ2, N2 | y2_newton.py:111-121 |
| sekant-1/2 ve referans TSV_a'dan | y2_newton.py:73-74 (yalnız kopya); tanım ext_common.py:412, 433-444 |
| H2a/H2b küme-bootstrap (2000, yüzdelik, tohum 20261026) | y_summary.py:47-54; y_common.py:86-98 |
| Ek: MAE, aşma, eksik, duvar saati | y_summary.py:33-45, 55-60; y_extra.py:16-24 |
| §3 örnek: aile başına 24, rng(20261026+i), yerine koymadan | y3_limiter.py:33-39 |
| Sınırlayıcı p=20, kaw=kiv/kpv; Imax=\|i_ref(x00)\|/u_nom | y3_limiter.py:67-71; ext_engine.py:162-168, 249-252 |
| Ayar noktaları sabit, sınırlı denge | y3_limiter.py:72-75 |
| stage1_at(strict=False), stage2(with_exact=False), u0 | y3_limiter.py:76-87 |
| Seviye analizleri, R1/R4, ε2 alt kümesi, Wilson | y_summary.py:63-89; y_common.py:101-108 |
| H3a tek yönlü kesin işaret testi | y_summary.py:90-94; y_common.py:111-116 |
| H3b ≥0.90 eşiği | kodda karar yok; karar metinde verilmiş (y_summary.py:86-87 yalnız oranları üretir) |

## §2 Özet tablo
| # | Konu | Hüküm |
|---|---|---|
| 1 | Newton-κ formülü, N1/N2 adımları, başarısızlık yolu | PASS |
| 2 | κ'nın F'nin türevi olarak kullanımı (κ_at ↔ kappa_hat) | PASS |
| 3 | Sekant, ikinci derece ve referans kaynağı; sızıntı | PASS |
| 4 | Aynı maliyet koşulu | PASS (not) |
| 5 | Hata metriği (MAE, işaret, aşma) | PASS (B-3, B-6 notları) |
| 6 | Bootstrap aralığı | REVISE (B-2) |
| 7 | Nokta kümesi (y2_set) | PASS |
| 8 | Y3: örnek, sınırlayıcı, seviyeler, kullanım ölçüsü | PASS (B-5 notu) |
| 9 | Y3: iyimser tanımı, R1, H3a | PASS |
| 10 | Y3: H3b eşiği ve |ε2| sapması | REVISE (B-1, B-7) |
| 11 | Pin/zincir/mühür bütünlüğü | PASS (analiz betikleri için B-1) |
| 12 | Makale sayılarının yeniden hesabı | PASS (hepsi uyuşuyor) |

## §3 Doğru bulunanlar (kanıt)
1. **Newton-κ.** F(ΔG) = min ρ(x(ΔG); Y'de G) − ΔG ise F'(0) = κ − 1 olur. Buradan 0'dan bir Newton adımı ΔG1 = ΔG_f/(1−κ0) (y2_newton.py:91), ikinci adım N1 = ΔG1 + F1/(1−κ1) (:106), üçüncü adım N2 = N1 + F2/(1−κ2) (:120) çıkar. (0, ΔG_f) ve (ΔG1, F1) üzerinden sekant N1s = ΔG1 − F1·ΔG1/(F1−ΔG_f) (:102) olur. TSV sekant-1 ise ΔG_f²/(ΔG_f−F1) (ext_common.py:435), yani (0,ΔG_f),(ΔG_f,F1) sekantıdır. Hepsi kâğıt üzerinde yeniden türetildi. Kayıtlı ara değerlerden dG1/N1/N1s/N2'nin yeniden hesabında 774 kayıtta 1e-14 üstü fark 0.
2. **κ_at.** ξ, J(x, G−ΔG)ξ = ∂f/∂G ile hesaplanıyor (y2_newton.py:33-36). Bu, ext_engine.py:541-543 ile aynı işaret kuralıdır. Y ve kesişme ise sevk öncesi G ile kuruluyor (:37-47; evaluate :60). Bu, sekant-1'in F_min_at'ı (ext_common.py:397) ve frozen_margin ile aynı kuraldır. Öz-test: üç noktada κ_at(x0) ve ΔG_f mühürlü değerlere bayt düzeyinde eşit (selftest_y2.jsonl).
3. **Sızıntı yok.** dGref, dG_sec1/2, dG2nd, dG1st yalnız kopyalanıyor (y2_newton.py:73-74); hiçbir hesapta kullanılmıyor. Kestirim yalnız aşama-1 büyüklüklerini (ΔG_f, κ0) ve yeni dengeleri kullanıyor. Kopyalanan 7 alan mühürlü points.csv ile 774×7'de birebir. Nokta kümesinin referans durumuna göre (sansürsüz, 'alpha') seçilmesi bir sızıntı değil: protokolün koşullamasıdır ve tüm kestiricilere aynı uygulanır.
4. **Başarısızlık yolu.** Durumlar: ok 764, "step1 no equilibrium" 10. κ0≥1, κ1≥1 ya da N1≤0 hiç oluşmadı. N1 olup N2'si olmayan kayıt yok.
5. **Maliyet.** N1 ile sekant-1 aynı sayıda ek denge çözer: x0'dan bir newton_fixed_refs ve tam tarama. N1 buna ek olarak κ'yı değerlendirir: 4 Jacobian (y2_newton.py:33,37,40,41; Jy, evaluate:60'taki ile aynı ve iki kez hesaplanıyor, yalnız verim sorunu) ve ω'da 3 Schur/özdeğer. Tablo 9'daki † notu bunu söylüyor ("an equilibrium, a frequency scan and the coefficient"), metin de "not as a saving of run time" diyor. Uygun.
6. **Y3.** Örnek bağımsız olarak yeniden üretildi (sample.json ile eşit). iref_gfm (y3_limiter.py:46-54), rhs'nin sınırlayıcı öncesi akım referansıyla terim terim aynı (ext_engine.py:147-161). Sınırlayıcı durum ekleyip çıkarmıyor, bu yüzden sysd'yi kurulumdan sonra değiştirmek güvenli. 288 durum var ve (id, u) anahtarları tekil. H3a: 55 ortak noktada 44'e 0, P = 2⁻⁴⁴ = 5.68×10⁻¹⁴. En kötü durumda bile, yani 0.88'de dışlanan 17 durumun hepsi ters yönde sayılsa (44'e 17), p = 3.6×10⁻⁴ olurdu ve sonuç sağlam kalırdı.
7. **Zincir.** y_chain alt süreçleri `-I` ile çağırıyor. G92_* ortam değişkenleri (PYTHON* değil) alt süreçlere geçiyor; çıkış kodu 3 "bitmiş" anlamına geliyor. Pin denetimi koşudan önce yapılmış.

## §4 Bulgular
**B-1 (orta). Ön-kayıtlı analizlerin kodu koşudan sonra yazılmış ve pinlenmemiş.**
- Kanıt: y_summary.py'nin değişiklik zamanı 10:20:51, y_extra.py'ninki 10:25:17. y3 çıktısı ise 10:13:13'te mühürlenmiş. İki betik de P92_yetki.json:8-17'de yok.
- |ε2| sapması bu betikte (y_summary.py:73). S2 satır 1165 "…pinned, together with the engine, the common module and every run script" diyor. Bu cümle koşu betikleri için doğru, ama okuyucu analiz kodunun da önceden sabitlendiğini anlayabilir.
- Sonuçlar bağımsız yeniden hesapla tutuyor ve H3b hükmü iki okumada da aynı (B-7). Bu yüzden etki yalnız açıklama düzeyinde.
- **R-1:** S2 G'ye şu cümle eklenmeli: "the summary scripts y_summary.py and y_extra.py were written after the run outputs and are not pinned; SHA-256 b82865e0…/99445c14…". Hash'ler yeni bir ek kayda yazılmalı.

**B-2 (orta). Tablo 9 başlığında yanlış yöntem.**
- Başlık "cluster bootstrap, BCa 95%" diyor, ama N1/N1s/N2 satırlarının aralıkları yüzdelik bootstrap ile hesaplanmış (y_extra.py:19 → y_common.py:86-98, np.percentile).
- Ayrıca "küme" pratikte nokta düzeyinde: 774 noktada 773 küme var ve 766 noktada cluster = id. Küme-bootstrap'ın bir korelasyon yapısını hesaba kattığı izlenimi verilmemeli.
- **R-2:** Başlıkta Newton satırları için "percentile cluster bootstrap" yazılmalı ya da † ile ayrılmalı. "Clusters are almost all singletons (773 of 774)" notu eklenmeli.

**B-3 (orta, yorum). N2'nin hatası referansın taban ofseti düzeyinde.**
- N2 − ΔG_t* bütün 764 noktada pozitif: en küçük 4.8×10⁻⁶, medyan 3.5×10⁻⁵, aile medyanları A2/B2/C için 2.1/3.5/5.4×10⁻⁵.
- Buna karşılık |F(N1)| medyanı 6.1×10⁻⁷. Yani N2, F'nin köküne bundan çok daha yakın.
- **INFERENCE:** Kalan fark kestiricinin hatası değil; F kökü ile 'rel' referansı (α ≥ −10⁻¹⁰‖A‖₂, ext_engine.py:609-611) arasındaki tanımsal ofset. Dolayısıyla N2'nin MAE'si (4.1×10⁻⁵) ve H2b farkı (−1.6×10⁻⁵) bu ofsetle aynı ölçektedir.
- Metin bunu nitel olarak söylüyor ("approach the resolution of the reference… overshoot counts are not informative").
- **R-3:** Ofsetin büyüklüğü sayıyla yazılmalı ("all N2 above the reference by 0.5–16×10⁻⁵ pu, median 3.5×10⁻⁵"). H2b, "N2 at the reference resolution; the secant-2 excess is …" biçiminde verilmeli. N2'nin "secant-2'den doğru" olduğu ifadesi, referans tanımına göre olduğu belirtilerek yumuşatılmalı.

**B-4 (küçük).** y2_newton.py:106-110: N1, `N1 > 0` denetiminden önce kayda yazılıyor; bu yüzden negatif bir N1 MAE'ye girerdi. Hiç oluşmadığı için (0 durum) etkisi yok. Not olarak kalabilir.

**B-5 (küçük).** u0 sınırlayıcı öncesi oranı ölçüyor: |i_ref(x0)|/Imax (y3_limiter.py:76). Sınırlayıcı sonrası medyanlarla fark ≤ 0.004 (0.7000/0.8003/0.8512/0.8826). Metinde "utilisation = pre-limiter reference / Imax" diye tanımlanmalı.

**B-6 (küçük).** Tablo 9'daki MAE'ler eşleştirilmemiş ve n değerleri farklı (770, 767, 764). Aynı 763 noktada değerler şöyle: N1 1.11×10⁻⁴, sekant-1 1.24×10⁻³, ikinci derece 1.27×10⁻³, N1s 5.30×10⁻⁴, N2 4.15×10⁻⁵, sekant-2 5.72×10⁻⁵. Sıralama değişmiyor. Başlıkta n'lerin farklı olduğu belirtilebilir.

**B-7 (küçük).** H3b'nin ana metinde (ms_v3 :632, Tablo 8) |ε2| okuması sapma olarak işaretlenmemiş; S2 :1286 (i) bunu doğru anlatıyor. Kontrol: protokolün kelimesi kelimesine okumasıyla (ε2 < 0.5) uyum 58/58, 35/51, 42/60 ve 44/55; H3b yine desteklenmiyor. Ayrıca protokolün istediği Wilson aralıkları Tablo 8'de yok (y3_levels.csv'de var). **R-7:** Metne "(S2 G.6 (i))" atfı ve Wilson aralıkları eklenmeli.

**B-8 (küçük).** y_chain yalnız kod pinlerini denetliyor; protokol §1'deki girdi verisi hash'lerini denetlemiyor. Denetimde girdilerin hepsi tuttu; S1 eki zip'i ise doğrulanamadı.

**B-9 (küçük).** "First hypothesis" iki yerde, farklı anlamlarla geçiyor: §6.7'de H3a, §6.8'de H2a. H2a/H3a etiketleri kullanılmalı. Ayrıca y_summary.py:57'deki "optimistic" etiketi, gözlenen iyimserliği değil κ0 < 0'ı seçiyor. Burada iki küme aynı 18 nokta olduğu için etkisi yok. Yine y_summary.py:57, istisna kaydında kappa0 olmadığı için çökerdi; istisna oluşmadı.

## §5 Makale sayılarının yeniden hesabı
| İddia | Yeniden hesap | Uyuşma |
|---|---|---|
| Y2: 774 nokta | y2_set = 774; kayıt 774; id kümesi eşit | ✓ |
| N1 MAE 1.11×10⁻⁴ (0.87–1.37) | 1.1080×10⁻⁴ (0.8670–1.3718; tohum 20261026) | ✓ |
| sekant-1 1.36×10⁻³ | 1.3626×10⁻³ (n=770) | ✓ |
| ikinci derece 1.47×10⁻³ | 1.4667×10⁻³ (n=774) | ✓ |
| κ ile başlatılmış sekant 5.3×10⁻⁴ | 5.307×10⁻⁴ (n=764) | ✓ |
| N2 4.14×10⁻⁵, en büyük 1.6×10⁻⁴ | 4.143×10⁻⁵; 1.622×10⁻⁴ | ✓ |
| sekant-2 6.31×10⁻⁵ | 6.312×10⁻⁵ (n=767) | ✓ |
| H2a farkı −1.13×10⁻³ (−1.31; −0.97) | −1.1338×10⁻³ (−1.3084; −0.9724); tohum 7 ile (−1.2987; −0.9700) | ✓ |
| H2b −1.6×10⁻⁵ (−2.7; −0.7) | −1.569×10⁻⁵ (−2.685; −0.652) | ✓ |
| ilk Newton 10 noktada başarısız | 10 "step1 no equilibrium" | ✓ |
| N1 aşma 763/764 | 763/764 (N2 764/764; sekant-1 770/770) | ✓ |
| ≈2/3 kazanç başlangıçtan | eşleştirilmemiş 0.66; eşleştirilmiş 0.63 | ✓ |
| Y3: 72 × 4 | 288 durum; değerlendirilebilir 72/72/63/55 | ✓ |
| κ<0: %0/51/92/100 | 0/72, 37/72, 58/63, 55/55 | ✓ |
| gözlenen iyimser: %0/15/60/80 | 0, 11, 38, 44 (payda değerlendirilebilir) | ✓ |
| R1 uyumu 1.00/0.69/0.70/0.80 | 67/67, 36/52, 42/60, 44/55 | ✓ |
| R4 (Tablo 8) 60/28/41/47 | 60/28/41/47 | ✓ |
| \|ε2\|<0.5 uyumu 58/58, 16/18, –/0, –/0 | aynı | ✓ |
| 45 uyumsuzluğun hepsi yanlış alarm; ε2 −4.6…−0.36 | 45 yanlış alarm, 0 kaçırma; ε2 −4.63…−0.364 | ✓ |
| 93 iyimser durumdan hiçbiri kaçırılmadı | 93; κ ≥ 0 olan iyimser durum 0 | ✓ |
| H3a p = 5.7×10⁻¹⁴ | 44 / 0, p = 5.684×10⁻¹⁴ | ✓ |
| H3b desteklenmedi | \|ε2\|: 0.80'de 16/18 = 0.89 < 0.90, 0.85 ve 0.88'de boş; literal okuma: 0.69/0.70/0.80 | ✓ |
| Donmuş marj hatası medyanı +20.1/+9.1/−4.7/−21.4% | aynı | ✓ |
| κ-tetikli kural: güvensiz 0; yalnız donmuş 11/38/44 | aynı | ✓ |

## §6 Düzeltme listesi
| ID | Öncelik | Yer | Düzeltme |
|---|---|---|---|
| R-1 | orta | S2 :1165, ek kayıt | Analiz betiklerinin koşudan sonra yazıldığı ve pinlenmediği belirtilmeli; hash'leri kaydedilmeli |
| R-2 | orta | ms Tablo 9 başlığı | Newton satırları için "percentile cluster bootstrap"; kümelerin neredeyse hepsinin tekil olduğu notu |
| R-3 | orta | ms §6.8 | N2 ile referans arasındaki ofset sayıyla verilmeli; H2b referans çözünürlüğüne göre ifade edilmeli |
| R-4 | küçük | y2_newton.py:106-110 | Sonraki sürümde N1 yalnız N1 > 0 ise yazılmalı |
| R-5 | küçük | ms §6.7 / S2 | u0 tanımı (sınırlayıcı öncesi) yazılmalı |
| R-6 | küçük | ms Tablo 9 | n farkı ya da eşleştirilmiş MAE notu |
| R-7 | küçük | ms §6.7, Tablo 8 | S2 G.6 (i) atfı ve Wilson aralıkları |
| R-8 | küçük | y_chain.py | Sonraki turda girdi verisi pinleri de denetlenmeli |
| R-9 | küçük | ms §6.7–6.8; y_summary.py:57 | H2a/H3a etiketleri; değişken adı |

## §7 Çözülmemiş engeller
Yok. Kodda hesap hatası bulunmadı ve yeniden koşu gerekmiyor. S1 eki zip'inin hash'i bu denetimde doğrulanamadı.

## §8 Genel hüküm
**REVISE.** Düzeltme yalnız metin ve açıklama düzeyinde; kod ve sayılar kabul edilebilir.
- Y2 ve Y3 kodu protokolle uyumlu, formüller doğru, sızıntı yok. Makaledeki sayıların hepsi mühürlü kayıtlardan bağımsız olarak yeniden üretildi.
- Hükmü REVISE yapan en esaslı bulgu B-2 (Tablo 9 başlığında yanlış bootstrap yöntemi) ile B-1 (ön-kayıtlı analiz kodunun koşudan sonra yazılması ve pinlenmemesi; S2'deki pin cümlesinin bunu örtmesi). İkisi de yalnız metinde düzeltilir, kodda değişiklik ya da yeniden koşu gerekmez.
- R-1, R-2 ve R-3 metinde uygulanınca ACCEPT'e dönüşür.

