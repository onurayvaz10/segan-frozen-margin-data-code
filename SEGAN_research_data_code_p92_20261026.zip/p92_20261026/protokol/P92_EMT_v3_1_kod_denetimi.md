# P92-EMT v3.1 (Y5b) kod denetimi: v3.0 → v3.1 farkı

- Tarih: 2026-10-26.
- Kapsam: P92_EMT_v3_kod_denetimi.md sonrası v3.1 revizyon denetimi.
- Kapsam: yalnız v3.0 → v3.1 farkı ve farkın açtığı yeni boşluklar. Ölçüt P92_EMT_PROTOKOL_v3 + v3_1 (D1–D4).
- Revizyon turu: 2/3.
- Bu rapor hiçbir şeye yetki vermez.

## §0 Kapsam
- `--run`/`--selftest` koşulmadı; `g92out\y5v3` açılmadı; model kurulmadı. Kayıtlı değer görülmedi.
- Koşulanlar:
  - `--check-only`: pins OK.
  - Sentetik test (`synth.py <boş klasör>`): 39/39 PASS.
  - Denetçi araçları (model yok): `audit_tools/v31_grid_test.py` (kayıt ızgarasının birebir yeniden üretimi) ve satır farkı.
- Okunan sonuç dışı çıktı: yalnız `g92out/selftest_y5v3.json`.
- Tamamen okunan: y5_emt_v3.py (v3.1), y5_emt_v3_synth.py (v3.1), P92_EMT_PROTOKOL_v3_1.txt.

SHA-256 (VERIFIED):

| dosya | SHA-256 |
|---|---|
| kod/y5_emt_v3.py (v3.1) | caf69f99ddb194f420a99686961516c4db869fcb50c4d1f992b2c43c7dd06797 (beklenen "caf69f99…797" ile uyumlu) |
| kod/y5_emt_v3_synth.py (v3.1) | 2aff7d8f1883177363aced2a6e66c571dab4e2e2083da0049bab6fdfe04b701f |
| archive/y5_emt_v3_v3.0_20261026T135846.py | 30018638a13c37fe29abfebcd43353bf8aa8a5420928fc4b217cc46d4326fc46 (önceki denetimdeki dosya) |
| archive/y5_emt_v3_synth_v3.0_20261026T135846.py | 2b4ec5f0e60635f3d8643c25a470edfb59259d779e4b9b489a8c8753192c7b0c |
| protokol/P92_EMT_PROTOKOL_v3_1.txt | d8d8876adf596912cfe62cb4f3bbfb649da625b870ce7d5dc90d996baa415857 |
| protokol/P92_EMT_PROTOKOL_v3.txt (artık PINS içinde) | 152f0087cd28240c30c81c89ba397ccda723eb6c6c10ba28a00a025590242b6f |
| pin_list_sha256 (--check-only) | 4d1d80ab7ce2e16e8f8ca1d7573fc95b95b34a642922bd9172afad0ded5a94a2 |
| g92out/selftest_y5v3.json | a06b70d4570ec7b2f044d4c5e038a189ac0fadd4cbef2b3cad5c194019462f6f (14:01:25; betik 14:00:39, sonrası) |

Satır farkı: değişiklikler belge dizesi, PROTOCOL/PINS, `_write_text`, verify_authorization, load_rows, departure/sat_until, evaluable E3 satırı, inject/switched_mm, simulate'in `stats`/`cum` kısmı, post_equilibrium, run_case çıktısı, selftest, run_all ve main ile sınırlı. Heun döngüsü, örnekleme ve gecikme, `f` gövdesi ve taşıyıcı değişmemiş. `inject` (v3.1:192-195), v3.0:137-138 formülünün aynısı.

## §1 Özet
| madde | konu | hüküm |
|---|---|---|
| 1 | departure() mantığı ve kenarları (D1) | PASS |
| 2 | sat_until() ve cum ızgarasıyla hizalama (D1 "[0, t_lim]") | **REVISE** (R-6, orta-yüksek) |
| 3 | cum dizilerinin zamanlaması (her W kayıt + son) | PASS |
| 4 | iki kolda ts/vs ızgarasının aynılığı | PASS (küçük not R-8) |
| 5 | D1'in negatif kontrolü (dalgalanma ve örnekleme kaynaklı sahte ayrılma) | **REVISE** (R-7, orta) |
| 6 | post_equilibrium istisna yolu (D2 = R-1) | PASS |
| 7 | load_rows (D4 = R-4) | PASS (küçük not R-9) |
| 8 | verify_authorization öz-test şartı (D4) | PASS (küçük not R-10) |
| 9 | run_all satır sırası, hukum alanları (R-2) | PASS |
| 10 | sentetik test (R-5) ve öz-test (R-3) | PASS |

**Genel hüküm: REVISE** (R-6, R-7).

## Madde bölümleri

**1. departure() PASS** (v3.1:130-139).
- Ortak uzunluk `n = min(...)`. Yalnız iç noktalar `range(W, n−W)` taranır; bu, `np.convolve 'same'` kenar sapmasını (ilk ve son 2 nokta) dışarıda bırakır ve classify'ın `dev[w:-w]` kuralıyla aynıdır.
- `> DEP_THR` katıdır.
- Kol erken durmuşsa ve ayrılma yoksa sonuç `ts[n−W−1]` olur (son iç nokta). D1'deki "ortak uzunluğun sonu" ile tutarlı bir okuma; belge dizesinde beyan edilmiş.
- Hiç ayrılma yoksa `inf` döner; `min(SAT_WIN, inf) = 0.75`.
- Kenar durumları: `n ≤ 2W` ve kırılma varsa `ts[0]`; `n = 0` ise 0.0. İkisinde de t_lim'den önce cum kaydı olmaz, `sat_until → None`, sonuç E3 (D1: "değerlendirme yoksa E3"). Doğru.
- `broke` tanımı (v3.1:327) classify'ın erken bitiş testiyle aynı. Tam koşuda son kayıt 2.7496025 s > T−1e-3 (denetçi aracı), yani yanlış "broke" yok.

**2. sat_until() / hizalama REVISE — R-6 (orta-yüksek).**
- sat_until (v3.1:142-150) cum'da `t ≤ t_lim` olan son kaydı alıyor. Kendi içinde doğru: sentetik testte sınır, arada kalma, inf ve n = 0 durumları geçti.
- Sorun hizalamada:
  - (i) cum yalnız her W = 5 kayıtta tutuluyor (v3.1:267-269). departure() ise her 0.4 ms kaydı tarıyor. Bu yüzden sayım penceresi t_ayr'dan 1.6 ms'ye kadar önce bitiyor.
  - (ii) t_ayr, 7 ondalığa yuvarlanmış `ts` değerinden geliyor (v3.1:328). cum zamanları ise yuvarlanmamış `t` (v3.1:269). t_ayr tam bir cum kaydına denk geldiğinde yuvarlama onu `t_lim`'in altına düşürebilir ve o 2 ms'lik blok da dışarıda kalır.
- Denetçi aracı (`v31_grid_test.py`, simulate'in t birikimini birebir yeniden üretir):
  - en büyük açık 2.0 ms;
  - hizalı 1373 ayrılma indeksinin 458'inde kendi cum kaydı yuvarlama yüzünden düşüyor;
  - t_lim = 0.75 için açık 0.40 ms (zararsız).
- Neden önemli: D1 doymanın "[0, t_lim] içinde" sayılmasını istiyor. Ayrılmadan hemen önceki doyma, kuralın yakalamak istediği şeyin ta kendisi ("ayrılmanın nedeni"). Ayrılmaya ~0.4 s kala %0.1 eşiği yaklaşık 0.4 ms'lik doymuş değerlendirmeye karşılık geliyor. 2 ms'lik eksik pencere, E3 hükmünü değerlendirilebilir yönüne çevirebilir.
- Ayrıca D1 metni "2 ms'lik ortak ızgarada" diyor, kod ise 0.4 ms ızgarada tarıyor (Y5b-d). İki okuma da savunulabilir ama ızgara ile sayım hizalı olmalı.

**3. cum zamanlaması PASS.**
- Kayıt eklendikten sonra `len(ts) % W == 0` olduğunda bir giriş yazılıyor, kırılma testinden önce (v3.1:265-271). Döngü sonunda (kırılma dahil) bir giriş daha ekleniyor (v3.1:272-273).
- Bir girişin zamanı t, o adımın k2 değerlendirmesini (zaman t) de içeriyor. Yani giriş, "zamanı ≤ t olan tüm değerlendirmeler" demek; doğru.
- avg kolunda cum = None, run_all yalnız sw kolunun cum'unu kullanıyor (v3.1:383).
- Öz-testte `cum_consistent = true` ve n = 80000 (= 0.1 s / 2.5 µs × 2 Heun aşaması).

**4. ts/vs ızgarası PASS.**
- İki kol aynı DT, n, rec_k ve aynı t birikim dizisini kullanıyor (v3.1:243-266). Bu yüzden ts kesirleri bit düzeyinde aynı.
- vs her kolda kendi vb'sinden (v3.1:328) aynı W ile hesaplanıyor; yuvarlama simetrik.
- departure yalnız `s['ts']` kullanıyor (v3.1:381). Aynılık savunma amaçlı denetlenmiyor (küçük, R-8).

**5. D1 negatif kontrolü REVISE — R-7 (orta).**
- Kayıtlar her 160 DT = 8 Ts'de bir alınıyor (v3.1:249, 263). Yani hep aynı taşıyıcı fazında örnekleniyor ve anahtarlama dalgalanması kayıtlarda yavaş değişen bir öteleme olarak görünüyor (aliasing). 2 ms ortalaması bunu süzmez.
- Öz-test çıktısı: atmasız 0.1 s anahtarlamalı koşuda kayıtlı bara gerilimi sapması `sw_max_dev = 0.087 pu`, D1 eşiği ise 0.1 pu.
- Bu değerin ne kadarı ortalamalı kola göre kalıcı bir fark, bilinmiyor; denetçi modeli koşmadı ve öz-test avg kolunu yalnız 0.02 s koşuyor.
- Fark eşiğe yakınsa t_ayr dinamikle değil dalgalanma ya da başlangıç geçişiyle erken tetiklenir. Pencere küçülür, sonraki doyma hiç sayılmaz ve D1 anlamını yitirir.
- Ucuz bir ön-koşu negatif kontrolü gerekiyor.

**6. post_equilibrium PASS** (v3.1:279-304).
- LinAlgError, FloatingPointError, OverflowError, ValueError ve ZeroDivisionError yakalanıyor (bunu doğruladım). Sonlu olmayan çözüm başarısız sayılıyor. Doğrudan adım `frac = 1.0` ile çağrılıyor. Sürdürme x0'dan `j/20` adımlarıyla gidiyor ve 20/20 = 1.0 tam.
- Başarısızlıkta `(x0, False, gerekçe)` dönüyor. vb_eq sonlu kalıyor (atma öncesi bara gerilimi), durum E2 (ya da önceden gelen E1). Gerekçe hukum'a yazılıyor (v3.1:386).
- Not: ValueError bir programlama hatasını da "denge yok" olarak gizleyebilir. Bu, gerekçe dizesinde `exception ValueError` diye görünür; kabul edilebilir.

**7. load_rows PASS** (v3.1:105-122).
- Yarım son satır atılıyor ve dosya yeniden yazılıyor. Bozuk ara satır hata veriyor. Sentetik testte üç durum geçti.
- Küçük (R-9): son satır geçerli JSON olduğu hâlde `\n` eksikse (yazım tam satır sonundan önce kesilmişse) dosya yeniden yazılmıyor. Sonraki ekleme aynı satıra yapışır ve devam engellenir.
- Satırlara yazılan `script_sha256` devamda denetlenmiyor (v3.1:369), yani farklı betik sürümlerinin satırları karışabilir.

**8. verify_authorization PASS** (v3.1:97-101).
- Öz-test dosyası, yetkideki `selftest_sha256` ve `pass is True` şartları yetki denetiminden sonra, model importundan önce kontrol ediliyor (v3.1:414-425). OUT tanımı y_common ile aynı (v3.1:413).
- Küçük (R-10): selftest_y5v3.json betik hash'ini içermiyor. Hangi betiğin ürettiği yalnız zaman damgasından çıkarılabiliyor (14:01:25 > betik 14:00:39).

**9. run_all PASS** (v3.1:365-396).
- Durum sırası `cases()` sırası; her durumda önce avg, sonra sw.
- Satırlar `**hashes` ile yazılıyor. Hüküm satırlarında eq_found, eq_how, t_dep, t_lim, sat_frac_win ve sat_frac_all var (R-2 karşılandı).
- E1→E4 sırası korunuyor; E3, None ya da boş pencereyi değerlendirilemez sayıyor (v3.1:160). verdict değişmemiş.
- Not: U.clean `t_dep = inf` değerini `null` yazıyor. Sonuç raporunda "null = ayrılma yok" diye açıklanmalı.

**10. PASS.**
- Öz-test sıfır-dizi denetimi artık `inject()` üzerinden yapılıyor (v3.1:342-343); R-3 karşılandı.
- Sentetik test E2<E3, E3<E4, K2<K3, "tam 4 → K1 değil" ve D1/D4 satırlarını içeriyor; R-5 karşılandı.

## Düzeltme listesi
| ID | öncelik | yer | düzeltme |
|---|---|---|---|
| R-6 | orta-yüksek (zorunlu) | v3.1:130-150, 267-269, 328, 381-383 | Ayrılma ve sayım aynı indeks ızgarasında olsun; karşılaştırma float zamanla değil indeksle yapılsın. Seçenek A (D1 metnine en yakın): departure yalnız `(i+1) % W == 0` olan iç indeksleri tarasın ve `i_dep` döndürsün; sat_until o indeksin cum girdisini (`cum[(i_dep+1)//W − 1]`) alsın. Seçenek B: 0.4 ms ızgarada kal, cum her kayıtta tutulsun ve indeksle seçilsin. Her iki seçenekte SAT_WIN de indekse çevrilsin (son kayıt ≤ 0.75). Hangi okumanın seçildiği v3.1 notuna kısa bir satırla eklensin. |
| R-7 | orta (zorunlu, koşudan önce) | selftest v3.1:335-362 | D1 negatif kontrolü: atmasız F2 için avg kolu da 0.1 s koşsun ve `departure(ts, vs_sw, vs_avg, False)` hesaplansın. Sonuç ∞ olmalı ve en büyük iç fark `max|vs_sw − vs_avg|` raporlansın. Geçme şartı: ∞ ve fark < DEP_THR/2. Geçmezse koşu yapılmaz; D1 (ölçü ya da eşik) koşudan önce ve sonuç görülmeden yeniden yazılır. |
| R-8 | küçük | v3.1:381 | `a['ts'][:n] == s['ts'][:n]` doğrulaması eklensin (uyuşmazlıkta dur). |
| R-9 | küçük | v3.1:105-122, 369 | Dosya `\n` ile bitmiyorsa son satır geçerli bile olsa atılsın ya da `\n` eklensin. Devamda satırın `script_sha256`/`pin_list_sha256` değerleri güncel değerlerle karşılaştırılsın; uyuşmazlıkta dur. |
| R-10 | küçük | v3.1:360 | selftest_y5v3.json'a `script_sha256` ve `pin_list_sha256` eklensin. |

R-8–R-10 tek başına REVISE gerektirmez. Kod yine değişeceği için birlikte uygulanmaları önerilir.

## Çözülmemiş engeller
- R-6 ve R-7 uygulanmadan yetki dosyası yazılmamalı. R-7'nin yeni öz-testi geçmeden koşu yapılmamalı.
- Sonraki denetim 3. ve son turdur. Kapsamı v3.1 → v3.2 farkı ve R-7 öz-test çıktısıyla sınırlanabilir.

## Genel hüküm: **REVISE**
- Gerekçe 1 (R-6): D1'in "[0, t_lim]" penceresi kodda 2 ms'ye kadar kısa kalıyor. Kural tam olarak ayrılmadan hemen önceki doymayı yakalamak için yazılmışken o aralık sayılmayabilir.
- Gerekçe 2 (R-7): 0.1 pu ayrılma eşiğinin, öz-testte görülen 0.087 pu'luk anahtarlamalı sapma ile sahte tetiklenmeyeceği gösterilmemiş.
- D2/D3/D4 ve R-1..R-5 karşılanmış.

