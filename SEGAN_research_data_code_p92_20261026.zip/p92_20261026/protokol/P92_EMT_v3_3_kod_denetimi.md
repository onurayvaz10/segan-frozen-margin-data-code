# P92-EMT v3.3 (Y5b) kod denetimi: v3.1 → v3.3 farkı ve öz-test çıktısı

- Tarih: 2026-10-26.
- Kapsam: P92-EMT v3.3 son revizyon ve öz-test denetimi.
- Ölçüt: P92_EMT_PROTOKOL_v3 + v3_1 + v3_2 (D5–D8) + v3_3 (D9–D10).
- Tur 3/3 (son).
- Bu rapor hiçbir şeye yetki vermez.

## §0 Kapsam
- `--run`/`--selftest` koşulmadı; `g92out\y5v3` açılmadı; model kurulmadı. Hiçbir durum sonucu görülmedi.
- Okunanlar: v3.3 betiği ve sentetik test (tamamen), protokol v3_2 ve v3_3, `g92out\selftest_y5v3.json`, `archive\selftest_y5v3_v3.2_FAILED_*.json`, `tools/emt_diag5.py`.
- Koşulanlar:
  - `--check-only`: pins OK.
  - Sentetik test (`synth.py <boş klasör>`): 59/59 PASS.
  - Denetçi aracı `audit_tools/v33_dep_test.py` (saf aritmetik, model yok).

SHA-256 (VERIFIED):

| dosya | SHA-256 |
|---|---|
| kod/y5_emt_v3.py (v3.3) | 92756607d889a1315b5edb7a31e148509ddc3f7c0630c0902a048b40b689dbe9 (beklenen "92756607…dbe9" ile uyumlu) |
| kod/y5_emt_v3_synth.py (v3.3) | 658fab7c905f1455f695c9f2c84636b8d6483e43f205a4782dd2edb182320425 |
| archive/y5_emt_v3_v3.1_20261026T140653.py | caf69f99ddb194f420a99686961516c4db869fcb50c4d1f992b2c43c7dd06797 (önceki denetimdeki dosya) |
| archive/y5_emt_v3_v3.2_20261026T140949.py | 5329f102d899364800395bc4cfa4abd776450f93ad92a4cad2f9ceb0d32a88b6 |
| archive/selftest_y5v3_v3.2_FAILED_20261026T140949.json | bf36aa2d3cc9e62f81fb4cb7d0923be1b51a6ec9ca3975058fdc9fae790bc693 (script 5329f102…, pass false, 0.0576) |
| protokol/P92_EMT_PROTOKOL_v3_2.txt | 8d0971cf77752c719c31fd5e99ccef0db20b3e9939c2d41d36dce168c01414c2 (PINS'te aynı) |
| protokol/P92_EMT_PROTOKOL_v3_3.txt | 6c0d4dc0bf51b4965a77adb8c1e848a62d9707081f1f8772916a3a8da931ce2f (PROTOCOL; yetkide pinlenecek) |
| pin_list_sha256 (--check-only) | 0cc384d8287710dd19c450c5e918473daeb163646eeb71a03e6ee8190e3b073f |
| g92out/selftest_y5v3.json (v3.3) | f16c29a073da82def01b534fb7247dfde87d48d3792fb73dd17683e6792ae3fc |
| tools/emt_diag5.py | 0d348b8da0c44de9ebbbf5823eed660149498f2df457ae5ae48124e9022cf3a9 |

Öz-test çıktısı (v3.3):
- `script_sha256` ve `pin_list_sha256`, güncel betik ve `--check-only` değerleriyle aynı.
- `pass: true`, `grid_same: true`, `noshed_departure: null`, `noshed_n_signal: 216` (= 250 kayıt − 34), `noshed_max_vs_diff: 0.0120 < 0.05`.
- `sat = 0` (n = 80000), `avg_max_dev = 0`, `cum_consistent: true`.

Satır farkı (v3.1 → v3.3): değişiklikler PINS/PROTOCOL, WD, load_rows, dep_signal/departure/same_grid/limit_index/sat_until, simulate'in cum kısmı, selftest ve run_all ile sınırlı. Modülatör, Heun döngüsü, post_equilibrium ve verdict değişmemiş.

## §1 Özet
| madde | konu | hüküm |
|---|---|---|
| 1 | dep_signal kayan toplamı ve indeks sınırları (D9) | PASS |
| 2 | departure → limit_index → sat_until zinciri (D5, D9) | PASS |
| 3 | cum her kayıtta, indeks hizası (D5) | PASS |
| 4 | ızgara aynılığı (D6) | PASS |
| 5 | filtre gecikmesinin E3'e etkisi | PASS (bağlayıcı raporlama notu N-3) |
| 6 | D9 seçiminin zamanı ve gerekçesi | PASS (açıklama notu N-6) |
| 7 | öz-test (D7/D10) ve hash'ler; yetki şartı | PASS |
| 8 | devam (D8), run_all sırası | PASS |

**Genel hüküm: ACCEPT.**

## Madde bölümleri

**1. dep_signal PASS** (v3.3:138-151).
- `h = 12` ve `lo = W+h = 17`, `hi = n−W−h`; D9'daki `[5+12, n−5−12)` ile aynı.
- İlk toplam `d[5..29]` (25 öğe, 17'de merkezli). Özyineleme `+d[i+h] − d[i−h−1]` doğru.
- Kullanılan en uç d indeksleri 5 ve n−6. Bu, kısa kolun `'same'` kenar sapmalı son 2 noktasını ve baştaki 2 noktayı dışarıda bırakıyor.
- Denetçi aracı (n = 34…6875, rastgele, farklı uzunluklu kollar):
  - kayan toplam ile kaba kuvvet arasındaki en büyük fark 2.1e-17;
  - indeks kümesi beklenenle birebir aynı;
  - `n ≤ 34` için boş liste dönüyor.

**2. Zincir PASS.**
- `departure` (v3.3:154-163): ilk `|s| > 0.1` indeksini döndürür. Kol erken durmuşsa ve ayrılma yoksa son iç indeksi, hiç ayrılma yoksa None döndürür. D9 ile aynı.
- `limit_index` (v3.3:172-180): `ts ≤ 0.75` olan son kaydın indeksi (1874, ts = 0.7496025; sonraki 0.7500025). `min(i_dep, i_win)` alınır, pencerede kayıt yoksa None. D5 ile aynı.
- `sat_until` (v3.3:183-188): `cum[i_lim]` değeri, o kayıt dahil. None, sınır dışı ya da n = 0 olursa None döner, bu da E3'e gider (v3.3:198).
- İndeksler float zamanla değil, ortak kayıt indeksiyle karşılaştırılıyor. v3.1'deki 2 ms açık (R-6) kapandı.
- Küçük not N-5: kol erken durmuşsa ve iç nokta yoksa (n ≤ 34, yani < 14 ms) `departure` 0 döndürür ve pencere ilk kayıtla sınırlanır. Atma rampası 250 ms ve atmasız öz-test kararlı olduğundan pratikte oluşmaz. Değiştirilmesi gerekmez.

**3. cum PASS** (v3.3:256, 305-307).
- Sayaçlar her kayıtta, kırılma testinden önce ekleniyor. Bu yüzden `len(cum) == len(ts)` (öz-testte de doğrulandı) ve `i_dep` ile `i_lim`, `vs`/`ts` indeksleriyle aynı kayda işaret ediyor.
- Kayıt i'deki sayaç, zamanı ≤ ts[i] olan tüm değerlendirmeleri içeriyor (k2 dahil).

**4. Izgara PASS.**
- `same_grid` (v3.3:166-169): ortak uzunlukta karşılaştırma, 1e-9 s toleransla. Uyuşmazlıkta `i_lim = None`, sonuç E3 (v3.3:431-433). D6 ile aynı.
- İki kol aynı DT, n, rec_k ve t birikimini kullanıyor. Öz-testte `grid_same` = true.

**5. Filtre gecikmesi ve E3: PASS, bağlayıcı raporlama notu N-3.**
- Merkezli 25 kayıtlık filtre yavaş değişen bir farkı geciktirmez. Denetçi aracında d = 1e-3·e^{σt}·cos(2πft):
  - f = 0–5 Hz'de gecikme 0 ile −0.8 ms;
  - f = 20 Hz, σ = 20/s'de 0.4 ms.
- Salınımlı bir farkta ise gecikme frekansa bağlı ve ~5 ms'yi aşabiliyor. Kutu filtrenin kazancı 30 Hz'de 0.86, 50 Hz'de 0.64, 93 Hz'de 0.075, 150 Hz'de 0.21. Ham (2 ms) ayrılmaya göre gecikme:
  - 50 Hz'de σ = 5/20/80 s⁻¹ için 90/20/8 ms;
  - 93 Hz'de 516/128/24 ms;
  - 150 Hz'de 307/77/17 ms.
- Yani v3.3 D9'daki "en çok ~5 ms geciktirir" cümlesi yalnız ≲ 20 Hz içerik için doğru.
- Etkinin yönü: pencere gerçek ayrılmanın ötesine uzar (üst sınır 0.75 s). Ayrılma sonrası doyma da sayılır ve E3 (değerlendirilemez) olasılığı artar. Bu, H5b'yi destekleyen yöne değil, K1 yönüne bir sapma; yanlış bir "ok" üretmez.
- Kod kuralı harfi harfine uyguluyor. D10 bu zincirde başka protokol değişikliğini yasaklıyor ve sapma tutucu yönde. Bu yüzden kod düzeltmesi istemiyorum.
- **Bağlayıcı not (sonuç raporu için):**
  - (i) "≤ 5 ms" ifadesi kullanılmaz; bu sınırlama yazılır.
  - (ii) Her durum için ham 2 ms ayrılma indeksi (`|vs_sw − vs_avg| > 0.1`, iç noktalar), kayıtlı `ts`/`vs`'den yalnız betimleyici ve post hoc olarak verilir. Karar değiştirmez.
  - (iii) E3 olan her durumda doyma zaman çizelgesi her iki ayrılma anına göre gösterilir.
  - Bu bilgi jsonl'de (`ts`, `vs`, `cum`) eksiksiz bulunuyor; kod değişikliği gerekmez.

**6. D9'un zamanı ve gerekçesi PASS, açıklama notu N-6.**
- D9, yalnız atmasız F2 tanısına dayanıyor. `emt_diag5.py` atma koşmuyor (`lambda t: G`, 0.3 s) ve hiçbir durum verisine dokunmuyor.
- Seçim gerekçeli ve tanı satırına bağlı: 2/10/20/40 ms denenmiş; 10 ms, eşiği (0.05) geçen en kısa pencere (0.016 pu). Karar eşiği 0.1 pu, pencere (0.75 s) ve doyma sınırı (%0.1) değişmemiş.
- Açıklama notu: D7 ölçütü (< 0.05 pu) bu denetçinin önerisiydi. Ölçüt kalınca ölçü (sinyal) değiştirildi. Bu, sonuç verisinde değil ölçüm gürültüsü kalibrasyonunda bir çatallanma. Sonuç raporu bunu v3.2 FAILED → v3.3 zinciriyle birlikte, sonradan yapılmış bir ayar olarak beyan etmeli (protokol v3_3 bunu zaten yazıyor).

**7. Öz-test ve yetki PASS.**
- D7/D10 şartları v3.3:394-404'te: `departure is None`, iç nokta > 100, en büyük süzülmüş fark < 0.05; ayrıca `grid_same` ve `cum_consistent`.
- Öz-test hash'leri D8'e uygun ve güncel betikle aynı (§0).
- `verify_authorization` (v3.3:105-109) öz-test hash'ini ve `pass` = true şartını denetliyor. Yetki dosyasında `selftest_sha256 = f16c29a0…3fc`, `protocol_sha256 = 6c0d4dc0…e2f`, `script_sha256 = 92756607…832` ve `pin_list_sha256 = 0cc384d8…73f` olmalı.

**8. Devam ve run_all PASS.**
- load_rows (v3.3:128): satır sonu eksikse dosyayı yeniden yazıyor (sentetik testte doğrulandı).
- Devamda hash uyuşmazlığı varsa dur (v3.3:414-418; D8).
- Sıra `cases()` × (avg, sw). Hüküm satırları t_dep, t_lim, grid_same, eq_found ve eq_how alanlarını içeriyor (v3.3:436-442).

**Küçük not N-4:** belge dizesi v3.3:11-13 hâlâ "counts are kept every W records" diyor; kod artık her kayıtta tutuyor. Bu yalnız açıklama hatası; bu sürümde düzeltilmesi gerekmez (betik hash'i ve öz-test yeniden gerekirdi). Sonuç raporunda D5 esas alınır.

## Düzeltme listesi
Zorunlu kod düzeltmesi yok.

| ID | tür | yer | not |
|---|---|---|---|
| N-3 | bağlayıcı raporlama | sonuç raporu | "≤ 5 ms" kullanılmaz; ham 2 ms ayrılma betimleyici olarak verilir; E3 durumlarında doyma zaman çizelgesi her iki ana göre gösterilir |
| N-4 | küçük | v3.3:11-13 | belge dizesi eski; bir sonraki sürümde düzeltilsin |
| N-5 | küçük | v3.3:161-162 | iç nokta yoksa 0 dönmesi; pratikte oluşmaz |
| N-6 | açıklama | sonuç raporu | D7 → D9 kalibrasyon zinciri sonradan yapılmış ayar olarak beyan edilsin |

## Çözülmemiş engeller
Yok. Kalan adımlar: §7'deki dört hash ve bu raporun hash'iyle `P92_EMT_v3_yetki.json` dosyasının yazılması, ardından tek koşu.

## Genel hüküm: **ACCEPT**
- Gerekçe: D5–D10'un her maddesi kodda harfi harfine ve indeks düzeyinde doğru uygulanmış, sentetik ve denetçi testleriyle de doğrulanmış.
- Öz-test hash'leri güncel betikle tutarlı ve öz-test geçmiş.
- En önemli açık nokta (N-3) bir kod hatası değil; protokol gerekçesindeki bir abartı. Etkisi tutucu yönde (E3'e doğru) ve sonuç raporunda bağlayıcı olarak ele alınacak.

