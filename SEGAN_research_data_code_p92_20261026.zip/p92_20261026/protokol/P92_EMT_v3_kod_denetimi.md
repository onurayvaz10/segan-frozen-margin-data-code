# P92-EMT v3 (Y5b) kod denetimi — y5_emt_v3.py

Tarih: 2026-10-26. Kapsam: P92_EMT_PROTOKOL_v3 (+ v1, v2) uyarınca kod denetimi (Tur 1).

## §0 Kapsam ve bağımsızlık
- Görülen sonuç bilgisi: yalnız protokol v3 metnindeki v2 özeti ("6/6 ıraksama") ve tanı tepe değerleri. `g92out\y5v3`, `y5`, S1 kayıt değerleri **açılmadı**; points.csv/selection.json içeriği okunmadı (yalnız --check-only ile hash). Kayıtlı değer görülmedi.
- `--run`, `--selftest` koşulmadı. Koşulanlar: `--check-only`, `y5_emt_v3_synth.py`, iki denetçi el-testi (`audit_tools/diff_sim.py`, `mm_test.py`; model importu yok, stub `Y`).
- Tamamen okunan: y5_emt_v3.py, y5_emt_v3_synth.py, y5_emt.py, y_common.py, protokol v1/v2/v3, P92_EMT_yetki.json. Kısmen: ext_engine.py:365-444 (dispatch, newton_fixed_refs), ext_common.py:15-56.

SHA-256 (VERIFIED, PowerShell Get-FileHash; pinler `--check-only` ile "pins OK"):

| dosya | SHA-256 |
|---|---|
| kod/y5_emt_v3.py | 30018638a13c37fe29abfebcd43353bf8aa8a5420928fc4b217cc46d4326fc46 |
| kod/y5_emt_v3_synth.py | 2b4ec5f0e60635f3d8643c25a470edfb59259d779e4b9b489a8c8753192c7b0c |
| kod/y5_emt.py | 166d2e8427a00e6b9d6fb560ab6614abd2668c3ca4b95878c14d3616a258d495 |
| kod/ext_engine.py | 35d6bd7773b51cce12ca5d5506ab2860f45dcf2f2f217f398ccc76e1a53dbb7f |
| kod/ext_common.py | 63982bfd61cf3a38da8e39ebc470952c8db44b02a11811f712fcc6d38c444c1b |
| kod/y_common.py | 7b16ffbf27dce28fb1932a38705eadbadde2ad1f22c9349c485f6feb523a2970 |
| protokol/P92_EMT_PROTOKOL_v1.txt | 83d860c0c2e8821dd0351771006f2826260eaa1dd5526445342203c4ebb4f778 |
| protokol/P92_EMT_PROTOKOL_v2.txt | d36dd0b91b5893da5df8c29a12b878ed6a87f5a3e00254b3b8e26b6a09e90d7e |
| protokol/P92_EMT_PROTOKOL_v3.txt | 152f0087cd28240c30c81c89ba397ccda723eb6c6c10ba28a00a025590242b6f |
| pin_list_sha256 (--check-only) | 71ed6f79492fbd6a36e56a79ddc765248ad1e2678e538f4ad2eac92302b248f7 |

Pinler P92_EMT_yetki.json (v2) ile aynı 6 dosya + S1 points.csv, selection.json; y5_emt.py pini v2 yetkisindekiyle aynı.

## Eşleme tablosu (protokol § → kod)
| § | konu | kod |
|---|---|---|
| 1 | min-max enjeksiyon, iki dönüştürücü; 20 kHz, dt=Ts/20, gecikme, Heun | v3:135-150, 167, 173; Y.TS/DT y5_emt.py:25-27; örnek/gecikme v3:192-195; Heun v3:197-202 |
| 2 | noktalar, miktarlar, T_r, gözlem | v3:290 → y5_emt.py:147-162; v3:36, 244 |
| 3 | atma sonrası denge, 20 adım sürdürme | v3:212-228; kullanım 237-238; kayıt 250 |
| 4 | kollar sw / avg | v3:295 (avg, sw); avg dalı v3:163-164 |
| 5 | sınıflandırma, yön sınıfı, harfi harfine | v3:247 → y5_emt.py:134-144; v3:92-93; 249, 310 |
| 6 | E1–E4 | v3:96-107; SAT_WIN/SAT_MAX 37-38; sayım 139-146; oran 253-254; çağrı 306-307 |
| 7 | K1–K4 | v3:110-121; 311-314 |
| 8 | öz-test | v3:258-285 |
| 9 | çıktılar, biten koşu, devam, düşük öncelik | v3:291-302, 312-316, 348, 353-357 |
| kapı | yetki, pin, importtan önce | v3:62-88, 329-347; model importu 125-132 |

## §1 Özet
| madde | konu | hüküm |
|---|---|---|
| a | min-max enjeksiyon, taşıyıcı, sıfır-dizi | PASS |
| b | simulate/make_f kopyası | PASS |
| c | doyma sayımı ve pencere (§6-E3) | PASS |
| d | evaluable/verdict sırası, kenar durumlar | PASS (küçük not) |
| e | post_equilibrium (§3) | **REVISE** (R-1, yüksek) |
| f | kontrol kolu ortalama model | PASS |
| g | yetki/pin/import sırası; Y5b-a/b/c | PASS; Y5b-a/b/c KABUL |
| h | devam ve yeniden koşmama | PASS (küçük not) |

**Genel hüküm: REVISE** (R-1).

## Madde bölümleri
**(a) PASS.** v3:138 `m = (ph − 0.5(max+min))/vdc` = §1 `v0 = −(max+min)/2, m=(v+v0)/Vdc` (el-testi: 200 rastgele vektörde fark 0.0). Doyma sayımı kırpmadan önce (v3:139-146), kırpma v3:147. Taşıyıcı ve karşılaştırma v3:148-149, y5_emt.py:66-68 ile aynı ifade; v0 = 0 olan vektörlerde switched_mm ile v2 `switched` farkı 2.2e-16. Geri dönüşüm v3:150 = y5_emt.py:69; Σ conj(A3)_k = 0 olduğundan her ortak bileşen (anahtarlanmış ±vdc dahil) tam yok olur. Bir taşıyıcı periyodu ortalaması |vref| ≤ 1.10·vdc'de vref'i verir (hata 1.2e-4, 20000 örnek çözünürlüğü); doyma |vref|/vdc = 1.15'te 0, 1.16'da başlar (2/√3 = 1.1547 ile tutarlı).
- Not N-1 (küçük, protokol metni): §1'deki `e^{-j2πk/3}` işareti koddaki `conj(A3) = e^{+j2πk/3}` ile ters yazılmış. Kod v2 ile aynı ve doğru (öz-test geri dönüşümü vref'e eşitliyor, v3:265-268); sıfır-dizi iddiası her iki işarette geçerli. Kod düzeltmesi gerekmez; sonuç raporunda düzeltilmeli.

**(b) PASS.** `diff_sim.py` (yorumlar ve `lay.ix`→`ix`, `Y.` öneki, `vdc_g` mekanik eşlemesi sonrası): 56/55 satırın 45'i özdeş. Farklar yalnız: imza/`M` açılımı (v3:153-155), `stats` (158), `Gfun(t)` satır içi (162, eşdeğer), `switched`→`switched_mm` (167, 173), make_f kapanışının simulate'e gömülmesi (181), `g = s['par']['gfm']` (190, y5_emt.py:118 ile eşdeğer), dönüşe `stats` eklenmesi (209). Modülatör dışında anlamsal fark yok.

**(c) PASS.** "Değerlendirme" = her switched_mm çağrısı (her iki Heun aşaması, v3:197, 199); doymuş = herhangi faz |m| > 1 (v3:142); pencere `t ≤ T_r+0.5` (v3:37, 144; k2'de t+DT verilir); oran dönüştürücü başına `sat_win/n_win` (v3:254), E3'te dönüştürücüler üzerinden max ≥ 1e-3 (v3:103). El-testi: t ∈ {0, 0.75, 0.75+1e-9, 1.0} → n_win = 2. §6-E3 ile birebir.
- Not N-2 (protokol düzeyi değerlendirilebilirlik riski, kod hatası değil): E3, E4'ten önce ve ıraksama için istisna yok. Anahtarlamalı kol [0, 0.75 s] içinde büyüyüp ıraksarsa modülatör büyük olasılıkla doyar → E3. v2'de görülen ıraksama sürerse K1 olasıdır. Kural sabit; sonuç raporunda bu mekanizma ayrıca yazılmalı.

**(d) PASS.** evaluable v3:99-107 sırası E1→E2→E3→E4→ok, §6 ile aynı; kontrol 'undetermined' → yön None ≠ beklenen → E1 (doğru). verdict v3:114-121 sırası K1→K2→K3→K4, §7 ile aynı; K1 `< 4` (4 değerlendirilebilir → K1 değil). Yazarın sentetik testi 21/21 PASS. Denetçi ek satırları (mm_test.py): E2 E3'ten önce, E3 E4'ten önce, K2 K3'ten önce, tam 4 değerlendirilebilir → K3, hepsi E1 → K1; hepsi beklenen sonucu verdi.
- Küçük: K3 A2 durumlarını `id.startswith('A2')` ile seçiyor (v3:118); protokol §2 kimlikleri (A2-F00993, A2-F01921) ile uyumlu, F2 kimliği 'F2-0.65-0.20' karışmaz.
- Küçük (R-2): denge bulunamazsa vb_eq çözülmemiş x'ten hesaplanır (v3:238); kontrol kolu büyük olasılıkla E1'e düşer ve E2 gerekçesi hukum.json'da görünmez (satırlarda eq_found yok, v3:308-310). Sonuç değişmez (her ikisi de değerlendirilemez), yalnız gerekçe izlenebilirliği.

**(e) REVISE — R-1 (yüksek).** Akış §3 ile uyumlu: doğrudan Newton (v3:218), başarısızsa x0'dan 20 eşit adım, her adım bir öncekinden (v3:221-227), başarısızlıkta ok = False (v3:227). Ancak `E.newton_fixed_refs` içinde `np.linalg.solve` (ext_engine.py:424) yakınsamayan iterasyonda NaN/inf içeren Jacobian'da istisna atar (bu ortamda numpy 2.5.3: NaN girişli matris → `LinAlgError: Singular matrix`, denetçi denemesi). post_equilibrium'da yakalama yok. Sürdürme tam olarak v2'de doğrudan Newton'un başarısız olduğu A2-F01921'de koşacak, yani dal bitimine (katlanma) yaklaşan adımlarda bu yolun açılma olasılığı yüksek. O zaman §3'ün "denge yok → DEĞERLENDİRİLEMEZ" satırı yerine süreç izle çöker. Devam mantığı aynı durumu belirlenimci olarak yeniden dener ve yine çöker: hukum.json hiç yazılmaz, koşu ortasında kod değişikliği ve yeni yetki gerekir. Doğrudan adım v2 ile aynı çağrı olduğundan bu altı durumda istisna atmaz. Risk yalnız yeni sürdürme çağrılarındadır.

**(f) PASS.** `mode == 'avg'` → `Minv * E.rhs(...)` (v3:162-164), ctrl_out/switched_mm çağrılmaz, istatistik None (v3:209). Aynı Heun, aynı DT, aynı kayıt ve kesme kuralı, aynı classify (v3:246-247). Örnekleme döngüsü avg'de de ctrl_out hesaplar (v3:192-195), ama sonucu kullanılmaz; zararsız.

**(g) PASS.** Modül tepesi yalnız stdlib (v3:14-20). `--run` önce `verify_authorization` (v3:334-341), `--selftest` önce pin (v3:343-346), model importu ancak sonra (v3:347). Yetki denetimi: action, protokol v3 hash, betik hash, pin listesi hash, denetim raporu hash (v3:76-87). Pin listesi tam: çalışma anında okunan her yerel dosya pinli (y5_emt, ext_engine, ext_common, y_common; S1'den yalnız points.csv ve selection.json okunur, y_common.py:41-48), protokol v3 ve betik yetki üzerinden pinli. Yetki dosyası P92_EMT_v3_yetki.json henüz yok (beklenen).
- Y5b-a **KABUL**: enjeksiyon, v2'nin taşıyıcı karşılaştırmasının kullandığı aynı tutulmuş komuttan hesaplanıyor (v3:167, 173). Tek model değişikliği ilkesini (§1) korur.
- Y5b-b **KABUL**: her iki Heun aşamasını saymak, §6'daki "modülatör değerlendirmesi" ifadesinin harfi harfine okunuşudur. Payda ve pay aynı kümeden geldiği için oran yanlı değildir.
- Y5b-c **KABUL**: protokol §3 metninin kendisidir; bir seçim değil.

**(h) PASS.** Biten koşu: exit_code.txt varsa ret (v3:355-357), yetkiden sonra. exit_code yalnız hukum.json'dan sonra yazılır (v3:312-315). Devam: anahtar (id, case, arm) (v3:292, 296); her satırdan sonra flush (v3:300); hüküm dosyadan yüklenen kayıtlarla da kurulur (v3:304-310).
- Küçük (R-4): `U.load_jsonl` (y_common.py:66) yarım kalmış son satırda `JSONDecodeError` atar ve devam engellenir. Ayrıca satırlarda betik hash'i yok, bu yüzden farklı betik sürümlerinin satırları karışabilir.

**Öz-test §8 notları (küçük).** v3:263-268 sıfır-dizi testi enjeksiyonu satır içinde yeniden yazıyor, switched_mm'i sınamıyor (bu açığı denetçi el-testi kapattı). "Sınırlı kalır" eşiği 0.5 pu belgelenmemiş bir seçim (v3:281). Koşu, öz-testin geçtiğini kapıda denetlemiyor.

## Düzeltme listesi
| ID | öncelik | yer | düzeltme |
|---|---|---|---|
| R-1 | yüksek (zorunlu) | v3:212-228 | Her `E.newton_fixed_refs` çağrısını `try/except (np.linalg.LinAlgError, FloatingPointError, OverflowError, ValueError)` ile sar. İstisnayı ve sonlu olmayan sonucu (`not np.all(np.isfinite(x))`) başarısızlık say ve `(x0, False, 'exception/nonfinite at step j')` döndür. Böylece §3'ün "denge yok" satırına düşer. Doğrudan adımda da aynı sarma (davranış v2 ile aynı kalır). |
| R-2 | küçük | v3:308-310 | hukum.json satırlarına `eq_found`, `eq_how` ekle (E1'in E2'yi gölgelediği durum izlenebilir olsun). Sıra ve kurallar değişmez. |
| R-3 | küçük | v3:258-285, 68-88 | Öz-test sıfır-dizi denetimini switched_mm üzerinden yap (ör. taşıyıcı periyodu ortalaması = vref). İsteğe bağlı: yetkiye `selftest_y5v3.json` hash'ini ve `pass=true` koşulunu ekle. |
| R-4 | küçük | v3:292, 312 | Yarım son satırı atlayan (ve uyaran) yükleyici kullan. Her satıra ve hukum.json'a `script_sha256` ile `pin_list_sha256` yaz. |
| R-5 | küçük | synth | E2<E3, E3<E4, K2<K3 ve "tam 4 → K1 değil" satırlarını ekle (denetçi el-testinde doğrulandı). |

R-2–R-5 tek başına REVISE gerektirmez. Kod sürümü zaten değişeceği için birlikte uygulanmaları önerilir.

## Çözülmemiş engeller
- R-1 uygulanmadan koşu yetkilendirilmemeli. R-1 sonrası yeniden denetim, yalnız v3 → v3.1 farkı ve post_equilibrium ile sınırlanabilir.

## Genel hüküm: **REVISE**
Gerekçe: R-1. Protokol §3'ün "denge yok" yolu, sürdürmenin kesin koşacağı A2-F01921 durumunda istisna ile kırılabilir. Bu da tek koşunun ortasında kod değişikliğini zorunlu kılar. Modülatör (a), kopya (b), doyma ölçütü (c), karar tabloları (d), kontrol kolu (f) ve kapı (g) doğrudur.

