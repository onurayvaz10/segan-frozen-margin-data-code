"""Assemble ms_v2.txt and s2_v2.txt (pandoc markdown) from the v1 sources of gelistirme91 and the plan files in ms/,
then optionally build the .docx files with pandoc (run with the venv python that has pypandoc_binary).

Plan directives (one per line):
  @@KEEP a-b@@            v1 lines a..b (1-based, inclusive), with table/figure renumbering
  @@SUB n|||old|||new@@   v1 line n with one exact substring replaced (must occur), then renumbered
  @@ROW2 c1|c2|c3|c4|c5@@ a row of the multiline Table 2 (column widths of the v1 table)
  @@REFS@@                v1 lines 741..end with the verified corrections and the new references
  @@S2KEEP 1-END@@        the whole S2 v1 source
  @@MS a-b@@              v1 manuscript lines moved to S2 (main-text table numbers renamed G.1/G.2)
  @@CSV name@@            S2 table generated from the summary CSV files of the P92 round
Usage: python -I build_ms_v2.py SUMMARY_DIR [--docx OUTDIR]
"""
import csv
import os
import re
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
MS1 = ROOT.parent / 'gelistirme91_20261025' / 'ms'
MSD = ROOT / 'ms'
IMG = MSD / 'img'
REF = ROOT.parent / 'revizyon_20261025' / 'ms'

TABLE_MAP = {6: 'S2 Table G.1', 7: 'Table 6', 8: 'S2 Table G.2', 9: 'Table 7', 10: 'Table 9'}
FIG_MAP = {10: 'Figure 11'}
WIDTHS = [25, 56, 60, 139]


def renumber(s):
    """One pass over main-text table references (bold captions included) and figure references."""
    def t(m):
        v = TABLE_MAP.get(int(m.group(2)))
        if v is None:
            return m.group(0)
        return f'**{v}.**' if m.group(1) and m.group(3) else (m.group(1) or '') + v
    s = re.sub(r'(?<!S2 )(\*\*)?\bTable (\d+)(?:(\.\*\*)|(?!\.\d)\b)', t, s)
    return re.sub(r'\bFigure (\d+)\b', lambda m: FIG_MAP.get(int(m.group(1)), m.group(0)), s)


def fix_images(s):
    def rep(m):
        p = m.group(1).replace('\\', '/')
        name = p.split('/')[-1]
        if 'media_v0/media/' in p:
            src = MS1 / 'media_v0' / 'media' / name
        elif p.startswith('../sekil/') and (ROOT / 'sekil' / name).exists():
            src = ROOT / 'sekil' / name
        else:
            src = MS1.parent / 'sekil' / name
        IMG.mkdir(parents=True, exist_ok=True)
        shutil.copy(src, IMG / name)
        return f'](img/{name})'
    return re.sub(r'\]\(([^)]+\.png)\)', rep, s)


NEW_REFS = [
    r'\[52\] D. Pullaguram, R. Madani, T. Altun, A. Davoudi. Small-signal stability-constrained optimal power flow for inverter dominant autonomous microgrids. IEEE Transactions on Industrial Electronics 69(7) (2022), 7318--7328. https://doi.org/10.1109/TIE.2021.3102454',
    r'\[53\] A. Aissa Berraies, A. Rabiee, I. Kamwa. Small-signal stability-constrained optimal power flow using eigenvalue sensitivity factors. In: 2026 IEEE Power & Energy Society General Meeting (PESGM) (2026), 1--5. https://doi.org/10.1109/PESGM58988.2026.11693590',
    r'\[54\] B. Yang, N. Baeckeland, G.-S. Seo. Small-signal analysis of current-limiting grid-forming inverters. IEEE Transactions on Industry Applications 62(5) (2026), 7661--7677. https://doi.org/10.1109/TIA.2026.3655646',
    r'\[55\] J. Manoharan. Audited selective verification for risk-controlled N-1 thermal contingency screening under deployment shift. arXiv preprint arXiv:2607.13221 (2026). https://doi.org/10.48550/arXiv.2607.13221',
]


def refs(v1):
    out = v1[740:]
    txt = '\n'.join(out)
    for old, new in (('F. C. Perez', 'F. Canales Perez'), ('D. S. Callaway, B.-M. Hodge, C. Barrows', 'D. S. Callaway, C. Barrows')):
        assert txt.count(old) == 1, old
        txt = txt.replace(old, new)
    txt = txt.rstrip('\n') + '\n\n' + '\n\n'.join(NEW_REFS) + '\n'
    return txt.split('\n')


def row2(cells):
    cells = [c.strip() for c in cells]
    parts = []
    for c, w in zip(cells[:4], WIDTHS):
        assert len(c) <= w, (c, w)
        parts.append(c.ljust(w))
    return '  ' + ' '.join(parts) + ' ' + cells[4]


def fmt(v, k=4):
    try:
        x = float(v)
    except (TypeError, ValueError):
        return '--' if v in (None, '', 'None') else str(v)
    if x != 0 and (abs(x) < 1e-3 or abs(x) >= 1e4):
        m, e = f'{x:.{k - 2}e}'.split('e')
        return f'{m}×10^{int(e)}^'
    return f'{x:.{k}g}'


def csv_table(name, sdir):
    def rd(p):
        return list(csv.DictReader(open(p, encoding='utf-8')))
    if name == 'y2':
        rows = rd(sdir / 'y2_estimators.csv')
        cap = ('**Table G.3.** Margin estimators on the 774 uncensored primary TSV points, including the Newton-κ '
               'estimators (pre-specified analysis; reference of the sealed run TSV_a).')
        hdr = ['Estimator', 'Extra equilibria', 'n', 'Missing', 'MAE (pu)', 'RMSE (pu)', 'Max AE (pu)',
               'Median abs. rel. error (%)', '95th pct abs. rel. error (%)', 'Overshoots']
        body = [[r['estimator'].replace('_', ' '), r['extra_equilibria'], r['n'], r['n_missing'], fmt(r['MAE']),
                 fmt(r['RMSE']), fmt(r['max_AE']), fmt(r['median_abs_rel_pct'], 3), fmt(r['p95_abs_rel_pct'], 3),
                 r['overshoot']] for r in rows]
    elif name == 'y3':
        rows = rd(sdir / 'y3_levels.csv')
        cap = ('**Table G.4.** Current-limit study, per utilisation level (72 points per level; pre-specified). '
               'Wilson 95% intervals of the agreement of sign κ.')
        hdr = ['u_nom', 'Evaluable', 'Status', 'Median u0', 'κ < 0', 'Median κ', 'Optimistic', 'Ties', 'Primary',
               'R1 agrees', 'R1 Wilson 95%', 'R4 agrees', 'abs(ε2) < 0.5', 'R1 agrees there']
        body = [[r['u_nom'], r['evaluable'], r['status'].replace('"', '').replace('{', '').replace('}', ''),
                 fmt(r['u0_median'], 3), r['kappa_neg'], fmt(r['kappa_median'], 3), r['obs_optimistic'], r['obs_tie'],
                 r['primary'], r['R1_agree'], '--'.join(fmt(v.strip(), 3) for v in r['R1_wilson'].strip('()').split(',')), r['R4_agree'],
                 r['eps2_lt_0p5'], r['R1_agree_eps2']] for r in rows]
    elif name == 'y1':
        rows = rd(sdir / 'y1_policy.csv')
        cap = ('**Table G.5.** Screening rules on the sealed TSV records (post hoc): all 1249 selected points and the '
               '922 primary points.')
        hdr = ['Set', 'Rule', 'n', 'Accepted', 'Unsafe accepted', 'Tie accepted', 'Safe refused', 'Extra equilibria',
               'F_single missing']
        body = [[r['set'].replace('_', ' '), r['policy'].replace('_', ' '), r['n'], r['accepted'], r['unsafe_accepted'],
                 r['tie_accepted'], r['safe_refused'], r['extra_equilibria'], r['F_single_missing']] for r in rows]
    elif name == 'y6':
        rows = rd(sdir / 'y6_baseline.csv')
        cap = '**Table G.6.** Learned baseline against the sign rules on the 922 primary TSV points (post hoc).'
        hdr = ['Scheme', 'Test set', 'Model', 'n', 'Optimistic', 'Sensitivity', 'Specificity', 'Balanced', 'Errors']
        body = [[r['scheme'], r['test'], r['model'], r['n'], r['n_opt'], fmt(r['sensitivity'], 3),
                 fmt(r['specificity'], 3), fmt(r['balanced'], 3), r['errors']] for r in rows]
    elif name == 'y4':
        rows = rd(sdir / 'y4_ramp.csv')
        cap = ('**Table G.7.** Ramped shedding in $\\mathcal{F}_{2}$ (pre-specified). Envelopes: maximum |bus-voltage '
               'deviation| in the first and the last 0.5 s after the ramp.')
        hdr = ['Member (P_set, G_R)', 'Amount', 'ΔG (pu)', 'T_r (s)', 'Diverged', 'Divergence time (s)',
               'Envelope, first 0.5 s (pu)', 'Envelope, last 0.5 s (pu)', 'Growth last/first']
        body = [[f"({r['P_set']}, {r['G_R']})", r['case'], fmt(r['dG']), r['T_r'], r['diverged'],
                 fmt(r['diverged_at_s'], 3), fmt(r['env_first_0p5s_after_ramp'], 3), fmt(r['envelope_last_0p5s'], 3),
                 fmt(r['growth_last_over_first'], 3)] for r in rows]
    lines = [cap, '', '| ' + ' | '.join(f'**{h}**' for h in hdr) + ' |', '|' + '|'.join([':--'] * len(hdr)) + '|']
    lines += ['| ' + ' | '.join(str(c) for c in b) + ' |' for b in body]
    return lines


def expand(plan, v1, s2v1, sdir):
    out = []
    for line in plan:
        m = re.fullmatch(r'@@KEEP (\d+)-(\d+)@@', line)
        if m:
            out += [renumber(l) for l in v1[int(m.group(1)) - 1:int(m.group(2))]]
            continue
        m = re.fullmatch(r'@@SUB (\d+)\|\|\|(.*?)\|\|\|(.*)@@', line)
        if m:
            src = v1[int(m.group(1)) - 1]
            assert src.count(m.group(2)) == 1, ('SUB', m.group(1), m.group(2)[:60])
            out.append(renumber(src.replace(m.group(2), '\x00')).replace('\x00', m.group(3)))
            continue
        m = re.fullmatch(r'@@ROW2 (.*)@@', line)
        if m:
            out.append(row2(m.group(1).split('|')))
            continue
        if line == '@@REFS@@':
            out += refs(v1)
            continue
        if line == '@@S2KEEP 1-END@@':
            out += s2v1
            continue
        m = re.fullmatch(r'@@MS (\d+)-(\d+)@@', line)
        if m:
            blk = '\n'.join(v1[int(m.group(1)) - 1:int(m.group(2))])
            blk = blk.replace('**Table 6.**', '**Table G.1.**').replace('**Table 8.**', '**Table G.2.**')
            blk = re.sub(r'(?<!S2 )\bTable 8\b', 'Table G.2', blk)
            out += blk.split('\n')
            continue
        m = re.fullmatch(r'@@CSV (\w+)@@', line)
        if m:
            out += csv_table(m.group(1), sdir)
            continue
        assert not line.startswith('@@'), line
        out.append(line)
    return out


def main():
    sdir = Path(sys.argv[1])
    v1 = (MS1 / 'ms_v1.txt').read_text(encoding='utf-8').split('\n')
    s2v1 = (MS1 / 's2_v1.txt').read_text(encoding='utf-8').split('\n')
    ms = expand((MSD / os.environ.get('MS_PLAN', 'ms_v2_plan.txt')).read_text(encoding='utf-8').split('\n'), v1, s2v1, sdir)
    s2 = expand((MSD / 's2_appG_plan.txt').read_text(encoding='utf-8').split('\n'), v1, s2v1, sdir)
    (MSD / os.environ.get('MS_OUT', 'ms_v2.txt')).write_text(fix_images('\n'.join(ms)), encoding='utf-8')
    (MSD / 's2_v2.txt').write_text(fix_images('\n'.join(s2)), encoding='utf-8')
    print('ms_v2 lines', len(ms), 's2_v2 lines', len(s2))
    if '--docx' in sys.argv:
        import pypandoc
        od = Path(sys.argv[sys.argv.index('--docx') + 1])
        od.mkdir(parents=True, exist_ok=True)
        for src, dst, ref in ((os.environ.get('MS_OUT', 'ms_v2.txt'), 'Manuscript.docx', 'ref_manuscript.docx'),
                              ('s2_v2.txt', 'Supplementary_Methods_S2.docx', 'ref_s2.docx')):
            pypandoc.convert_file(str(MSD / src), 'docx',
                                  format='markdown+pipe_tables+multiline_tables+grid_tables+tex_math_dollars',
                                  outputfile=str(od / dst),
                                  extra_args=[f'--reference-doc={REF / ref}', f'--resource-path={MSD}', '--wrap=none'])
            print('built', od / dst)


if __name__ == '__main__':
    main()
