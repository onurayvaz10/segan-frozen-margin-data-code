"""Y5 (protocol P92_EMT_PROTOKOL_v1): switching-level (PWM) time-domain check of the direction of the frozen-margin bias.

The balanced three-wire network and devices of ext_engine are written in a rotating frame with all RLC elements
dynamic, so feeding them instantaneous switched converter voltages (transformed into the frame) reproduces the
switching behaviour. Control outputs are sampled every Ts and applied one sample later; regular-sampled triangular
SPWM at fsw; leg voltages +-Vdc (pu); the CPL DC link is fed by the instantaneous switched power.
  --selftest   averaged mode keeps x0 (0.02 s) and switched mode stays bounded (0.02 s)
  --run        six cases into OUT/y5/emt.jsonl (resumes; refuses if OUT/y5/exit_code.txt exists)
"""
import argparse
import json
import math
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import y_common as U  # noqa: E402
import ext_common as C  # noqa: E402
import ext_engine as E  # noqa: E402

FSW = 20000.0          # protocol v2 (10 kHz: pre-shedding equilibrium unstable with one-sample delay)
TS = 1.0 / FSW
DT = TS / 20
A3 = np.exp(-2j * np.pi * np.arange(3) / 3)          # phase shifts a, b, c


def ctrl_out(lay, x, refs):
    """Converter voltage commands in the frame: GFM (Vrc, Vic) and per CPL (lVrc, lVic), as ext_engine.rhs."""
    s, p = lay.sysd, lay.sysd['par']
    g, ix = p['gfm'], lay.ix
    X = lambda nm: x[ix[nm]]  # noqa: E731
    Pref, Qref, Vref = refs[0], refs[1], refs[2]
    th, pm, qm = X('G:th'), X('G:pm'), X('G:qm')
    z = g['w_ref'] + g['Rp'] * (Pref - pm)
    Voc = Vref + g['kq'] * (Qref - qm)
    Idf, Iqf = E.park(th, X('G:Irf'), X('G:Iif'))
    Idc, Iqc = E.park(th, X('G:Irc'), X('G:Iic'))
    Vdf, Vqf = E.park(th, X('G:Vrf'), X('G:Vif'))
    Vdr = Voc - g['rv'] * Idf + z * g['lv'] * Iqf
    Vqr = -g['rv'] * Iqf - z * g['lv'] * Idf
    Idcr = g['kpv'] * (Vdr - Vdf) + g['kiv'] * X('G:xid') - g['cf'] * z * Vqf + g['kffi'] * Idf
    Iqcr = g['kpv'] * (Vqr - Vqf) + g['kiv'] * X('G:xiq') + g['cf'] * z * Vdf + g['kffi'] * Iqf
    Vd = g['kpc'] * (Idcr - Idc) + g['kic'] * X('G:gd') - z * g['lf'] * Iqc + g['kffv'] * Vdf - g['kad'] * (Vdf - X('G:phd'))
    Vq = g['kpc'] * (Iqcr - Iqc) + g['kic'] * X('G:gq') + z * g['lf'] * Idc + g['kffv'] * Vqf - g['kad'] * (Vqf - X('G:phq'))
    out = [complex(*E.ipark(th, Vd, Vq))]
    for c, cd in enumerate(s['cpls']):
        q, pre = cd['par'], f'C{c}:'
        thp = X(pre + 'thp')
        lIdc, lIqc = E.park(thp, X(pre + 'Irc'), X(pre + 'Iic'))
        Vdp, Vqp = E.park(thp, X(pre + 'Vrf'), X(pre + 'Vif'))
        dw = q['kp_pll'] * Vqp + q['ki_pll'] * X(pre + 'eps')
        Idr = q['kpv'] * (refs[3 + 2 * c] - X(pre + 'vdc')) + q['kiv'] * X(pre + 'eta')
        Vdc_ = q['kpc'] * (-Idr + lIdc) + q['kic'] * X(pre + 'gd') + (1 + dw) * q['lf'] * lIqc
        Vqc_ = q['kpc'] * (-refs[4 + 2 * c] + lIqc) + q['kic'] * X(pre + 'gq') - (1 + dw) * q['lf'] * lIdc
        out.append(complex(*E.ipark(thp, Vdc_, Vqc_)))
    return out, z


def switched(vref, vdc, thf, t):
    """Frame voltage of a two-level SPWM leg set: reference vref (frame), DC voltage vdc (pu), frame angle thf."""
    m = np.clip(np.real(vref * np.exp(1j * thf) * A3) / vdc, -1.0, 1.0)
    ph = (t / TS) % 1.0
    car = 1.0 - 4.0 * abs(ph - 0.5)
    sw = np.where(m > car, vdc, -vdc)
    return (2.0 / 3.0) * np.sum(sw * np.conj(A3)) * np.exp(-1j * thf)


def make_f(lay, refs, Gfun, mode):
    s, ix = lay.sysd, lay.ix
    Minv = 1.0 / lay.M
    vdc_g = C.VDC_GFM_PU
    held = {}

    def f(t, x, thf):
        Gt = Gfun(t)
        fa = E.rhs(lay, x, refs, Gt)
        if mode == 'avg':
            return Minv * fa
        cmd, _ = ctrl_out(lay, x, refs)
        app = held['app']
        vg = switched(app[0], vdc_g, thf, t)
        fa[ix['G:Irc']] += vg.real - cmd[0].real
        fa[ix['G:Iic']] += vg.imag - cmd[0].imag
        for c, cd in enumerate(s['cpls']):
            pre, q = f'C{c}:', cd['par']
            vdc = x[ix[pre + 'vdc']]
            vc = switched(app[1 + c], vdc, thf, t)
            fa[ix[pre + 'Irc']] -= vc.real - cmd[1 + c].real
            fa[ix[pre + 'Iic']] -= vc.imag - cmd[1 + c].imag
            Isw = complex(x[ix[pre + 'Irc']], x[ix[pre + 'Iic']])
            dP = (vc.real - cmd[1 + c].real) * Isw.real + (vc.imag - cmd[1 + c].imag) * Isw.imag
            fa[ix[pre + 'vdc']] += (E.WB / q['c_dc']) * dP / vdc
        return Minv * fa

    return f, held


def simulate(lay, x0, refs, Gfun, T, mode, vb_eq=None, rec_every=4e-4):
    f, held = make_f(lay, refs, Gfun, mode)
    sb = lay.sysd['shed_bus']
    bR, bI = lay.ix[f'V{sb}:R'], lay.ix[f'V{sb}:I']
    x, thf, t = x0.copy(), 0.0, 0.0
    cmd0, _ = ctrl_out(lay, x, refs)
    held['app'], nxt = list(cmd0), list(cmd0)
    k_next = 1
    ts, vb = [], []
    n = int(round(T / DT))
    rec_k = max(1, int(round(rec_every / DT)))
    for k in range(n):
        if t >= k_next * TS - 1e-12:                 # sample instant: apply the previous command, compute the next
            held['app'] = nxt
            nxt, _ = ctrl_out(lay, x, refs)
            k_next += 1
        z = lay.sysd['par']['gfm']['w_ref'] + lay.sysd['par']['gfm']['Rp'] * (refs[0] - x[lay.ix['G:pm']])
        k1 = f(t, x, thf)
        xp = x + DT * k1
        k2 = f(t + DT, xp, thf + DT * E.WB * z)
        x = x + 0.5 * DT * (k1 + k2)
        thf += DT * E.WB * z
        t += DT
        if k % rec_k == 0:
            v = math.hypot(x[bR], x[bI])
            ts.append(t)
            vb.append(v)
            if not math.isfinite(v) or (vb_eq is not None and abs(v - vb_eq) > 2.0):
                break
    return np.array(ts), np.array(vb), x


def classify(ts, vb, vb_eq, Tr, T):
    w = max(1, int(round(2e-3 / 4e-4)))
    vs = np.convolve(vb, np.ones(w) / w, mode='same')
    dev = np.abs(vs - vb_eq)
    if len(ts) and (np.nanmax(dev[w:-w]) > 0.5 or ts[-1] < T - 1e-3):
        return 'diverged', None, dev
    def env(a, b):
        e = [dev[(ts >= u) & (ts < u + 0.05)].max() for u in np.arange(a, b - 1e-9, 0.05)]
        return float(np.mean(e))
    R = env(T - 0.5, T) / env(Tr + 0.5, Tr + 1.0)
    return ('growing' if R > 1.2 else 'decaying' if R < 0.8 else 'undetermined'), R, dev


def cases():
    rows = [r for r in U.load_points() if r['stage1_pin_ok'] is True]
    opt = sorted([r for r in rows if r['system'] == 'A2' and r['source'] != 'search' and U.is_primary(r)
                  and r['kappa'] < 0], key=lambda r: r['kappa'])[:2]
    sel = U.selection()
    lay, G, P = C.build_F2(0.65, 0.20)
    r1 = C.stage1(lay, G, P, rec={}, strict=False)
    s2 = C.stage2(lay, G, P, r1, with_exact=False)
    f2 = dict(id='F2-0.65-0.20', builder=('F2', None), dGf=r1['dGf'], dGt=s2['dGref'], kappa=r1['kappa'])
    out = [(f2, 'A_between', f2['dGf'] + 0.5 * (f2['dGt'] - f2['dGf']), 'decaying'),
           (f2, 'B_beyond', 1.05 * f2['dGt'], 'growing')]
    for r in opt:
        d = dict(id=r['id'], builder=('sel', r['id']), dGf=r['dGf'], dGt=r['dGref'], kappa=r['kappa'])
        out += [(d, 'A_between', d['dGt'] + 0.5 * (d['dGf'] - d['dGt']), 'growing'),
                (d, 'B_below', 0.90 * d['dGt'], 'decaying')]
    return out, sel


def build(b, sel):
    if b[0] == 'F2':
        return C.build_F2(0.65, 0.20)
    r = sel[b[1]]
    return C.BUILDERS[r['system']](r)


def run_case(pt, name, dG, expect, sel, Tr=0.25, Tobs=2.5):
    lay, G, P = build(pt['builder'], sel)
    d = E.dispatch(lay, P, G, tol=1e-12)
    x0, refs = d['x'], d['refs']
    sb = lay.sysd['shed_bus']
    Gp = G.copy()
    Gp[sb] -= dG
    xe, ok, _, _ = E.newton_fixed_refs(lay, x0, refs, Gp)
    vb_eq = math.hypot(xe[lay.ix[f'V{sb}:R']], xe[lay.ix[f'V{sb}:I']])

    def Gfun(t):
        g = G.copy()
        g[sb] -= dG * min(t / Tr, 1.0)
        return g
    T = Tr + Tobs
    t0 = time.perf_counter()
    ts, vb, _ = simulate(lay, x0, refs, Gfun, T, 'sw', vb_eq)
    cls, R, dev = classify(ts, vb, vb_eq, Tr, T)
    return dict(id=pt['id'], case=name, kappa=pt['kappa'], dGf=pt['dGf'], dGt=pt['dGt'], dG=dG, expected=expect,
                observed=cls, agree=cls == expect, R=R, eq_found=bool(ok), t_end=float(ts[-1]) if len(ts) else 0.0,
                wall_s=time.perf_counter() - t0,
                trace=[[float(a), float(b)] for a, b in zip(ts[::5], dev[::5])])


def main():
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument('--selftest', action='store_true')
    g.add_argument('--run', action='store_true')
    a = ap.parse_args()
    U.OUT.mkdir(parents=True, exist_ok=True)
    if a.selftest:
        lay, G, P = C.build_F2(0.65, 0.20)
        d = E.dispatch(lay, P, G, tol=1e-12)
        x0, refs = d['x'], d['refs']
        sb = lay.sysd['shed_bus']
        v0 = math.hypot(x0[lay.ix[f'V{sb}:R']], x0[lay.ix[f'V{sb}:I']])
        res = {}
        for mode in ('avg', 'sw'):
            t0 = time.perf_counter()
            ts, vb, x = simulate(lay, x0, refs, lambda t: G, 0.02, mode)
            res[mode] = dict(max_dev=float(np.max(np.abs(vb - v0))), mean_dev=float(np.mean(vb - v0)),
                             wall=time.perf_counter() - t0, finite=bool(np.all(np.isfinite(x))))
        (U.OUT / 'selftest_y5.json').write_text(json.dumps(res, indent=1), encoding='utf-8')
        print(res)
        return 0
    od = U.OUT / 'y5'
    od.mkdir(parents=True, exist_ok=True)
    if (od / 'exit_code.txt').exists():
        print('refused: finished run exists')
        return 3
    cs, sel = cases()
    done = {(o['id'], o['case']) for o in U.load_jsonl(od / 'emt.jsonl')}
    with open(od / 'emt.jsonl', 'a', encoding='utf-8') as f:
        for pt, name, dG, expect in cs:
            if (pt['id'], name) in done:
                continue
            o = run_case(pt, name, dG, expect, sel)
            f.write(json.dumps(U.clean(o)) + '\n')
            f.flush()
            print(o['id'], name, o['observed'], o['expected'], o['R'], round(o['wall_s']), flush=True)
    (od / 'exit_code.txt').write_text('0', encoding='utf-8')
    U.write_sums(od)
    return 0


if __name__ == '__main__':
    C.lower_priority()
    sys.exit(main())
