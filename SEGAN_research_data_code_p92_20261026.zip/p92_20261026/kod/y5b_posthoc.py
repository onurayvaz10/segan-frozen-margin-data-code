"""POST HOC (not pre-specified): re-classification of the sealed Y5b records (OUT/y5v3/emt_v3.jsonl) with the edge
artifact of y5_emt.classify removed. classify computes the 50-ms envelopes on np.convolve(..., 'same'), whose last
W - 1 - W//2 = 2 records are zero-padded (about 0.4 pu spurious deviation), so the late envelope is inflated by ~0.04 pu
and every fully decayed response has R > 1. Here the envelopes use interior records only (as the divergence test of
classify already does); thresholds unchanged. Reads only the sealed file; writes OUT/y5v3_posthoc/posthoc.json."""
import json
import os
import sys

W = 5
OUT = os.environ['G92_OUT']


def env(ts, d, a, b):
    e = []
    u = a
    while u < b - 1e-9:
        w = [d[i] for i in range(len(ts)) if u <= ts[i] < u + 0.05]
        if w:
            e.append(max(w))
        u += 0.05
    return sum(e) / len(e) if e else None


def classify(o, Tr=0.25, T=2.75):
    ts, vs, e = o['ts'], o['vs'], o['vb_eq']
    n = len(ts)
    ti, d = ts[W:n - W], [abs(v - e) for v in vs[W:n - W]]
    if (d and max(d) > 0.5) or o['broke']:
        return 'diverged', None, None, None
    e1, e2 = env(ti, d, Tr + 0.5, Tr + 1.0), env(ti, d, T - 0.5, T)
    R = e2 / e1
    return ('growing' if R > 1.2 else 'decaying' if R < 0.8 else 'undetermined'), R, e1, e2


def main():
    rows = [json.loads(l) for l in open(os.path.join(OUT, 'y5v3', 'emt_v3.jsonl'), encoding='utf-8')]
    res = []
    for o in rows:
        cls, R, e1, e2 = classify(o)
        t_col = next((t for t, v in zip(o['ts'][W:-W], o['vs'][W:-W]) if abs(v - o['vb_eq']) > 0.5), None)
        res.append(dict(id=o['id'], case=o['case'], arm=o['arm'], expected=o['expected'], sealed=o['observed'],
                        posthoc=cls, R=R, env_early=e1, env_late=e2, t_collapse=t_col,
                        sat_frac_all=None if 'mod' not in o else {k: v['sat_frac'] for k, v in o['mod'].items()}))
    od = os.path.join(OUT, 'y5v3_posthoc')
    os.makedirs(od, exist_ok=True)
    with open(os.path.join(od, 'posthoc.json'), 'w', encoding='utf-8', newline='\n') as f:
        json.dump(res, f, indent=1)
    for r in res:
        print(r['id'], r['case'], r['arm'], 'expected', r['expected'], 'sealed', r['sealed'], 'posthoc', r['posthoc'],
              None if r['R'] is None else round(r['R'], 3), None if r['env_late'] is None else f"{r['env_early']:.3g}->{r['env_late']:.3g}",
              't_collapse', r['t_collapse'], r['sat_frac_all'])
    return 0


if __name__ == '__main__':
    sys.exit(main())
