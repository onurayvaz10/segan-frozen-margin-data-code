"""Common helpers of the P92 round (protocol protokol/P92_PROTOKOL_v1.txt): paths, sealed TSV records, statistics.

G92_S1  extracted folder development_20261026 of the S1 addition (read only)
G92_OUT output folder of this round
"""
import csv
import hashlib
import json
import math
import os
from pathlib import Path

os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('MKL_NUM_THREADS', '1')
import numpy as np  # noqa: E402

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OUT = Path(os.environ.get('G92_OUT', str(ROOT / 'out')))
S1 = Path(os.environ.get('G92_S1', str(ROOT / 'girdi' / 'development_20261026')))
TSV = S1 / 'out' / 'tsv'
TAU = 0.05
SEED = 20261026


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def num(v):
    if v is None or v == '':
        return None
    if v in ('True', 'False'):
        return v == 'True'
    try:
        return float(v)
    except ValueError:
        return v


def load_points():
    with open(TSV / 'TSV_a' / 'analysis' / 'points.csv', encoding='utf-8') as f:
        return [{k: num(v) for k, v in r.items()} for r in csv.DictReader(f)]


def selection():
    doc = json.loads((TSV / 'selection.json').read_text(encoding='utf-8'))
    return {p['id']: p for p in doc['points']}


def is_primary(r):
    return (r['abs_kappa'] is not None and r['abs_kappa'] >= TAU and r['ref_sign'] in (1.0, -1.0)
            and r['stage1_pin_ok'] is True)


def is_uncensored(r):
    return r['censored'] is False and r['ref_status'] == 'alpha'


def y2_set(rows):
    return [r for r in rows if is_primary(r) and is_uncensored(r)]


def load_jsonl(p):
    p = Path(p)
    return [json.loads(l) for l in open(p, encoding='utf-8')] if p.exists() else []


def clean(o):
    if isinstance(o, dict):
        return {k: clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [clean(v) for v in o]
    if isinstance(o, (np.floating, float)):
        v = float(o)
        return v if math.isfinite(v) else None
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.bool_,)):
        return bool(o)
    if isinstance(o, complex):
        return [o.real, o.imag]
    return o


def cluster_boot_mean(d, clusters, B=2000, seed=SEED):
    """Percentile cluster-bootstrap 95% interval of the mean of d (clusters resampled with replacement)."""
    d = np.asarray(d, float)
    cl = np.asarray(clusters)
    keys = np.unique(cl)
    idx = {k: np.nonzero(cl == k)[0] for k in keys}
    rng = np.random.default_rng(seed)
    ms = np.empty(B)
    for b in range(B):
        pick = rng.choice(keys, size=len(keys), replace=True)
        ii = np.concatenate([idx[k] for k in pick])
        ms[b] = d[ii].mean()
    return float(d.mean()), float(np.percentile(ms, 2.5)), float(np.percentile(ms, 97.5))


def wilson(k, n, z=1.959964):
    if n == 0:
        return (None, None)
    p = k / n
    den = 1 + z * z / n
    c = (p + z * z / (2 * n)) / den
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return (max(0.0, c - h), min(1.0, c + h))


def sign_test_one_sided(n_plus, n_minus):
    """Exact one-sided sign test P(X >= n_plus), X ~ Bin(n_plus + n_minus, 1/2)."""
    n = n_plus + n_minus
    if n == 0:
        return 1.0
    return float(sum(math.comb(n, k) for k in range(n_plus, n + 1)) / 2 ** n)


def write_sums(folder):
    folder = Path(folder)
    with open(folder / 'SHA256SUMS', 'w', encoding='utf-8', newline='\n') as f:
        for p in sorted(folder.iterdir()):
            if p.is_file() and p.name != 'SHA256SUMS':
                f.write(f'{sha(p)}  {p.name}\n')
