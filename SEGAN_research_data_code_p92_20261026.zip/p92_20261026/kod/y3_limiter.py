"""Y3 (protocol P92 section 3): GFM operating close to its current limit in the physically sized families.

72 points (24 per family, kappa0 >= 0.05, uncensored primary TSV points, fixed seeds) x 4 utilisation levels. A smooth
magnitude limiter (p = 20, back-calculation anti-windup kaw = kiv/kpv) is added to the GFM inner current reference with
Imax = |i_ref(x00)| / u_nom, x00 the unlimited dispatch; the set-points of the unlimited dispatch are kept and the
limited equilibrium is solved with them. Stage 1 (strict = False, as the F2 limiter study) and, if evaluable, Stage 2
(new reference margin and single-step relinearization).

  --selftest   one point, one level, into OUT/selftest_y3.jsonl
  --run        all cases into OUT/y3/limiter.jsonl (resumes; refuses if OUT/y3/exit_code.txt exists)
"""
import argparse
import json
import math
import sys
import time
import traceback
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import y_common as U  # noqa: E402
import ext_common as C  # noqa: E402
import ext_engine as E  # noqa: E402

U_NOM = (0.70, 0.80, 0.85, 0.88)
SYSTEMS = ('A2', 'B2', 'C')
N_PER = 24


def sample(rows):
    out = []
    for i, s in enumerate(SYSTEMS):
        pool = sorted([r for r in rows if r['system'] == s and r['kappa'] >= U.TAU], key=lambda r: r['id'])
        rng = np.random.default_rng(U.SEED + i)
        out += [pool[j] for j in sorted(rng.choice(len(pool), size=N_PER, replace=False))]
    return out


def iref_gfm(lay, x, refs):
    """Magnitude of the GFM inner current reference (the quantity the limiter acts on), as p5_current_limit.util."""
    ix = lay.ix
    g = lay.sysd['par']['gfm']
    z = g['w_ref'] + g['Rp'] * (refs[0] - x[ix['G:pm']])
    th = x[ix['G:th']]
    Idf, Iqf = E.park(th, x[ix['G:Irf']], x[ix['G:Iif']])
    Vdf, Vqf = E.park(th, x[ix['G:Vrf']], x[ix['G:Vif']])
    Voc = refs[2] + g['kq'] * (refs[1] - x[ix['G:qm']])
    Vdr = Voc - g['rv'] * Idf + z * g['lv'] * Iqf
    Vqr = -g['rv'] * Iqf - z * g['lv'] * Idf
    Idcr = g['kpv'] * (Vdr - Vdf) + g['kiv'] * x[ix['G:xid']] - g['cf'] * z * Vqf + g['kffi'] * Idf
    Iqcr = g['kpv'] * (Vqr - Vqf) + g['kiv'] * x[ix['G:xiq']] + g['cf'] * z * Vdf + g['kffi'] * Iqf
    return math.hypot(Idcr, Iqcr)


def one_case(r, spec, u_nom):
    t0 = time.perf_counter()
    o = dict(id=r['id'], system=r['system'], cluster=r['cluster'], u_nom=u_nom, kappa_unlim=r['kappa'],
             dGf_unlim=r['dGf'], dGref_unlim=r['dGref'])
    lay, G, P = C.BUILDERS[r['system']](spec)
    d = E.dispatch(lay, P, G, tol=1e-12)
    if not (d['ok'] or d['hist'][-1] <= 1e-8):
        o['status'] = 'dispatch failed'
        return o
    x00, refs = d['x'], d['refs']
    i0 = iref_gfm(lay, x00, refs)
    g = lay.sysd['par']['gfm']
    lay.sysd['gfm_ilim'] = dict(Imax=i0 / u_nom, p=20.0, kaw=g['kiv'] / g['kpv'])
    o.update(iref_unlim=i0, Imax=i0 / u_nom)
    x0, ok, _, _ = E.newton_fixed_refs(lay, x00, refs, G)
    if not ok:
        o['status'] = 'no equilibrium with imposed set-points'
        return o
    o['u0'] = iref_gfm(lay, x0, refs) / (i0 / u_nom)
    rec = C.stage1_at(lay, G, P, x0, refs, rec={}, strict=False)
    for k in ('excl', 'phys_gate', 'alpha0', 'dGf', 'omega', 'c', 'kappa', 'kappa_noc', 'kappa_L', 'kappa_V',
              'kappa_theta', 'kappa_rest', 'k_fd', 'curv', 'eps2', 'dG1st', 'dG2nd', 'I_gfm', 'Vmin'):
        o[k] = rec.get(k)
    if rec.get('excl') is not None:
        o['status'] = 'stage1 excluded'
        return o
    s2 = C.stage2(lay, G, P, rec, with_exact=False, x0=x0, refs=refs)
    for k in ('dGref', 'ref_status', 'ref_sign', 'rel_err', 'censored', 'fold', 'F_single', 'dG_sec1', 'dG_sec2',
              'ref_newton_solves'):
        o[k] = s2.get(k)
    o['status'] = 'ok'
    o['t_s'] = time.perf_counter() - t0
    return o


def main():
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument('--selftest', action='store_true')
    g.add_argument('--run', action='store_true')
    a = ap.parse_args()
    rows = U.y2_set(U.load_points())
    pts = sample(rows)
    sel = U.selection()
    U.OUT.mkdir(parents=True, exist_ok=True)
    if a.selftest:
        o = one_case(pts[0], sel[pts[0]['id']], 0.85)
        (U.OUT / 'selftest_y3.jsonl').write_text(json.dumps(U.clean(o)) + '\n', encoding='utf-8')
        print({k: o.get(k) for k in ('id', 'u_nom', 'u0', 'status', 'kappa_unlim', 'kappa', 'dGf_unlim', 'dGf',
                                      'dGref_unlim', 'dGref', 'ref_sign', 't_s')})
        return 0
    od = U.OUT / 'y3'
    od.mkdir(parents=True, exist_ok=True)
    if (od / 'exit_code.txt').exists():
        print('refused: finished run exists')
        return 3
    (od / 'sample.json').write_text(json.dumps([p['id'] for p in pts]), encoding='utf-8')
    done = {(o['id'], o['u_nom']) for o in U.load_jsonl(od / 'limiter.jsonl')}
    t0 = time.perf_counter()
    with open(od / 'limiter.jsonl', 'a', encoding='utf-8') as f, open(od / 'log.txt', 'a', encoding='utf-8') as lg:
        for k, r in enumerate(pts):
            for u in U_NOM:
                if (r['id'], u) in done:
                    continue
                try:
                    o = one_case(r, sel[r['id']], u)
                except Exception as exc:  # noqa: BLE001
                    o = dict(id=r['id'], system=r['system'], u_nom=u, status='error',
                             error=f'{type(exc).__name__}: {exc}', tb=traceback.format_exc()[-400:])
                f.write(json.dumps(U.clean(o)) + '\n')
                f.flush()
                lg.write(f"{k + 1}/{len(pts)} {r['id']} u={u} {o.get('status')} kappa={o.get('kappa')} "
                         f"sign={o.get('ref_sign')} t={time.perf_counter() - t0:.0f}s\n")
                lg.flush()
    (od / 'exit_code.txt').write_text('0', encoding='utf-8')
    U.write_sums(od)
    return 0


if __name__ == '__main__':
    C.lower_priority()
    sys.exit(main())
