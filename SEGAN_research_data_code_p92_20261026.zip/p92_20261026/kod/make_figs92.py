"""Figures of the P92 round (all numbers read from files; nothing typed in). Output: sekil/*.png at 600 dpi.

fig_kappa_sign_v2.png    revision of Figure 8: legend and labels outside the data, inset on the optimistic quadrant,
                         clipped points marked.
fig_accuracy_v2.png      revision of Figure 10: (a) MAE against the number of extra equilibria, including the
                         Newton-kappa estimators (Y2); (b) |relative error| vs eps2 (unchanged content).
fig_stress_ramp.png      new Figure 11: (a) GFM utilisation study (Y3); (b) ramped shedding envelopes (Y4).
Sources: G92_S1/out/tsv/TSV_a/analysis/points.csv, G92_OUT/summary/*.csv, G92_OUT/y3/limiter.jsonl,
G92_OUT/y4/ramp.jsonl.
"""
import csv
import json
import math
import sys
from pathlib import Path

import matplotlib
import numpy as np

matplotlib.use('Agg')
import matplotlib.pyplot as plt  # noqa: E402

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import y_common as U  # noqa: E402

FIG = HERE.parent / 'sekil'
FIG.mkdir(exist_ok=True)
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8.5, 'axes.titlesize': 9, 'axes.labelsize': 8.5,
                     'legend.fontsize': 7.5, 'xtick.labelsize': 7.5, 'ytick.labelsize': 7.5,
                     'mathtext.fontset': 'dejavusans', 'axes.linewidth': 0.7, 'savefig.bbox': 'tight',
                     'savefig.pad_inches': 0.03})
W2 = 7.48
COL = {'A2': '#1b9e77', 'B2': '#d95f02', 'C': '#7570b3'}
DPI = 600


def save(fig, name):
    fig.savefig(FIG / f'{name}.png', dpi=DPI)
    plt.close(fig)
    print('wrote', name)


def panel(ax, s, x=-0.12, y=1.03):
    ax.text(x, y, s, transform=ax.transAxes, fontsize=9.5, fontweight='bold', va='bottom')


def fnum(v):
    try:
        x = float(v)
        return x if math.isfinite(x) else float('nan')
    except (TypeError, ValueError):
        return float('nan')


def fig_kappa_sign():
    pts = list(csv.DictReader(open(U.TSV / 'TSV_a' / 'analysis' / 'points.csv', encoding='utf-8')))
    fig, (a, b) = plt.subplots(1, 2, figsize=(W2, 3.1), gridspec_kw=dict(width_ratios=[1, 1.15], wspace=0.32))
    fams = ['A2', 'B2', 'C']
    for i, s in enumerate(fams):
        k = np.array([fnum(r['kappa']) for r in pts if r['system'] == s and r['source'] != 'search'])
        ks = np.array([fnum(r['kappa']) for r in pts if r['system'] == s and r['source'] == 'search'])
        y = i + np.random.default_rng(i).uniform(-0.18, 0.18, len(k))
        a.scatter(k, y, s=5, color=COL[s], alpha=0.55, lw=0)
        a.scatter(ks, i + 0.32 + 0 * ks, s=14, marker='v', facecolor='none', edgecolor=COL[s], lw=0.8)
    a.axvspan(-0.05, 0.05, color='#bbbbbb', alpha=0.35, lw=0)
    a.axvline(0, color='k', lw=0.6)
    a.set_yticks(range(3), fams)
    a.set_xlabel(r'first-order coefficient $\hat\kappa$')
    a.set_xlim(-0.6, 1.2)
    a.set_ylim(-0.6, 2.7)
    panel(a, '(a)')
    ins = b.inset_axes([0.07, 0.52, 0.30, 0.36])
    for s in fams:
        rr = [r for r in pts if r['system'] == s and abs(fnum(r['kappa'])) >= 0.05 and r['ref_sign'] not in ('0', '0.0')]
        kk = np.array([fnum(r['kappa']) for r in rr])
        xr = np.where(kk < 1, kk / (1 - np.where(kk < 1, kk, 0)), np.inf)
        clip = xr > 1.45
        x = np.minimum(xr, 1.45)
        yv = 100 * np.array([fnum(r['rel_err']) for r in rr])
        src = np.array([r['source'] for r in rr])
        m = src != 'search'
        b.scatter(x[m & ~clip], yv[m & ~clip], s=7, color=COL[s], alpha=0.65, lw=0, label=f'{s} (sampled)')
        b.scatter(x[m & clip], yv[m & clip], s=12, marker='>', color=COL[s], alpha=0.65, lw=0)
        b.scatter(x[~m], yv[~m], s=16, marker='v', facecolor='none', edgecolor=COL[s], lw=0.8, label=f'{s} (search)')
        neg = kk < 0
        ins.scatter(x[neg & m], yv[neg & m], s=10, color=COL[s], lw=0)
        ins.scatter(x[neg & ~m], yv[neg & ~m], s=16, marker='v', facecolor='none', edgecolor=COL[s], lw=0.8)
    for ax in (b, ins):
        ax.axhline(0, color='k', lw=0.6)
        ax.axvline(0, color='k', lw=0.6)
    b.set_xlim(-0.3, 1.5)
    b.set_ylim(-20, 106)
    ins.set_xlim(-0.22, 0.0)
    ins.set_ylim(-16, 0)
    ins.tick_params(labelsize=6)
    ins.set_title(r'$\hat\kappa<0$ (18 points)', fontsize=6.5, pad=2)
    b.set_xlabel(r'predicted relative shift $\hat\kappa/(1-\hat\kappa)$ ($\triangleright$: clipped at 1.45)')
    b.set_ylabel(r'observed $(\Delta G_t^*-\Delta G_f^*)/\Delta G_f^*$ (%)')
    b.legend(loc='upper center', bbox_to_anchor=(0.5, -0.2), ncol=3, fontsize=6.3, frameon=False)
    panel(b, '(b)')
    save(fig, 'fig_kappa_sign_v2')


def fig_accuracy():
    est = list(csv.DictReader(open(U.OUT / 'summary' / 'y2_estimators.csv', encoding='utf-8')))
    pts = list(csv.DictReader(open(U.TSV / 'TSV_a' / 'analysis' / 'points.csv', encoding='utf-8')))
    fig, (a, b) = plt.subplots(1, 2, figsize=(W2, 2.9), gridspec_kw=dict(wspace=0.34))
    lab = dict(frozen='frozen', first_order='first order', second_order='second order (Eq. 18)',
               secant_1='secant, 1 solve', secant_2='secant, 2 solves', newton_kappa_1=r'Newton-$\kappa$, 1 solve',
               kappa_started_secant_1=r'$\kappa$-started secant, 1 solve', newton_kappa_2=r'Newton-$\kappa$, 2 solves')
    off = dict(frozen=(4, 2), first_order=(4, -9), second_order=(4, 3), secant_1=(4, -9), secant_2=(-62, 4),
               newton_kappa_1=(7, -3), kappa_started_secant_1=(7, -3), newton_kappa_2=(7, -3))
    for r in est:
        n = int(r['extra_equilibria'])
        nk = r['estimator'].startswith('newton') or r['estimator'].startswith('kappa')
        xj = n + (0.12 if nk else -0.12)
        a.scatter(xj, fnum(r['MAE']), s=26, marker='D' if nk else 'o', color='#c0392b' if nk else '#2b5d8c', lw=0)
        a.annotate(lab[r['estimator']], (xj, fnum(r['MAE'])), fontsize=5.8, xytext=off[r['estimator']],
                   textcoords='offset points')
    a.set_yscale('log')
    a.set_xticks([0, 1, 2])
    a.set_xlim(-0.5, 3.1)
    a.set_xlabel('extra post-shedding equilibria per point')
    a.set_ylabel('MAE against the reference (pu)')
    a.text(0.98, 0.97, 'blue: earlier estimators\nred: Newton-$\\kappa$ (this study)', transform=a.transAxes, fontsize=6, ha='right', va='top')
    panel(a, '(a)')
    rr = [r for r in pts if r.get('censored') in ('False', 'false', '0', '') and abs(fnum(r['kappa'])) >= 0.05
          and math.isfinite(fnum(r['eps2'])) and fnum(r['eps2']) > 0]
    e2 = np.array([fnum(r['eps2']) for r in rr])
    e1 = np.array([abs(fnum(r['relerr_first_order'])) for r in rr])
    e2n = np.array([abs(fnum(r['relerr_second_order'])) for r in rr])
    b.scatter(e2, 100 * e1, s=6, color='#2b5d8c', alpha=0.6, lw=0, label='first order')
    b.scatter(e2, 100 * e2n, s=6, color='#c0392b', alpha=0.6, lw=0, label='second order')
    xx = np.logspace(math.log10(max(e2.min(), 1e-4)), math.log10(e2.max()), 50)
    b.plot(xx, 100 * xx / 4, color='k', lw=0.8, ls='--', label=r'$\varepsilon_2/4$')
    b.set_xscale('log')
    b.set_yscale('log')
    b.set_xlabel(r'curvature indicator $\varepsilon_2=-2\hat\rho^{\prime\prime}\Delta G_f^*/(1-\hat\kappa)^2$')
    b.set_ylabel('|relative error| (%)')
    b.legend(frameon=False, loc='lower right')
    panel(b, '(b)')
    save(fig, 'fig_accuracy_v2')


def fig_stress_ramp():
    lv = list(csv.DictReader(open(U.OUT / 'summary' / 'y3_levels.csv', encoding='utf-8')))
    fig, (a, b) = plt.subplots(1, 2, figsize=(W2, 2.9), gridspec_kw=dict(wspace=0.34))
    u = np.array([fnum(r['u_nom']) for r in lv])
    ev = np.array([fnum(r['evaluable']) for r in lv])
    a.plot(u, 100 * np.array([fnum(r['kappa_neg']) for r in lv]) / ev, 'o-', color='#2b5d8c', ms=4, lw=1,
           label=r'predicted optimistic ($\hat\kappa<0$)')
    a.plot(u, 100 * np.array([fnum(r['obs_optimistic']) for r in lv]) / ev, 's-', color='#c0392b', ms=4, lw=1,
           label='observed optimistic')
    acc = np.array([fnum(r['R1_acc']) for r in lv])
    a.plot(u, 100 * acc, '^--', color='k', ms=4, lw=0.8, label=r'agreement of sign $\hat\kappa$ ($|\hat\kappa|\geq0.05$)')
    for x, e in zip(u, ev):
        a.annotate(f'n={int(e)}', (x, 106), fontsize=5.8, ha='center')
    a.set_xlabel(r'GFM current-reference utilisation at $x_0$ (nominal)')
    a.set_ylabel('% of evaluable cases')
    a.set_ylim(0, 112)
    a.set_xticks(u)
    a.legend(frameon=False, fontsize=6.0, loc='center left')
    panel(a, '(a)')
    recs = U.load_jsonl(U.OUT / 'y4' / 'ramp.jsonl')
    sty = {0.0: ('-', 'step'), 0.25: ('--', '$T_r$ = 0.25 s'), 1.0: (':', '$T_r$ = 1 s')}
    for r in recs:
        if r['P_set'] != 0.65 or r['case'] not in ('reference', 'frozen') or r['T_r'] not in sty:
            continue
        if r['case'] == 'frozen' and r['T_r'] != 0.0:
            continue
        tr = np.array(r['trace'])
        t, v = tr[:, 0] - r['T_r'], np.abs(tr[:, 1])
        edges = np.arange(0, t.max() - 0.05 + 1e-9, 0.05)
        env = np.array([v[(t >= e0) & (t < e0 + 0.05)].max() if np.any((t >= e0) & (t < e0 + 0.05)) else np.nan
                        for e0 in edges])
        ls, lab = sty[r['T_r']]
        colr = '#c0392b' if r['case'] == 'reference' else '#1b9e77'
        b.plot(edges + 0.025, env, ls=ls, color=colr, lw=1.0, label=f"{r['case']} amount, {lab}")
        if r['diverged']:
            b.plot(edges[-1] + 0.025, min(env[~np.isnan(env)][-1], 1.5), marker='x', color=colr, ms=6, mew=1.2)
    b.set_yscale('log')
    b.set_ylim(1e-6, 3)
    b.set_xlim(0, 3)
    b.set_xlabel('time after the end of the ramp (s)')
    b.set_ylabel('50-ms envelope of |bus voltage deviation| (pu)')
    b.legend(frameon=False, fontsize=6.0, loc='upper right')
    panel(b, '(b)')
    save(fig, 'fig_stress_ramp')


if __name__ == '__main__':
    for w in sys.argv[1:] or ['kappa_sign', 'accuracy', 'stress_ramp']:
        globals()['fig_' + w]()
