"""Title page (new title, otherwise unchanged), Highlights and cover letter of the P92 version.
Usage: python -I letters92.py OLD_SUBMISSION_FOLDER OUTDIR"""
import sys
from pathlib import Path

from docx import Document
from docx.shared import Pt

OLD = ('Operating-point shift and the frozen stability margin after resistive load shedding: an analytical sign rule '
       'with protocol-fixed computational evaluation')
NEW = ('Decision-induced bias of frozen small-signal margins in resistive load shedding: a port-admittance sign rule '
       'for grid-forming microgrids')
HIGHLIGHTS = [
    'Load shedding moves the equilibrium and biases frozen small-signal margins',
    'Sign of a port-admittance coefficient κ matched all 922 two-sign test points',
    'κ as margin derivative gives Newton estimates 12× more accurate than secants',
    'Near the GFM current limit, frozen margins turn optimistic in most points',
    'Steps to the boundary diverge; 0.25-s ramps reached it without divergence',
]
LETTER = [
    'Dear Editor,',
    f'We submit “{NEW}” for consideration as a Research Article in Sustainable Energy, Grids and Networks.',
    'The system-level problem. Remedial actions such as load shedding are often screened with a small-signal stability '
    'margin computed at the operating point before the action, although the action itself moves the equilibrium. In '
    'islanded, inverter-dominated microgrids with constant power loads, a margin read with the operating point frozen '
    'can therefore differ systematically from the margin that applies after re-equilibration. Operators and planning '
    'tools need to know in which direction this error goes, why, and when it is worth computing the post-action state.',
    'What is new. Operating-point-dependent stability, certificates over operating regions, eigenvalue sensitivities '
    'and the linearization of small-signal constraints around successive operating points in stability-constrained '
    'optimal power flow are established; our paper does not claim them. Its subject is the decision-induced bias: we '
    'derive a first-order coefficient for the error of the frozen margin from the sensitivity of a critical '
    'port-admittance crossing, attribute it to voltage-magnitude, angle-rotation, crossing-frequency and source terms, '
    'show that the angle term vanishes for isotropic sources, state when the sign conclusion is rigorous, and give a '
    'second-order estimate with a reliability indicator.',
    'Evidence and its limits. In a protocol-fixed two-sign test of 922 operating points of three physically sized '
    'families, including a meshed five-bus network, the sign of the coefficient predicted the direction of the bias in '
    'all 18 optimistic and 904 conservative cases, where the majority-class rule missed every optimistic case and a '
    'classifier trained on the outcomes reached a balanced accuracy of 0.87 on unseen families. Studies whose analysis '
    'was fixed before computation show that the coefficient, used as the derivative of the margin equation, makes one '
    'post-shedding equilibrium give errors twelve times smaller than a secant step of equal cost; that it can trigger '
    'relinearization only where needed; that a grid-forming source close to its current limit makes the frozen margin '
    'optimistic in most points, with sign errors that are false alarms only; and that ramped shedding reached the '
    'small-signal boundary without the divergence seen after a step. All evidence is offline computation in '
    'average-value models with a single grid-forming source; frozen and corrected margins remain screening values, not '
    'safe step-shedding limits, and the limitations are stated in Section 7.5.',
    'Fit to SEGAN. The paper addresses dynamics and stability of converter-dominated grids and contributes mathematical '
    'and computational methods for operational decisions, in line with recent SEGAN work on operating-point '
    'sensitivities of small-signal stability and on demand-side actions for small-signal stability.',
    'Transparency. Supplementary Material S1 contains the model and analysis code, the internally fixed protocol records '
    'with hashes, the sealed outputs and the scripts of every study; Supplementary Methods S2 contains the proofs, the '
    'complete model, the protocol records, an intermediate prospective test that we do not use as evidence, and all '
    'result tables.',
    'The work has not been published and is not under consideration elsewhere. The authors report no funding and no '
    'competing interests.',
    'Sincerely,',
    'Özgür Tomak (corresponding author), on behalf of Onur Ayvaz and Özgür Tomak, ozgur.tomak@giresun.edu.tr',
]


def main():
    old, out = Path(sys.argv[1]), Path(sys.argv[2])
    out.mkdir(parents=True, exist_ok=True)
    d = Document(old / 'Title_page.docx')
    hit = 0
    for p in d.paragraphs:
        if OLD in p.text:
            for r in p.runs[1:]:
                r.text = ''
            p.runs[0].text = p.text.replace(OLD, NEW) if len(p.runs) == 1 else NEW
            hit += 1
    assert hit == 1, hit
    d.save(out / 'Title_page.docx')
    for name, paras, bullets in (('Highlights.docx', HIGHLIGHTS, True), ('Cover_letter_journal.docx', LETTER, False)):
        doc = Document()
        doc.styles['Normal'].font.name = 'Times New Roman'
        doc.styles['Normal'].font.size = Pt(11)
        if bullets:
            doc.add_heading('Highlights', level=1)
        for t in paras:
            doc.add_paragraph(t, style='List Bullet' if bullets else None)
        doc.save(out / name)
    print('ok', [len(h) for h in HIGHLIGHTS])


if __name__ == '__main__':
    main()
