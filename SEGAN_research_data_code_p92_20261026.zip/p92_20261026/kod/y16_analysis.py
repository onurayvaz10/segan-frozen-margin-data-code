"""Y1 and Y6 (protocol P92 sections 5 and 6): post hoc analyses of the sealed TSV_a records, no model evaluation.

Y1  kappa-triggered relinearization: accept the frozen amount when kappa >= tau, otherwise decide by the sign of the
    single-step relinearization F_single; compared with frozen-only and always-relinearize.
Y6  data-driven baseline: class-weighted L2 logistic regression on predictor quantities at x0 (kappa and its
    components excluded), leave-one-family-out and clustered 5-fold cross-validation, against R1, R4 and R5.
Writes OUT/y16/{y1_policy.csv, y6_baseline.csv, y16_summary.json}.
"""
import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
from scipy.optimize import minimize

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import y_common as U  # noqa: E402

SYSTEMS = ('A2', 'B2', 'C')
SHED = dict(A2=dict(P='P_set', s_pll='s_pll', Kiv='Kiv'), B2=dict(P='P2', s_pll='s_pll2', Kiv='Kiv2'),
            C=dict(P='P3', s_pll='s_pll3', Kiv='Kiv3'))


# ------------------------------------------------------------------------------------------------------------- Y1
def truth(r):
    """+1 safe (reference beyond the frozen amount or censored), -1 unsafe, 0 tie."""
    if r['censored'] is True:
        return 1
    return int(r['ref_sign']) if r['ref_sign'] is not None else None


def policy_rows(rows, label):
    out = []
    usable = [r for r in rows if truth(r) is not None]
    for name, tau in (('frozen_only', None), ('always_relinearize', -math.inf), ('kappa_trigger_0', 0.0),
                      ('kappa_trigger_0.05', 0.05), ('kappa_trigger_0.10', 0.10)):
        acc = unsafe = refuse_safe = eq = n_tie_acc = missing = 0
        for r in usable:
            t = truth(r)
            if tau is None or (tau != -math.inf and r['kappa'] >= tau):
                decide = 1
            else:
                eq += 1
                F = r['F_single']
                if F is None:
                    missing += 1
                    decide = -1          # no equilibrium at the frozen amount: refuse
                else:
                    decide = 1 if F > 0 else -1
            if decide == 1:
                acc += 1
                if t == -1:
                    unsafe += 1
                if t == 0:
                    n_tie_acc += 1
            elif t == 1:
                refuse_safe += 1
        out.append(dict(set=label, policy=name, n=len(usable), accepted=acc, unsafe_accepted=unsafe,
                        tie_accepted=n_tie_acc, safe_refused=refuse_safe, extra_equilibria=eq,
                        extra_equilibria_frac=eq / len(usable), F_single_missing=missing))
    return out


def natural_fraction():
    out = {}
    for s in SYSTEMS:
        ev = [r for r in U.load_jsonl(U.S1 / 'out' / f'p2_explore_{s}.jsonl') if r.get('excl') is None]
        k = np.array([r['kappa'] for r in ev])
        out[s] = dict(valid=len(ev), below_0=int(np.sum(k < 0)), below_tau=int(np.sum(k < U.TAU)),
                      below_0p10=int(np.sum(k < 0.10)), frac_below_tau=float(np.mean(k < U.TAU)) if len(k) else None)
    return out


# ------------------------------------------------------------------------------------------------------------- Y6
def features(r):
    m = SHED[r['system']]
    P, V = r[m['P']], r['V_b']
    return [P / V ** 2, r['omega'], r['pi_d_re'], r['pi_x_abs'], r[m['s_pll']], r[m['Kiv']], r['rx'], r['lv'],
            r['dGf_over_GR'], r['log10_cond_J'], r['gap_rel'], r['aniso'], r['xi_d'], r['xi_q'], r['dv_rel_at_margin']]


FEATURE_NAMES = ['P_b/V_b^2', 'omega', 'Re pi_d', '|pi_x|', 's_pll(shed bus)', 'Kiv(shed bus)', 'R/X', 'lv', 'dGf/G_R',
                 'log10 cond J', 'gap_rel', 'anisotropy', 'xi_d', 'xi_q', 'dv_rel_at_margin']


def fit_logit(X, y, C=1.0):
    n, p = X.shape
    w = np.where(y == 1, n / (2.0 * max(1, y.sum())), n / (2.0 * max(1, n - y.sum())))
    s = 2 * y - 1

    def f(b):
        z = X @ b[1:] + b[0]
        m = s * z
        loss = np.sum(w * np.logaddexp(0, -m)) + 0.5 / C * np.sum(b[1:] ** 2)
        g0 = -w * s / (1 + np.exp(m))
        return loss, np.concatenate([[g0.sum()], X.T @ g0 + b[1:] / C])
    b = minimize(f, np.zeros(p + 1), jac=True, method='L-BFGS-B').x
    return b


def predict(b, X):
    return (X @ b[1:] + b[0] > 0).astype(int)


def scores(y, yhat):
    pos, neg = y == 1, y == 0
    sens = float(np.mean(yhat[pos] == 1)) if pos.any() else None
    spec = float(np.mean(yhat[neg] == 0)) if neg.any() else None
    bal = 0.5 * (sens + spec) if sens is not None and spec is not None else None
    return dict(n=int(len(y)), n_opt=int(pos.sum()), sensitivity=sens, specificity=spec, balanced=bal,
                errors=int(np.sum(yhat != y)))


def y6(prim):
    X = np.array([features(r) for r in prim], float)
    y = np.array([1 if r['ref_sign'] == -1 else 0 for r in prim])
    fam = np.array([r['system'] for r in prim])
    cl = np.array([r['cluster'] for r in prim])
    rules = dict(R1=np.array([1 if r['kappa'] < 0 else 0 for r in prim]),
                 R4=np.array([1 if r['eta_re'] < 0 else 0 for r in prim]),
                 R5=np.array([1 if r['kappa_L'] < 0 else 0 for r in prim]))
    rows = []
    # leave one family out
    yhat = np.zeros_like(y)
    for s in SYSTEMS:
        tr, te = fam != s, fam == s
        mu, sd = X[tr].mean(0), X[tr].std(0) + 1e-12
        b = fit_logit((X[tr] - mu) / sd, y[tr])
        yhat[te] = predict(b, (X[te] - mu) / sd)
        rows.append(dict(scheme='leave-family-out', test=s, model='logistic', **scores(y[te], yhat[te])))
        for k, v in rules.items():
            rows.append(dict(scheme='leave-family-out', test=s, model=k, **scores(y[te], v[te])))
    rows.append(dict(scheme='leave-family-out', test='pooled', model='logistic', **scores(y, yhat)))
    for k, v in rules.items():
        rows.append(dict(scheme='leave-family-out', test='pooled', model=k, **scores(y, v)))
    # clustered 5-fold
    keys = np.unique(cl)
    rng = np.random.default_rng(U.SEED)
    fold_of = dict(zip(keys, rng.permutation(len(keys)) % 5))
    folds = np.array([fold_of[c] for c in cl])
    yhat5 = np.zeros_like(y)
    for k in range(5):
        tr, te = folds != k, folds == k
        mu, sd = X[tr].mean(0), X[tr].std(0) + 1e-12
        b = fit_logit((X[tr] - mu) / sd, y[tr])
        yhat5[te] = predict(b, (X[te] - mu) / sd)
    rows.append(dict(scheme='clustered-5-fold', test='pooled', model='logistic', **scores(y, yhat5)))
    # in-sample fit (optimistic upper bound for the baseline)
    mu, sd = X.mean(0), X.std(0) + 1e-12
    b = fit_logit((X - mu) / sd, y)
    rows.append(dict(scheme='in-sample (upper bound)', test='pooled', model='logistic',
                     **scores(y, predict(b, (X - mu) / sd))))
    coef = dict(zip(FEATURE_NAMES, [float(v) for v in b[1:]]))
    return rows, coef


def main():
    rows = U.load_points()
    sel = [r for r in rows if r['stage1_pin_ok'] is True]
    prim = [r for r in sel if U.is_primary(r)]
    od = U.OUT / 'y16'
    od.mkdir(parents=True, exist_ok=True)
    pol = policy_rows(sel, 'all_selected') + policy_rows(prim, 'primary')
    with open(od / 'y1_policy.csv', 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(pol[0]))
        w.writeheader()
        w.writerows(pol)
    y6rows, coef = y6(prim)
    with open(od / 'y6_baseline.csv', 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(y6rows[0]))
        w.writeheader()
        w.writerows(y6rows)
    summ = dict(n_selected=len(sel), n_primary=len(prim), natural_fraction=natural_fraction(), y1=pol, y6=y6rows,
                y6_insample_coefficients=coef)
    (od / 'y16_summary.json').write_text(json.dumps(U.clean(summ), indent=1), encoding='utf-8')
    for r in pol:
        print(r)
    for r in y6rows:
        print(r)
    print(json.dumps(summ['natural_fraction']))


if __name__ == '__main__':
    main()
