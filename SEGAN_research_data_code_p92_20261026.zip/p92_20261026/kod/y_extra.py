"""Additional reporting quantities (post hoc, no model evaluation): MAE intervals (cluster bootstrap) and mean
|relative error| of the Newton-kappa estimators for the manuscript table; kappa-triggered relinearization (Y1 rule)
applied to the utilisation study (Y3). Writes OUT/summary/y_extra.json."""
import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import y_common as U  # noqa: E402

out = {}
recs = U.load_jsonl(U.OUT / 'y2' / 'newton.jsonl')
for k in ('N1', 'N1s', 'N2'):
    rr = [r for r in recs if r.get(k) is not None]
    ae = [abs(r[k] - r['dGref']) for r in rr]
    m, lo, hi = U.cluster_boot_mean(ae, [r['cluster'] for r in rr])
    rel = np.array([abs(r[k] - r['dGref']) / r['dGref'] for r in rr])
    out[k] = dict(n=len(rr), MAE=m, lo=lo, hi=hi, mean_abs_rel_pct=float(100 * rel.mean()),
                  p95_abs_rel_pct=float(100 * np.percentile(rel, 95)), overshoot=int(sum(r[k] > r['dGref'] for r in rr)))
miss = [r for r in recs if r.get('status') != 'ok']
out['missing'] = [dict(id=r['id'], kappa0=r['kappa0'], status=r['status']) for r in miss]
y3 = [r for r in U.load_jsonl(U.OUT / 'y3' / 'limiter.jsonl') if r.get('status') == 'ok' and r.get('ref_sign') is not None]
pol = {}
for u in (0.70, 0.80, 0.85, 0.88):
    rs = [r for r in y3 if abs(r['u_nom'] - u) < 1e-9]
    frozen_unsafe = sum(1 for r in rs if r['ref_sign'] == -1)
    trig = [r for r in rs if r['kappa'] < U.TAU]
    unsafe = 0
    for r in rs:
        if r['kappa'] >= U.TAU:
            unsafe += r['ref_sign'] == -1
        else:
            F = r.get('F_single')
            unsafe += (F is not None and F > 0 and r['ref_sign'] == -1)
    pol[str(u)] = dict(n=len(rs), frozen_only_unsafe=frozen_unsafe, triggered=len(trig), kappa_trigger_unsafe=int(unsafe),
                       missed_optimistic_by_sign=sum(1 for r in rs if r['ref_sign'] == -1 and r['kappa'] >= 0))
out['y3_policy'] = pol
(U.OUT / 'summary' / 'y_extra.json').write_text(json.dumps(U.clean(out), indent=1), encoding='utf-8')
print(json.dumps(U.clean(out), indent=1))
