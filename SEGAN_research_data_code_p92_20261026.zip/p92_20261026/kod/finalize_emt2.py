"""Insert the Y5b result (protocol P92_EMT v3 + v3_1..v3_3, sealed run Y5B_20261026_a, post hoc re-classification
y5b_posthoc.py) into ms_v3_plan.txt and s2_appG_plan.txt and write the report lines ms/y5b_rapor.txt, ms/ayna_durum.txt.
Archived copies of both plans: research_intelligence/archive/*_before_v3emt_*.txt."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
p = ROOT / 'ms' / 'ms_v3_plan.txt'
t = p.read_text(encoding='utf-8')
END6 = 'dominates the response before the small-signal mode does.'
NEW6 = (END6 + '\n\n**Repeat with more modulation headroom (post hoc, S2 Appendix G.8).** Because the collapse could reflect '
        'the 690-V DC link rather than the margin, the six cases were repeated with min-max zero-sequence injection '
        '(equivalent to symmetrical space-vector PWM; linear range larger by 15.5%), everything else unchanged, under a '
        'protocol written after the result above and amended three times before any case was run (independent code '
        'audit, no-shedding self-test); an averaged-model arm served as control. The pre-specified verdict is not '
        'evaluable: the classifier inherited from the first protocol inflates its late envelope by about 0.04 pu through '
        'an edge artifact of its moving average, so the control arm labelled every decaying response as growing, and in '
        'the three remaining cases the modulator saturated before the switched and averaged trajectories separated. '
        'Re-classified with the artifact removed (post hoc), the control arm agreed with the expectation in all six '
        'cases. In the switching model the three amounts inside the reference margin no longer collapsed but stayed in '
        'the switching-ripple band (50-ms envelope about 0.06 pu, envelope ratio 0.96–1.04) for 2.5 s, and two of the '
        'three amounts beyond it collapsed: the member (0.65, 0.20) beyond its margin at 0.58 s, and A2-F00993, whose '
        'frozen margin accepts the amount, at 0.46 s (0.79 s in the averaged model). The third, A2-F01921, diverged in '
        'the averaged model at 0.90 s but remained in the ripple band of the switching model. Even with injection, the '
        'GFM modulator saturated in 1–3% of its evaluations at the A2 points. These observations agree with the '
        'direction of the frozen-margin bias at one of the two optimistic points but do not establish it.')
assert t.count(END6) == 1
t = t.replace(END6, NEW6)
OLD75 = ('no electromagnetic-transient simulation, switching, delays, protection, hardware-in-the-loop or field data; '
         'in particular, the effect of PWM delay on the 90--105 Hz critical mode is not assessed.')
NEW75 = ('no independently built electromagnetic-transient model, protection, hardware-in-the-loop or field data; '
         'switching and sampling delay enter only through the checks of Section 6.7, which reuse the same device '
         'equations, so the effect of PWM delay on the 90--105 Hz critical mode is assessed only there.')
assert t.count(OLD75) == 1
t = t.replace(OLD75, NEW75)
OLDLIM = t[t.index('The switching-level check (Section 6.7) shows'):]
OLDLIM = OLDLIM[:OLDLIM.index('control bandwidth.') + len('control bandwidth.')]
NEWLIM = ('The switching-level checks (Section 6.7) show that the average-value results presume adequate modulation '
          'headroom and control bandwidth: with sinusoidal PWM and the given DC-link voltage the tested model is '
          'unstable at 10 kHz and saturates at 20 kHz; with space-vector-equivalent modulation at 20 kHz, amounts inside '
          'the reference margin remain bounded and one of the two optimistic points collapses as predicted, but neither '
          'pre-specified direction test was evaluable, the repeat was designed after the first result, and its classifier '
          'had to be corrected post hoc.')
t = t.replace(OLDLIM, NEWLIM)
p.write_text(t, encoding='utf-8')

s = ROOT / 'ms' / 's2_appG_plan.txt'
u = s.read_text(encoding='utf-8')
OLDG7 = ('A modulation scheme with more linear range (for example third-harmonic injection) or a higher DC-link voltage '
         'would change the model and was not tested.')
assert u.count(OLDG7) == 1
u = u.replace(OLDG7, 'A modulation scheme with more linear range was tested afterwards (G.8).')
if '## G.8' not in u:
    u += ('\n\n## G.8 Repeat with min-max zero-sequence injection (protocol P92_EMT v3, change notes v3_1–v3_3; post hoc)\n\n'
          'Written after the result of G.7, before any repeat case was run. Single model change: both modulators add the '
          'zero-sequence voltage $v_0 = -(\\max_k v_k + \\min_k v_k)/2$ (symmetrical space-vector equivalent; linear range '
          '$2/\\sqrt{3}$ instead of 1); 20 kHz, $\\Delta t = T_s/20$, one-period delay, the same six cases and thresholds. '
          'Without shedding the peak phase modulation fell from 1.061 (GFM) and 1.042 (CPL) to 0.904 and 0.902, with no '
          'saturation. Additions: an averaged-model control arm (same integrator, step and classifier); post-shedding '
          'equilibrium by direct Newton or, failing that, 20-step continuation (needed for A2-F01921); evaluability rows '
          'E1 control arm not in the expected direction, E2 no equilibrium, E3 modulator saturation ≥ 0.1% before the '
          'switched and averaged 2-ms bus-voltage averages separate by 0.1 pu (10-ms filtered difference) or before '
          '$T_r$ + 0.5 s, E4 no direction; verdict rows K1 fewer than four evaluable cases … K4 supported. Changes before '
          'the run: v3_1 and v3_2 after two code audits (REVISE: exception handling of the continuation, saturation window '
          'on the record grid, false-departure check); v3_3 after the no-shedding self-test failed the 0.05-pu '
          'false-departure condition (0.058 pu, oscillatory aliasing of the switching ripple on the 0.4-ms record grid): '
          'the departure signal was filtered over 10 ms (no-shedding maximum 0.012 pu). Third audit: ACCEPT. '
          'Result of the single run (Y5B_20261026_a): K1, not evaluable. Rows E1 (three cases): the control arm '
          'classified the decaying responses as growing ($R$ = 737, 7.3×10⁴, 4.9×10⁴), because the classifier of '
          'protocol v1 forms its envelopes on np.convolve(·, "same"), whose last two records are zero-padded (≈ 0.4 pu, '
          'raising the late envelope by ≈ 0.04 pu); the divergence test of the same classifier excludes these records, so '
          'the G.7 result is not affected. Rows E3 (three cases): saturation before separation (GFM 0.04–3.9%, CPL '
          '0–1.2%). Post hoc, with interior records only: averaged arm 6/6 as expected; switching arm — '
          '(0.65, 0.20) inside: ripple band, $R$ = 0.96; beyond: collapse at 0.58 s; A2-F00993 accepted by the frozen '
          'margin: collapse at 0.46 s (averaged 0.79 s); A2-F00993 0.90 $\\Delta G_{t}^{*}$: ripple band, $R$ = 1.00; '
          'A2-F01921 accepted by the frozen margin: ripple band, $R$ = 1.08 (averaged: collapse at 0.90 s); A2-F01921 '
          '0.90 $\\Delta G_{t}^{*}$: ripple band, $R$ = 1.04. GFM saturation over the whole run 0–3.0% (A2 points '
          '1.0–3.0%). Outputs: S1 addition p92_20261026, folders out/y5v3 (sealed) and out/y5v3_posthoc; protocols and '
          'audit reports in protokol/.')
    s.write_text(u, encoding='utf-8')

(ROOT / 'ms' / 'y5b_rapor.txt').write_text(
    'YAPILDI — ön-kayıtlı hüküm değerlendirilemez (K1)\tmin-max (SVPWM eşdeğeri) enjeksiyon, 20 kHz; 3 denetim turu '
    '(REVISE, REVISE, ACCEPT). Kontrol kolu E1: v1 sınıflandırıcısında kenar hatası (son zarf ≈ +0.04 pu); düzeltilince '
    '(post hoc) ortalama kol 6/6. Anahtarlamalı kol: marj içindeki 3 miktar artık çökmüyor; marj ötesi 3 miktardan 2’si '
    'çöküyor (iyimser A2-F00993 dahil), A2-F01921 dalgalanma bandında kalıyor. §6.7, §7.5, S2 G.8.\n', encoding='utf-8')
(ROOT / 'ms' / 'ayna_durum.txt').write_text(
    'YAPILDI\tgithub.com/onurayvaz10/segan-frozen-margin-data-code: SEGAN_research_data_code_p92_20261026.zip eklendi, '
    'SHA256SUMS ve README güncellendi (development eki zaten oradaydı)\n', encoding='utf-8')
print('finalized v3 EMT')
