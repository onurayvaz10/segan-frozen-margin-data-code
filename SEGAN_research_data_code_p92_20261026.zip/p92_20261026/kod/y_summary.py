"""Pre-specified analyses of Y2, Y3 and Y4 (protocol P92 sections 2-4). Writes OUT/summary/{y2_estimators.csv,
y3_levels.csv, y4_ramp.csv, p92_summary.json}."""
import csv
import json
import math
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import y_common as U  # noqa: E402


def write(p, rows):
    keys = []
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    with open(p, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def y2():
    recs = U.load_jsonl(U.OUT / 'y2' / 'newton.jsonl')
    status = {}
    for r in recs:
        status[r.get('status')] = status.get(r.get('status'), 0) + 1
    est = dict(frozen='dGf', first_order='dG1st', second_order='dG2nd', secant_1='dG_sec1', secant_2='dG_sec2',
               newton_kappa_1='N1', kappa_started_secant_1='N1s', newton_kappa_2='N2')
    neq = dict(frozen=0, first_order=0, second_order=2, secant_1=1, secant_2=2, newton_kappa_1=1,
               kappa_started_secant_1=1, newton_kappa_2=2)
    rows = []
    for name, k in est.items():
        e = [(r[k] - r['dGref'], r['dGref']) for r in recs if r.get(k) is not None]
        a = np.array([x for x, _ in e])
        rel = np.array([x / y for x, y in e])
        rows.append(dict(estimator=name, extra_equilibria=neq[name], n=len(a), n_missing=len(recs) - len(a),
                         MAE=float(np.mean(np.abs(a))), RMSE=float(np.sqrt(np.mean(a ** 2))), max_AE=float(np.max(np.abs(a))),
                         median_abs_rel_pct=float(100 * np.median(np.abs(rel))),
                         p95_abs_rel_pct=float(100 * np.percentile(np.abs(rel), 95)), overshoot=int(np.sum(a > 0))))
    tests = {}
    for a_, b_, lab in (('N1', 'dG_sec1', 'H2a N1 - secant_1'), ('N2', 'dG_sec2', 'H2b N2 - secant_2'),
                        ('N1s', 'dG_sec1', 'N1s - secant_1'), ('N1', 'dG2nd', 'N1 - second_order'),
                        ('N2', 'dG_sec1', 'N2 - secant_1')):
        pr = [r for r in recs if r.get(a_) is not None and r.get(b_) is not None]
        d = [abs(r[a_] - r['dGref']) - abs(r[b_] - r['dGref']) for r in pr]
        m, lo, hi = U.cluster_boot_mean(d, [r['cluster'] for r in pr])
        tests[lab] = dict(n=len(pr), mean_diff=m, ci_lo=lo, ci_hi=hi,
                          verdict='negative (first better)' if hi < 0 else ('positive (second better)' if lo > 0 else 'no difference'))
    t1 = [r['t_step1'] for r in recs if r.get('t_step1')]
    t2 = [r['t_step2'] for r in recs if r.get('t_step2')]
    opt = [r for r in recs if r['kappa0'] < 0]
    return rows, dict(status=status, tests=tests, median_t_step1=float(np.median(t1)), median_t_step2=float(np.median(t2)),
                      optimistic_N1_overshoot=sum(1 for r in opt if r.get('N1') is not None and r['N1'] > r['dGref']),
                      n_optimistic=len(opt))


def y3():
    recs = U.load_jsonl(U.OUT / 'y3' / 'limiter.jsonl')
    rows = []
    by = {}
    for u in (0.70, 0.80, 0.85, 0.88):
        rs = [r for r in recs if abs(r['u_nom'] - u) < 1e-9]
        ok = [r for r in rs if r.get('status') == 'ok']
        prim = [r for r in ok if r['ref_sign'] in (1, -1) and abs(r['kappa']) >= U.TAU]
        r1 = sum(1 for r in prim if (1 if r['kappa'] > 0 else -1) == r['ref_sign'])
        r4 = sum(1 for r in prim if (1 if r['kappa_noc'] > 0 else -1) == r['ref_sign'])
        lowc = [r for r in prim if r.get('eps2') is not None and abs(r['eps2']) < 0.5]
        r1c = sum(1 for r in lowc if (1 if r['kappa'] > 0 else -1) == r['ref_sign'])
        st = {}
        for r in rs:
            st[r.get('status')] = st.get(r.get('status'), 0) + 1
        relf = [r['rel_err'] for r in ok if r.get('rel_err') is not None]
        u0 = [r['u0'] for r in rs if r.get('u0') is not None]
        rows.append(dict(u_nom=u, cases=len(rs), evaluable=len(ok), status=json.dumps(st),
                         u0_median=float(np.median(u0)) if u0 else None, kappa_neg=sum(1 for r in ok if r['kappa'] < 0),
                         kappa_median=float(np.median([r['kappa'] for r in ok])) if ok else None,
                         obs_optimistic=sum(1 for r in ok if r['ref_sign'] == -1),
                         obs_tie=sum(1 for r in ok if r['ref_sign'] == 0), primary=len(prim), R1_agree=r1,
                         R1_acc=r1 / len(prim) if prim else None, R1_wilson=U.wilson(r1, len(prim)), R4_agree=r4,
                         eps2_lt_0p5=len(lowc), R1_agree_eps2=r1c, R1_acc_eps2=r1c / len(lowc) if lowc else None,
                         R1_wilson_eps2=U.wilson(r1c, len(lowc)),
                         rel_err_frozen_median=float(np.median(relf)) if relf else None))
        by[u] = {r['id']: r for r in ok}
    a, b = by[0.70], by[0.88]
    both = [i for i in a if i in b]
    plus = sum(1 for i in both if b[i]['ref_sign'] == -1 and a[i]['ref_sign'] != -1)
    minus = sum(1 for i in both if a[i]['ref_sign'] == -1 and b[i]['ref_sign'] != -1)
    h3a = dict(n_both=len(both), opt_at_088_only=plus, opt_at_070_only=minus, p_one_sided=U.sign_test_one_sided(plus, minus))
    errs = [dict(id=r['id'], u_nom=r['u_nom'], kappa=r['kappa'], eps2=r.get('eps2'), ref_sign=r['ref_sign'],
                 rel_err=r.get('rel_err')) for r in recs if r.get('status') == 'ok' and r['ref_sign'] in (1, -1)
            and abs(r['kappa']) >= U.TAU and (1 if r['kappa'] > 0 else -1) != r['ref_sign']]
    return rows, dict(H3a=h3a, sign_errors=errs)


def y4():
    recs = U.load_jsonl(U.OUT / 'y4' / 'ramp.jsonl')
    rows = []
    for r in recs:
        tr = r['trace'] or []
        post = [abs(v) for t, v in tr if t >= r['T_r']]
        first = max(post[:50]) if post else None          # first 0.5 s after the ramp (trace step 10 ms)
        rows.append(dict(P_set=r['P_set'], G_R=r['G_R'], case=r['case'], dG=r['dG'], T_r=r['T_r'], diverged=r['diverged'],
                         diverged_at_s=r['diverged_at_s'], peak_dev_after_ramp=r['peak_dev_after_ramp'],
                         env_first_0p5s_after_ramp=first, envelope_last_0p5s=r['envelope_last_0p5s'],
                         growth_last_over_first=(r['envelope_last_0p5s'] / first)
                         if first and r['envelope_last_0p5s'] is not None else None))
    tstar = {}
    for r in rows:
        if r['case'] != 'reference':
            continue
        key = f"{r['P_set']}/{r['G_R']}"
        if not r['diverged']:
            tstar[key] = min(tstar.get(key, math.inf), r['T_r'])
    return rows, dict(T_r_star_reference=tstar)


def main():
    od = U.OUT / 'summary'
    od.mkdir(parents=True, exist_ok=True)
    r2, s2 = y2()
    r3, s3 = y3()
    r4, s4 = y4()
    write(od / 'y2_estimators.csv', r2)
    write(od / 'y3_levels.csv', r3)
    write(od / 'y4_ramp.csv', r4)
    (od / 'p92_summary.json').write_text(json.dumps(U.clean(dict(y2=s2, y3=s3, y4=s4)), indent=1), encoding='utf-8')
    for r in r2 + r3 + r4:
        print(r)
    print(json.dumps(U.clean(dict(y2=s2, y3=s3, y4=s4)), indent=1))


if __name__ == '__main__':
    main()
