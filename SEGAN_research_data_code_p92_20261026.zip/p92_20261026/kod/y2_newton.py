"""Y2 (protocol P92 section 2): Newton-kappa margin estimator on the 774 uncensored primary TSV points.

F(dG) = min_z rho_z(x(dG)) - dG with G_R held in the port admittance; F'(0) = kappa - 1, so the first-order corrected
margin dGf/(1 - kappa0) is one Newton step from 0. This script takes that point, solves one equilibrium there, evaluates
F and kappa again (one linear solve) and takes a second Newton step (N1); the same once more gives N2. N1s is the secant
through (0, dGf) and (dG1, F1). The reference and the secant estimators of the sealed run TSV_a are not recomputed.

  --selftest   3 points: kappa_at(x0) must reproduce the sealed kappa; output to OUT/selftest_y2.jsonl
  --run        all points into OUT/y2/newton.jsonl (resumes; refuses if OUT/y2/exit_code.txt exists)
"""
import argparse
import json
import math
import sys
import time
import traceback
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import y_common as U  # noqa: E402
import ext_common as C  # noqa: E402
import ext_engine as E  # noqa: E402


def kappa_at(lay, x, refs, G, Gk, th, cr, eps=1e-5):
    """kappa at an equilibrium x of the system with conductances Gk; the port admittance keeps G (G_R pre-shedding).
    Same construction as ext_engine.kappa_hat, which is the special case x = x0, Gk = G."""
    keep = lay.keep
    sb = lay.sysd['shed_bus']
    Jk = E.jac(lay, x, refs, Gk)
    r = E.dfdG(lay, x, refs, Gk, sb)
    xi = np.zeros(lay.n)
    xi[keep] = np.linalg.solve(Jk[np.ix_(keep, keep)], r[keep])
    Jy = E.jac(lay, x, refs, G)
    w0 = cr['omega']
    lam0, v, wl, _ = E.eig_branch(lay, Jy, th, w0, cr['lam'])
    Jp = E.jac(lay, x + eps * xi, refs, G)
    Jn = E.jac(lay, x - eps * xi, refs, G)
    dY = (E.to_F0(E.port_admittance(lay, Jp, 1j * w0), th) - E.to_F0(E.port_admittance(lay, Jn, 1j * w0), th)) / (2 * eps)
    eta = complex(wl @ dY @ v / (wl @ v))
    dw = 1e-6 * w0
    lp = E.eig_branch(lay, Jy, th, w0 + dw, lam0)[0]
    lm = E.eig_branch(lay, Jy, th, w0 - dw, lam0)[0]
    dl = (lp - lm) / (2 * dw)
    c = dl.real / dl.imag
    return (eta * complex(1.0, c)).real, c, eta


def evaluate(lay, x_start, refs, G, dG, th):
    """Equilibrium at dG (from x_start), F = min rho - dG over all positive crossings, kappa at that crossing."""
    sb = lay.sysd['shed_bus']
    Gk = G.copy()
    Gk[sb] -= dG
    xs, ok, _, nj = E.newton_fixed_refs(lay, x_start, refs, Gk)
    if not ok:
        return dict(status='no equilibrium')
    cr = [c for c in E.crossings(lay, E.jac(lay, xs, refs, G), th) if c['rho'] > 0]
    if not cr:
        return dict(status='no crossing', x=xs)
    c = min(cr, key=lambda d: d['rho'])
    k, cc, eta = kappa_at(lay, xs, refs, G, Gk, th, c)
    return dict(status='ok', x=xs, F=c['rho'] - dG, rho=c['rho'], omega=c['omega'], kappa=k, c=cc,
                eta_re=eta.real, eta_im=eta.imag, newton_jac=nj)


def one_point(r, spec, selftest=False):
    t0 = time.perf_counter()
    lay, G, P = C.BUILDERS[r['system']](spec)
    d = E.dispatch(lay, P, G, tol=1e-12)
    o = dict(id=r['id'], system=r['system'], source=r['source'], cluster=r['cluster'], dGf=r['dGf'], kappa0=r['kappa'],
             dGref=r['dGref'], dG_sec1=r['dG_sec1'], dG_sec2=r['dG_sec2'], dG1st=r['dG1st'], dG2nd=r['dG2nd'])
    if not (d['ok'] or d['hist'][-1] <= 1e-8):
        o['status'] = 'dispatch failed'
        return o
    x0, refs = d['x'], d['refs']
    sb = lay.sysd['shed_bus']
    th = float(np.arctan2(x0[lay.ix[f'V{sb}:I']], x0[lay.ix[f'V{sb}:R']]))
    o['Vb_check'] = abs(math.hypot(x0[lay.ix[f'V{sb}:R']], x0[lay.ix[f'V{sb}:I']]) - r['V_b'])
    if selftest:
        Jm = E.jac(lay, x0, refs, G)
        fm = E.frozen_margin(lay, Jm, th, G[sb])
        k0, _, _ = kappa_at(lay, x0, refs, G, G, th, fm)
        o.update(selftest_dGf=fm['rho'], selftest_kappa=k0)
    k0 = r['kappa']
    if not k0 < 1:
        o['status'] = 'kappa0 >= 1'
        return o
    dG1 = r['dGf'] / (1.0 - k0)
    o['dG1'] = dG1
    t1 = time.perf_counter()
    e1 = evaluate(lay, x0, refs, G, dG1, th)
    o['t_step1'] = time.perf_counter() - t1
    o['step1_status'] = e1['status']
    if e1['status'] != 'ok':
        o['status'] = 'step1 ' + e1['status']
        return o
    F1, k1 = e1['F'], e1['kappa']
    o.update(F1=F1, kappa1=k1, omega1=e1['omega'], c1=e1['c'])
    o['N1s'] = dG1 - F1 * dG1 / (F1 - r['dGf']) if abs(F1 - r['dGf']) > 1e-300 else None
    if not k1 < 1:
        o['status'] = 'kappa1 >= 1'
        return o
    N1 = dG1 + F1 / (1.0 - k1)
    o['N1'] = N1
    if not N1 > 0:
        o['status'] = 'N1 <= 0'
        return o
    t2 = time.perf_counter()
    e2 = evaluate(lay, e1['x'], refs, G, N1, th)
    o['t_step2'] = time.perf_counter() - t2
    o['step2_status'] = e2['status']
    if e2['status'] != 'ok':
        o['status'] = 'step2 ' + e2['status']
        return o
    F2, k2 = e2['F'], e2['kappa']
    o.update(F2=F2, kappa2=k2, omega2=e2['omega'])
    o['N2'] = N1 + F2 / (1.0 - k2) if k2 < 1 else None
    o['status'] = 'ok' if o['N2'] is not None else 'kappa2 >= 1'
    o['t_total'] = time.perf_counter() - t0
    return o


def main():
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument('--selftest', action='store_true')
    g.add_argument('--run', action='store_true')
    a = ap.parse_args()
    rows = U.y2_set(U.load_points())
    if len(rows) != 774:
        print('ABORT: point set has', len(rows), 'points, protocol requires 774')
        return 2
    sel = U.selection()
    U.OUT.mkdir(parents=True, exist_ok=True)
    if a.selftest:
        out = U.OUT / 'selftest_y2.jsonl'
        picks = [rows[0], [r for r in rows if r['kappa'] < 0][0], [r for r in rows if r['system'] == 'C'][0]]
        with open(out, 'w', encoding='utf-8') as f:
            for r in picks:
                o = one_point(r, sel[r['id']], selftest=True)
                f.write(json.dumps(U.clean(o)) + '\n')
                print(r['id'], 'kappa sealed', r['kappa'], 'kappa_at(x0)', o.get('selftest_kappa'), 'dGf', r['dGf'],
                      o.get('selftest_dGf'), 'N1', o.get('N1'), 'N2', o.get('N2'), 'ref', r['dGref'], 'sec1', r['dG_sec1'],
                      o.get('status'), flush=True)
        return 0
    od = U.OUT / 'y2'
    od.mkdir(parents=True, exist_ok=True)
    if (od / 'exit_code.txt').exists():
        print('refused: finished run exists')
        return 3
    done = {o['id'] for o in U.load_jsonl(od / 'newton.jsonl')}
    t0 = time.perf_counter()
    with open(od / 'newton.jsonl', 'a', encoding='utf-8') as f, open(od / 'log.txt', 'a', encoding='utf-8') as lg:
        for k, r in enumerate(rows):
            if r['id'] in done:
                continue
            try:
                o = one_point(r, sel[r['id']])
            except Exception as exc:  # noqa: BLE001
                o = dict(id=r['id'], system=r['system'], status='error', error=f'{type(exc).__name__}: {exc}',
                         tb=traceback.format_exc()[-400:])
            f.write(json.dumps(U.clean(o)) + '\n')
            f.flush()
            lg.write(f"{k + 1}/{len(rows)} {r['id']} {o.get('status')} t={time.perf_counter() - t0:.0f}s\n")
            lg.flush()
    (od / 'exit_code.txt').write_text('0', encoding='utf-8')
    U.write_sums(od)
    return 0


if __name__ == '__main__':
    C.lower_priority()
    sys.exit(main())
