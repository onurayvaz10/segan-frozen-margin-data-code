"""Y5b (protocol P92_EMT_PROTOKOL_v3 with change notes v3_1, v3_2 and v3_3): switching-level check of the frozen-margin bias direction
with more modulation headroom - min-max zero-sequence injection (equivalent to symmetrical space-vector PWM) on both
converters, everything else as protocol v2 (y5_emt.py: 20 kHz, dt = Ts/20, one-sample delay, Heun). Post hoc
follow-up of the v2 result.

Protocol sections -> functions: v3 s1 inject/switched_mm; s2 y5_emt.cases; s3 + v3.1 D2 post_equilibrium; s4 arms
in run_all (control arm = averaged model); s5 y5_emt.classify + direction; s6 + v3.1 D1 departure, sat_until,
evaluable; s7 verdict; s8 selftest; v3.1 D4 load_rows, yetki selftest condition.
Author choices: Y5b-a the injection is computed from the sampled reference (the held command), as the carrier
comparison of v2; Y5b-b saturation counts every modulator evaluation (both Heun stages) in which any phase |m| > 1
before clipping; Y5b-c the continuation uses 20 equal steps from x0; Y5b-d the departure uses the 2-ms moving average
of y5_emt.classify (np.convolve 'same', W = 5) on the common 0.4-ms record grid, interior points only; cumulative
modulator counts are kept every W records and at the end.
v3.1 changes (audit P92_EMT_v3_kod_denetimi.md): R-1 Newton exceptions/non-finite -> failure; R-2 eq_found/eq_how in
hukum.json; R-3 selftest uses inject(); R-4 tolerant resume, hashes in every row; R-5 more synthetic rows; N-2 -> D1.
v3.2 changes (audit P92_EMT_v3_1_kod_denetimi.md, change note v3_2): R-6 departure and saturation window on the same
record index grid, counters at every record (D5); R-8 grid check (D6); R-7 no-shedding departure check in the
selftest as a run condition (D7); R-9 newline repair and hash check on resume, R-10 hashes in the selftest (D8).
v3.3 change (change note v3_3, after the v3.2 selftest failed D7 at 0.058 pu): departure on the 10-ms moving average
of the difference of the 2-ms averages (dep_signal, D9); the D7 condition on the same signal (D10).
  --check-only           verify pins (no model import), print hashes
  --selftest             protocol s8 checks into OUT/selftest_y5v3.json
  --run --yetki PATH     twelve simulations into OUT/y5v3/emt_v3.jsonl (resumes; refuses if exit_code.txt exists)
"""
import argparse
import hashlib
import json
import math
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
S1 = os.environ.get('G92_S1', os.path.join(ROOT, 'girdi', 'development_20261026'))
PINS = {
    'protokol/P92_EMT_PROTOKOL_v1.txt': '83d860c0c2e8821dd0351771006f2826260eaa1dd5526445342203c4ebb4f778',
    'protokol/P92_EMT_PROTOKOL_v2.txt': 'd36dd0b91b5893da5df8c29a12b878ed6a87f5a3e00254b3b8e26b6a09e90d7e',
    'protokol/P92_EMT_PROTOKOL_v3.txt': '152f0087cd28240c30c81c89ba397ccda723eb6c6c10ba28a00a025590242b6f',
    'protokol/P92_EMT_PROTOKOL_v3_1.txt': 'd8d8876adf596912cfe62cb4f3bbfb649da625b870ce7d5dc90d996baa415857',
    'protokol/P92_EMT_PROTOKOL_v3_2.txt': '8d0971cf77752c719c31fd5e99ccef0db20b3e9939c2d41d36dce168c01414c2',
    'kod/y5_emt.py': '166d2e8427a00e6b9d6fb560ab6614abd2668c3ca4b95878c14d3616a258d495',
    'kod/ext_engine.py': '35d6bd7773b51cce12ca5d5506ab2860f45dcf2f2f217f398ccc76e1a53dbb7f',
    'kod/ext_common.py': '63982bfd61cf3a38da8e39ebc470952c8db44b02a11811f712fcc6d38c444c1b',
    'kod/y_common.py': '7b16ffbf27dce28fb1932a38705eadbadde2ad1f22c9349c485f6feb523a2970',
    'S1:out/tsv/TSV_a/analysis/points.csv': '6a099961188a4cdf51865fbc0e370c2c9ce5a8e961e55a8a7e23e01dcbb844e7',
    'S1:out/tsv/selection.json': '2d5a00d86497b174277d238293e08129f901627da99844552dcfcc397d981b53',
}
PROTOCOL = 'protokol/P92_EMT_PROTOKOL_v3_3.txt'
TR, TOBS = 0.25, 2.5
SAT_WIN = TR + 0.5
SAT_MAX = 1e-3
DEP_THR = 0.1
W = 5                       # 2 ms / 0.4 ms, as y5_emt.classify
WD = 25                     # 10 ms / 0.4 ms, departure filter (v3.3 D9)
EXPECT_DIR = {'decaying': 'stable', 'growing': 'unstable'}


def _read_bytes(p):
    with open(p, 'rb') as f:
        return f.read()


def _write_text(p, s, mode='w'):
    with open(p, mode, encoding='utf-8', newline='\n') as f:
        f.write(s)


def _sha(p):
    return hashlib.sha256(_read_bytes(p)).hexdigest()


def _path(key):
    if key.startswith('S1:'):
        return os.path.join(S1, *key[3:].split('/'))
    return os.path.join(ROOT, *key.split('/'))


def check_pins():
    bad = [k for k, v in PINS.items() if not os.path.exists(_path(k)) or _sha(_path(k)) != v]
    lst = '\n'.join(f'{v}  {k}' for k, v in sorted(PINS.items())) + '\n'
    return bad, hashlib.sha256(lst.encode('utf-8')).hexdigest()


def verify_authorization(path, out_dir):
    bad, pls = check_pins()
    if bad:
        return f'KAPI: pin uyusmazligi {bad}'
    try:
        y = json.loads(_read_bytes(path).decode('utf-8'))
    except (OSError, ValueError) as e:
        return f'KAPI: yetki dosyasi okunamadi ({e})'
    if y.get('action') != 'ALLOW_P92_EMT_V3_RUN':
        return 'KAPI: action'
    if y.get('protocol_sha256') != _sha(_path(PROTOCOL)):
        return 'KAPI: protokol hash'
    if y.get('script_sha256') != _sha(os.path.abspath(__file__)):
        return 'KAPI: betik hash'
    if y.get('pin_list_sha256') != pls:
        return 'KAPI: pin listesi hash'
    a = y.get('code_audit_report') or {}
    ap = _path(a.get('path', '-'))
    if not os.path.exists(ap) or _sha(ap) != a.get('sha256'):
        return 'KAPI: kod denetimi raporu'
    sp = os.path.join(out_dir, 'selftest_y5v3.json')
    if not os.path.exists(sp) or _sha(sp) != y.get('selftest_sha256'):
        return 'KAPI: oz-test hash'
    if json.loads(_read_bytes(sp).decode('utf-8')).get('pass') is not True:
        return 'KAPI: oz-test gecmedi'
    return None


def load_rows(path):
    """jsonl rows; a broken last line (interrupted write) is dropped and the file rewritten without it (v3.1 D4)."""
    if not os.path.exists(path):
        return []
    lines = _read_bytes(path).decode('utf-8').split('\n')
    rows, good = [], []
    for j, l in enumerate(lines):
        if not l.strip():
            continue
        try:
            rows.append(json.loads(l))
            good.append(l)
        except ValueError:
            if any(x.strip() for x in lines[j + 1:]):
                raise
    if len(good) != sum(1 for l in lines if l.strip()) or (good and lines[-1] != ''):
        _write_text(path, ''.join(g + '\n' for g in good))
    return rows


# ---- pure decision functions (protocol s5-s7, v3.1 D1) ----------------------------------------------------------
def direction(cls):
    return {'growing': 'unstable', 'diverged': 'unstable', 'decaying': 'stable'}.get(cls)


def dep_signal(vs_sw, vs_avg):
    """v3.3 D9: [(i, s_i)] with s_i the WD-record centred moving average of vs_sw - vs_avg, interior indices only."""
    n = min(len(vs_sw), len(vs_avg))
    d = [vs_sw[i] - vs_avg[i] for i in range(n)]
    h = WD // 2
    lo, hi = W + h, n - W - h
    if hi <= lo:
        return []
    s = sum(d[lo - h:lo + h + 1])
    out = [(lo, s / WD)]
    for i in range(lo + 1, hi):
        s += d[i + h] - d[i - h - 1]
        out.append((i, s / WD))
    return out


def departure(vs_sw, vs_avg, broke):
    """v3.2 D5 + v3.3 D9: first record INDEX at which the filtered difference exceeds DEP_THR in absolute value; if
    either arm stopped early and there is no departure, the last interior index; None if never."""
    sig = dep_signal(vs_sw, vs_avg)
    for i, v in sig:
        if abs(v) > DEP_THR:
            return i
    if broke:
        return sig[-1][0] if sig else 0
    return None


def same_grid(ts_a, ts_b):
    """v3.2 D6: record times of the two arms agree on the common length within 1e-9 s."""
    n = min(len(ts_a), len(ts_b))
    return n > 0 and all(abs(ts_a[i] - ts_b[i]) <= 1e-9 for i in range(n))


def limit_index(ts, i_dep):
    """v3.2 D5: i_lim = min(i_dep, last record index with t <= T_r + 0.5 s); None if no record in the window."""
    i_win = None
    for i, t in enumerate(ts):
        if t <= SAT_WIN + 1e-12:
            i_win = i
    if i_win is None:
        return None
    return i_win if i_dep is None else min(i_dep, i_win)


def sat_until(cum, i_lim):
    """cum: {'n': [...], 'sat': [...]} cumulative modulator counts per record. Saturated fraction up to and including
    record i_lim; None if i_lim is None, outside the record or there is no evaluation."""
    if i_lim is None or i_lim < 0 or i_lim >= len(cum['n']) or cum['n'][i_lim] == 0:
        return None
    return cum['sat'][i_lim] / cum['n'][i_lim]


def evaluable(expected, ctrl_cls, eq_ok, sat_frac_win, sw_cls):
    """Protocol s6 (E3 as v3.1 D1), first matching row. Returns (status, agree), status 'E1'..'E4' or 'ok'."""
    want = EXPECT_DIR[expected]
    if direction(ctrl_cls) != want:
        return 'E1', None
    if not eq_ok:
        return 'E2', None
    if not sat_frac_win or any(v is None for v in sat_frac_win.values()) or max(sat_frac_win.values()) >= SAT_MAX:
        return 'E3', None
    if direction(sw_cls) is None:
        return 'E4', None
    return 'ok', direction(sw_cls) == want


def verdict(rows):
    """Protocol s7. rows: dicts with id, case, status, agree. Returns (row, label, disagreeing)."""
    ev = [r for r in rows if r['status'] == 'ok']
    dis = [(r['id'], r['case']) for r in ev if not r['agree']]
    if len(ev) < 4:
        return 'K1', 'NOT_EVALUABLE', dis
    if dis:
        return 'K2', 'NOT_SUPPORTED', dis
    a2 = [r for r in rows if r['id'].startswith('A2') and r['case'] == 'A_between']
    if len(a2) != 2 or any(r['status'] != 'ok' for r in a2):
        return 'K3', 'PARTIALLY_SUPPORTED', dis
    return 'K4', 'SUPPORTED', dis


# ---- model part (imported only after the pins are verified) ----------------------------------------------------
def _model():
    sys.path.insert(0, HERE)
    import numpy as np
    import ext_common as C
    import ext_engine as E
    import y5_emt as Y
    import y_common as U
    return np, C, E, Y, U


def inject(np, Y, vref, vdc, thf):
    """Phase modulation indices with min-max zero-sequence injection, before clipping (protocol s1)."""
    ph = np.real(vref * np.exp(1j * thf) * Y.A3)
    return (ph - 0.5 * (ph.max() + ph.min())) / vdc


def switched_mm(np, Y, vref, vdc, thf, t, st=None):
    """Two-level carrier PWM of the frame reference vref with min-max injection; carrier as y5_emt.switched."""
    m = inject(np, Y, vref, vdc, thf)
    if st is not None:
        st['n'] += 1
        st['peak'] = max(st['peak'], float(np.abs(m).max()))
        st['sat'] += bool(np.abs(m).max() > 1.0)
    m = np.clip(m, -1.0, 1.0)
    car = 1.0 - 4.0 * abs((t / Y.TS) % 1.0 - 0.5)
    sw = np.where(m > car, vdc, -vdc)
    return (2.0 / 3.0) * np.sum(sw * np.conj(Y.A3)) * np.exp(-1j * thf)


def simulate(M, lay, x0, refs, Gfun, T, mode, vb_eq=None, rec_every=4e-4):
    """y5_emt.simulate with the min-max modulator and cumulative modulator counts at every record (mode 'avg'/'sw')."""
    np, C, E, Y, U = M
    s, ix = lay.sysd, lay.ix
    Minv = 1.0 / lay.M
    keys = ['G'] + [f'C{c}' for c in range(len(s['cpls']))]
    stats = {k: dict(n=0, sat=0, peak=0.0) for k in keys}
    cum = {k: dict(n=[], sat=[]) for k in keys}
    held = {}

    def f(t, x, thf):
        fa = E.rhs(lay, x, refs, Gfun(t))
        if mode == 'avg':
            return Minv * fa
        cmd, _ = Y.ctrl_out(lay, x, refs)
        app = held['app']
        vg = switched_mm(np, Y, app[0], C.VDC_GFM_PU, thf, t, stats['G'])
        fa[ix['G:Irc']] += vg.real - cmd[0].real
        fa[ix['G:Iic']] += vg.imag - cmd[0].imag
        for c, cd in enumerate(s['cpls']):
            pre, q = f'C{c}:', cd['par']
            vdc = x[ix[pre + 'vdc']]
            vc = switched_mm(np, Y, app[1 + c], vdc, thf, t, stats[f'C{c}'])
            fa[ix[pre + 'Irc']] -= vc.real - cmd[1 + c].real
            fa[ix[pre + 'Iic']] -= vc.imag - cmd[1 + c].imag
            Isw = complex(x[ix[pre + 'Irc']], x[ix[pre + 'Iic']])
            dP = (vc.real - cmd[1 + c].real) * Isw.real + (vc.imag - cmd[1 + c].imag) * Isw.imag
            fa[ix[pre + 'vdc']] += (E.WB / q['c_dc']) * dP / vdc
        return Minv * fa

    sb = s['shed_bus']
    bR, bI = ix[f'V{sb}:R'], ix[f'V{sb}:I']
    x, thf, t = x0.copy(), 0.0, 0.0
    cmd0, _ = Y.ctrl_out(lay, x, refs)
    held['app'], nxt = list(cmd0), list(cmd0)
    k_next = 1
    ts, vb = [], []
    n = int(round(T / Y.DT))
    rec_k = max(1, int(round(rec_every / Y.DT)))
    g = s['par']['gfm']
    for k in range(n):
        if t >= k_next * Y.TS - 1e-12:
            held['app'] = nxt
            nxt, _ = Y.ctrl_out(lay, x, refs)
            k_next += 1
        z = g['w_ref'] + g['Rp'] * (refs[0] - x[ix['G:pm']])
        k1 = f(t, x, thf)
        xp = x + Y.DT * k1
        k2 = f(t + Y.DT, xp, thf + Y.DT * E.WB * z)
        x = x + 0.5 * Y.DT * (k1 + k2)
        thf += Y.DT * E.WB * z
        t += Y.DT
        if k % rec_k == 0:
            v = math.hypot(x[bR], x[bI])
            ts.append(t)
            vb.append(v)
            for kk in keys:
                cum[kk]['n'].append(stats[kk]['n'])
                cum[kk]['sat'].append(stats[kk]['sat'])
            if not math.isfinite(v) or (vb_eq is not None and abs(v - vb_eq) > 2.0):
                break
    if mode != 'sw':
        stats, cum = None, None
    return np.array(ts), np.array(vb), x, stats, cum


def post_equilibrium(M, lay, x0, refs, G, dG):
    """Protocol s3 + v3.1 D2: direct Newton, else 20-step continuation from x0. Returns (x, ok, how)."""
    np, C, E, Y, U = M
    sb = lay.sysd['shed_bus']
    errs = (np.linalg.LinAlgError, FloatingPointError, OverflowError, ValueError, ZeroDivisionError)

    def solve(xs, frac):
        Gk = G.copy()
        Gk[sb] -= dG * frac
        try:
            xe, ok, _, _ = E.newton_fixed_refs(lay, xs, refs, Gk)
        except errs as e:
            return None, f'exception {type(e).__name__}'
        if not ok or not np.all(np.isfinite(xe)):
            return None, 'no convergence' if ok is False else 'nonfinite'
        return xe, None

    xe, why = solve(x0, 1.0)
    if xe is not None:
        return xe, True, 'direct'
    x = x0.copy()
    for j in range(1, 21):
        x, why = solve(x, j / 20)
        if x is None:
            return x0, False, f'direct failed; continuation {why} at step {j}'
    return x, True, 'continuation'


def run_case(M, pt, name, dG, expect, sel, arm):
    np, C, E, Y, U = M
    lay, G, P = Y.build(pt['builder'], sel)
    d = E.dispatch(lay, P, G, tol=1e-12)
    x0, refs = d['x'], d['refs']
    sb = lay.sysd['shed_bus']
    xe, ok, how = post_equilibrium(M, lay, x0, refs, G, dG)
    vb_eq = math.hypot(xe[lay.ix[f'V{sb}:R']], xe[lay.ix[f'V{sb}:I']])

    def Gfun(t):
        g = G.copy()
        g[sb] -= dG * min(t / TR, 1.0)
        return g
    T = TR + TOBS
    t0 = time.perf_counter()
    ts, vb, _, st, cum = simulate(M, lay, x0, refs, Gfun, T, arm, vb_eq)
    cls, R, dev = Y.classify(ts, vb, vb_eq, TR, T)
    out = dict(id=pt['id'], case=name, arm=arm, kappa=pt['kappa'], dGf=pt['dGf'], dGt=pt['dGt'], dG=dG,
               expected=expect, observed=cls, direction=direction(cls), literal_agree=cls == expect, R=R,
               eq_found=bool(ok), eq_how=how, vb_eq=vb_eq, t_end=float(ts[-1]) if len(ts) else 0.0,
               broke=bool(len(ts) == 0 or ts[-1] < T - 1e-3), wall_s=time.perf_counter() - t0,
               ts=[round(float(a), 7) for a in ts], vs=[round(float(a), 7) for a in np.convolve(vb, np.ones(W) / W, 'same')])
    if st is not None:
        out['mod'] = {k: dict(peak=v['peak'], sat_frac=v['sat'] / max(v['n'], 1)) for k, v in st.items()}
        out['cum'] = cum
    return out


def selftest(M, out_dir, hashes):
    np, C, E, Y, U = M
    res = dict(hashes)
    rng = np.random.default_rng(20261026)
    err = 0.0
    for _ in range(50):
        vref, thf, vdc = complex(*rng.normal(size=2)), float(rng.uniform(0, 2 * np.pi)), float(rng.uniform(0.8, 1.3))
        m = inject(np, Y, vref, vdc, thf)
        back = (2.0 / 3.0) * np.sum(m * vdc * np.conj(Y.A3)) * np.exp(-1j * thf)
        err = max(err, abs(back - vref))
    res['zero_seq_cancel_err'] = err
    lay, G, P = C.build_F2(0.65, 0.20)
    d = E.dispatch(lay, P, G, tol=1e-12)
    x0, refs = d['x'], d['refs']
    sb = lay.sysd['shed_bus']
    v0 = math.hypot(x0[lay.ix[f'V{sb}:R']], x0[lay.ix[f'V{sb}:I']])
    ta, vba, x, _, _ = simulate(M, lay, x0, refs, lambda t: G, 0.1, 'avg')
    res['avg_max_dev'] = float(np.max(np.abs(vba - v0)))
    ts, vb, x, st, cum = simulate(M, lay, x0, refs, lambda t: G, 0.1, 'sw')
    res['sw_max_dev'] = float(np.max(np.abs(vb - v0)))
    res['sw_finite'] = bool(np.all(np.isfinite(x)))
    res['sw_mod'] = {k: dict(peak=v['peak'], sat=v['sat'], n=v['n']) for k, v in st.items()}
    res['cum_consistent'] = all(len(cum[k]['n']) == len(ts) and cum[k]['n'][-1] <= st[k]['n'] for k in st)
    vs_a = [float(v) for v in np.convolve(vba, np.ones(W) / W, 'same')]
    vs_s = [float(v) for v in np.convolve(vb, np.ones(W) / W, 'same')]
    res['grid_same'] = same_grid(list(ta), list(ts))
    res['noshed_departure'] = departure(vs_s, vs_a, False)
    sig = dep_signal(vs_s, vs_a)
    res['noshed_n_signal'] = len(sig)
    res['noshed_max_vs_diff'] = max(abs(v) for _, v in sig) if sig else None
    res['pass'] = bool(err < 1e-12 and res['avg_max_dev'] < 1e-6 and res['sw_finite'] and res['sw_max_dev'] < 0.5
                       and all(v['sat'] == 0 for v in st.values()) and res['cum_consistent'] and res['grid_same']
                       and res['noshed_departure'] is None and res['noshed_n_signal'] > 100
                       and res['noshed_max_vs_diff'] < 0.05)
    _write_text(os.path.join(out_dir, 'selftest_y5v3.json'), json.dumps(U.clean(res), indent=1))
    print(res)
    return 0 if res['pass'] else 1


def run_all(M, od, hashes):
    np, C, E, Y, U = M
    cs, sel = Y.cases()
    path = os.path.join(od, 'emt_v3.jsonl')
    prev = load_rows(path)
    if any(o.get('script_sha256') != hashes['script_sha256'] or o.get('pin_list_sha256') != hashes['pin_list_sha256']
           for o in prev):
        print('KAPI: devam satirlari farkli betik/pin hash')
        return 2
    done = {(o['id'], o['case'], o['arm']): o for o in prev}
    for pt, name, dG, expect in cs:
        for arm in ('avg', 'sw'):
            if (pt['id'], name, arm) in done:
                continue
            o = U.clean(dict(run_case(M, pt, name, dG, expect, sel, arm), **hashes))
            _write_text(path, json.dumps(o) + '\n', mode='a')
            done[(pt['id'], name, arm)] = o
            print(pt['id'], name, arm, o['observed'], o['expected'], o['R'], round(o['wall_s']), flush=True)
    rows = []
    for pt, name, dG, expect in cs:
        a, s = done[(pt['id'], name, 'avg')], done[(pt['id'], name, 'sw')]
        grid = same_grid(s['ts'], a['ts'])
        i_dep = departure(s['vs'], a['vs'], s['broke'] or a['broke'])
        i_lim = limit_index(s['ts'], i_dep) if grid else None
        win = {k: sat_until(v, i_lim) for k, v in s['cum'].items()}
        status, agree = evaluable(expect, a['observed'], s['eq_found'], win, s['observed'])
        rows.append(dict(id=pt['id'], case=name, expected=expect, ctrl=a['observed'], ctrl_R=a['R'], sw=s['observed'],
                         sw_R=s['R'], eq_found=s['eq_found'], eq_how=s['eq_how'], grid_same=grid,
                         t_dep=None if i_dep is None else s['ts'][i_dep],
                         t_lim=None if i_lim is None else s['ts'][i_lim],
                         sat_frac_win=win, sat_frac_all={k: v['sat_frac'] for k, v in s['mod'].items()},
                         peak={k: v['peak'] for k, v in s['mod'].items()}, status=status, agree=agree,
                         literal_agree=s['literal_agree']))
    row, label, dis = verdict(rows)
    doc = dict(protocol=PROTOCOL, decision_row=row, H5b=label, disagreeing=dis, cases=rows, **hashes)
    _write_text(os.path.join(od, 'hukum.json'), json.dumps(U.clean(doc), indent=1))
    _write_text(os.path.join(od, 'exit_code.txt'), '0')
    U.write_sums(od)
    print('H5b', row, label, dis)
    return 0


def main():
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument('--check-only', action='store_true')
    g.add_argument('--selftest', action='store_true')
    g.add_argument('--run', action='store_true')
    ap.add_argument('--yetki')
    a = ap.parse_args()
    bad, pls = check_pins()
    hashes = dict(script_sha256=_sha(os.path.abspath(__file__)), pin_list_sha256=pls)
    if a.check_only:
        print('pins', 'OK' if not bad else f'BAD {bad}', 'pin_list_sha256', pls,
              'protocol_sha256', _sha(_path(PROTOCOL)), 'script_sha256', hashes['script_sha256'])
        return 0 if not bad else 2
    out = os.environ.get('G92_OUT', os.path.join(ROOT, 'out'))
    if a.run:
        if not a.yetki:
            print('KAPI: --run requires --yetki')
            return 2
        msg = verify_authorization(a.yetki, out)
        if msg:
            print(msg)
            return 2
    elif bad:
        print(f'KAPI: pin uyusmazligi {bad}')
        return 2
    M = _model()
    M[1].lower_priority()
    os.makedirs(out, exist_ok=True)
    if a.selftest:
        return selftest(M, out, hashes)
    od = os.path.join(out, 'y5v3')
    os.makedirs(od, exist_ok=True)
    if os.path.exists(os.path.join(od, 'exit_code.txt')):
        print('refused: finished run exists')
        return 3
    return run_all(M, od, hashes)


if __name__ == '__main__':
    sys.exit(main())
