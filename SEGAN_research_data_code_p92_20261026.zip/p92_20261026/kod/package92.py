"""Delivery package of the P92 round: S1 addition zip (p92_20261026), Turkish report, figures (TIF for upload),
validation tables, code and protocol, and the final zip. Usage:
  python -I package92.py G92_OUT OLD_PACKAGE_DIR DEST_DIR"""
import csv
import hashlib
import json
import shutil
import sys
import zipfile
from pathlib import Path

from docx import Document
from docx.shared import Pt
from openpyxl import Workbook
from PIL import Image

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
G92, OLD, DEST = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
NAME = 'SEGAN_92_GELISTIRME_TESLIM_2026-10-26_v2'
PK = DEST / NAME
DEV = 'Supplementary_S1_addition_development_20261026.zip'
CODE = ['ext_engine.py', 'ext_common.py', 'y_common.py', 'y2_newton.py', 'y3_limiter.py', 'y4_ramp.py', 'y5_emt.py', 'finalize_emt.py',
        'y5_emt_v3.py', 'y5_emt_v3_synth.py', 'y5b_posthoc.py', 'finalize_emt2.py', 'y_chain.py',
        'y16_analysis.py', 'y_summary.py', 'y_extra.py', 'make_figs92.py', 'build_ms_v2.py', 'letters92.py', 'package92.py']


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def s1_addition():
    z = PK / 'Supplementary_S1_addition_p92_20261026.zip'
    base = 'p92_20261026/'
    readme = (
        'p92_20261026 - addition to Supplementary Material S1 (additional studies of Section 5.5 and Appendix G)\n\n'
        'kod/       ext_engine.py: byte-exact engine pinned by the TSV run (SHA-256 35d6bd77...b7f); ext_common.py unchanged;\n'
        '           y2_newton.py (Newton-kappa), y3_limiter.py (GFM close to its current limit), y4_ramp.py (ramped\n'
        '           shedding), y_chain.py (pinned sequential runner), y16_analysis.py (kappa-triggered rule, learned\n'
        '           baseline), y_summary.py and y_extra.py (pre-specified and post hoc summaries), make_figs92.py,\n'
        '           build_ms_v2.py, letters92.py, package92.py; y5_emt.py (switching-level check, protocol P92_EMT\n'
        '           v1/v2) and y5_emt_v3.py (repeat with min-max zero-sequence injection, protocol v3 with change\n'
        '           notes v3_1-v3_3; y5_emt_v3_synth.py = synthetic tests of its decision rules), finalize_emt*.py\n'
        'protokol/  P92_PROTOKOL_v1.txt (protocol, written before any computation) and P92_yetki.json (SHA-256 pins);\n'
        '           P92_EMT_PROTOKOL_v1, v2, v3, v3_1, v3_2, v3_3, the three code-audit reports of y5_emt_v3.py and\n'
        '           the run authorizations P92_EMT_yetki.json and P92_EMT_v3_yetki.json\n'
        'out/       y2/, y3/, y4/, y5/, y5v3/ (one run each, sealed by SHA256SUMS), y16/, summary/, selftest_*, chain.txt\n'
        'figures/   new PNG figures (600 dpi)\n\n'
        'Order (python >= 3.12 with numpy, scipy, matplotlib; G92_S1 = extracted development_20261026, G92_OUT =\n'
        'output folder): y2_newton.py --selftest; y3_limiter.py --selftest; y4_ramp.py --selftest; y_chain.py;\n'
        'y16_analysis.py; y_summary.py; y_extra.py; make_figs92.py; y5_emt.py --selftest/--run;\n'
        'y5_emt_v3.py --check-only, --selftest, --run --yetki protokol/P92_EMT_v3_yetki.json. A finished run refuses\n'
        'to run again. Separate code reviews: y5_emt_v3.py (protokol/P92_EMT_v3*_kod_denetimi.md) and the Y2/Y3\n'
        'scripts with their summaries (protokol/P92_y2y3_kod_denetimi.md); y4_ramp.py and y16_analysis.py were not\n'
        'reviewed.\n')
    with zipfile.ZipFile(z, 'w', zipfile.ZIP_DEFLATED) as f:
        f.writestr(base + 'README_p92_20261026.txt', readme)
        for c in CODE:
            f.write(HERE / c, base + 'kod/' + c)
        for p in (ROOT / 'protokol').iterdir():
            f.write(p, base + 'protokol/' + p.name)
        for p in sorted(G92.rglob('*')):
            if p.is_file():
                f.write(p, base + 'out/' + p.relative_to(G92).as_posix())
        for p in (ROOT / 'sekil').glob('*.png'):
            f.write(p, base + 'figures/' + p.name)
    shutil.copy(OLD / DEV, PK / DEV)
    (PK / 'SHA256_S1_eklari.txt').write_text(f'{sha(z)}  {z.name}\n{sha(PK / DEV)}  {DEV}\n', encoding='utf-8')
    return sha(z)


def report(zsha):
    d = Document()
    d.styles['Normal'].font.name = 'Calibri'
    d.styles['Normal'].font.size = Pt(10.5)
    d.add_heading('SEGAN makalesi — P92 iyileştirme turu raporu', level=0)
    d.add_paragraph('26 Ekim 2026 · protokol P92 v1').runs[0].italic = True
    d.add_heading('1. Özet', level=1)
    for t in [
        'Önceki turda önerilen iyileştirmeler uygulandı: dört yeni hesap çalışması (Y1, Y2, Y3, Y4) ve bir taban çizgisi '
        '(Y6) ön-kayıtlı protokolle yapıldı; makale v2 ve S2 Ek G yazıldı; dar yenilik kapısı (YK92) yürütüldü.',
        'Ana yeni bulgu: κ marj denkleminin türevidir; tek bir atma sonrası dengede yeniden hesaplanınca Newton-κ kestirimi '
        'aynı maliyetteki sekanttan ~12 kat daha doğru (MAE 1.1×10⁻⁴ pu, sekant 1.36×10⁻³ pu). Bu, önceki sürümün en zayıf '
        'noktasını ("büyüklükte sekant daha iyi") tersine çevirir.',
        'İkinci yeni bulgu: GFM akım sınırına yakınken (kullanım ≥ 0.85) donmuş marj noktaların çoğunda iyimser oluyor; '
        'işaret kuralı burada yalnız yanlış alarm veriyor, iyimser durumu hiç kaçırmıyor. Bu, iyimser rejimin "nadir ve sığ" '
        'itirazına yanıt verir; kanıt yine E2 düzeyindedir.',
        'Yenilik kapısı hükmü REVISE: Newton-κ ve κ-tetiklemeli kural yöntem yeniliği değildir (SSSC-OPF ardışık '
        'doğrusallaştırma, A düzeyi; seçici doğrulama, B düzeyi); makalede böyle sunuldu. Çekirdek iddiaya A/B tehdit '
        'bulunmadı (yokluğun ispatı değildir).']:
        d.add_paragraph(t, style='List Bullet')
    d.add_heading('2. Önerilerin durumu', level=1)
    rows = [
        ('İç süreç anlatısını çıkarma (tarihler, "earlier prospective extension")', 'YAPILDI', 'PSV S2 Ek G.3; ana metinde tek paragraf'),
        ('Özeti TSV ile başlatma, başlığı kısaltma', 'YAPILDI', 'yeni başlık; özet ~250 kelime'),
        ('Uzunluğu 11–13 bin kelimeye indirme', 'KISMEN (~−1000 kelime)', '18.7 bin → 19.7 bin kelime (Word), 36 → 38 sayfa: Tablo 6, Tablo 8 ve PSV S2’ye taşındı ama üç yeni çalışma eklendi. Ek kısaltma önerisi: §2.6 ve §3.8’in bir kısmı, Örnek 2 S2’ye.'),
        ('Maliyet mesajı', 'YAPILDI', 'Newton-κ ile “türev” çerçevesi (§6.8, Şekil 11a)'),
        ('İstatistik çerçevesi (duyarlılık/özgüllük)', 'YAPILDI', 'Tablo 10, §6.10'),
        ('SSSC-OPF ayrımı', 'YAPILDI', '[52], [53]; Tablo 2 yeni satır; §1 yenilik paragrafı'),
        ('Şekil 8 düzeltmesi', 'YAPILDI', 'iç çerçeve, lejant dışarıda, kırpılan noktalar işaretli'),
        ('Şekil 1(b) yerine kavramsal şekil', 'YAPILMADI', 'Şekil 1 tek görüntü; (a) panelinin kaynak dosyası yok'),
        ('Hash uyuşmazlığı (ext_engine.py)', 'ÇÖZÜLDÜ', 'koşuda sabitlenen dosya bayt düzeyinde yeniden kuruldu (35d6bd77…); S1 eki p92 içinde.'),
        ('Kaynak doğrulaması', 'YAPILDI', '[38] “F. Canales Perez”; [51] B.-M. Hodge çıkarıldı (arXiv kaydı); diğer 2026–2027 kaynakları doğru'),
        ('Y1 κ-tetiklemeli kural', 'YAPILDI', 'birincil kümede 0 güvensiz kabul, %2 ek denge; akım sınırında da 0'),
        ('Y2 Newton-κ', 'YAPILDI', 'H2a ve H2b desteklendi'),
        ('Y3 akım sınırı', 'YAPILDI', 'H3a desteklendi (p = 5.7×10⁻¹⁴); H3b desteklenmedi'),
        ('Y4 rampalı atma', 'YAPILDI', 'adım ıraksıyor, ≥ 0.25 s rampa ıraksamıyor; teğet miktarda 1-pu ölçütü tetiklenmedi (zarf ~20× büyüdü) — makalede açıkça yazıldı'),
        ('Y5 anahtarlamalı (EMT tipi) kontrol', 'YAPILDI — değerlendirilemez', '10 kHz: gecikme dengeyi bozuyor; 20 kHz: modülasyon sınırı, 6/6 durum rampadan sonra çöküyor (S2 G.7, §6.7). Aynı denklemlerle yerel Python uygulaması.'),
        ('Y5b modülasyon payı artırılmış tekrar (min-max/SVPWM)', *(ROOT / 'ms' / 'y5b_rapor.txt').read_text(encoding='utf-8').strip().split('\t')),
        ('Y6 öğrenen taban çizgisi', 'YAPILDI', 'aile-dışı dengeli doğruluk 0.87; κ işareti 1.00'),
        ('Y7–Y9 (çok kaynak, karışık blok, probe-κ)', 'İKİNCİ MAKALE', 'önerildiği gibi bu makaleye eklenmedi'),
        ('S1 ekleri tek pakette', 'YAPILDI', 'development_20261026 (değişmedi, SHA-256 b312ad6c…9321) ve p92_20261026 paket kökünde'),
        ('GitHub aynası', *(ROOT / 'ms' / 'ayna_durum.txt').read_text(encoding='utf-8').strip().split('\t')),
        ('Zenodo DOI', 'YAPILDI', 'kavram DOI 10.5281/zenodo.23665899 (tüm sürümler; veri beyanında); v1.3 = 10.5281/zenodo.23665900; v1.4 bu paketteki p92 ekini içerir; iki yazar ORCID ile'),
        ('Y2/Y3 bağımsız kod denetimi', 'YAPILDI — REVISE (yalnız metin)', 'tüm Y2/Y3 sayıları mühürlü kayıtlardan yeniden üretildi, hesap hatası yok; düzeltmeler: Tablo 9 aralık yöntemi, §6.8 N2–referans ofseti, S2 G.1 özet betikleri pinsiz (protokol/P92_y2y3_kod_denetimi.md)'),
        ('Özet ≤ 250 kelime (dergi kuralı)', 'YAPILDI', '260 → 247 kelime; makale gövdesi kısaltılmadı (dergide üst sınır yok)'),
    ]
    t = d.add_table(rows=1, cols=3)
    t.style = 'Table Grid'
    for i, h in enumerate(('Madde', 'Durum', 'Not / yer')):
        t.rows[0].cells[i].text = h
    for r in rows:
        c = t.add_row().cells
        for i, v in enumerate(r):
            c[i].text = v
    d.add_heading('3. Ön-kayıtlı sonuçlar (P92)', level=1)
    for t_ in [
        'Y2 (774 nokta): N1 MAE 1.11×10⁻⁴ pu (aralık 0.87–1.37×10⁻⁴), sekant-1 1.36×10⁻³, ikinci derece 1.47×10⁻³; '
        'κ ile başlatılmış sekant 5.3×10⁻⁴ (kazancın ~2/3’ü başlangıç noktasından). N2 4.14×10⁻⁵ (en büyük 1.6×10⁻⁴) — '
        'sekant-2 6.31×10⁻⁵ (en büyük 4.5×10⁻³). 10 noktada ilk Newton çözümü başarısız (sürdürme kullanılmadı). '
        'Newton kestirimleri tutucu değil (N1 763/764 aşma; bu düzeyde referans çözünürlüğüne yaklaşılıyor).',
        'Y3 (72 nokta × 4 seviye): κ<0 oranı %0, %51, %92, %100; gözlenen iyimser %0, %15, %60, %80; R1 uyumu 1.00, 0.69, '
        '0.70, 0.80. 45 uyumsuzluğun tamamı yanlış alarm (κ<0, gözlenen tutucu, ε₂ −4.6…−0.36); 93 iyimser durumun hiçbiri '
        'kaçırılmadı. H3b sapma notu: “ε₂ < 0.5” |ε₂| olarak değerlendirildi; harfi harfine okunuşta da hüküm aynı (S2 G.6).',
        'Y4: (0.65, 0.20) için adım referans/ikinci derece miktarlarında 0.75/0.82 s’de ıraksadı; 0.05 s ve üstü her rampada '
        'ıraksama yok. Diğer üyelerde adım 0.04–0.32 s’de ıraksadı, 0.25 s rampa ıraksamadı; (0.675, 0.18) adımda büyüyen 0.10 pu salınım.',
        'Y1/Y6 (post hoc): κ-tetiklemeli kural 1249 noktada 345 ek denge (%28) ve 1 güvensiz kabul (her noktada yeniden '
        'doğrusallaştırma da aynı noktayı kabul ediyor); doğal Sobol’da κ<0.05 oranı %3.4–4.2. Lojistik model C ailesindeki '
        'iki iyimser noktayı kaçırdı; tüm veriye uydurulsa bile 10 hata.']:
        d.add_paragraph(t_, style='List Bullet')
    d.add_heading('4. Kalan sınırlılıklar ve açık kararlar', level=1)
    for t_ in [
        'Kanıt düzeyi: ana sonuçlar E2 (ortalama-değer); anahtarlamalı kontrol aynı denklemlere PWM ve örnekleme eklenmiş bir zaman benzetimidir (bağımsız EMT aracı değildir).',
        'Y5b sonradan tasarlanmış bir izleme çalışmasıdır (v2 sonucu bilinirken); ayrılma ölçütü atmasız öz-test kaldıktan sonra, hiçbir durum sonucu görülmeden 10 ms süzgeçle değiştirildi (protokol v3_3). Makalede ve S2 G.8’de böyle beyan edildi.',
        'Bağımsız kod denetimi: y5_emt_v3.py (üç tur, ACCEPT) ve Y2/Y3 betikleri (REVISE, yalnız metin; düzeltmeler işlendi). y4_ramp.py ve y16_analysis.py denetlenmedi.',
        'İnceleme notları: yeni başlık, §5.5, §6.7 eki, §6.8 (Newton-κ), §6.10, §7.5’teki anahtarlamalı-model sınırlılığı.',
        'Declaration_of_interest.docx değiştirilmedi; Title_page.docx’te yalnız başlık güncellendi.',
        'Uzunluk ~19.3 bin kelime; dergide üst sınır yok.']:
        d.add_paragraph(t_, style='List Bullet')
    d.add_heading('5. Bütünlük', level=1)
    d.add_paragraph(f'Supplementary_S1_addition_p92_20261026.zip SHA-256: {zsha}')
    d.add_paragraph('Hesap çıktıları (y2, y3, y4) tek koşudur ve SHA256SUMS ile mühürlüdür; yetki dosyası pinleri koşu başında doğrulandı (chain.txt).')
    d.save(PK / '05_RAPORLAR' / 'P92_Gelistirme_Raporu.docx')


def main():
    if PK.exists():
        shutil.rmtree(PK)
    for sub in ('01_MAKALE_GONDERIM', '02_DOGRULAMA_VERILERI', '03_SEKILLER', '04_KOD_VE_PROTOKOL', '05_RAPORLAR'):
        (PK / sub).mkdir(parents=True)
    M = PK / '01_MAKALE_GONDERIM'
    for f in ('Manuscript.docx', 'Manuscript_proof.pdf', 'Supplementary_Methods_S2.docx', 'S2_proof.pdf', 'Highlights.docx',
              'Cover_letter_journal.docx', 'Title_page.docx'):
        shutil.copy(ROOT / 'cikti' / f, M / f)
    shutil.copy(OLD / '01_MAKALE_GONDERIM' / 'Declaration_of_interest.docx', M)
    for n in range(1, 8):
        shutil.copy(OLD / '01_MAKALE_GONDERIM' / f'Figure_{n}.tif', M)
    shutil.copy(OLD / '01_MAKALE_GONDERIM' / 'Figure_9.tif', M)
    for n, name in ((8, 'fig_kappa_sign_v2'), (10, 'fig_stress_ramp'), (11, 'fig_accuracy_v2')):
        Image.open(ROOT / 'sekil' / f'{name}.png').convert('RGB').save(M / f'Figure_{n}.tif', compression='tiff_lzw',
                                                                       dpi=(500, 500))
    for p in (ROOT / 'sekil').glob('*.png'):
        shutil.copy(p, PK / '03_SEKILLER')
    V = PK / '02_DOGRULAMA_VERILERI'
    for p in (ROOT / 'out_ozet').iterdir():
        shutil.copy(p, V)
    wb = Workbook()
    wb.remove(wb.active)
    for p in sorted(V.glob('*.csv')):
        ws = wb.create_sheet(p.stem[:31])
        for row in csv.reader(open(p, encoding='utf-8')):
            out = []
            for c in row:
                try:
                    out.append(float(c))
                except ValueError:
                    out.append(c)
            ws.append(out)
    wb.save(V / 'Dogrulama_tablolari_P92.xlsx')
    K = PK / '04_KOD_VE_PROTOKOL'
    (K / 'kod').mkdir()
    for c in CODE:
        shutil.copy(HERE / c, K / 'kod' / c)
    shutil.copytree(ROOT / 'protokol', K / 'protokol')
    shutil.copy(ROOT / 'ms' / 'ms_v3_plan.txt', K / 'kod')
    shutil.copy(ROOT / 'ms' / 's2_appG_plan.txt', K / 'kod')
    for p in (ROOT / 'yk').glob('*.docx'):         # converted from the .md files beforehand (pandoc venv)
        shutil.copy(p, PK / '05_RAPORLAR' / p.name)
    zsha = s1_addition()
    report(zsha)
    (PK / 'BENIOKU.txt').write_text(
        'TESLIM PAKETI - SEGAN P92 iyilestirme turu (26 Ekim 2026)\n\n'
        '01_MAKALE_GONDERIM   Manuscript v2 (yeni baslik), Supplementary_Methods_S2 (Ek G yeni), PDF on-izlemeler,\n'
        '                     Highlights, kapak mektubu, Title_page (yalniz baslik degisti), Declaration (degismedi),\n'
        '                     Figure_1..11.tif (Figure_8 duzeltildi; Figure_10 ve 11 yeni; Figure_11 = eski Sekil 10)\n'
        '02_DOGRULAMA_VERILERI P92 ozet CSV/JSON, kaynak dogrulama kaydi, Dogrulama_tablolari_P92.xlsx\n'
        '03_SEKILLER          yeni sekiller PNG (600 dpi)\n'
        '04_KOD_VE_PROTOKOL   P92 betikleri, makale derleme planlari, protokol ve yetki dosyasi\n'
        '05_RAPORLAR          P92 gelistirme raporu, yenilik kapisi plani ve sonucu\n'
        'Supplementary_S1_addition_p92_20261026.zip          S1 eki (kod, protokol, muhurlu ciktilar)\n'
        'Supplementary_S1_addition_development_20261026.zip  onceki S1 eki (degismedi; onceki paketten aynen)\n'
        'SHA256_S1_eklari.txt                                iki ekin SHA-256 degerleri\n\n'
        'DERGIYE YUKLEME: 01_MAKALE_GONDERIM icindeki Manuscript.docx, Supplementary_Methods_S2.docx, Figure_1..11.tif,\n'
        'Highlights, Cover_letter_journal, Title_page, Declaration_of_interest; S1 icin kokteki IKI zip.\n', encoding='utf-8')
    final = DEST / f'{NAME}.zip'
    if final.exists():
        final.unlink()
    with zipfile.ZipFile(final, 'w', zipfile.ZIP_DEFLATED) as f:
        for p in sorted(PK.rglob('*')):
            if p.is_file():
                f.write(p, (Path(NAME) / p.relative_to(PK)).as_posix())
    print('zip', final, final.stat().st_size, sha(final))


if __name__ == '__main__':
    main()
