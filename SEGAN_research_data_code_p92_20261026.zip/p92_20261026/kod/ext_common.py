"""Common definitions of the development round: system builders, physical-validity gates, Stage-1 predictors
(including the kappa decomposition), Stage-2 reference and comparator estimators, with solve counters.

Imports only numpy and kod/ext_engine.py. Every quantity is defined as in the manuscript (Sections 3-5) and in the
sealed PSV runner (revizyon_20261025/psv/psv_run.py); differences are marked 'NEW'.
"""
import math
import os
import time

os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('MKL_NUM_THREADS', '1')
import numpy as np  # noqa: E402

import ext_engine as E  # noqa: E402

def lower_priority():
    """Run the calling process at below-normal priority (Windows); no effect elsewhere."""
    try:
        import ctypes
        k = ctypes.windll.kernel32
        k.GetCurrentProcess.restype = ctypes.c_void_p
        k.SetPriorityClass.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
        k.SetPriorityClass(k.GetCurrentProcess(), 0x00004000)

        class _PT(ctypes.Structure):
            _fields_ = [('Version', ctypes.c_ulong), ('ControlMask', ctypes.c_ulong), ('StateMask', ctypes.c_ulong)]
        # opt out of EcoQoS execution-speed throttling of background processes (priority stays below normal)
        st = _PT(1, 0x1, 0x0)
        k.SetProcessInformation.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p, ctypes.c_ulong]
        k.SetProcessInformation(k.GetCurrentProcess(), 4, ctypes.byref(st), ctypes.sizeof(st))
        # pin to the efficiency cores (logical CPUs 16-31 of this machine, EfficiencyClass 0): random native crashes
        # (0xC0000005, 0xC0000409) occurred only on the performance cores; results do not depend on the core
        if os.cpu_count() == 32:
            k.SetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
            k.SetProcessAffinityMask(k.GetCurrentProcess(), 0xFFFF0000)
    except Exception:  # noqa: BLE001
        pass


def plog(msg, path):
    """Append one progress line to a log file, opening and closing it each time (safe against readers)."""
    try:
        with open(path, 'a', encoding='utf-8') as fh:
            fh.write(time.strftime('%H:%M:%S ') + str(msg) + '\n')
    except OSError:
        pass


VB, PB = 380.0, 10000.0
IB = PB / VB
VB_DC = math.sqrt(8) / math.sqrt(3) * VB
VDC_NOM_PU = 700.0 / VB_DC            # 700 V nominal CPL DC link
VDC_GFM_PU = 690.0 / VB_DC            # GFM DC link of the author data
TAU_K, TIE_K, H_REL = 0.05, 2e-3, 1e-3


# --------------------------------------------------------------------------------------------- device variants
def cpl_variant(base, Kiv=None, s_pll=1.0, s_cc=1.0, P_dc=None, Q_set=0.0, ilim=None):
    """CPL parameter dict. Kiv in A/(V s) (K_pv = K_iv/300, as the study); NEW: if P_dc is given, the DC load resistor
    is sized so that the DC link sits at its 700 V nominal at that power (physically sized CPL)."""
    q = dict(base)
    if Kiv is not None:
        q['kiv'] = Kiv * (VB_DC / IB)
        q['kpv'] = (Kiv / 300.0) * (VB_DC / IB)
    q['kp_pll'], q['ki_pll'] = base['kp_pll'] * s_pll, base['ki_pll'] * s_pll
    q['kpc'], q['kic'] = base['kpc'] * s_cc, base['kic'] * s_cc
    if P_dc is not None:
        q['r_load'] = VDC_NOM_PU ** 2 / P_dc
    if ilim is not None:
        q['ilim'] = dict(ilim)
    return q


def line(f, t, z, rx):
    """Line from bus f to bus t with impedance magnitude z (pu) and R/X ratio rx."""
    x = z / math.sqrt(1.0 + rx * rx)
    return dict(f=f, t=t, r=rx * x, x=x)


# --------------------------------------------------------------------------------------------- systems
def _opt(sysd, sp):
    """Optional sensitivity-only modifiers (absent in the sampled families): 'cdc' scales the DC-link capacitance of
    every CPL; 's_cc_gfm' scales the GFM current-loop gains."""
    if 'cdc' in sp:
        for cd in sysd['cpls']:
            cd['par']['c_dc'] = cd['par']['c_dc'] * sp['cdc']
    if 's_cc_gfm' in sp:
        g = sysd['par']['gfm']
        g['kpc'], g['kic'] = g['kpc'] * sp['s_cc_gfm'], g['kic'] * sp['s_cc_gfm']


def build_A2(sp):
    """NEW family A2: original two-bus topology with physically sized CPL DC load and variable line R/X."""
    par = E.base_parameters()
    g = par['gfm']
    g['lv'], g['rv'], g['kq'], g['Rp'] = sp['lv'], sp['rv'], sp['kq'], sp['Rp']
    g['kpv'], g['kiv'] = g['kpv'] * sp['s_v'], g['kiv'] * sp['s_v']
    z = math.hypot(0.01, 0.1) * sp['s_line']
    sysd = dict(par=par, buses=['1', '2'], b_shunt=[0.005, 0.005], lines=[line(0, 1, z, sp['rx'])], gfm_bus=0,
                cpls=[dict(bus=1, par=cpl_variant(par['cpl'], sp['Kiv'], sp['s_pll'], sp['s_cc'], P_dc=sp['P_set']),
                           Q_set=sp.get('q', 0.0) * sp['P_set'])],
                shed_bus=1)
    _opt(sysd, sp)
    if sp.get('gfm_ilim'):
        sysd['gfm_ilim'] = dict(sp['gfm_ilim'])
    return E.Layout(sysd), np.array([0.0, sp['G_R']]), [sp['P_set']]


def build_B2(sp):
    """NEW family B2: the three-bus radial feeder of PSV system B with physically sized CPL DC loads and line R/X."""
    par = E.base_parameters()
    par['gfm']['lv'] = sp['lv']
    z0 = math.hypot(0.01, 0.1)
    sysd = dict(par=par, buses=['1', '2', '3'], b_shunt=[0.005, 0.010, 0.005],
                lines=[line(0, 1, z0 * sp['s_l1'], sp['rx']), line(1, 2, z0 * sp['s_l2'], sp['rx'])], gfm_bus=0,
                cpls=[dict(bus=1, par=cpl_variant(par['cpl'], sp['Kiv1'], sp['s_pll1'], P_dc=sp['P1'])),
                      dict(bus=2, par=cpl_variant(par['cpl'], sp['Kiv2'], sp['s_pll2'], P_dc=sp['P2']),
                           Q_set=sp.get('q', 0.0) * sp['P2'])],
                shed_bus=2)
    _opt(sysd, sp)
    return E.Layout(sysd), np.array([0.0, sp['G2'], sp['G_R']]), [sp['P1'], sp['P2']]


def build_C(sp):
    """NEW system C: five-bus meshed low-voltage-type microgrid. Bus 0 GFM; trunk 0-1; loop 1-2-3-4-1 of resistive
    cables (R/X = rx); CPL1 at bus 2, CPL2 at bus 3, CPL3 with the sheddable resistive load at bus 4; non-shed
    resistive loads at buses 1 and 3."""
    par = E.base_parameters()
    par['gfm']['lv'] = sp['lv']
    zt, zl = sp['z_trunk'], sp['z_loop']
    lines = [line(0, 1, zt, sp['rx_trunk']), line(1, 2, zl, sp['rx']), line(2, 3, zl * sp['f23'], sp['rx']),
             line(3, 4, zl * sp['f34'], sp['rx']), line(1, 4, zl * sp['f14'], sp['rx'])]
    sysd = dict(par=par, buses=['1', '2', '3', '4', '5'], b_shunt=[0.004, 0.008, 0.008, 0.008, 0.008], lines=lines,
                gfm_bus=0,
                cpls=[dict(bus=2, par=cpl_variant(par['cpl'], sp['Kiv1'], sp['s_pll1'], P_dc=sp['P1'])),
                      dict(bus=3, par=cpl_variant(par['cpl'], sp['Kiv2'], sp['s_pll2'], P_dc=sp['P2'])),
                      dict(bus=4, par=cpl_variant(par['cpl'], sp['Kiv3'], sp['s_pll3'], P_dc=sp['P3']),
                           Q_set=sp.get('q', 0.0) * sp['P3'])],
                shed_bus=4)
    _opt(sysd, sp)
    return E.Layout(sysd), np.array([0.0, sp['G1'], 0.0, sp['G3'], sp['G_R']]), [sp['P1'], sp['P2'], sp['P3']]


def build_F2(P_set, G_R, ilim=None, cpl_ilim=None):
    """Original test model (member of F2): two-bus system of the study, setting S3."""
    par = E.base_parameters()
    sysd = E.two_bus_system(par)
    if ilim:
        sysd['gfm_ilim'] = dict(ilim)
    if cpl_ilim:
        sysd['cpls'][0]['par']['ilim'] = dict(cpl_ilim)
    return E.Layout(sysd), np.array([0.0, G_R]), [P_set]


def build_psvA(spec):
    """PSV system A exactly as the sealed runner (fixed 70-ohm DC load)."""
    par = E.base_parameters()
    g = par['gfm']
    g['lv'], g['rv'], g['kq'], g['Rp'] = spec['lv'], spec['rv'], spec['kq'], spec['Rp']
    g['kpv'], g['kiv'] = g['kpv'] * spec['s_v'], g['kiv'] * spec['s_v']
    sysd = dict(par=par, buses=['1', '2'], b_shunt=[0.005, 0.005],
                lines=[dict(f=0, t=1, r=0.01 * spec['s_line'], x=0.1 * spec['s_line'])], gfm_bus=0,
                cpls=[dict(bus=1, par=cpl_variant(par['cpl'], spec['Kiv'], spec['s_pll'], spec['s_cc']))], shed_bus=1)
    return E.Layout(sysd), np.array([0.0, spec['G_R']]), [spec['P_set']]


def build_psvB(spec):
    par = E.base_parameters()
    par['gfm']['lv'] = spec['lv']
    sysd = dict(par=par, buses=['1', '2', '3'], b_shunt=[0.005, 0.010, 0.005],
                lines=[dict(f=0, t=1, r=0.01 * spec['s_l1'], x=0.1 * spec['s_l1']),
                       dict(f=1, t=2, r=0.01 * spec['s_l2'], x=0.1 * spec['s_l2'])], gfm_bus=0,
                cpls=[dict(bus=1, par=cpl_variant(par['cpl'], spec['Kiv1'], spec['s_pll1'])),
                      dict(bus=2, par=cpl_variant(par['cpl'], spec['Kiv2'], spec['s_pll2']))], shed_bus=2)
    return E.Layout(sysd), np.array([0.0, spec['G2'], spec['G_R']]), [spec['P1'], spec['P2']]


BUILDERS = dict(A2=build_A2, B2=build_B2, C=build_C, psvA=build_psvA, psvB=build_psvB)


# --------------------------------------------------------------------------------------------- operating quantities
def operating_quantities(lay, x0, refs, G, P):
    """Bus voltages, source and CPL currents, frame frequency, modulation indices, DC-link deviation."""
    s, p = lay.sysd, lay.sysd['par']
    ix = lay.ix
    g = p['gfm']
    nb = len(s['buses'])
    V = [abs(complex(x0[ix[f'V{k}:R']], x0[ix[f'V{k}:I']])) for k in range(nb)]
    z = g['w_ref'] + g['Rp'] * (refs[0] - x0[ix['G:pm']])
    Ig = abs(complex(x0[ix['G:Irf']], x0[ix['G:Iif']]))
    # GFM inner current reference magnitude (what a limiter acts on): equals the converter current at equilibrium
    Igc = abs(complex(x0[ix['G:Irc']], x0[ix['G:Iic']]))
    # GFM converter voltage = filter voltage + (rf + j z lf) i_c
    Vf = complex(x0[ix['G:Vrf']], x0[ix['G:Vif']])
    Vc = Vf + complex(g['rf'], z * g['lf']) * complex(x0[ix['G:Irc']], x0[ix['G:Iic']])
    out = dict(Vmin=min(V), Vmax=max(V), V=V, z=z, I_gfm=Ig, I_gfm_conv=Igc, m_gfm=abs(Vc) / VDC_GFM_PU)
    m, Ic, dev = [], [], []
    for c, cd in enumerate(s['cpls']):
        q = cd['par']
        pre = f'C{c}:'
        Vfl = complex(x0[ix[pre + 'Vrf']], x0[ix[pre + 'Vif']])
        Icl = complex(x0[ix[pre + 'Irc']], x0[ix[pre + 'Iic']])
        Vcl = Vfl - complex(q['rf'], z * q['lf']) * Icl
        vdc = x0[ix[pre + 'vdc']]
        m.append(abs(Vcl) / vdc)
        Ic.append(abs(complex(x0[ix[pre + 'Irf']], x0[ix[pre + 'Iif']])))
        dev.append(vdc / VDC_NOM_PU - 1.0)
    out.update(m_cpl=m, I_cpl=Ic, vdc_dev=dev, load=sum(P) + sum(G[k] * V[k] ** 2 for k in range(nb)),
               S_G=V[s['gfm_bus']] * Ig)
    return out


def physical_gate(oq, strict=True):
    """K1-type operating limits of the study (S2 Table B.5) plus NEW DC-link check. Returns failure label or None."""
    if not (0.88 <= oq['Vmin'] and oq['Vmax'] <= 1.10):
        return 'G2-voltage'
    if oq['S_G'] > 1.0 or oq['load'] > 1.0 or oq['I_gfm'] > 1.0:
        return 'G2-source'
    if not strict:
        return None
    if not (0.98 <= oq['z'] <= 1.02):
        return 'G2-frequency'
    if max(oq['I_cpl']) > 1.0:
        return 'G2-cpl-current'
    if max(oq['m_cpl']) > 1.0:
        return 'G2-modulation'
    if max(abs(d) for d in oq['vdc_dev']) > 0.15:
        return 'G2-dclink'
    return None


# --------------------------------------------------------------------------------------------- decomposition
def decompose(lay, x0, refs, G, th, crit, kres, P_bus):
    """NEW: ideal-CPL load-side decomposition (Eqs. 12-15) of the computed coefficient at the shedding bus.
    P_bus: active power of the CPL at the shedding bus (0 if none). Returns dict."""
    ix = lay.ix
    sb = lay.sysd['shed_bus']
    Vr, Vi = x0[ix[f'V{sb}:R']], x0[ix[f'V{sb}:I']]
    V = math.hypot(Vr, Vi)
    xi = kres['xi']
    R = E.rot(-th)
    xd, xq = R @ np.array([xi[ix[f'V{sb}:R']], xi[ix[f'V{sb}:I']]])
    Jm = E.jac(lay, x0, refs, G)
    lam, v, wl, Y = E.eig_branch(lay, Jm, th, crit['omega'], crit['lam'])
    den = wl @ v
    pd = wl[0] * v[0] / den
    px = (wl[0] * v[1] + wl[1] * v[0]) / den
    c = kres['c']
    k2 = 2.0 * P_bus / V ** 3
    eV = k2 * xd * (2 * pd - 1)
    eT = -k2 * xq * px
    kV = (eV * complex(1, c)).real
    kT = (eT * complex(1, c)).real
    # anisotropy of the remaining port admittance Y - G_R I - Y_CPL,ideal (Y_CPL,ideal = -(P/V^2) Sigma in F0)
    Yr = Y - G[sb] * np.eye(2) + (P_bus / V ** 2) * np.diag([1.0, -1.0])
    al, be = (Yr[0, 0] + Yr[1, 1]) / 2, (Yr[1, 0] - Yr[0, 1]) / 2
    mu, de = (Yr[0, 0] - Yr[1, 1]) / 2, (Yr[0, 1] + Yr[1, 0]) / 2
    aniso = math.sqrt(abs(mu) ** 2 + abs(de) ** 2) / max(1e-300, math.sqrt(abs(al) ** 2 + abs(be) ** 2))
    return dict(V_b=V, xi_d=float(xd), xi_q=float(xq), pi_d_re=pd.real, pi_d_im=pd.imag, pi_x_abs=abs(px),
                kappa_V=kV, kappa_theta=kT, kappa_L=kV + kT, kappa_rest=kres['kappa'] - kV - kT, aniso=aniso)


# --------------------------------------------------------------------------------------------- stage 1
def stage1(lay, G, P, rec=None, strict=True, P_bus=None, mapping=False):
    """Predictor stage at x0 and x(+-h) only (no reference). Same gates as the PSV runner (G1-G6), with the NEW
    strict physical gate. Adds decomposition, conditioning and the dimensionless curvature indicator."""
    rec = {} if rec is None else rec
    t0 = time.perf_counter()
    d = E.dispatch(lay, P, G, tol=1e-12)
    rec['res'] = d['hist'][-1]
    if not (d['ok'] or d['hist'][-1] <= 1e-8):     # residual criterion of gate K1 of the study (1e-8)
        rec['excl'] = 'G1'
        return rec
    return stage1_at(lay, G, P, d['x'], d['refs'], rec, strict, P_bus, t0, mapping)


def stage1_at(lay, G, P, x0, refs, rec=None, strict=True, P_bus=None, t0=None, mapping=False):
    """Stage 1 at a given equilibrium (x0, refs): used directly when the set-points are imposed (limiter study).
    mapping=True (sensitivity maps only): the physical gate and the bound dGf <= G_R are recorded as flags
    ('phys_gate', 'g4_bound') instead of ending the evaluation."""
    rec = {} if rec is None else rec
    t0 = time.perf_counter() if t0 is None else t0
    cnt = dict(eq=0, jac=0, scan=0)
    sb = lay.sysd['shed_bus']
    oq = operating_quantities(lay, x0, refs, G, P)
    rec.update(Vmin=oq['Vmin'], Vmax=oq['Vmax'], z=oq['z'], I_gfm=oq['I_gfm'], I_gfm_conv=oq['I_gfm_conv'],
               m_gfm=oq['m_gfm'], m_cpl_max=max(oq['m_cpl']), I_cpl_max=max(oq['I_cpl']),
               vdc_dev_maxabs=max(abs(v) for v in oq['vdc_dev']), load=oq['load'], S_G=oq['S_G'])
    gate = physical_gate(oq, strict)
    rec['phys_gate'] = gate
    if gate and not mapping:
        rec['excl'] = gate
        return rec
    Jm = E.jac(lay, x0, refs, G)
    cnt['jac'] += 1
    a = E.spectral_abscissa(lay, Jm)[0]
    keep = lay.keep
    A = Jm[np.ix_(keep, keep)] / lay.M[keep][:, None]
    tab = 1e-10 * float(np.linalg.norm(A, 2))
    rec['alpha0'] = a
    if not a < -max(1e-3, tab):
        rec['excl'] = 'G3'
        return rec
    th = float(np.arctan2(x0[lay.ix[f'V{sb}:I']], x0[lay.ix[f'V{sb}:R']]))
    fm = E.frozen_margin(lay, Jm, th, G[sb])
    cnt['scan'] += 1
    rec['g4_bound'] = fm is not None and fm['rho'] > G[sb]
    if fm is None or not (0 < fm['rho'] <= G[sb] or (mapping and fm['rho'] > 0)):
        rec['excl'] = 'G4'
        rec['dGf'] = None if fm is None else fm['rho']
        return rec
    Y0 = E.to_F0(E.port_admittance(lay, Jm, 0.0), th)
    if any(abs(e.imag) < 1e-12 and 0 < e.real <= fm['rho'] for e in np.linalg.eigvals(Y0)):
        rec['excl'] = 'G4-omega0'
        return rec
    k = E.kappa_hat(lay, x0, refs, G, th, fm)
    cnt['jac'] += 3
    lam, _, _, Yw = E.eig_branch(lay, Jm, th, fm['omega'], fm['lam'])
    evw = np.linalg.eigvals(Yw)
    gap = float(abs(evw[0] - evw[1]))
    t_first = time.perf_counter() - t0
    rec.update(dGf=fm['rho'], omega=fm['omega'], c=k['c'], eta_re=k['eta'].real, eta_im=k['eta'].imag,
               kappa=k['kappa'], kappa_noc=k['eta'].real, gap=gap, gap_rel=gap / max(1.0, abs(lam)),
               dIm_domega=k['dlam_domega'].imag, cond_J=float(np.linalg.cond(Jm[np.ix_(keep, keep)])),
               xi_norm_state=float(np.linalg.norm(k['xi'][keep])), dGf_over_GR=fm['rho'] / G[sb])
    if P_bus is None:
        P_bus = sum(P[c] for c, cd in enumerate(lay.sysd['cpls']) if cd['bus'] == sb)
    rec.update(decompose(lay, x0, refs, G, th, fm, k, P_bus))
    rec['dv_rel_at_margin'] = abs(rec['xi_d']) * fm['rho'] / rec['V_b']
    if not (gap >= 1e-6 * max(1.0, abs(lam)) and abs(k['dlam_domega'].imag) >= 1e-9):
        rec['excl'] = 'G5'
        return rec
    h = H_REL * fm['rho']
    rr = {}
    for sg in (1, -1):
        Gk = G.copy()
        Gk[sb] -= sg * h
        xs, ok, _, nj = E.newton_fixed_refs(lay, x0, refs, Gk)
        cnt['eq'] += 1
        cnt['jac'] += nj
        if not ok:
            rec['excl'] = 'G6-newton'
            return rec
        rr[sg] = E.rho_at(lay, xs, refs, G, th, fm)['rho']
        cnt['jac'] += 1
    k_fd = (rr[1] - rr[-1]) / (2 * h)
    curv = (rr[1] - 2 * fm['rho'] + rr[-1]) / h ** 2
    rec.update(k_fd=k_fd, curv=curv)
    sign_ok = abs(k_fd) < 0.005 or np.sign(k['kappa']) == np.sign(k_fd)
    mag_ok = abs(k['kappa'] - k_fd) <= 0.10 * max(abs(k_fd), TAU_K)
    if not (sign_ok and mag_ok):
        rec['excl'] = 'G6'
        return rec
    kk = k['kappa']
    rec['dG1st'] = fm['rho'] / (1 - kk) if kk < 1 else float('inf')
    rec['dG1st_noc'] = fm['rho'] / (1 - k['eta'].real) if k['eta'].real < 1 else float('inf')
    rec['dG1st_L'] = fm['rho'] / (1 - rec['kappa_L']) if rec['kappa_L'] < 1 else float('inf')
    rec['dG2nd'] = quad_root(fm['rho'], k_fd, curv)
    # NEW dimensionless curvature indicator of Eq. (18): eps2 = -2 rho'' dGf / (1 - kappa)^2
    rec['eps2'] = -2.0 * curv * fm['rho'] / (1.0 - k_fd) ** 2 if k_fd < 1 else float('nan')
    rec['excl'] = None
    rec['abstain'] = abs(kk) < TAU_K
    rec['cost_stage1'] = dict(cnt, t_first=t_first, t_total=time.perf_counter() - t0)
    return rec


def quad_root(dGf, k, curv):
    """Smallest positive root of dGf + (k - 1) x + curv x^2 / 2 (Eq. 17), as the PSV runner."""
    a2, b2, c2 = 0.5 * curv, k - 1.0, dGf
    if abs(a2) < 1e-300:
        return -c2 / b2 if b2 < 0 else None
    disc = b2 * b2 - 4 * a2 * c2
    roots = [(-b2 - math.sqrt(disc)) / (2 * a2), (-b2 + math.sqrt(disc)) / (2 * a2)] if disc >= 0 else []
    pos = [r for r in roots if r > 0]
    return min(pos) if pos else None


# --------------------------------------------------------------------------------------------- stage 2
def ref_sign_of(status, e, dGf):
    if status.startswith('unstable'):
        return None
    if status.startswith('censored'):
        return 1
    tie = TIE_K * dGf
    return 1 if e > tie else (-1 if e < -tie else 0)


def F_min_at(lay, x0, refs, G, dG, th):
    """min over crossings of rho_z(x(dG)) - dG at one further equilibrium (single-step relinearization)."""
    sb = lay.sysd['shed_bus']
    Gk = G.copy()
    Gk[sb] -= dG
    xs, ok, _, nj = E.newton_fixed_refs(lay, x0, refs, Gk)
    if not ok:
        return None, nj
    cr = [c for c in E.crossings(lay, E.jac(lay, xs, refs, G), th) if c['rho'] > 0]
    return ((min(c['rho'] for c in cr) - dG) if cr else float('inf')), nj + 1


def stage2(lay, G, P, rec, with_exact=True, x0=None, refs=None):
    """Reference margin (relative tolerance, as the sealed runs), exact-crossing reference, single-step
    relinearization and NEW one- and two-solve secant estimators. Returns dict with counters and timings.
    If (x0, refs) are given they are used instead of the dispatch (imposed set-points)."""
    sb = lay.sysd['shed_bus']
    if x0 is None:
        d = E.dispatch(lay, P, G, tol=1e-12)
        x0, refs = d['x'], d['refs']
    dGf = rec['dGf']
    dmax = min(G[sb], 2.0 * dGf)
    t0 = time.perf_counter()
    R = E.reference_margin(lay, x0, refs, G, dmax, 0.01 * dGf, tol=1e-9, alpha_tab='rel')
    t_ref = time.perf_counter() - t0
    out = dict(dGref=R['dGt'], ref_status=R['status'], ref_newton_solves=R['newton_solves'],
               ref_jacobians=R['jacobians'], ref_eig=R['eig_solves'], ref_points=R['points'], t_ref=t_ref,
               dG_max=dmax)
    if with_exact:
        try:
            out['dGref_exact'] = E.reference_margin(lay, x0, refs, G, dmax, 0.01 * dGf, tol=1e-9,
                                                    alpha_tab=0.0)['dGt']
        except Exception as exc:  # noqa: BLE001
            out['dGref_exact'] = None
            out['exact_error'] = f'{type(exc).__name__}: {exc}'
    e = R['dGt'] - dGf
    s = ref_sign_of(R['status'], e, dGf)
    out.update(err=e, rel_err=e / dGf, ref_sign=s, fold=R['status'].startswith('newton'),
               censored=R['status'].startswith('censored'))
    th = float(np.arctan2(x0[lay.ix[f'V{sb}:I']], x0[lay.ix[f'V{sb}:R']]))
    t1 = time.perf_counter()
    F1, nj1 = F_min_at(lay, x0, refs, G, dGf, th)
    out['F_single'] = F1
    out['t_single'] = time.perf_counter() - t1
    # NEW secant estimators on F_min: points (0, dGf) and (dGf, F1); then one regula-falsi/secant step
    if F1 is not None and math.isfinite(F1) and F1 < dGf:
        s1 = dGf * dGf / (dGf - F1)
        out['dG_sec1'] = s1
        F2, _ = F_min_at(lay, x0, refs, G, s1, th) if s1 > 0 else (None, 0)
        if F2 is not None and math.isfinite(F2) and abs(F2 - F1) > 1e-300:
            out['dG_sec2'] = s1 - F2 * (s1 - dGf) / (F2 - F1)
        else:
            out['dG_sec2'] = None
    else:
        out['dG_sec1'] = None
        out['dG_sec2'] = None
    out['t_sec2'] = time.perf_counter() - t1
    return out
