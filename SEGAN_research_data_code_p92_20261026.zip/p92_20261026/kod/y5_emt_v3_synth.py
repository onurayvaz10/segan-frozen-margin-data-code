"""Hand-made synthetic tests of the decision functions of y5_emt_v3.py (protocol P92_EMT_PROTOKOL_v3 s5-s7 with
change note v3_1 D1/D4). No model import, no simulation. Argument: an empty scratch folder for the resume test.
Exit 0 = pass."""
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import y5_emt_v3 as V  # noqa: E402

ok = []


def eq(name, got, want):
    ok.append(got == want)
    print('PASS' if got == want else 'FAIL', name, got, want)


Z = {'G': 0.0, 'C0': 0.0}
# s5 direction
eq('dir growing', V.direction('growing'), 'unstable')
eq('dir diverged', V.direction('diverged'), 'unstable')
eq('dir decaying', V.direction('decaying'), 'stable')
eq('dir undetermined', V.direction('undetermined'), None)
# s6 rows in order
eq('E1 ctrl undetermined', V.evaluable('growing', 'undetermined', True, Z, 'growing'), ('E1', None))
eq('E1 ctrl wrong', V.evaluable('decaying', 'diverged', True, Z, 'decaying'), ('E1', None))
eq('E1 before E2', V.evaluable('decaying', 'growing', False, {'G': 0.5}, 'growing'), ('E1', None))
eq('E2 no eq', V.evaluable('decaying', 'decaying', False, Z, 'decaying'), ('E2', None))
eq('E2 before E3', V.evaluable('decaying', 'decaying', False, {'G': 0.5}, 'decaying'), ('E2', None))
eq('E3 sat at threshold', V.evaluable('decaying', 'decaying', True, {'G': 0.0, 'C0': 1e-3}, 'decaying'), ('E3', None))
eq('E3 none', V.evaluable('decaying', 'decaying', True, None, 'decaying'), ('E3', None))
eq('E3 empty', V.evaluable('decaying', 'decaying', True, {}, 'decaying'), ('E3', None))
eq('E3 one converter without evaluation', V.evaluable('decaying', 'decaying', True, {'G': 0.0, 'C0': None}, 'decaying'), ('E3', None))
eq('E3 before E4', V.evaluable('growing', 'growing', True, {'G': 0.2}, 'undetermined'), ('E3', None))
eq('below threshold ok', V.evaluable('decaying', 'decaying', True, {'G': 9.99e-4}, 'decaying'), ('ok', True))
eq('E4 sw undetermined', V.evaluable('growing', 'growing', True, Z, 'undetermined'), ('E4', None))
eq('ok agree diverged=unstable', V.evaluable('growing', 'diverged', True, Z, 'diverged'), ('ok', True))
eq('ok disagree', V.evaluable('decaying', 'decaying', True, Z, 'diverged'), ('ok', False))

# v3.1 D1 / v3.2 D5-D6 departure and saturation window (record indices)
# v3.3 D9: WD = 25 centred filter, interior indices [W + 12, n - W - 12) = [17, n - 17)
base = [1.0] * 100
eq('filter width', (V.W, V.WD), (5, 25))
eq('signal interior range', (V.dep_signal(base, base)[0][0], V.dep_signal(base, base)[-1][0]), (17, 82))
eq('signal too short', V.dep_signal(base[:34], base[:34]), [])
eq('departure none, not broken', V.departure(base, base, False), None)
eq('departure none, broken -> last interior index of common length 80', V.departure(base, base[:80], True), 62)
eq('departure none, broken and too short', V.departure(base[:20], base[:20], True), 0)
# step of +0.2 from index 50: centred window at i holds i - 37 elevated points -> 13 at i = 50 (0.104), 12 at 49 (0.096)
eq('step 0.2 at 50 departs at 50', V.departure(base[:50] + [1.2] * 50, base, False), 50)
# step of 0.19: 0.0988 at i = 50, 0.1064 at i = 51
eq('step 0.19 at 50 departs at 51', V.departure(base[:50] + [1.19] * 50, base, False), 51)
eq('negative step departs too', V.departure(base[:50] + [0.8] * 50, base, False), 50)
eq('constant offset just below threshold', V.departure([1.0999] * 100, base, False), None)
eq('constant offset just above threshold -> first interior index', V.departure([1.1001] * 100, base, False), 17)
eq('edge spikes ignored', V.departure([3.0] + base[1:99] + [3.0], base, False), None)
eq('single 2-pu spike filtered (2/25 = 0.08)', V.departure(base[:50] + [3.0] + base[51:], base, False), None)
eq('single 3-pu spike departs (3/25 = 0.12) at first window holding it', V.departure(base[:50] + [4.0] + base[51:], base, False), 38)
alt = [1.0 + (0.15 if i % 2 else -0.15) for i in range(100)]
eq('alternating 0.15-pu ripple filtered', V.departure(alt, base, False), None)
ts = [round(0.0004 * (i + 1), 7) for i in range(2000)]          # 0.0004 ... 0.8 s
i_win = max(i for i, t in enumerate(ts) if t <= V.SAT_WIN)
eq('window index is last record <= T_r+0.5', ts[i_win], 0.75)
eq('limit without departure = window', V.limit_index(ts, None), i_win)
eq('limit with early departure = departure', V.limit_index(ts, 100), 100)
eq('limit with late departure = window', V.limit_index(ts, 1900), i_win)
eq('limit departure at window index', V.limit_index(ts, i_win), i_win)
eq('limit no record in window', V.limit_index([0.9, 1.0], None), None)
cum = {'n': [0, 100, 200, 300], 'sat': [0, 0, 1, 50]}
eq('sat_until includes the limit record', V.sat_until(cum, 2), 1 / 200)
eq('sat_until last record', V.sat_until(cum, 3), 50 / 300)
eq('sat_until zero evaluations', V.sat_until(cum, 0), None)
eq('sat_until None limit', V.sat_until(cum, None), None)
eq('sat_until index outside', V.sat_until(cum, 4), None)
eq('same grid', V.same_grid(ts, ts[:500]), True)
eq('different grid', V.same_grid(ts, [t + 1e-6 for t in ts]), False)
eq('empty grid', V.same_grid([], ts), False)


def rows(st):
    ids = [('F2-x', 'A_between'), ('F2-x', 'B_beyond'), ('A2-1', 'A_between'), ('A2-1', 'B_below'),
           ('A2-2', 'A_between'), ('A2-2', 'B_below')]
    return [dict(id=i, case=c, status=s, agree=a) for (i, c), (s, a) in zip(ids, st)]


G = ('ok', True)
X = ('E3', None)
# s7 rows
eq('K1 three evaluable', V.verdict(rows([G, G, G, X, X, X]))[:2], ('K1', 'NOT_EVALUABLE'))
eq('K1 beats K2', V.verdict(rows([('ok', False), G, G, ('E1', None), ('E2', None), ('E4', None)]))[:2], ('K1', 'NOT_EVALUABLE'))
eq('exactly four evaluable is not K1', V.verdict(rows([X, X, G, G, G, G]))[:2], ('K4', 'SUPPORTED'))
eq('K2 one disagree', V.verdict(rows([G, G, G, ('ok', False), G, G])), ('K2', 'NOT_SUPPORTED', [('A2-1', 'B_below')]))
eq('K2 before K3', V.verdict(rows([('ok', False), G, X, G, G, G]))[:2], ('K2', 'NOT_SUPPORTED'))
eq('K3 A2 A_between missing', V.verdict(rows([G, G, X, G, G, G]))[:2], ('K3', 'PARTIALLY_SUPPORTED'))
eq('K4 all', V.verdict(rows([G] * 6)), ('K4', 'SUPPORTED', []))

# v3.1 D4 resume with a broken last line
d = sys.argv[1]
p = os.path.join(d, 'resume_test.jsonl')
V._write_text(p, '{"a": 1}\n{"a": 2}\n{"a": 3, "tr')
eq('broken last line dropped', V.load_rows(p), [{'a': 1}, {'a': 2}])
eq('file rewritten without it', V._read_bytes(p).decode('utf-8'), '{"a": 1}\n{"a": 2}\n')
V._write_text(p, '{"a": 1}\n{"a": 2}')
eq('valid last line without newline kept', V.load_rows(p), [{'a': 1}, {'a': 2}])
eq('missing final newline repaired', V._read_bytes(p).decode('utf-8'), '{"a": 1}\n{"a": 2}\n')
V._write_text(p, '{"a": 1}\n{"a": 2, "tr\n{"a": 3}\n')
try:
    V.load_rows(p)
    eq('broken middle line raises', False, True)
except ValueError:
    eq('broken middle line raises', True, True)
os.remove(p)
print('ALL PASS' if all(ok) else 'FAILED', sum(ok), len(ok))
sys.exit(0 if all(ok) else 1)
