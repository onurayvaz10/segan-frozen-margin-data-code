"""Y4 (protocol P92 section 4): ramped resistive load shedding in the original model F2 (no limiter).

G_R(t) = G_R - dG * min(t / T_r, 1) from the common pre-shedding equilibrium (T_r = 0: step), integrated for T_r + 3 s
(Radau, rtol 1e-7, atol 1e-9, max step 5 ms, as the abrupt-shedding check of the study). Divergence: bus-voltage
deviation from the post-shedding equilibrium above 1 pu (terminal event) or solver failure.

  --selftest   member (0.65, 0.20), reference amount, T_r = 0 and 1 s, 0.5 s after the ramp (OUT/selftest_y4.json)
  --run        full grid into OUT/y4/ramp.jsonl (resumes; refuses if OUT/y4/exit_code.txt exists)
"""
import argparse
import json
import math
import sys
import time
import traceback
from pathlib import Path

import numpy as np
from scipy.integrate import solve_ivp

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import y_common as U  # noqa: E402
import ext_common as C  # noqa: E402
import ext_engine as E  # noqa: E402

MAIN = (0.65, 0.20)
OTHERS = [(0.55, 0.34), (0.60, 0.27), (0.625, 0.22), (0.675, 0.18), (0.70, 0.29)]
TR_FULL = (0.0, 0.05, 0.1, 0.25, 0.5, 1.0, 2.0, 4.0)
TR_SHORT = (0.0, 1.0, 4.0)
TR_OTHERS = (0.0, 0.25, 1.0, 4.0)


def amounts(P_set, G_R):
    lay, G, P = C.build_F2(P_set, G_R)
    r = C.stage1(lay, G, P, rec={}, strict=False)
    s2 = C.stage2(lay, G, P, r, with_exact=False)
    return dict(frozen=r['dGf'], quadratic=r['dG2nd'], reference=s2['dGref'], tangent=r['dG1st'],
                ref_status=s2['ref_status'])


def simulate(P_set, G_R, dG, Tr, T_after=3.0):
    lay, G, P = C.build_F2(P_set, G_R)
    d = E.dispatch(lay, P, G, tol=1e-12)
    x_pre, refs = d['x'], d['refs']
    sb = lay.sysd['shed_bus']
    Gp = G.copy()
    Gp[sb] -= dG
    x_eq, ok, _, _ = E.newton_fixed_refs(lay, x_pre, refs, Gp)
    ix = lay.ix
    bR, bI = ix[f'V{sb}:R'], ix[f'V{sb}:I']
    vb_eq = math.hypot(x_eq[bR], x_eq[bI])
    Minv = 1.0 / lay.M

    def Gt(t):
        g = G.copy()
        g[sb] -= dG * (1.0 if Tr <= 0 else min(t / Tr, 1.0))
        return g

    def f(t, x):
        return Minv * E.rhs(lay, x, refs, Gt(t))

    def jac(t, x):
        return Minv[:, None] * E.jac(lay, x, refs, Gt(t))

    def ev(t, x):
        return 1.0 - abs(math.hypot(x[bR], x[bI]) - vb_eq)
    ev.terminal = True
    T_end = Tr + T_after
    T = np.linspace(0, T_end, int(round(T_end * 1000)) + 1)
    t0 = time.perf_counter()
    sol = solve_ivp(f, (0, T_end), x_pre, t_eval=T, method='Radau', rtol=1e-7, atol=1e-9, max_step=0.005, jac=jac,
                    events=ev)
    vb = np.hypot(sol.y[bR], sol.y[bI]) - vb_eq
    after = sol.t >= Tr
    last = sol.t >= T_end - 0.5
    ev_t = float(sol.t_events[0][0]) if len(sol.t_events[0]) else None
    return dict(P_set=P_set, G_R=G_R, dG=dG, T_r=Tr, equilibrium_found=bool(ok), success=bool(sol.success),
                message=str(sol.message), diverged_at_s=ev_t, diverged=bool(ev_t is not None or not sol.success),
                last_time_s=float(sol.t[-1]), peak_dev_after_ramp=float(np.abs(vb[after]).max()) if after.any() else None,
                envelope_last_0p5s=float(np.abs(vb[last]).max()) if last.any() else None,
                final_dev=float(abs(vb[-1])), t_wall_s=time.perf_counter() - t0,
                trace=[[float(sol.t[j]), float(vb[j])] for j in range(0, len(sol.t), 10)])


def grid():
    out = []
    a = amounts(*MAIN)
    for name in ('quadratic', 'reference'):
        out += [(MAIN, name, a[name], tr) for tr in TR_FULL]
    for name in ('frozen', 'tangent'):
        out += [(MAIN, name, a[name], tr) for tr in TR_SHORT]
    for m in OTHERS:
        am = amounts(*m)
        out += [(m, 'reference', am['reference'], tr) for tr in TR_OTHERS]
    return out


def main():
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument('--selftest', action='store_true')
    g.add_argument('--run', action='store_true')
    a = ap.parse_args()
    U.OUT.mkdir(parents=True, exist_ok=True)
    if a.selftest:
        am = amounts(*MAIN)
        res = [simulate(*MAIN, am['reference'], tr, T_after=0.5) for tr in (0.0, 1.0)]
        for r in res:
            r.pop('trace')
        (U.OUT / 'selftest_y4.json').write_text(json.dumps(U.clean(dict(amounts=am, runs=res)), indent=1),
                                                encoding='utf-8')
        print(am)
        for r in res:
            print(r['T_r'], r['diverged'], r['diverged_at_s'], r['peak_dev_after_ramp'], r['t_wall_s'])
        return 0
    od = U.OUT / 'y4'
    od.mkdir(parents=True, exist_ok=True)
    if (od / 'exit_code.txt').exists():
        print('refused: finished run exists')
        return 3
    jobs = grid()
    done = {(o['P_set'], o['G_R'], o['case'], o['T_r']) for o in U.load_jsonl(od / 'ramp.jsonl')}
    with open(od / 'ramp.jsonl', 'a', encoding='utf-8') as f, open(od / 'log.txt', 'a', encoding='utf-8') as lg:
        for (m, name, dG, tr) in jobs:
            if (m[0], m[1], name, tr) in done:
                continue
            try:
                o = simulate(m[0], m[1], dG, tr)
            except Exception as exc:  # noqa: BLE001
                o = dict(P_set=m[0], G_R=m[1], dG=dG, T_r=tr, diverged=None, error=f'{type(exc).__name__}: {exc}',
                         tb=traceback.format_exc()[-400:])
            o['case'] = name
            f.write(json.dumps(U.clean(o)) + '\n')
            f.flush()
            lg.write(f"{m} {name} dG={dG:.5f} Tr={tr} diverged={o.get('diverged')} at={o.get('diverged_at_s')} "
                     f"wall={o.get('t_wall_s')}\n")
            lg.flush()
    (od / 'exit_code.txt').write_text('0', encoding='utf-8')
    U.write_sums(od)
    return 0


if __name__ == '__main__':
    C.lower_priority()
    sys.exit(main())
