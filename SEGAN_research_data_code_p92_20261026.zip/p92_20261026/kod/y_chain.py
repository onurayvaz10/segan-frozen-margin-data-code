"""Run the P92 compute steps one after the other, each as its own subprocess (one heavy process at a time), after the
pins of the authorization file are verified. A step that ends with a non-zero exit code (e.g. an intermittent native
crash) is retried up to RETRIES times; every step resumes from its own output, so a retry never recomputes a point.
Usage: python -I y_chain.py"""
import json
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import y_common as U  # noqa: E402

AUTH = HERE.parent / 'protokol' / 'P92_yetki.json'
STEPS = ['y2_newton.py --run', 'y3_limiter.py --run', 'y4_ramp.py --run']
RETRIES = 5


def log(msg):
    with open(U.OUT / 'chain.txt', 'a', encoding='utf-8') as f:
        f.write(time.strftime('%H:%M:%S ') + msg + '\n')


def check():
    a = json.loads(AUTH.read_text(encoding='utf-8'))
    ok = a.get('action') == 'ALLOW_P92_RUN'
    for name, h in a['pins'].items():
        p = HERE.parent / name
        got = U.sha(p) if p.exists() else 'MISSING'
        log(f'pin {name} {"OK" if got == h else "MISMATCH " + got}')
        ok &= got == h
    return ok


U.OUT.mkdir(parents=True, exist_ok=True)
if not check():
    log('ABORT: pins')
    sys.exit(2)
for step in STEPS:
    for attempt in range(1, RETRIES + 1):
        r = subprocess.run([sys.executable, '-I'] + step.split(), cwd=HERE, stdout=subprocess.DEVNULL,
                           stderr=subprocess.PIPE)
        err = r.stderr.decode('utf-8', 'replace')[-600:]
        log(f'{step} attempt {attempt} exit {r.returncode}' + (f' stderr: {err!r}' if r.returncode else ''))
        if r.returncode in (0, 3):
            break
    else:
        log(f'{step} FAILED after {RETRIES} attempts; chain stopped')
        sys.exit(1)
log('chain done')
